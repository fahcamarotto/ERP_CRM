-- Sincronizacao do Google Calendar (worker): agenda Google sem recurso ligado ganha o recurso dela,
-- para os eventos virarem bloqueios visiveis. O worker passa a poder criar recurso (so INSERT, sem UPDATE).
GRANT INSERT ON agenda_recursos TO erp_worker;
