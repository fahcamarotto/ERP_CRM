-- M6 Agenda: recursos (profissional, sala, equipamento) com horario de trabalho e bloqueios, servicos com
-- duracao e preco, agendamentos (agenda_compromissos) com estado e recorrencia, e lembretes por job.
-- Toda tabela: tenant_id e workspace_id do contexto da sessao, PK composta, FK composta, RLS por
-- nucleo_aplicar_padrao, exclusao logica (sem DELETE). Idempotente.

-- M6.1 Recursos ------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS agenda_recursos (
  id                  uuid NOT NULL DEFAULT gen_random_uuid(),
  tenant_id           uuid NOT NULL DEFAULT nucleo_tenant_atual(),
  workspace_id        uuid NOT NULL DEFAULT nucleo_workspace_atual(),
  creator_id          uuid,
  nome                text NOT NULL CHECK (length(btrim(nome)) BETWEEN 2 AND 120),
  tipo                text NOT NULL DEFAULT 'profissional' CHECK (tipo IN ('profissional', 'sala', 'equipamento')),
  usuario_id          uuid,
  cor                 text NOT NULL DEFAULT 'acento' CHECK (cor IN ('acento', 'roxo', 'azul', 'ciano', 'laranja', 'dourado', 'sucesso', 'perigo')),
  fuso                text NOT NULL DEFAULT 'America/Sao_Paulo',
  horario             jsonb NOT NULL DEFAULT '[]'::jsonb CHECK (jsonb_typeof(horario) = 'array'),
  google_calendar_id  text,
  descricao           text,
  estado              text NOT NULL DEFAULT 'ativo' CHECK (estado IN ('ativo', 'arquivado')),
  extras              jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at          timestamptz NOT NULL DEFAULT now(),
  updated_at          timestamptz NOT NULL DEFAULT now(),
  deleted_at          timestamptz,
  PRIMARY KEY (id, tenant_id, workspace_id),
  FOREIGN KEY (workspace_id, tenant_id) REFERENCES workspaces (id, tenant_id),
  FOREIGN KEY (creator_id, tenant_id, workspace_id) REFERENCES usuarios (id, tenant_id, workspace_id),
  FOREIGN KEY (usuario_id, tenant_id, workspace_id) REFERENCES usuarios (id, tenant_id, workspace_id),
  CHECK (usuario_id IS NULL OR tipo = 'profissional')
);
CREATE UNIQUE INDEX IF NOT EXISTS agenda_recursos_nome_uq ON agenda_recursos (tenant_id, workspace_id, lower(nome)) WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS agenda_recursos_calendario_idx ON agenda_recursos (tenant_id, workspace_id, google_calendar_id) WHERE google_calendar_id IS NOT NULL AND deleted_at IS NULL;
SELECT nucleo_aplicar_padrao('agenda_recursos');
DROP TRIGGER IF EXISTS agenda_recursos_extras ON agenda_recursos;
CREATE TRIGGER agenda_recursos_extras BEFORE INSERT OR UPDATE OF extras ON agenda_recursos
  FOR EACH ROW EXECUTE FUNCTION nucleo_trigger_extras('agenda', 'recurso');

CREATE TABLE IF NOT EXISTS agenda_bloqueios (
  id                uuid NOT NULL DEFAULT gen_random_uuid(),
  tenant_id         uuid NOT NULL DEFAULT nucleo_tenant_atual(),
  workspace_id      uuid NOT NULL DEFAULT nucleo_workspace_atual(),
  creator_id        uuid,
  recurso_id        uuid NOT NULL,
  inicio            timestamptz NOT NULL,
  fim               timestamptz NOT NULL,
  motivo            text,
  origem            text NOT NULL DEFAULT 'manual' CHECK (origem IN ('manual', 'google')),
  google_evento_id  text,
  created_at        timestamptz NOT NULL DEFAULT now(),
  updated_at        timestamptz NOT NULL DEFAULT now(),
  deleted_at        timestamptz,
  PRIMARY KEY (id, tenant_id, workspace_id),
  FOREIGN KEY (workspace_id, tenant_id) REFERENCES workspaces (id, tenant_id),
  FOREIGN KEY (creator_id, tenant_id, workspace_id) REFERENCES usuarios (id, tenant_id, workspace_id),
  FOREIGN KEY (recurso_id, tenant_id, workspace_id) REFERENCES agenda_recursos (id, tenant_id, workspace_id),
  CHECK (fim > inicio)
);
CREATE INDEX IF NOT EXISTS agenda_bloqueios_periodo_idx ON agenda_bloqueios (tenant_id, workspace_id, recurso_id, inicio, fim) WHERE deleted_at IS NULL;
CREATE UNIQUE INDEX IF NOT EXISTS agenda_bloqueios_google_uq ON agenda_bloqueios (tenant_id, workspace_id, google_evento_id) WHERE google_evento_id IS NOT NULL AND deleted_at IS NULL;
SELECT nucleo_aplicar_padrao('agenda_bloqueios');

-- M6.2 Servicos ------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS agenda_servicos (
  id             uuid NOT NULL DEFAULT gen_random_uuid(),
  tenant_id      uuid NOT NULL DEFAULT nucleo_tenant_atual(),
  workspace_id   uuid NOT NULL DEFAULT nucleo_workspace_atual(),
  creator_id     uuid,
  nome           text NOT NULL CHECK (length(btrim(nome)) BETWEEN 2 AND 120),
  descricao      text,
  duracao_min    integer NOT NULL CHECK (duracao_min BETWEEN 5 AND 720 AND duracao_min % 5 = 0),
  intervalo_min  integer NOT NULL DEFAULT 0 CHECK (intervalo_min BETWEEN 0 AND 240),
  preco          numeric(14, 2) CHECK (preco IS NULL OR preco >= 0),
  moeda          char(3) NOT NULL DEFAULT 'BRL' CHECK (moeda ~ '^[A-Z]{3}$'),
  cor            text NOT NULL DEFAULT 'azul' CHECK (cor IN ('acento', 'roxo', 'azul', 'ciano', 'laranja', 'dourado', 'sucesso', 'perigo')),
  estado         text NOT NULL DEFAULT 'ativo' CHECK (estado IN ('ativo', 'arquivado')),
  extras         jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at     timestamptz NOT NULL DEFAULT now(),
  updated_at     timestamptz NOT NULL DEFAULT now(),
  deleted_at     timestamptz,
  PRIMARY KEY (id, tenant_id, workspace_id),
  FOREIGN KEY (workspace_id, tenant_id) REFERENCES workspaces (id, tenant_id),
  FOREIGN KEY (creator_id, tenant_id, workspace_id) REFERENCES usuarios (id, tenant_id, workspace_id)
);
CREATE UNIQUE INDEX IF NOT EXISTS agenda_servicos_nome_uq ON agenda_servicos (tenant_id, workspace_id, lower(nome)) WHERE deleted_at IS NULL;
SELECT nucleo_aplicar_padrao('agenda_servicos');
DROP TRIGGER IF EXISTS agenda_servicos_extras ON agenda_servicos;
CREATE TRIGGER agenda_servicos_extras BEFORE INSERT OR UPDATE OF extras ON agenda_servicos
  FOR EACH ROW EXECUTE FUNCTION nucleo_trigger_extras('agenda', 'servico');

CREATE TABLE IF NOT EXISTS agenda_servico_recursos (
  id            uuid NOT NULL DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL DEFAULT nucleo_tenant_atual(),
  workspace_id  uuid NOT NULL DEFAULT nucleo_workspace_atual(),
  creator_id    uuid,
  servico_id    uuid NOT NULL,
  recurso_id    uuid NOT NULL,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now(),
  deleted_at    timestamptz,
  PRIMARY KEY (id, tenant_id, workspace_id),
  FOREIGN KEY (workspace_id, tenant_id) REFERENCES workspaces (id, tenant_id),
  FOREIGN KEY (creator_id, tenant_id, workspace_id) REFERENCES usuarios (id, tenant_id, workspace_id),
  FOREIGN KEY (servico_id, tenant_id, workspace_id) REFERENCES agenda_servicos (id, tenant_id, workspace_id),
  FOREIGN KEY (recurso_id, tenant_id, workspace_id) REFERENCES agenda_recursos (id, tenant_id, workspace_id)
);
CREATE UNIQUE INDEX IF NOT EXISTS agenda_servico_recursos_uq ON agenda_servico_recursos (tenant_id, workspace_id, servico_id, recurso_id);
SELECT nucleo_aplicar_padrao('agenda_servico_recursos');

-- M6.3 Agregado Agendamento ------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS agenda_compromissos (
  id                uuid NOT NULL DEFAULT gen_random_uuid(),
  tenant_id         uuid NOT NULL DEFAULT nucleo_tenant_atual(),
  workspace_id      uuid NOT NULL DEFAULT nucleo_workspace_atual(),
  creator_id        uuid,
  recurso_id        uuid NOT NULL,
  servico_id        uuid,
  parceiro_id       uuid,
  oportunidade_id   uuid,
  titulo            text CHECK (titulo IS NULL OR length(titulo) <= 200),
  inicio            timestamptz NOT NULL,
  fim               timestamptz NOT NULL,
  estado            text NOT NULL DEFAULT 'marcado' CHECK (estado IN ('marcado', 'confirmado', 'realizado', 'faltou', 'cancelado')),
  observacoes       text,
  recorrencia       jsonb,
  serie_id          uuid,
  origem            text NOT NULL DEFAULT 'manual' CHECK (origem IN ('manual', 'api', 'google')),
  google_evento_id  text,
  google_estado     text CHECK (google_estado IS NULL OR google_estado IN ('pendente_envio', 'sincronizado', 'sem_conector')),
  extras            jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at        timestamptz NOT NULL DEFAULT now(),
  updated_at        timestamptz NOT NULL DEFAULT now(),
  deleted_at        timestamptz,
  PRIMARY KEY (id, tenant_id, workspace_id),
  FOREIGN KEY (workspace_id, tenant_id) REFERENCES workspaces (id, tenant_id),
  FOREIGN KEY (creator_id, tenant_id, workspace_id) REFERENCES usuarios (id, tenant_id, workspace_id),
  FOREIGN KEY (recurso_id, tenant_id, workspace_id) REFERENCES agenda_recursos (id, tenant_id, workspace_id),
  FOREIGN KEY (servico_id, tenant_id, workspace_id) REFERENCES agenda_servicos (id, tenant_id, workspace_id),
  FOREIGN KEY (parceiro_id, tenant_id, workspace_id) REFERENCES cadastros_parceiros (id, tenant_id, workspace_id),
  CHECK (fim > inicio AND fim - inicio <= interval '24 hours')
);
CREATE INDEX IF NOT EXISTS agenda_compromissos_periodo_idx ON agenda_compromissos (tenant_id, workspace_id, recurso_id, inicio, fim) WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS agenda_compromissos_lista_idx ON agenda_compromissos (tenant_id, workspace_id, created_at, id) WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS agenda_compromissos_parceiro_idx ON agenda_compromissos (tenant_id, workspace_id, parceiro_id) WHERE deleted_at IS NULL;
CREATE UNIQUE INDEX IF NOT EXISTS agenda_compromissos_google_uq ON agenda_compromissos (tenant_id, workspace_id, google_evento_id) WHERE google_evento_id IS NOT NULL AND deleted_at IS NULL;
SELECT nucleo_aplicar_padrao('agenda_compromissos');
DROP TRIGGER IF EXISTS agenda_compromissos_extras ON agenda_compromissos;
CREATE TRIGGER agenda_compromissos_extras BEFORE INSERT OR UPDATE OF extras ON agenda_compromissos
  FOR EACH ROW EXECUTE FUNCTION nucleo_trigger_extras('agenda', 'compromisso');

-- M6.4 Conflito bloqueado na gravacao (segunda barreira depois do caso de uso). Trava por recurso na
-- transacao e recusa sobreposicao com agendamento que ocupa horario; sai como 23505 (409 conflito).
CREATE OR REPLACE FUNCTION agenda_compromisso_sem_conflito() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF NEW.deleted_at IS NOT NULL OR NEW.estado NOT IN ('marcado', 'confirmado', 'realizado') THEN
    RETURN NEW;
  END IF;
  PERFORM pg_advisory_xact_lock(hashtextextended('agenda:' || NEW.tenant_id::text || ':' || NEW.workspace_id::text || ':' || NEW.recurso_id::text, 0));
  IF EXISTS (
    SELECT 1 FROM agenda_compromissos x
     WHERE x.tenant_id = NEW.tenant_id AND x.workspace_id = NEW.workspace_id AND x.recurso_id = NEW.recurso_id AND x.id <> NEW.id
       AND x.deleted_at IS NULL AND x.estado IN ('marcado', 'confirmado', 'realizado')
       AND x.inicio < NEW.fim AND x.fim > NEW.inicio
  ) THEN
    RAISE EXCEPTION 'Horario ocupado para este recurso' USING ERRCODE = 'unique_violation';
  END IF;
  RETURN NEW;
END $$;
DROP TRIGGER IF EXISTS agenda_compromissos_sem_conflito ON agenda_compromissos;
CREATE TRIGGER agenda_compromissos_sem_conflito BEFORE INSERT OR UPDATE OF inicio, fim, recurso_id, estado, deleted_at ON agenda_compromissos
  FOR EACH ROW EXECUTE FUNCTION agenda_compromisso_sem_conflito();

-- M6.6 Confirmacao e lembretes (um job agenda.lembrete por linha, com disponivel_em) ------------
CREATE TABLE IF NOT EXISTS agenda_lembretes (
  id                 uuid NOT NULL DEFAULT gen_random_uuid(),
  tenant_id          uuid NOT NULL DEFAULT nucleo_tenant_atual(),
  workspace_id       uuid NOT NULL DEFAULT nucleo_workspace_atual(),
  creator_id         uuid,
  compromisso_id     uuid NOT NULL,
  tipo               text NOT NULL CHECK (tipo IN ('confirmacao', 'lembrete')),
  horas_antes        integer CHECK (horas_antes IS NULL OR horas_antes BETWEEN 1 AND 168),
  canal              text NOT NULL DEFAULT 'whatsapp' CHECK (canal IN ('whatsapp')),
  programado_para    timestamptz NOT NULL,
  referencia_inicio  timestamptz NOT NULL,
  estado             text NOT NULL DEFAULT 'agendado'
                     CHECK (estado IN ('agendado', 'enviado', 'aguardando_canal', 'sem_conector', 'sem_telefone', 'cancelado', 'erro')),
  mensagem           text,
  erro               text,
  job_id             uuid,
  processado_em      timestamptz,
  created_at         timestamptz NOT NULL DEFAULT now(),
  updated_at         timestamptz NOT NULL DEFAULT now(),
  deleted_at         timestamptz,
  PRIMARY KEY (id, tenant_id, workspace_id),
  FOREIGN KEY (workspace_id, tenant_id) REFERENCES workspaces (id, tenant_id),
  FOREIGN KEY (creator_id, tenant_id, workspace_id) REFERENCES usuarios (id, tenant_id, workspace_id),
  FOREIGN KEY (compromisso_id, tenant_id, workspace_id) REFERENCES agenda_compromissos (id, tenant_id, workspace_id)
);
CREATE INDEX IF NOT EXISTS agenda_lembretes_compromisso_idx ON agenda_lembretes (tenant_id, workspace_id, compromisso_id) WHERE deleted_at IS NULL;
SELECT nucleo_aplicar_padrao('agenda_lembretes');

-- Papeis de banco: API (erp_app) e worker (erp_worker: lembretes, sincronizacao do Google Calendar).
GRANT SELECT, INSERT, UPDATE ON agenda_recursos, agenda_bloqueios, agenda_servicos, agenda_servico_recursos,
  agenda_compromissos, agenda_lembretes TO erp_app;
GRANT SELECT, INSERT, UPDATE ON agenda_bloqueios, agenda_compromissos, agenda_lembretes TO erp_worker;
GRANT SELECT ON agenda_recursos, agenda_servicos, agenda_servico_recursos TO erp_worker;
