/** Portas do agregado Servico, segregadas por operacao. */
import type { Servico } from './servico.ts';

export interface ObterServico {
  obterPorId(id: string): Promise<Servico | null>;
}

export interface GravarServico {
  inserir(s: Servico): Promise<void>;
  atualizar(s: Servico): Promise<void>;
}

export interface BuscarServicoPorNome {
  buscarPorNome(nome: string): Promise<Servico | null>;
}

/** Referencia fora do agregado: recursos ativos do workspace. */
export interface ConsultarRecursosAtivos {
  recursosAtivos(ids: string[]): Promise<string[]>;
}
