/**
 * Entidade Servico (M6.2): duracao, intervalo de preparo depois do atendimento, preco e recursos que o atendem.
 * Imutavel: toda alteracao devolve um clone novo.
 */
import { randomUUID } from 'node:crypto';
import { erroDe, fail, ok, type ErroDominio, type Result } from '../../compartilhado/result.ts';
import { CORES, type Cor, type EstadoCadastro } from '../../recurso/model/recurso.ts';

export interface DadosServico {
  nome: string;
  descricao?: string | null;
  duracao_min?: number;
  intervalo_min?: number;
  preco?: number | null;
  moeda?: string;
  cor?: Cor;
  recurso_ids?: string[];
  extras?: Record<string, unknown>;
}

export interface ServicoDados {
  id: string;
  nome: string;
  descricao: string | null;
  duracao_min: number;
  intervalo_min: number;
  preco: number | null;
  moeda: string;
  cor: Cor;
  recurso_ids: string[];
  estado: EstadoCadastro;
  extras: Record<string, unknown>;
}

const t = (v?: string | null) => (v ?? '').trim() || null;
const dinheiro = (v: number | null | undefined) => (v === undefined || v === null ? null : Math.round(Number(v) * 100) / 100);

function validar(d: ServicoDados): ErroDominio[] {
  const e: ErroDominio[] = [];
  if (d.nome.length < 2 || d.nome.length > 120) e.push(erroDe('nome_invalido', 'Nome deve ter de 2 a 120 caracteres', 'nome'));
  if (!Number.isInteger(d.duracao_min) || d.duracao_min < 5 || d.duracao_min > 720 || d.duracao_min % 5 !== 0) {
    e.push(erroDe('duracao_invalida', 'Duracao de 5 a 720 minutos, em multiplos de 5', 'duracao_min'));
  }
  if (!Number.isInteger(d.intervalo_min) || d.intervalo_min < 0 || d.intervalo_min > 240) e.push(erroDe('intervalo_invalido', 'Intervalo de 0 a 240 minutos', 'intervalo_min'));
  if (d.preco !== null && (!Number.isFinite(d.preco) || d.preco < 0)) e.push(erroDe('preco_invalido', 'Preco deve ser zero ou positivo', 'preco'));
  if (!/^[A-Z]{3}$/.test(d.moeda)) e.push(erroDe('moeda_invalida', 'Moeda em ISO 4217 (BRL, USD, EUR)', 'moeda'));
  if (!CORES.includes(d.cor)) e.push(erroDe('cor_invalida', 'Cor fora da paleta', 'cor'));
  if (d.recurso_ids.length > 100) e.push(erroDe('recursos_invalidos', 'Maximo de 100 recursos', 'recurso_ids'));
  return e;
}

export class Servico {
  private constructor(private readonly d: ServicoDados) {}

  static tryCreate(e: DadosServico, id: string = randomUUID()): Result<Servico> {
    const d: ServicoDados = {
      id, nome: (e.nome ?? '').trim(), descricao: t(e.descricao), duracao_min: Number(e.duracao_min ?? 60), intervalo_min: Number(e.intervalo_min ?? 0),
      preco: dinheiro(e.preco), moeda: (t(e.moeda) ?? 'BRL').toUpperCase(), cor: e.cor ?? 'azul', recurso_ids: [...new Set(e.recurso_ids ?? [])],
      estado: 'ativo', extras: e.extras ?? {},
    };
    const erros = validar(d);
    return erros.length ? fail(...erros) : ok(new Servico(d));
  }

  static create(e: DadosServico, id?: string): Servico {
    const r = Servico.tryCreate(e, id);
    if (!r.ok) throw new Error(r.erros.map((x) => x.mensagem).join('; '));
    return r.valor;
  }

  static reidratar(d: ServicoDados): Servico {
    return new Servico({ ...d, recurso_ids: [...(d.recurso_ids ?? [])], extras: { ...(d.extras ?? {}) } });
  }

  get id(): string { return this.d.id; }
  get estado(): EstadoCadastro { return this.d.estado; }
  get duracaoMin(): number { return this.d.duracao_min; }
  get intervaloMin(): number { return this.d.intervalo_min; }
  get recursoIds(): string[] { return [...this.d.recurso_ids]; }

  /** O recurso pode atender este servico? Lista vazia = qualquer recurso. */
  atendidoPor(recursoId: string): boolean {
    return this.d.recurso_ids.length === 0 || this.d.recurso_ids.includes(recursoId);
  }

  editar(e: Partial<DadosServico>): Result<Servico> {
    if (this.d.estado === 'arquivado') return fail(erroDe('transicao_invalida', 'Servico arquivado nao pode ser editado; reative antes'));
    const tem = (k: keyof DadosServico) => e[k] !== undefined;
    const n: ServicoDados = {
      ...this.d,
      nome: tem('nome') ? (e.nome ?? '').trim() : this.d.nome,
      descricao: tem('descricao') ? t(e.descricao) : this.d.descricao,
      duracao_min: tem('duracao_min') ? Number(e.duracao_min) : this.d.duracao_min,
      intervalo_min: tem('intervalo_min') ? Number(e.intervalo_min) : this.d.intervalo_min,
      preco: tem('preco') ? dinheiro(e.preco) : this.d.preco,
      moeda: tem('moeda') ? (t(e.moeda) ?? 'BRL').toUpperCase() : this.d.moeda,
      cor: tem('cor') ? e.cor! : this.d.cor,
      recurso_ids: tem('recurso_ids') ? [...new Set(e.recurso_ids!)] : [...this.d.recurso_ids],
      extras: tem('extras') ? { ...e.extras } : { ...this.d.extras },
    };
    const erros = validar(n);
    return erros.length ? fail(...erros) : ok(new Servico(n));
  }

  mudarEstado(novo: EstadoCadastro): Result<Servico> {
    if (novo !== 'ativo' && novo !== 'arquivado') return fail(erroDe('estado_invalido', 'Estado invalido', 'estado'));
    if (novo === this.d.estado) return fail(erroDe('transicao_invalida', `Servico ja esta ${novo}`, 'estado'));
    return ok(new Servico({ ...this.d, estado: novo }));
  }

  paraDados(): ServicoDados {
    return { ...this.d, recurso_ids: [...this.d.recurso_ids], extras: { ...this.d.extras } };
  }
}
