/** Adaptador Postgres do Servico e da ligacao servico x recurso (N para N com exclusao logica). */
import type pg from 'pg';
import type { BuscarServicoPorNome, ConsultarRecursosAtivos, GravarServico, ObterServico } from '../model/portas.ts';
import { Servico, type ServicoDados } from '../model/servico.ts';

const SELECT = `SELECT s.id, s.nome, s.descricao, s.duracao_min, s.intervalo_min, s.preco::float8 AS preco, s.moeda, s.cor, s.estado, s.extras,
  coalesce((SELECT array_agg(sr.recurso_id) FROM agenda_servico_recursos sr WHERE sr.servico_id = s.id AND sr.deleted_at IS NULL), '{}') AS recurso_ids
  FROM agenda_servicos s`;

export class ServicoRepoPg implements ObterServico, GravarServico, BuscarServicoPorNome, ConsultarRecursosAtivos {
  constructor(private readonly c: pg.PoolClient) {}

  async obterPorId(id: string): Promise<Servico | null> {
    const r = await this.c.query(`${SELECT} WHERE s.id = $1 AND s.deleted_at IS NULL`, [id]);
    return r.rows[0] ? Servico.reidratar(r.rows[0] as ServicoDados) : null;
  }

  async buscarPorNome(nome: string): Promise<Servico | null> {
    const r = await this.c.query(`${SELECT} WHERE lower(s.nome) = lower($1) AND s.deleted_at IS NULL LIMIT 1`, [nome]);
    return r.rows[0] ? Servico.reidratar(r.rows[0] as ServicoDados) : null;
  }

  async inserir(s: Servico): Promise<void> {
    const d = s.paraDados();
    await this.c.query(
      `INSERT INTO agenda_servicos (id, nome, descricao, duracao_min, intervalo_min, preco, moeda, cor, estado, extras, creator_id)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, nucleo_usuario_atual())`,
      [d.id, d.nome, d.descricao, d.duracao_min, d.intervalo_min, d.preco, d.moeda, d.cor, d.estado, JSON.stringify(d.extras)],
    );
    await this.sincronizarRecursos(d.id, d.recurso_ids);
  }

  async atualizar(s: Servico): Promise<void> {
    const d = s.paraDados();
    await this.c.query(
      `UPDATE agenda_servicos SET nome = $2, descricao = $3, duracao_min = $4, intervalo_min = $5, preco = $6, moeda = $7, cor = $8,
         estado = $9, extras = $10 WHERE id = $1 AND deleted_at IS NULL`,
      [d.id, d.nome, d.descricao, d.duracao_min, d.intervalo_min, d.preco, d.moeda, d.cor, d.estado, JSON.stringify(d.extras)],
    );
    await this.sincronizarRecursos(d.id, d.recurso_ids);
  }

  private async sincronizarRecursos(servicoId: string, ids: string[]): Promise<void> {
    await this.c.query(
      'UPDATE agenda_servico_recursos SET deleted_at = now() WHERE servico_id = $1 AND deleted_at IS NULL AND NOT (recurso_id = ANY ($2::uuid[]))',
      [servicoId, ids],
    );
    if (!ids.length) return;
    await this.c.query(
      `INSERT INTO agenda_servico_recursos (servico_id, recurso_id, creator_id) SELECT $1, r, nucleo_usuario_atual() FROM unnest($2::uuid[]) r
       ON CONFLICT (tenant_id, workspace_id, servico_id, recurso_id) DO UPDATE SET deleted_at = NULL`,
      [servicoId, ids],
    );
  }

  async recursosAtivos(ids: string[]): Promise<string[]> {
    const r = await this.c.query("SELECT id FROM agenda_recursos WHERE id = ANY ($1::uuid[]) AND estado = 'ativo' AND deleted_at IS NULL", [ids]);
    return r.rows.map((x) => x.id as string);
  }
}
