/** Consultas de leitura do Servico: lista e ficha com os recursos que atendem. */
import type pg from 'pg';

const RESUMO = `s.id, s.nome, s.descricao, s.duracao_min, s.intervalo_min, s.preco::float8 AS preco, s.moeda, s.cor, s.estado, s.created_at, s.updated_at,
  coalesce((SELECT json_agg(json_build_object('id', r.id, 'nome', r.nome) ORDER BY r.nome) FROM agenda_servico_recursos sr
            JOIN agenda_recursos r ON r.id = sr.recurso_id AND r.deleted_at IS NULL WHERE sr.servico_id = s.id AND sr.deleted_at IS NULL), '[]') AS recursos`;

export async function listarServicos(c: pg.PoolClient, f: { estado?: 'ativo' | 'arquivado' | 'todos'; busca?: string; recurso_id?: string } = {}) {
  const r = await c.query(
    `SELECT ${RESUMO} FROM agenda_servicos s
     WHERE s.deleted_at IS NULL AND ($1::text = 'todos' OR s.estado = $1) AND ($2::text IS NULL OR s.nome ILIKE '%' || $2 || '%')
       AND ($3::uuid IS NULL OR NOT EXISTS (SELECT 1 FROM agenda_servico_recursos z WHERE z.servico_id = s.id AND z.deleted_at IS NULL)
            OR EXISTS (SELECT 1 FROM agenda_servico_recursos z WHERE z.servico_id = s.id AND z.recurso_id = $3 AND z.deleted_at IS NULL))
     ORDER BY s.nome LIMIT 500`,
    [f.estado ?? 'ativo', f.busca?.trim() || null, f.recurso_id ?? null],
  );
  return r.rows;
}

export async function obterServico(c: pg.PoolClient, id: string) {
  return (await c.query(`SELECT ${RESUMO}, s.extras FROM agenda_servicos s WHERE s.id = $1 AND s.deleted_at IS NULL`, [id])).rows[0] ?? null;
}
