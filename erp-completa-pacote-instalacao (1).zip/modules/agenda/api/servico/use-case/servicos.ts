/** Casos de uso do Servico (M6.2): CriarServico, EditarServico, MudarEstadoServico. */
import type { ContextoCaso } from '../../compartilhado/efeitos.ts';
import { erroDe, fail, ok, okVazio, type ErroDominio, type Result } from '../../compartilhado/result.ts';
import type { EstadoCadastro } from '../../recurso/model/recurso.ts';
import type { BuscarServicoPorNome, ConsultarRecursosAtivos, GravarServico, ObterServico } from '../model/portas.ts';
import { Servico, type DadosServico } from '../model/servico.ts';

const TABELA = 'agenda_servicos';

export interface DepsServico {
  repo: ObterServico & GravarServico & BuscarServicoPorNome;
  recursos: ConsultarRecursosAtivos;
}

async function conferir(deps: DepsServico, s: Servico, anterior?: Servico): Promise<ErroDominio[]> {
  const d = s.paraDados();
  const erros: ErroDominio[] = [];
  const mesmo = await deps.repo.buscarPorNome(d.nome);
  if (mesmo && mesmo.id !== d.id) erros.push(erroDe('conflito', 'Ja existe servico com este nome', 'nome', { servico_id: mesmo.id }));
  const novos = d.recurso_ids.filter((r) => !anterior?.recursoIds.includes(r));
  if (novos.length) {
    const ativos = new Set(await deps.recursos.recursosAtivos(novos));
    const faltam = novos.filter((r) => !ativos.has(r));
    if (faltam.length) erros.push(erroDe('recurso_invalido', 'Recurso nao encontrado ou arquivado', 'recurso_ids', { faltam }));
  }
  return erros;
}

export class CriarServico {
  constructor(private readonly deps: DepsServico) {}
  async execute(ctx: ContextoCaso, e: DadosServico): Promise<Result<{ id: string }>> {
    const r = Servico.tryCreate(e);
    if (!r.ok) return r;
    const erros = await conferir(this.deps, r.valor);
    if (erros.length) return fail(...erros);
    await this.deps.repo.inserir(r.valor);
    const d = r.valor.paraDados();
    await ctx.efeitos.auditar('servico.criar', TABELA, d.id, undefined, d);
    return ok({ id: d.id });
  }
}

export class EditarServico {
  constructor(private readonly deps: DepsServico) {}
  async execute(ctx: ContextoCaso, e: { id: string } & Partial<DadosServico>): Promise<Result<void>> {
    const { id, ...mud } = e;
    const atual = await this.deps.repo.obterPorId(id);
    if (!atual) return fail(erroDe('nao_encontrado', 'Servico nao encontrado'));
    const r = atual.editar(mud);
    if (!r.ok) return r;
    const erros = await conferir(this.deps, r.valor, atual);
    if (erros.length) return fail(...erros);
    await this.deps.repo.atualizar(r.valor);
    const antes = atual.paraDados() as unknown as Record<string, unknown>;
    const depois = r.valor.paraDados() as unknown as Record<string, unknown>;
    await ctx.efeitos.historico(TABELA, id, antes, depois);
    await ctx.efeitos.auditar('servico.editar', TABELA, id, antes, depois);
    return okVazio();
  }
}

export class MudarEstadoServico {
  constructor(private readonly deps: { repo: ObterServico & GravarServico }) {}
  async execute(ctx: ContextoCaso, e: { id: string; estado: EstadoCadastro }): Promise<Result<void>> {
    const atual = await this.deps.repo.obterPorId(e.id);
    if (!atual) return fail(erroDe('nao_encontrado', 'Servico nao encontrado'));
    const r = atual.mudarEstado(e.estado);
    if (!r.ok) return r;
    await this.deps.repo.atualizar(r.valor);
    await ctx.efeitos.historico(TABELA, e.id, { estado: atual.estado }, { estado: e.estado });
    await ctx.efeitos.auditar('servico.mudar_estado', TABELA, e.id, { estado: atual.estado }, { estado: e.estado });
    return okVazio();
  }
}
