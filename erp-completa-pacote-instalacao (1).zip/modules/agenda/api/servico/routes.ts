/** Rotas REST do Servico fora das tools: ficha, criar, editar e arquivar. Listar e @tool agenda.servicos. */
import { esquemaErro, requer, type FastifyInstance } from '@erp/api/sdk';
import { naTransacao, naoEncontrado } from '../borda.ts';
import { exigirOk } from '../compartilhado/result.ts';
import { propsServico, uuid } from '../esquemas.ts';
import type { EstadoCadastro } from '../recurso/model/recurso.ts';
import type { DadosServico } from './model/servico.ts';
import { obterServico } from './query/servicos.ts';

const tags = ['agenda'];
const paramId = { type: 'object', required: ['id'], properties: { id: uuid } } as const;
const erros = { 400: esquemaErro, 403: esquemaErro, 404: esquemaErro, 409: esquemaErro };

export function rotasServico(app: FastifyInstance): void {
  app.get<{ Params: { id: string } }>('/servicos/:id', {
    preHandler: requer('agenda.ver'),
    schema: { tags, summary: 'Ficha do servico com recursos', params: paramId, response: { 404: esquemaErro } },
  }, (req) => naTransacao(req, async (_, __, c) => (await obterServico(c, req.params.id)) ?? Promise.reject(naoEncontrado('Servico nao encontrado'))));

  app.post<{ Body: DadosServico }>('/servicos', {
    preHandler: requer('agenda.criar'),
    schema: { tags, summary: 'Cria servico com duracao e preco (CriarServico)', body: { type: 'object', additionalProperties: false, required: ['nome', 'duracao_min'], properties: propsServico }, response: erros },
  }, async (req, reply) => reply.code(201).send(await naTransacao(req, async (casos, ctx, c) => {
    const { id } = exigirOk(await casos.criarServico.execute(ctx, req.body));
    return obterServico(c, id);
  })));

  app.patch<{ Params: { id: string }; Body: Partial<DadosServico> }>('/servicos/:id', {
    preHandler: requer('agenda.editar'),
    schema: { tags, summary: 'Edita servico (EditarServico)', params: paramId, body: { type: 'object', additionalProperties: false, properties: propsServico }, response: erros },
  }, (req) => naTransacao(req, async (casos, ctx, c) => {
    exigirOk(await casos.editarServico.execute(ctx, { ...req.body, id: req.params.id }));
    return obterServico(c, req.params.id);
  }));

  app.post<{ Params: { id: string }; Body: { estado: EstadoCadastro } }>('/servicos/:id/estado', {
    preHandler: requer('agenda.editar'),
    schema: { tags, summary: 'Arquiva ou reativa o servico (MudarEstadoServico)', params: paramId,
      body: { type: 'object', additionalProperties: false, required: ['estado'], properties: { estado: { type: 'string', enum: ['ativo', 'arquivado'] } } }, response: erros },
  }, (req) => naTransacao(req, async (casos, ctx, c) => {
    exigirOk(await casos.mudarEstadoServico.execute(ctx, { id: req.params.id, estado: req.body.estado }));
    return obterServico(c, req.params.id);
  }));
}
