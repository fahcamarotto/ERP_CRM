/**
 * Objeto de valor Recorrencia (M6.3): diaria, semanal ou mensal, com intervalo e numero de ocorrencias.
 * Gera as ocorrencias mantendo a hora local do recurso (o fuso decide o instante UTC de cada uma).
 */
import { localParaInstante, partesLocais, somarDias, somarMeses } from '../../compartilhado/fuso.ts';
import { erroDe, fail, ok, type ErroDominio, type Result } from '../../compartilhado/result.ts';
import { Periodo } from './periodo.ts';

export const FREQUENCIAS = ['diaria', 'semanal', 'mensal'] as const;
export type Frequencia = (typeof FREQUENCIAS)[number];

export interface RecorrenciaDados {
  frequencia: Frequencia;
  intervalo: number;
  ocorrencias: number;
}

export class Recorrencia {
  private constructor(readonly d: RecorrenciaDados) {}

  static tryCreate(bruto: Partial<RecorrenciaDados> | null | undefined): Result<Recorrencia | null> {
    if (!bruto) return ok(null);
    const e: ErroDominio[] = [];
    const frequencia = bruto.frequencia as Frequencia;
    const intervalo = Number(bruto.intervalo ?? 1);
    const ocorrencias = Number(bruto.ocorrencias ?? 0);
    if (!FREQUENCIAS.includes(frequencia)) e.push(erroDe('recorrencia_invalida', 'Frequencia deve ser diaria, semanal ou mensal', 'recorrencia'));
    if (!Number.isInteger(intervalo) || intervalo < 1 || intervalo > 12) e.push(erroDe('recorrencia_invalida', 'Intervalo de 1 a 12', 'recorrencia'));
    if (!Number.isInteger(ocorrencias) || ocorrencias < 2 || ocorrencias > 52) e.push(erroDe('recorrencia_invalida', 'Ocorrencias de 2 a 52', 'recorrencia'));
    return e.length ? fail(...e) : ok(new Recorrencia({ frequencia, intervalo, ocorrencias }));
  }

  /** Todas as ocorrencias, a primeira igual ao periodo de origem. */
  ocorrencias(origem: Periodo, fuso: string): Periodo[] {
    const ini = partesLocais(fuso, new Date(origem.inicio));
    const dur = origem.duracaoMin;
    const lista: Periodo[] = [];
    for (let k = 0; k < this.d.ocorrencias; k++) {
      const passo = k * this.d.intervalo;
      const data = this.d.frequencia === 'diaria' ? somarDias(ini.data, passo)
        : this.d.frequencia === 'semanal' ? somarDias(ini.data, passo * 7) : somarMeses(ini.data, passo);
      const inicio = localParaInstante(fuso, data, ini.minutos);
      lista.push(Periodo.create(inicio.toISOString(), new Date(inicio.getTime() + dur * 60000).toISOString()));
    }
    return lista;
  }

  paraDados(): RecorrenciaDados {
    return { ...this.d };
  }
}
