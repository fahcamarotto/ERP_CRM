/**
 * Regra de disponibilidade (M6.4): horarios livres de cada recurso entre duas datas, dentro do horario de
 * trabalho no fuso do recurso, sem sobrepor agendamento ativo nem bloqueio, respeitando o intervalo do servico.
 */
import { diaDaSemana, localParaInstante, partesLocais, somarDias } from '../../compartilhado/fuso.ts';
import type { HorarioTrabalho } from '../../recurso/model/horario.ts';

export interface RecursoAgenda {
  id: string;
  nome: string;
  fuso: string;
  horario: HorarioTrabalho;
}

export interface Ocupacao {
  tipo: 'compromisso' | 'bloqueio';
  id: string;
  recurso_id: string;
  inicio: string;
  fim: string;
}

export interface Horario {
  recurso_id: string;
  recurso_nome: string;
  inicio: string;
  fim: string;
}

export interface PedidoDisponibilidade {
  recursos: RecursoAgenda[];
  ocupados: Ocupacao[];
  de: string;
  ate: string;
  duracaoMin: number;
  intervaloMin: number;
  passoMin: number;
  agora: number;
  limite: number;
}

export const MAX_DIAS = 31;

/** Periodo cabe no horario de trabalho do recurso (mesmo dia local, inteiro numa faixa)? */
export function dentroDoHorario(r: RecursoAgenda, inicio: string, fim: string): boolean {
  const a = partesLocais(r.fuso, new Date(inicio));
  const b = partesLocais(r.fuso, new Date(Date.parse(fim) - 1));
  if (a.data !== b.data) return false;
  return r.horario.contem(a.dia, a.minutos, b.minutos + 1);
}

export function calcularHorarios(p: PedidoDisponibilidade): Horario[] {
  const saida: Horario[] = [];
  const porRecurso = new Map<string, [number, number][]>();
  for (const o of p.ocupados) {
    const l = porRecurso.get(o.recurso_id) ?? [];
    l.push([Date.parse(o.inicio), Date.parse(o.fim)]);
    porRecurso.set(o.recurso_id, l);
  }
  const passo = Math.max(5, p.passoMin);
  const dur = p.duracaoMin * 60000;
  const ocupaAte = (p.duracaoMin + p.intervaloMin) * 60000;
  dias: for (let data = p.de; data <= p.ate; data = somarDias(data, 1)) {
    for (const r of p.recursos) {
      const ocupados = porRecurso.get(r.id) ?? [];
      for (const [ini, fim] of r.horario.doDia(diaDaSemana(data))) {
        for (let m = ini; m + p.duracaoMin <= fim; m += passo) {
          const a = localParaInstante(r.fuso, data, m).getTime();
          if (a < p.agora) continue;
          const livre = ocupados.every(([x, y]) => !(a < y && x < a + ocupaAte));
          if (!livre) continue;
          saida.push({ recurso_id: r.id, recurso_nome: r.nome, inicio: new Date(a).toISOString(), fim: new Date(a + dur).toISOString() });
          if (saida.length >= p.limite) break dias;
        }
      }
    }
  }
  return saida.sort((x, y) => x.inicio.localeCompare(y.inicio) || x.recurso_nome.localeCompare(y.recurso_nome));
}
