/**
 * Agregado Agendamento (M6.3), tabela agenda_compromissos: recurso, servico, parceiro, oportunidade opcional,
 * periodo, estado (marcado, confirmado, realizado, faltou, cancelado) e recorrencia (serie).
 * Imutavel: toda alteracao devolve um clone novo.
 */
import { randomUUID } from 'node:crypto';
import { combinar, erroDe, fail, ok, type ErroDominio, type Result } from '../../compartilhado/result.ts';
import { Periodo } from './periodo.ts';
import { Recorrencia, type RecorrenciaDados } from './recorrencia.ts';

export const ESTADOS_COMPROMISSO = ['marcado', 'confirmado', 'realizado', 'faltou', 'cancelado'] as const;
export type EstadoCompromisso = (typeof ESTADOS_COMPROMISSO)[number];

/** Maquina de estados. Realizado, faltou e cancelado sao finais. */
export const TRANSICOES: Record<EstadoCompromisso, EstadoCompromisso[]> = {
  marcado: ['confirmado', 'realizado', 'faltou', 'cancelado'],
  confirmado: ['realizado', 'faltou', 'cancelado'],
  realizado: [],
  faltou: [],
  cancelado: [],
};

/** Estados que ocupam o horario do recurso (bloqueiam conflito). */
export const ESTADOS_OCUPAM: EstadoCompromisso[] = ['marcado', 'confirmado', 'realizado'];

export type OrigemCompromisso = 'manual' | 'api' | 'google';

export interface DadosCompromisso {
  recurso_id: string;
  servico_id?: string | null;
  parceiro_id?: string | null;
  oportunidade_id?: string | null;
  titulo?: string | null;
  inicio: string;
  fim: string;
  observacoes?: string | null;
  recorrencia?: Partial<RecorrenciaDados> | null;
  serie_id?: string | null;
  origem?: OrigemCompromisso;
  google_evento_id?: string | null;
  extras?: Record<string, unknown>;
}

export interface CompromissoDados {
  id: string;
  recurso_id: string;
  servico_id: string | null;
  parceiro_id: string | null;
  oportunidade_id: string | null;
  titulo: string | null;
  inicio: string;
  fim: string;
  estado: EstadoCompromisso;
  observacoes: string | null;
  recorrencia: RecorrenciaDados | null;
  serie_id: string | null;
  origem: OrigemCompromisso;
  google_evento_id: string | null;
  extras: Record<string, unknown>;
}

const t = (v?: string | null) => (v ?? '').trim() || null;

function validar(d: CompromissoDados): ErroDominio[] {
  const e: ErroDominio[] = [];
  if (!d.recurso_id) e.push(erroDe('recurso_obrigatorio', 'Recurso obrigatorio', 'recurso_id'));
  if (d.titulo && d.titulo.length > 200) e.push(erroDe('titulo_invalido', 'Titulo de ate 200 caracteres', 'titulo'));
  if (d.observacoes && d.observacoes.length > 4000) e.push(erroDe('observacoes_invalidas', 'Observacoes de ate 4000 caracteres', 'observacoes'));
  if (!d.titulo && !d.servico_id && !d.parceiro_id) e.push(erroDe('titulo_obrigatorio', 'Informe titulo, servico ou cliente', 'titulo'));
  return e;
}

export class Compromisso {
  private constructor(private readonly d: CompromissoDados) {}

  static tryCreate(e: DadosCompromisso, id: string = randomUUID()): Result<Compromisso> {
    const r = combinar(Periodo.tryCreate(e.inicio, e.fim), Recorrencia.tryCreate(e.recorrencia));
    const parcial: CompromissoDados = {
      id, recurso_id: t(e.recurso_id) ?? '', servico_id: t(e.servico_id), parceiro_id: t(e.parceiro_id), oportunidade_id: t(e.oportunidade_id),
      titulo: t(e.titulo), inicio: r.ok ? r.valor[0].inicio : e.inicio, fim: r.ok ? r.valor[0].fim : e.fim, estado: 'marcado',
      observacoes: t(e.observacoes), recorrencia: r.ok && r.valor[1] ? r.valor[1].paraDados() : null, serie_id: t(e.serie_id),
      origem: e.origem ?? 'manual', google_evento_id: t(e.google_evento_id), extras: e.extras ?? {},
    };
    const erros = [...(r.ok ? [] : r.erros), ...validar(parcial)];
    return erros.length ? fail(...erros) : ok(new Compromisso(parcial));
  }

  static create(e: DadosCompromisso, id?: string): Compromisso {
    const r = Compromisso.tryCreate(e, id);
    if (!r.ok) throw new Error(r.erros.map((x) => x.mensagem).join('; '));
    return r.valor;
  }

  static reidratar(d: CompromissoDados): Compromisso {
    return new Compromisso({
      ...d, inicio: new Date(d.inicio).toISOString(), fim: new Date(d.fim).toISOString(),
      recorrencia: d.recorrencia ? { ...d.recorrencia } : null, extras: { ...(d.extras ?? {}) },
    });
  }

  get id(): string { return this.d.id; }
  get estado(): EstadoCompromisso { return this.d.estado; }
  get recursoId(): string { return this.d.recurso_id; }
  get periodo(): Periodo { return Periodo.create(this.d.inicio, this.d.fim); }
  get final(): boolean { return TRANSICOES[this.d.estado].length === 0; }

  /** Ocorrencia da serie (recorrencia): mesmo agendamento em outro periodo. */
  ocorrencia(p: Periodo, serieId: string, id: string = randomUUID()): Compromisso {
    return new Compromisso({ ...this.d, id, inicio: p.inicio, fim: p.fim, serie_id: serieId, extras: { ...this.d.extras } });
  }

  editar(e: Partial<Pick<DadosCompromisso, 'titulo' | 'observacoes' | 'servico_id' | 'parceiro_id' | 'oportunidade_id' | 'extras'>>): Result<Compromisso> {
    if (this.final) return fail(erroDe('transicao_invalida', `Agendamento ${this.d.estado} nao pode ser editado`));
    const tem = (k: keyof typeof e) => e[k] !== undefined;
    const n: CompromissoDados = {
      ...this.d,
      titulo: tem('titulo') ? t(e.titulo) : this.d.titulo,
      observacoes: tem('observacoes') ? t(e.observacoes) : this.d.observacoes,
      servico_id: tem('servico_id') ? t(e.servico_id) : this.d.servico_id,
      parceiro_id: tem('parceiro_id') ? t(e.parceiro_id) : this.d.parceiro_id,
      oportunidade_id: tem('oportunidade_id') ? t(e.oportunidade_id) : this.d.oportunidade_id,
      extras: tem('extras') ? { ...e.extras } : { ...this.d.extras },
    };
    const erros = validar(n);
    return erros.length ? fail(...erros) : ok(new Compromisso(n));
  }

  /** Novo periodo e, opcionalmente, outro recurso. Confirmado volta a marcado (precisa confirmar de novo). */
  reagendar(p: Periodo, recursoId?: string): Result<Compromisso> {
    if (this.final) return fail(erroDe('transicao_invalida', `Agendamento ${this.d.estado} nao pode ser reagendado`, 'estado'));
    return ok(new Compromisso({ ...this.d, inicio: p.inicio, fim: p.fim, recurso_id: recursoId ?? this.d.recurso_id, estado: 'marcado' }));
  }

  /** Mudanca vinda do Google Calendar (evento mais recente vence): so periodo, sem mexer no estado. */
  moverPorSincronizacao(p: Periodo): Compromisso {
    return new Compromisso({ ...this.d, inicio: p.inicio, fim: p.fim });
  }

  mudarEstado(novo: EstadoCompromisso): Result<Compromisso> {
    if (!ESTADOS_COMPROMISSO.includes(novo)) return fail(erroDe('estado_invalido', 'Estado invalido', 'estado'));
    if (!TRANSICOES[this.d.estado].includes(novo)) {
      return fail(erroDe('transicao_invalida', `Transicao de ${this.d.estado} para ${novo} nao permitida`, 'estado', { permitidas: TRANSICOES[this.d.estado] }));
    }
    return ok(new Compromisso({ ...this.d, estado: novo }));
  }

  ligarGoogle(eventoId: string): Compromisso {
    return new Compromisso({ ...this.d, google_evento_id: eventoId });
  }

  paraDados(): CompromissoDados {
    return { ...this.d, recorrencia: this.d.recorrencia ? { ...this.d.recorrencia } : null, extras: { ...this.d.extras } };
  }
}
