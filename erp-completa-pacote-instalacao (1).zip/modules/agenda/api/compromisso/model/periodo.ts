/** Objeto de valor Periodo: inicio e fim ISO 8601 normalizados em UTC, fim depois do inicio, no maximo 24 h. */
import { erroDe, fail, ok, type Result } from '../../compartilhado/result.ts';

const MAX_MS = 24 * 3600000;

export class Periodo {
  private constructor(readonly inicio: string, readonly fim: string) {}

  static tryCreate(inicio: string, fim: string): Result<Periodo> {
    const a = Date.parse(inicio);
    const b = Date.parse(fim);
    if (Number.isNaN(a)) return fail(erroDe('data_invalida', 'Inicio em data e hora ISO 8601 (2026-10-05T14:00:00-03:00)', 'inicio'));
    if (Number.isNaN(b)) return fail(erroDe('data_invalida', 'Fim em data e hora ISO 8601', 'fim'));
    if (b <= a) return fail(erroDe('periodo_invalido', 'Fim deve ser depois do inicio', 'fim'));
    if (b - a > MAX_MS) return fail(erroDe('periodo_invalido', 'Agendamento de no maximo 24 horas', 'fim'));
    return ok(new Periodo(new Date(a).toISOString(), new Date(b).toISOString()));
  }

  static create(inicio: string, fim: string): Periodo {
    const r = Periodo.tryCreate(inicio, fim);
    if (!r.ok) throw new Error(r.erros.map((e) => e.mensagem).join('; '));
    return r.valor;
  }

  get duracaoMin(): number {
    return Math.round((Date.parse(this.fim) - Date.parse(this.inicio)) / 60000);
  }

  sobrepoe(outro: { inicio: string | Date; fim: string | Date }): boolean {
    return Date.parse(this.inicio) < new Date(outro.fim).getTime() && new Date(outro.inicio).getTime() < Date.parse(this.fim);
  }
}
