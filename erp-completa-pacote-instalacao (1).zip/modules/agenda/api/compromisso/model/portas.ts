/** Portas do agregado Agendamento (Compromisso), segregadas por operacao. */
import type { RecursoAgenda, Ocupacao } from './disponibilidade.ts';
import type { Compromisso, CompromissoDados } from './compromisso.ts';

export interface ObterCompromisso {
  obterPorId(id: string): Promise<Compromisso | null>;
}

export interface GravarCompromisso {
  inserir(x: Compromisso): Promise<void>;
  atualizar(x: Compromisso): Promise<void>;
}

/** Recurso e servico vistos pelo agendamento (leitura, outro agregado do mesmo modulo). */
export interface ServicoAgenda {
  id: string;
  nome: string;
  duracao_min: number;
  intervalo_min: number;
  recurso_ids: string[];
  estado: 'ativo' | 'arquivado';
}

export interface ConsultarReferenciasAgenda {
  recurso(id: string): Promise<(RecursoAgenda & { estado: 'ativo' | 'arquivado' }) | null>;
  recursosAtivos(ids?: string[]): Promise<RecursoAgenda[]>;
  servico(id: string): Promise<ServicoAgenda | null>;
  /** Interface publicada do Cadastros (CONTRATOS 7.1.1): parceiro vivo e ativo. */
  parceiroAtivo(id: string): Promise<boolean>;
}

/** Agendamentos ativos e bloqueios que tocam o periodo (para conflito e disponibilidade). */
export interface ConsultarOcupacao {
  ocupacao(recursoIds: string[], inicio: string, fim: string, ignorarId?: string | null): Promise<Ocupacao[]>;
}

/** Lembretes por job (M6.6): programa confirmacao e lembretes e cancela os pendentes. */
export interface ProgramarLembretes {
  programar(c: CompromissoDados): Promise<number>;
  cancelar(compromissoId: string): Promise<void>;
}

/** Envio ao Google Calendar por job (M6.5): so enfileira se o conector e o calendario do recurso existirem. */
export interface SincronizarGoogle {
  solicitar(compromissoId: string): Promise<boolean>;
}
