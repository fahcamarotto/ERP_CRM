/**
 * Rotas REST do Agendamento fora das tools: ficha, edicao, lembretes, clientes para o seletor e estado das
 * integracoes. Agendar, listar, mudar estado, reagendar e disponibilidade sao @tool em ../tools.ts.
 */
import { esquemaErro, requer, type FastifyInstance } from '@erp/api/sdk';
import { naTransacao, naoEncontrado } from '../borda.ts';
import { exigirOk } from '../compartilhado/result.ts';
import { propsEditarCompromisso, uuid } from '../esquemas.ts';
import { estadoIntegracoes } from '../google/google-pg.ts';
import { listarLembretes } from '../lembrete/lembrete-repo-pg.ts';
import type { DadosCompromisso } from './model/compromisso.ts';
import { obterCompromisso } from './query/compromissos.ts';

const tags = ['agenda'];
const paramId = { type: 'object', required: ['id'], properties: { id: uuid } } as const;

export function rotasCompromisso(app: FastifyInstance): void {
  app.get<{ Params: { id: string } }>('/compromissos/:id', {
    preHandler: requer('agenda.ver'),
    schema: { tags, summary: 'Ficha do agendamento com lembretes', params: paramId, response: { 404: esquemaErro } },
  }, (req) => naTransacao(req, async (_, __, c) => (await obterCompromisso(c, req.params.id)) ?? Promise.reject(naoEncontrado('Agendamento nao encontrado'))));

  app.patch<{ Params: { id: string }; Body: Partial<DadosCompromisso> }>('/compromissos/:id', {
    preHandler: requer('agenda.editar'),
    schema: {
      tags, summary: 'Edita titulo, observacoes, servico, cliente e oportunidade (EditarCompromisso)', params: paramId,
      body: { type: 'object', additionalProperties: false, properties: propsEditarCompromisso },
      response: { 400: esquemaErro, 404: esquemaErro, 409: esquemaErro },
    },
  }, (req) => naTransacao(req, async (casos, ctx, c) => {
    exigirOk(await casos.editarCompromisso.execute(ctx, { ...req.body, id: req.params.id }));
    return obterCompromisso(c, req.params.id);
  }));

  app.get<{ Params: { id: string } }>('/compromissos/:id/lembretes', {
    preHandler: requer('agenda.ver'),
    schema: { tags, summary: 'Confirmacao e lembretes do agendamento (jobs)', params: paramId },
  }, (req) => naTransacao(req, (_, __, c) => listarLembretes(c, req.params.id)));

  // Interface publicada do Cadastros (CONTRATOS 7.1.1): seletor de clientes, so leitura.
  app.get<{ Querystring: { busca?: string } }>('/clientes', {
    preHandler: requer('agenda.ver'),
    schema: { tags, summary: 'Clientes ativos para o seletor do agendamento', querystring: { type: 'object', additionalProperties: false, properties: { busca: { type: 'string', maxLength: 120 } } } },
  }, (req) => naTransacao(req, async (_, __, c) => (await c.query(
    `SELECT id, nome, telefone FROM cadastros_parceiros WHERE e_cliente AND estado = 'ativo' AND deleted_at IS NULL
       AND ($1::text IS NULL OR nome ILIKE '%' || $1 || '%') ORDER BY nome LIMIT 200`, [req.query.busca?.trim() || null])).rows));

  app.get('/integracoes', {
    preHandler: requer('agenda.ver'),
    schema: { tags, summary: 'Estado dos conectores WhatsApp e Google Calendar usados pela Agenda' },
  }, (req) => naTransacao(req, (_, __, c) => estadoIntegracoes(c)));
}
