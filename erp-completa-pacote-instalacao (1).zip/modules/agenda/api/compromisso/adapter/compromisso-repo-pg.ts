/**
 * Adaptador Postgres do Agendamento: repositorio, referencias (recurso, servico e cliente pela tabela publicada
 * do Cadastros), ocupacao para conflito e disponibilidade, e portas da sincronizacao com o Google Calendar.
 * A trigger agenda_compromissos_sem_conflito e a segunda barreira contra sobreposicao (409 conflito).
 */
import type pg from 'pg';
import { conectores } from '@erp/api/sdk/puro';
import { HorarioTrabalho } from '../../recurso/model/horario.ts';
import { CONECTOR_GOOGLE, TIPO_JOB_ENVIO, type PortaEnvioGoogle } from '../../google/sincronizar.ts';
import { Compromisso, type CompromissoDados } from '../model/compromisso.ts';
import type { Ocupacao, RecursoAgenda } from '../model/disponibilidade.ts';
import type { ConsultarOcupacao, ConsultarReferenciasAgenda, GravarCompromisso, ObterCompromisso, ServicoAgenda, SincronizarGoogle } from '../model/portas.ts';

const COLUNAS = `id, recurso_id, servico_id, parceiro_id, oportunidade_id, titulo, inicio, fim, estado, observacoes, recorrencia, serie_id,
  origem, google_evento_id, extras`;

type LinhaRecurso = { id: string; nome: string; fuso: string; horario: unknown; estado: 'ativo' | 'arquivado' };
const paraRecurso = (r: LinhaRecurso) => ({ id: r.id, nome: r.nome, fuso: r.fuso, horario: HorarioTrabalho.create(r.horario), estado: r.estado });

export class CompromissoRepoPg implements ObterCompromisso, GravarCompromisso, ConsultarReferenciasAgenda, ConsultarOcupacao, SincronizarGoogle, PortaEnvioGoogle {
  constructor(private readonly c: pg.PoolClient) {}

  async obterPorId(id: string): Promise<Compromisso | null> {
    const r = await this.c.query(`SELECT ${COLUNAS} FROM agenda_compromissos WHERE id = $1 AND deleted_at IS NULL`, [id]);
    return r.rows[0] ? Compromisso.reidratar(r.rows[0] as CompromissoDados) : null;
  }

  async inserir(x: Compromisso): Promise<void> {
    const d = x.paraDados();
    await this.c.query(
      `INSERT INTO agenda_compromissos (id, recurso_id, servico_id, parceiro_id, oportunidade_id, titulo, inicio, fim, estado, observacoes,
         recorrencia, serie_id, origem, google_evento_id, extras, creator_id)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, nucleo_usuario_atual())`,
      [d.id, d.recurso_id, d.servico_id, d.parceiro_id, d.oportunidade_id, d.titulo, d.inicio, d.fim, d.estado, d.observacoes,
        d.recorrencia ? JSON.stringify(d.recorrencia) : null, d.serie_id, d.origem, d.google_evento_id, JSON.stringify(d.extras)],
    );
  }

  async atualizar(x: Compromisso): Promise<void> {
    const d = x.paraDados();
    await this.c.query(
      `UPDATE agenda_compromissos SET recurso_id = $2, servico_id = $3, parceiro_id = $4, oportunidade_id = $5, titulo = $6, inicio = $7, fim = $8,
         estado = $9, observacoes = $10, google_evento_id = $11, extras = $12 WHERE id = $1 AND deleted_at IS NULL`,
      [d.id, d.recurso_id, d.servico_id, d.parceiro_id, d.oportunidade_id, d.titulo, d.inicio, d.fim, d.estado, d.observacoes, d.google_evento_id, JSON.stringify(d.extras)],
    );
  }

  async recurso(id: string) {
    const r = await this.c.query('SELECT id, nome, fuso, horario, estado FROM agenda_recursos WHERE id = $1 AND deleted_at IS NULL', [id]);
    return r.rows[0] ? paraRecurso(r.rows[0] as LinhaRecurso) : null;
  }

  async recursosAtivos(ids?: string[]): Promise<RecursoAgenda[]> {
    const r = await this.c.query(
      "SELECT id, nome, fuso, horario, estado FROM agenda_recursos WHERE estado = 'ativo' AND deleted_at IS NULL AND ($1::uuid[] IS NULL OR id = ANY ($1::uuid[])) ORDER BY nome LIMIT 100",
      [ids ?? null],
    );
    return (r.rows as LinhaRecurso[]).map(paraRecurso);
  }

  async servico(id: string): Promise<ServicoAgenda | null> {
    const r = await this.c.query(
      `SELECT s.id, s.nome, s.duracao_min, s.intervalo_min, s.estado,
         coalesce((SELECT array_agg(sr.recurso_id) FROM agenda_servico_recursos sr WHERE sr.servico_id = s.id AND sr.deleted_at IS NULL), '{}') AS recurso_ids
       FROM agenda_servicos s WHERE s.id = $1 AND s.deleted_at IS NULL`,
      [id],
    );
    return (r.rows[0] as ServicoAgenda | undefined) ?? null;
  }

  /** Interface publicada do Cadastros (CONTRATOS 7.1.1): leitura de cadastros_parceiros, nunca escrita. */
  async parceiroAtivo(id: string): Promise<boolean> {
    const r = await this.c.query("SELECT 1 FROM cadastros_parceiros WHERE id = $1 AND deleted_at IS NULL AND estado = 'ativo'", [id]);
    return (r.rowCount ?? 0) > 0;
  }

  async ocupacao(recursoIds: string[], inicio: string, fim: string, ignorarId: string | null = null): Promise<Ocupacao[]> {
    if (!recursoIds.length) return [];
    const r = await this.c.query(
      `SELECT 'compromisso' AS tipo, id, recurso_id, inicio, fim FROM agenda_compromissos
        WHERE recurso_id = ANY ($1::uuid[]) AND deleted_at IS NULL AND estado IN ('marcado', 'confirmado', 'realizado')
          AND inicio < $3 AND fim > $2 AND ($4::uuid IS NULL OR id <> $4)
       UNION ALL
       SELECT 'bloqueio', id, recurso_id, inicio, fim FROM agenda_bloqueios
        WHERE recurso_id = ANY ($1::uuid[]) AND deleted_at IS NULL AND inicio < $3 AND fim > $2
       ORDER BY inicio`,
      [recursoIds, inicio, fim, ignorarId],
    );
    return r.rows.map((o) => ({ ...o, inicio: new Date(o.inicio).toISOString(), fim: new Date(o.fim).toISOString() }));
  }

  // M6.5 saida: enfileira o envio so com conector ativo e calendario ligado ao recurso.
  async solicitar(compromissoId: string): Promise<boolean> {
    const r = await this.c.query(
      `SELECT r.google_calendar_id FROM agenda_compromissos x JOIN agenda_recursos r ON r.id = x.recurso_id WHERE x.id = $1`, [compromissoId]);
    if (!r.rows[0]?.google_calendar_id) return false;
    if ((await conectores.obter(this.c, CONECTOR_GOOGLE))?.estado !== 'ativo') return false;
    await this.c.query('INSERT INTO outbox (tipo, payload) VALUES ($1, $2)', [TIPO_JOB_ENVIO, JSON.stringify({ compromisso_id: compromissoId })]);
    await this.c.query("UPDATE agenda_compromissos SET google_estado = 'pendente_envio' WHERE id = $1", [compromissoId]);
    return true;
  }

  async dadosEnvio(compromissoId: string) {
    const r = await this.c.query(
      `SELECT ${COLUNAS.split(',').map((x) => `x.${x.trim()}`).join(', ')}, r.google_calendar_id, coalesce(x.titulo, s.nome, 'Agendamento') AS titulo_envio
       FROM agenda_compromissos x JOIN agenda_recursos r ON r.id = x.recurso_id LEFT JOIN agenda_servicos s ON s.id = x.servico_id
       WHERE x.id = $1 AND x.deleted_at IS NULL`,
      [compromissoId],
    );
    const l = r.rows[0];
    return l ? { compromisso: Compromisso.reidratar(l as CompromissoDados), calendar_id: (l.google_calendar_id as string | null) ?? null, titulo: l.titulo_envio as string } : null;
  }

  async marcar(compromissoId: string, estado: 'sincronizado' | 'pendente_envio' | 'sem_conector', googleEventoId?: string | null): Promise<void> {
    await this.c.query('UPDATE agenda_compromissos SET google_estado = $2, google_evento_id = coalesce($3, google_evento_id) WHERE id = $1', [compromissoId, estado, googleEventoId ?? null]);
  }

  async compromissoPorGoogle(eventoId: string) {
    const r = await this.c.query(`SELECT ${COLUNAS}, updated_at FROM agenda_compromissos WHERE google_evento_id = $1 AND deleted_at IS NULL`, [eventoId]);
    const l = r.rows[0];
    return l ? { compromisso: Compromisso.reidratar(l as CompromissoDados), atualizado_em: new Date(l.updated_at).toISOString() } : null;
  }

  atualizarCompromisso(x: Compromisso): Promise<void> {
    return this.atualizar(x);
  }
}

/** Savepoint por item: erro num evento externo volta so aquele evento. */
export function porItemPg(c: pg.PoolClient) {
  return async <T>(fn: () => Promise<T>): Promise<T> => {
    await c.query('SAVEPOINT agenda_item');
    try {
      const r = await fn();
      await c.query('RELEASE SAVEPOINT agenda_item');
      return r;
    } catch (e) {
      await c.query('ROLLBACK TO SAVEPOINT agenda_item');
      throw e;
    }
  };
}
