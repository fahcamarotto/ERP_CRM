/**
 * Agendar (M6.3 e M6.4): valida recurso, servico e cliente, gera a serie da recorrencia, bloqueia conflito
 * e horario fora do expediente, grava, programa lembretes, pede sincronizacao com o Google e publica agenda.marcado.
 * ConsultarDisponibilidade: horarios livres por recurso e servico.
 */
import { randomUUID } from 'node:crypto';
import type { ContextoCaso } from '../../compartilhado/efeitos.ts';
import { dataValida, partesLocais, somarDias } from '../../compartilhado/fuso.ts';
import { erroDe, fail, ok, type ErroDominio, type Result } from '../../compartilhado/result.ts';
import { Compromisso, type CompromissoDados, type DadosCompromisso } from '../model/compromisso.ts';
import { calcularHorarios, dentroDoHorario, MAX_DIAS, type Horario, type Ocupacao, type RecursoAgenda } from '../model/disponibilidade.ts';
import type { ConsultarOcupacao, ConsultarReferenciasAgenda, GravarCompromisso, ObterCompromisso, ProgramarLembretes, ServicoAgenda, SincronizarGoogle } from '../model/portas.ts';
import { Periodo } from '../model/periodo.ts';
import { Recorrencia } from '../model/recorrencia.ts';

export const TABELA = 'agenda_compromissos';

export interface DepsAgenda {
  repo: ObterCompromisso & GravarCompromisso;
  refs: ConsultarReferenciasAgenda;
  ocupacao: ConsultarOcupacao;
  lembretes: ProgramarLembretes;
  google: SincronizarGoogle;
}

export type EntradaAgendar = Omit<DadosCompromisso, 'fim' | 'serie_id' | 'google_evento_id'> & { fim?: string | null; encaixe?: boolean };

/** Dados publicados no evento (CONTRATOS 7.1.x da Agenda). */
export function dadosEvento(d: CompromissoDados): Record<string, unknown> {
  return {
    id: d.id, recurso_id: d.recurso_id, servico_id: d.servico_id, parceiro_id: d.parceiro_id, oportunidade_id: d.oportunidade_id,
    inicio: d.inicio, fim: d.fim, estado: d.estado, serie_id: d.serie_id,
  };
}

/** Recurso ativo, servico ativo que o recurso atende e cliente ativo. */
export async function conferirReferencias(refs: ConsultarReferenciasAgenda, e: { recurso_id: string; servico_id?: string | null; parceiro_id?: string | null }) {
  const erros: ErroDominio[] = [];
  const recurso = await refs.recurso(e.recurso_id);
  if (!recurso || recurso.estado !== 'ativo') erros.push(erroDe('recurso_invalido', 'Recurso nao encontrado ou arquivado', 'recurso_id'));
  let servico: ServicoAgenda | null = null;
  if (e.servico_id) {
    servico = await refs.servico(e.servico_id);
    if (!servico || servico.estado !== 'ativo') erros.push(erroDe('servico_invalido', 'Servico nao encontrado ou arquivado', 'servico_id'));
    else if (recurso && servico.recurso_ids.length && !servico.recurso_ids.includes(recurso.id)) {
      erros.push(erroDe('recurso_nao_atende', 'Este recurso nao atende o servico escolhido', 'recurso_id', { recursos: servico.recurso_ids }));
    }
  }
  if (e.parceiro_id && !(await refs.parceiroAtivo(e.parceiro_id))) erros.push(erroDe('cliente_invalido', 'Cliente nao encontrado ou arquivado', 'parceiro_id'));
  return { erros, recurso, servico };
}

/** Conflito com agendamento ativo ou bloqueio e expediente do recurso, para cada periodo. */
export async function conferirHorarios(ocupacao: ConsultarOcupacao, recurso: RecursoAgenda, periodos: Periodo[], encaixe: boolean, ignorarId: string | null = null) {
  const erros: ErroDominio[] = [];
  if (!encaixe) {
    const fora = periodos.filter((p) => !dentroDoHorario(recurso, p.inicio, p.fim));
    if (fora.length) erros.push(erroDe('fora_do_horario', 'Fora do horario de trabalho do recurso (use encaixe para forcar)', 'inicio', { periodos: fora.map((p) => p.inicio) }));
  }
  const inicio = periodos.reduce((a, p) => (p.inicio < a ? p.inicio : a), periodos[0]!.inicio);
  const fim = periodos.reduce((a, p) => (p.fim > a ? p.fim : a), periodos[0]!.fim);
  const ocupados = await ocupacao.ocupacao([recurso.id], inicio, fim, ignorarId);
  const conflitos: Ocupacao[] = ocupados.filter((o) => periodos.some((p) => p.sobrepoe(o)));
  if (conflitos.length) {
    erros.push(erroDe('conflito', 'Horario ocupado para este recurso', 'inicio', { conflitos: conflitos.map((c) => ({ tipo: c.tipo, id: c.id, inicio: c.inicio, fim: c.fim })) }));
  }
  return erros;
}

export class Agendar {
  constructor(private readonly deps: DepsAgenda) {}

  async execute(ctx: ContextoCaso, e: EntradaAgendar): Promise<Result<{ id: string; ids: string[] }>> {
    const ref = await conferirReferencias(this.deps.refs, e);
    if (ref.erros.length || !ref.recurso) return fail(...ref.erros);
    const inicioMs = Date.parse(e.inicio);
    const fim = e.fim || (ref.servico && !Number.isNaN(inicioMs) ? new Date(inicioMs + ref.servico.duracao_min * 60000).toISOString() : null);
    if (!fim) return fail(erroDe('fim_obrigatorio', 'Informe o fim ou um servico com duracao', 'fim'));
    const titulo = e.titulo ?? (ref.servico ? ref.servico.nome : null);
    const r = Compromisso.tryCreate({ ...e, titulo, fim, serie_id: null, google_evento_id: null });
    if (!r.ok) return r;
    const base = r.valor;
    const rec = Recorrencia.tryCreate(base.paraDados().recorrencia);
    const serieId = rec.ok && rec.valor ? randomUUID() : null;
    const todos = rec.ok && rec.valor
      ? rec.valor.ocorrencias(base.periodo, ref.recurso.fuso).map((p, i) => (i === 0 ? base.ocorrencia(p, serieId!, base.id) : base.ocorrencia(p, serieId!)))
      : [base];
    const erros = await conferirHorarios(this.deps.ocupacao, ref.recurso, todos.map((x) => x.periodo), !!e.encaixe);
    if (erros.length) return fail(...erros);
    for (const x of todos) {
      await this.deps.repo.inserir(x);
      const d = x.paraDados();
      await this.deps.lembretes.programar(d);
      await this.deps.google.solicitar(d.id);
      await ctx.efeitos.auditar('agendamento.criar', TABELA, d.id, undefined, d);
      await ctx.efeitos.publicar('agenda.marcado', dadosEvento(d));
    }
    return ok({ id: base.id, ids: todos.map((x) => x.id) });
  }
}

export interface EntradaDisponibilidade {
  servico_id?: string | null;
  recurso_id?: string | null;
  de: string;
  ate?: string | null;
  duracao_min?: number | null;
  passo_min?: number | null;
  limite?: number | null;
}

export class ConsultarDisponibilidade {
  constructor(private readonly deps: { refs: ConsultarReferenciasAgenda; ocupacao: ConsultarOcupacao; agora?: () => number }) {}

  async execute(e: EntradaDisponibilidade): Promise<Result<{ duracao_min: number; intervalo_min: number; de: string; ate: string; horarios: Horario[] }>> {
    const ate = e.ate || e.de;
    if (!dataValida(e.de) || !dataValida(ate)) return fail(erroDe('data_invalida', 'Datas de e ate no formato AAAA-MM-DD', 'de'));
    if (ate < e.de) return fail(erroDe('periodo_invalido', 'Data final antes da inicial', 'ate'));
    if (somarDias(e.de, MAX_DIAS - 1) < ate) return fail(erroDe('periodo_invalido', `Consulta de no maximo ${MAX_DIAS} dias`, 'ate'));
    let servico: ServicoAgenda | null = null;
    if (e.servico_id) {
      servico = await this.deps.refs.servico(e.servico_id);
      if (!servico || servico.estado !== 'ativo') return fail(erroDe('servico_invalido', 'Servico nao encontrado ou arquivado', 'servico_id'));
    }
    const duracao = Number(e.duracao_min ?? servico?.duracao_min ?? 0);
    if (!Number.isInteger(duracao) || duracao < 5 || duracao > 720) return fail(erroDe('duracao_invalida', 'Informe um servico ou duracao_min de 5 a 720', 'duracao_min'));
    let recursos: RecursoAgenda[];
    if (e.recurso_id) {
      const r = await this.deps.refs.recurso(e.recurso_id);
      if (!r || r.estado !== 'ativo') return fail(erroDe('recurso_invalido', 'Recurso nao encontrado ou arquivado', 'recurso_id'));
      if (servico?.recurso_ids.length && !servico.recurso_ids.includes(r.id)) return fail(erroDe('recurso_nao_atende', 'Este recurso nao atende o servico escolhido', 'recurso_id'));
      recursos = [r];
    } else {
      recursos = await this.deps.refs.recursosAtivos(servico?.recurso_ids.length ? servico.recurso_ids : undefined);
    }
    if (!recursos.length) return ok({ duracao_min: duracao, intervalo_min: servico?.intervalo_min ?? 0, de: e.de, ate, horarios: [] });
    // Janela larga o bastante para cobrir qualquer fuso (um dia antes e depois em UTC).
    const ocupados = await this.deps.ocupacao.ocupacao(recursos.map((r) => r.id), `${somarDias(e.de, -1)}T00:00:00Z`, `${somarDias(ate, 2)}T00:00:00Z`, null);
    const horarios = calcularHorarios({
      recursos, ocupados, de: e.de, ate, duracaoMin: duracao, intervaloMin: servico?.intervalo_min ?? 0,
      passoMin: Number(e.passo_min ?? (duracao >= 30 ? 30 : duracao)), agora: (this.deps.agora ?? Date.now)(), limite: Math.min(Math.max(Number(e.limite ?? 200), 1), 500),
    });
    return ok({ duracao_min: duracao, intervalo_min: servico?.intervalo_min ?? 0, de: e.de, ate, horarios });
  }
}

/** Data local de hoje no fuso (padrao das consultas sem data). */
export const hojeNoFuso = (fuso: string, agora = Date.now()) => partesLocais(fuso, new Date(agora)).data;
