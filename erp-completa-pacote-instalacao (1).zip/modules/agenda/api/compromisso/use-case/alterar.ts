/** Casos de uso de alteracao do Agendamento: Reagendar, EditarCompromisso e MudarEstadoCompromisso (agenda.confirmado, agenda.cancelado). */
import type { ContextoCaso } from '../../compartilhado/efeitos.ts';
import { erroDe, fail, okVazio, type Result } from '../../compartilhado/result.ts';
import type { DadosCompromisso, EstadoCompromisso } from '../model/compromisso.ts';
import { Periodo } from '../model/periodo.ts';
import { conferirHorarios, conferirReferencias, dadosEvento, TABELA, type DepsAgenda } from './agendar.ts';

const naoEncontrado = () => fail(erroDe('nao_encontrado', 'Agendamento nao encontrado'));

export class Reagendar {
  constructor(private readonly deps: DepsAgenda) {}
  async execute(ctx: ContextoCaso, e: { id: string; inicio: string; fim?: string | null; recurso_id?: string | null; encaixe?: boolean }): Promise<Result<void>> {
    const atual = await this.deps.repo.obterPorId(e.id);
    if (!atual) return naoEncontrado();
    const a = atual.paraDados();
    const recursoId = e.recurso_id || a.recurso_id;
    const ref = await conferirReferencias(this.deps.refs, { recurso_id: recursoId, servico_id: a.servico_id });
    if (ref.erros.length || !ref.recurso) return fail(...ref.erros);
    const fim = e.fim || new Date(Date.parse(e.inicio) + atual.periodo.duracaoMin * 60000).toISOString();
    const p = Periodo.tryCreate(e.inicio, fim);
    if (!p.ok) return p;
    const r = atual.reagendar(p.valor, recursoId);
    if (!r.ok) return r;
    const erros = await conferirHorarios(this.deps.ocupacao, ref.recurso, [p.valor], !!e.encaixe, e.id);
    if (erros.length) return fail(...erros);
    await this.deps.repo.atualizar(r.valor);
    const d = r.valor.paraDados();
    await this.deps.lembretes.cancelar(e.id);
    await this.deps.lembretes.programar(d);
    await this.deps.google.solicitar(e.id);
    const antes = { inicio: a.inicio, fim: a.fim, recurso_id: a.recurso_id, estado: a.estado };
    const depois = { inicio: d.inicio, fim: d.fim, recurso_id: d.recurso_id, estado: d.estado };
    await ctx.efeitos.historico(TABELA, e.id, antes, depois);
    await ctx.efeitos.auditar('agendamento.reagendar', TABELA, e.id, antes, depois);
    return okVazio();
  }
}

export class EditarCompromisso {
  constructor(private readonly deps: DepsAgenda) {}
  async execute(ctx: ContextoCaso, e: { id: string } & Partial<Pick<DadosCompromisso, 'titulo' | 'observacoes' | 'servico_id' | 'parceiro_id' | 'oportunidade_id' | 'extras'>>): Promise<Result<void>> {
    const { id, ...mud } = e;
    const atual = await this.deps.repo.obterPorId(id);
    if (!atual) return naoEncontrado();
    const r = atual.editar(mud);
    if (!r.ok) return r;
    const a = atual.paraDados();
    const d = r.valor.paraDados();
    const ref = await conferirReferencias(this.deps.refs, {
      recurso_id: d.recurso_id,
      servico_id: d.servico_id !== a.servico_id ? d.servico_id : null,
      parceiro_id: d.parceiro_id !== a.parceiro_id ? d.parceiro_id : null,
    });
    const erros = ref.erros.filter((x) => x.campo !== 'recurso_id' || d.servico_id !== a.servico_id);
    if (erros.length) return fail(...erros);
    await this.deps.repo.atualizar(r.valor);
    await this.deps.google.solicitar(id);
    await ctx.efeitos.historico(TABELA, id, a as unknown as Record<string, unknown>, d as unknown as Record<string, unknown>);
    await ctx.efeitos.auditar('agendamento.editar', TABELA, id, a, d);
    return okVazio();
  }
}

export class MudarEstadoCompromisso {
  constructor(private readonly deps: DepsAgenda) {}
  async execute(ctx: ContextoCaso, e: { id: string; estado: EstadoCompromisso; motivo?: string | null }): Promise<Result<void>> {
    const atual = await this.deps.repo.obterPorId(e.id);
    if (!atual) return naoEncontrado();
    const r = atual.mudarEstado(e.estado);
    if (!r.ok) return r;
    await this.deps.repo.atualizar(r.valor);
    const d = r.valor.paraDados();
    if (e.estado === 'cancelado' || e.estado === 'faltou' || e.estado === 'realizado') await this.deps.lembretes.cancelar(e.id);
    await this.deps.google.solicitar(e.id);
    await ctx.efeitos.historico(TABELA, e.id, { estado: atual.estado }, { estado: d.estado });
    await ctx.efeitos.auditar('agendamento.mudar_estado', TABELA, e.id, { estado: atual.estado }, { estado: d.estado, motivo: e.motivo ?? null });
    const motivo = (e.motivo ?? '').trim();
    if (motivo) await ctx.efeitos.nota(TABELA, e.id, `Motivo (${d.estado}): ${motivo.slice(0, 500)}`);
    if (d.estado === 'confirmado') await ctx.efeitos.publicar('agenda.confirmado', dadosEvento(d));
    if (d.estado === 'cancelado') await ctx.efeitos.publicar('agenda.cancelado', { ...dadosEvento(d), motivo: motivo || null });
    return okVazio();
  }
}
