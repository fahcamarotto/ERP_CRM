/** Consultas de leitura do Agendamento: lista por periodo (calendario) e ficha com lembretes. */
import type pg from 'pg';
import { decodificarCursor, pagina } from '../../compartilhado/cursor.ts';

const RESUMO = `x.id, x.recurso_id, r.nome AS recurso_nome, r.cor AS recurso_cor, x.servico_id, s.nome AS servico_nome, s.preco::float8 AS servico_preco,
  s.moeda AS servico_moeda, x.parceiro_id, p.nome AS cliente_nome, p.telefone AS cliente_telefone, x.oportunidade_id, x.titulo,
  coalesce(x.titulo, s.nome, p.nome) AS rotulo, x.inicio, x.fim, x.estado, x.observacoes, x.recorrencia, x.serie_id, x.origem,
  x.google_evento_id, x.google_estado, x.created_at, x.updated_at`;

const JUNCOES = `FROM agenda_compromissos x
  JOIN agenda_recursos r ON r.id = x.recurso_id
  LEFT JOIN agenda_servicos s ON s.id = x.servico_id
  LEFT JOIN cadastros_parceiros p ON p.id = x.parceiro_id AND p.deleted_at IS NULL`;

export interface FiltroCompromissos {
  de?: string;
  ate?: string;
  recurso_id?: string;
  parceiro_id?: string;
  estado?: string;
  busca?: string;
  limite?: number;
  cursor?: string;
}

/** `de` e `ate` em data (AAAA-MM-DD, UTC) ou data e hora ISO; `ate` em data inclui o dia inteiro. */
export async function listarCompromissos(c: pg.PoolClient, f: FiltroCompromissos) {
  const lim = Math.min(Math.max(f.limite ?? 500, 1), 1000);
  const cur = decodificarCursor(f.cursor);
  const ate = f.ate && /^\d{4}-\d{2}-\d{2}$/.test(f.ate) ? `${f.ate}T23:59:59.999Z` : f.ate ?? null;
  const r = await c.query(
    `SELECT ${RESUMO} ${JUNCOES}
     WHERE x.deleted_at IS NULL AND ($1::timestamptz IS NULL OR x.fim > $1) AND ($2::timestamptz IS NULL OR x.inicio < $2)
       AND ($3::uuid IS NULL OR x.recurso_id = $3) AND ($4::uuid IS NULL OR x.parceiro_id = $4) AND ($5::text IS NULL OR x.estado = $5)
       AND ($6::text IS NULL OR x.titulo ILIKE '%' || $6 || '%' OR p.nome ILIKE '%' || $6 || '%' OR s.nome ILIKE '%' || $6 || '%')
       AND ($7::timestamptz IS NULL OR (x.created_at, x.id) > ($7::timestamptz, $8::uuid))
     ORDER BY x.created_at, x.id LIMIT $9`,
    [f.de ?? null, ate, f.recurso_id ?? null, f.parceiro_id ?? null, f.estado ?? null, f.busca?.trim() || null, cur?.[0] ?? null, cur?.[1] ?? null, lim + 1],
  );
  return pagina(r.rows, lim);
}

export async function obterCompromisso(c: pg.PoolClient, id: string) {
  const r = await c.query(
    `SELECT ${RESUMO}, x.extras, r.fuso,
       coalesce((SELECT json_agg(json_build_object('id', l.id, 'tipo', l.tipo, 'horas_antes', l.horas_antes, 'programado_para', l.programado_para,
                 'estado', l.estado, 'erro', l.erro) ORDER BY l.programado_para) FROM agenda_lembretes l
                 WHERE l.compromisso_id = x.id AND l.deleted_at IS NULL), '[]') AS lembretes
     ${JUNCOES} WHERE x.id = $1 AND x.deleted_at IS NULL`,
    [id],
  );
  return r.rows[0] ?? null;
}
