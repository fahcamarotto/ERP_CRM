/** JSON Schemas dos DTOs de entrada (validacao Fastify, OpenAPI em /docs e schema das tools MCP). */
export const uuid = { type: 'string', format: 'uuid' } as const;
const texto = (max: number) => ({ type: ['string', 'null'], maxLength: max });
const cores = ['acento', 'roxo', 'azul', 'ciano', 'laranja', 'dourado', 'sucesso', 'perigo'];
const dataHora = { type: 'string', format: 'date-time', description: 'ISO 8601 com fuso, ex.: 2026-10-05T14:00:00-03:00' } as const;

export const estadosCompromisso = ['marcado', 'confirmado', 'realizado', 'faltou', 'cancelado'] as const;

export const propsFaixa = {
  type: 'object', additionalProperties: false, required: ['dia', 'inicio', 'fim'],
  properties: {
    dia: { type: 'integer', minimum: 0, maximum: 6, description: '0 domingo a 6 sabado' },
    inicio: { type: 'string', pattern: '^([01][0-9]|2[0-3]):[0-5][0-9]$' },
    fim: { type: 'string', pattern: '^(([01][0-9]|2[0-3]):[0-5][0-9]|24:00)$' },
  },
} as const;

export const propsRecurso = {
  nome: { type: 'string', minLength: 2, maxLength: 120 },
  tipo: { type: 'string', enum: ['profissional', 'sala', 'equipamento'] },
  usuario_id: { type: ['string', 'null'], format: 'uuid', description: 'Usuario do workspace (so profissional)' },
  cor: { type: 'string', enum: cores },
  fuso: { type: 'string', maxLength: 60, description: 'Fuso IANA, padrao America/Sao_Paulo' },
  horario: { type: 'array', items: propsFaixa, maxItems: 28, description: 'Horario de trabalho por dia da semana' },
  google_calendar_id: texto(200),
  descricao: texto(2000),
  extras: { type: 'object' },
} as const;

export const propsBloqueio = {
  inicio: dataHora,
  fim: dataHora,
  motivo: texto(200),
} as const;

export const propsServico = {
  nome: { type: 'string', minLength: 2, maxLength: 120 },
  descricao: texto(2000),
  duracao_min: { type: 'integer', minimum: 5, maximum: 720, multipleOf: 5 },
  intervalo_min: { type: 'integer', minimum: 0, maximum: 240, description: 'Preparo depois do atendimento' },
  preco: { type: ['number', 'null'], minimum: 0 },
  moeda: { type: 'string', pattern: '^[A-Z]{3}$' },
  cor: { type: 'string', enum: cores },
  recurso_ids: { type: 'array', items: uuid, maxItems: 100, description: 'Recursos que atendem (vazio = todos)' },
  extras: { type: 'object' },
} as const;

export const propsRecorrencia = {
  type: ['object', 'null'], additionalProperties: false, required: ['frequencia', 'ocorrencias'],
  properties: {
    frequencia: { type: 'string', enum: ['diaria', 'semanal', 'mensal'] },
    intervalo: { type: 'integer', minimum: 1, maximum: 12, default: 1 },
    ocorrencias: { type: 'integer', minimum: 2, maximum: 52 },
  },
} as const;

export const propsAgendar = {
  recurso_id: uuid,
  servico_id: { type: ['string', 'null'], format: 'uuid' },
  parceiro_id: { type: ['string', 'null'], format: 'uuid', description: 'Cliente (cadastros_parceiros)' },
  oportunidade_id: { type: ['string', 'null'], format: 'uuid', description: 'Oportunidade do Pipeline (opcional)' },
  titulo: texto(200),
  inicio: dataHora,
  fim: { ...dataHora, description: 'Opcional com servico: inicio + duracao do servico' },
  observacoes: texto(4000),
  recorrencia: propsRecorrencia,
  encaixe: { type: 'boolean', description: 'Permite fora do horario de trabalho (conflito continua bloqueado)' },
  extras: { type: 'object' },
} as const;

export const propsEditarCompromisso = {
  titulo: texto(200),
  observacoes: texto(4000),
  servico_id: { type: ['string', 'null'], format: 'uuid' },
  parceiro_id: { type: ['string', 'null'], format: 'uuid' },
  oportunidade_id: { type: ['string', 'null'], format: 'uuid' },
  extras: { type: 'object' },
} as const;

export const propsReagendar = {
  inicio: dataHora,
  fim: { ...dataHora, description: 'Opcional: mantem a duracao atual' },
  recurso_id: { type: ['string', 'null'], format: 'uuid' },
  encaixe: { type: 'boolean' },
} as const;

export const propsDisponibilidade = {
  servico_id: uuid,
  recurso_id: uuid,
  de: { type: 'string', format: 'date', description: 'Primeiro dia (AAAA-MM-DD)' },
  ate: { type: 'string', format: 'date', description: 'Ultimo dia (padrao: igual a de; maximo 31 dias)' },
  duracao_min: { type: 'integer', minimum: 5, maximum: 720, description: 'Sem servico: duracao desejada' },
  passo_min: { type: 'integer', minimum: 5, maximum: 240, description: 'Distancia entre horarios oferecidos' },
  limite: { type: 'integer', minimum: 1, maximum: 500, default: 200 },
} as const;

export const filtroCompromissos = {
  de: { type: 'string', maxLength: 40, description: 'Data ou data e hora inicial' },
  ate: { type: 'string', maxLength: 40, description: 'Data ou data e hora final (data inclui o dia inteiro)' },
  recurso_id: uuid,
  parceiro_id: uuid,
  estado: { type: 'string', enum: [...estadosCompromisso] },
  busca: { type: 'string', maxLength: 120 },
  limite: { type: 'integer', minimum: 1, maximum: 1000, default: 500 },
  cursor: { type: 'string', maxLength: 200 },
} as const;

export const filtroCadastro = {
  estado: { type: 'string', enum: ['ativo', 'arquivado', 'todos'], default: 'ativo' },
  busca: { type: 'string', maxLength: 120 },
} as const;
