/**
 * Google Calendar nos dois sentidos (M6.5), sempre por job.
 * Entrada: webhook `google-calendar` (Maton ou OAuth direto) vira job; AplicarEventosGoogle aplica cada evento.
 * Agendamento ligado ao evento muda de horario ou e cancelado; evento sem agendamento vira bloqueio do recurso
 * dono do calendario. Conflito: vence o mais recente (updated do Google contra updated_at local).
 * Saida: cada mudanca local enfileira agenda.google_enviar; ProcessarEnvioGoogle entrega pelo canal.
 */
import type { ContextoCaso } from '../compartilhado/efeitos.ts';
import { erroDe, fail, ok, type Result } from '../compartilhado/result.ts';
import { dadosEvento, TABELA } from '../compromisso/use-case/agendar.ts';
import type { Compromisso } from '../compromisso/model/compromisso.ts';
import type { ProgramarLembretes } from '../compromisso/model/portas.ts';
import { Periodo } from '../compromisso/model/periodo.ts';
import { Bloqueio, type BloqueioDados } from '../recurso/model/bloqueio.ts';

export const CONECTOR_GOOGLE = 'google-calendar';
export const TIPO_JOB_ENVIO = 'agenda.google_enviar';

export interface EventoExterno {
  id: string;
  calendar_id: string | null;
  titulo: string | null;
  inicio: string | null;
  fim: string | null;
  cancelado: boolean;
  atualizado_em: string;
}

type Bruto = Record<string, unknown>;
const s = (v: unknown) => (typeof v === 'string' && v.trim() ? v.trim() : null);
const quando = (v: unknown): string | null => {
  if (typeof v === 'string') return v;
  if (v && typeof v === 'object') { const o = v as Bruto; return s(o.dateTime) ?? (s(o.date) ? `${s(o.date)}T00:00:00Z` : null); }
  return null;
};

/** Aceita o formato do Google (items, start.dateTime, updated, status) e o formato simples (eventos, inicio, fim). */
export function normalizarEventos(corpo: unknown): EventoExterno[] {
  const raiz = (corpo && typeof corpo === 'object' ? corpo : {}) as Bruto;
  const calendario = s(raiz.calendar_id) ?? s(raiz.calendarId) ?? s((raiz.calendar as Bruto | undefined)?.id);
  const lista = (Array.isArray(raiz.eventos) ? raiz.eventos : Array.isArray(raiz.items) ? raiz.items : raiz.id ? [raiz] : []) as Bruto[];
  return lista.slice(0, 5000).flatMap((e) => {
    const id = s(e.id);
    if (!id) return [];
    const atualizado = s(e.atualizado_em) ?? s(e.updated);
    return [{
      id, calendar_id: s(e.calendar_id) ?? calendario ?? s((e.organizer as Bruto | undefined)?.email),
      titulo: s(e.titulo) ?? s(e.summary), inicio: quando(e.inicio ?? e.start), fim: quando(e.fim ?? e.end),
      cancelado: e.cancelado === true || e.status === 'cancelled',
      atualizado_em: atualizado && !Number.isNaN(Date.parse(atualizado)) ? new Date(atualizado).toISOString() : new Date(0).toISOString(),
    }];
  });
}

export interface PortaSincronizacao {
  recursoPorCalendario(calendarId: string): Promise<string | null>;
  compromissoPorGoogle(eventoId: string): Promise<{ compromisso: Compromisso; atualizado_em: string } | null>;
  atualizarCompromisso(x: Compromisso): Promise<void>;
  bloqueioPorGoogle(eventoId: string): Promise<(BloqueioDados & { atualizado_em: string }) | null>;
  inserirBloqueio(b: Bloqueio): Promise<void>;
  atualizarBloqueio(b: Bloqueio): Promise<void>;
  excluirBloqueio(id: string): Promise<void>;
}

export type ResultadoEvento = 'criado' | 'atualizado' | 'cancelado' | 'ignorado';

export class AplicarEventosGoogle {
  constructor(private readonly deps: { sync: PortaSincronizacao; lembretes: ProgramarLembretes; porItem: <T>(fn: () => Promise<T>) => Promise<T> }) {}

  async execute(ctx: ContextoCaso, eventos: EventoExterno[]): Promise<Result<Record<ResultadoEvento | 'erros', number>>> {
    const cont = { criado: 0, atualizado: 0, cancelado: 0, ignorado: 0, erros: 0 };
    for (const ev of eventos) {
      try {
        const r = await this.deps.porItem(() => this.aplicar(ctx, ev));
        cont[r]++;
      } catch (e) {
        cont.erros++;
        if (cont.erros === 1) console.error('[agenda] falha ao aplicar evento do Google', ev.id, e instanceof Error ? e.message : e);
      }
    }
    return ok(cont);
  }

  private async aplicar(ctx: ContextoCaso, ev: EventoExterno): Promise<ResultadoEvento> {
    const { sync } = this.deps;
    const local = await sync.compromissoPorGoogle(ev.id);
    if (local) {
      if (ev.atualizado_em <= local.atualizado_em) return 'ignorado';
      const x = local.compromisso;
      if (ev.cancelado) {
        if (x.final) return 'ignorado';
        const r = x.mudarEstado('cancelado');
        if (!r.ok) return 'ignorado';
        await sync.atualizarCompromisso(r.valor);
        await this.deps.lembretes.cancelar(x.id);
        await ctx.efeitos.auditar('agendamento.sincronizar_google', TABELA, x.id, { estado: x.estado }, { estado: 'cancelado' });
        await ctx.efeitos.publicar('agenda.cancelado', { ...dadosEvento(r.valor.paraDados()), motivo: 'google_calendar' });
        return 'cancelado';
      }
      const p = ev.inicio && ev.fim ? Periodo.tryCreate(ev.inicio, ev.fim) : null;
      if (!p?.ok || x.final) return 'ignorado';
      const n = x.moverPorSincronizacao(p.valor);
      await sync.atualizarCompromisso(n);
      await this.deps.lembretes.cancelar(x.id);
      await this.deps.lembretes.programar(n.paraDados());
      const a = x.paraDados();
      await ctx.efeitos.historico(TABELA, x.id, { inicio: a.inicio, fim: a.fim }, { inicio: p.valor.inicio, fim: p.valor.fim });
      await ctx.efeitos.auditar('agendamento.sincronizar_google', TABELA, x.id, { inicio: a.inicio, fim: a.fim }, { inicio: p.valor.inicio, fim: p.valor.fim });
      return 'atualizado';
    }
    const bloq = await sync.bloqueioPorGoogle(ev.id);
    if (bloq) {
      if (ev.atualizado_em <= bloq.atualizado_em) return 'ignorado';
      if (ev.cancelado) { await sync.excluirBloqueio(bloq.id); return 'cancelado'; }
      if (!ev.inicio || !ev.fim) return 'ignorado';
      const r = Bloqueio.reidratar(bloq).mover(ev.inicio, ev.fim, ev.titulo);
      if (!r.ok) return 'ignorado';
      await sync.atualizarBloqueio(r.valor);
      return 'atualizado';
    }
    if (ev.cancelado || !ev.calendar_id || !ev.inicio || !ev.fim) return 'ignorado';
    const recursoId = await sync.recursoPorCalendario(ev.calendar_id);
    if (!recursoId) return 'ignorado';
    const b = Bloqueio.tryCreate({ recurso_id: recursoId, inicio: ev.inicio, fim: ev.fim, motivo: ev.titulo ?? 'Google Calendar', origem: 'google', google_evento_id: ev.id });
    if (!b.ok) return 'ignorado';
    await sync.inserirBloqueio(b.valor);
    await ctx.efeitos.auditar('recurso.bloquear', 'agenda_bloqueios', b.valor.id, undefined, b.valor.paraDados());
    return 'criado';
  }
}

/** Canal do calendario externo visto pela Agenda. */
export interface CanalCalendario {
  ativo(): Promise<boolean>;
  enviar(evento: { compromisso_id: string; calendar_id: string; google_evento_id: string | null; titulo: string; inicio: string; fim: string; cancelado: boolean }):
    Promise<{ enviado: boolean; google_evento_id?: string; motivo?: string }>;
}

export interface PortaEnvioGoogle {
  dadosEnvio(compromissoId: string): Promise<{ compromisso: Compromisso; calendar_id: string | null; titulo: string } | null>;
  marcar(compromissoId: string, estado: 'sincronizado' | 'pendente_envio' | 'sem_conector', googleEventoId?: string | null): Promise<void>;
}

export class ProcessarEnvioGoogle {
  constructor(private readonly deps: { envio: PortaEnvioGoogle; canal: CanalCalendario }) {}

  async execute(e: { compromisso_id: string }): Promise<Result<{ estado: string }>> {
    const d = await this.deps.envio.dadosEnvio(e.compromisso_id);
    if (!d) return fail(erroDe('nao_encontrado', 'Agendamento nao encontrado'));
    if (!d.calendar_id || !(await this.deps.canal.ativo())) {
      await this.deps.envio.marcar(e.compromisso_id, 'sem_conector');
      return ok({ estado: 'sem_conector' });
    }
    const x = d.compromisso.paraDados();
    const r = await this.deps.canal.enviar({
      compromisso_id: x.id, calendar_id: d.calendar_id, google_evento_id: x.google_evento_id, titulo: d.titulo, inicio: x.inicio, fim: x.fim, cancelado: x.estado === 'cancelado',
    });
    if (!r.enviado) {
      await this.deps.envio.marcar(e.compromisso_id, 'pendente_envio');
      return ok({ estado: 'pendente_envio' });
    }
    await this.deps.envio.marcar(e.compromisso_id, 'sincronizado', r.google_evento_id ?? x.google_evento_id);
    return ok({ estado: 'sincronizado' });
  }
}
