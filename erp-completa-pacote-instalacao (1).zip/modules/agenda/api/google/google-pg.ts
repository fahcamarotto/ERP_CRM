/**
 * Canal do Google Calendar (M6.5). Estado pelo conector `google-calendar` (conectores.obter do nucleo).
 * O nucleo ainda nao publica funcao de envio para o calendario externo: o agendamento fica `pendente_envio`
 * ate a interface existir. A entrada (webhook) funciona pelo handler webhook.recebido.google-calendar.
 */
import type pg from 'pg';
import { conectores } from '@erp/api/sdk/puro';
import { CONECTOR_GOOGLE, type CanalCalendario } from './sincronizar.ts';

export class CanalGooglePg implements CanalCalendario {
  constructor(private readonly c: pg.PoolClient) {}
  async ativo(): Promise<boolean> {
    return (await conectores.obter(this.c, CONECTOR_GOOGLE))?.estado === 'ativo';
  }
  async enviar(): Promise<{ enviado: boolean; motivo?: string }> {
    return { enviado: false, motivo: 'Nucleo sem interface publicada de envio ao Google Calendar' };
  }
}

/** Estado dos conectores usados pela Agenda, para a tela mostrar o recurso desativado com o link de Integracoes. */
export async function estadoIntegracoes(c: pg.PoolClient) {
  const [whatsapp, google] = await Promise.all([conectores.obter(c, 'whatsapp-cloud-api'), conectores.obter(c, CONECTOR_GOOGLE)]);
  return { whatsapp: whatsapp?.estado ?? 'ausente', google_calendar: google?.estado ?? 'ausente' };
}
