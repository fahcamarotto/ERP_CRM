/**
 * Composicao do modulo Agenda: liga casos de uso aos adaptadores Postgres para um cliente de transacao.
 * Usada pelas rotas, pelas tools, pelo worker e pelo seed. Nao importa Fastify nem o pool do servidor.
 */
import type pg from 'pg';
import { CompromissoRepoPg, porItemPg } from './compromisso/adapter/compromisso-repo-pg.ts';
import { Agendar, ConsultarDisponibilidade } from './compromisso/use-case/agendar.ts';
import { EditarCompromisso, MudarEstadoCompromisso, Reagendar } from './compromisso/use-case/alterar.ts';
import { CanalGooglePg } from './google/google-pg.ts';
import { AplicarEventosGoogle, ProcessarEnvioGoogle, type PortaSincronizacao } from './google/sincronizar.ts';
import { CanalWhatsappPg, LembretesPg } from './lembrete/lembrete-repo-pg.ts';
import { ProcessarLembrete } from './lembrete/lembretes.ts';
import { RecursoRepoPg } from './recurso/adapter/recurso-repo-pg.ts';
import { AdicionarBloqueio, CriarRecurso, EditarRecurso, MudarEstadoRecurso, RemoverBloqueio } from './recurso/use-case/recursos.ts';
import { ServicoRepoPg } from './servico/adapter/servico-repo-pg.ts';
import { CriarServico, EditarServico, MudarEstadoServico } from './servico/use-case/servicos.ts';

export function casosDeUso(c: pg.PoolClient) {
  const recursos = new RecursoRepoPg(c);
  const servicos = new ServicoRepoPg(c);
  const compromissos = new CompromissoRepoPg(c);
  const lembretes = new LembretesPg(c);
  const depsAgenda = { repo: compromissos, refs: compromissos, ocupacao: compromissos, lembretes, google: compromissos };
  const sync: PortaSincronizacao = {
    recursoPorCalendario: (id) => recursos.garantirRecursoDoCalendario(id),
    compromissoPorGoogle: (id) => compromissos.compromissoPorGoogle(id),
    atualizarCompromisso: (x) => compromissos.atualizarCompromisso(x),
    bloqueioPorGoogle: (id) => recursos.bloqueioPorGoogle(id),
    inserirBloqueio: (b) => recursos.inserirBloqueio(b),
    atualizarBloqueio: (b) => recursos.atualizarBloqueio(b),
    excluirBloqueio: (id) => recursos.excluirBloqueio(id),
  };
  return {
    criarRecurso: new CriarRecurso({ repo: recursos, usuarios: recursos }),
    editarRecurso: new EditarRecurso({ repo: recursos, usuarios: recursos }),
    mudarEstadoRecurso: new MudarEstadoRecurso({ repo: recursos }),
    adicionarBloqueio: new AdicionarBloqueio({ repo: recursos, bloqueios: recursos }),
    removerBloqueio: new RemoverBloqueio({ bloqueios: recursos }),
    criarServico: new CriarServico({ repo: servicos, recursos: servicos }),
    editarServico: new EditarServico({ repo: servicos, recursos: servicos }),
    mudarEstadoServico: new MudarEstadoServico({ repo: servicos }),
    agendar: new Agendar(depsAgenda),
    reagendar: new Reagendar(depsAgenda),
    editarCompromisso: new EditarCompromisso(depsAgenda),
    mudarEstadoCompromisso: new MudarEstadoCompromisso(depsAgenda),
    consultarDisponibilidade: new ConsultarDisponibilidade({ refs: compromissos, ocupacao: compromissos }),
    processarLembrete: new ProcessarLembrete({ lembretes, canal: new CanalWhatsappPg(c) }),
    aplicarEventosGoogle: new AplicarEventosGoogle({ sync, lembretes, porItem: porItemPg(c) }),
    processarEnvioGoogle: new ProcessarEnvioGoogle({ envio: compromissos, canal: new CanalGooglePg(c) }),
  };
}

export type CasosDeUso = ReturnType<typeof casosDeUso>;
