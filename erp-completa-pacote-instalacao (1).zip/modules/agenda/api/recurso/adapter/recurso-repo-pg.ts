/** Adaptador Postgres do Recurso e dos bloqueios (RLS restringe ao workspace da sessao). */
import type pg from 'pg';
import { Bloqueio, type BloqueioDados } from '../model/bloqueio.ts';
import type { BuscarRecursoPorNome, ConsultarUsuarios, GravarBloqueios, GravarRecurso, ObterRecurso } from '../model/portas.ts';
import { Recurso, type RecursoDados } from '../model/recurso.ts';

const COLUNAS = 'id, nome, tipo, usuario_id, cor, fuso, horario, google_calendar_id, descricao, estado, extras';
const COLUNAS_BLOQ = 'id, recurso_id, inicio, fim, motivo, origem, google_evento_id';

export class RecursoRepoPg implements ObterRecurso, GravarRecurso, BuscarRecursoPorNome, ConsultarUsuarios, GravarBloqueios {
  constructor(private readonly c: pg.PoolClient) {}

  async obterPorId(id: string): Promise<Recurso | null> {
    const r = await this.c.query(`SELECT ${COLUNAS} FROM agenda_recursos WHERE id = $1 AND deleted_at IS NULL`, [id]);
    return r.rows[0] ? Recurso.reidratar(r.rows[0] as RecursoDados) : null;
  }

  async buscarPorNome(nome: string): Promise<Recurso | null> {
    const r = await this.c.query(`SELECT ${COLUNAS} FROM agenda_recursos WHERE lower(nome) = lower($1) AND deleted_at IS NULL LIMIT 1`, [nome]);
    return r.rows[0] ? Recurso.reidratar(r.rows[0] as RecursoDados) : null;
  }

  async inserir(x: Recurso): Promise<void> {
    const d = x.paraDados();
    await this.c.query(
      `INSERT INTO agenda_recursos (id, nome, tipo, usuario_id, cor, fuso, horario, google_calendar_id, descricao, estado, extras, creator_id)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, nucleo_usuario_atual())`,
      [d.id, d.nome, d.tipo, d.usuario_id, d.cor, d.fuso, JSON.stringify(d.horario), d.google_calendar_id, d.descricao, d.estado, JSON.stringify(d.extras)],
    );
  }

  async atualizar(x: Recurso): Promise<void> {
    const d = x.paraDados();
    await this.c.query(
      `UPDATE agenda_recursos SET nome = $2, tipo = $3, usuario_id = $4, cor = $5, fuso = $6, horario = $7, google_calendar_id = $8,
         descricao = $9, estado = $10, extras = $11 WHERE id = $1 AND deleted_at IS NULL`,
      [d.id, d.nome, d.tipo, d.usuario_id, d.cor, d.fuso, JSON.stringify(d.horario), d.google_calendar_id, d.descricao, d.estado, JSON.stringify(d.extras)],
    );
  }

  async usuarioExiste(id: string): Promise<boolean> {
    return ((await this.c.query('SELECT 1 FROM usuarios WHERE id = $1 AND deleted_at IS NULL', [id])).rowCount ?? 0) > 0;
  }

  async obterBloqueio(id: string): Promise<Bloqueio | null> {
    const r = await this.c.query(`SELECT ${COLUNAS_BLOQ} FROM agenda_bloqueios WHERE id = $1 AND deleted_at IS NULL`, [id]);
    return r.rows[0] ? Bloqueio.reidratar(r.rows[0] as BloqueioDados) : null;
  }

  async inserirBloqueio(b: Bloqueio): Promise<void> {
    const d = b.paraDados();
    await this.c.query(
      `INSERT INTO agenda_bloqueios (id, recurso_id, inicio, fim, motivo, origem, google_evento_id, creator_id)
       VALUES ($1, $2, $3, $4, $5, $6, $7, nucleo_usuario_atual())`,
      [d.id, d.recurso_id, d.inicio, d.fim, d.motivo, d.origem, d.google_evento_id],
    );
  }

  async atualizarBloqueio(b: Bloqueio): Promise<void> {
    const d = b.paraDados();
    await this.c.query('UPDATE agenda_bloqueios SET inicio = $2, fim = $3, motivo = $4 WHERE id = $1 AND deleted_at IS NULL', [d.id, d.inicio, d.fim, d.motivo]);
  }

  async excluirBloqueio(id: string): Promise<void> {
    await this.c.query('UPDATE agenda_bloqueios SET deleted_at = now() WHERE id = $1 AND deleted_at IS NULL', [id]);
  }

  async bloqueioPorGoogle(googleEventoId: string): Promise<(BloqueioDados & { atualizado_em: string }) | null> {
    const r = await this.c.query(`SELECT ${COLUNAS_BLOQ}, updated_at AS atualizado_em FROM agenda_bloqueios WHERE google_evento_id = $1 AND deleted_at IS NULL`, [googleEventoId]);
    return r.rows[0] ? { ...r.rows[0], atualizado_em: new Date(r.rows[0].atualizado_em).toISOString() } : null;
  }

  async recursoPorCalendario(calendarId: string): Promise<string | null> {
    const r = await this.c.query("SELECT id FROM agenda_recursos WHERE google_calendar_id = $1 AND estado = 'ativo' AND deleted_at IS NULL LIMIT 1", [calendarId]);
    return (r.rows[0]?.id as string | undefined) ?? null;
  }

  /**
   * Agenda Google sincronizada sem recurso ligado: cria o recurso dela (profissional, nome da agenda) para os
   * eventos virarem bloqueios visiveis na Agenda. Idempotente: reaproveita o recurso arquivado do mesmo calendario.
   */
  async garantirRecursoDoCalendario(calendarId: string): Promise<string | null> {
    const existente = await this.recursoPorCalendario(calendarId);
    if (existente) return existente;
    const arquivado = await this.c.query('SELECT id FROM agenda_recursos WHERE google_calendar_id = $1 AND deleted_at IS NULL LIMIT 1', [calendarId]);
    if (arquivado.rows[0]) return null;
    const r = Recurso.tryCreate({ nome: `Google Agenda (${calendarId})`.slice(0, 120), tipo: 'profissional', google_calendar_id: calendarId });
    if (!r.ok) return null;
    await this.inserir(r.valor);
    return r.valor.id;
  }
}
