/** Consultas de leitura do Recurso: lista com usuario ligado e ficha com bloqueios futuros e servicos. */
import type pg from 'pg';

const RESUMO = `r.id, r.nome, r.tipo, r.usuario_id, u.nome AS usuario_nome, r.cor, r.fuso, r.horario, r.google_calendar_id, r.descricao,
  r.estado, r.created_at, r.updated_at,
  (SELECT count(*)::int FROM agenda_compromissos x WHERE x.recurso_id = r.id AND x.deleted_at IS NULL
     AND x.estado IN ('marcado', 'confirmado') AND x.inicio >= now()) AS proximos`;

export interface FiltroRecursos {
  estado?: 'ativo' | 'arquivado' | 'todos';
  tipo?: string;
  busca?: string;
}

export async function listarRecursos(c: pg.PoolClient, f: FiltroRecursos = {}) {
  const estado = f.estado ?? 'ativo';
  const r = await c.query(
    `SELECT ${RESUMO} FROM agenda_recursos r LEFT JOIN usuarios u ON u.id = r.usuario_id
     WHERE r.deleted_at IS NULL AND ($1::text = 'todos' OR r.estado = $1) AND ($2::text IS NULL OR r.tipo = $2)
       AND ($3::text IS NULL OR r.nome ILIKE '%' || $3 || '%')
     ORDER BY r.nome LIMIT 500`,
    [estado, f.tipo ?? null, f.busca?.trim() || null],
  );
  return r.rows;
}

export async function obterRecurso(c: pg.PoolClient, id: string) {
  const r = await c.query(
    `SELECT ${RESUMO}, r.extras,
       coalesce((SELECT json_agg(json_build_object('id', b.id, 'inicio', b.inicio, 'fim', b.fim, 'motivo', b.motivo, 'origem', b.origem) ORDER BY b.inicio)
                 FROM agenda_bloqueios b WHERE b.recurso_id = r.id AND b.deleted_at IS NULL AND b.fim >= now() - interval '1 day'), '[]') AS bloqueios,
       coalesce((SELECT json_agg(json_build_object('id', s.id, 'nome', s.nome) ORDER BY s.nome) FROM agenda_servico_recursos sr
                 JOIN agenda_servicos s ON s.id = sr.servico_id AND s.deleted_at IS NULL WHERE sr.recurso_id = r.id AND sr.deleted_at IS NULL), '[]') AS servicos
     FROM agenda_recursos r LEFT JOIN usuarios u ON u.id = r.usuario_id WHERE r.id = $1 AND r.deleted_at IS NULL`,
    [id],
  );
  return r.rows[0] ?? null;
}

export interface FiltroBloqueios {
  de: string;
  ate: string;
  recurso_id?: string;
}

/** Bloqueios (manuais e eventos do Google) que cruzam o periodo, com nome e cor do recurso, para o calendario. */
export async function listarBloqueios(c: pg.PoolClient, f: FiltroBloqueios) {
  const r = await c.query(
    `SELECT b.id, b.recurso_id, r.nome AS recurso_nome, r.cor AS recurso_cor, b.inicio, b.fim, b.motivo, b.origem
     FROM agenda_bloqueios b JOIN agenda_recursos r ON r.id = b.recurso_id AND r.deleted_at IS NULL
     WHERE b.deleted_at IS NULL AND b.fim > $1::timestamptz AND b.inicio < $2::timestamptz AND ($3::uuid IS NULL OR b.recurso_id = $3)
     ORDER BY b.inicio, b.id LIMIT 2000`,
    [f.de, f.ate, f.recurso_id ?? null],
  );
  return r.rows;
}
