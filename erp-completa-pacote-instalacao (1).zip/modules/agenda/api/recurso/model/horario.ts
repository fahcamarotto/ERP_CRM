/**
 * Objeto de valor HorarioTrabalho (M6.1): faixas por dia da semana (0 domingo a 6 sabado) em hora local
 * do recurso, HH:MM a HH:MM, sem sobreposicao no mesmo dia.
 */
import { erroDe, fail, ok, type ErroDominio, type Result } from '../../compartilhado/result.ts';

export interface FaixaHorario {
  dia: number;
  inicio: string;
  fim: string;
}

const HHMM = /^([01]\d|2[0-3]):[0-5]\d$|^24:00$/;
export const minutos = (hhmm: string) => Number(hhmm.slice(0, 2)) * 60 + Number(hhmm.slice(3, 5));

export class HorarioTrabalho {
  private constructor(readonly faixas: readonly FaixaHorario[]) {}

  static tryCreate(bruto: unknown): Result<HorarioTrabalho> {
    if (!Array.isArray(bruto)) return fail(erroDe('horario_invalido', 'Horario deve ser uma lista de faixas', 'horario'));
    if (bruto.length > 28) return fail(erroDe('horario_invalido', 'Maximo de 28 faixas', 'horario'));
    const erros: ErroDominio[] = [];
    const faixas: FaixaHorario[] = [];
    for (const [i, f] of bruto.entries()) {
      const x = (f ?? {}) as Partial<FaixaHorario>;
      const dia = Number(x.dia);
      if (!Number.isInteger(dia) || dia < 0 || dia > 6) { erros.push(erroDe('horario_invalido', `Faixa ${i + 1}: dia de 0 (domingo) a 6 (sabado)`, 'horario')); continue; }
      if (typeof x.inicio !== 'string' || typeof x.fim !== 'string' || !HHMM.test(x.inicio) || !HHMM.test(x.fim)) {
        erros.push(erroDe('horario_invalido', `Faixa ${i + 1}: horas no formato HH:MM`, 'horario')); continue;
      }
      if (minutos(x.fim) <= minutos(x.inicio)) { erros.push(erroDe('horario_invalido', `Faixa ${i + 1}: fim antes do inicio`, 'horario')); continue; }
      faixas.push({ dia, inicio: x.inicio, fim: x.fim });
    }
    faixas.sort((a, b) => a.dia - b.dia || minutos(a.inicio) - minutos(b.inicio));
    for (let i = 1; i < faixas.length; i++) {
      const a = faixas[i - 1]!;
      const b = faixas[i]!;
      if (a.dia === b.dia && minutos(b.inicio) < minutos(a.fim)) erros.push(erroDe('horario_invalido', `Faixas sobrepostas no dia ${a.dia}`, 'horario'));
    }
    return erros.length ? fail(...erros) : ok(new HorarioTrabalho(faixas));
  }

  static create(bruto: unknown): HorarioTrabalho {
    const r = HorarioTrabalho.tryCreate(bruto);
    if (!r.ok) throw new Error(r.erros.map((e) => e.mensagem).join('; '));
    return r.valor;
  }

  /** Segunda a sexta, 08:00 a 12:00 e 13:00 a 18:00. */
  static padrao(): HorarioTrabalho {
    return HorarioTrabalho.create([1, 2, 3, 4, 5].flatMap((dia) => [{ dia, inicio: '08:00', fim: '12:00' }, { dia, inicio: '13:00', fim: '18:00' }]));
  }

  /** Faixas do dia em minutos [inicio, fim). */
  doDia(dia: number): [number, number][] {
    return this.faixas.filter((f) => f.dia === dia).map((f) => [minutos(f.inicio), minutos(f.fim)]);
  }

  /** O trecho [ini, fim) em minutos do dia cabe inteiro numa faixa? */
  contem(dia: number, ini: number, fim: number): boolean {
    return this.doDia(dia).some(([a, b]) => ini >= a && fim <= b);
  }

  paraDados(): FaixaHorario[] {
    return this.faixas.map((f) => ({ ...f }));
  }
}
