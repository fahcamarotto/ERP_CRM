/**
 * Entidade Recurso (M6.1): profissional, sala ou equipamento com horario de trabalho, fuso e cor.
 * Imutavel: toda alteracao devolve um clone novo.
 */
import { randomUUID } from 'node:crypto';
import { fusoValido } from '../../compartilhado/fuso.ts';
import { combinar, erroDe, fail, ok, type ErroDominio, type Result } from '../../compartilhado/result.ts';
import { HorarioTrabalho, type FaixaHorario } from './horario.ts';

export const TIPOS_RECURSO = ['profissional', 'sala', 'equipamento'] as const;
export type TipoRecurso = (typeof TIPOS_RECURSO)[number];
export const CORES = ['acento', 'roxo', 'azul', 'ciano', 'laranja', 'dourado', 'sucesso', 'perigo'] as const;
export type Cor = (typeof CORES)[number];
export type EstadoCadastro = 'ativo' | 'arquivado';

export interface DadosRecurso {
  nome: string;
  tipo?: TipoRecurso;
  usuario_id?: string | null;
  cor?: Cor;
  fuso?: string;
  horario?: FaixaHorario[];
  google_calendar_id?: string | null;
  descricao?: string | null;
  extras?: Record<string, unknown>;
}

export interface RecursoDados {
  id: string;
  nome: string;
  tipo: TipoRecurso;
  usuario_id: string | null;
  cor: Cor;
  fuso: string;
  horario: FaixaHorario[];
  google_calendar_id: string | null;
  descricao: string | null;
  estado: EstadoCadastro;
  extras: Record<string, unknown>;
}

const t = (v?: string | null) => (v ?? '').trim() || null;

function validar(d: Omit<RecursoDados, 'horario'>): ErroDominio[] {
  const e: ErroDominio[] = [];
  if (d.nome.length < 2 || d.nome.length > 120) e.push(erroDe('nome_invalido', 'Nome deve ter de 2 a 120 caracteres', 'nome'));
  if (!TIPOS_RECURSO.includes(d.tipo)) e.push(erroDe('tipo_invalido', 'Tipo deve ser profissional, sala ou equipamento', 'tipo'));
  if (!CORES.includes(d.cor)) e.push(erroDe('cor_invalida', 'Cor fora da paleta', 'cor'));
  if (!fusoValido(d.fuso)) e.push(erroDe('fuso_invalido', 'Fuso horario IANA invalido (ex.: America/Sao_Paulo)', 'fuso'));
  if (d.usuario_id && d.tipo !== 'profissional') e.push(erroDe('usuario_invalido', 'So profissional pode ser ligado a um usuario', 'usuario_id'));
  if (d.google_calendar_id && d.google_calendar_id.length > 200) e.push(erroDe('calendario_invalido', 'Id do Google Calendar muito longo', 'google_calendar_id'));
  return e;
}

export class Recurso {
  private constructor(private readonly d: Omit<RecursoDados, 'horario'>, readonly horario: HorarioTrabalho) {}

  static tryCreate(e: DadosRecurso, id: string = randomUUID()): Result<Recurso> {
    const base = {
      id, nome: (e.nome ?? '').trim(), tipo: e.tipo ?? 'profissional', usuario_id: t(e.usuario_id), cor: e.cor ?? 'acento',
      fuso: t(e.fuso) ?? 'America/Sao_Paulo', google_calendar_id: t(e.google_calendar_id), descricao: t(e.descricao), estado: 'ativo' as const, extras: e.extras ?? {},
    };
    const h = e.horario === undefined ? ok(HorarioTrabalho.padrao()) : HorarioTrabalho.tryCreate(e.horario);
    const v = validar(base);
    const r = combinar(h, v.length ? fail(...v) : ok(null));
    return r.ok ? ok(new Recurso(base, r.valor[0])) : r;
  }

  static create(e: DadosRecurso, id?: string): Recurso {
    const r = Recurso.tryCreate(e, id);
    if (!r.ok) throw new Error(r.erros.map((x) => x.mensagem).join('; '));
    return r.valor;
  }

  static reidratar(d: RecursoDados): Recurso {
    const { horario, ...resto } = d;
    return new Recurso({ ...resto, extras: { ...(resto.extras ?? {}) } }, HorarioTrabalho.create(horario ?? []));
  }

  get id(): string { return this.d.id; }
  get nome(): string { return this.d.nome; }
  get fuso(): string { return this.d.fuso; }
  get estado(): EstadoCadastro { return this.d.estado; }

  editar(e: Partial<DadosRecurso>): Result<Recurso> {
    if (this.d.estado === 'arquivado') return fail(erroDe('transicao_invalida', 'Recurso arquivado nao pode ser editado; reative antes'));
    const tem = (k: keyof DadosRecurso) => e[k] !== undefined;
    const n = {
      ...this.d,
      nome: tem('nome') ? (e.nome ?? '').trim() : this.d.nome,
      tipo: tem('tipo') ? e.tipo! : this.d.tipo,
      usuario_id: tem('usuario_id') ? t(e.usuario_id) : this.d.usuario_id,
      cor: tem('cor') ? e.cor! : this.d.cor,
      fuso: tem('fuso') ? (t(e.fuso) ?? 'America/Sao_Paulo') : this.d.fuso,
      google_calendar_id: tem('google_calendar_id') ? t(e.google_calendar_id) : this.d.google_calendar_id,
      descricao: tem('descricao') ? t(e.descricao) : this.d.descricao,
      extras: tem('extras') ? { ...e.extras } : { ...this.d.extras },
    };
    const h = tem('horario') ? HorarioTrabalho.tryCreate(e.horario) : ok(this.horario);
    const v = validar(n);
    const r = combinar(h, v.length ? fail(...v) : ok(null));
    return r.ok ? ok(new Recurso(n, r.valor[0])) : r;
  }

  mudarEstado(novo: EstadoCadastro): Result<Recurso> {
    if (novo !== 'ativo' && novo !== 'arquivado') return fail(erroDe('estado_invalido', 'Estado invalido', 'estado'));
    if (novo === this.d.estado) return fail(erroDe('transicao_invalida', `Recurso ja esta ${novo}`, 'estado'));
    return ok(new Recurso({ ...this.d, estado: novo }, this.horario));
  }

  paraDados(): RecursoDados {
    return { ...this.d, horario: this.horario.paraDados(), extras: { ...this.d.extras } };
  }
}
