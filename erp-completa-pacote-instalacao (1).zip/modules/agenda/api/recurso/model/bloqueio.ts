/**
 * Bloqueio do recurso (M6.1): ferias, manutencao, compromisso externo ou evento vindo do Google Calendar.
 * Entidade filha do Recurso; o horario bloqueado some da disponibilidade e impede agendamento.
 */
import { randomUUID } from 'node:crypto';
import { erroDe, fail, ok, type ErroDominio, type Result } from '../../compartilhado/result.ts';

export type OrigemBloqueio = 'manual' | 'google';

export interface DadosBloqueio {
  recurso_id: string;
  inicio: string;
  fim: string;
  motivo?: string | null;
  origem?: OrigemBloqueio;
  google_evento_id?: string | null;
}

export interface BloqueioDados {
  id: string;
  recurso_id: string;
  inicio: string;
  fim: string;
  motivo: string | null;
  origem: OrigemBloqueio;
  google_evento_id: string | null;
}

const MAX_MS = 366 * 86400000;

export function validarPeriodo(inicio: string, fim: string, campo = 'inicio'): ErroDominio[] {
  const a = Date.parse(inicio);
  const b = Date.parse(fim);
  if (Number.isNaN(a) || Number.isNaN(b)) return [erroDe('data_invalida', 'Inicio e fim em data e hora ISO 8601', campo)];
  if (b <= a) return [erroDe('periodo_invalido', 'Fim deve ser depois do inicio', 'fim')];
  return [];
}

export class Bloqueio {
  private constructor(private readonly d: BloqueioDados) {}

  static tryCreate(e: DadosBloqueio, id: string = randomUUID()): Result<Bloqueio> {
    const erros = validarPeriodo(e.inicio, e.fim);
    if (!erros.length && Date.parse(e.fim) - Date.parse(e.inicio) > MAX_MS) erros.push(erroDe('periodo_invalido', 'Bloqueio de no maximo 366 dias', 'fim'));
    const motivo = (e.motivo ?? '').trim() || null;
    if (motivo && motivo.length > 200) erros.push(erroDe('motivo_invalido', 'Motivo de ate 200 caracteres', 'motivo'));
    if (erros.length) return fail(...erros);
    return ok(new Bloqueio({
      id, recurso_id: e.recurso_id, inicio: new Date(e.inicio).toISOString(), fim: new Date(e.fim).toISOString(), motivo,
      origem: e.origem ?? 'manual', google_evento_id: (e.google_evento_id ?? '').trim() || null,
    }));
  }

  static create(e: DadosBloqueio, id?: string): Bloqueio {
    const r = Bloqueio.tryCreate(e, id);
    if (!r.ok) throw new Error(r.erros.map((x) => x.mensagem).join('; '));
    return r.valor;
  }

  static reidratar(d: BloqueioDados): Bloqueio {
    return new Bloqueio({ ...d, inicio: new Date(d.inicio).toISOString(), fim: new Date(d.fim).toISOString() });
  }

  get id(): string { return this.d.id; }

  /** Novo periodo (sincronizacao do Google). */
  mover(inicio: string, fim: string, motivo?: string | null): Result<Bloqueio> {
    return Bloqueio.tryCreate({ ...this.d, inicio, fim, motivo: motivo === undefined ? this.d.motivo : motivo }, this.d.id);
  }

  paraDados(): BloqueioDados {
    return { ...this.d };
  }
}
