/** Portas do agregado Recurso (e do bloqueio, entidade filha), segregadas por operacao. */
import type { Bloqueio } from './bloqueio.ts';
import type { Recurso } from './recurso.ts';

export interface ObterRecurso {
  obterPorId(id: string): Promise<Recurso | null>;
}

export interface GravarRecurso {
  inserir(r: Recurso): Promise<void>;
  atualizar(r: Recurso): Promise<void>;
}

export interface BuscarRecursoPorNome {
  buscarPorNome(nome: string): Promise<Recurso | null>;
}

/** Referencia fora do agregado: usuario do workspace (profissional ligado a login). */
export interface ConsultarUsuarios {
  usuarioExiste(id: string): Promise<boolean>;
}

export interface GravarBloqueios {
  obterBloqueio(id: string): Promise<Bloqueio | null>;
  inserirBloqueio(b: Bloqueio): Promise<void>;
  atualizarBloqueio(b: Bloqueio): Promise<void>;
  excluirBloqueio(id: string): Promise<void>;
}
