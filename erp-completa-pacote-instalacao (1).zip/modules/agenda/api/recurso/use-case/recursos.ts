/** Casos de uso do Recurso (M6.1): CriarRecurso, EditarRecurso, MudarEstadoRecurso, AdicionarBloqueio, RemoverBloqueio. */
import type { ContextoCaso } from '../../compartilhado/efeitos.ts';
import { erroDe, fail, ok, okVazio, type ErroDominio, type Result } from '../../compartilhado/result.ts';
import { Bloqueio, type DadosBloqueio } from '../model/bloqueio.ts';
import type { BuscarRecursoPorNome, ConsultarUsuarios, GravarBloqueios, GravarRecurso, ObterRecurso } from '../model/portas.ts';
import { Recurso, type DadosRecurso, type EstadoCadastro } from '../model/recurso.ts';

const TABELA = 'agenda_recursos';

export interface DepsRecurso {
  repo: ObterRecurso & GravarRecurso & BuscarRecursoPorNome;
  usuarios: ConsultarUsuarios;
}

async function conferir(deps: DepsRecurso, r: Recurso, anterior?: Recurso): Promise<ErroDominio[]> {
  const d = r.paraDados();
  const erros: ErroDominio[] = [];
  const mesmoNome = await deps.repo.buscarPorNome(d.nome);
  if (mesmoNome && mesmoNome.id !== d.id) erros.push(erroDe('conflito', 'Ja existe recurso com este nome', 'nome', { recurso_id: mesmoNome.id }));
  if (d.usuario_id && d.usuario_id !== anterior?.paraDados().usuario_id && !(await deps.usuarios.usuarioExiste(d.usuario_id))) {
    erros.push(erroDe('usuario_invalido', 'Usuario nao encontrado no workspace', 'usuario_id'));
  }
  return erros;
}

export class CriarRecurso {
  constructor(private readonly deps: DepsRecurso) {}
  async execute(ctx: ContextoCaso, e: DadosRecurso): Promise<Result<{ id: string }>> {
    const r = Recurso.tryCreate(e);
    if (!r.ok) return r;
    const erros = await conferir(this.deps, r.valor);
    if (erros.length) return fail(...erros);
    await this.deps.repo.inserir(r.valor);
    const d = r.valor.paraDados();
    await ctx.efeitos.auditar('recurso.criar', TABELA, d.id, undefined, d);
    return ok({ id: d.id });
  }
}

export class EditarRecurso {
  constructor(private readonly deps: DepsRecurso) {}
  async execute(ctx: ContextoCaso, e: { id: string } & Partial<DadosRecurso>): Promise<Result<void>> {
    const { id, ...mud } = e;
    const atual = await this.deps.repo.obterPorId(id);
    if (!atual) return fail(erroDe('nao_encontrado', 'Recurso nao encontrado'));
    const r = atual.editar(mud);
    if (!r.ok) return r;
    const erros = await conferir(this.deps, r.valor, atual);
    if (erros.length) return fail(...erros);
    await this.deps.repo.atualizar(r.valor);
    const antes = atual.paraDados() as unknown as Record<string, unknown>;
    const depois = r.valor.paraDados() as unknown as Record<string, unknown>;
    await ctx.efeitos.historico(TABELA, id, antes, depois);
    await ctx.efeitos.auditar('recurso.editar', TABELA, id, antes, depois);
    return okVazio();
  }
}

export class MudarEstadoRecurso {
  constructor(private readonly deps: { repo: ObterRecurso & GravarRecurso }) {}
  async execute(ctx: ContextoCaso, e: { id: string; estado: EstadoCadastro }): Promise<Result<void>> {
    const atual = await this.deps.repo.obterPorId(e.id);
    if (!atual) return fail(erroDe('nao_encontrado', 'Recurso nao encontrado'));
    const r = atual.mudarEstado(e.estado);
    if (!r.ok) return r;
    await this.deps.repo.atualizar(r.valor);
    await ctx.efeitos.historico(TABELA, e.id, { estado: atual.estado }, { estado: e.estado });
    await ctx.efeitos.auditar('recurso.mudar_estado', TABELA, e.id, { estado: atual.estado }, { estado: e.estado });
    return okVazio();
  }
}

export class AdicionarBloqueio {
  constructor(private readonly deps: { repo: ObterRecurso; bloqueios: GravarBloqueios }) {}
  async execute(ctx: ContextoCaso, e: DadosBloqueio): Promise<Result<{ id: string }>> {
    const recurso = await this.deps.repo.obterPorId(e.recurso_id);
    if (!recurso) return fail(erroDe('nao_encontrado', 'Recurso nao encontrado'));
    const b = Bloqueio.tryCreate({ ...e, origem: 'manual', google_evento_id: null });
    if (!b.ok) return b;
    await this.deps.bloqueios.inserirBloqueio(b.valor);
    const d = b.valor.paraDados();
    await ctx.efeitos.auditar('recurso.bloquear', 'agenda_bloqueios', d.id, undefined, d);
    await ctx.efeitos.nota(TABELA, e.recurso_id, `Bloqueio de ${d.inicio} a ${d.fim}${d.motivo ? `: ${d.motivo}` : ''}`);
    return ok({ id: d.id });
  }
}

export class RemoverBloqueio {
  constructor(private readonly deps: { bloqueios: GravarBloqueios }) {}
  async execute(ctx: ContextoCaso, e: { id: string }): Promise<Result<void>> {
    const b = await this.deps.bloqueios.obterBloqueio(e.id);
    if (!b) return fail(erroDe('nao_encontrado', 'Bloqueio nao encontrado'));
    await this.deps.bloqueios.excluirBloqueio(e.id);
    await ctx.efeitos.auditar('recurso.desbloquear', 'agenda_bloqueios', e.id, b.paraDados(), undefined);
    return okVazio();
  }
}
