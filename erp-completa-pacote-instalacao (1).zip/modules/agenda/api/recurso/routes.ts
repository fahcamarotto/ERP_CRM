/** Rotas REST do Recurso fora das tools: ficha, criar, editar, arquivar, bloqueios e opcoes de usuario. Listar e @tool agenda.recursos. */
import { esquemaErro, requer, type FastifyInstance } from '@erp/api/sdk';
import { naTransacao, naoEncontrado } from '../borda.ts';
import { exigirOk } from '../compartilhado/result.ts';
import { propsBloqueio, propsRecurso, uuid } from '../esquemas.ts';
import type { DadosRecurso, EstadoCadastro } from './model/recurso.ts';
import { listarBloqueios, obterRecurso } from './query/recursos.ts';

const tags = ['agenda'];
const paramId = { type: 'object', required: ['id'], properties: { id: uuid } } as const;
const erros = { 400: esquemaErro, 403: esquemaErro, 404: esquemaErro, 409: esquemaErro };

export function rotasRecurso(app: FastifyInstance): void {
  // Leitura da tabela publicada do nucleo `usuarios` (CONTRATOS 2.2): profissional ligado a um login.
  app.get('/usuarios', {
    preHandler: requer('agenda.ver'),
    schema: { tags, summary: 'Usuarios ativos do workspace (para ligar ao profissional)' },
  }, (req) => naTransacao(req, async (_, __, c) => (await c.query('SELECT id, nome FROM usuarios WHERE ativo AND deleted_at IS NULL ORDER BY nome')).rows));

  app.get<{ Params: { id: string } }>('/recursos/:id', {
    preHandler: requer('agenda.ver'),
    schema: { tags, summary: 'Ficha do recurso com bloqueios e servicos', params: paramId, response: { 404: esquemaErro } },
  }, (req) => naTransacao(req, async (_, __, c) => (await obterRecurso(c, req.params.id)) ?? Promise.reject(naoEncontrado('Recurso nao encontrado'))));

  app.post<{ Body: DadosRecurso }>('/recursos', {
    preHandler: requer('agenda.criar'),
    schema: { tags, summary: 'Cria profissional, sala ou equipamento (CriarRecurso)', body: { type: 'object', additionalProperties: false, required: ['nome'], properties: propsRecurso }, response: erros },
  }, async (req, reply) => reply.code(201).send(await naTransacao(req, async (casos, ctx, c) => {
    const { id } = exigirOk(await casos.criarRecurso.execute(ctx, req.body));
    return obterRecurso(c, id);
  })));

  app.patch<{ Params: { id: string }; Body: Partial<DadosRecurso> }>('/recursos/:id', {
    preHandler: requer('agenda.editar'),
    schema: { tags, summary: 'Edita recurso e horario de trabalho (EditarRecurso)', params: paramId, body: { type: 'object', additionalProperties: false, properties: propsRecurso }, response: erros },
  }, (req) => naTransacao(req, async (casos, ctx, c) => {
    exigirOk(await casos.editarRecurso.execute(ctx, { ...req.body, id: req.params.id }));
    return obterRecurso(c, req.params.id);
  }));

  app.post<{ Params: { id: string }; Body: { estado: EstadoCadastro } }>('/recursos/:id/estado', {
    preHandler: requer('agenda.editar'),
    schema: { tags, summary: 'Arquiva ou reativa o recurso (MudarEstadoRecurso)', params: paramId,
      body: { type: 'object', additionalProperties: false, required: ['estado'], properties: { estado: { type: 'string', enum: ['ativo', 'arquivado'] } } }, response: erros },
  }, (req) => naTransacao(req, async (casos, ctx, c) => {
    exigirOk(await casos.mudarEstadoRecurso.execute(ctx, { id: req.params.id, estado: req.body.estado }));
    return obterRecurso(c, req.params.id);
  }));

  app.post<{ Params: { id: string }; Body: { inicio: string; fim: string; motivo?: string | null } }>('/recursos/:id/bloqueios', {
    preHandler: requer('agenda.editar'),
    schema: { tags, summary: 'Bloqueia um periodo do recurso (AdicionarBloqueio)', params: paramId,
      body: { type: 'object', additionalProperties: false, required: ['inicio', 'fim'], properties: propsBloqueio }, response: erros },
  }, async (req, reply) => reply.code(201).send(await naTransacao(req, async (casos, ctx, c) => {
    exigirOk(await casos.adicionarBloqueio.execute(ctx, { ...req.body, recurso_id: req.params.id }));
    return obterRecurso(c, req.params.id);
  })));

  app.get<{ Querystring: { de: string; ate: string; recurso_id?: string } }>('/bloqueios', {
    preHandler: requer('agenda.ver'),
    schema: { tags, summary: 'Bloqueios e eventos do Google que cruzam o periodo (calendario), recurso opcional',
      querystring: { type: 'object', additionalProperties: false, required: ['de', 'ate'],
        properties: { de: { type: 'string', format: 'date-time' }, ate: { type: 'string', format: 'date-time' }, recurso_id: uuid } },
      response: { 400: esquemaErro, 403: esquemaErro } },
  }, (req) => naTransacao(req, (_, __, c) => listarBloqueios(c, req.query)));

  app.delete<{ Params: { id: string } }>('/bloqueios/:id', {
    preHandler: requer('agenda.excluir'),
    schema: { tags, summary: 'Remove um bloqueio (RemoverBloqueio, exclusao logica)', params: paramId, response: { 404: esquemaErro } },
  }, async (req, reply) => {
    await naTransacao(req, async (casos, ctx) => exigirOk(await casos.removerBloqueio.execute(ctx, { id: req.params.id })));
    return reply.code(204).send();
  });
}
