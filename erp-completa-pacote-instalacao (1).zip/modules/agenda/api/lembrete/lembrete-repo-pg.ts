/**
 * Adaptadores Postgres dos lembretes (M6.6): tabela agenda_lembretes, job agenda.lembrete na outbox com
 * disponivel_em, configuracao `agenda.lembretes` (N16) e canal WhatsApp pelo conector do nucleo.
 */
import type pg from 'pg';
import { conectores, lerConfiguracao } from '@erp/api/sdk/puro';
import type { CompromissoDados } from '../compromisso/model/compromisso.ts';
import type { ProgramarLembretes } from '../compromisso/model/portas.ts';
import {
  CHAVE_CONFIG, CONFIG_PADRAO, planejarLembretes, TIPO_JOB_LEMBRETE,
  type CanalMensagens, type ConfigLembretes, type EstadoLembrete, type LembreteContexto, type PortaLembretes,
} from './lembretes.ts';

export const CONECTOR_WHATSAPP = 'whatsapp-cloud-api';

export class LembretesPg implements ProgramarLembretes, PortaLembretes {
  constructor(private readonly c: pg.PoolClient, private readonly agora: () => number = Date.now) {}

  async programar(d: CompromissoDados): Promise<number> {
    const cfg = { ...CONFIG_PADRAO, ...(await lerConfiguracao<Partial<ConfigLembretes>>(this.c, CHAVE_CONFIG, CONFIG_PADRAO)) };
    const plano = planejarLembretes(d.inicio, cfg, this.agora());
    for (const p of plano) {
      const l = await this.c.query(
        `INSERT INTO agenda_lembretes (compromisso_id, tipo, horas_antes, programado_para, referencia_inicio, creator_id)
         VALUES ($1, $2, $3, $4, $5, nucleo_usuario_atual()) RETURNING id`,
        [d.id, p.tipo, p.horas_antes, p.programado_para, d.inicio],
      );
      const id = l.rows[0].id as string;
      const job = await this.c.query('INSERT INTO outbox (tipo, payload, disponivel_em) VALUES ($1, $2, $3) RETURNING id', [TIPO_JOB_LEMBRETE, JSON.stringify({ lembrete_id: id }), p.programado_para]);
      await this.c.query('UPDATE agenda_lembretes SET job_id = $2 WHERE id = $1', [id, job.rows[0].id]);
    }
    return plano.length;
  }

  async cancelar(compromissoId: string): Promise<void> {
    await this.c.query("UPDATE agenda_lembretes SET estado = 'cancelado', processado_em = now() WHERE compromisso_id = $1 AND estado = 'agendado' AND deleted_at IS NULL", [compromissoId]);
  }

  async obter(id: string): Promise<LembreteContexto | null> {
    const r = await this.c.query(
      `SELECT l.id, l.tipo, l.estado, l.referencia_inicio,
         CASE WHEN x.id IS NULL THEN NULL ELSE json_build_object('id', x.id, 'estado', x.estado, 'inicio', x.inicio, 'titulo', x.titulo,
           'recurso_nome', r.nome, 'fuso', r.fuso) END AS compromisso,
         CASE WHEN p.id IS NULL THEN NULL ELSE json_build_object('nome', p.nome, 'telefone', p.telefone) END AS cliente
       FROM agenda_lembretes l
       LEFT JOIN agenda_compromissos x ON x.id = l.compromisso_id AND x.deleted_at IS NULL
       LEFT JOIN agenda_recursos r ON r.id = x.recurso_id
       LEFT JOIN cadastros_parceiros p ON p.id = x.parceiro_id AND p.deleted_at IS NULL
       WHERE l.id = $1 AND l.deleted_at IS NULL`,
      [id],
    );
    const l = r.rows[0];
    return l ? { ...l, referencia_inicio: new Date(l.referencia_inicio).toISOString() } : null;
  }

  async concluir(id: string, estado: EstadoLembrete, extra: { mensagem?: string | null; erro?: string | null }): Promise<void> {
    await this.c.query('UPDATE agenda_lembretes SET estado = $2, mensagem = coalesce($3, mensagem), erro = $4, processado_em = now() WHERE id = $1', [id, estado, extra.mensagem ?? null, extra.erro ?? null]);
  }
}

/**
 * Canal WhatsApp: estado vem de conectores.obter (interface publicada do nucleo, nunca credencial).
 * O nucleo ainda nao publica funcao de envio de mensagem; com o conector ativo o lembrete fica
 * `aguardando_canal` com a mensagem montada, pronto para o envio quando a interface existir.
 */
export class CanalWhatsappPg implements CanalMensagens {
  constructor(private readonly c: pg.PoolClient) {}
  async ativo(): Promise<boolean> {
    return (await conectores.obter(this.c, CONECTOR_WHATSAPP))?.estado === 'ativo';
  }
  async enviar(): Promise<{ enviado: boolean; motivo?: string }> {
    return { enviado: false, motivo: 'Nucleo sem interface publicada de envio pelo WhatsApp' };
  }
}

export async function listarLembretes(c: pg.PoolClient, compromissoId: string) {
  return (await c.query(
    `SELECT id, tipo, horas_antes, programado_para, estado, mensagem, erro, job_id, processado_em, created_at
     FROM agenda_lembretes WHERE compromisso_id = $1 AND deleted_at IS NULL ORDER BY programado_para, created_at`, [compromissoId])).rows;
}
