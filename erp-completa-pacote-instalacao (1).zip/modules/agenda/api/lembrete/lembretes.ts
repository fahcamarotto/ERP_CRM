/**
 * Confirmacao e lembrete pelo WhatsApp (M6.6). Programacao: confirmacao logo ao marcar e lembretes N horas antes
 * (padrao 24 h e 2 h, configuravel em `agenda.lembretes`), cada um um job na outbox com `disponivel_em`.
 * ProcessarLembrete roda no worker: idempotente, descarta lembrete de agendamento cancelado ou reagendado e
 * so envia com o conector whatsapp-cloud-api ativo.
 */
import { erroDe, fail, ok, type Result } from '../compartilhado/result.ts';

export const TIPO_JOB_LEMBRETE = 'agenda.lembrete';
export const CHAVE_CONFIG = 'agenda.lembretes';

export interface ConfigLembretes {
  ativo: boolean;
  confirmacao: boolean;
  horas_antes: number[];
}

export const CONFIG_PADRAO: ConfigLembretes = { ativo: true, confirmacao: true, horas_antes: [24, 2] };

export type EstadoLembrete = 'agendado' | 'enviado' | 'aguardando_canal' | 'sem_conector' | 'sem_telefone' | 'cancelado' | 'erro';

export interface LembreteProgramado {
  tipo: 'confirmacao' | 'lembrete';
  horas_antes: number | null;
  programado_para: string;
}

/** Quais lembretes nascem para um agendamento (regra pura, testada em memoria). */
export function planejarLembretes(inicio: string, cfg: ConfigLembretes, agora: number): LembreteProgramado[] {
  if (!cfg.ativo) return [];
  const t = Date.parse(inicio);
  if (t <= agora) return [];
  const lista: LembreteProgramado[] = [];
  if (cfg.confirmacao) lista.push({ tipo: 'confirmacao', horas_antes: null, programado_para: new Date(agora).toISOString() });
  for (const h of [...new Set(cfg.horas_antes)].filter((x) => Number.isFinite(x) && x > 0 && x <= 168).sort((a, b) => b - a)) {
    const quando = t - h * 3600000;
    if (quando > agora) lista.push({ tipo: 'lembrete', horas_antes: h, programado_para: new Date(quando).toISOString() });
  }
  return lista;
}

export interface LembreteContexto {
  id: string;
  tipo: 'confirmacao' | 'lembrete';
  estado: EstadoLembrete;
  referencia_inicio: string;
  compromisso: { id: string; estado: string; inicio: string; titulo: string | null; recurso_nome: string; fuso: string } | null;
  cliente: { nome: string; telefone: string | null } | null;
}

export interface PortaLembretes {
  obter(id: string): Promise<LembreteContexto | null>;
  concluir(id: string, estado: EstadoLembrete, extra: { mensagem?: string | null; erro?: string | null }): Promise<void>;
}

/** Canal de mensagem (WhatsApp) visto pela Agenda. */
export interface CanalMensagens {
  ativo(): Promise<boolean>;
  enviar(telefone: string, mensagem: string): Promise<{ enviado: boolean; motivo?: string }>;
}

export function montarMensagem(l: LembreteContexto): string {
  const c = l.compromisso!;
  const quando = new Intl.DateTimeFormat('pt-BR', { timeZone: c.fuso, weekday: 'long', day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' }).format(new Date(c.inicio));
  const nome = (l.cliente?.nome ?? '').split(' ')[0] || 'tudo bem';
  const oque = c.titulo ?? 'seu horario';
  return l.tipo === 'confirmacao'
    ? `Ola, ${nome}! Seu agendamento de ${oque} com ${c.recurso_nome} esta marcado para ${quando}. Responda SIM para confirmar.`
    : `Ola, ${nome}! Lembrete: ${oque} com ${c.recurso_nome} em ${quando}. Ate logo!`;
}

export class ProcessarLembrete {
  constructor(private readonly deps: { lembretes: PortaLembretes; canal: CanalMensagens }) {}

  async execute(e: { lembrete_id: string }): Promise<Result<{ estado: EstadoLembrete }>> {
    const l = await this.deps.lembretes.obter(e.lembrete_id);
    if (!l) return fail(erroDe('nao_encontrado', 'Lembrete nao encontrado'));
    if (l.estado !== 'agendado') return ok({ estado: l.estado });
    const c = l.compromisso;
    const fim = async (estado: EstadoLembrete, extra: { mensagem?: string | null; erro?: string | null } = {}) => {
      await this.deps.lembretes.concluir(l.id, estado, extra);
      return ok({ estado });
    };
    if (!c || !['marcado', 'confirmado'].includes(c.estado) || new Date(c.inicio).getTime() !== new Date(l.referencia_inicio).getTime()) return fim('cancelado');
    if (l.tipo === 'confirmacao' && c.estado === 'confirmado') return fim('cancelado');
    if (!l.cliente?.telefone) return fim('sem_telefone');
    const mensagem = montarMensagem(l);
    if (!(await this.deps.canal.ativo())) return fim('sem_conector', { mensagem });
    const r = await this.deps.canal.enviar(l.cliente.telefone, mensagem);
    return r.enviado ? fim('enviado', { mensagem }) : fim('aguardando_canal', { mensagem, erro: r.motivo ?? null });
  }
}
