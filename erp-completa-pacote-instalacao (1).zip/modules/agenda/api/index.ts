/**
 * Plugin do modulo Agenda (M6), registrado sozinho com prefixo /api/v1/agenda.
 * Importar ./tools.ts registra as @tool (MCP e REST) no carregamento.
 */
import type { FastifyPluginAsync } from '@erp/api/sdk';
import './tools.ts';
import { rotasCompromisso } from './compromisso/routes.ts';
import { rotasRecurso } from './recurso/routes.ts';
import { rotasServico } from './servico/routes.ts';

const plugin: FastifyPluginAsync = async (app) => {
  rotasCompromisso(app);
  rotasRecurso(app);
  rotasServico(app);
};

export default plugin;
