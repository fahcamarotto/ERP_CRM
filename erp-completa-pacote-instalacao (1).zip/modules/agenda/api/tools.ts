/**
 * @tool da Agenda (N15): cada chamada vira tool MCP em /mcp e rota REST com o mesmo schema no OpenAPI.
 * Tools de M6.8: agenda.disponibilidade e agenda.agendar; mais agenda.listar, agenda.mudar_estado,
 * agenda.reagendar, agenda.recursos e agenda.servicos.
 */
import { tool } from '@erp/api/sdk';
import { naoEncontrado } from './borda.ts';
import { contextoPg } from './compartilhado/efeitos-pg.ts';
import { exigirOk } from './compartilhado/result.ts';
import type { EstadoCompromisso } from './compromisso/model/compromisso.ts';
import { listarCompromissos, obterCompromisso, type FiltroCompromissos } from './compromisso/query/compromissos.ts';
import type { EntradaAgendar, EntradaDisponibilidade } from './compromisso/use-case/agendar.ts';
import { estadosCompromisso, filtroCadastro, filtroCompromissos, propsAgendar, propsDisponibilidade, propsReagendar, uuid } from './esquemas.ts';
import { casosDeUso } from './fabrica.ts';
import { listarRecursos } from './recurso/query/recursos.ts';
import { listarServicos } from './servico/query/servicos.ts';

const ficha = async (c: Parameters<typeof obterCompromisso>[0], id: string) => (await obterCompromisso(c, id)) ?? Promise.reject(naoEncontrado('Agendamento nao encontrado'));

tool<EntradaDisponibilidade>({
  nome: 'agenda.disponibilidade', modulo: 'agenda', titulo: 'Consultar horarios livres', tipo: 'leitura', permissao: 'agenda.ver',
  descricao: 'Horarios livres por servico e recurso entre duas datas (AAAA-MM-DD, ate 31 dias), dentro do horario de trabalho de cada recurso, sem agendamento nem bloqueio no caminho. Use antes de agenda.agendar.',
  entrada: { type: 'object', required: ['de'], properties: propsDisponibilidade },
  rota: { metodo: 'GET', caminho: '/api/v1/agenda/disponibilidade' },
  executar: async ({ c }, a) => exigirOk(await casosDeUso(c).consultarDisponibilidade.execute(a)),
});

tool<EntradaAgendar>({
  nome: 'agenda.agendar', modulo: 'agenda', titulo: 'Agendar', tipo: 'escrita', permissao: 'agenda.criar',
  descricao: 'Marca um agendamento para um recurso (profissional, sala ou equipamento), com servico, cliente e oportunidade opcionais e recorrencia. Bloqueia conflito e horario fora do expediente, programa confirmacao e lembretes pelo WhatsApp e publica agenda.marcado.',
  entrada: { type: 'object', required: ['recurso_id', 'inicio'], properties: propsAgendar },
  rota: { metodo: 'POST', caminho: '/api/v1/agenda/compromissos' },
  executar: async ({ c, ator, ip }, a) => {
    const { id, ids } = exigirOk(await casosDeUso(c).agendar.execute(contextoPg(c, ator, ip), { ...a, origem: ator.tipo === 'chave_api' ? 'api' : 'manual' }));
    return { ...(await ficha(c, id)), serie_ids: ids };
  },
});

tool<FiltroCompromissos>({
  nome: 'agenda.listar', modulo: 'agenda', titulo: 'Listar agendamentos', tipo: 'leitura', permissao: 'agenda.ver',
  descricao: 'Lista agendamentos por periodo (de e ate), recurso, cliente, estado ou busca, com recurso, servico e cliente.',
  entrada: { type: 'object', properties: filtroCompromissos },
  rota: { metodo: 'GET', caminho: '/api/v1/agenda/compromissos' },
  executar: ({ c }, a) => listarCompromissos(c, a),
});

tool<{ id: string; estado: EstadoCompromisso; motivo?: string | null }>({
  nome: 'agenda.mudar_estado', modulo: 'agenda', titulo: 'Confirmar, concluir ou cancelar agendamento', tipo: 'escrita', permissao: 'agenda.editar',
  descricao: 'Muda o estado do agendamento (marcado, confirmado, realizado, faltou, cancelado) respeitando as transicoes. Publica agenda.confirmado ou agenda.cancelado.',
  entrada: { type: 'object', required: ['id', 'estado'], properties: { id: uuid, estado: { type: 'string', enum: [...estadosCompromisso] }, motivo: { type: ['string', 'null'], maxLength: 500 } } },
  rota: { metodo: 'POST', caminho: '/api/v1/agenda/compromissos/:id/estado' },
  executar: async ({ c, ator, ip }, a) => {
    exigirOk(await casosDeUso(c).mudarEstadoCompromisso.execute(contextoPg(c, ator, ip), a));
    return ficha(c, a.id);
  },
});

tool<{ id: string; inicio: string; fim?: string | null; recurso_id?: string | null; encaixe?: boolean }>({
  nome: 'agenda.reagendar', modulo: 'agenda', titulo: 'Reagendar', tipo: 'escrita', permissao: 'agenda.editar',
  descricao: 'Move o agendamento para outro horario ou recurso, checando conflito e expediente. Confirmado volta a marcado e os lembretes sao refeitos.',
  entrada: { type: 'object', required: ['id', 'inicio'], properties: { id: uuid, ...propsReagendar } },
  rota: { metodo: 'POST', caminho: '/api/v1/agenda/compromissos/:id/reagendar' },
  executar: async ({ c, ator, ip }, a) => {
    exigirOk(await casosDeUso(c).reagendar.execute(contextoPg(c, ator, ip), a));
    return ficha(c, a.id);
  },
});

tool<{ estado?: 'ativo' | 'arquivado' | 'todos'; busca?: string; tipo?: string }>({
  nome: 'agenda.recursos', modulo: 'agenda', titulo: 'Listar profissionais e recursos', tipo: 'leitura', permissao: 'agenda.ver',
  descricao: 'Lista profissionais, salas e equipamentos com horario de trabalho, fuso e numero de agendamentos futuros.',
  entrada: { type: 'object', properties: { ...filtroCadastro, tipo: { type: 'string', enum: ['profissional', 'sala', 'equipamento'] } } },
  rota: { metodo: 'GET', caminho: '/api/v1/agenda/recursos' },
  executar: ({ c }, a) => listarRecursos(c, a),
});

tool<{ estado?: 'ativo' | 'arquivado' | 'todos'; busca?: string; recurso_id?: string }>({
  nome: 'agenda.servicos', modulo: 'agenda', titulo: 'Listar servicos', tipo: 'leitura', permissao: 'agenda.ver',
  descricao: 'Lista servicos com duracao, intervalo, preco e os recursos que atendem; filtra pelos que um recurso atende.',
  entrada: { type: 'object', properties: { ...filtroCadastro, recurso_id: uuid } },
  rota: { metodo: 'GET', caminho: '/api/v1/agenda/servicos' },
  executar: ({ c }, a) => listarServicos(c, a),
});
