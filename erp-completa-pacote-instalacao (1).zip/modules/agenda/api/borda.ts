/** Borda HTTP do modulo: abre a transacao com o escopo da sessao e entrega casos de uso e contexto. */
import type pg from 'pg';
import { atorDe, comEscopo, sessaoDe, type FastifyRequest } from '@erp/api/sdk';
import { contextoPg } from './compartilhado/efeitos-pg.ts';
import type { ContextoCaso } from './compartilhado/efeitos.ts';
import { casosDeUso, type CasosDeUso } from './fabrica.ts';

export function naTransacao<T>(req: FastifyRequest, fn: (casos: CasosDeUso, ctx: ContextoCaso, c: pg.PoolClient) => Promise<T>): Promise<T> {
  return comEscopo(sessaoDe(req), (c) => fn(casosDeUso(c), contextoPg(c, atorDe(req), req.ip ?? null), c));
}

/** Erro 404 lido pelo handler global. */
export function naoEncontrado(mensagem: string): Error {
  return Object.assign(new Error(mensagem), { statusCode: 404, codigo: 'nao_encontrado' });
}
