/**
 * Fuso horario sem dependencia externa (Intl): converte hora local de um recurso em instante UTC e
 * de volta. Usado pela disponibilidade, pela checagem de horario de trabalho e pela recorrencia.
 */
const formatadores = new Map<string, Intl.DateTimeFormat>();

function formatador(fuso: string): Intl.DateTimeFormat {
  let f = formatadores.get(fuso);
  if (!f) {
    f = new Intl.DateTimeFormat('en-US', {
      timeZone: fuso, hourCycle: 'h23', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit', weekday: 'short',
    });
    formatadores.set(fuso, f);
  }
  return f;
}

export function fusoValido(fuso: string): boolean {
  try {
    formatador(fuso);
    return true;
  } catch {
    return false;
  }
}

const DIAS: Record<string, number> = { Sun: 0, Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6 };

/** Partes da hora local de um instante no fuso: data AAAA-MM-DD, dia da semana (0 domingo) e minutos do dia. */
export function partesLocais(fuso: string, instante: Date): { data: string; dia: number; minutos: number } {
  const p = Object.fromEntries(formatador(fuso).formatToParts(instante).map((x) => [x.type, x.value]));
  return { data: `${p.year}-${p.month}-${p.day}`, dia: DIAS[p.weekday!] ?? 0, minutos: Number(p.hour) * 60 + Number(p.minute) };
}

/** Diferenca em minutos entre a hora local do fuso e UTC no instante dado. */
export function deslocamentoMin(fuso: string, instante: Date): number {
  const p = Object.fromEntries(formatador(fuso).formatToParts(instante).map((x) => [x.type, x.value]));
  const comoUtc = Date.UTC(Number(p.year), Number(p.month) - 1, Number(p.day), Number(p.hour), Number(p.minute), Number(p.second));
  return Math.round((comoUtc - Math.floor(instante.getTime() / 1000) * 1000) / 60000);
}

/** Instante UTC de uma data local (AAAA-MM-DD) mais minutos do dia, no fuso do recurso. */
export function localParaInstante(fuso: string, data: string, minutosDoDia: number): Date {
  const [a, m, d] = data.split('-').map(Number);
  const ingenuo = Date.UTC(a!, m! - 1, d!, 0, minutosDoDia);
  const off = deslocamentoMin(fuso, new Date(ingenuo));
  let t = ingenuo - off * 60000;
  const off2 = deslocamentoMin(fuso, new Date(t));
  if (off2 !== off) t = ingenuo - off2 * 60000;
  return new Date(t);
}

/** Soma dias a uma data AAAA-MM-DD (calendario, sem fuso). */
export function somarDias(data: string, n: number): string {
  const [a, m, d] = data.split('-').map(Number);
  return new Date(Date.UTC(a!, m! - 1, d! + n)).toISOString().slice(0, 10);
}

/** Soma meses mantendo o dia; dia inexistente vira o ultimo dia do mes (31/01 + 1 mes = 28 ou 29/02). */
export function somarMeses(data: string, n: number): string {
  const [a, m, d] = data.split('-').map(Number);
  const ultimo = new Date(Date.UTC(a!, m! - 1 + n + 1, 0)).getUTCDate();
  return new Date(Date.UTC(a!, m! - 1 + n, Math.min(d!, ultimo))).toISOString().slice(0, 10);
}

/** Dia da semana (0 domingo) de uma data AAAA-MM-DD. */
export function diaDaSemana(data: string): number {
  const [a, m, d] = data.split('-').map(Number);
  return new Date(Date.UTC(a!, m! - 1, d!)).getUTCDay();
}

export const dataValida = (v: string) => /^\d{4}-\d{2}-\d{2}$/.test(v) && !Number.isNaN(Date.parse(`${v}T00:00:00Z`));
