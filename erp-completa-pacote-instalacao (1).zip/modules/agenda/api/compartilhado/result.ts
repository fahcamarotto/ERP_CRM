/**
 * Padrao Result do modulo: erro e valor, nao excecao (MANUAL secao 5).
 * Cada modulo tem a sua copia deste arquivo (modulo nao importa codigo de outro modulo).
 */
export interface ErroDominio {
  /** Codigo estavel em snake_case: `documento_invalido`, `nao_encontrado`, `conflito`, `transicao_invalida`. */
  codigo: string;
  mensagem: string;
  /** Campo da entrada que causou o erro, quando houver. */
  campo?: string;
  meta?: Record<string, unknown>;
}

export type Result<T> = { ok: true; valor: T } | { ok: false; erros: ErroDominio[] };

export const ok = <T>(valor: T): Result<T> => ({ ok: true, valor });
export const okVazio = (): Result<void> => ({ ok: true, valor: undefined });
export const fail = <T = never>(...erros: ErroDominio[]): Result<T> => ({ ok: false, erros });
export const erroDe = (codigo: string, mensagem: string, campo?: string, meta?: Record<string, unknown>): ErroDominio =>
  ({ codigo, mensagem, ...(campo ? { campo } : {}), ...(meta ? { meta } : {}) });

/** Junta varios Result: falha com todos os erros ou devolve os valores na mesma ordem. */
export function combinar<T extends readonly Result<unknown>[]>(...rs: T): Result<{ [K in keyof T]: T[K] extends Result<infer V> ? V : never }> {
  const erros = rs.flatMap((r) => (r.ok ? [] : r.erros));
  if (erros.length) return fail(...erros);
  return ok(rs.map((r) => (r as { ok: true; valor: unknown }).valor) as never);
}

/** Status HTTP de cada codigo de erro de dominio (o resto vira 400). */
const STATUS: Record<string, number> = { nao_encontrado: 404, conflito: 409, transicao_invalida: 409, sem_permissao: 403 };

export function statusDoErro(e: ErroDominio): number {
  return STATUS[e.codigo] ?? 400;
}

/** Excecao com status e codigo, lida pelo handler global da API e pelo /mcp. Usada so na borda (rota e tool). */
export class FalhaDeCasoDeUso extends Error {
  statusCode: number;
  codigo: string;
  detalhes: ErroDominio[];
  constructor(erros: ErroDominio[]) {
    const primeiro = erros[0] ?? erroDe('entrada_invalida', 'Entrada invalida');
    super(erros.map((e) => e.mensagem).join('; '));
    this.statusCode = statusDoErro(primeiro);
    this.codigo = primeiro.codigo;
    this.detalhes = erros;
  }
}

/** Na borda: devolve o valor ou lanca FalhaDeCasoDeUso. */
export function exigirOk<T>(r: Result<T>): T {
  if (!r.ok) throw new FalhaDeCasoDeUso(r.erros);
  return r.valor;
}
