/** Cursor opaco de paginacao (created_at e id), resposta `{ itens, proximo_cursor }`. */
export function codificarCursor(l: { created_at: Date | string; id: string }): string {
  const d = l.created_at instanceof Date ? l.created_at.toISOString() : new Date(l.created_at).toISOString();
  return Buffer.from(`${d}|${l.id}`).toString('base64url');
}

export function decodificarCursor(c?: string | null): [string, string] | null {
  if (!c) return null;
  const [d, id] = Buffer.from(c, 'base64url').toString('utf8').split('|');
  return d && id && !Number.isNaN(Date.parse(d)) && /^[0-9a-f-]{36}$/.test(id) ? [d, id] : null;
}

export function pagina<T extends { created_at: Date | string; id: string }>(linhas: T[], limite: number): { itens: T[]; proximo_cursor: string | null } {
  const itens = linhas.slice(0, limite);
  const ultimo = itens[itens.length - 1];
  return { itens, proximo_cursor: linhas.length > limite && ultimo ? codificarCursor(ultimo) : null };
}
