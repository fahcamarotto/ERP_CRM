/**
 * Porta de efeitos colaterais de todo caso de uso de escrita: auditoria (N11), evento (N14) e
 * historico no chatter (N10). O adaptador Postgres usa o SDK do nucleo; o teste usa a versao em memoria.
 */
export interface AtorCaso {
  tipo: 'usuario' | 'chave_api' | 'sistema';
  id: string | null;
}

export interface Efeitos {
  auditar(acao: string, entidade: string, entidadeId: string | null, antes?: unknown, depois?: unknown): Promise<void>;
  publicar(evento: string, dados: Record<string, unknown>): Promise<void>;
  historico(entidade: string, registroId: string, antes: Record<string, unknown>, depois: Record<string, unknown>): Promise<void>;
  nota(entidade: string, registroId: string, corpo: string): Promise<void>;
}

/** Contexto que todo caso de uso recebe: ator e efeitos. */
export interface ContextoCaso {
  ator: AtorCaso;
  efeitos: Efeitos;
}
