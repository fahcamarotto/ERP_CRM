/** Adaptador Postgres da porta Efeitos: usa so o SDK puro do nucleo (vale na API, no worker e no seed). */
import type pg from 'pg';
import { auditar, postarNoChatter, publicarEvento, registrarAlteracao } from '@erp/api/sdk/puro';
import type { AtorCaso, ContextoCaso, Efeitos } from './efeitos.ts';

export function efeitosPg(c: pg.PoolClient, ator: AtorCaso, ip: string | null = null): Efeitos {
  return {
    auditar: (acao, entidade, entidadeId, antes, depois) => auditar(c, ator, { acao, entidade, entidadeId, antes, depois, ip }),
    publicar: async (evento, dados) => { await publicarEvento(c, evento, dados); },
    historico: (entidade, registroId, antes, depois) => registrarAlteracao(c, ator, entidade, registroId, antes, depois),
    nota: async (entidade, registroId, corpo) => { await postarNoChatter(c, ator, { entidade, registroId, tipo: 'sistema', corpo }); },
  };
}

export function contextoPg(c: pg.PoolClient, ator: AtorCaso, ip: string | null = null): ContextoCaso {
  return { ator, efeitos: efeitosPg(c, ator, ip) };
}
