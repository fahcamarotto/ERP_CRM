/**
 * Handlers de worker da Agenda (carregados pelo worker do nucleo na partida).
 * `c` ja esta numa transacao do papel erp_worker com o escopo do job (RLS vale).
 */
import type { HandlersModulo } from '@erp/api/sdk/puro';
import { contextoPg } from '../api/compartilhado/efeitos-pg.ts';
import { casosDeUso } from '../api/fabrica.ts';
import { normalizarEventos, TIPO_JOB_ENVIO } from '../api/google/sincronizar.ts';
import { TIPO_JOB_LEMBRETE } from '../api/lembrete/lembretes.ts';

const SISTEMA = { tipo: 'sistema' as const, id: null };

const handlers: HandlersModulo = {
  // M6.6 Confirmacao e lembrete (job com disponivel_em 24 h e 2 h antes, configuravel em agenda.lembretes).
  [TIPO_JOB_LEMBRETE]: async (d, c) => {
    const p = d.payload as { lembrete_id: string };
    const r = await casosDeUso(c).processarLembrete.execute({ lembrete_id: p.lembrete_id });
    // Lembrete inexistente (removido) nao e reprocessado; o resto encerra com o estado gravado na linha.
    if (!r.ok && r.erros[0]?.codigo !== 'nao_encontrado') throw new Error(r.erros.map((e) => e.mensagem).join('; '));
  },

  // M6.5 Saida para o Google Calendar (enfileirado so com conector ativo e calendario no recurso).
  [TIPO_JOB_ENVIO]: async (d, c) => {
    const p = d.payload as { compromisso_id: string };
    const r = await casosDeUso(c).processarEnvioGoogle.execute({ compromisso_id: p.compromisso_id });
    if (!r.ok && r.erros[0]?.codigo !== 'nao_encontrado') throw new Error(r.erros.map((e) => e.mensagem).join('; '));
  },

  // M6.5 Entrada: POST /api/v1/webhooks/google-calendar/<token> (Maton ou OAuth direto), assinatura validada pelo nucleo.
  'webhook.recebido.google-calendar': async (d, c) => {
    const p = d.payload as { recebido_id: string };
    const ev = (await c.query('SELECT payload FROM integracoes_eventos_recebidos WHERE id = $1', [p.recebido_id])).rows[0];
    if (!ev) return;
    const eventos = normalizarEventos(ev.payload);
    if (!eventos.length) {
      await c.query('UPDATE integracoes_eventos_recebidos SET erro = $2 WHERE id = $1', [p.recebido_id, 'Nenhum evento reconhecido no corpo']);
      return;
    }
    const r = await casosDeUso(c).aplicarEventosGoogle.execute(contextoPg(c, SISTEMA), eventos);
    if (r.ok && r.valor.erros) {
      await c.query('UPDATE integracoes_eventos_recebidos SET erro = $2 WHERE id = $1', [p.recebido_id, `${r.valor.erros} evento(s) com erro`]);
    }
  },
};

export default handlers;
