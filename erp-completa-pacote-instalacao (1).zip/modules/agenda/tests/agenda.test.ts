/**
 * P3 do modulo Agenda: objetos de valor, entidades e casos de uso com repositorio em memoria.
 * Rodar: node --import tsx --test modules/agenda/tests/*.test.ts
 */
import assert from 'node:assert/strict';
import { describe, it } from 'node:test';
import { localParaInstante, partesLocais, somarMeses } from '../api/compartilhado/fuso.ts';
import { Compromisso } from '../api/compromisso/model/compromisso.ts';
import { calcularHorarios, dentroDoHorario } from '../api/compromisso/model/disponibilidade.ts';
import { Periodo } from '../api/compromisso/model/periodo.ts';
import { Recorrencia } from '../api/compromisso/model/recorrencia.ts';
import { Agendar, ConsultarDisponibilidade } from '../api/compromisso/use-case/agendar.ts';
import { EditarCompromisso, MudarEstadoCompromisso, Reagendar } from '../api/compromisso/use-case/alterar.ts';
import { AplicarEventosGoogle, normalizarEventos, ProcessarEnvioGoogle } from '../api/google/sincronizar.ts';
import { montarMensagem, planejarLembretes, ProcessarLembrete, type EstadoLembrete, type LembreteContexto } from '../api/lembrete/lembretes.ts';
import { Bloqueio } from '../api/recurso/model/bloqueio.ts';
import { HorarioTrabalho } from '../api/recurso/model/horario.ts';
import { Recurso } from '../api/recurso/model/recurso.ts';
import { AdicionarBloqueio, CriarRecurso, EditarRecurso, MudarEstadoRecurso } from '../api/recurso/use-case/recursos.ts';
import { Servico } from '../api/servico/model/servico.ts';
import { CriarServico, EditarServico } from '../api/servico/use-case/servicos.ts';
import { contexto, montarAgenda, RecursosMemoria, ServicosMemoria } from './memoria.ts';

const FUSO = 'America/Sao_Paulo';
const SEG = '2026-10-05'; // segunda-feira
const em = (hhmm: string, data = SEG) => `${data}T${hhmm}:00-03:00`;
const CLIENTE = '11111111-1111-4111-8111-111111111111';

async function cenario() {
  const m = montarAgenda();
  const ctx = contexto();
  const r = await new CriarRecurso({ repo: m.recursos, usuarios: m.recursos }).execute(ctx, { nome: 'Dra. Paula Reis', tipo: 'profissional', fuso: FUSO });
  assert.ok(r.ok);
  const s = await new CriarServico({ repo: m.servicos, recursos: m.servicos }).execute(ctx, { nome: 'Consulta', duracao_min: 50, intervalo_min: 10, preco: 250, recurso_ids: [r.valor.id] });
  assert.ok(s.ok);
  m.agenda.parceiros.add(CLIENTE);
  return { ...m, ctx, recursoId: r.valor.id, servicoId: s.valor.id, agendar: new Agendar(m.deps) };
}

describe('fuso horario', () => {
  it('converte hora local em instante UTC e de volta', () => {
    const i = localParaInstante(FUSO, SEG, 9 * 60);
    assert.equal(i.toISOString(), '2026-10-05T12:00:00.000Z');
    assert.deepEqual(partesLocais(FUSO, i), { data: SEG, dia: 1, minutos: 540 });
  });
  it('soma meses sem estourar o fim do mes', () => {
    assert.equal(somarMeses('2027-01-31', 1), '2027-02-28');
  });
});

describe('objetos de valor', () => {
  it('HorarioTrabalho valida formato, ordem e sobreposicao', () => {
    assert.ok(HorarioTrabalho.tryCreate([{ dia: 1, inicio: '08:00', fim: '12:00' }]).ok);
    const r = HorarioTrabalho.tryCreate([{ dia: 9, inicio: '08:00', fim: '12:00' }, { dia: 1, inicio: '10:00', fim: '09:00' }, { dia: 2, inicio: '8h', fim: '9h' }]);
    assert.ok(!r.ok);
    assert.equal(r.erros.length, 3);
    assert.ok(!HorarioTrabalho.tryCreate([{ dia: 1, inicio: '08:00', fim: '12:00' }, { dia: 1, inicio: '11:00', fim: '13:00' }]).ok);
    assert.throws(() => HorarioTrabalho.create('x'));
    assert.ok(HorarioTrabalho.padrao().contem(1, 8 * 60, 12 * 60));
    assert.ok(!HorarioTrabalho.padrao().contem(0, 8 * 60, 9 * 60));
  });
  it('Periodo exige fim depois do inicio e no maximo 24 h', () => {
    assert.ok(Periodo.tryCreate(em('09:00'), em('10:00')).ok);
    assert.ok(!Periodo.tryCreate(em('10:00'), em('09:00')).ok);
    assert.ok(!Periodo.tryCreate(em('09:00'), '2026-10-07T09:00:00-03:00').ok);
    assert.ok(!Periodo.tryCreate('ontem', em('09:00')).ok);
    assert.throws(() => Periodo.create('x', 'y'));
  });
  it('Recorrencia gera ocorrencias mantendo a hora local', () => {
    const r = Recorrencia.tryCreate({ frequencia: 'semanal', intervalo: 1, ocorrencias: 3 });
    assert.ok(r.ok && r.valor);
    const lista = r.valor.ocorrencias(Periodo.create(em('09:00'), em('10:00')), FUSO);
    assert.deepEqual(lista.map((p) => p.inicio), ['2026-10-05T12:00:00.000Z', '2026-10-12T12:00:00.000Z', '2026-10-19T12:00:00.000Z']);
    assert.ok(!Recorrencia.tryCreate({ frequencia: 'anual' as never, ocorrencias: 1 }).ok);
    const nenhuma = Recorrencia.tryCreate(null);
    assert.ok(nenhuma.ok && nenhuma.valor === null);
  });
  it('Bloqueio valida periodo', () => {
    assert.ok(Bloqueio.tryCreate({ recurso_id: 'r', inicio: em('09:00'), fim: em('12:00') }).ok);
    assert.ok(!Bloqueio.tryCreate({ recurso_id: 'r', inicio: em('12:00'), fim: em('09:00') }).ok);
  });
});

describe('entidades', () => {
  it('Recurso.tryCreate acumula erros e editar nao muta o original', () => {
    const r = Recurso.tryCreate({ nome: 'x', fuso: 'Lua/Base', tipo: 'sala', usuario_id: '00000000-0000-4000-8000-000000000001', horario: 'x' as never });
    assert.ok(!r.ok);
    assert.deepEqual(r.erros.map((e) => e.codigo).sort(), ['fuso_invalido', 'horario_invalido', 'nome_invalido', 'usuario_invalido']);
    const a = Recurso.create({ nome: 'Sala 1', tipo: 'sala' });
    const b = a.editar({ nome: 'Sala Azul' });
    assert.ok(b.ok);
    assert.equal(a.nome, 'Sala 1');
    assert.equal(b.valor.nome, 'Sala Azul');
    assert.ok(!a.mudarEstado('ativo').ok);
  });
  it('Servico valida duracao em multiplos de 5 e preco', () => {
    const r = Servico.tryCreate({ nome: 'Corte', duracao_min: 7, preco: -1 });
    assert.ok(!r.ok);
    assert.deepEqual(r.erros.map((e) => e.codigo).sort(), ['duracao_invalida', 'preco_invalido']);
    const s = Servico.create({ nome: 'Corte', duracao_min: 30, preco: 49.999 });
    assert.equal(s.paraDados().preco, 50);
    assert.ok(s.atendidoPor('qualquer'));
  });
  it('Compromisso segue a maquina de estados', () => {
    const c = Compromisso.create({ recurso_id: 'r', titulo: 'Teste', inicio: em('09:00'), fim: em('10:00') });
    const conf = c.mudarEstado('confirmado');
    assert.ok(conf.ok);
    assert.equal(c.estado, 'marcado');
    assert.ok(!conf.valor.mudarEstado('marcado').ok);
    const feito = conf.valor.mudarEstado('realizado');
    assert.ok(feito.ok);
    for (const e of ['confirmado', 'cancelado', 'faltou'] as const) {
      const r: ReturnType<Compromisso['mudarEstado']> = feito.valor.mudarEstado(e);
      assert.ok(!r.ok);
      assert.equal(r.erros[0]!.codigo, 'transicao_invalida');
    }
    assert.ok(!feito.valor.reagendar(Periodo.create(em('11:00'), em('12:00'))).ok);
    assert.ok(!feito.valor.editar({ titulo: 'x' }).ok);
    const re = conf.valor.reagendar(Periodo.create(em('11:00'), em('12:00')));
    assert.ok(re.ok);
    assert.equal(re.valor.estado, 'marcado');
  });
  it('Compromisso exige titulo, servico ou cliente', () => {
    const r = Compromisso.tryCreate({ recurso_id: 'r', inicio: em('09:00'), fim: em('10:00') });
    assert.ok(!r.ok);
    assert.equal(r.erros[0]!.codigo, 'titulo_obrigatorio');
  });
});

describe('Recursos e servicos', () => {
  it('CriarRecurso recusa nome repetido e usuario inexistente', async () => {
    const m = montarAgenda();
    const ctx = contexto();
    const criar = new CriarRecurso({ repo: m.recursos, usuarios: m.recursos });
    assert.ok((await criar.execute(ctx, { nome: 'Sala 1', tipo: 'sala' })).ok);
    const dup = await criar.execute(ctx, { nome: 'sala 1', tipo: 'sala' });
    assert.ok(!dup.ok && dup.erros[0]!.codigo === 'conflito');
    const sem = await criar.execute(ctx, { nome: 'Dr. X', usuario_id: '99999999-9999-4999-8999-999999999999' });
    assert.ok(!sem.ok && sem.erros[0]!.codigo === 'usuario_invalido');
    assert.equal(ctx.efeitos.auditoria[0]!.acao, 'recurso.criar');
  });
  it('EditarRecurso grava historico e MudarEstadoRecurso arquiva', async () => {
    const { recursos, ctx, recursoId } = await cenario();
    const r = await new EditarRecurso({ repo: recursos, usuarios: recursos }).execute(ctx, { id: recursoId, horario: [{ dia: 1, inicio: '09:00', fim: '17:00' }] });
    assert.ok(r.ok);
    assert.equal(ctx.efeitos.historicos.at(-1)!.entidade, 'agenda_recursos');
    assert.ok((await new MudarEstadoRecurso({ repo: recursos }).execute(ctx, { id: recursoId, estado: 'arquivado' })).ok);
    const n = await new EditarRecurso({ repo: recursos, usuarios: recursos }).execute(ctx, { id: 'nao-existe', nome: 'x' });
    assert.ok(!n.ok && n.erros[0]!.codigo === 'nao_encontrado');
  });
  it('CriarServico recusa recurso inexistente; EditarServico conflita por nome', async () => {
    const recursos = new RecursosMemoria();
    const servicos = new ServicosMemoria(recursos);
    const ctx = contexto();
    const r = await new CriarServico({ repo: servicos, recursos: servicos }).execute(ctx, { nome: 'Banho', duracao_min: 30, recurso_ids: ['22222222-2222-4222-8222-222222222222'] });
    assert.ok(!r.ok && r.erros[0]!.codigo === 'recurso_invalido');
    const a = await new CriarServico({ repo: servicos, recursos: servicos }).execute(ctx, { nome: 'Banho', duracao_min: 30 });
    const b = await new CriarServico({ repo: servicos, recursos: servicos }).execute(ctx, { nome: 'Tosa', duracao_min: 60 });
    assert.ok(a.ok && b.ok);
    const e = await new EditarServico({ repo: servicos, recursos: servicos }).execute(ctx, { id: b.valor.id, nome: 'BANHO' });
    assert.ok(!e.ok && e.erros[0]!.codigo === 'conflito');
  });
});

describe('Agendar e disponibilidade', () => {
  it('agenda no caminho feliz: fim pela duracao do servico, lembretes, Google e agenda.marcado', async () => {
    const t = await cenario();
    const r = await t.agendar.execute(t.ctx, { recurso_id: t.recursoId, servico_id: t.servicoId, parceiro_id: CLIENTE, inicio: em('09:00') });
    assert.ok(r.ok);
    const d = t.agenda.linhas.get(r.valor.id)!;
    assert.equal(d.fim, '2026-10-05T12:50:00.000Z');
    assert.equal(d.titulo, 'Consulta');
    assert.equal(t.lembretes.programados.length, 1);
    assert.deepEqual(t.agenda.googleSolicitados, [r.valor.id]);
    assert.equal(t.ctx.efeitos.eventos[0]!.evento, 'agenda.marcado');
    assert.equal(t.ctx.efeitos.auditoria.at(-1)!.acao, 'agendamento.criar');
  });
  it('bloqueia conflito com agendamento, com bloqueio e fora do horario', async () => {
    const t = await cenario();
    assert.ok((await t.agendar.execute(t.ctx, { recurso_id: t.recursoId, servico_id: t.servicoId, inicio: em('09:00') })).ok);
    const c1 = await t.agendar.execute(t.ctx, { recurso_id: t.recursoId, titulo: 'Encaixe', inicio: em('09:30'), fim: em('10:00') });
    assert.ok(!c1.ok && c1.erros[0]!.codigo === 'conflito');
    assert.ok((await new AdicionarBloqueio({ repo: t.recursos, bloqueios: t.recursos }).execute(t.ctx, { recurso_id: t.recursoId, inicio: em('14:00'), fim: em('16:00'), motivo: 'Curso' })).ok);
    const c2 = await t.agendar.execute(t.ctx, { recurso_id: t.recursoId, servico_id: t.servicoId, inicio: em('15:00') });
    assert.ok(!c2.ok && c2.erros[0]!.codigo === 'conflito');
    const fora = await t.agendar.execute(t.ctx, { recurso_id: t.recursoId, servico_id: t.servicoId, inicio: em('20:00') });
    assert.ok(!fora.ok && fora.erros[0]!.codigo === 'fora_do_horario');
    assert.ok((await t.agendar.execute(t.ctx, { recurso_id: t.recursoId, servico_id: t.servicoId, inicio: em('20:00'), encaixe: true })).ok);
  });
  it('recusa recurso que nao atende, servico ausente sem fim e cliente invalido', async () => {
    const t = await cenario();
    const outro = await new CriarRecurso({ repo: t.recursos, usuarios: t.recursos }).execute(t.ctx, { nome: 'Sala 2', tipo: 'sala' });
    assert.ok(outro.ok);
    const r1 = await t.agendar.execute(t.ctx, { recurso_id: outro.valor.id, servico_id: t.servicoId, inicio: em('09:00') });
    assert.ok(!r1.ok && r1.erros[0]!.codigo === 'recurso_nao_atende');
    const r2 = await t.agendar.execute(t.ctx, { recurso_id: t.recursoId, titulo: 'Sem fim', inicio: em('09:00') });
    assert.ok(!r2.ok && r2.erros[0]!.codigo === 'fim_obrigatorio');
    const r3 = await t.agendar.execute(t.ctx, { recurso_id: t.recursoId, servico_id: t.servicoId, parceiro_id: '33333333-3333-4333-8333-333333333333', inicio: em('09:00') });
    assert.ok(!r3.ok && r3.erros[0]!.codigo === 'cliente_invalido');
  });
  it('recorrencia cria a serie inteira ou nada (conflito numa ocorrencia)', async () => {
    const t = await cenario();
    assert.ok((await t.agendar.execute(t.ctx, { recurso_id: t.recursoId, titulo: 'Ocupado', inicio: em('09:00', '2026-10-19'), fim: em('10:00', '2026-10-19') })).ok);
    const total = t.agenda.linhas.size;
    const r = await t.agendar.execute(t.ctx, { recurso_id: t.recursoId, servico_id: t.servicoId, inicio: em('09:00'), recorrencia: { frequencia: 'semanal', intervalo: 1, ocorrencias: 3 } });
    assert.ok(!r.ok && r.erros[0]!.codigo === 'conflito');
    assert.equal(t.agenda.linhas.size, total);
    const ok = await t.agendar.execute(t.ctx, { recurso_id: t.recursoId, servico_id: t.servicoId, inicio: em('11:00'), recorrencia: { frequencia: 'semanal', intervalo: 1, ocorrencias: 4 } });
    assert.ok(ok.ok);
    assert.equal(ok.valor.ids.length, 4);
    const series = new Set(ok.valor.ids.map((i) => t.agenda.linhas.get(i)!.serie_id));
    assert.equal(series.size, 1);
    assert.equal(t.ctx.efeitos.eventos.filter((e) => e.evento === 'agenda.marcado').length, 5);
  });
  it('disponibilidade oferece horarios livres respeitando ocupacao, intervalo e expediente', async () => {
    const t = await cenario();
    assert.ok((await t.agendar.execute(t.ctx, { recurso_id: t.recursoId, servico_id: t.servicoId, inicio: em('09:00') })).ok);
    const q = new ConsultarDisponibilidade({ refs: t.agenda, ocupacao: t.agenda, agora: () => Date.parse('2026-10-01T00:00:00Z') });
    const r = await q.execute({ servico_id: t.servicoId, de: SEG });
    assert.ok(r.ok);
    const inicios = r.valor.horarios.map((h) => h.inicio);
    assert.ok(inicios.includes('2026-10-05T11:00:00.000Z'));
    assert.ok(!inicios.includes('2026-10-05T12:00:00.000Z'));
    assert.ok(!inicios.includes('2026-10-05T12:30:00.000Z'));
    assert.ok(inicios.includes('2026-10-05T13:00:00.000Z'));
    assert.ok(!inicios.includes('2026-10-05T14:30:00.000Z'), 'termina depois das 12h locais');
    const dom = await q.execute({ servico_id: t.servicoId, de: '2026-10-04' });
    assert.ok(dom.ok && dom.valor.horarios.length === 0);
    const longo = await q.execute({ servico_id: t.servicoId, de: SEG, ate: '2026-12-31' });
    assert.ok(!longo.ok && longo.erros[0]!.codigo === 'periodo_invalido');
  });
  it('calcularHorarios respeita limite e agora', () => {
    const recurso = { id: 'r', nome: 'R', fuso: FUSO, horario: HorarioTrabalho.padrao() };
    const h = calcularHorarios({ recursos: [recurso], ocupados: [], de: SEG, ate: SEG, duracaoMin: 60, intervaloMin: 0, passoMin: 60, agora: Date.parse(em('10:30')), limite: 3 });
    assert.deepEqual(h.map((x) => x.inicio), ['2026-10-05T14:00:00.000Z', '2026-10-05T16:00:00.000Z', '2026-10-05T17:00:00.000Z']);
    assert.ok(dentroDoHorario(recurso, em('08:00'), em('12:00')));
    assert.ok(!dentroDoHorario(recurso, em('11:30'), em('12:30')));
  });
});

describe('Alterar agendamento', () => {
  it('Reagendar checa conflito, refaz lembretes e volta confirmado para marcado', async () => {
    const t = await cenario();
    const a = await t.agendar.execute(t.ctx, { recurso_id: t.recursoId, servico_id: t.servicoId, inicio: em('09:00') });
    const b = await t.agendar.execute(t.ctx, { recurso_id: t.recursoId, servico_id: t.servicoId, inicio: em('10:00') });
    assert.ok(a.ok && b.ok);
    const mudar = new MudarEstadoCompromisso(t.deps);
    assert.ok((await mudar.execute(t.ctx, { id: a.valor.id, estado: 'confirmado' })).ok);
    assert.equal(t.ctx.efeitos.eventos.at(-1)!.evento, 'agenda.confirmado');
    const re = new Reagendar(t.deps);
    const conflito = await re.execute(t.ctx, { id: a.valor.id, inicio: em('10:30') });
    assert.ok(!conflito.ok && conflito.erros[0]!.codigo === 'conflito');
    assert.ok((await re.execute(t.ctx, { id: a.valor.id, inicio: em('13:00') })).ok);
    const d = t.agenda.linhas.get(a.valor.id)!;
    assert.equal(d.estado, 'marcado');
    assert.equal(d.fim, '2026-10-05T16:50:00.000Z');
    assert.ok(t.lembretes.cancelados.includes(a.valor.id));
    const mesmo = await re.execute(t.ctx, { id: a.valor.id, inicio: em('13:10') });
    assert.ok(mesmo.ok, 'nao conflita consigo mesmo');
    const nada = await re.execute(t.ctx, { id: '44444444-4444-4444-8444-444444444444', inicio: em('13:00') });
    assert.ok(!nada.ok && nada.erros[0]!.codigo === 'nao_encontrado');
  });
  it('cancelar publica agenda.cancelado com motivo e cancela lembretes; transicao invalida falha', async () => {
    const t = await cenario();
    const a = await t.agendar.execute(t.ctx, { recurso_id: t.recursoId, servico_id: t.servicoId, inicio: em('09:00') });
    assert.ok(a.ok);
    const mudar = new MudarEstadoCompromisso(t.deps);
    assert.ok((await mudar.execute(t.ctx, { id: a.valor.id, estado: 'cancelado', motivo: 'Cliente viajou' })).ok);
    const ev = t.ctx.efeitos.eventos.at(-1)!;
    assert.equal(ev.evento, 'agenda.cancelado');
    assert.equal(ev.dados.motivo, 'Cliente viajou');
    assert.equal(t.ctx.efeitos.notas.at(-1)!.entidade, 'agenda_compromissos');
    const inv = await mudar.execute(t.ctx, { id: a.valor.id, estado: 'confirmado' });
    assert.ok(!inv.ok && inv.erros[0]!.codigo === 'transicao_invalida');
    const ed = await new EditarCompromisso(t.deps).execute(t.ctx, { id: a.valor.id, titulo: 'x' });
    assert.ok(!ed.ok && ed.erros[0]!.codigo === 'transicao_invalida');
  });
});

describe('Lembretes (job)', () => {
  it('planeja confirmacao e lembretes 24 h e 2 h no futuro', () => {
    const agora = Date.parse('2026-10-03T12:00:00Z');
    const p = planejarLembretes('2026-10-05T12:00:00Z', { ativo: true, confirmacao: true, horas_antes: [2, 24] }, agora);
    assert.deepEqual(p.map((x) => [x.tipo, x.horas_antes]), [['confirmacao', null], ['lembrete', 24], ['lembrete', 2]]);
    assert.equal(planejarLembretes('2026-10-03T13:00:00Z', { ativo: true, confirmacao: false, horas_antes: [24, 2] }, agora).length, 0);
    assert.equal(planejarLembretes('2026-10-05T12:00:00Z', { ativo: false, confirmacao: true, horas_antes: [24] }, agora).length, 0);
  });

  function porta(l: LembreteContexto) {
    const gravados: { estado: EstadoLembrete; mensagem?: string | null }[] = [];
    return { gravados, lembretes: { obter: async () => l, concluir: async (_: string, estado: EstadoLembrete, e: { mensagem?: string | null }) => { gravados.push({ estado, mensagem: e.mensagem }); } } };
  }
  const base = (): LembreteContexto => ({
    id: 'l1', tipo: 'lembrete', estado: 'agendado', referencia_inicio: '2026-10-05T12:00:00.000Z',
    compromisso: { id: 'c1', estado: 'marcado', inicio: '2026-10-05T12:00:00.000Z', titulo: 'Consulta', recurso_nome: 'Dra. Paula', fuso: FUSO },
    cliente: { nome: 'Ana Souza', telefone: '+5511991234501' },
  });

  it('sem conector ativo grava sem_conector com a mensagem montada', async () => {
    const p = porta(base());
    const r = await new ProcessarLembrete({ lembretes: p.lembretes, canal: { ativo: async () => false, enviar: async () => ({ enviado: true }) } }).execute({ lembrete_id: 'l1' });
    assert.ok(r.ok && r.valor.estado === 'sem_conector');
    assert.match(p.gravados[0]!.mensagem!, /Ana/);
  });
  it('com canal ativo envia; agendamento reagendado ou cancelado descarta; sem telefone registra', async () => {
    const canal = { ativo: async () => true, enviar: async () => ({ enviado: true }) };
    const a = porta(base());
    assert.equal((await new ProcessarLembrete({ lembretes: a.lembretes, canal }).execute({ lembrete_id: 'l1' })).ok && a.gravados[0]!.estado, 'enviado');
    const mov = base();
    mov.compromisso!.inicio = '2026-10-05T15:00:00.000Z';
    const b = porta(mov);
    await new ProcessarLembrete({ lembretes: b.lembretes, canal }).execute({ lembrete_id: 'l1' });
    assert.equal(b.gravados[0]!.estado, 'cancelado');
    const semTel = base();
    semTel.cliente = { nome: 'X', telefone: null };
    const c = porta(semTel);
    await new ProcessarLembrete({ lembretes: c.lembretes, canal }).execute({ lembrete_id: 'l1' });
    assert.equal(c.gravados[0]!.estado, 'sem_telefone');
    const feito = base();
    feito.estado = 'enviado';
    const d = porta(feito);
    const r = await new ProcessarLembrete({ lembretes: d.lembretes, canal }).execute({ lembrete_id: 'l1' });
    assert.ok(r.ok && d.gravados.length === 0, 'idempotente');
  });
  it('mensagem de confirmacao pede SIM', () => {
    assert.match(montarMensagem({ ...base(), tipo: 'confirmacao' }), /Responda SIM/);
  });
});

describe('Google Calendar (job)', () => {
  it('normaliza formato do Google e formato simples', () => {
    const g = normalizarEventos({ calendarId: 'cal@x', items: [{ id: 'e1', summary: 'Ferias', status: 'confirmed', updated: '2026-10-02T10:00:00Z', start: { dateTime: em('09:00') }, end: { dateTime: em('10:00') } }] });
    assert.deepEqual(g[0], { id: 'e1', calendar_id: 'cal@x', titulo: 'Ferias', inicio: em('09:00'), fim: em('10:00'), cancelado: false, atualizado_em: '2026-10-02T10:00:00.000Z' });
    assert.equal(normalizarEventos({ eventos: [{ id: 'e2', cancelado: true }] })[0]!.cancelado, true);
    assert.equal(normalizarEventos('lixo').length, 0);
  });
  it('evento novo vira bloqueio; mais recente vence; cancelado remove', async () => {
    const t = await cenario();
    await new EditarRecurso({ repo: t.recursos, usuarios: t.recursos }).execute(t.ctx, { id: t.recursoId, google_calendar_id: 'paula@clinica' });
    const aplicar = new AplicarEventosGoogle({ sync: t.agenda.sincronizacao(), lembretes: t.lembretes, porItem: (fn) => fn() });
    const ev = { id: 'g1', calendar_id: 'paula@clinica', titulo: 'Congresso', inicio: em('14:00'), fim: em('18:00'), cancelado: false, atualizado_em: new Date(Date.now() + 60000).toISOString() };
    const r1 = await aplicar.execute(t.ctx, [ev, { ...ev, id: 'g2', calendar_id: 'outro@x' }]);
    assert.ok(r1.ok);
    assert.equal(r1.valor.criado, 1);
    assert.equal(r1.valor.ignorado, 1);
    const antigo = await aplicar.execute(t.ctx, [{ ...ev, inicio: em('15:00'), atualizado_em: '2000-01-01T00:00:00.000Z' }]);
    assert.ok(antigo.ok && antigo.valor.ignorado === 1, 'local mais recente vence');
    const cancel = await aplicar.execute(t.ctx, [{ ...ev, cancelado: true, atualizado_em: new Date(Date.now() + 120000).toISOString() }]);
    assert.ok(cancel.ok && cancel.valor.cancelado === 1);
    assert.equal([...t.recursos.bloqueios.values()].filter((b) => !b.deleted).length, 0);
  });
  it('agendamento ligado ao evento muda de horario ou e cancelado pelo Google', async () => {
    const t = await cenario();
    const a = await t.agendar.execute(t.ctx, { recurso_id: t.recursoId, servico_id: t.servicoId, inicio: em('09:00') });
    assert.ok(a.ok);
    const d = t.agenda.linhas.get(a.valor.id)!;
    t.agenda.linhas.set(a.valor.id, { ...d, google_evento_id: 'g9' });
    const aplicar = new AplicarEventosGoogle({ sync: t.agenda.sincronizacao(), lembretes: t.lembretes, porItem: (fn) => fn() });
    const futuro = (s: number) => new Date(Date.now() + s * 1000).toISOString();
    const r = await aplicar.execute(t.ctx, [{ id: 'g9', calendar_id: null, titulo: null, inicio: em('15:00'), fim: em('15:50'), cancelado: false, atualizado_em: futuro(60) }]);
    assert.ok(r.ok && r.valor.atualizado === 1);
    assert.equal(t.agenda.linhas.get(a.valor.id)!.inicio, '2026-10-05T18:00:00.000Z');
    const c = await aplicar.execute(t.ctx, [{ id: 'g9', calendar_id: null, titulo: null, inicio: null, fim: null, cancelado: true, atualizado_em: futuro(120) }]);
    assert.ok(c.ok && c.valor.cancelado === 1);
    assert.equal(t.agenda.linhas.get(a.valor.id)!.estado, 'cancelado');
    assert.equal(t.ctx.efeitos.eventos.at(-1)!.evento, 'agenda.cancelado');
  });
  it('envio ao Google sem conector marca sem_conector; com canal marca sincronizado', async () => {
    const marcas: string[] = [];
    const comp = Compromisso.create({ recurso_id: 'r', titulo: 'X', inicio: em('09:00'), fim: em('10:00') });
    const envio = { dadosEnvio: async () => ({ compromisso: comp, calendar_id: 'cal', titulo: 'X' }), marcar: async (_: string, e: string) => { marcas.push(e); } };
    await new ProcessarEnvioGoogle({ envio, canal: { ativo: async () => false, enviar: async () => ({ enviado: true }) } }).execute({ compromisso_id: comp.id });
    await new ProcessarEnvioGoogle({ envio, canal: { ativo: async () => true, enviar: async () => ({ enviado: true, google_evento_id: 'g1' }) } }).execute({ compromisso_id: comp.id });
    await new ProcessarEnvioGoogle({ envio, canal: { ativo: async () => true, enviar: async () => ({ enviado: false }) } }).execute({ compromisso_id: comp.id });
    assert.deepEqual(marcas, ['sem_conector', 'sincronizado', 'pendente_envio']);
  });
});
