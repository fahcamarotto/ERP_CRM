/**
 * Repositorios em memoria das portas da Agenda e porta Efeitos que grava o que foi publicado.
 * Os casos de uso rodam aqui sem banco, sem Fastify e sem o SDK (P3).
 */
import type { ContextoCaso, Efeitos } from '../api/compartilhado/efeitos.ts';
import { Compromisso, type CompromissoDados } from '../api/compromisso/model/compromisso.ts';
import type { Ocupacao, RecursoAgenda } from '../api/compromisso/model/disponibilidade.ts';
import type { ConsultarOcupacao, ConsultarReferenciasAgenda, GravarCompromisso, ObterCompromisso, ProgramarLembretes, ServicoAgenda, SincronizarGoogle } from '../api/compromisso/model/portas.ts';
import type { PortaSincronizacao } from '../api/google/sincronizar.ts';
import { Bloqueio, type BloqueioDados } from '../api/recurso/model/bloqueio.ts';
import { HorarioTrabalho } from '../api/recurso/model/horario.ts';
import type { BuscarRecursoPorNome, ConsultarUsuarios, GravarBloqueios, GravarRecurso, ObterRecurso } from '../api/recurso/model/portas.ts';
import { Recurso, type RecursoDados } from '../api/recurso/model/recurso.ts';
import type { BuscarServicoPorNome, ConsultarRecursosAtivos, GravarServico, ObterServico } from '../api/servico/model/portas.ts';
import { Servico, type ServicoDados } from '../api/servico/model/servico.ts';

export class EfeitosMemoria implements Efeitos {
  auditoria: { acao: string; entidade: string; id: string | null }[] = [];
  eventos: { evento: string; dados: Record<string, unknown> }[] = [];
  historicos: { entidade: string; id: string; antes: unknown; depois: unknown }[] = [];
  notas: { entidade: string; id: string; corpo: string }[] = [];
  async auditar(acao: string, entidade: string, id: string | null) { this.auditoria.push({ acao, entidade, id }); }
  async publicar(evento: string, dados: Record<string, unknown>) { this.eventos.push({ evento, dados }); }
  async historico(entidade: string, id: string, antes: unknown, depois: unknown) { this.historicos.push({ entidade, id, antes, depois }); }
  async nota(entidade: string, id: string, corpo: string) { this.notas.push({ entidade, id, corpo }); }
}

export function contexto(): ContextoCaso & { efeitos: EfeitosMemoria } {
  return { ator: { tipo: 'usuario', id: '00000000-0000-4000-8000-000000000001' }, efeitos: new EfeitosMemoria() };
}

export class RecursosMemoria implements ObterRecurso, GravarRecurso, BuscarRecursoPorNome, ConsultarUsuarios, GravarBloqueios {
  linhas = new Map<string, RecursoDados>();
  bloqueios = new Map<string, BloqueioDados & { deleted: boolean; atualizado_em: string }>();
  usuarios = new Set<string>(['00000000-0000-4000-8000-000000000001']);
  async obterPorId(id: string) { const d = this.linhas.get(id); return d ? Recurso.reidratar(d) : null; }
  async buscarPorNome(nome: string) { const d = [...this.linhas.values()].find((x) => x.nome.toLowerCase() === nome.toLowerCase()); return d ? Recurso.reidratar(d) : null; }
  async inserir(r: Recurso) { this.linhas.set(r.id, r.paraDados()); }
  async atualizar(r: Recurso) { this.linhas.set(r.id, r.paraDados()); }
  async usuarioExiste(id: string) { return this.usuarios.has(id); }
  async obterBloqueio(id: string) { const b = this.bloqueios.get(id); return b && !b.deleted ? Bloqueio.reidratar(b) : null; }
  async inserirBloqueio(b: Bloqueio) { this.bloqueios.set(b.id, { ...b.paraDados(), deleted: false, atualizado_em: new Date().toISOString() }); }
  async atualizarBloqueio(b: Bloqueio) { this.bloqueios.set(b.id, { ...b.paraDados(), deleted: false, atualizado_em: new Date().toISOString() }); }
  async excluirBloqueio(id: string) { const b = this.bloqueios.get(id); if (b) b.deleted = true; }
}

export class ServicosMemoria implements ObterServico, GravarServico, BuscarServicoPorNome, ConsultarRecursosAtivos {
  linhas = new Map<string, ServicoDados>();
  constructor(private readonly recursos: RecursosMemoria) {}
  async obterPorId(id: string) { const d = this.linhas.get(id); return d ? Servico.reidratar(d) : null; }
  async buscarPorNome(nome: string) { const d = [...this.linhas.values()].find((x) => x.nome.toLowerCase() === nome.toLowerCase()); return d ? Servico.reidratar(d) : null; }
  async inserir(s: Servico) { this.linhas.set(s.id, s.paraDados()); }
  async atualizar(s: Servico) { this.linhas.set(s.id, s.paraDados()); }
  async recursosAtivos(ids: string[]) { return ids.filter((i) => this.recursos.linhas.get(i)?.estado === 'ativo'); }
}

export class LembretesMemoria implements ProgramarLembretes {
  programados: { compromisso_id: string; inicio: string }[] = [];
  cancelados: string[] = [];
  async programar(c: CompromissoDados) { this.programados.push({ compromisso_id: c.id, inicio: c.inicio }); return 3; }
  async cancelar(id: string) { this.cancelados.push(id); }
}

export class AgendaMemoria implements ObterCompromisso, GravarCompromisso, ConsultarReferenciasAgenda, ConsultarOcupacao, SincronizarGoogle {
  linhas = new Map<string, CompromissoDados & { atualizado_em: string }>();
  parceiros = new Set<string>();
  googleSolicitados: string[] = [];
  constructor(readonly recursos: RecursosMemoria, readonly servicos: ServicosMemoria) {}
  async obterPorId(id: string) { const d = this.linhas.get(id); return d ? Compromisso.reidratar(d) : null; }
  async inserir(x: Compromisso) { this.linhas.set(x.id, { ...x.paraDados(), atualizado_em: new Date().toISOString() }); }
  async atualizar(x: Compromisso) { this.linhas.set(x.id, { ...x.paraDados(), atualizado_em: new Date().toISOString() }); }
  private paraAgenda(d: RecursoDados): RecursoAgenda & { estado: 'ativo' | 'arquivado' } {
    return { id: d.id, nome: d.nome, fuso: d.fuso, horario: HorarioTrabalho.create(d.horario), estado: d.estado };
  }
  async recurso(id: string) { const d = this.recursos.linhas.get(id); return d ? this.paraAgenda(d) : null; }
  async recursosAtivos(ids?: string[]) {
    return [...this.recursos.linhas.values()].filter((d) => d.estado === 'ativo' && (!ids || ids.includes(d.id))).map((d) => this.paraAgenda(d));
  }
  async servico(id: string): Promise<ServicoAgenda | null> {
    const d = this.servicos.linhas.get(id);
    return d ? { id: d.id, nome: d.nome, duracao_min: d.duracao_min, intervalo_min: d.intervalo_min, recurso_ids: d.recurso_ids, estado: d.estado } : null;
  }
  async parceiroAtivo(id: string) { return this.parceiros.has(id); }
  async ocupacao(recursoIds: string[], inicio: string, fim: string, ignorarId: string | null = null): Promise<Ocupacao[]> {
    const toca = (a: string, b: string) => Date.parse(a) < Date.parse(fim) && Date.parse(b) > Date.parse(inicio);
    const comp = [...this.linhas.values()]
      .filter((x) => recursoIds.includes(x.recurso_id) && ['marcado', 'confirmado', 'realizado'].includes(x.estado) && x.id !== ignorarId && toca(x.inicio, x.fim))
      .map((x) => ({ tipo: 'compromisso' as const, id: x.id, recurso_id: x.recurso_id, inicio: x.inicio, fim: x.fim }));
    const bloq = [...this.recursos.bloqueios.values()]
      .filter((b) => !b.deleted && recursoIds.includes(b.recurso_id) && toca(b.inicio, b.fim))
      .map((b) => ({ tipo: 'bloqueio' as const, id: b.id, recurso_id: b.recurso_id, inicio: b.inicio, fim: b.fim }));
    return [...comp, ...bloq];
  }
  async solicitar(id: string) { this.googleSolicitados.push(id); return true; }

  /** Porta da sincronizacao com o Google sobre os mesmos mapas. */
  sincronizacao(): PortaSincronizacao {
    return {
      recursoPorCalendario: async (cal) => [...this.recursos.linhas.values()].find((r) => r.google_calendar_id === cal)?.id ?? null,
      compromissoPorGoogle: async (ev) => {
        const d = [...this.linhas.values()].find((x) => x.google_evento_id === ev);
        return d ? { compromisso: Compromisso.reidratar(d), atualizado_em: d.atualizado_em } : null;
      },
      atualizarCompromisso: (x) => this.atualizar(x),
      bloqueioPorGoogle: async (ev) => [...this.recursos.bloqueios.values()].find((b) => !b.deleted && b.google_evento_id === ev) ?? null,
      inserirBloqueio: (b) => this.recursos.inserirBloqueio(b),
      atualizarBloqueio: (b) => this.recursos.atualizarBloqueio(b),
      excluirBloqueio: (id) => this.recursos.excluirBloqueio(id),
    };
  }
}

export function montarAgenda() {
  const recursos = new RecursosMemoria();
  const servicos = new ServicosMemoria(recursos);
  const agenda = new AgendaMemoria(recursos, servicos);
  const lembretes = new LembretesMemoria();
  const deps = { repo: agenda, refs: agenda, ocupacao: agenda, lembretes, google: agenda };
  return { recursos, servicos, agenda, lembretes, deps };
}
