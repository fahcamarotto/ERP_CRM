/**
 * Seed demo da Agenda: profissionais, sala e equipamento com horario de trabalho, servicos com duracao e
 * preco, bloqueio e agendamentos da semana atual e da proxima (passados como realizado ou faltou).
 * Idempotente por id deterministico; grava pelos adaptadores e entidades do modulo. Clientes vem da tabela
 * publicada do Cadastros (seed do Cadastros roda antes). Sem lembretes: o seed nao enfileira jobs.
 */
import { createHash } from 'node:crypto';
import type { SeedModulo } from '@erp/api/sdk/puro';
import { localParaInstante, partesLocais, somarDias } from '../api/compartilhado/fuso.ts';
import { CompromissoRepoPg } from '../api/compromisso/adapter/compromisso-repo-pg.ts';
import { Compromisso, type EstadoCompromisso } from '../api/compromisso/model/compromisso.ts';
import { RecursoRepoPg } from '../api/recurso/adapter/recurso-repo-pg.ts';
import { Bloqueio } from '../api/recurso/model/bloqueio.ts';
import { Recurso, type Cor, type TipoRecurso } from '../api/recurso/model/recurso.ts';
import { ServicoRepoPg } from '../api/servico/adapter/servico-repo-pg.ts';
import { Servico } from '../api/servico/model/servico.ts';

const FUSO = 'America/Sao_Paulo';

/** uuid deterministico a partir de uma chave (mesmo id em toda execucao). */
function idDe(chave: string): string {
  const h = createHash('sha256').update(`agenda-demo:${chave}`).digest('hex');
  return `${h.slice(0, 8)}-${h.slice(8, 12)}-4${h.slice(13, 16)}-a${h.slice(17, 20)}-${h.slice(20, 32)}`;
}

const semana = (ini: string, fim: string, dias = [1, 2, 3, 4, 5]) => dias.map((dia) => ({ dia, inicio: ini, fim }));
const comAlmoco = (dias = [1, 2, 3, 4, 5]) => dias.flatMap((dia) => [{ dia, inicio: '08:00', fim: '12:00' }, { dia, inicio: '13:00', fim: '18:00' }]);

const RECURSOS: { k: string; nome: string; tipo: TipoRecurso; cor: Cor; horario: { dia: number; inicio: string; fim: string }[]; usuario?: boolean; descricao: string }[] = [
  { k: 'paula', nome: 'Dra. Paula Reis', tipo: 'profissional', cor: 'roxo', horario: comAlmoco(), usuario: true, descricao: 'Atendimento individual e retornos.' },
  { k: 'carlos', nome: 'Carlos Mendes', tipo: 'profissional', cor: 'azul', horario: [...semana('09:00', '18:00', [1, 2, 3, 4]), { dia: 6, inicio: '08:00', fim: '12:00' }], descricao: 'Diagnósticos e reuniões com empresas.' },
  { k: 'sala', nome: 'Sala de Reuniões 1', tipo: 'sala', cor: 'ciano', horario: semana('07:00', '21:00'), descricao: 'Capacidade para 8 pessoas, TV e quadro.' },
  { k: 'projetor', nome: 'Projetor Epson', tipo: 'equipamento', cor: 'laranja', horario: semana('08:00', '18:00'), descricao: 'Retirada na recepção.' },
];

const SERVICOS = [
  { k: 'consulta', nome: 'Consulta inicial', duracao: 60, intervalo: 10, preco: 250, cor: 'roxo' as Cor, recursos: ['paula', 'carlos'], descricao: 'Primeiro atendimento com levantamento completo.' },
  { k: 'retorno', nome: 'Retorno', duracao: 30, intervalo: 0, preco: 120, cor: 'sucesso' as Cor, recursos: ['paula'], descricao: 'Acompanhamento de até 30 dias.' },
  { k: 'diagnostico', nome: 'Reunião de diagnóstico', duracao: 90, intervalo: 15, preco: 600, cor: 'azul' as Cor, recursos: ['carlos', 'sala'], descricao: 'Diagnóstico com a equipe do cliente.' },
  { k: 'uso-sala', nome: 'Reserva de sala', duracao: 60, intervalo: 0, preco: null, cor: 'ciano' as Cor, recursos: ['sala'], descricao: 'Reserva interna.' },
];

// dia relativo a segunda-feira da semana atual, hora local, servico, recurso, indice do cliente, estado final
const AGENDA: { k: string; dia: number; hora: string; servico: string; recurso: string; cliente: number | null; estado: EstadoCompromisso; titulo?: string }[] = [
  { k: 'a1', dia: 0, hora: '09:00', servico: 'consulta', recurso: 'paula', cliente: 0, estado: 'realizado' },
  { k: 'a2', dia: 0, hora: '14:00', servico: 'retorno', recurso: 'paula', cliente: 1, estado: 'faltou' },
  { k: 'a3', dia: 1, hora: '10:00', servico: 'diagnostico', recurso: 'carlos', cliente: 2, estado: 'realizado' },
  { k: 'a4', dia: 3, hora: '09:00', servico: 'retorno', recurso: 'paula', cliente: 3, estado: 'confirmado' },
  { k: 'a5', dia: 3, hora: '15:00', servico: 'consulta', recurso: 'carlos', cliente: 4, estado: 'marcado' },
  { k: 'a6', dia: 4, hora: '10:00', servico: 'diagnostico', recurso: 'sala', cliente: 2, estado: 'marcado' },
  { k: 'a7', dia: 4, hora: '16:00', servico: 'consulta', recurso: 'paula', cliente: 5, estado: 'cancelado' },
  { k: 'a8', dia: 7, hora: '08:00', servico: 'consulta', recurso: 'paula', cliente: 1, estado: 'confirmado' },
  { k: 'a9', dia: 7, hora: '11:00', servico: 'retorno', recurso: 'paula', cliente: 0, estado: 'marcado' },
  { k: 'a10', dia: 8, hora: '09:30', servico: 'diagnostico', recurso: 'carlos', cliente: 3, estado: 'marcado' },
  { k: 'a11', dia: 9, hora: '14:00', servico: 'uso-sala', recurso: 'sala', cliente: null, estado: 'marcado', titulo: 'Planejamento trimestral' },
  { k: 'a12', dia: 10, hora: '13:00', servico: 'consulta', recurso: 'paula', cliente: 4, estado: 'marcado' },
];

const CAMINHO: Record<EstadoCompromisso, EstadoCompromisso[]> = {
  marcado: [], confirmado: ['confirmado'], realizado: ['confirmado', 'realizado'], faltou: ['faltou'], cancelado: ['cancelado'],
};

const semear: SeedModulo = async ({ c, usuarioId, log }) => {
  const recursos = new RecursoRepoPg(c);
  const servicos = new ServicoRepoPg(c);
  const agenda = new CompromissoRepoPg(c);
  let novos = 0;

  const rid = new Map<string, string>();
  for (const r of RECURSOS) {
    const id = idDe(`recurso:${r.k}`);
    const existente = (await recursos.obterPorId(id)) ?? (await recursos.buscarPorNome(r.nome));
    if (!existente) {
      await recursos.inserir(Recurso.create({ nome: r.nome, tipo: r.tipo, cor: r.cor, fuso: FUSO, horario: r.horario, usuario_id: r.usuario ? usuarioId : null, descricao: r.descricao }, id));
      novos++;
    }
    rid.set(r.k, existente?.id ?? id);
  }

  const sid = new Map<string, string>();
  for (const s of SERVICOS) {
    const id = idDe(`servico:${s.k}`);
    const existente = (await servicos.obterPorId(id)) ?? (await servicos.buscarPorNome(s.nome));
    if (!existente) {
      await servicos.inserir(Servico.create({ nome: s.nome, duracao_min: s.duracao, intervalo_min: s.intervalo, preco: s.preco, cor: s.cor, descricao: s.descricao, recurso_ids: s.recursos.map((k) => rid.get(k)!) }, id));
      novos++;
    }
    sid.set(s.k, existente?.id ?? id);
  }

  // Segunda-feira da semana atual no fuso dos recursos.
  const hoje = partesLocais(FUSO, new Date());
  const segunda = somarDias(hoje.data, -((hoje.dia + 6) % 7));

  const bloqueioId = idDe('bloqueio:carlos-curso');
  if (!(await recursos.obterBloqueio(bloqueioId))) {
    const dia = somarDias(segunda, 11);
    await recursos.inserirBloqueio(Bloqueio.create({
      recurso_id: rid.get('carlos')!, inicio: localParaInstante(FUSO, dia, 13 * 60).toISOString(), fim: localParaInstante(FUSO, dia, 18 * 60).toISOString(), motivo: 'Curso externo',
    }, bloqueioId));
    novos++;
  }

  // Interface publicada do Cadastros (CONTRATOS 7.1.1): so leitura de clientes ativos.
  const clientes = (await c.query("SELECT id FROM cadastros_parceiros WHERE e_cliente AND estado = 'ativo' AND deleted_at IS NULL ORDER BY created_at, id LIMIT 6")).rows.map((x) => x.id as string);
  let pulados = 0;
  for (const a of AGENDA) {
    const id = idDe(`compromisso:${a.k}`);
    if (await agenda.obterPorId(id)) continue;
    const s = SERVICOS.find((x) => x.k === a.servico)!;
    const dia = somarDias(segunda, a.dia);
    const [h, m] = a.hora.split(':').map(Number);
    const inicio = localParaInstante(FUSO, dia, h! * 60 + m!);
    const base = Compromisso.create({
      recurso_id: rid.get(a.recurso)!, servico_id: sid.get(a.servico)!, parceiro_id: a.cliente === null ? null : clientes[a.cliente % Math.max(clientes.length, 1)] ?? null,
      titulo: a.titulo ?? s.nome, inicio: inicio.toISOString(), fim: new Date(inicio.getTime() + s.duracao * 60000).toISOString(), origem: 'manual',
    }, id);
    const final = CAMINHO[a.estado].reduce((x, e) => { const r = x.mudarEstado(e); if (!r.ok) throw new Error(r.erros[0]!.mensagem); return r.valor; }, base);
    await c.query('SAVEPOINT agenda_seed');
    try {
      await agenda.inserir(final);
      await c.query('RELEASE SAVEPOINT agenda_seed');
      novos++;
    } catch {
      // Horario ja ocupado por dado anterior do proprio workspace: pula sem derrubar o seed.
      await c.query('ROLLBACK TO SAVEPOINT agenda_seed');
      pulados++;
    }
  }
  log(`${novos} registro(s) demo novo(s) (${RECURSOS.length} recursos, ${SERVICOS.length} serviços, 1 bloqueio, ${AGENDA.length} agendamentos${pulados ? `, ${pulados} pulado(s) por conflito` : ''})`);
};

export default semear;
