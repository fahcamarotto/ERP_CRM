/**
 * Handlers de worker do Automacoes (carregados pelo worker do nucleo na partida). `c` ja esta na transacao do papel
 * erp_worker com o escopo do job (RLS vale). Erro lancado = retry do job; envio leva chave de idempotencia.
 */
import type { HandlersModulo } from '@erp/api/sdk/puro';
import { TIPO_JOB_BROADCAST } from '../api/broadcast/broadcast.ts';
import { contextoPg } from '../api/compartilhado/efeitos-pg.ts';
import { casosDeUso } from '../api/fabrica.ts';
import { TIPO_JOB_CONTINUAR } from '../api/motor/adapter/motor-repo-pg.ts';
import { TIPO_JOB_VARRER } from '../api/motor/adapter/varredura-pg.ts';

const SISTEMA = { tipo: 'sistema' as const, id: null };
const TIPO_JOB_SINCRONIZAR = 'automacoes.sincronizar_templates';
/** Mensagem mais velha que isto (importacao de historico) nao dispara automacao. */
const IDADE_MAXIMA_MS = 15 * 60 * 1000;
const falhar = (r: { ok: false; erros: { mensagem: string }[] }): never => { throw new Error(r.erros.map((e) => e.mensagem).join('; ')); };

type Ev<T> = { id?: string; dados?: T };

const handlers: HandlersModulo = {
  // Mensagem recebida no Conversas (WhatsApp ou Instagram): clique em botao, clique de broadcast ou palavra-chave.
  'automacoes:ao:mensagem.recebida': async (d, c) => {
    const dados = (d.payload as Ev<{ id?: string; conversa_id?: string; canal?: string; parceiro_id?: string | null; ocorrida_em?: string }>).dados ?? {};
    if (!dados.id || !dados.conversa_id) return;
    const m = (await c.query(
      `SELECT m.id, m.corpo, m.direcao, m.ocorrida_em, m.id_externo, cv.canal, cv.contato_externo, cv.contato_nome, cv.parceiro_id
       FROM conversas_mensagens m JOIN conversas_conversas cv ON cv.id = m.conversa_id WHERE m.id = $1 AND m.deleted_at IS NULL`,
      [dados.id],
    )).rows[0] as { id: string; corpo: string; direcao: string; ocorrida_em: Date; id_externo: string | null; canal: 'whatsapp' | 'instagram'; contato_externo: string; contato_nome: string; parceiro_id: string | null } | undefined;
    if (!m || m.direcao !== 'entrada' || !m.corpo) return;
    if (Date.now() - new Date(m.ocorrida_em).getTime() > IDADE_MAXIMA_MS) return;
    const r = await casosDeUso(c).motor.aoMensagem(contextoPg(c, SISTEMA), {
      mensagem_id: m.id_externo ?? m.id, canal: m.canal, contato: m.contato_externo, contato_nome: m.contato_nome, conversa_id: dados.conversa_id,
      parceiro_id: m.parceiro_id, texto: m.corpo, ocorrida_em: new Date(m.ocorrida_em).toISOString(),
    });
    if (!r.ok) falhar(r);
  },

  // Comentario em post do Instagram publicado pelo Integracoes (webhook comment.received da Zernio).
  'automacoes:ao:comentario.recebido': async (d, c) => {
    const x = (d.payload as Ev<{ comentario_id?: string; post_id?: string; texto?: string; autor_id?: string; autor_usuario?: string | null; autor_nome?: string | null; conta_usuario?: string | null; ocorrido_em?: string | null }>).dados ?? {};
    if (!x.comentario_id || !x.post_id || !x.autor_id) return;
    // Conta que recebeu o comentario (pelo @ da conta): o gatilho com canal escolhido so casa com a mesma conta.
    const conta = x.conta_usuario
      ? ((await c.query(`SELECT conta_id FROM integracoes_canais WHERE canal = 'instagram' AND estado = 'ativo' AND deleted_at IS NULL AND lower(ltrim(usuario, '@')) = lower(ltrim($1, '@')) LIMIT 1`, [x.conta_usuario])).rows[0]?.conta_id as string | undefined) ?? null
      : null;
    const r = await casosDeUso(c).motor.aoComentario(contextoPg(c, SISTEMA), {
      conta_id: conta,
      comentario_id: x.comentario_id, post_id: x.post_id, texto: x.texto ?? '', autor_id: x.autor_id, autor_usuario: x.autor_usuario ?? null,
      autor_nome: x.autor_nome ?? null, conta_usuario: x.conta_usuario ?? null, ocorrido_em: x.ocorrido_em ?? null,
    });
    if (!r.ok) falhar(r);
  },

  // Status de template da Meta publicado pelo Integracoes (webhook whatsapp.template.status_updated da Zernio).
  'automacoes:ao:whatsapp_template.status_atualizado': async (d, c) => {
    const x = (d.payload as Ev<{ template_id?: string | null; nome?: string; idioma?: string; status?: string; motivo?: string | null }>).dados ?? {};
    if (!x.nome || !x.status) return;
    const r = await casosDeUso(c).aplicarStatusTemplate.execute(contextoPg(c, SISTEMA), { id: x.template_id ?? null, nome: x.nome, idioma: x.idioma ?? 'pt_BR', status: x.status, motivo: x.motivo ?? null });
    if (!r.ok) falhar(r);
  },

  // Fim de uma espera do fluxo.
  [TIPO_JOB_CONTINUAR]: async (d, c) => {
    const r = await casosDeUso(c).motor.continuar(contextoPg(c, SISTEMA), d.payload as { execucao_id: string; no_id: string });
    if (!r.ok) falhar(r);
  },

  // Lote do broadcast (ritmo por minuto).
  [TIPO_JOB_BROADCAST]: async (d, c) => {
    const r = await casosDeUso(c).processarLoteBroadcast.execute(contextoPg(c, SISTEMA), d.payload as { broadcast_id: string });
    if (!r.ok) falhar(r);
  },

  // Varredura de comentarios do Instagram (sem webhook publico).
  [TIPO_JOB_VARRER]: async (_d, c) => {
    const r = await casosDeUso(c).varrerComentarios.execute(contextoPg(c, SISTEMA));
    if (!r.ok) falhar(r);
  },

  // Status dos templates pendentes: reconsulta a cada 5 min enquanto houver pendente.
  [TIPO_JOB_SINCRONIZAR]: async (_d, c) => {
    const casos = casosDeUso(c);
    const r = await casos.sincronizarTemplates.execute(contextoPg(c, SISTEMA));
    if (!r.ok) return falhar(r);
    if (r.valor.pendentes > 0) await casos.fila.agendar(TIPO_JOB_SINCRONIZAR, {}, 300);
  },
};

export default handlers;
