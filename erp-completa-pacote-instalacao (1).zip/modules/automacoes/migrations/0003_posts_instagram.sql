-- Cache dos posts do Instagram de cada conta conectada (Zernio GET /inbox/comments), usado pelo seletor de posts do
-- gatilho de comentario, pelo proxy de miniatura (a URL do Instagram expira e e renovada a cada listagem) e pela
-- varredura no modo geral (comentarios_varridos guarda a contagem ja lida para so reler post com comentario novo).
CREATE TABLE IF NOT EXISTS automacoes_posts_instagram (
  id                   uuid NOT NULL DEFAULT gen_random_uuid(),
  tenant_id            uuid NOT NULL DEFAULT nucleo_tenant_atual(),
  workspace_id         uuid NOT NULL DEFAULT nucleo_workspace_atual(),
  creator_id           uuid,
  conta_id             text NOT NULL CHECK (conta_id ~ '^[A-Za-z0-9_-]{4,128}$'),
  post_id              text NOT NULL CHECK (post_id ~ '^[A-Za-z0-9_-]{1,80}$'),
  legenda              text NOT NULL DEFAULT '',
  tipo                 text NOT NULL DEFAULT 'post' CHECK (tipo IN ('post', 'reels', 'carrossel')),
  publicado_em         timestamptz,
  link                 text,
  miniatura_url        text,
  comentarios          integer,
  curtidas             integer,
  comentarios_varridos integer,
  created_at           timestamptz NOT NULL DEFAULT now(),
  updated_at           timestamptz NOT NULL DEFAULT now(),
  deleted_at           timestamptz,
  PRIMARY KEY (id, tenant_id, workspace_id),
  FOREIGN KEY (workspace_id, tenant_id) REFERENCES workspaces (id, tenant_id)
);
CREATE UNIQUE INDEX IF NOT EXISTS automacoes_posts_instagram_uq ON automacoes_posts_instagram (tenant_id, workspace_id, conta_id, post_id);
CREATE INDEX IF NOT EXISTS automacoes_posts_instagram_lista_idx ON automacoes_posts_instagram (tenant_id, workspace_id, conta_id, publicado_em DESC) WHERE deleted_at IS NULL;
SELECT nucleo_aplicar_padrao('automacoes_posts_instagram');

GRANT SELECT, INSERT, UPDATE ON automacoes_posts_instagram TO erp_app;
GRANT SELECT, INSERT, UPDATE ON automacoes_posts_instagram TO erp_worker;
