-- Corrige o CHECK do nome do template: o Postgres limita repeticao de regex a 255 ({1,512} falhava no INSERT).
ALTER TABLE automacoes_templates DROP CONSTRAINT IF EXISTS automacoes_templates_nome_check;
ALTER TABLE automacoes_templates ADD CONSTRAINT automacoes_templates_nome_check CHECK (nome ~ '^[a-z][a-z0-9_]*$' AND length(nome) <= 512);
