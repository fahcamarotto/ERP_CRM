-- Automacoes (estilo ManyChat) para Instagram e WhatsApp, Broadcast e Templates oficiais da Meta.
-- Toda tabela: tenant_id e workspace_id do contexto da sessao, PK composta, FK composta, RLS por
-- nucleo_aplicar_padrao, exclusao logica (sem DELETE). Idempotente.

-- Fluxo (automacao): grafo de nos e fios salvo como veio do editor (React Flow), validado no caso de uso.
CREATE TABLE IF NOT EXISTS automacoes_fluxos (
  id              uuid NOT NULL DEFAULT gen_random_uuid(),
  tenant_id       uuid NOT NULL DEFAULT nucleo_tenant_atual(),
  workspace_id    uuid NOT NULL DEFAULT nucleo_workspace_atual(),
  creator_id      uuid,
  nome            text NOT NULL CHECK (length(btrim(nome)) BETWEEN 2 AND 120),
  canal           text NOT NULL CHECK (canal IN ('instagram', 'whatsapp')),
  gatilho         text NOT NULL CHECK (gatilho IN ('comentario_post', 'mensagem_palavra', 'botao_clicado', 'broadcast')),
  -- Copia do no de gatilho (post, palavras, correspondencia) para achar o fluxo sem ler o grafo inteiro.
  config_gatilho  jsonb NOT NULL DEFAULT '{}'::jsonb,
  grafo           jsonb NOT NULL DEFAULT '{"nos": [], "fios": []}'::jsonb,
  versao          integer NOT NULL DEFAULT 1 CHECK (versao >= 1),
  estado          text NOT NULL DEFAULT 'rascunho' CHECK (estado IN ('rascunho', 'ativa', 'pausada')),
  ativada_em      timestamptz,
  extras          jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at      timestamptz NOT NULL DEFAULT now(),
  updated_at      timestamptz NOT NULL DEFAULT now(),
  deleted_at      timestamptz,
  PRIMARY KEY (id, tenant_id, workspace_id),
  FOREIGN KEY (workspace_id, tenant_id) REFERENCES workspaces (id, tenant_id),
  FOREIGN KEY (creator_id, tenant_id, workspace_id) REFERENCES usuarios (id, tenant_id, workspace_id)
);
CREATE INDEX IF NOT EXISTS automacoes_fluxos_lista_idx ON automacoes_fluxos (tenant_id, workspace_id, created_at, id) WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS automacoes_fluxos_ativos_idx ON automacoes_fluxos (tenant_id, workspace_id, canal, gatilho) WHERE estado = 'ativa' AND deleted_at IS NULL;
SELECT nucleo_aplicar_padrao('automacoes_fluxos');
DROP TRIGGER IF EXISTS automacoes_fluxos_extras ON automacoes_fluxos;
CREATE TRIGGER automacoes_fluxos_extras BEFORE INSERT OR UPDATE OF extras ON automacoes_fluxos
  FOR EACH ROW EXECUTE FUNCTION nucleo_trigger_extras('automacoes', 'fluxo');

-- Execucao de um fluxo para um contato. chave_evento = idempotencia (id do comentario, da mensagem ou do envio
-- do broadcast): o mesmo evento entregue duas vezes inicia uma execucao so.
CREATE TABLE IF NOT EXISTS automacoes_execucoes (
  id                uuid NOT NULL DEFAULT gen_random_uuid(),
  tenant_id         uuid NOT NULL DEFAULT nucleo_tenant_atual(),
  workspace_id      uuid NOT NULL DEFAULT nucleo_workspace_atual(),
  creator_id        uuid,
  fluxo_id          uuid NOT NULL,
  versao_fluxo      integer NOT NULL DEFAULT 1,
  canal             text NOT NULL CHECK (canal IN ('instagram', 'whatsapp')),
  contato           text NOT NULL CHECK (length(contato) BETWEEN 3 AND 64),
  contato_nome      text,
  conversa_id       uuid,
  parceiro_id       uuid,
  chave_evento      text NOT NULL CHECK (length(chave_evento) BETWEEN 1 AND 200),
  estado            text NOT NULL DEFAULT 'em_andamento'
                    CHECK (estado IN ('em_andamento', 'aguardando_clique', 'aguardando_tempo', 'concluida', 'falhou', 'cancelada')),
  -- Botoes pendentes (titulo normalizado -> no de destino) enquanto aguarda clique.
  aguardando        jsonb NOT NULL DEFAULT '{}'::jsonb,
  -- Comentario, post, texto recebido e variaveis do contato usados pelos nos.
  contexto          jsonb NOT NULL DEFAULT '{}'::jsonb,
  ultima_entrada_em timestamptz,
  erro              text,
  concluida_em      timestamptz,
  created_at        timestamptz NOT NULL DEFAULT now(),
  updated_at        timestamptz NOT NULL DEFAULT now(),
  deleted_at        timestamptz,
  PRIMARY KEY (id, tenant_id, workspace_id),
  FOREIGN KEY (workspace_id, tenant_id) REFERENCES workspaces (id, tenant_id),
  FOREIGN KEY (fluxo_id, tenant_id, workspace_id) REFERENCES automacoes_fluxos (id, tenant_id, workspace_id),
  FOREIGN KEY (parceiro_id, tenant_id, workspace_id) REFERENCES cadastros_parceiros (id, tenant_id, workspace_id)
);
CREATE UNIQUE INDEX IF NOT EXISTS automacoes_execucoes_evento_uq ON automacoes_execucoes (tenant_id, workspace_id, fluxo_id, chave_evento);
CREATE INDEX IF NOT EXISTS automacoes_execucoes_fluxo_idx ON automacoes_execucoes (tenant_id, workspace_id, fluxo_id, created_at DESC);
CREATE INDEX IF NOT EXISTS automacoes_execucoes_aguardando_idx ON automacoes_execucoes (tenant_id, workspace_id, canal, contato)
  WHERE estado = 'aguardando_clique' AND deleted_at IS NULL;
SELECT nucleo_aplicar_padrao('automacoes_execucoes');

-- Historico de execucao: um passo por no visitado (contadores por no saem daqui: disparos e cliques).
CREATE TABLE IF NOT EXISTS automacoes_passos (
  id            uuid NOT NULL DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL DEFAULT nucleo_tenant_atual(),
  workspace_id  uuid NOT NULL DEFAULT nucleo_workspace_atual(),
  creator_id    uuid,
  execucao_id   uuid NOT NULL,
  fluxo_id      uuid NOT NULL,
  no_id         text NOT NULL CHECK (length(no_id) BETWEEN 1 AND 64),
  tipo_no       text NOT NULL,
  -- disparo = no executado; clique = botao clicado que levou a este no.
  evento        text NOT NULL DEFAULT 'disparo' CHECK (evento IN ('disparo', 'clique')),
  resultado     text NOT NULL CHECK (resultado IN ('ok', 'falhou', 'ignorado', 'aguardando')),
  detalhe       jsonb NOT NULL DEFAULT '{}'::jsonb,
  id_externo    text,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now(),
  deleted_at    timestamptz,
  PRIMARY KEY (id, tenant_id, workspace_id),
  FOREIGN KEY (workspace_id, tenant_id) REFERENCES workspaces (id, tenant_id),
  FOREIGN KEY (execucao_id, tenant_id, workspace_id) REFERENCES automacoes_execucoes (id, tenant_id, workspace_id),
  FOREIGN KEY (fluxo_id, tenant_id, workspace_id) REFERENCES automacoes_fluxos (id, tenant_id, workspace_id)
);
CREATE INDEX IF NOT EXISTS automacoes_passos_execucao_idx ON automacoes_passos (tenant_id, workspace_id, execucao_id, created_at);
CREATE INDEX IF NOT EXISTS automacoes_passos_contador_idx ON automacoes_passos (tenant_id, workspace_id, fluxo_id, no_id, evento);
SELECT nucleo_aplicar_padrao('automacoes_passos');

-- Template oficial da Meta (WhatsApp) criado no ERP e submetido pela Zernio.
CREATE TABLE IF NOT EXISTS automacoes_templates (
  id                uuid NOT NULL DEFAULT gen_random_uuid(),
  tenant_id         uuid NOT NULL DEFAULT nucleo_tenant_atual(),
  workspace_id      uuid NOT NULL DEFAULT nucleo_workspace_atual(),
  creator_id        uuid,
  nome              text NOT NULL CONSTRAINT automacoes_templates_nome_check CHECK (nome ~ '^[a-z][a-z0-9_]*$' AND length(nome) <= 512),
  idioma            text NOT NULL DEFAULT 'pt_BR' CHECK (idioma ~ '^[a-z]{2}(_[A-Z]{2})?$'),
  categoria         text NOT NULL DEFAULT 'MARKETING' CHECK (categoria IN ('MARKETING', 'UTILITY', 'AUTHENTICATION')),
  cabecalho         jsonb,
  corpo             text NOT NULL CHECK (length(corpo) BETWEEN 1 AND 1024),
  exemplos          jsonb NOT NULL DEFAULT '[]'::jsonb,
  rodape            text CHECK (rodape IS NULL OR length(rodape) <= 60),
  botoes            jsonb NOT NULL DEFAULT '[]'::jsonb,
  estado            text NOT NULL DEFAULT 'rascunho' CHECK (estado IN ('rascunho', 'pendente', 'aprovado', 'rejeitado', 'pausado', 'desativado')),
  motivo_rejeicao   text,
  id_externo        text,
  submetido_em      timestamptz,
  sincronizado_em   timestamptz,
  extras            jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at        timestamptz NOT NULL DEFAULT now(),
  updated_at        timestamptz NOT NULL DEFAULT now(),
  deleted_at        timestamptz,
  PRIMARY KEY (id, tenant_id, workspace_id),
  FOREIGN KEY (workspace_id, tenant_id) REFERENCES workspaces (id, tenant_id),
  FOREIGN KEY (creator_id, tenant_id, workspace_id) REFERENCES usuarios (id, tenant_id, workspace_id)
);
CREATE UNIQUE INDEX IF NOT EXISTS automacoes_templates_nome_uq ON automacoes_templates (tenant_id, workspace_id, nome, idioma) WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS automacoes_templates_lista_idx ON automacoes_templates (tenant_id, workspace_id, created_at, id) WHERE deleted_at IS NULL;
SELECT nucleo_aplicar_padrao('automacoes_templates');

-- Broadcast: disparo de template aprovado para um segmento de clientes do Cadastros.
CREATE TABLE IF NOT EXISTS automacoes_broadcasts (
  id                uuid NOT NULL DEFAULT gen_random_uuid(),
  tenant_id         uuid NOT NULL DEFAULT nucleo_tenant_atual(),
  workspace_id      uuid NOT NULL DEFAULT nucleo_workspace_atual(),
  creator_id        uuid,
  nome              text NOT NULL CHECK (length(btrim(nome)) BETWEEN 2 AND 120),
  template_id       uuid NOT NULL,
  parametros        jsonb NOT NULL DEFAULT '[]'::jsonb,
  segmento          jsonb NOT NULL DEFAULT '{}'::jsonb,
  agendado_para     timestamptz,
  ritmo_por_minuto  integer NOT NULL DEFAULT 30 CHECK (ritmo_por_minuto BETWEEN 1 AND 600),
  fluxo_id          uuid,
  estado            text NOT NULL DEFAULT 'rascunho' CHECK (estado IN ('rascunho', 'agendado', 'enviando', 'concluido', 'cancelado')),
  total             integer NOT NULL DEFAULT 0,
  iniciado_em       timestamptz,
  concluido_em      timestamptz,
  extras            jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at        timestamptz NOT NULL DEFAULT now(),
  updated_at        timestamptz NOT NULL DEFAULT now(),
  deleted_at        timestamptz,
  PRIMARY KEY (id, tenant_id, workspace_id),
  FOREIGN KEY (workspace_id, tenant_id) REFERENCES workspaces (id, tenant_id),
  FOREIGN KEY (creator_id, tenant_id, workspace_id) REFERENCES usuarios (id, tenant_id, workspace_id),
  FOREIGN KEY (template_id, tenant_id, workspace_id) REFERENCES automacoes_templates (id, tenant_id, workspace_id),
  FOREIGN KEY (fluxo_id, tenant_id, workspace_id) REFERENCES automacoes_fluxos (id, tenant_id, workspace_id)
);
CREATE INDEX IF NOT EXISTS automacoes_broadcasts_lista_idx ON automacoes_broadcasts (tenant_id, workspace_id, created_at, id) WHERE deleted_at IS NULL;
SELECT nucleo_aplicar_padrao('automacoes_broadcasts');

-- Destinatario do broadcast (um por cliente): estado do envio, entrega, leitura e clique.
CREATE TABLE IF NOT EXISTS automacoes_broadcast_envios (
  id              uuid NOT NULL DEFAULT gen_random_uuid(),
  tenant_id       uuid NOT NULL DEFAULT nucleo_tenant_atual(),
  workspace_id    uuid NOT NULL DEFAULT nucleo_workspace_atual(),
  creator_id      uuid,
  broadcast_id    uuid NOT NULL,
  parceiro_id     uuid NOT NULL,
  telefone        text NOT NULL CHECK (telefone ~ '^\+[1-9][0-9]{7,14}$'),
  estado          text NOT NULL DEFAULT 'pendente' CHECK (estado IN ('pendente', 'enviado', 'entregue', 'lido', 'falhou')),
  id_externo      text,
  erro            text,
  enviado_em      timestamptz,
  entregue_em     timestamptz,
  lido_em         timestamptz,
  clicado_em      timestamptz,
  botao           text,
  created_at      timestamptz NOT NULL DEFAULT now(),
  updated_at      timestamptz NOT NULL DEFAULT now(),
  deleted_at      timestamptz,
  PRIMARY KEY (id, tenant_id, workspace_id),
  FOREIGN KEY (workspace_id, tenant_id) REFERENCES workspaces (id, tenant_id),
  FOREIGN KEY (broadcast_id, tenant_id, workspace_id) REFERENCES automacoes_broadcasts (id, tenant_id, workspace_id),
  FOREIGN KEY (parceiro_id, tenant_id, workspace_id) REFERENCES cadastros_parceiros (id, tenant_id, workspace_id)
);
CREATE UNIQUE INDEX IF NOT EXISTS automacoes_broadcast_envios_uq ON automacoes_broadcast_envios (tenant_id, workspace_id, broadcast_id, parceiro_id);
CREATE INDEX IF NOT EXISTS automacoes_broadcast_envios_fila_idx ON automacoes_broadcast_envios (tenant_id, workspace_id, broadcast_id, estado);
CREATE INDEX IF NOT EXISTS automacoes_broadcast_envios_tel_idx ON automacoes_broadcast_envios (tenant_id, workspace_id, telefone, enviado_em DESC);
SELECT nucleo_aplicar_padrao('automacoes_broadcast_envios');

-- Comentarios ja vistos pela varredura do Instagram (idempotencia do gatilho de comentario por polling).
CREATE TABLE IF NOT EXISTS automacoes_comentarios_vistos (
  id              uuid NOT NULL DEFAULT gen_random_uuid(),
  tenant_id       uuid NOT NULL DEFAULT nucleo_tenant_atual(),
  workspace_id    uuid NOT NULL DEFAULT nucleo_workspace_atual(),
  creator_id      uuid,
  comentario_id   text NOT NULL CHECK (length(comentario_id) BETWEEN 1 AND 200),
  post_id         text,
  created_at      timestamptz NOT NULL DEFAULT now(),
  updated_at      timestamptz NOT NULL DEFAULT now(),
  deleted_at      timestamptz,
  PRIMARY KEY (id, tenant_id, workspace_id),
  FOREIGN KEY (workspace_id, tenant_id) REFERENCES workspaces (id, tenant_id)
);
CREATE UNIQUE INDEX IF NOT EXISTS automacoes_comentarios_vistos_uq ON automacoes_comentarios_vistos (tenant_id, workspace_id, comentario_id);
SELECT nucleo_aplicar_padrao('automacoes_comentarios_vistos');

GRANT SELECT, INSERT, UPDATE ON automacoes_fluxos, automacoes_execucoes, automacoes_passos, automacoes_templates,
  automacoes_broadcasts, automacoes_broadcast_envios, automacoes_comentarios_vistos TO erp_app;
GRANT SELECT, INSERT, UPDATE ON automacoes_fluxos, automacoes_execucoes, automacoes_passos, automacoes_templates,
  automacoes_broadcasts, automacoes_broadcast_envios, automacoes_comentarios_vistos TO erp_worker;
