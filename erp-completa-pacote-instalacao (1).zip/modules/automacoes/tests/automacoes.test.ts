/** Provas do modulo Automacoes com adaptadores em memoria: grafo, motor, templates e broadcast. */
import assert from 'node:assert/strict';
import { describe, it } from 'node:test';
import { AgendarBroadcast, Broadcast, CriarBroadcast, ProcessarLoteBroadcast, RegistrarCliqueBroadcast, TIPO_JOB_BROADCAST } from '../api/broadcast/broadcast.ts';
import { Fluxo } from '../api/fluxo/model/fluxo.ts';
import { alvoPosts, gatilhoCasaComentario, validarGrafo, type Grafo } from '../api/fluxo/model/grafo.ts';
import { contaDoGatilho, planejarVarredura, precisaReler } from '../api/motor/model/varredura.ts';
import { CriarFluxo, MudarEstadoFluxo, SalvarFluxo } from '../api/fluxo/use-case/fluxos.ts';
import { Motor } from '../api/motor/use-case/motor.ts';
import { AplicarStatusTemplate, CriarTemplate, SincronizarTemplates, SubmeterTemplate } from '../api/template/casos.ts';
import { TemplateMeta } from '../api/template/template.ts';
import { AgendadorMemoria, ApiTemplatesMemoria, BroadcastMemoria, CanalMemoria, contexto, FilaMemoria, FluxosMemoria, MotorMemoria, TemplatesMemoria } from './memoria.ts';

const grafoIg = (): Grafo => ({
  versao: 1, entrada: 'gatilho',
  nos: [
    { id: 'gatilho', tipo: 'gatilho', posicao: { x: 0, y: 0 }, dados: { tipo: 'comentario_post', post_id: 'post_1', palavras: ['quero'], correspondencia: 'contem', uma_vez_por_contato: true } },
    { id: 'publica', tipo: 'resposta_publica', posicao: { x: 300, y: 0 }, dados: { respostas: ['Te mandei no direct, {{primeiro_nome}}!'] } },
    { id: 'dm', tipo: 'mensagem', posicao: { x: 600, y: 0 }, dados: { texto: 'Oi {{primeiro_nome}}, toca no botao', botoes: [{ tipo: 'resposta', titulo: 'RECEBER ACESSO' }, { tipo: 'resposta', titulo: 'Agora nao', resposta: 'Tudo bem!' }] } },
    { id: 'acesso', tipo: 'mensagem', posicao: { x: 900, y: 0 }, dados: { texto: 'Aqui esta o acesso: https://exemplo.com' } },
    { id: 'tag', tipo: 'acao', posicao: { x: 1200, y: 0 }, dados: { tipo: 'cliente', tags: ['lead-instagram'] } },
  ],
  fios: [
    { id: 'f1', origem: 'gatilho', porta: 'saida', destino: 'publica' },
    { id: 'f2', origem: 'publica', porta: 'saida', destino: 'dm' },
    { id: 'f3', origem: 'dm', porta: 'botao:0', destino: 'acesso' },
    { id: 'f4', origem: 'acesso', porta: 'saida', destino: 'tag' },
  ],
});

async function montar(grafo: Grafo, canal: 'instagram' | 'whatsapp' = 'instagram') {
  const fluxos = new FluxosMemoria();
  const repo = new MotorMemoria(fluxos);
  const canalM = new CanalMemoria();
  const agendador = new AgendadorMemoria();
  const ctx = contexto();
  const c = await new CriarFluxo({ repo: fluxos }).execute(ctx, { nome: 'Automacao teste', canal, grafo });
  assert.ok(c.ok, JSON.stringify(c));
  const at = await new MudarEstadoFluxo({ repo: fluxos }).execute(ctx, { id: c.valor.id, estado: 'ativa' });
  assert.ok(at.ok, JSON.stringify(at));
  let agora = new Date('2026-10-07T12:00:00Z');
  const relogio = { agora: () => agora };
  const motor = new Motor({ repo, canal: canalM, agendador, relogio, aleatorio: () => 0 });
  return { fluxos, repo, canal: canalM, agendador, ctx, motor, id: c.valor.id, avancar: (ms: number) => { agora = new Date(agora.getTime() + ms); return agora; }, agora: () => agora };
}

const comentario = { comentario_id: 'c1', post_id: 'post_1', texto: 'Eu QUERO!', autor_id: '178414000001', autor_usuario: 'ana.silva', autor_nome: 'Ana Silva', conta_usuario: 'minhaconta' };

describe('grafo', () => {
  it('aceita o fluxo do Instagram e acusa porta duplicada, ciclo, botao demais e falta de entrega', () => {
    assert.deepEqual(validarGrafo('instagram', grafoIg()), []);
    const g = grafoIg();
    g.fios.push({ id: 'f5', origem: 'gatilho', porta: 'saida', destino: 'dm' });
    g.fios.push({ id: 'f6', origem: 'tag', porta: 'saida', destino: 'publica' });
    const codigos = validarGrafo('instagram', g).map((e) => e.codigo);
    assert.ok(codigos.includes('fio_invalido'));
    assert.ok(codigos.includes('ciclo'));
    const wa = grafoIg();
    (wa.nos[0]!.dados as { tipo: string }).tipo = 'mensagem_palavra';
    (wa.nos[2]!.dados as { botoes: unknown[] }).botoes = [1, 2, 3, 4].map((i) => ({ tipo: 'resposta', titulo: `b${i}` }));
    const ew = validarGrafo('whatsapp', wa).map((e) => e.codigo);
    assert.ok(ew.includes('botoes_demais') && ew.includes('no_invalido'));
    const semEntrega: Grafo = { versao: 1, entrada: 'gatilho', nos: [grafoIg().nos[0]!], fios: [] };
    assert.ok(validarGrafo('instagram', semEntrega).some((e) => e.codigo === 'sem_entrega'));
  });

  it('rascunho salva grafo incompleto mas nao ativa; versao sobe a cada salvamento', async () => {
    const fluxos = new FluxosMemoria();
    const ctx = contexto();
    const c = await new CriarFluxo({ repo: fluxos }).execute(ctx, { nome: 'Novo', canal: 'instagram' });
    assert.ok(c.ok);
    const g: Grafo = { versao: 1, entrada: 'gatilho', nos: [grafoIg().nos[0]!], fios: [] };
    const s = await new SalvarFluxo({ repo: fluxos }).execute(ctx, { id: c.valor.id, grafo: g });
    assert.ok(s.ok && s.valor.versao === 2);
    const a = await new MudarEstadoFluxo({ repo: fluxos }).execute(ctx, { id: c.valor.id, estado: 'ativa' });
    assert.ok(!a.ok && a.erros.some((e) => e.codigo === 'sem_entrega'));
    const p = await new MudarEstadoFluxo({ repo: fluxos }).execute(ctx, { id: c.valor.id, estado: 'pausada' });
    assert.ok(!p.ok && p.erros[0]!.codigo === 'transicao_invalida');
    assert.throws(() => Fluxo.create({ nome: 'x', canal: 'instagram' }));
  });
});

describe('motor', () => {
  it('comentario no post: resposta publica + DM privada com botoes; idempotente por comentario', async () => {
    const t = await montar(grafoIg());
    const r = await t.motor.aoComentario(t.ctx, comentario);
    assert.ok(r.ok && r.valor.tratado);
    assert.deepEqual(t.canal.chamadas.map((c) => c.tipo), ['resposta_publica', 'resposta_privada']);
    assert.equal(t.canal.chamadas[0]!.dados.texto, 'Te mandei no direct, Ana!');
    assert.equal(t.canal.chamadas[0]!.dados.comentario_id, 'c1');
    const dm = t.canal.chamadas[1]!.dados as { texto: string; botoes: { titulo: string; payload: string }[] };
    assert.equal(dm.texto, 'Oi Ana, toca no botao');
    assert.equal(dm.botoes.length, 2);
    assert.match(dm.botoes[0]!.payload, /^af1:[0-9a-f-]{36}:dm:0$/);
    const exec = [...t.repo.execucoes.values()][0]!;
    assert.equal(exec.estado, 'aguardando_clique');
    // Mesmo comentario de novo (webhook repetido) e outro comentario da mesma pessoa: nada sai.
    const r2 = await t.motor.aoComentario(t.ctx, comentario);
    const r3 = await t.motor.aoComentario(t.ctx, { ...comentario, comentario_id: 'c2' });
    assert.ok(r2.ok && r3.ok && !r3.valor.tratado);
    assert.equal(t.canal.chamadas.length, 2);
    assert.equal(t.repo.execucoes.size, 1);
    // Comentario sem palavra-chave, de outro post ou da propria conta nao dispara.
    for (const ev of [{ ...comentario, comentario_id: 'c3', autor_id: 'x1', texto: 'lindo' }, { ...comentario, comentario_id: 'c4', autor_id: 'x2', post_id: 'outro' }, { ...comentario, comentario_id: 'c5', autor_id: 'x3', autor_usuario: 'minhaconta' }]) {
      const x = await t.motor.aoComentario(t.ctx, ev);
      assert.ok(x.ok && !x.valor.tratado);
    }
  });

  it('clique em botao segue o ramo do botao, conta clique e publica a acao de cliente', async () => {
    const t = await montar(grafoIg());
    await t.motor.aoComentario(t.ctx, comentario);
    t.avancar(60_000);
    const r = await t.motor.aoMensagem(t.ctx, { mensagem_id: 'm1', canal: 'instagram', contato: comentario.autor_id, texto: 'receber acesso' });
    assert.ok(r.ok && r.valor.tratado);
    const ultima = t.canal.chamadas.at(-1)!;
    assert.equal(ultima.tipo, 'mensagem');
    assert.equal((ultima.dados as { texto: string }).texto, 'Aqui esta o acesso: https://exemplo.com');
    assert.ok(t.repo.passos.some((p) => p.evento === 'clique' && p.no_id === 'acesso'));
    const ev = t.ctx.efeitos.eventos.find((e) => e.evento === 'automacao.cliente_solicitado');
    assert.deepEqual(ev?.dados.tags, ['lead-instagram']);
    const exec = [...t.repo.execucoes.values()][0]!;
    assert.equal(exec.estado, 'aguardando_clique', 'o outro botao (Agora nao) segue pendente');
    // Botao sem ramo mas com resposta: responde e conclui.
    await t.motor.aoMensagem(t.ctx, { mensagem_id: 'm2', canal: 'instagram', contato: comentario.autor_id, texto: 'Agora nao' });
    assert.equal((t.canal.chamadas.at(-1)!.dados as { texto: string }).texto, 'Tudo bem!');
    assert.equal([...t.repo.execucoes.values()][0]!.estado, 'concluida');
    assert.ok(t.ctx.efeitos.eventos.some((e) => e.evento === 'automacao.execucao_concluida'));
  });

  it('janela de 24 h: DM depois da janela e ignorada no Instagram; WhatsApp usa template aprovado', async () => {
    const g = grafoIg();
    g.nos.splice(1, 1);
    g.fios = [{ id: 'f1', origem: 'gatilho', porta: 'saida', destino: 'dm' }, { id: 'f3', origem: 'dm', porta: 'botao:0', destino: 'espera' }, { id: 'f4', origem: 'espera', porta: 'saida', destino: 'acesso' }];
    g.nos.push({ id: 'espera', tipo: 'espera', posicao: { x: 0, y: 0 }, dados: { minutos: 1500 } });
    const t = await montar(g);
    await t.motor.aoComentario(t.ctx, comentario);
    await t.motor.aoMensagem(t.ctx, { mensagem_id: 'm1', canal: 'instagram', contato: comentario.autor_id, texto: 'RECEBER ACESSO' });
    const exec = [...t.repo.execucoes.values()][0]!;
    assert.equal(exec.estado, 'aguardando_tempo');
    assert.deepEqual(t.agendador.agendados, [{ execucao_id: exec.id, no_id: 'acesso', minutos: 1500 }]);
    t.avancar(25 * 3600 * 1000);
    await t.motor.continuar(t.ctx, { execucao_id: exec.id, no_id: 'acesso' });
    assert.ok(t.repo.passos.some((p) => p.no_id === 'acesso' && p.resultado === 'ignorado' && p.detalhe?.motivo === 'janela_instagram_fechada'));
    assert.equal(t.canal.chamadas.length, 1);

    const wa: Grafo = {
      versao: 1, entrada: 'gatilho',
      nos: [
        { id: 'gatilho', tipo: 'gatilho', posicao: { x: 0, y: 0 }, dados: { tipo: 'mensagem_palavra', palavras: ['preco'], correspondencia: 'palavra' } },
        { id: 'espera', tipo: 'espera', posicao: { x: 0, y: 0 }, dados: { minutos: 1500 } },
        { id: 'msg', tipo: 'mensagem', posicao: { x: 0, y: 0 }, dados: { texto: 'Lembrete', template_id: 'tpl-1', parametros: ['Ana'] } },
      ],
      fios: [{ id: 'a', origem: 'gatilho', porta: 'saida', destino: 'espera' }, { id: 'b', origem: 'espera', porta: 'saida', destino: 'msg' }],
    };
    const w = await montar(wa, 'whatsapp');
    w.repo.templates.set('tpl-1', { id: 'tpl-1', nome: 'lembrete', idioma: 'pt_BR', estado: 'aprovado', botoes: [] });
    await w.motor.aoMensagem(w.ctx, { mensagem_id: 'w1', canal: 'whatsapp', contato: '+5511999990001', texto: 'qual o preco?', ocorrida_em: w.agora().toISOString() });
    const ex = [...w.repo.execucoes.values()][0]!;
    w.avancar(25 * 3600 * 1000);
    await w.motor.continuar(w.ctx, { execucao_id: ex.id, no_id: 'msg' });
    assert.equal(w.canal.chamadas[0]!.tipo, 'template');
    assert.deepEqual(w.canal.chamadas[0]!.dados.parametros, ['Ana']);
  });

  it('erro permanente do provedor marca falha no historico; erro transitorio volta para a fila e o retry nao duplica', async () => {
    const t = await montar(grafoIg());
    t.canal.falhar = { permanente: false, mensagem: 'rede' };
    await assert.rejects(() => t.motor.aoComentario(t.ctx, comentario));
    // Retry do mesmo evento (o job refaz): a execucao ja criada retoma do no e o comentario nao e reivindicado de novo.
    const r = await t.motor.aoComentario(t.ctx, comentario);
    assert.ok(r.ok && r.valor.tratado);
    assert.deepEqual(t.canal.chamadas.map((c) => c.tipo), ['resposta_publica', 'resposta_privada']);
    const u = await montar(grafoIg());
    u.canal.falhar = { permanente: true, mensagem: 'comentario apagado' };
    await u.motor.aoComentario(u.ctx, comentario);
    assert.ok(u.repo.passos.some((p) => p.resultado === 'falhou' && p.no_id === 'publica'));
    assert.equal(u.canal.chamadas[0]!.tipo, 'resposta_privada', 'falha na resposta publica nao impede a DM');
  });

  it('automacao pausada nao dispara', async () => {
    const t = await montar(grafoIg());
    await new MudarEstadoFluxo({ repo: t.fluxos }).execute(t.ctx, { id: t.id, estado: 'pausada' });
    const r = await t.motor.aoComentario(t.ctx, comentario);
    assert.ok(r.ok && !r.valor.tratado && t.canal.chamadas.length === 0);
  });
});

describe('templates oficiais', () => {
  const entrada = { nome: 'promo_outubro', idioma: 'pt_BR', categoria: 'MARKETING' as const, cabecalho: { tipo: 'texto' as const, texto: 'Oferta' }, corpo: 'Oi {{1}}, sua oferta {{2}} chegou', exemplos: ['Ana', 'VIP'], rodape: 'Responda SAIR para nao receber', botoes: [{ tipo: 'resposta' as const, texto: 'Quero' }, { tipo: 'url' as const, texto: 'Ver site', url: 'https://exemplo.com' }] };

  it('valida variaveis e exemplos e monta os components da Meta', () => {
    assert.ok(!TemplateMeta.tryCreate({ ...entrada, corpo: 'Oi {{2}}' }).ok);
    assert.ok(!TemplateMeta.tryCreate({ ...entrada, exemplos: ['Ana'] }).ok);
    assert.ok(!TemplateMeta.tryCreate({ ...entrada, nome: 'Promo Outubro' }).ok);
    const c = TemplateMeta.create(entrada).componentes();
    assert.deepEqual(c.map((x) => x.type), ['HEADER', 'BODY', 'FOOTER', 'BUTTONS']);
    assert.deepEqual((c[1] as { example: unknown }).example, { body_text: [['Ana', 'VIP']] });
    assert.deepEqual((c[3] as { buttons: unknown[] }).buttons, [{ type: 'QUICK_REPLY', text: 'Quero' }, { type: 'URL', text: 'Ver site', url: 'https://exemplo.com' }]);
  });

  it('submit vai para pendente; sincronizacao traz aprovado e rejeitado com motivo, sem evento repetido', async () => {
    const repo = new TemplatesMemoria();
    const api = new ApiTemplatesMemoria();
    const ctx = contexto();
    const c = await new CriarTemplate({ repo }).execute(ctx, entrada);
    assert.ok(c.ok);
    const dup = await new CriarTemplate({ repo }).execute(ctx, entrada);
    assert.ok(!dup.ok && dup.erros[0]!.codigo === 'conflito');
    const s = await new SubmeterTemplate({ repo, api }).execute(ctx, { id: c.valor.id });
    assert.ok(s.ok && s.valor.estado === 'pendente');
    assert.equal(api.submetidos[0]!.nome, 'promo_outubro');
    assert.equal(repo.m.get(c.valor.id)!.id_externo, 'tpl_1');
    const de2 = await new SubmeterTemplate({ repo, api }).execute(ctx, { id: c.valor.id });
    assert.ok(!de2.ok && de2.erros[0]!.codigo === 'transicao_invalida');
    const aplicar = new AplicarStatusTemplate({ repo });
    const sinc = new SincronizarTemplates({ repo, api, aplicar });
    api.remotos[0]!.status = 'REJECTED';
    api.remotos[0]!.motivo = 'INVALID_FORMAT';
    const r1 = await sinc.execute(ctx);
    assert.ok(r1.ok && r1.valor.alterados === 1);
    assert.equal(repo.m.get(c.valor.id)!.estado, 'rejeitado');
    assert.equal(repo.m.get(c.valor.id)!.motivo_rejeicao, 'INVALID_FORMAT');
    const r2 = await sinc.execute(ctx);
    assert.ok(r2.ok && r2.valor.alterados === 0);
    await new SubmeterTemplate({ repo, api }).execute(ctx, { id: c.valor.id });
    const w = await aplicar.execute(ctx, { id: 'tpl_1', nome: 'promo_outubro', idioma: 'pt_BR', status: 'APPROVED', motivo: 'NONE' });
    assert.ok(w.ok && w.valor.mudou);
    assert.equal(repo.m.get(c.valor.id)!.estado, 'aprovado');
    assert.equal(ctx.efeitos.eventos.filter((e) => e.evento === 'template_meta.status_alterado').length, 2);
  });
});

describe('broadcast', () => {
  it('envia em lotes no ritmo por minuto, reagenda, conclui e registra clique que inicia a automacao', async () => {
    const templates = new TemplatesMemoria();
    const t = TemplateMeta.create({ nome: 'promo', corpo: 'Oi {{1}}', exemplos: ['Ana'], botoes: [{ tipo: 'resposta', texto: 'Quero' }] });
    templates.m.set(t.id, { ...t.paraDados(), estado: 'aprovado' });
    const agora = new Date('2026-10-07T12:00:00Z');
    const repo = new BroadcastMemoria(Broadcast.reidratar, () => agora);
    repo.botoesTemplate = ['Quero'];
    repo.clientes = Array.from({ length: 5 }, (_, i) => ({ parceiro_id: `p${i}`, telefone: `+551199999000${i}`, tags: i < 4 ? ['vip'] : [] }));
    const fila = new FilaMemoria();
    const canal = new CanalMemoria();
    const ctx = contexto();
    const deps = { repo, templates: { template: async (id: string) => templates.ref(id) }, fila };
    const c = await new CriarBroadcast(deps).execute(ctx, { nome: 'Outubro VIP', template_id: t.id, parametros: ['cliente'], segmento: { tag_ids: ['vip'] }, ritmo_por_minuto: 3 });
    assert.ok(c.ok);
    const ag = await new AgendarBroadcast({ ...deps, relogio: () => agora }).execute(ctx, { id: c.valor.id });
    assert.ok(ag.ok);
    assert.deepEqual(fila.jobs[0], { tipo: TIPO_JOB_BROADCAST, payload: { broadcast_id: c.valor.id }, atraso: 0 });
    const lote = new ProcessarLoteBroadcast({ ...deps, canal, relogio: () => agora });
    canal.falhar = null;
    const l1 = await lote.execute(ctx, { broadcast_id: c.valor.id });
    assert.ok(l1.ok && l1.valor.enviados === 3 && l1.valor.restantes);
    assert.equal(fila.jobs.at(-1)!.atraso, 60, 'proximo lote em 60 s (rate limit)');
    assert.equal(repo.m.get(c.valor.id)!.total, 4);
    canal.falhar = { permanente: true, mensagem: '131026 numero sem WhatsApp' };
    const l2 = await lote.execute(ctx, { broadcast_id: c.valor.id });
    assert.ok(l2.ok && l2.valor.falhas === 1 && !l2.valor.restantes);
    assert.equal(repo.m.get(c.valor.id)!.estado, 'concluido');
    const rel = { enviados: repo.envios.filter((e) => e.estado === 'enviado').length, falhas: repo.envios.filter((e) => e.estado === 'falhou').length };
    assert.deepEqual(rel, { enviados: 3, falhas: 1 });
    assert.equal(canal.chamadas.length, 3);
    assert.deepEqual(canal.chamadas[0]!.dados, { telefone: '+5511999990000', nome: 'promo', idioma: 'pt_BR', parametros: ['cliente'], chave: 'broadcast:env_1' });
    assert.ok(ctx.efeitos.eventos.some((e) => e.evento === 'broadcast.concluido'));
    const clique = await new RegistrarCliqueBroadcast({ repo }).registrarClique('+5511999990000', 'quero', agora);
    assert.equal(clique?.envio_id, 'env_1');
    assert.equal(repo.envios[0]!.botao, 'Quero');
    assert.equal(await new RegistrarCliqueBroadcast({ repo }).registrarClique('+5511999990000', 'outra coisa', agora), null);
  });

  it('nao agenda com template sem aprovacao', async () => {
    const templates = new TemplatesMemoria();
    const t = TemplateMeta.create({ nome: 'rasc', corpo: 'Oi' });
    templates.m.set(t.id, t.paraDados());
    const repo = new BroadcastMemoria(Broadcast.reidratar);
    const deps = { repo, templates: { template: async (id: string) => templates.ref(id) }, fila: new FilaMemoria() };
    const ctx = contexto();
    const c = await new CriarBroadcast(deps).execute(ctx, { nome: 'Teste', template_id: t.id });
    assert.ok(c.ok);
    const a = await new AgendarBroadcast(deps).execute(ctx, { id: c.valor.id });
    assert.ok(!a.ok && a.erros[0]!.codigo === 'template_nao_aprovado');
  });
});

describe('gatilho de comentario: geral ou posts especificos', () => {
  const comPosts = (dados: Record<string, unknown>): Grafo => {
    const g = grafoIg();
    g.nos[0]!.dados = { tipo: 'comentario_post', palavras: ['quero'], correspondencia: 'contem', uma_vez_por_contato: false, ...dados } as never;
    return g;
  };

  it('alvoPosts: geral, especificos e legado post_id; validacao exige post no modo especificos', () => {
    assert.deepEqual(alvoPosts({ tipo: 'comentario_post', modo_posts: 'geral', post_ids: ['x'] }), { geral: true, ids: [] });
    assert.deepEqual(alvoPosts({ tipo: 'comentario_post', modo_posts: 'especificos', post_ids: ['a', 'b', 'a'] }), { geral: false, ids: ['a', 'b'] });
    assert.deepEqual(alvoPosts({ tipo: 'comentario_post', post_id: 'velho' }), { geral: false, ids: ['velho'] });
    assert.deepEqual(alvoPosts({ tipo: 'comentario_post' }), { geral: true, ids: [] });
    assert.ok(validarGrafo('instagram', comPosts({ modo_posts: 'especificos', post_ids: [] })).some((e) => e.codigo === 'gatilho_invalido'));
    assert.ok(validarGrafo('instagram', comPosts({ modo_posts: 'especificos', post_ids: ['id com espaco'] })).some((e) => e.codigo === 'gatilho_invalido'));
    assert.deepEqual(validarGrafo('instagram', comPosts({ modo_posts: 'geral' })), []);
  });

  it('gatilhoCasaComentario respeita a conta do canal escolhido', () => {
    const g = { tipo: 'comentario_post' as const, modo_posts: 'geral' as const, conta_id: 'acc_a', conta_usuario: 'conta.a' };
    assert.ok(gatilhoCasaComentario(g, { post_id: 'qualquer', conta_id: 'acc_a' }));
    assert.ok(!gatilhoCasaComentario(g, { post_id: 'qualquer', conta_id: 'acc_b' }));
    assert.ok(!gatilhoCasaComentario(g, { post_id: 'qualquer', conta_usuario: '@conta.b' }));
    assert.ok(gatilhoCasaComentario(g, { post_id: 'qualquer', conta_usuario: '@Conta.A' }));
  });

  it('motor no modo geral dispara em qualquer post da conta, inclusive post novo', async () => {
    const t = await montar(comPosts({ modo_posts: 'geral', conta_id: 'acc_a' }));
    const r1 = await t.motor.aoComentario(t.ctx, { ...comentario, comentario_id: 'g1', post_id: 'post_publicado_depois', conta_id: 'acc_a' });
    const r2 = await t.motor.aoComentario(t.ctx, { ...comentario, comentario_id: 'g2', post_id: 'outro_post', conta_id: 'acc_a', autor_id: '178414000002' });
    const r3 = await t.motor.aoComentario(t.ctx, { ...comentario, comentario_id: 'g3', post_id: 'outro_post', conta_id: 'acc_b', autor_id: '178414000003' });
    assert.ok(r1.ok && r1.valor.tratado && r2.ok && r2.valor.tratado);
    assert.ok(r3.ok && !r3.valor.tratado && r3.valor.motivo === 'sem_automacao');
    assert.equal(t.canal.chamadas[0]!.dados.conta_id, 'acc_a');
  });

  it('motor no modo especificos so dispara nos posts escolhidos', async () => {
    const t = await montar(comPosts({ modo_posts: 'especificos', post_ids: ['p1', 'p2'] }));
    const fora = await t.motor.aoComentario(t.ctx, { ...comentario, comentario_id: 'e0', post_id: 'p3' });
    assert.ok(fora.ok && !fora.valor.tratado && fora.valor.motivo === 'sem_automacao');
    const p1 = await t.motor.aoComentario(t.ctx, { ...comentario, comentario_id: 'e1', post_id: 'p1' });
    const p2 = await t.motor.aoComentario(t.ctx, { ...comentario, comentario_id: 'e2', post_id: 'p2', autor_id: '178414000009' });
    assert.ok(p1.ok && p1.valor.tratado && p2.ok && p2.valor.tratado);
  });

  it('plano da varredura agrupa por conta do canal, com geral e posts especificos', () => {
    const contas = [{ id: 'c-b', conta_id: 'acc_b', usuario: 'b' }, { id: 'c-a', conta_id: 'acc_a', usuario: 'a' }];
    const d1 = new Date('2026-10-01T00:00:00Z');
    const d2 = new Date('2026-10-05T00:00:00Z');
    const planos = planejarVarredura([
      { id: 'f1', config: { tipo: 'comentario_post', modo_posts: 'geral', canal_id: 'c-a' }, ativada_em: d2 },
      { id: 'f2', config: { tipo: 'comentario_post', modo_posts: 'geral', canal_id: 'c-a' }, ativada_em: d1 },
      { id: 'f3', config: { tipo: 'comentario_post', modo_posts: 'especificos', post_ids: ['x'] }, ativada_em: d2 },
      { id: 'f4', config: { tipo: 'comentario_post', modo_posts: 'geral', canal_id: 'desconectado' }, ativada_em: d1 },
    ], contas);
    const a = planos.find((p) => p.conta_id === 'acc_a')!;
    const b = planos.find((p) => p.conta_id === 'acc_b')!;
    assert.equal(planos.length, 2);
    assert.equal(a.geral_desde?.toISOString(), d1.toISOString());
    assert.equal(a.posts.size, 0);
    assert.equal(b.geral_desde, null);
    assert.deepEqual([...b.posts.keys()], ['x']);
    assert.equal(contaDoGatilho({ tipo: 'comentario_post', conta_id: 'acc_a' }, contas)?.id, 'c-a');
    assert.ok(precisaReler(null, null) && precisaReler(3, 2) && !precisaReler(3, 3) && !precisaReler(0, null));
  });
});
