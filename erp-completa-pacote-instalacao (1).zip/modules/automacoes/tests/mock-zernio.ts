/**
 * Mock HTTP local da API Zernio (/api/v1) para as automacoes, no padrao de modules/integracoes/tests/mock-zernio.ts:
 * comentarios (resposta publica, resposta privada, leitura), mensagens na conversa, template para numero e templates
 * do WhatsApp (criar, listar). Nunca envia nada de verdade. Uso avulso: node --import tsx <este arquivo> 4998
 */
import { createServer, type IncomingMessage, type Server } from 'node:http';
import type { AddressInfo } from 'node:net';
import { pathToFileURL } from 'node:url';

export interface PedidoMock { metodo: string; caminho: string; query: Record<string, string>; corpo: Record<string, unknown> | undefined; auth: string | undefined; idem: string | undefined }

export class MockZernioAutomacoes {
  pedidos: PedidoMock[] = [];
  templates: { id: string; name: string; language: string; status: string; category: string; reason?: string }[] = [];
  /** Posts da conta para GET /inbox/comments (lista de posts, mais novos primeiro, cursor = indice). */
  posts: { id: string; accountId: string; content: string; createdTime: string; permalink: string; picture: string; commentCount: number; likeCount: number }[] = [];
  comentarios = new Map<string, { id: string; message: string; from: { id: string; username: string; name: string }; created_time: string }[]>();
  /** Proximas respostas forcadas (status http) para provar a classificacao de erro. */
  forcar: number[] = [];
  private respostasPrivadas = new Set<string>();
  private srv: Server | null = null;
  private n = 0;

  get base() { return `http://127.0.0.1:${(this.srv!.address() as AddressInfo).port}/api/v1`; }
  async iniciar(porta = 0): Promise<this> {
    this.srv = createServer((req, res) => void this.tratar(req).then(([s, b]) => { res.writeHead(s, { 'content-type': 'application/json' }); res.end(JSON.stringify(b)); }));
    await new Promise<void>((ok) => this.srv!.listen(porta, '127.0.0.1', ok));
    return this;
  }
  async parar() { await new Promise((ok) => this.srv?.close(ok)); }
  feitos(metodo: string, prefixo: string) { return this.pedidos.filter((p) => p.metodo === metodo && p.caminho.startsWith(prefixo)); }

  private async tratar(req: IncomingMessage): Promise<[number, unknown]> {
    const u = new URL(req.url ?? '/', 'http://x');
    let bruto = '';
    for await (const c of req) bruto += c;
    const corpo = bruto ? (JSON.parse(bruto) as Record<string, unknown>) : undefined;
    const p: PedidoMock = { metodo: req.method ?? 'GET', caminho: u.pathname.replace(/^\/api\/v1/, ''), query: Object.fromEntries(u.searchParams), corpo, auth: req.headers.authorization, idem: req.headers['idempotency-key'] as string | undefined };
    this.pedidos.push(p);
    if (!p.auth?.startsWith('Bearer ')) return [401, { error: 'sem token' }];
    const f = this.forcar.shift();
    if (f) return [f, { error: f === 400 ? 'Meta code 2 subcode 1545133' : 'indisponivel' }];
    const c = p.caminho;
    const priv = /^\/inbox\/comments\/([^/]+)\/([^/]+)\/private-reply$/.exec(c);
    if (priv && p.metodo === 'POST') {
      if (this.respostasPrivadas.has(priv[2]!)) return [400, { error: 'private reply already sent', details: { privateReplyConsumed: true } }];
      this.respostasPrivadas.add(priv[2]!);
      return [200, { status: 'success', messageId: `mid.P${++this.n}`, commentId: priv[2], platform: 'instagram' }];
    }
    if (c === '/inbox/comments' && p.metodo === 'GET') {
      const daConta = this.posts.filter((x) => x.accountId === p.query.accountId);
      const ini = Number(p.query.cursor ?? 0);
      const fim = ini + Number(p.query.limit ?? 25);
      return [200, { data: daConta.slice(ini, fim), pagination: { hasMore: fim < daConta.length, nextCursor: fim < daConta.length ? String(fim) : null } }];
    }
    if (c === '/analytics' && p.metodo === 'GET') return [200, { posts: [{ mediaType: 'carousel', platforms: [{ platformPostId: 'p_carrossel' }] }] }];
    const com = /^\/inbox\/comments\/([^/]+)$/.exec(c);
    if (com && p.metodo === 'POST') return [200, { success: true, data: { commentId: `rep_${++this.n}`, isReply: true } }];
    if (com && p.metodo === 'GET') return [200, { status: 'success', comments: this.comentarios.get(com[1]!) ?? [], pagination: { hasMore: false } }];
    const msgs = /^\/inbox\/conversations\/([^/]+)\/messages$/.exec(c);
    if (msgs && p.metodo === 'POST') return [200, { success: true, data: { messageId: `mid.M${++this.n}`, conversationId: msgs[1] } }];
    if (c === '/inbox/conversations' && p.metodo === 'POST') return [201, { success: true, data: { messageId: `wamid.T${++this.n}`, conversationId: `conv_${this.n}`, participantId: corpo?.participantId } }];
    if (c === '/whatsapp/templates' && p.metodo === 'POST') {
      const t = { id: `tpl_${++this.n}`, name: String(corpo?.name), language: String(corpo?.language), status: 'PENDING', category: String(corpo?.category) };
      this.templates.push(t);
      return [200, { success: true, template: t }];
    }
    if (c === '/whatsapp/templates' && p.metodo === 'GET') return [200, { templates: this.templates }];
    return [404, { error: `rota do mock inexistente: ${p.metodo} ${c}` }];
  }
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  const m = await new MockZernioAutomacoes().iniciar(Number(process.argv[2] ?? 4998));
  console.log(`mock zernio (automacoes) em ${m.base}`);
}
