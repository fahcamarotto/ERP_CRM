/**
 * Ponta a ponta contra o mock HTTP da Zernio (nada real sai): motor com o adaptador de canal de verdade, templates
 * e broadcast. A conta e a conversa vem de um cliente pg falso (as tabelas do Integracoes nao sao tocadas).
 */
import assert from 'node:assert/strict';
import { after, before, describe, it } from 'node:test';
import type pg from 'pg';
import { AgendarBroadcast, Broadcast, CriarBroadcast, ProcessarLoteBroadcast } from '../api/broadcast/broadcast.ts';
import type { Grafo } from '../api/fluxo/model/grafo.ts';
import { CriarFluxo, MudarEstadoFluxo } from '../api/fluxo/use-case/fluxos.ts';
import { CanalZernioPg } from '../api/motor/adapter/canal-zernio.ts';
import { ErroCanal } from '../api/motor/model/portas.ts';
import { Motor } from '../api/motor/use-case/motor.ts';
import { TemplatesZernio } from '../api/template/adapter.ts';
import { AplicarStatusTemplate, CriarTemplate, SincronizarTemplates, SubmeterTemplate } from '../api/template/casos.ts';
import { ClienteZernioAutomacoes } from '../api/zernio/cliente.ts';
import { AgendadorMemoria, BroadcastMemoria, contexto, FilaMemoria, FluxosMemoria, MotorMemoria, TemplatesMemoria } from './memoria.ts';
import { MockZernioAutomacoes } from './mock-zernio.ts';

const pgFalso = { query: async (sql: string) => ({ rows: sql.includes('integracoes_canais') ? [{ conta_id: 'acc_mock', usuario: 'minhaconta' }] : [{ conversa_externa_id: 'conv_ig_1' }], rowCount: 1 }) } as unknown as pg.PoolClient;

let mock: MockZernioAutomacoes;
let cliente: ClienteZernioAutomacoes;
before(async () => { mock = await new MockZernioAutomacoes().iniciar(); cliente = new ClienteZernioAutomacoes({ base: mock.base, token: 'teste' }); });
after(async () => { await mock.parar(); });

const grafo: Grafo = {
  versao: 1, entrada: 'gatilho',
  nos: [
    { id: 'gatilho', tipo: 'gatilho', posicao: { x: 0, y: 0 }, dados: { tipo: 'comentario_post', post_id: '17900000000000099', palavras: ['quero'] } },
    { id: 'publica', tipo: 'resposta_publica', posicao: { x: 0, y: 0 }, dados: { respostas: ['Te mandei no direct!'] } },
    { id: 'dm', tipo: 'mensagem', posicao: { x: 0, y: 0 }, dados: { texto: 'Toca no botao', botoes: [{ tipo: 'resposta', titulo: 'RECEBER ACESSO' }] } },
    { id: 'link', tipo: 'mensagem', posicao: { x: 0, y: 0 }, dados: { texto: 'Seu acesso', botoes: [{ tipo: 'url', titulo: 'Abrir', url: 'https://exemplo.com' }, { tipo: 'resposta', titulo: 'Ajuda' }] } },
  ],
  fios: [{ id: 'a', origem: 'gatilho', porta: 'saida', destino: 'publica' }, { id: 'b', origem: 'publica', porta: 'saida', destino: 'dm' }, { id: 'c', origem: 'dm', porta: 'botao:0', destino: 'link' }],
};

describe('motor pela Zernio (mock)', () => {
  it('comentario -> POST resposta publica + private-reply com quickReplies; clique -> mensagem na conversa com button template', async () => {
    const fluxos = new FluxosMemoria();
    const repo = new MotorMemoria(fluxos);
    const ctx = contexto();
    const c = await new CriarFluxo({ repo: fluxos }).execute(ctx, { nome: 'IG mock', canal: 'instagram', grafo });
    assert.ok(c.ok);
    await new MudarEstadoFluxo({ repo: fluxos }).execute(ctx, { id: c.valor.id, estado: 'ativa' });
    const motor = new Motor({ repo, canal: new CanalZernioPg(pgFalso, cliente), agendador: new AgendadorMemoria() });
    const r = await motor.aoComentario(ctx, { comentario_id: '1852634789012345679', post_id: '17900000000000099', texto: 'quero!', autor_id: '17841400000000001', autor_usuario: 'ana', autor_nome: 'Ana' });
    assert.ok(r.ok && r.valor.tratado);
    const [pub] = mock.feitos('POST', '/inbox/comments/17900000000000099');
    assert.deepEqual(pub!.corpo, { accountId: 'acc_mock', commentId: '1852634789012345679', message: 'Te mandei no direct!' });
    assert.ok(pub!.idem?.startsWith('pub:'));
    const priv = mock.pedidos.find((p) => p.caminho.endsWith('/private-reply'))!;
    assert.equal(priv.caminho, '/inbox/comments/17900000000000099/1852634789012345679/private-reply');
    const qr = (priv.corpo!.quickReplies as { title: string; payload: string }[]);
    assert.equal(qr[0]!.title, 'RECEBER ACESSO');
    assert.match(qr[0]!.payload, /^af1:/);
    // Clique pelo payload do botao (como chega no metadata do webhook) segue o ramo.
    const r2 = await motor.aoMensagem(ctx, { mensagem_id: 'mid.1', canal: 'instagram', contato: '17841400000000001', texto: qr[0]!.payload });
    assert.ok(r2.ok && r2.valor.tratado);
    const msg = mock.feitos('POST', '/inbox/conversations/conv_ig_1/messages')[0]!;
    assert.deepEqual(msg.corpo, { accountId: 'acc_mock', message: 'Seu acesso', buttons: [{ type: 'url', title: 'Abrir', url: 'https://exemplo.com' }, { type: 'postback', title: 'Ajuda', payload: `af1:${c.valor.id}:link:1` }] });
    // Webhook repetido do mesmo comentario nao chama a Zernio de novo.
    const antes = mock.pedidos.length;
    await motor.aoComentario(ctx, { comentario_id: '1852634789012345679', post_id: '17900000000000099', texto: 'quero!', autor_id: '17841400000000001' });
    assert.equal(mock.pedidos.length, antes);
  });

  it('WhatsApp: botoes de resposta como postback e classificacao de erro (400 permanente, 503 transitorio)', async () => {
    const canal = new CanalZernioPg(pgFalso, cliente);
    await canal.enviarMensagem({ canal: 'whatsapp', contato: '+5511999990001', texto: 'Confirma?', botoes: [{ tipo: 'resposta', titulo: 'Sim', payload: 'p1' }], chave: 'k1' });
    assert.deepEqual(mock.pedidos.at(-1)!.corpo, { accountId: 'acc_mock', message: 'Confirma?', buttons: [{ type: 'postback', title: 'Sim', payload: 'p1' }] });
    mock.forcar.push(400);
    await assert.rejects(() => canal.enviarTemplate({ telefone: '+5511999990001', nome: 'x', idioma: 'pt_BR', parametros: [], chave: 'k2' }), (e) => e instanceof ErroCanal && e.permanente);
    mock.forcar.push(503);
    await assert.rejects(() => canal.enviarTemplate({ telefone: '+5511999990001', nome: 'x', idioma: 'pt_BR', parametros: [], chave: 'k3' }), (e) => e instanceof ErroCanal && !e.permanente);
  });
});

describe('templates e broadcast pela Zernio (mock)', () => {
  it('template submit -> PENDING; sincronizacao -> APPROVED; broadcast envia template no ritmo', async () => {
    const repo = new TemplatesMemoria();
    const api = new TemplatesZernio(pgFalso, cliente);
    const ctx = contexto();
    const t = await new CriarTemplate({ repo }).execute(ctx, { nome: 'oferta_mock', corpo: 'Oi {{1}}', exemplos: ['Ana'], botoes: [{ tipo: 'resposta', texto: 'Quero' }] });
    assert.ok(t.ok);
    const s = await new SubmeterTemplate({ repo, api }).execute(ctx, { id: t.valor.id });
    assert.ok(s.ok && s.valor.estado === 'pendente');
    const post = mock.feitos('POST', '/whatsapp/templates')[0]!;
    assert.equal(post.corpo!.accountId, 'acc_mock');
    assert.deepEqual((post.corpo!.components as { type: string }[]).map((x) => x.type), ['BODY', 'BUTTONS']);
    mock.templates[0]!.status = 'APPROVED';
    const sinc = await new SincronizarTemplates({ repo, api, aplicar: new AplicarStatusTemplate({ repo }) }).execute(ctx);
    assert.ok(sinc.ok && sinc.valor.alterados === 1 && sinc.valor.pendentes === 0);
    assert.equal(repo.m.get(t.valor.id)!.estado, 'aprovado');

    const agora = new Date();
    const bre = new BroadcastMemoria(Broadcast.reidratar, () => agora);
    bre.clientes = [1, 2, 3].map((i) => ({ parceiro_id: `p${i}`, telefone: `+55119999900${i}0`, tags: [] }));
    const fila = new FilaMemoria();
    const deps = { repo: bre, templates: { template: async (id: string) => repo.ref(id) }, fila };
    const b = await new CriarBroadcast(deps).execute(ctx, { nome: 'Mock', template_id: t.valor.id, parametros: ['Ana'], ritmo_por_minuto: 2 });
    assert.ok(b.ok);
    assert.ok((await new AgendarBroadcast(deps).execute(ctx, { id: b.valor.id })).ok);
    const lote = new ProcessarLoteBroadcast({ ...deps, canal: new CanalZernioPg(pgFalso, cliente) });
    const l1 = await lote.execute(ctx, { broadcast_id: b.valor.id });
    assert.ok(l1.ok && l1.valor.enviados === 2 && l1.valor.restantes);
    const l2 = await lote.execute(ctx, { broadcast_id: b.valor.id });
    assert.ok(l2.ok && l2.valor.enviados === 1 && !l2.valor.restantes);
    const envios = mock.feitos('POST', '/inbox/conversations').filter((p) => p.caminho === '/inbox/conversations' && p.corpo?.templateName === 'oferta_mock');
    assert.equal(envios.length, 3);
    assert.deepEqual(envios[0]!.corpo, { accountId: 'acc_mock', participantId: '5511999990010', templateName: 'oferta_mock', templateLanguage: 'pt_BR', templateParams: ['Ana'] });
    assert.equal(bre.m.get(b.valor.id)!.estado, 'concluido');
  });
});

describe('posts do Instagram e varredura no modo geral (mock)', () => {
  const post = (i: number, comentarios: number, conta = 'acc_geral') => ({
    id: `p${i}`, accountId: conta, content: `Legenda do post ${i}`, createdTime: new Date(Date.UTC(2026, 9, 7) - i * 86_400_000).toISOString(),
    permalink: i % 2 ? `https://www.instagram.com/reel/R${i}/` : `https://www.instagram.com/p/P${i}/`, picture: `https://scontent.cdninstagram.com/${i}.jpg`, commentCount: comentarios, likeCount: 1,
  });

  it('postsDaConta: legenda, tipo pelo link, contagem e cursor; carrosseis pelo analytics', async () => {
    mock.posts = [post(1, 2), post(2, 0), post(3, 5)];
    const p1 = await cliente.postsDaConta('acc_geral', { limite: 2 });
    assert.deepEqual(p1.itens.map((x) => [x.id, x.tipo, x.comentarios]), [['p1', 'reels', 2], ['p2', 'post', 0]]);
    assert.equal(p1.proximo_cursor, '2');
    const p2 = await cliente.postsDaConta('acc_geral', { limite: 2, cursor: p1.proximo_cursor });
    assert.deepEqual(p2.itens.map((x) => x.id), ['p3']);
    assert.equal(p2.proximo_cursor, null);
    assert.ok((await cliente.carrosseis('acc_geral', '2026-10-01', '2026-10-08')).has('p_carrossel'));
  });

  it('modo geral varre os posts recentes da conta com limite e so rele post com comentario novo', async () => {
    const { VarrerComentarios, TIPO_JOB_VARRER } = await import('../api/motor/adapter/varredura-pg.ts');
    const { LIMITE_POSTS_GERAL } = await import('../api/motor/model/varredura.ts');
    mock.posts = Array.from({ length: LIMITE_POSTS_GERAL + 10 }, (_, i) => post(i + 1, i < 3 ? 1 : 0));
    mock.posts.push(post(99, 1, 'outra_conta'));
    const ativada = new Date('2026-10-01T00:00:00Z');
    for (const p of mock.posts) mock.comentarios.set(p.id, [
      { id: `${p.id}_novo`, message: 'quero', from: { id: `u_${p.id}`, username: `fa_${p.id}`, name: 'Fa' }, created_time: '2026-10-07T10:00:00Z' },
      { id: `${p.id}_antigo`, message: 'quero', from: { id: `v_${p.id}`, username: `ve_${p.id}`, name: 'Ve' }, created_time: '2026-09-01T10:00:00Z' },
    ]);
    const cache = new Map<string, { comentarios: number | null; varridos: number | null }>();
    const c = { query: async (sql: string, params: unknown[] = []) => {
      if (sql.includes('FROM automacoes_fluxos')) return { rows: [{ id: 'f1', config_gatilho: { tipo: 'comentario_post', modo_posts: 'geral', canal_id: 'canal-1' }, ativada_em: ativada }], rowCount: 1 };
      if (sql.includes('FROM integracoes_canais')) return { rows: [{ id: 'canal-1', conta_id: 'acc_geral', usuario: 'empresa.exemplo' }], rowCount: 1 };
      if (sql.includes('INSERT INTO automacoes_posts_instagram')) {
        for (const x of JSON.parse(params[1] as string) as { id: string; comentarios: number | null }[]) cache.set(x.id, { comentarios: x.comentarios, varridos: cache.get(x.id)?.varridos ?? null });
        return { rows: [], rowCount: 0 };
      }
      if (sql.includes('SELECT post_id, comentarios_varridos')) return { rows: (params[1] as string[]).map((id) => ({ post_id: id, comentarios_varridos: cache.get(id)?.varridos ?? null })), rowCount: 0 };
      if (sql.includes('UPDATE automacoes_posts_instagram')) { cache.get(params[1] as string)!.varridos = params[2] as number; return { rows: [], rowCount: 1 }; }
      throw new Error(`sql inesperado: ${sql}`);
    } } as unknown as pg.PoolClient;
    const eventos: { post_id: string; comentario_id: string; conta_id?: string | null }[] = [];
    const motor = { aoComentario: async (_ctx: unknown, ev: { post_id: string; comentario_id: string; conta_id?: string | null }) => { eventos.push(ev); return { ok: true, valor: { tratado: true, execucoes: [] } }; } } as unknown as Motor;
    const fila = new FilaMemoria();
    const v = new VarrerComentarios({ c, motor, zernio: cliente, fila });
    const antes = mock.feitos('GET', '/inbox/comments/').length;
    const r1 = await v.execute(contexto());
    assert.ok(r1.ok);
    assert.equal(cache.size, LIMITE_POSTS_GERAL);
    assert.deepEqual(eventos.map((e) => e.comentario_id), ['p1_novo', 'p2_novo', 'p3_novo']);
    assert.ok(eventos.every((e) => e.conta_id === 'acc_geral'));
    assert.equal(mock.feitos('GET', '/inbox/comments/').length - antes, 3);
    assert.equal(fila.jobs.at(-1)?.tipo, TIPO_JOB_VARRER);
    // Segunda passada sem comentario novo: nenhum post relido.
    await v.execute(contexto());
    assert.equal(mock.feitos('GET', '/inbox/comments/').length - antes, 3);
    // Post 2 ganha comentario: so ele e relido.
    mock.posts[1]!.commentCount = 2;
    await v.execute(contexto());
    assert.equal(mock.feitos('GET', '/inbox/comments/').length - antes, 4);
  });
});
