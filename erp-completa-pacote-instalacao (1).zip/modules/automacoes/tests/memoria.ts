/** Adaptadores em memoria das portas do modulo (sem SDK, pg ou Fastify) para os testes dos casos de uso. */
import type { ContextoCaso, Efeitos } from '../api/compartilhado/efeitos.ts';
import type { Broadcast, Destinatario, EnvioPendente, RepoBroadcast, Segmento } from '../api/broadcast/broadcast.ts';
import { Fluxo, type DadosFluxo } from '../api/fluxo/model/fluxo.ts';
import type { CanalFluxo, TipoGatilho } from '../api/fluxo/model/grafo.ts';
import type { RepoFluxos } from '../api/fluxo/use-case/fluxos.ts';
import { ErroCanal, type Agendador, type CanalEnvio, type DadosExecucao, type MensagemSaida, type Passo, type PerfilContato, type RepoMotor, type TemplateRef } from '../api/motor/model/portas.ts';
import type { ApiTemplates, RepoTemplates, StatusRemoto } from '../api/template/casos.ts';
import { TemplateMeta } from '../api/template/template.ts';

export class EfeitosMemoria implements Efeitos {
  auditoria: { acao: string; entidade: string; id: string | null }[] = [];
  eventos: { evento: string; dados: Record<string, unknown> }[] = [];
  historicos: unknown[] = [];
  notas: string[] = [];
  async auditar(acao: string, entidade: string, id: string | null) { this.auditoria.push({ acao, entidade, id }); }
  async publicar(evento: string, dados: Record<string, unknown>) { this.eventos.push({ evento, dados }); }
  async historico(...a: unknown[]) { this.historicos.push(a); }
  async nota(_e: string, _r: string, corpo: string) { this.notas.push(corpo); }
}

export function contexto(): ContextoCaso & { efeitos: EfeitosMemoria } {
  return { ator: { tipo: 'usuario', id: '00000000-0000-4000-8000-000000000001' }, efeitos: new EfeitosMemoria() };
}

export class FluxosMemoria implements RepoFluxos {
  m = new Map<string, DadosFluxo>();
  async obter(id: string) { const d = this.m.get(id); return d ? Fluxo.reidratar(structuredClone(d)) : null; }
  async inserir(f: Fluxo) { this.m.set(f.id, structuredClone(f.paraDados())); }
  async atualizar(f: Fluxo) { this.m.set(f.id, structuredClone(f.paraDados())); }
  async excluir(id: string) { this.m.delete(id); }
}

export class MotorMemoria implements RepoMotor {
  execucoes = new Map<string, DadosExecucao>();
  passos: Passo[] = [];
  comentarios = new Set<string>();
  perfis = new Map<string, PerfilContato>();
  templates = new Map<string, TemplateRef>();
  constructor(readonly fluxos: FluxosMemoria) {}
  async fluxosAtivos(canal: CanalFluxo, gatilhos: TipoGatilho[]) { return [...this.fluxos.m.values()].filter((f) => f.estado === 'ativa' && f.canal === canal && gatilhos.includes(f.gatilho)).map((f) => structuredClone(f)); }
  async fluxo(id: string) { const f = this.fluxos.m.get(id); return f ? structuredClone(f) : null; }
  async criarExecucao(x: DadosExecucao) {
    if ([...this.execucoes.values()].some((e) => e.fluxo_id === x.fluxo_id && e.chave_evento === x.chave_evento)) return false;
    this.execucoes.set(x.id, structuredClone(x));
    return true;
  }
  async execucaoPorChave(f: string, chave: string) { const x = [...this.execucoes.values()].find((e) => e.fluxo_id === f && e.chave_evento === chave); return x ? structuredClone(x) : null; }
  async execucao(id: string) { const x = this.execucoes.get(id); return x ? structuredClone(x) : null; }
  async atualizarExecucao(x: DadosExecucao) { this.execucoes.set(x.id, structuredClone(x)); }
  async aguardandoClique(canal: CanalFluxo, contato: string) { return [...this.execucoes.values()].filter((e) => e.canal === canal && e.contato === contato && e.estado === 'aguardando_clique').map((e) => structuredClone(e)).reverse(); }
  async jaExecutouParaContato(f: string, contato: string) { return [...this.execucoes.values()].some((e) => e.fluxo_id === f && e.contato === contato); }
  async registrarPasso(p: Passo) { this.passos.push(structuredClone(p)); }
  async reivindicarComentario(id: string) { if (this.comentarios.has(id)) return false; this.comentarios.add(id); return true; }
  async perfil(_c: CanalFluxo, contato: string): Promise<PerfilContato> { return this.perfis.get(contato) ?? { parceiro_id: null, e_cliente: false, telefone: null, tags: [], conversa_id: null, ultima_entrada_em: null }; }
  async template(id: string) { return this.templates.get(id) ?? null; }
}

/** Canal fake: grava cada chamada. `falhar` define o proximo erro (permanente ou transitorio). */
export class CanalMemoria implements CanalEnvio {
  chamadas: { tipo: string; dados: Record<string, unknown> }[] = [];
  falhar: { permanente: boolean; mensagem: string } | null = null;
  private n = 0;
  private registrar(tipo: string, dados: Record<string, unknown>) {
    if (this.falhar) { const f = this.falhar; this.falhar = null; throw new ErroCanal(f.mensagem, f.permanente); }
    this.chamadas.push({ tipo, dados });
    return { id_externo: `ext_${++this.n}` };
  }
  async responderComentario(e: { post_id: string; comentario_id: string; texto: string; chave: string }) { return this.registrar('resposta_publica', e); }
  async respostaPrivada(e: Record<string, unknown>) { return this.registrar('resposta_privada', e); }
  async enviarMensagem(m: MensagemSaida) { return this.registrar('mensagem', m as unknown as Record<string, unknown>); }
  async enviarTemplate(e: Record<string, unknown>) { return this.registrar('template', e); }
}

export class AgendadorMemoria implements Agendador {
  agendados: { execucao_id: string; no_id: string; minutos: number }[] = [];
  async continuarDepois(execucao_id: string, no_id: string, minutos: number) { this.agendados.push({ execucao_id, no_id, minutos }); }
}

export class TemplatesMemoria implements RepoTemplates {
  m = new Map<string, ReturnType<TemplateMeta['paraDados']>>();
  sincronizados = 0;
  async obter(id: string) { const d = this.m.get(id); return d ? TemplateMeta.reidratar(structuredClone(d)) : null; }
  async porNome(nome: string, idioma: string) { const d = [...this.m.values()].find((x) => x.nome === nome && x.idioma === idioma); return d ? TemplateMeta.reidratar(structuredClone(d)) : null; }
  async inserir(t: TemplateMeta) { this.m.set(t.id, t.paraDados()); }
  async atualizar(t: TemplateMeta, sinc?: boolean) { this.m.set(t.id, t.paraDados()); if (sinc) this.sincronizados++; }
  async excluir(id: string) { this.m.delete(id); }
  async acompanhados() { return [...this.m.values()].filter((d) => d.estado !== 'rascunho').map((d) => TemplateMeta.reidratar(structuredClone(d))); }
  ref(id: string): TemplateRef | null { const d = this.m.get(id); return d ? { id: d.id, nome: d.nome, idioma: d.idioma, estado: d.estado, botoes: d.botoes.map((b) => ({ tipo: b.tipo, texto: b.texto })) } : null; }
}

export class ApiTemplatesMemoria implements ApiTemplates {
  submetidos: { nome: string; idioma: string; categoria: string; componentes: Record<string, unknown>[] }[] = [];
  remotos: StatusRemoto[] = [];
  async submeter(e: { nome: string; idioma: string; categoria: string; componentes: Record<string, unknown>[] }) {
    this.submetidos.push(e);
    const id = `tpl_${this.submetidos.length}`;
    this.remotos.push({ id, nome: e.nome, idioma: e.idioma, status: 'PENDING', motivo: null });
    return { id_externo: id, status: 'PENDING' };
  }
  async listar() { return structuredClone(this.remotos); }
}

export class BroadcastMemoria implements RepoBroadcast {
  m = new Map<string, ReturnType<Broadcast['paraDados']>>();
  clientes: (Destinatario & { tags: string[] })[] = [];
  envios: { id: string; broadcast_id: string; parceiro_id: string; telefone: string; estado: string; id_externo: string | null; erro: string | null; enviado_em: Date | null; clicado_em: Date | null; botao: string | null }[] = [];
  botoesTemplate: string[] = [];
  fluxos = new Set<string>();
  constructor(private readonly reidratar: (d: ReturnType<Broadcast['paraDados']>) => Broadcast, private readonly relogio: () => Date = () => new Date()) {}
  async obter(id: string) { const d = this.m.get(id); return d ? this.reidratar(structuredClone(d)) : null; }
  async inserir(b: Broadcast) { this.m.set(b.id, b.paraDados()); }
  async atualizar(b: Broadcast) { this.m.set(b.id, b.paraDados()); }
  async destinatarios(s: Segmento) { return this.clientes.filter((c) => !s.tag_ids?.length || c.tags.some((t) => s.tag_ids!.includes(t))).map(({ parceiro_id, telefone }) => ({ parceiro_id, telefone })); }
  async criarEnvios(bid: string, ds: Destinatario[]) {
    for (const d of ds) if (!this.envios.some((e) => e.broadcast_id === bid && e.parceiro_id === d.parceiro_id)) this.envios.push({ id: `env_${this.envios.length + 1}`, broadcast_id: bid, ...d, estado: 'pendente', id_externo: null, erro: null, enviado_em: null, clicado_em: null, botao: null });
    return this.envios.filter((e) => e.broadcast_id === bid).length;
  }
  async pendentes(bid: string, limite: number): Promise<EnvioPendente[]> { return this.envios.filter((e) => e.broadcast_id === bid && e.estado === 'pendente').slice(0, limite).map(({ id, parceiro_id, telefone }) => ({ id, parceiro_id, telefone })); }
  async marcarEnvio(id: string, p: { estado: 'enviado' | 'falhou'; id_externo?: string | null; erro?: string | null }) { const e = this.envios.find((x) => x.id === id)!; Object.assign(e, { estado: p.estado, id_externo: p.id_externo ?? null, erro: p.erro ?? null, enviado_em: p.estado === 'enviado' ? this.relogio() : null }); }
  async enviosRecentes(telefone: string, desde: Date) {
    return this.envios.filter((e) => e.telefone === telefone && e.enviado_em && e.enviado_em >= desde)
      .map((e) => ({ envio_id: e.id, broadcast_id: e.broadcast_id, parceiro_id: e.parceiro_id, fluxo_id: this.m.get(e.broadcast_id)?.fluxo_id ?? null, botoes: this.botoesTemplate, clicado: !!e.clicado_em }));
  }
  async marcarClique(id: string, botao: string, quando: Date) { Object.assign(this.envios.find((x) => x.id === id)!, { clicado_em: quando, botao }); }
  async fluxoValido(id: string) { return this.fluxos.has(id); }
}

export class FilaMemoria {
  jobs: { tipo: string; payload: Record<string, unknown>; atraso: number }[] = [];
  async agendar(tipo: string, payload: Record<string, unknown>, atraso: number) { this.jobs.push({ tipo, payload, atraso }); return `job_${this.jobs.length}`; }
}
