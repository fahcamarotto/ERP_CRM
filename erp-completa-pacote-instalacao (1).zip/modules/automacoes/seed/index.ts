/**
 * Dados demo minimos e idempotentes (id deterministico). Tudo nasce em rascunho: nenhuma automacao ativa e nenhum
 * broadcast agendado, entao o seed nunca envia mensagem real.
 */
import { createHash } from 'node:crypto';
import type { SeedModulo } from '@erp/api/sdk/puro';
import { Broadcast } from '../api/broadcast/broadcast.ts';
import { BroadcastRepoPg } from '../api/broadcast/adapter.ts';
import { FluxoRepoPg } from '../api/fluxo/adapter/fluxo-repo-pg.ts';
import { Fluxo } from '../api/fluxo/model/fluxo.ts';
import type { Grafo } from '../api/fluxo/model/grafo.ts';
import { TemplateRepoPg } from '../api/template/adapter.ts';
import { TemplateMeta } from '../api/template/template.ts';

const idDe = (chave: string) => {
  const h = createHash('sha256').update(`automacoes-demo:${chave}`).digest('hex');
  return `${h.slice(0, 8)}-${h.slice(8, 12)}-4${h.slice(13, 16)}-8${h.slice(17, 20)}-${h.slice(20, 32)}`;
};

const grafoInstagram: Grafo = {
  versao: 1, entrada: 'gatilho',
  nos: [
    { id: 'gatilho', tipo: 'gatilho', posicao: { x: 0, y: 160 }, dados: { tipo: 'comentario_post', post_id: null, palavras: ['quero'], correspondencia: 'contem', uma_vez_por_contato: true } },
    { id: 'publica', tipo: 'resposta_publica', posicao: { x: 320, y: 40 }, dados: { respostas: ['Te mandei tudo no direct, {{primeiro_nome}}!', 'Corre no direct que chegou!'] } },
    { id: 'dm', tipo: 'mensagem', posicao: { x: 640, y: 160 }, dados: { texto: 'Oi {{primeiro_nome}}! Toca no botao para receber o material.', botoes: [{ tipo: 'resposta', titulo: 'RECEBER MATERIAL' }] } },
    { id: 'material', tipo: 'mensagem', posicao: { x: 960, y: 160 }, dados: { texto: 'Aqui esta: https://exemplo.com/material' } },
    { id: 'tag', tipo: 'acao', posicao: { x: 1280, y: 160 }, dados: { tipo: 'cliente', tags: ['lead-instagram'] } },
    { id: 'fim', tipo: 'fim', posicao: { x: 1600, y: 160 }, dados: {} },
  ],
  fios: [
    { id: 'f1', origem: 'gatilho', porta: 'saida', destino: 'publica' },
    { id: 'f2', origem: 'publica', porta: 'saida', destino: 'dm' },
    { id: 'f3', origem: 'dm', porta: 'botao:0', destino: 'material' },
    { id: 'f4', origem: 'material', porta: 'saida', destino: 'tag' },
    { id: 'f5', origem: 'tag', porta: 'saida', destino: 'fim' },
  ],
};

const grafoWhatsapp: Grafo = {
  versao: 1, entrada: 'gatilho',
  nos: [
    { id: 'gatilho', tipo: 'gatilho', posicao: { x: 0, y: 160 }, dados: { tipo: 'mensagem_palavra', palavras: ['preco', 'valor'], correspondencia: 'palavra', uma_vez_por_contato: false } },
    { id: 'menu', tipo: 'mensagem', posicao: { x: 320, y: 160 }, dados: { texto: 'Oi {{primeiro_nome}}! Quer receber a tabela de precos?', botoes: [{ tipo: 'resposta', titulo: 'Sim, quero' }, { tipo: 'resposta', titulo: 'Falar com time' }] } },
    { id: 'tabela', tipo: 'mensagem', posicao: { x: 640, y: 40 }, dados: { texto: 'Tabela: https://exemplo.com/precos' } },
    { id: 'humano', tipo: 'mensagem', posicao: { x: 640, y: 300 }, dados: { texto: 'Perfeito, alguem do time ja vai te chamar.' } },
  ],
  fios: [
    { id: 'f1', origem: 'gatilho', porta: 'saida', destino: 'menu' },
    { id: 'f2', origem: 'menu', porta: 'botao:0', destino: 'tabela' },
    { id: 'f3', origem: 'menu', porta: 'botao:1', destino: 'humano' },
  ],
};

const semear: SeedModulo = async ({ c, log }) => {
  let novos = 0;
  const fluxos = new FluxoRepoPg(c);
  for (const [chave, nome, canal, grafo] of [['ig', 'Comentario QUERO no post', 'instagram', grafoInstagram], ['wa', 'Tabela de precos no WhatsApp', 'whatsapp', grafoWhatsapp]] as const) {
    const id = idDe(chave);
    if (await fluxos.obter(id)) continue;
    await fluxos.inserir(Fluxo.create({ nome, canal, grafo }, id));
    novos++;
  }
  const templates = new TemplateRepoPg(c);
  const tid = idDe('template');
  if (!(await templates.obter(tid)) && !(await templates.porNome('boas_vindas_demo', 'pt_BR'))) {
    await templates.inserir(TemplateMeta.create({
      nome: 'boas_vindas_demo', categoria: 'MARKETING', cabecalho: { tipo: 'texto', texto: 'Novidade' }, corpo: 'Oi {{1}}, temos uma condicao especial para voce. Quer saber mais?',
      exemplos: ['Ana'], rodape: 'Responda SAIR para nao receber', botoes: [{ tipo: 'resposta', texto: 'Quero saber' }, { tipo: 'resposta', texto: 'Agora nao' }],
    }, tid));
    novos++;
  }
  const bid = idDe('broadcast');
  const broadcasts = new BroadcastRepoPg(c);
  if ((await templates.obter(tid)) && !(await broadcasts.obter(bid))) {
    const b = Broadcast.tryCreate({ nome: 'Condicao especial de outubro', template_id: tid, parametros: ['cliente'], segmento: { somente_clientes: true }, ritmo_por_minuto: 30 }, bid);
    if (b.ok) { await broadcasts.inserir(b.valor); novos++; }
  }
  log(`${novos} registro(s) demo novo(s)`);
};

export default semear;
