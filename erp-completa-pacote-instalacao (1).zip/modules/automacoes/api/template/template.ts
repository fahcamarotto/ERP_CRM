/**
 * Entidade TemplateMeta: template oficial do WhatsApp criado no ERP (categoria, idioma, cabecalho de texto, corpo
 * com variaveis {{1}}..{{n}} e exemplos, rodape, botoes de resposta rapida, link e telefone). Converte para os
 * `components` da Meta enviados pela Zernio e le o status da Meta.
 */
import { randomUUID } from 'node:crypto';
import { erroDe, fail, ok, type ErroDominio, type Result } from '../compartilhado/result.ts';

export const CATEGORIAS = ['MARKETING', 'UTILITY', 'AUTHENTICATION'] as const;
export type Categoria = (typeof CATEGORIAS)[number];
export const ESTADOS = ['rascunho', 'pendente', 'aprovado', 'rejeitado', 'pausado', 'desativado'] as const;
export type EstadoTemplate = (typeof ESTADOS)[number];

export interface BotaoTemplate { tipo: 'resposta' | 'url' | 'telefone'; texto: string; url?: string | null; telefone?: string | null }
export interface DadosTemplateMeta {
  id: string;
  nome: string;
  idioma: string;
  categoria: Categoria;
  cabecalho: { tipo: 'texto'; texto: string } | null;
  corpo: string;
  exemplos: string[];
  rodape: string | null;
  botoes: BotaoTemplate[];
  estado: EstadoTemplate;
  motivo_rejeicao: string | null;
  id_externo: string | null;
}
export type EntradaTemplate = Partial<Pick<DadosTemplateMeta, 'idioma' | 'categoria' | 'cabecalho' | 'exemplos' | 'rodape' | 'botoes'>> & { nome: string; corpo: string };

/** Status da Meta (verbatim, como a Zernio repassa) para o estado local. */
export const STATUS_META: Record<string, EstadoTemplate> = {
  PENDING: 'pendente', IN_APPEAL: 'pendente', APPROVED: 'aprovado', REJECTED: 'rejeitado', PAUSED: 'pausado', DISABLED: 'desativado', PENDING_DELETION: 'desativado',
};

export function variaveis(texto: string): number[] {
  return [...new Set([...texto.matchAll(/\{\{\s*(\d+)\s*\}\}/g)].map((m) => Number(m[1])))].sort((a, b) => a - b);
}

function validar(d: DadosTemplateMeta): ErroDominio[] {
  const e: ErroDominio[] = [];
  if (!/^[a-z][a-z0-9_]{0,511}$/.test(d.nome)) e.push(erroDe('nome_invalido', 'Nome com letras minusculas, numeros e _, comecando por letra (regra da Meta)', 'nome'));
  if (!/^[a-z]{2}(_[A-Z]{2})?$/.test(d.idioma)) e.push(erroDe('idioma_invalido', 'Idioma no formato da Meta (pt_BR, en_US, es)', 'idioma'));
  if (!CATEGORIAS.includes(d.categoria)) e.push(erroDe('categoria_invalida', `Categoria ${CATEGORIAS.join(', ')}`, 'categoria'));
  if (d.corpo.trim().length < 1 || d.corpo.length > 1024) e.push(erroDe('corpo_invalido', 'Corpo de 1 a 1024 caracteres', 'corpo'));
  const vs = variaveis(d.corpo);
  if (vs.some((n, i) => n !== i + 1)) e.push(erroDe('variaveis_invalidas', 'Variaveis {{1}}, {{2}}... em sequencia, sem pular numero', 'corpo'));
  if (vs.length && d.exemplos.filter((x) => x.trim()).length !== vs.length) e.push(erroDe('exemplos_faltando', `A Meta exige um exemplo para cada variavel (${vs.length})`, 'exemplos'));
  if (d.cabecalho && (d.cabecalho.tipo !== 'texto' || !d.cabecalho.texto.trim() || d.cabecalho.texto.length > 60 || variaveis(d.cabecalho.texto).length)) e.push(erroDe('cabecalho_invalido', 'Cabecalho de texto ate 60 caracteres, sem variavel', 'cabecalho'));
  if (d.rodape !== null && (d.rodape.length > 60 || !d.rodape.trim())) e.push(erroDe('rodape_invalido', 'Rodape ate 60 caracteres', 'rodape'));
  const bs = d.botoes;
  if (bs.length > 10) e.push(erroDe('botoes_invalidos', 'Ate 10 botoes', 'botoes'));
  if (bs.filter((b) => b.tipo === 'url').length > 2 || bs.filter((b) => b.tipo === 'telefone').length > 1) e.push(erroDe('botoes_invalidos', 'Ate 2 botoes de link e 1 de telefone', 'botoes'));
  for (const [i, b] of bs.entries()) {
    if (!['resposta', 'url', 'telefone'].includes(b.tipo) || !b.texto?.trim() || b.texto.length > 25) e.push(erroDe('botoes_invalidos', `Botao ${i + 1}: texto de 1 a 25 caracteres`, 'botoes'));
    if (b.tipo === 'url' && !/^https:\/\/\S+$/.test(b.url ?? '')) e.push(erroDe('botoes_invalidos', `Botao ${i + 1}: link https obrigatorio`, 'botoes'));
    if (b.tipo === 'telefone' && !/^\+[1-9]\d{7,14}$/.test(b.telefone ?? '')) e.push(erroDe('botoes_invalidos', `Botao ${i + 1}: telefone E.164 (+5511...)`, 'botoes'));
  }
  return e;
}

export const TRANSICOES: Record<EstadoTemplate, EstadoTemplate[]> = {
  rascunho: ['pendente'], rejeitado: ['pendente', 'rascunho'], pendente: ['aprovado', 'rejeitado', 'pausado', 'desativado'],
  aprovado: ['pausado', 'rejeitado', 'desativado', 'pendente'], pausado: ['aprovado', 'rejeitado', 'desativado'], desativado: ['aprovado'],
};

export class TemplateMeta {
  private constructor(private readonly p: DadosTemplateMeta) {}

  static tryCreate(e: EntradaTemplate, id: string = randomUUID()): Result<TemplateMeta> {
    const d: DadosTemplateMeta = {
      id, nome: (e.nome ?? '').trim(), idioma: e.idioma ?? 'pt_BR', categoria: e.categoria ?? 'MARKETING', cabecalho: e.cabecalho?.texto?.trim() ? { tipo: 'texto', texto: e.cabecalho.texto.trim() } : null,
      corpo: e.corpo ?? '', exemplos: (e.exemplos ?? []).map(String), rodape: e.rodape?.trim() ? e.rodape.trim() : null,
      botoes: (e.botoes ?? []).map((b) => ({ tipo: b.tipo, texto: (b.texto ?? '').trim(), url: b.url ?? null, telefone: b.telefone ?? null })), estado: 'rascunho', motivo_rejeicao: null, id_externo: null,
    };
    const erros = validar(d);
    return erros.length ? fail(...erros) : ok(new TemplateMeta(d));
  }

  static create(e: EntradaTemplate, id?: string): TemplateMeta {
    const r = TemplateMeta.tryCreate(e, id);
    if (!r.ok) throw new Error(r.erros.map((x) => x.mensagem).join('; '));
    return r.valor;
  }

  static reidratar(d: DadosTemplateMeta): TemplateMeta { return new TemplateMeta({ ...d }); }

  get id() { return this.p.id; }
  get estado() { return this.p.estado; }

  editar(e: Partial<EntradaTemplate>): Result<TemplateMeta> {
    if (!['rascunho', 'rejeitado'].includes(this.p.estado)) return fail(erroDe('transicao_invalida', 'So rascunho ou rejeitado pode ser editado', 'estado'));
    const r = TemplateMeta.tryCreate({ ...this.p, ...e, cabecalho: e.cabecalho === undefined ? this.p.cabecalho : e.cabecalho, rodape: e.rodape === undefined ? this.p.rodape : e.rodape }, this.p.id);
    return r.ok ? ok(new TemplateMeta({ ...r.valor.p, estado: 'rascunho', id_externo: this.p.id_externo })) : r;
  }

  mudarEstado(para: EstadoTemplate, extra: { motivo?: string | null; id_externo?: string | null } = {}): Result<TemplateMeta> {
    if (para !== this.p.estado && !TRANSICOES[this.p.estado].includes(para)) {
      return fail(erroDe('transicao_invalida', `De ${this.p.estado} para ${para} nao e permitido`, 'estado', { permitidas: TRANSICOES[this.p.estado] }));
    }
    return ok(new TemplateMeta({
      ...this.p, estado: para, motivo_rejeicao: para === 'rejeitado' ? (extra.motivo ?? this.p.motivo_rejeicao) : null,
      id_externo: extra.id_externo ?? this.p.id_externo,
    }));
  }

  /** Components no formato da Meta (POST /v1/whatsapp/templates da Zernio). */
  componentes(): Record<string, unknown>[] {
    const c: Record<string, unknown>[] = [];
    if (this.p.cabecalho) c.push({ type: 'HEADER', format: 'TEXT', text: this.p.cabecalho.texto });
    const vs = variaveis(this.p.corpo);
    c.push({ type: 'BODY', text: this.p.corpo, ...(vs.length ? { example: { body_text: [this.p.exemplos.slice(0, vs.length)] } } : {}) });
    if (this.p.rodape) c.push({ type: 'FOOTER', text: this.p.rodape });
    if (this.p.botoes.length) {
      c.push({
        type: 'BUTTONS',
        buttons: this.p.botoes.map((b) => (b.tipo === 'url' ? { type: 'URL', text: b.texto, url: b.url } : b.tipo === 'telefone' ? { type: 'PHONE_NUMBER', text: b.texto, phone_number: b.telefone } : { type: 'QUICK_REPLY', text: b.texto })),
      });
    }
    return c;
  }

  paraDados(): DadosTemplateMeta { return { ...this.p, exemplos: [...this.p.exemplos], botoes: this.p.botoes.map((b) => ({ ...b })) }; }
}
