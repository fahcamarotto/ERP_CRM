/** Casos de uso dos templates oficiais: criar, editar, excluir, submeter a Meta pela Zernio e sincronizar status. */
import { erroDe, fail, ok, okVazio, type Result } from '../compartilhado/result.ts';
import type { ContextoCaso } from '../compartilhado/efeitos.ts';
import { STATUS_META, TemplateMeta, type DadosTemplateMeta, type EntradaTemplate, type EstadoTemplate } from './template.ts';

export const TABELA_TEMPLATES = 'automacoes_templates';

export interface RepoTemplates {
  obter(id: string): Promise<TemplateMeta | null>;
  porNome(nome: string, idioma: string): Promise<TemplateMeta | null>;
  inserir(t: TemplateMeta): Promise<void>;
  atualizar(t: TemplateMeta, sincronizado?: boolean): Promise<void>;
  excluir(id: string): Promise<void>;
  acompanhados(): Promise<TemplateMeta[]>;
}

export interface StatusRemoto { id: string | null; nome: string; idioma: string; status: string; motivo: string | null }

/** API de templates do provedor (Zernio). Erro com `permanente` = recusa da Meta; sem = falha transitoria. */
export interface ApiTemplates {
  submeter(e: { nome: string; idioma: string; categoria: string; componentes: Record<string, unknown>[] }): Promise<{ id_externo: string | null; status: string }>;
  listar(): Promise<StatusRemoto[]>;
}

export class CriarTemplate {
  constructor(private readonly d: { repo: RepoTemplates }) {}
  async execute(ctx: ContextoCaso, e: EntradaTemplate): Promise<Result<{ id: string }>> {
    const r = TemplateMeta.tryCreate(e);
    if (!r.ok) return r;
    const d = r.valor.paraDados();
    if (await this.d.repo.porNome(d.nome, d.idioma)) return fail(erroDe('conflito', 'Ja existe template com esse nome e idioma', 'nome'));
    await this.d.repo.inserir(r.valor);
    await ctx.efeitos.auditar('template_meta.criar', TABELA_TEMPLATES, d.id, undefined, d);
    return ok({ id: d.id });
  }
}

export class EditarTemplate {
  constructor(private readonly d: { repo: RepoTemplates }) {}
  async execute(ctx: ContextoCaso, e: Partial<EntradaTemplate> & { id: string }): Promise<Result<void>> {
    const t = await this.d.repo.obter(e.id);
    if (!t) return fail(erroDe('nao_encontrado', 'Template nao encontrado'));
    const { id: _id, ...resto } = e;
    const r = t.editar(resto);
    if (!r.ok) return r;
    const n = r.valor.paraDados();
    if (n.nome !== t.paraDados().nome || n.idioma !== t.paraDados().idioma) {
      const outro = await this.d.repo.porNome(n.nome, n.idioma);
      if (outro && outro.id !== t.id) return fail(erroDe('conflito', 'Ja existe template com esse nome e idioma', 'nome'));
    }
    await this.d.repo.atualizar(r.valor);
    await ctx.efeitos.auditar('template_meta.editar', TABELA_TEMPLATES, t.id, t.paraDados(), n);
    return okVazio();
  }
}

export class ExcluirTemplate {
  constructor(private readonly d: { repo: RepoTemplates }) {}
  async execute(ctx: ContextoCaso, e: { id: string }): Promise<Result<void>> {
    const t = await this.d.repo.obter(e.id);
    if (!t) return fail(erroDe('nao_encontrado', 'Template nao encontrado'));
    if (!['rascunho', 'rejeitado'].includes(t.estado)) return fail(erroDe('transicao_invalida', 'So rascunho ou rejeitado pode ser excluido', 'estado'));
    await this.d.repo.excluir(e.id);
    await ctx.efeitos.auditar('template_meta.excluir', TABELA_TEMPLATES, e.id, t.paraDados(), undefined);
    return okVazio();
  }
}

export class SubmeterTemplate {
  constructor(private readonly d: { repo: RepoTemplates; api: ApiTemplates }) {}
  async execute(ctx: ContextoCaso, e: { id: string }): Promise<Result<{ estado: EstadoTemplate }>> {
    const t = await this.d.repo.obter(e.id);
    if (!t) return fail(erroDe('nao_encontrado', 'Template nao encontrado'));
    if (!['rascunho', 'rejeitado'].includes(t.estado)) return fail(erroDe('transicao_invalida', 'So rascunho ou rejeitado vai para aprovacao', 'estado'));
    const d = t.paraDados();
    let r: { id_externo: string | null; status: string };
    try {
      r = await this.d.api.submeter({ nome: d.nome, idioma: d.idioma, categoria: d.categoria, componentes: t.componentes() });
    } catch (err) {
      const msg = (err as Error).message;
      return fail(erroDe((err as { permanente?: boolean }).permanente ? 'provedor_recusou' : 'provedor_indisponivel', `A Meta nao aceitou o template: ${msg}`.slice(0, 400)));
    }
    const para = STATUS_META[r.status.toUpperCase()] ?? 'pendente';
    const m = t.mudarEstado('pendente', { id_externo: r.id_externo });
    if (!m.ok) return m;
    const final = para === 'pendente' ? null : m.valor.mudarEstado(para);
    const valor = final?.ok ? final.valor : m.valor;
    await this.d.repo.atualizar(valor, true);
    await ctx.efeitos.auditar('template_meta.submeter', TABELA_TEMPLATES, d.id, { estado: d.estado }, { estado: valor.estado, id_externo: r.id_externo });
    await ctx.efeitos.publicar('template_meta.submetido', { id: d.id, nome: d.nome, idioma: d.idioma, categoria: d.categoria, id_externo: r.id_externo });
    if (valor.estado !== 'pendente') await ctx.efeitos.publicar('template_meta.status_alterado', { id: d.id, nome: d.nome, idioma: d.idioma, de: 'pendente', para: valor.estado, motivo: null });
    return ok({ estado: valor.estado });
  }
}

/**
 * Aplica um status vindo da Meta (sincronizacao ou webhook whatsapp.template.status_updated): casa pelo id externo
 * ou por nome e idioma. Idempotente: mesmo status nao gera evento.
 */
export class AplicarStatusTemplate {
  constructor(private readonly d: { repo: RepoTemplates }) {}
  async execute(ctx: ContextoCaso, s: StatusRemoto, locais?: TemplateMeta[]): Promise<Result<{ mudou: boolean }>> {
    const lista = locais ?? (await this.d.repo.acompanhados());
    const t = lista.find((x) => s.id && x.paraDados().id_externo === s.id) ?? lista.find((x) => x.paraDados().nome === s.nome && x.paraDados().idioma === s.idioma) ?? (await this.d.repo.porNome(s.nome, s.idioma));
    if (!t) return ok({ mudou: false });
    const para = STATUS_META[s.status.toUpperCase()];
    const antes: DadosTemplateMeta = t.paraDados();
    const motivo = s.motivo && s.motivo !== 'NONE' ? s.motivo.slice(0, 500) : null;
    if (!para || (para === antes.estado && (para !== 'rejeitado' || motivo === antes.motivo_rejeicao))) {
      await this.d.repo.atualizar(t, true);
      return ok({ mudou: false });
    }
    const r = t.mudarEstado(para, { motivo, id_externo: s.id ?? antes.id_externo });
    if (!r.ok) return ok({ mudou: false });
    await this.d.repo.atualizar(r.valor, true);
    await ctx.efeitos.auditar('template_meta.status', TABELA_TEMPLATES, antes.id, { estado: antes.estado }, { estado: para, motivo });
    await ctx.efeitos.publicar('template_meta.status_alterado', { id: antes.id, nome: antes.nome, idioma: antes.idioma, de: antes.estado, para, motivo });
    return ok({ mudou: true });
  }
}

export class SincronizarTemplates {
  constructor(private readonly d: { repo: RepoTemplates; api: ApiTemplates; aplicar: AplicarStatusTemplate }) {}
  async execute(ctx: ContextoCaso): Promise<Result<{ verificados: number; alterados: number; pendentes: number }>> {
    const locais = await this.d.repo.acompanhados();
    if (!locais.length) return ok({ verificados: 0, alterados: 0, pendentes: 0 });
    let remotos: StatusRemoto[];
    try { remotos = await this.d.api.listar(); } catch (err) { return fail(erroDe('provedor_indisponivel', (err as Error).message.slice(0, 300))); }
    let alterados = 0;
    for (const s of remotos) {
      const r = await this.d.aplicar.execute(ctx, s, locais);
      if (r.ok && r.valor.mudou) alterados++;
    }
    const pendentes = (await this.d.repo.acompanhados()).filter((t) => t.estado === 'pendente').length;
    return ok({ verificados: remotos.length, alterados, pendentes });
  }
}
