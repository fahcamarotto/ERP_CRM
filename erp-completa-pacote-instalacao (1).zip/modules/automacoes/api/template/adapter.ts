/** Adaptadores dos templates: repositorio Postgres, API da Zernio (conta do WhatsApp da subconta) e leituras. */
import type pg from 'pg';
import { contaAtiva } from '../motor/adapter/canal-zernio.ts';
import { ErroCanal } from '../motor/model/portas.ts';
import { ClienteZernioAutomacoes } from '../zernio/cliente.ts';
import type { ApiTemplates, RepoTemplates, StatusRemoto } from './casos.ts';
import { TemplateMeta, type DadosTemplateMeta } from './template.ts';

const COLUNAS = `id, nome, idioma, categoria, cabecalho, corpo, exemplos, rodape, botoes, estado, motivo_rejeicao, id_externo`;

export class TemplateRepoPg implements RepoTemplates {
  constructor(private readonly c: pg.PoolClient) {}
  private um = (r: pg.QueryResult) => (r.rows[0] ? TemplateMeta.reidratar(r.rows[0] as DadosTemplateMeta) : null);
  async obter(id: string) { return this.um(await this.c.query(`SELECT ${COLUNAS} FROM automacoes_templates WHERE id = $1 AND deleted_at IS NULL`, [id])); }
  async porNome(nome: string, idioma: string) { return this.um(await this.c.query(`SELECT ${COLUNAS} FROM automacoes_templates WHERE nome = $1 AND idioma = $2 AND deleted_at IS NULL`, [nome, idioma])); }
  async inserir(t: TemplateMeta) {
    const d = t.paraDados();
    await this.c.query(
      `INSERT INTO automacoes_templates (id, nome, idioma, categoria, cabecalho, corpo, exemplos, rodape, botoes, estado, creator_id)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, nucleo_usuario_atual())`,
      [d.id, d.nome, d.idioma, d.categoria, d.cabecalho ? JSON.stringify(d.cabecalho) : null, d.corpo, JSON.stringify(d.exemplos), d.rodape, JSON.stringify(d.botoes), d.estado],
    );
  }
  async atualizar(t: TemplateMeta, sincronizado = false) {
    const d = t.paraDados();
    await this.c.query(
      `UPDATE automacoes_templates SET nome = $2, idioma = $3, categoria = $4, cabecalho = $5, corpo = $6, exemplos = $7, rodape = $8, botoes = $9, estado = $10,
         motivo_rejeicao = $11, id_externo = $12, submetido_em = CASE WHEN $10 = 'pendente' AND estado <> 'pendente' THEN now() ELSE submetido_em END,
         sincronizado_em = CASE WHEN $13 THEN now() ELSE sincronizado_em END WHERE id = $1`,
      [d.id, d.nome, d.idioma, d.categoria, d.cabecalho ? JSON.stringify(d.cabecalho) : null, d.corpo, JSON.stringify(d.exemplos), d.rodape, JSON.stringify(d.botoes), d.estado, d.motivo_rejeicao, d.id_externo, sincronizado],
    );
  }
  async excluir(id: string) { await this.c.query(`UPDATE automacoes_templates SET deleted_at = now() WHERE id = $1`, [id]); }
  async acompanhados() {
    const r = await this.c.query(`SELECT ${COLUNAS} FROM automacoes_templates WHERE estado <> 'rascunho' AND deleted_at IS NULL`);
    return r.rows.map((x) => TemplateMeta.reidratar(x as DadosTemplateMeta));
  }
}

/** Templates na Zernio da conta de WhatsApp conectada nesta subconta. */
export class TemplatesZernio implements ApiTemplates {
  constructor(private readonly c: pg.PoolClient, private readonly api = new ClienteZernioAutomacoes()) {}
  private async conta() {
    const x = await contaAtiva(this.c, 'whatsapp');
    if (!x) throw Object.assign(new ErroCanal('WhatsApp nao conectado (Integracoes > Conectores)', true), { permanente: true });
    return x.conta_id;
  }
  async submeter(e: { nome: string; idioma: string; categoria: string; componentes: Record<string, unknown>[] }) { return this.api.criarTemplate(await this.conta(), e); }
  async listar(): Promise<StatusRemoto[]> { return this.api.listarTemplates(await this.conta()); }
}

export async function listarTemplates(c: pg.PoolClient, f: { estado?: string } = {}) {
  const r = await c.query(
    `SELECT ${COLUNAS}, submetido_em, sincronizado_em, created_at, updated_at FROM automacoes_templates
     WHERE deleted_at IS NULL AND ($1::text IS NULL OR estado = $1) ORDER BY created_at DESC, id LIMIT 500`,
    [f.estado ?? null],
  );
  return r.rows;
}

export async function obterTemplate(c: pg.PoolClient, id: string) {
  return (await c.query(`SELECT ${COLUNAS}, submetido_em, sincronizado_em, created_at, updated_at FROM automacoes_templates WHERE id = $1 AND deleted_at IS NULL`, [id])).rows[0] ?? null;
}
