/**
 * Motor de execucao das automacoes (roda no worker, pela fila). Replica a cadeia do sistema de agentes de referencia:
 * comentario no post -> resposta publica + DM (resposta privada) com botoes; clique em botao -> ramo do no;
 * mensagem com palavra-chave e clique em botao no WhatsApp. Idempotente por evento (chave unica por fluxo),
 * uma automacao por comentario, uma execucao por contato quando o gatilho pede, janela de 24 h respeitada.
 */
import { randomUUID } from 'node:crypto';
import { ok, type Result } from '../../compartilhado/result.ts';
import type { ContextoCaso } from '../../compartilhado/efeitos.ts';
import type { DadosFluxo } from '../../fluxo/model/fluxo.ts';
import {
  casaPalavras, gatilhoCasaComentario, noDe, normalizar, seguir,
  type CanalFluxo, type DadosAcao, type DadosCondicao, type DadosEspera, type DadosGatilho, type DadosMensagem, type DadosRespostaPublica, type No,
} from '../../fluxo/model/grafo.ts';
import { ErroCanal, type Agendador, type BotaoPendente, type CanalEnvio, type ContextoExecucao, type DadosExecucao, type PerfilContato, type RepoMotor, type Relogio } from '../model/portas.ts';

export const JANELA_MS = 24 * 3600 * 1000;
export const RESPOSTA_PRIVADA_MS = 7 * 24 * 3600 * 1000;
const MAX_PASSOS = 60;

export interface EventoComentario { comentario_id: string; post_id: string; texto: string; autor_id: string; autor_usuario?: string | null; autor_nome?: string | null; conta_usuario?: string | null; conta_id?: string | null; ocorrido_em?: string | null }
export interface EventoMensagem { mensagem_id: string; canal: CanalFluxo; contato: string; contato_nome?: string | null; conversa_id?: string | null; parceiro_id?: string | null; texto: string; ocorrida_em?: string | null }
export interface CliqueBroadcast { fluxo_id: string | null; envio_id: string; broadcast_id: string; parceiro_id: string }

export interface DepsMotor {
  repo: RepoMotor;
  canal: CanalEnvio;
  agendador: Agendador;
  relogio?: Relogio;
  /** Clique em botao de template de broadcast (devolve null quando o texto nao e clique de broadcast). */
  broadcast?: { registrarClique(telefone: string, texto: string, quando: Date): Promise<CliqueBroadcast | null> };
  aleatorio?: () => number;
}

export type Resultado = { tratado: boolean; execucoes: string[]; motivo?: string };

const prioridade = (f: DadosFluxo) => ((f.config_gatilho.palavras ?? []).some((p) => p.trim()) ? 0 : 1);
const payloadBotao = (fluxoId: string, noId: string, i: number) => `af1:${fluxoId}:${noId}:${i}`;

export class Motor {
  private readonly relogio: Relogio;
  constructor(private readonly d: DepsMotor) { this.relogio = d.relogio ?? { agora: () => new Date() }; }

  /** Comentario em post do Instagram (webhook comment.received ou varredura). */
  async aoComentario(ctx: ContextoCaso, ev: EventoComentario): Promise<Result<Resultado>> {
    if (ev.conta_usuario && ev.autor_usuario && normalizar(ev.conta_usuario) === normalizar(ev.autor_usuario)) return ok({ tratado: false, execucoes: [], motivo: 'comentario_da_propria_conta' });
    const fluxos = (await this.d.repo.fluxosAtivos('instagram', ['comentario_post']))
      .filter((f) => gatilhoCasaComentario(f.config_gatilho, ev))
      .filter((f) => casaPalavras(ev.texto, f.config_gatilho.palavras, f.config_gatilho.correspondencia ?? 'contem'))
      .sort((a, b) => prioridade(a) - prioridade(b) || a.id.localeCompare(b.id));
    if (!fluxos.length) return ok({ tratado: false, execucoes: [], motivo: 'sem_automacao' });
    for (const f of fluxos) {
      // Retry do mesmo comentario retoma a execucao existente; contato que ja recebeu o fluxo nao recebe de novo.
      const ja = await this.d.repo.execucaoPorChave(f.id, `comentario:${ev.comentario_id}`);
      if (!ja && f.config_gatilho.uma_vez_por_contato !== false && (await this.d.repo.jaExecutouParaContato(f.id, ev.autor_id))) continue;
      // Uma automacao por comentario: a primeira que casa reivindica (o Instagram aceita uma resposta privada).
      if (!ja && !(await this.d.repo.reivindicarComentario(ev.comentario_id, ev.post_id))) return ok({ tratado: false, execucoes: [], motivo: 'comentario_ja_tratado' });
      const id = await this.iniciar(ctx, f, {
        contato: ev.autor_id, contato_nome: ev.autor_nome ?? ev.autor_usuario ?? null, chave: `comentario:${ev.comentario_id}`,
        contexto: { texto: ev.texto, comentario_id: ev.comentario_id, post_id: ev.post_id, conta_id: ev.conta_id ?? f.config_gatilho.conta_id ?? null, autor_usuario: ev.autor_usuario ?? null, resposta_privada_usada: false },
        ultima_entrada_em: null, existente: ja,
      });
      return ok({ tratado: true, execucoes: id ? [id] : [] });
    }
    return ok({ tratado: false, execucoes: [], motivo: 'contato_ja_recebeu' });
  }

  /** Mensagem recebida (Conversas): clique em botao pendente, clique em template de broadcast ou palavra-chave. */
  async aoMensagem(ctx: ContextoCaso, ev: EventoMensagem): Promise<Result<Resultado>> {
    const quando = ev.ocorrida_em ? new Date(ev.ocorrida_em) : this.relogio.agora();
    const t = normalizar(ev.texto);
    // 1. Clique em botao de mensagem do fluxo (titulo ou payload af1).
    for (const x of await this.d.repo.aguardandoClique(ev.canal, ev.contato)) {
      const pend = this.botaoClicado(x, ev.texto);
      if (!pend) continue;
      const fluxo = await this.d.repo.fluxo(x.fluxo_id);
      if (!fluxo || fluxo.estado !== 'ativa') continue;
      const resto = { ...x.aguardando };
      delete resto[normalizar(pend.titulo)];
      const exec: DadosExecucao = { ...x, aguardando: resto, estado: 'em_andamento', ultima_entrada_em: quando.toISOString(), contexto: { ...x.contexto, texto: ev.texto } };
      await this.d.repo.registrarPasso({ execucao_id: x.id, fluxo_id: x.fluxo_id, no_id: pend.destino ?? pend.origem, tipo_no: 'botao', evento: 'clique', resultado: 'ok', detalhe: { botao: pend.titulo, origem: pend.origem } });
      if (pend.resposta) await this.enviar(exec, fluxo, `${pend.origem}:resposta:${pend.indice}`, { texto: pend.resposta, botoes: [] }, pend.origem);
      await this.executar(ctx, fluxo, exec, pend.destino);
      return ok({ tratado: true, execucoes: [x.id] });
    }
    // 2. Clique em botao de template de broadcast (WhatsApp).
    if (ev.canal === 'whatsapp' && this.d.broadcast) {
      const c = await this.d.broadcast.registrarClique(ev.contato, ev.texto, quando);
      if (c) {
        const fluxo = c.fluxo_id ? await this.d.repo.fluxo(c.fluxo_id) : null;
        if (!fluxo || fluxo.estado !== 'ativa') return ok({ tratado: true, execucoes: [], motivo: 'clique_broadcast_sem_automacao' });
        const id = await this.iniciar(ctx, fluxo, {
          contato: ev.contato, contato_nome: ev.contato_nome ?? null, chave: `broadcast:${c.envio_id}:${t}`.slice(0, 200), conversa_id: ev.conversa_id ?? null,
          parceiro_id: c.parceiro_id, contexto: { texto: ev.texto, broadcast_id: c.broadcast_id, envio_id: c.envio_id }, ultima_entrada_em: quando.toISOString(), clique: true,
        });
        return ok({ tratado: true, execucoes: id ? [id] : [] });
      }
    }
    // 3. Gatilhos de mensagem: clique em botao avulso e palavra-chave (com palavra primeiro).
    const fluxos = (await this.d.repo.fluxosAtivos(ev.canal, ['botao_clicado', 'mensagem_palavra']))
      .filter((f) => (f.gatilho === 'botao_clicado' ? normalizar(f.config_gatilho.botao ?? '') === t : casaPalavras(ev.texto, f.config_gatilho.palavras, f.config_gatilho.correspondencia ?? 'contem')))
      .sort((a, b) => (a.gatilho === 'botao_clicado' ? -1 : 0) - (b.gatilho === 'botao_clicado' ? -1 : 0) || prioridade(a) - prioridade(b) || a.id.localeCompare(b.id));
    for (const f of fluxos) {
      const chave = `mensagem:${ev.mensagem_id}`;
      const existente = await this.d.repo.execucaoPorChave(f.id, chave);
      if (!existente && f.config_gatilho.uma_vez_por_contato !== false && (await this.d.repo.jaExecutouParaContato(f.id, ev.contato))) continue;
      const id = await this.iniciar(ctx, f, {
        contato: ev.contato, contato_nome: ev.contato_nome ?? null, chave, conversa_id: ev.conversa_id ?? null, parceiro_id: ev.parceiro_id ?? null,
        contexto: { texto: ev.texto }, ultima_entrada_em: quando.toISOString(), existente,
      });
      return ok({ tratado: true, execucoes: id ? [id] : [] });
    }
    return ok({ tratado: false, execucoes: [], motivo: 'sem_automacao' });
  }

  /** Fim da espera: continua no no agendado. */
  async continuar(ctx: ContextoCaso, e: { execucao_id: string; no_id: string }): Promise<Result<Resultado>> {
    const x = await this.d.repo.execucao(e.execucao_id);
    if (!x || x.estado !== 'aguardando_tempo') return ok({ tratado: false, execucoes: [], motivo: 'execucao_nao_aguarda' });
    const fluxo = await this.d.repo.fluxo(x.fluxo_id);
    if (!fluxo || fluxo.estado !== 'ativa') {
      await this.d.repo.atualizarExecucao({ ...x, estado: 'cancelada', erro: 'automacao_pausada' });
      return ok({ tratado: false, execucoes: [x.id], motivo: 'automacao_pausada' });
    }
    await this.executar(ctx, fluxo, { ...x, estado: 'em_andamento' }, e.no_id);
    return ok({ tratado: true, execucoes: [x.id] });
  }

  private botaoClicado(x: DadosExecucao, texto: string): BotaoPendente | null {
    const m = /^af1:([0-9a-f-]{36}):([A-Za-z0-9:_-]{1,80}):(\d+)$/.exec(texto.trim());
    if (m) return Object.values(x.aguardando).find((b) => m[1] === x.fluxo_id && b.origem === m[2] && b.indice === Number(m[3])) ?? null;
    return x.aguardando[normalizar(texto)] ?? null;
  }

  private async iniciar(ctx: ContextoCaso, f: DadosFluxo, e: {
    contato: string; contato_nome: string | null; chave: string; contexto: ContextoExecucao; ultima_entrada_em: string | null;
    conversa_id?: string | null; parceiro_id?: string | null; existente?: DadosExecucao | null; clique?: boolean;
  }): Promise<string | null> {
    // Retry do mesmo evento: retoma do no em que parou (os envios levam chave de idempotencia).
    if (e.existente) {
      if (e.existente.estado !== 'em_andamento') return null;
      await this.executar(ctx, f, e.existente, e.existente.contexto.no_atual ?? f.grafo.entrada);
      return e.existente.id;
    }
    const perfil = await this.d.repo.perfil(f.canal, e.contato);
    const exec: DadosExecucao = {
      id: randomUUID(), fluxo_id: f.id, versao_fluxo: f.versao, canal: f.canal, contato: e.contato, contato_nome: e.contato_nome,
      conversa_id: e.conversa_id ?? perfil.conversa_id, parceiro_id: e.parceiro_id ?? perfil.parceiro_id, chave_evento: e.chave, estado: 'em_andamento',
      aguardando: {}, contexto: { ...e.contexto, no_atual: f.grafo.entrada }, ultima_entrada_em: e.ultima_entrada_em ?? perfil.ultima_entrada_em, erro: null,
    };
    if (!(await this.d.repo.criarExecucao(exec))) return null;
    await this.executar(ctx, f, exec, f.grafo.entrada);
    return exec.id;
  }

  /** Percorre o grafo a partir de `inicio` ate esperar (clique ou tempo) ou terminar. */
  private async executar(ctx: ContextoCaso, f: DadosFluxo, exec: DadosExecucao, inicio: string | null): Promise<void> {
    let atual = inicio;
    let x = exec;
    for (let passos = 0; atual && passos < MAX_PASSOS; passos++) {
      const no = noDe(f.grafo, atual);
      if (!no) break;
      x = { ...x, contexto: { ...x.contexto, no_atual: no.id } };
      await this.d.repo.atualizarExecucao(x);
      const r = await this.passo(ctx, f, x, no);
      x = r.exec;
      if (r.parar) return;
      atual = r.proximo;
    }
    const pendentes = Object.keys(x.aguardando).length > 0;
    const final: DadosExecucao = { ...x, estado: pendentes ? 'aguardando_clique' : x.estado === 'falhou' ? 'falhou' : 'concluida', contexto: { ...x.contexto, no_atual: null } };
    await this.d.repo.atualizarExecucao(final);
    if (final.estado === 'concluida' || final.estado === 'falhou') {
      await ctx.efeitos.publicar('automacao.execucao_concluida', { id: final.id, fluxo_id: f.id, canal: f.canal, contato: final.contato, parceiro_id: final.parceiro_id, estado: final.estado });
    }
  }

  private async passo(ctx: ContextoCaso, f: DadosFluxo, x: DadosExecucao, no: No): Promise<{ exec: DadosExecucao; proximo: string | null; parar?: boolean }> {
    const reg = (resultado: 'ok' | 'falhou' | 'ignorado' | 'aguardando', detalhe: Record<string, unknown> = {}, id_externo: string | null = null) =>
      this.d.repo.registrarPasso({ execucao_id: x.id, fluxo_id: f.id, no_id: no.id, tipo_no: no.tipo, evento: 'disparo', resultado, detalhe, id_externo });
    const saida = () => seguir(f.grafo, no.id, 'saida');
    switch (no.tipo) {
      case 'gatilho':
        await reg('ok', { gatilho: (no.dados as DadosGatilho).tipo });
        return { exec: x, proximo: saida() };
      case 'fim':
        await reg('ok');
        return { exec: x, proximo: null };
      case 'resposta_publica': {
        const { comentario_id, post_id } = x.contexto;
        if (!comentario_id || !post_id) { await reg('ignorado', { motivo: 'sem_comentario' }); return { exec: x, proximo: saida() }; }
        const opcoes = (no.dados as DadosRespostaPublica).respostas;
        const texto = opcoes[Math.floor((this.d.aleatorio ?? Math.random)() * opcoes.length)] ?? opcoes[0]!;
        try {
          const r = await this.d.canal.responderComentario({ post_id, comentario_id, conta_id: x.contexto.conta_id ?? null, texto: this.preencher(texto, x), chave: `${f.id}:${x.chave_evento}:${no.id}` });
          await reg('ok', { texto }, r.id_externo);
        } catch (e) {
          if (!(e instanceof ErroCanal) || !e.permanente) throw e;
          await reg('falhou', { erro: e.message });
        }
        return { exec: x, proximo: saida() };
      }
      case 'mensagem': {
        const d = no.dados as DadosMensagem;
        const botoes = (d.botoes ?? []).map((b, i) => ({ ...b, payload: payloadBotao(f.id, no.id, i) }));
        const r = await this.enviar(x, f, no.id, { texto: this.preencher(d.texto ?? '', x), midia_url: d.midia_url, midia_tipo: d.midia_tipo, botoes, template_id: d.template_id, parametros: d.parametros }, no.id);
        let exec = r.exec;
        if (r.resultado === 'ok') {
          const pend: Record<string, BotaoPendente> = { ...exec.aguardando };
          botoes.forEach((b, i) => {
            if (b.tipo !== 'resposta') return;
            const destino = seguir(f.grafo, no.id, `botao:${i}`);
            if (destino || b.resposta) pend[normalizar(b.titulo)] = { destino, origem: no.id, indice: i, titulo: b.titulo, resposta: b.resposta ?? null };
          });
          exec = { ...exec, aguardando: pend };
        }
        return { exec, proximo: r.resultado === 'falhou' ? null : saida() };
      }
      case 'condicao': {
        const c = no.dados as DadosCondicao;
        const perfil = await this.d.repo.perfil(f.canal, x.contato);
        const sim = this.avaliar(c, x, perfil);
        await reg('ok', { resultado: sim ? 'sim' : 'nao' });
        return { exec: x, proximo: seguir(f.grafo, no.id, sim ? 'sim' : 'nao') };
      }
      case 'espera': {
        const prox = saida();
        if (!prox) { await reg('ok'); return { exec: x, proximo: null }; }
        const min = (no.dados as DadosEspera).minutos;
        await this.d.agendador.continuarDepois(x.id, prox, min);
        await reg('aguardando', { minutos: min, proximo: prox });
        const exec: DadosExecucao = { ...x, estado: 'aguardando_tempo', contexto: { ...x.contexto, no_atual: prox } };
        await this.d.repo.atualizarExecucao(exec);
        return { exec, proximo: null, parar: true };
      }
      case 'acao': {
        const a = no.dados as DadosAcao;
        const perfil = await this.d.repo.perfil(f.canal, x.contato);
        const parceiro = x.parceiro_id ?? perfil.parceiro_id;
        const base = { execucao_id: x.id, fluxo_id: f.id, no_id: no.id, canal: f.canal, contato: x.contato, nome: x.contato_nome, parceiro_id: parceiro };
        if (a.tipo === 'cliente' || a.tipo === 'tag') {
          if (a.tipo === 'tag' && !parceiro) { await reg('ignorado', { motivo: 'sem_cliente' }); return { exec: x, proximo: saida() }; }
          await ctx.efeitos.publicar('automacao.cliente_solicitado', { ...base, telefone: f.canal === 'whatsapp' ? x.contato : perfil.telefone, usuario: x.contexto.autor_usuario ?? null, tags: (a.tags ?? []).map((t) => t.trim()).filter(Boolean), so_tags: a.tipo === 'tag' });
          await reg('ok', { acao: a.tipo, tags: a.tags ?? [] });
        } else {
          if (!parceiro) { await reg('ignorado', { motivo: 'sem_cliente' }); return { exec: x, proximo: saida() }; }
          await ctx.efeitos.publicar('automacao.oportunidade_solicitada', { ...base, funil_id: a.funil_id ?? null, etapa_id: a.etapa_id, titulo: (a.titulo || `${f.nome}: ${x.contato_nome ?? x.contato}`).slice(0, 200) });
          await reg('ok', { acao: 'oportunidade', etapa_id: a.etapa_id });
        }
        return { exec: { ...x, parceiro_id: parceiro }, proximo: saida() };
      }
    }
    return { exec: x, proximo: null };
  }

  private avaliar(c: DadosCondicao, x: DadosExecucao, p: PerfilContato): boolean {
    const v = normalizar(c.valor ?? '');
    switch (c.campo) {
      case 'texto': { const t = normalizar(x.contexto.texto ?? ''); return c.operador === 'existe' ? !!t : c.operador === 'igual' ? t === v : t.includes(v); }
      case 'tag': { const tags = p.tags.map(normalizar); return c.operador === 'existe' ? tags.length > 0 : c.operador === 'igual' ? tags.includes(v) : tags.some((t) => t.includes(v)); }
      case 'e_cliente': return p.e_cliente;
      case 'tem_telefone': return !!p.telefone || x.canal === 'whatsapp';
    }
    return false;
  }

  private preencher(texto: string, x: DadosExecucao): string {
    const nome = (x.contato_nome ?? '').trim();
    return texto.replace(/\{\{\s*primeiro_nome\s*\}\}/g, nome.split(/\s+/)[0] ?? '').replace(/\{\{\s*nome\s*\}\}/g, nome).replace(/\{\{\s*usuario\s*\}\}/g, x.contexto.autor_usuario ?? '');
  }

  /**
   * Entrega uma mensagem respeitando a janela: no Instagram a primeira mensagem de um comentario sai como resposta
   * privada (7 dias); depois, e no WhatsApp, so ate 24 h da ultima entrada do contato. Fora da janela o WhatsApp
   * usa o template aprovado do no; sem template o passo e ignorado com motivo.
   */
  private async enviar(x: DadosExecucao, f: DadosFluxo, noId: string, m: { texto: string; midia_url?: string | null; midia_tipo?: string | null; botoes: MensagemBotoes; template_id?: string | null; parametros?: string[] }, noReg: string): Promise<{ exec: DadosExecucao; resultado: 'ok' | 'falhou' | 'ignorado' }> {
    const agora = this.relogio.agora().getTime();
    const chave = `${f.id}:${x.chave_evento}:${noId}`;
    const reg = (resultado: 'ok' | 'falhou' | 'ignorado', detalhe: Record<string, unknown>, id_externo: string | null = null) =>
      this.d.repo.registrarPasso({ execucao_id: x.id, fluxo_id: f.id, no_id: noReg, tipo_no: 'mensagem', evento: 'disparo', resultado, detalhe, id_externo });
    try {
      if (f.canal === 'instagram' && x.contexto.comentario_id && x.contexto.post_id && !x.contexto.resposta_privada_usada) {
        const r = await this.d.canal.respostaPrivada({ post_id: x.contexto.post_id, comentario_id: x.contexto.comentario_id, conta_id: x.contexto.conta_id ?? null, texto: m.texto, botoes: m.botoes, chave });
        await reg('ok', { via: 'resposta_privada', botoes: m.botoes.length }, r.id_externo);
        return { exec: { ...x, contexto: { ...x.contexto, resposta_privada_usada: true } }, resultado: 'ok' };
      }
      const dentro = !!x.ultima_entrada_em && agora - new Date(x.ultima_entrada_em).getTime() <= JANELA_MS;
      if (!dentro) {
        if (f.canal === 'whatsapp' && m.template_id) {
          const t = await this.d.repo.template(m.template_id);
          if (!t || t.estado !== 'aprovado') { await reg('ignorado', { motivo: 'template_nao_aprovado' }); return { exec: x, resultado: 'ignorado' }; }
          const r = await this.d.canal.enviarTemplate({ telefone: x.contato, nome: t.nome, idioma: t.idioma, parametros: m.parametros ?? [], chave });
          await reg('ok', { via: 'template', template: t.nome }, r.id_externo);
          return { exec: x, resultado: 'ok' };
        }
        await reg('ignorado', { motivo: f.canal === 'whatsapp' ? 'janela_24h_fechada' : 'janela_instagram_fechada' });
        return { exec: x, resultado: 'ignorado' };
      }
      const r = await this.d.canal.enviarMensagem({ canal: f.canal, contato: x.contato, texto: m.texto, midia_url: m.midia_url, midia_tipo: m.midia_tipo, botoes: m.botoes, chave });
      await reg('ok', { via: 'mensagem', botoes: m.botoes.length }, r.id_externo);
      return { exec: x, resultado: 'ok' };
    } catch (e) {
      if (!(e instanceof ErroCanal) || !e.permanente) throw e;
      await reg('falhou', { erro: e.message });
      return { exec: { ...x, estado: 'falhou', erro: e.message.slice(0, 300) }, resultado: 'falhou' };
    }
  }
}

type MensagemBotoes = Parameters<CanalEnvio['enviarMensagem']>[0]['botoes'];
