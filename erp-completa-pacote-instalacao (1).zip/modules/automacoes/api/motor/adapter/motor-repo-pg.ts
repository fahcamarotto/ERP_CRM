/** Adaptador Postgres do motor: fluxos ativos, execucoes, passos, comentarios vistos, perfil do contato e fila. */
import type pg from 'pg';
import type { DadosFluxo } from '../../fluxo/model/fluxo.ts';
import type { CanalFluxo, TipoGatilho } from '../../fluxo/model/grafo.ts';
import type { Agendador, DadosExecucao, Passo, PerfilContato, RepoMotor, TemplateRef } from '../model/portas.ts';

export const TIPO_JOB_CONTINUAR = 'automacoes.continuar';
export const COLUNAS_FLUXO = `id, nome, canal, gatilho, config_gatilho, grafo, versao, estado, ativada_em`;
const COLUNAS_EXEC = `id, fluxo_id, versao_fluxo, canal, contato, contato_nome, conversa_id, parceiro_id, chave_evento, estado, aguardando, contexto, ultima_entrada_em, erro`;

const iso = (v: unknown): string | null => (v === null || v === undefined ? null : v instanceof Date ? v.toISOString() : new Date(String(v)).toISOString());
export const fluxoDaLinha = (r: Record<string, unknown>): DadosFluxo => ({ ...(r as unknown as DadosFluxo), ativada_em: iso(r.ativada_em) });
const execDaLinha = (r: Record<string, unknown>): DadosExecucao => ({ ...(r as unknown as DadosExecucao), ultima_entrada_em: iso(r.ultima_entrada_em) });

export class MotorRepoPg implements RepoMotor, Agendador {
  constructor(private readonly c: pg.PoolClient) {}

  async fluxosAtivos(canal: CanalFluxo, gatilhos: TipoGatilho[]) {
    const r = await this.c.query(`SELECT ${COLUNAS_FLUXO} FROM automacoes_fluxos WHERE estado = 'ativa' AND canal = $1 AND gatilho = ANY ($2::text[]) AND deleted_at IS NULL`, [canal, gatilhos]);
    return r.rows.map(fluxoDaLinha);
  }

  async fluxo(id: string) {
    const r = await this.c.query(`SELECT ${COLUNAS_FLUXO} FROM automacoes_fluxos WHERE id = $1 AND deleted_at IS NULL`, [id]);
    return r.rows[0] ? fluxoDaLinha(r.rows[0]) : null;
  }

  async criarExecucao(x: DadosExecucao) {
    const r = await this.c.query(
      `INSERT INTO automacoes_execucoes (id, fluxo_id, versao_fluxo, canal, contato, contato_nome, conversa_id, parceiro_id, chave_evento, estado, aguardando, contexto, ultima_entrada_em)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13)
       ON CONFLICT (tenant_id, workspace_id, fluxo_id, chave_evento) DO NOTHING RETURNING id`,
      [x.id, x.fluxo_id, x.versao_fluxo, x.canal, x.contato, x.contato_nome?.slice(0, 200) ?? null, x.conversa_id, x.parceiro_id, x.chave_evento, x.estado, JSON.stringify(x.aguardando), JSON.stringify(x.contexto), x.ultima_entrada_em],
    );
    return (r.rowCount ?? 0) > 0;
  }

  async execucaoPorChave(fluxoId: string, chave: string) {
    const r = await this.c.query(`SELECT ${COLUNAS_EXEC} FROM automacoes_execucoes WHERE fluxo_id = $1 AND chave_evento = $2`, [fluxoId, chave]);
    return r.rows[0] ? execDaLinha(r.rows[0]) : null;
  }

  async execucao(id: string) {
    const r = await this.c.query(`SELECT ${COLUNAS_EXEC} FROM automacoes_execucoes WHERE id = $1 FOR UPDATE`, [id]);
    return r.rows[0] ? execDaLinha(r.rows[0]) : null;
  }

  async atualizarExecucao(x: DadosExecucao) {
    await this.c.query(
      `UPDATE automacoes_execucoes SET estado = $2, aguardando = $3, contexto = $4, ultima_entrada_em = $5, erro = $6, parceiro_id = $7,
         concluida_em = CASE WHEN $2 IN ('concluida', 'falhou', 'cancelada') THEN coalesce(concluida_em, now()) ELSE NULL END
       WHERE id = $1`,
      [x.id, x.estado, JSON.stringify(x.aguardando), JSON.stringify(x.contexto), x.ultima_entrada_em, x.erro, x.parceiro_id],
    );
  }

  async aguardandoClique(canal: CanalFluxo, contato: string) {
    const r = await this.c.query(
      `SELECT ${COLUNAS_EXEC} FROM automacoes_execucoes WHERE canal = $1 AND contato = $2 AND estado = 'aguardando_clique' AND deleted_at IS NULL
       AND updated_at > now() - interval '7 days' ORDER BY updated_at DESC LIMIT 20 FOR UPDATE`,
      [canal, contato],
    );
    return r.rows.map(execDaLinha);
  }

  async jaExecutouParaContato(fluxoId: string, contato: string) {
    return ((await this.c.query(`SELECT 1 FROM automacoes_execucoes WHERE fluxo_id = $1 AND contato = $2 AND deleted_at IS NULL LIMIT 1`, [fluxoId, contato])).rowCount ?? 0) > 0;
  }

  async registrarPasso(p: Passo) {
    await this.c.query(
      `INSERT INTO automacoes_passos (execucao_id, fluxo_id, no_id, tipo_no, evento, resultado, detalhe, id_externo) VALUES ($1, $2, $3, $4, $5, $6, $7, $8)`,
      [p.execucao_id, p.fluxo_id, p.no_id, p.tipo_no, p.evento, p.resultado, JSON.stringify(p.detalhe ?? {}), p.id_externo ?? null],
    );
  }

  async reivindicarComentario(comentarioId: string, postId: string | null) {
    const r = await this.c.query(
      `INSERT INTO automacoes_comentarios_vistos (comentario_id, post_id) VALUES ($1, $2) ON CONFLICT (tenant_id, workspace_id, comentario_id) DO NOTHING RETURNING id`,
      [comentarioId, postId],
    );
    return (r.rowCount ?? 0) > 0;
  }

  /** Conversa (tabela publicada do Conversas) e cliente (tabela publicada do Cadastros) do contato. */
  async perfil(canal: CanalFluxo, contato: string): Promise<PerfilContato> {
    const cv = (await this.c.query(
      `SELECT id, parceiro_id, ultima_entrada_em FROM conversas_conversas WHERE canal = $1 AND contato_externo = $2 AND deleted_at IS NULL LIMIT 1`,
      [canal, contato],
    )).rows[0] as { id: string; parceiro_id: string | null; ultima_entrada_em: Date | null } | undefined;
    let parceiroId = cv?.parceiro_id ?? null;
    if (!parceiroId && canal === 'whatsapp') {
      parceiroId = ((await this.c.query(`SELECT id FROM cadastros_parceiros WHERE telefone = $1 AND deleted_at IS NULL ORDER BY created_at LIMIT 1`, [contato])).rows[0]?.id as string | undefined) ?? null;
    }
    const p = parceiroId
      ? ((await this.c.query(
          `SELECT p.e_cliente, p.telefone, coalesce((SELECT array_agg(c.nome) FROM cadastros_parceiro_tags t JOIN cadastros_classificacoes c ON c.id = t.tag_id AND c.deleted_at IS NULL
             WHERE t.parceiro_id = p.id AND t.deleted_at IS NULL), '{}') AS tags
           FROM cadastros_parceiros p WHERE p.id = $1 AND p.deleted_at IS NULL`,
          [parceiroId],
        )).rows[0] as { e_cliente: boolean; telefone: string | null; tags: string[] } | undefined)
      : undefined;
    return { parceiro_id: p ? parceiroId : null, e_cliente: !!p?.e_cliente, telefone: p?.telefone ?? null, tags: p?.tags ?? [], conversa_id: cv?.id ?? null, ultima_entrada_em: iso(cv?.ultima_entrada_em) };
  }

  async template(id: string): Promise<TemplateRef | null> {
    const r = await this.c.query(`SELECT id, nome, idioma, estado, botoes FROM automacoes_templates WHERE id = $1 AND deleted_at IS NULL`, [id]);
    const t = r.rows[0];
    return t ? { id: t.id, nome: t.nome, idioma: t.idioma, estado: t.estado, botoes: (t.botoes as { tipo: string; texto: string }[]).map((b) => ({ tipo: b.tipo, texto: b.texto })) } : null;
  }

  async continuarDepois(execucaoId: string, noId: string, minutos: number) {
    await this.c.query(`INSERT INTO outbox (tipo, payload, disponivel_em) VALUES ($1, $2, now() + make_interval(mins => $3))`, [TIPO_JOB_CONTINUAR, JSON.stringify({ execucao_id: execucaoId, no_id: noId }), minutos]);
  }
}

/** Fila do modulo na outbox do nucleo, com atraso opcional (rate limit e agendamento). */
export class FilaOutboxPg {
  constructor(private readonly c: pg.PoolClient) {}
  async agendar(tipo: string, payload: Record<string, unknown>, atrasoSeg: number): Promise<string> {
    return (await this.c.query(`INSERT INTO outbox (tipo, payload, disponivel_em) VALUES ($1, $2, now() + make_interval(secs => $3)) RETURNING id`, [tipo, JSON.stringify(payload), atrasoSeg])).rows[0].id as string;
  }
}
