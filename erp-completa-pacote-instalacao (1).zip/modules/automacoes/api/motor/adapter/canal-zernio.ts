/**
 * Adaptador do canal de envio pela Zernio. A conta (accountId) e a conversa (conversationId) saem das tabelas do
 * Integracoes que guardam o vinculo do canal da subconta (leitura sob RLS, escopo do workspace).
 * Botoes: Instagram com so respostas vira quickReplies; com link vira button template (ate 3). WhatsApp: respostas
 * viram botoes de resposta (payload); um link vira interactive cta_url.
 */
import type pg from 'pg';
import type { Botao, CanalFluxo } from '../../fluxo/model/grafo.ts';
import { ClienteZernioAutomacoes } from '../../zernio/cliente.ts';
import { ErroCanal, type CanalEnvio, type MensagemSaida } from '../model/portas.ts';

type BotaoSaida = Botao & { payload: string };

export async function contaAtiva(c: pg.PoolClient, canal: CanalFluxo): Promise<{ conta_id: string; usuario: string | null } | null> {
  const r = await c.query(
    `SELECT conta_id, usuario FROM integracoes_canais WHERE canal = $1 AND estado = 'ativo' AND deleted_at IS NULL ORDER BY conectado_em DESC NULLS LAST LIMIT 1`,
    [canal],
  );
  return (r.rows[0] as { conta_id: string; usuario: string | null } | undefined) ?? null;
}

function botoesInstagram(bs: BotaoSaida[]): Record<string, unknown> {
  if (!bs.length) return {};
  if (bs.every((b) => b.tipo === 'resposta')) return { quickReplies: bs.map((b) => ({ title: b.titulo, payload: b.payload })) };
  return { buttons: bs.slice(0, 3).map((b) => (b.tipo === 'url' ? { type: 'url', title: b.titulo, url: b.url } : { type: 'postback', title: b.titulo, payload: b.payload })) };
}

function corpoWhatsapp(texto: string, bs: BotaoSaida[]): Record<string, unknown> {
  const link = bs.find((b) => b.tipo === 'url');
  if (link) return { interactive: { type: 'cta_url', body: { text: texto || link.titulo }, action: { name: 'cta_url', parameters: { display_text: link.titulo, url: link.url } } } };
  return { message: texto, ...(bs.length ? { buttons: bs.map((b) => ({ type: 'postback', title: b.titulo, payload: b.payload })) } : {}) };
}

export class CanalZernioPg implements CanalEnvio {
  constructor(private readonly c: pg.PoolClient, private readonly api = new ClienteZernioAutomacoes()) {}

  private async conta(canal: CanalFluxo): Promise<string> {
    const x = await contaAtiva(this.c, canal);
    if (!x) throw new ErroCanal(`canal ${canal} nao conectado (Integracoes > Conectores)`, true);
    return x.conta_id;
  }

  private async conversa(canal: CanalFluxo, contato: string): Promise<string | null> {
    const r = await this.c.query(
      `SELECT conversa_externa_id FROM integracoes_zernio_conversas WHERE canal = $1 AND contato IN ($2, ltrim($2, '+')) AND deleted_at IS NULL
       ORDER BY updated_at DESC LIMIT 1`,
      [canal, contato],
    );
    return (r.rows[0]?.conversa_externa_id as string | undefined) ?? null;
  }

  async responderComentario(e: { post_id: string; comentario_id: string; texto: string; chave: string; conta_id?: string | null }) {
    return this.api.responderComentario(e.conta_id ?? await this.conta('instagram'), e.post_id, e.comentario_id, e.texto, `pub:${e.chave}`);
  }

  async respostaPrivada(e: { post_id: string; comentario_id: string; texto: string; botoes: BotaoSaida[]; chave: string; conta_id?: string | null }) {
    return this.api.respostaPrivada(e.conta_id ?? await this.conta('instagram'), e.post_id, e.comentario_id, { message: e.texto, ...botoesInstagram(e.botoes) }, `dm:${e.chave}`);
  }

  async enviarMensagem(m: MensagemSaida) {
    const conta = await this.conta(m.canal);
    const conversa = await this.conversa(m.canal, m.contato);
    if (!conversa) throw new ErroCanal('conversa do contato ainda nao existe na Zernio', true);
    const midia = m.midia_url ? { attachmentUrl: m.midia_url, attachmentType: m.midia_tipo ?? 'image' } : {};
    const corpo = m.canal === 'instagram' ? { message: m.texto, ...botoesInstagram(m.botoes), ...midia } : { ...corpoWhatsapp(m.texto, m.botoes), ...midia };
    return this.api.enviarNaConversa(conta, conversa, corpo, `msg:${m.chave}`);
  }

  async enviarTemplate(e: { telefone: string; nome: string; idioma: string; parametros: string[]; chave: string }) {
    const r = await this.api.enviarTemplate(await this.conta('whatsapp'), e.telefone.replace(/^\+/, ''), e.nome, e.idioma, e.parametros, `tpl:${e.chave}`);
    return { id_externo: r.id_externo };
  }
}
