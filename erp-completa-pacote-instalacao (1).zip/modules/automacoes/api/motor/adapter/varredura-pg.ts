/**
 * Varredura dos comentarios do Instagram (caminho automatico sem URL publica, igual a importacao do Integracoes).
 * Para cada conta com automacao ativa de comentario: posts especificos tem os comentarios lidos a cada passada; no
 * modo geral le os posts recentes da conta (ate LIMITE_POSTS_GERAL, seguindo o cursor da Zernio), grava o cache e
 * so rele o post cuja contagem de comentarios mudou. Comentario anterior a ativacao e ignorado; o motor e idempotente
 * (comentario visto uma vez). Reagenda a cada 2 min enquanto houver automacao de comentario ativa. Com o webhook
 * comment.received o disparo fica em tempo real.
 */
import type pg from 'pg';
import type { ContextoCaso } from '../../compartilhado/efeitos.ts';
import { ok, type Result } from '../../compartilhado/result.ts';
import type { DadosGatilho } from '../../fluxo/model/grafo.ts';
import { gravarCachePosts } from '../../instagram/posts.ts';
import type { ClienteZernioAutomacoes, PostZernio } from '../../zernio/cliente.ts';
import { LIMITE_POSTS_GERAL, PAGINA_POSTS_GERAL, planejarVarredura, precisaReler, type ContaInstagram, type PlanoConta } from '../model/varredura.ts';
import type { Motor } from '../use-case/motor.ts';

export const TIPO_JOB_VARRER = 'automacoes.varrer_comentarios';
export const INTERVALO_VARREDURA_SEG = 120;

type Totais = { automacoes: number; posts: number; comentarios: number; disparos: number };

export class VarrerComentarios {
  constructor(private readonly d: { c: pg.PoolClient; motor: Motor; zernio: ClienteZernioAutomacoes; fila: { agendar(tipo: string, p: Record<string, unknown>, s: number): Promise<string> } }) {}

  /** Agenda a varredura se nao houver outra pendente (uma corrente por workspace). */
  async garantirAgendada(atrasoSeg = 0): Promise<void> {
    const ja = await this.d.c.query(`SELECT 1 FROM outbox WHERE tipo = $1 AND estado IN ('pendente', 'despachado') AND deleted_at IS NULL LIMIT 1`, [TIPO_JOB_VARRER]);
    if (!ja.rowCount) await this.d.fila.agendar(TIPO_JOB_VARRER, {}, atrasoSeg);
  }

  async execute(ctx: ContextoCaso): Promise<Result<Totais>> {
    const fluxos = (await this.d.c.query(
      `SELECT id, config_gatilho, ativada_em FROM automacoes_fluxos
       WHERE estado = 'ativa' AND canal = 'instagram' AND gatilho = 'comentario_post' AND deleted_at IS NULL`,
    )).rows as { id: string; config_gatilho: DadosGatilho; ativada_em: Date }[];
    const t: Totais = { automacoes: fluxos.length, posts: 0, comentarios: 0, disparos: 0 };
    if (!fluxos.length) return ok(t);
    const contas = (await this.d.c.query(
      `SELECT id, conta_id, usuario FROM integracoes_canais WHERE canal = 'instagram' AND estado = 'ativo' AND deleted_at IS NULL ORDER BY conectado_em DESC NULLS LAST`,
    )).rows as ContaInstagram[];
    const planos = planejarVarredura(fluxos.map((f) => ({ id: f.id, config: f.config_gatilho ?? { tipo: 'comentario_post' }, ativada_em: new Date(f.ativada_em) })), contas);
    for (const p of planos) {
      for (const [post, desde] of p.posts) await this.lerPost(ctx, p, post, desde, t);
      if (p.geral_desde) await this.varrerGeral(ctx, p, p.geral_desde, t);
    }
    await this.d.fila.agendar(TIPO_JOB_VARRER, {}, INTERVALO_VARREDURA_SEG);
    return ok(t);
  }

  /** Modo geral: posts recentes da conta com limite e cursor; rele so o post com contagem de comentarios nova. */
  private async varrerGeral(ctx: ContextoCaso, p: PlanoConta, desde: Date, t: Totais): Promise<void> {
    const posts: PostZernio[] = [];
    let cursor: string | null = null;
    do {
      const pg = await this.d.zernio.postsDaConta(p.conta_id, { limite: Math.min(PAGINA_POSTS_GERAL, LIMITE_POSTS_GERAL - posts.length), cursor });
      posts.push(...pg.itens);
      cursor = pg.proximo_cursor;
    } while (cursor && posts.length < LIMITE_POSTS_GERAL);
    await gravarCachePosts(this.d.c, p.conta_id, posts);
    const vistos = new Map((await this.d.c.query(
      `SELECT post_id, comentarios_varridos FROM automacoes_posts_instagram WHERE conta_id = $1 AND post_id = ANY($2::text[])`,
      [p.conta_id, posts.map((x) => x.id)],
    )).rows.map((r) => [r.post_id as string, r.comentarios_varridos as number | null]));
    for (const x of posts) {
      if (p.posts.has(x.id) || !precisaReler(x.comentarios, vistos.get(x.id) ?? null)) continue;
      await this.lerPost(ctx, p, x.id, desde, t);
      await this.d.c.query(
        `UPDATE automacoes_posts_instagram SET comentarios_varridos = $3 WHERE conta_id = $1 AND post_id = $2`,
        [p.conta_id, x.id, x.comentarios],
      );
    }
  }

  private async lerPost(ctx: ContextoCaso, p: PlanoConta, post: string, desde: Date, t: Totais): Promise<void> {
    t.posts++;
    for (const cm of await this.d.zernio.comentarios(p.conta_id, post)) {
      if (cm.criado_em && Date.parse(cm.criado_em) < desde.getTime()) continue;
      t.comentarios++;
      const r = await this.d.motor.aoComentario(ctx, {
        comentario_id: cm.id, post_id: post, texto: cm.texto, autor_id: cm.autor_id, autor_usuario: cm.autor_usuario, autor_nome: cm.autor_nome,
        conta_usuario: p.conta_usuario, conta_id: p.conta_id, ocorrido_em: cm.criado_em,
      });
      if (r.ok && r.valor.tratado) t.disparos++;
    }
  }
}
