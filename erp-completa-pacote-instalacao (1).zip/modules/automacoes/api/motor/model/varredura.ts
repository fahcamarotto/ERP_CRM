/**
 * Plano da varredura de comentarios do Instagram (funcao pura): agrupa as automacoes ativas de comentario por conta
 * do canal escolhido no gatilho. Modo geral vale para todos os posts da conta (le os posts recentes com limite e
 * cursor); modo especificos so para os posts escolhidos. Cada post ou conta guarda a ativacao mais antiga, para
 * ignorar comentario feito antes de a automacao existir.
 */
import { alvoPosts, type DadosGatilho } from '../../fluxo/model/grafo.ts';

export interface FluxoVarredura { id: string; config: DadosGatilho; ativada_em: Date }
export interface ContaInstagram { id: string; conta_id: string; usuario: string | null }
export interface PlanoConta { conta_id: string; conta_usuario: string | null; geral_desde: Date | null; posts: Map<string, Date> }

/** Posts recentes lidos por varredura no modo geral (pagina da Zernio de ate 25, seguindo o cursor ate o limite). */
export const LIMITE_POSTS_GERAL = 30;
export const PAGINA_POSTS_GERAL = 25;

const menor = (a: Date | null | undefined, b: Date) => (a && a < b ? a : b);

/** Conta do gatilho: canal escolhido (id do canal ou accountId); sem escolha, o canal Instagram mais recente. */
export function contaDoGatilho(g: DadosGatilho, contas: ContaInstagram[]): ContaInstagram | null {
  if (g.canal_id) return contas.find((x) => x.id === g.canal_id) ?? null;
  if (g.conta_id) return contas.find((x) => x.conta_id === g.conta_id) ?? null;
  return contas[0] ?? null;
}

export function planejarVarredura(fluxos: FluxoVarredura[], contas: ContaInstagram[]): PlanoConta[] {
  const planos = new Map<string, PlanoConta>();
  for (const f of fluxos) {
    const conta = contaDoGatilho(f.config, contas);
    if (!conta) continue;
    const p = planos.get(conta.conta_id) ?? { conta_id: conta.conta_id, conta_usuario: conta.usuario, geral_desde: null, posts: new Map<string, Date>() };
    const alvo = alvoPosts(f.config);
    if (alvo.geral) p.geral_desde = menor(p.geral_desde, f.ativada_em);
    else for (const id of alvo.ids) p.posts.set(id, menor(p.posts.get(id), f.ativada_em));
    planos.set(conta.conta_id, p);
  }
  return [...planos.values()];
}

/** No modo geral, reler os comentarios do post so quando a contagem mudou desde a ultima leitura (ou e desconhecida). */
export function precisaReler(comentarios: number | null, varridos: number | null): boolean {
  if (comentarios === null) return true;
  if (comentarios === 0) return false;
  return comentarios !== varridos;
}
