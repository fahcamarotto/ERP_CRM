/** Portas do motor de execucao: repositorio das execucoes, canal de envio (Zernio) e agendador da fila. */
import type { DadosFluxo } from '../../fluxo/model/fluxo.ts';
import type { Botao, CanalFluxo, TipoGatilho } from '../../fluxo/model/grafo.ts';

export type EstadoExecucao = 'em_andamento' | 'aguardando_clique' | 'aguardando_tempo' | 'concluida' | 'falhou' | 'cancelada';

/** Botao pendente: titulo normalizado -> no de destino (null = so responde) e resposta do botao. */
export interface BotaoPendente { destino: string | null; origem: string; indice: number; titulo: string; resposta: string | null }

export interface ContextoExecucao {
  texto?: string | null;
  comentario_id?: string | null;
  post_id?: string | null;
  /** Conta da Zernio (accountId) que recebeu o comentario: a resposta sai pela mesma conta. */
  conta_id?: string | null;
  autor_usuario?: string | null;
  /** O Instagram aceita uma resposta privada por comentario: a primeira mensagem usa e marca. */
  resposta_privada_usada?: boolean;
  broadcast_id?: string | null;
  envio_id?: string | null;
  /** No em execucao (retomada idempotente no retry do job). */
  no_atual?: string | null;
}

export interface DadosExecucao {
  id: string;
  fluxo_id: string;
  versao_fluxo: number;
  canal: CanalFluxo;
  contato: string;
  contato_nome: string | null;
  conversa_id: string | null;
  parceiro_id: string | null;
  chave_evento: string;
  estado: EstadoExecucao;
  aguardando: Record<string, BotaoPendente>;
  contexto: ContextoExecucao;
  ultima_entrada_em: string | null;
  erro: string | null;
}

export interface Passo {
  execucao_id: string;
  fluxo_id: string;
  no_id: string;
  tipo_no: string;
  evento: 'disparo' | 'clique';
  resultado: 'ok' | 'falhou' | 'ignorado' | 'aguardando';
  detalhe?: Record<string, unknown>;
  id_externo?: string | null;
}

export interface PerfilContato { parceiro_id: string | null; e_cliente: boolean; telefone: string | null; tags: string[]; conversa_id: string | null; ultima_entrada_em: string | null }
export interface TemplateRef { id: string; nome: string; idioma: string; estado: string; botoes: { tipo: string; texto: string }[] }

export interface RepoMotor {
  fluxosAtivos(canal: CanalFluxo, gatilhos: TipoGatilho[]): Promise<DadosFluxo[]>;
  fluxo(id: string): Promise<DadosFluxo | null>;
  /** Insere; false quando a chave do evento ja existe (idempotencia por evento). */
  criarExecucao(x: DadosExecucao): Promise<boolean>;
  execucaoPorChave(fluxoId: string, chave: string): Promise<DadosExecucao | null>;
  execucao(id: string): Promise<DadosExecucao | null>;
  atualizarExecucao(x: DadosExecucao): Promise<void>;
  /** Execucoes do contato aguardando clique (mais recentes primeiro). */
  aguardandoClique(canal: CanalFluxo, contato: string): Promise<DadosExecucao[]>;
  jaExecutouParaContato(fluxoId: string, contato: string): Promise<boolean>;
  registrarPasso(p: Passo): Promise<void>;
  /** Marca o comentario como visto; false se ja estava (uma automacao por comentario). */
  reivindicarComentario(comentarioId: string, postId: string | null): Promise<boolean>;
  perfil(canal: CanalFluxo, contato: string): Promise<PerfilContato>;
  template(id: string): Promise<TemplateRef | null>;
}

export interface MensagemSaida { canal: CanalFluxo; contato: string; texto: string; midia_url?: string | null; midia_tipo?: string | null; botoes: (Botao & { payload: string })[]; chave: string }

/** Erro do provedor: permanente nao volta para a fila (registrado no historico); transitorio refaz o job. */
export class ErroCanal extends Error {
  constructor(mensagem: string, readonly permanente: boolean) { super(mensagem); }
}

export interface CanalEnvio {
  responderComentario(e: { post_id: string; comentario_id: string; texto: string; chave: string; conta_id?: string | null }): Promise<{ id_externo: string | null }>;
  respostaPrivada(e: { post_id: string; comentario_id: string; texto: string; botoes: (Botao & { payload: string })[]; chave: string; conta_id?: string | null }): Promise<{ id_externo: string | null }>;
  enviarMensagem(m: MensagemSaida): Promise<{ id_externo: string | null }>;
  enviarTemplate(e: { telefone: string; nome: string; idioma: string; parametros: string[]; chave: string }): Promise<{ id_externo: string | null }>;
}

export interface Agendador {
  /** Continua a execucao no no indicado depois de `minutos` (job da fila com disponivel_em). */
  continuarDepois(execucaoId: string, noId: string, minutos: number): Promise<void>;
}

export interface Relogio { agora(): Date }
