/**
 * Composicao do modulo Automacoes: liga casos de uso aos adaptadores Postgres e Zernio para um cliente de transacao.
 * Usada pelas rotas, tools, worker e seed.
 */
import type pg from 'pg';
import { BroadcastRepoPg } from './broadcast/adapter.ts';
import { AgendarBroadcast, CancelarBroadcast, CriarBroadcast, EditarBroadcast, ProcessarLoteBroadcast, RegistrarCliqueBroadcast } from './broadcast/broadcast.ts';
import { FluxoRepoPg } from './fluxo/adapter/fluxo-repo-pg.ts';
import { CriarFluxo, ExcluirFluxo, MudarEstadoFluxo, SalvarFluxo } from './fluxo/use-case/fluxos.ts';
import { CanalZernioPg } from './motor/adapter/canal-zernio.ts';
import { FilaOutboxPg, MotorRepoPg } from './motor/adapter/motor-repo-pg.ts';
import type { CanalEnvio } from './motor/model/portas.ts';
import { Motor } from './motor/use-case/motor.ts';
import { VarrerComentarios } from './motor/adapter/varredura-pg.ts';
import { TemplateRepoPg, TemplatesZernio } from './template/adapter.ts';
import { AplicarStatusTemplate, CriarTemplate, EditarTemplate, ExcluirTemplate, SincronizarTemplates, SubmeterTemplate, type ApiTemplates } from './template/casos.ts';
import { ClienteZernioAutomacoes } from './zernio/cliente.ts';

export function casosDeUso(c: pg.PoolClient, o: { canal?: CanalEnvio; apiTemplates?: ApiTemplates; zernio?: ClienteZernioAutomacoes } = {}) {
  const fluxos = new FluxoRepoPg(c);
  const motorRepo = new MotorRepoPg(c);
  const templates = new TemplateRepoPg(c);
  const broadcasts = new BroadcastRepoPg(c);
  const fila = new FilaOutboxPg(c);
  const zernio = o.zernio ?? new ClienteZernioAutomacoes();
  const canal = o.canal ?? new CanalZernioPg(c, zernio);
  const api = o.apiTemplates ?? new TemplatesZernio(c, zernio);
  const leituraTemplates = { template: (id: string) => motorRepo.template(id) };
  const depsBroadcast = { repo: broadcasts, templates: leituraTemplates, fila };
  const clique = new RegistrarCliqueBroadcast({ repo: broadcasts });
  const motor = new Motor({ repo: motorRepo, canal, agendador: motorRepo, broadcast: clique });
  const aplicarStatus = new AplicarStatusTemplate({ repo: templates });
  return {
    criarFluxo: new CriarFluxo({ repo: fluxos }),
    salvarFluxo: new SalvarFluxo({ repo: fluxos }),
    mudarEstadoFluxo: new MudarEstadoFluxo({ repo: fluxos }),
    excluirFluxo: new ExcluirFluxo({ repo: fluxos }),
    motor,
    varrerComentarios: new VarrerComentarios({ c, motor, zernio, fila }),
    criarTemplate: new CriarTemplate({ repo: templates }),
    editarTemplate: new EditarTemplate({ repo: templates }),
    excluirTemplate: new ExcluirTemplate({ repo: templates }),
    submeterTemplate: new SubmeterTemplate({ repo: templates, api }),
    aplicarStatusTemplate: aplicarStatus,
    sincronizarTemplates: new SincronizarTemplates({ repo: templates, api, aplicar: aplicarStatus }),
    criarBroadcast: new CriarBroadcast(depsBroadcast),
    editarBroadcast: new EditarBroadcast(depsBroadcast),
    agendarBroadcast: new AgendarBroadcast(depsBroadcast),
    cancelarBroadcast: new CancelarBroadcast(depsBroadcast),
    processarLoteBroadcast: new ProcessarLoteBroadcast({ ...depsBroadcast, canal }),
    fila,
  };
}
export type CasosDeUso = ReturnType<typeof casosDeUso>;
