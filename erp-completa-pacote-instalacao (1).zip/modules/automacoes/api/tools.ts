/**
 * @tool do modulo Automacoes (N15): cada chamada vira tool MCP em /mcp e rota REST com o mesmo schema no OpenAPI.
 * Automacoes (fluxos), templates oficiais da Meta e broadcast.
 */
import { tool } from '@erp/api/sdk';
import { naoEncontrado } from './borda.ts';
import { listarBroadcasts, obterBroadcast, previaSegmento } from './broadcast/adapter.ts';
import type { EntradaBroadcast, Segmento } from './broadcast/broadcast.ts';
import { contextoPg } from './compartilhado/efeitos-pg.ts';
import { exigirOk } from './compartilhado/result.ts';
import { filtroFluxos, filtroPostsInstagram, grafo, propsBroadcast, propsCriarFluxo, propsTemplate, segmento, uuid } from './esquemas.ts';
import { casosDeUso } from './fabrica.ts';
import type { CanalFluxo, DadosGatilho, Grafo } from './fluxo/model/grafo.ts';
import { listarExecucoes, listarFluxos, obterFluxo, opcoesEditor, type FiltroFluxos } from './fluxo/query/fluxos.ts';
import { listarPostsInstagram, type FiltroPostsInstagram } from './instagram/posts.ts';
import { listarTemplates, obterTemplate } from './template/adapter.ts';
import { ClienteZernioAutomacoes } from './zernio/cliente.ts';
import type { EntradaTemplate } from './template/template.ts';

const M = 'automacoes';
const BASE = '/api/v1/automacoes';
export const TIPO_JOB_SINCRONIZAR = 'automacoes.sincronizar_templates';

tool<FiltroFluxos>({
  nome: 'automacoes.listar', modulo: M, titulo: 'Listar automacoes', tipo: 'leitura', permissao: 'automacoes.ver',
  descricao: 'Automacoes de Instagram e WhatsApp (estilo ManyChat) com canal, gatilho, estado, disparos, cliques e ultimo disparo.',
  entrada: { type: 'object', properties: filtroFluxos },
  rota: { metodo: 'GET', caminho: `${BASE}/fluxos` },
  executar: ({ c }, a) => listarFluxos(c, a),
});

tool<{ id: string }>({
  nome: 'automacao.obter', modulo: M, titulo: 'Obter automacao', tipo: 'leitura', permissao: 'automacoes.ver',
  descricao: 'Automacao com o grafo do editor (nos e fios), contadores por no (disparos, cliques, falhas, ignorados) e totais de execucao.',
  entrada: { type: 'object', required: ['id'], properties: { id: uuid } },
  rota: { metodo: 'GET', caminho: `${BASE}/fluxos/:id` },
  executar: async ({ c }, a) => (await obterFluxo(c, a.id)) ?? Promise.reject(naoEncontrado('Automacao nao encontrada')),
});

tool<{ id: string; limite?: number }>({
  nome: 'automacao.execucoes', modulo: M, titulo: 'Historico de execucao', tipo: 'leitura', permissao: 'automacoes.ver',
  descricao: 'Ultimas execucoes da automacao com o contato, estado e cada passo (no, resultado, motivo).',
  entrada: { type: 'object', required: ['id'], properties: { id: uuid, limite: { type: 'integer', minimum: 1, maximum: 200, default: 50 } } },
  rota: { metodo: 'GET', caminho: `${BASE}/fluxos/:id/execucoes` },
  executar: ({ c }, a) => listarExecucoes(c, a.id, a.limite ?? 50),
});

tool<Record<string, never>>({
  nome: 'automacoes.opcoes', modulo: M, titulo: 'Opcoes do editor', tipo: 'leitura', permissao: 'automacoes.ver',
  descricao: 'Etapas dos pipelines, tags e setores, templates aprovados e canais conectados, para montar os nos de acao e mensagem.',
  entrada: { type: 'object', properties: {} },
  rota: { metodo: 'GET', caminho: `${BASE}/opcoes` },
  executar: ({ c }) => opcoesEditor(c),
});

tool<FiltroPostsInstagram>({
  nome: 'posts_instagram.listar', modulo: M, titulo: 'Listar posts do Instagram', tipo: 'leitura', permissao: 'automacoes.ver',
  descricao: 'Posts do perfil do Instagram conectado (mais novos primeiro) com legenda, tipo (post, reels, carrossel), data, link, comentarios e miniatura, para escolher os posts do gatilho de comentario. Busca por trecho da legenda e cursor para a proxima pagina.',
  entrada: { type: 'object', properties: filtroPostsInstagram },
  rota: { metodo: 'GET', caminho: `${BASE}/instagram/posts` },
  executar: ({ c }, a) => listarPostsInstagram(c, new ClienteZernioAutomacoes(), a),
});

tool<{ nome: string; canal: CanalFluxo; gatilho?: DadosGatilho; grafo?: Grafo }>({
  nome: 'automacao.criar', modulo: M, titulo: 'Criar automacao', tipo: 'escrita', permissao: 'automacoes.criar',
  descricao: 'Cria a automacao em rascunho. Sem grafo nasce so com o gatilho (comentario no post no Instagram, palavra-chave no WhatsApp).',
  entrada: { type: 'object', required: ['nome', 'canal'], properties: propsCriarFluxo },
  rota: { metodo: 'POST', caminho: `${BASE}/fluxos` },
  executar: async ({ c, ator, ip }, a) => {
    const { id } = exigirOk(await casosDeUso(c).criarFluxo.execute(contextoPg(c, ator, ip), a));
    return obterFluxo(c, id);
  },
});

tool<{ id: string; nome?: string; grafo: Grafo }>({
  nome: 'automacao.salvar', modulo: M, titulo: 'Salvar automacao', tipo: 'escrita', permissao: 'automacoes.editar',
  descricao: 'Salva o grafo do editor (nova versao). Em rascunho aceita fluxo incompleto; ativa exige fluxo valido.',
  entrada: { type: 'object', required: ['id', 'grafo'], properties: { id: uuid, nome: { type: 'string', minLength: 2, maxLength: 120 }, grafo } },
  rota: { metodo: 'PUT', caminho: `${BASE}/fluxos/:id` },
  executar: async ({ c, ator, ip }, a) => {
    exigirOk(await casosDeUso(c).salvarFluxo.execute(contextoPg(c, ator, ip), a));
    return obterFluxo(c, a.id);
  },
});

for (const [acao, estado] of [['ativar', 'ativa'], ['pausar', 'pausada']] as const) {
  tool<{ id: string }>({
    nome: `automacao.${acao}`, modulo: M, titulo: acao === 'ativar' ? 'Ativar automacao' : 'Pausar automacao', tipo: 'escrita', permissao: 'automacoes.ativar',
    descricao: acao === 'ativar' ? 'Ativa a automacao (valida o fluxo inteiro). A partir dai comentarios e mensagens disparam envios reais.' : 'Pausa a automacao: nada novo dispara e esperas pendentes sao canceladas.',
    entrada: { type: 'object', required: ['id'], properties: { id: uuid } },
    rota: { metodo: 'POST', caminho: `${BASE}/fluxos/:id/${acao}` },
    executar: async ({ c, ator, ip }, a) => {
      const casos = casosDeUso(c);
      exigirOk(await casos.mudarEstadoFluxo.execute(contextoPg(c, ator, ip), { id: a.id, estado }));
      const f = await obterFluxo(c, a.id);
      if (estado === 'ativa' && f?.gatilho === 'comentario_post') await casos.varrerComentarios.garantirAgendada();
      return f;
    },
  });
}

tool<{ estado?: string }>({
  nome: 'templates_meta.listar', modulo: M, titulo: 'Listar templates oficiais', tipo: 'leitura', permissao: 'automacoes.ver',
  descricao: 'Templates oficiais do WhatsApp criados no ERP com estado da Meta (rascunho, pendente, aprovado, rejeitado com motivo, pausado, desativado).',
  entrada: { type: 'object', properties: { estado: { type: 'string', enum: ['rascunho', 'pendente', 'aprovado', 'rejeitado', 'pausado', 'desativado'] } } },
  rota: { metodo: 'GET', caminho: `${BASE}/templates` },
  executar: ({ c }, a) => listarTemplates(c, a),
});

tool<EntradaTemplate>({
  nome: 'template_meta.criar', modulo: M, titulo: 'Criar template oficial', tipo: 'escrita', permissao: 'automacoes.criar',
  descricao: 'Cria o template em rascunho: categoria, idioma, cabecalho de texto, corpo com variaveis {{n}} e exemplos, rodape e botoes (resposta rapida, link, telefone).',
  entrada: { type: 'object', required: ['nome', 'corpo'], properties: propsTemplate },
  rota: { metodo: 'POST', caminho: `${BASE}/templates` },
  executar: async ({ c, ator, ip }, a) => {
    const { id } = exigirOk(await casosDeUso(c).criarTemplate.execute(contextoPg(c, ator, ip), a));
    return obterTemplate(c, id);
  },
});

tool<Partial<EntradaTemplate> & { id: string }>({
  nome: 'template_meta.editar', modulo: M, titulo: 'Editar template oficial', tipo: 'escrita', permissao: 'automacoes.editar',
  descricao: 'Edita template em rascunho ou rejeitado.',
  entrada: { type: 'object', required: ['id'], properties: { id: uuid, ...propsTemplate } },
  rota: { metodo: 'PATCH', caminho: `${BASE}/templates/:id` },
  executar: async ({ c, ator, ip }, a) => {
    exigirOk(await casosDeUso(c).editarTemplate.execute(contextoPg(c, ator, ip), a));
    return obterTemplate(c, a.id);
  },
});

tool<{ id: string }>({
  nome: 'template_meta.submeter', modulo: M, titulo: 'Enviar template para aprovacao', tipo: 'escrita', permissao: 'automacoes.editar',
  descricao: 'Envia o template para aprovacao da Meta pela Zernio. Fica pendente; o status chega pela sincronizacao (a cada 5 min enquanto houver pendente) ou pelo webhook.',
  entrada: { type: 'object', required: ['id'], properties: { id: uuid } },
  rota: { metodo: 'POST', caminho: `${BASE}/templates/:id/submeter` },
  executar: async ({ c, ator, ip }, a) => {
    const casos = casosDeUso(c);
    const r = exigirOk(await casos.submeterTemplate.execute(contextoPg(c, ator, ip), a));
    if (r.estado === 'pendente') {
      const ja = await c.query(`SELECT 1 FROM outbox WHERE tipo = $1 AND estado IN ('pendente', 'despachado') LIMIT 1`, [TIPO_JOB_SINCRONIZAR]);
      if (!ja.rowCount) await casos.fila.agendar(TIPO_JOB_SINCRONIZAR, {}, 300);
    }
    return obterTemplate(c, a.id);
  },
});

tool<Record<string, never>>({
  nome: 'templates_meta.sincronizar', modulo: M, titulo: 'Sincronizar status dos templates', tipo: 'escrita', permissao: 'automacoes.editar',
  descricao: 'Le na Zernio o status de cada template submetido e atualiza aprovado, rejeitado (com motivo), pausado ou desativado.',
  entrada: { type: 'object', properties: {} },
  rota: { metodo: 'POST', caminho: `${BASE}/templates/sincronizar` },
  executar: async ({ c, ator, ip }) => exigirOk(await casosDeUso(c).sincronizarTemplates.execute(contextoPg(c, ator, ip))),
});

tool<Record<string, never>>({
  nome: 'broadcasts.listar', modulo: M, titulo: 'Listar broadcasts', tipo: 'leitura', permissao: 'automacoes.ver',
  descricao: 'Broadcasts de WhatsApp com template, agendamento, ritmo, estado e relatorio (enviados, entregues, lidos, falhas, cliques).',
  entrada: { type: 'object', properties: {} },
  rota: { metodo: 'GET', caminho: `${BASE}/broadcasts` },
  executar: ({ c }) => listarBroadcasts(c),
});

tool<{ id: string }>({
  nome: 'broadcast.obter', modulo: M, titulo: 'Obter broadcast', tipo: 'leitura', permissao: 'automacoes.ver',
  descricao: 'Broadcast com relatorio e cada destinatario (estado, erro, clique).',
  entrada: { type: 'object', required: ['id'], properties: { id: uuid } },
  rota: { metodo: 'GET', caminho: `${BASE}/broadcasts/:id` },
  executar: async ({ c }, a) => (await obterBroadcast(c, a.id)) ?? Promise.reject(naoEncontrado('Broadcast nao encontrado')),
});

tool<Segmento>({
  nome: 'broadcast.previa', modulo: M, titulo: 'Previa do segmento', tipo: 'leitura', permissao: 'automacoes.ver',
  descricao: 'Quantos clientes com telefone o segmento alcanca (por tag, setor e so clientes).',
  entrada: { type: 'object', properties: segmento.properties },
  rota: { metodo: 'POST', caminho: `${BASE}/broadcasts/previa` },
  executar: async ({ c }, a) => ({ destinatarios: await previaSegmento(c, a) }),
});

tool<EntradaBroadcast>({
  nome: 'broadcast.criar', modulo: M, titulo: 'Criar broadcast', tipo: 'escrita', permissao: 'automacoes.criar',
  descricao: 'Cria o broadcast em rascunho com template, parametros, segmento, agendamento, ritmo por minuto e automacao de clique opcional.',
  entrada: { type: 'object', required: ['nome', 'template_id'], properties: propsBroadcast },
  rota: { metodo: 'POST', caminho: `${BASE}/broadcasts` },
  executar: async ({ c, ator, ip }, a) => {
    const { id } = exigirOk(await casosDeUso(c).criarBroadcast.execute(contextoPg(c, ator, ip), a));
    return obterBroadcast(c, id);
  },
});

tool<Partial<EntradaBroadcast> & { id: string }>({
  nome: 'broadcast.editar', modulo: M, titulo: 'Editar broadcast', tipo: 'escrita', permissao: 'automacoes.editar',
  descricao: 'Edita broadcast em rascunho.',
  entrada: { type: 'object', required: ['id'], properties: { id: uuid, ...propsBroadcast } },
  rota: { metodo: 'PATCH', caminho: `${BASE}/broadcasts/:id` },
  executar: async ({ c, ator, ip }, a) => {
    exigirOk(await casosDeUso(c).editarBroadcast.execute(contextoPg(c, ator, ip), a));
    return obterBroadcast(c, a.id);
  },
});

tool<{ id: string }>({
  nome: 'broadcast.agendar', modulo: M, titulo: 'Agendar broadcast', tipo: 'escrita', permissao: 'automacoes.disparar',
  descricao: 'Agenda o disparo (na data marcada ou agora). Exige template aprovado. Envia em lotes no ritmo por minuto.',
  entrada: { type: 'object', required: ['id'], properties: { id: uuid } },
  rota: { metodo: 'POST', caminho: `${BASE}/broadcasts/:id/agendar` },
  executar: async ({ c, ator, ip }, a) => {
    const r = exigirOk(await casosDeUso(c).agendarBroadcast.execute(contextoPg(c, ator, ip), a));
    return { ...(await obterBroadcast(c, a.id)), job_id: r.job_id };
  },
});

tool<{ id: string }>({
  nome: 'broadcast.cancelar', modulo: M, titulo: 'Cancelar broadcast', tipo: 'escrita', permissao: 'automacoes.disparar',
  descricao: 'Cancela o broadcast: os envios ainda pendentes nao saem.',
  entrada: { type: 'object', required: ['id'], properties: { id: uuid } },
  rota: { metodo: 'POST', caminho: `${BASE}/broadcasts/:id/cancelar` },
  executar: async ({ c, ator, ip }, a) => {
    exigirOk(await casosDeUso(c).cancelarBroadcast.execute(contextoPg(c, ator, ip), a));
    return obterBroadcast(c, a.id);
  },
});

