/** Adaptador Postgres do agregado Fluxo. */
import type pg from 'pg';
import { COLUNAS_FLUXO, fluxoDaLinha } from '../../motor/adapter/motor-repo-pg.ts';
import { Fluxo } from '../model/fluxo.ts';
import type { RepoFluxos } from '../use-case/fluxos.ts';

export class FluxoRepoPg implements RepoFluxos {
  constructor(private readonly c: pg.PoolClient) {}
  async obter(id: string) {
    const r = await this.c.query(`SELECT ${COLUNAS_FLUXO} FROM automacoes_fluxos WHERE id = $1 AND deleted_at IS NULL`, [id]);
    return r.rows[0] ? Fluxo.reidratar(fluxoDaLinha(r.rows[0])) : null;
  }
  async inserir(f: Fluxo) {
    const d = f.paraDados();
    await this.c.query(
      `INSERT INTO automacoes_fluxos (id, nome, canal, gatilho, config_gatilho, grafo, versao, estado, creator_id) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, nucleo_usuario_atual())`,
      [d.id, d.nome, d.canal, d.gatilho, JSON.stringify(d.config_gatilho), JSON.stringify(d.grafo), d.versao, d.estado],
    );
  }
  async atualizar(f: Fluxo) {
    const d = f.paraDados();
    await this.c.query(
      `UPDATE automacoes_fluxos SET nome = $2, gatilho = $3, config_gatilho = $4, grafo = $5, versao = $6, estado = $7, ativada_em = $8 WHERE id = $1`,
      [d.id, d.nome, d.gatilho, JSON.stringify(d.config_gatilho), JSON.stringify(d.grafo), d.versao, d.estado, d.ativada_em],
    );
  }
  async excluir(id: string) { await this.c.query(`UPDATE automacoes_fluxos SET deleted_at = now() WHERE id = $1`, [id]); }
}
