/** Casos de uso do fluxo: criar, salvar o editor, ativar, pausar e excluir. */
import { erroDe, fail, ok, okVazio, type Result } from '../../compartilhado/result.ts';
import type { ContextoCaso } from '../../compartilhado/efeitos.ts';
import { Fluxo, type EstadoFluxo } from '../model/fluxo.ts';
import type { CanalFluxo, DadosGatilho, Grafo } from '../model/grafo.ts';

export const TABELA_FLUXOS = 'automacoes_fluxos';

export interface RepoFluxos {
  obter(id: string): Promise<Fluxo | null>;
  inserir(f: Fluxo): Promise<void>;
  atualizar(f: Fluxo): Promise<void>;
  excluir(id: string): Promise<void>;
}

const resumo = (f: Fluxo) => { const d = f.paraDados(); return { id: d.id, nome: d.nome, canal: d.canal, gatilho: d.gatilho, estado: d.estado, versao: d.versao, nos: d.grafo.nos.length }; };

export class CriarFluxo {
  constructor(private readonly d: { repo: RepoFluxos }) {}
  async execute(ctx: ContextoCaso, e: { nome: string; canal: CanalFluxo; gatilho?: DadosGatilho; grafo?: Grafo | null }): Promise<Result<{ id: string }>> {
    const r = Fluxo.tryCreate(e);
    if (!r.ok) return r;
    await this.d.repo.inserir(r.valor);
    await ctx.efeitos.auditar('automacao.criar', TABELA_FLUXOS, r.valor.id, undefined, resumo(r.valor));
    return ok({ id: r.valor.id });
  }
}

export class SalvarFluxo {
  constructor(private readonly d: { repo: RepoFluxos }) {}
  async execute(ctx: ContextoCaso, e: { id: string; nome?: string; grafo: Grafo }): Promise<Result<{ versao: number }>> {
    const f = await this.d.repo.obter(e.id);
    if (!f) return fail(erroDe('nao_encontrado', 'Automacao nao encontrada'));
    const r = f.salvar({ nome: e.nome, grafo: e.grafo });
    if (!r.ok) return r;
    await this.d.repo.atualizar(r.valor);
    await ctx.efeitos.historico(TABELA_FLUXOS, f.id, resumo(f), resumo(r.valor));
    await ctx.efeitos.auditar('automacao.salvar', TABELA_FLUXOS, f.id, resumo(f), resumo(r.valor));
    return ok({ versao: r.valor.paraDados().versao });
  }
}

export class MudarEstadoFluxo {
  constructor(private readonly d: { repo: RepoFluxos }) {}
  async execute(ctx: ContextoCaso, e: { id: string; estado: Exclude<EstadoFluxo, 'rascunho'> }): Promise<Result<void>> {
    const f = await this.d.repo.obter(e.id);
    if (!f) return fail(erroDe('nao_encontrado', 'Automacao nao encontrada'));
    const r = f.mudarEstado(e.estado);
    if (!r.ok) return r;
    await this.d.repo.atualizar(r.valor);
    await ctx.efeitos.historico(TABELA_FLUXOS, f.id, { estado: f.estado }, { estado: e.estado });
    await ctx.efeitos.auditar(e.estado === 'ativa' ? 'automacao.ativar' : 'automacao.pausar', TABELA_FLUXOS, f.id, { estado: f.estado }, { estado: e.estado });
    const d = r.valor.paraDados();
    await ctx.efeitos.publicar(e.estado === 'ativa' ? 'automacao.ativada' : 'automacao.pausada', { id: d.id, nome: d.nome, canal: d.canal, gatilho: d.gatilho, versao: d.versao });
    return okVazio();
  }
}

export class ExcluirFluxo {
  constructor(private readonly d: { repo: RepoFluxos }) {}
  async execute(ctx: ContextoCaso, e: { id: string }): Promise<Result<void>> {
    const f = await this.d.repo.obter(e.id);
    if (!f) return fail(erroDe('nao_encontrado', 'Automacao nao encontrada'));
    if (f.estado === 'ativa') return fail(erroDe('transicao_invalida', 'Pause a automacao antes de excluir', 'estado'));
    await this.d.repo.excluir(e.id);
    await ctx.efeitos.auditar('automacao.excluir', TABELA_FLUXOS, e.id, resumo(f), undefined);
    return okVazio();
  }
}
