/** Entidade Fluxo (automacao): nome, canal, grafo validado e maquina de estados rascunho, ativa, pausada. */
import { randomUUID } from 'node:crypto';
import { erroDe, fail, ok, type ErroDominio, type Result } from '../../compartilhado/result.ts';
import { grafoVazio, validarGrafo, type CanalFluxo, type DadosGatilho, type Grafo, type TipoGatilho } from './grafo.ts';

export type EstadoFluxo = 'rascunho' | 'ativa' | 'pausada';
export const TRANSICOES: Record<EstadoFluxo, EstadoFluxo[]> = { rascunho: ['ativa'], ativa: ['pausada'], pausada: ['ativa'] };

export interface DadosFluxo {
  id: string;
  nome: string;
  canal: CanalFluxo;
  gatilho: TipoGatilho;
  config_gatilho: DadosGatilho;
  grafo: Grafo;
  versao: number;
  estado: EstadoFluxo;
  ativada_em: string | null;
}

function validarNome(nome: unknown): ErroDominio[] {
  const n = typeof nome === 'string' ? nome.trim() : '';
  return n.length >= 2 && n.length <= 120 ? [] : [erroDe('nome_invalido', 'Nome de 2 a 120 caracteres', 'nome')];
}

export class Fluxo {
  private constructor(private readonly p: DadosFluxo) {}

  static tryCreate(e: { nome: string; canal: CanalFluxo; gatilho?: DadosGatilho; grafo?: Grafo | null }, id: string = randomUUID()): Result<Fluxo> {
    const erros = validarNome(e.nome);
    if (!['instagram', 'whatsapp'].includes(e.canal)) erros.push(erroDe('canal_invalido', 'Canal instagram ou whatsapp', 'canal'));
    const gat: DadosGatilho = e.gatilho ?? { tipo: e.canal === 'instagram' ? 'comentario_post' : 'mensagem_palavra', palavras: e.canal === 'whatsapp' ? ['quero'] : [], correspondencia: 'contem', uma_vez_por_contato: true };
    const grafo = e.grafo ?? grafoVazio(gat);
    if (e.grafo) erros.push(...validarGrafo(e.canal, grafo));
    if (erros.length) return fail(...erros);
    const g = Fluxo.gatilhoDe(grafo) ?? gat;
    return ok(new Fluxo({ id, nome: e.nome.trim(), canal: e.canal, gatilho: g.tipo, config_gatilho: g, grafo, versao: 1, estado: 'rascunho', ativada_em: null }));
  }

  static create(e: Parameters<typeof Fluxo.tryCreate>[0], id?: string): Fluxo {
    const r = Fluxo.tryCreate(e, id);
    if (!r.ok) throw new Error(r.erros.map((x) => x.mensagem).join('; '));
    return r.valor;
  }

  static reidratar(d: DadosFluxo): Fluxo { return new Fluxo({ ...d }); }

  static gatilhoDe(g: Grafo): DadosGatilho | null {
    const n = g.nos.find((x) => x.tipo === 'gatilho');
    return n ? (n.dados as DadosGatilho) : null;
  }

  get id() { return this.p.id; }
  get estado() { return this.p.estado; }
  get canal() { return this.p.canal; }
  get grafo() { return this.p.grafo; }

  /** Salvar o editor: grafo novo validado, versao +1. Ativo continua ativo (o motor le a versao nova). */
  salvar(e: { nome?: string; grafo: Grafo }): Result<Fluxo> {
    const erros = e.nome !== undefined ? validarNome(e.nome) : [];
    const ge = validarGrafo(this.p.canal, e.grafo);
    // Rascunho aceita grafo incompleto (salvar no meio da edicao) mas nunca estrutura quebrada.
    const estrutural = ge.filter((x) => this.p.estado !== 'rascunho' || !['sem_entrega', 'no_invalido', 'botao_invalido', 'gatilho_invalido', 'texto_longo', 'botoes_demais'].includes(x.codigo));
    erros.push(...estrutural);
    if (erros.length) return fail(...erros);
    const g = Fluxo.gatilhoDe(e.grafo)!;
    return ok(new Fluxo({ ...this.p, nome: e.nome?.trim() ?? this.p.nome, grafo: e.grafo, gatilho: g.tipo, config_gatilho: g, versao: this.p.versao + 1 }));
  }

  mudarEstado(para: EstadoFluxo, agora = new Date()): Result<Fluxo> {
    if (!TRANSICOES[this.p.estado].includes(para)) {
      return fail(erroDe('transicao_invalida', `De ${this.p.estado} para ${para} nao e permitido`, 'estado', { permitidas: TRANSICOES[this.p.estado] }));
    }
    if (para === 'ativa') {
      const erros = validarGrafo(this.p.canal, this.p.grafo);
      if (erros.length) return fail(...erros);
    }
    return ok(new Fluxo({ ...this.p, estado: para, ativada_em: para === 'ativa' ? agora.toISOString() : this.p.ativada_em }));
  }

  paraDados(): DadosFluxo { return { ...this.p }; }
}
