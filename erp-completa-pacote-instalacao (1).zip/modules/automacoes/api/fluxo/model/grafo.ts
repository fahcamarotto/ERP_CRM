/**
 * Grafo do fluxo (contrato do editor em canvas): nos e fios, replicando o `flow_v1` do sistema de agentes de referencia.
 * Regras: entrada e o no de gatilho, uma saida por porta, sem ciclo, botao de link nao ramifica, cadeia de saida
 * do gatilho com pelo menos uma entrega, limites de botao por canal. Funcao pura, sem banco.
 */
import { erroDe, type ErroDominio } from '../../compartilhado/result.ts';

export type CanalFluxo = 'instagram' | 'whatsapp';
export type TipoGatilho = 'comentario_post' | 'mensagem_palavra' | 'botao_clicado' | 'broadcast';
export type TipoNo = 'gatilho' | 'resposta_publica' | 'mensagem' | 'condicao' | 'espera' | 'acao' | 'fim';
export const TIPOS_NO: readonly TipoNo[] = ['gatilho', 'resposta_publica', 'mensagem', 'condicao', 'espera', 'acao', 'fim'];
export const TIPOS_GATILHO: readonly TipoGatilho[] = ['comentario_post', 'mensagem_palavra', 'botao_clicado', 'broadcast'];
export type Correspondencia = 'qualquer' | 'contem' | 'exata' | 'palavra';

export interface Botao { tipo: 'resposta' | 'url'; titulo: string; url?: string | null; resposta?: string | null }

export type ModoPosts = 'geral' | 'especificos';
export interface ResumoPost { id: string; legenda?: string | null; tipo?: string | null; publicado_em?: string | null }
export const MAX_POSTS_GATILHO = 50;
const ID_POST = /^[A-Za-z0-9_-]{1,80}$/;

export interface DadosGatilho {
  tipo: TipoGatilho;
  /** Legado: um post do Instagram (id da midia). Lido como post_ids [post_id] quando modo_posts falta. */
  post_id?: string | null;
  /** Instagram: `geral` vale para todos os posts da conta (inclusive futuros); `especificos` so para post_ids. */
  modo_posts?: ModoPosts;
  post_ids?: string[];
  /** Resumo dos posts escolhidos para o editor mostrar sem nova consulta (id, legenda curta, tipo, data). */
  posts?: ResumoPost[];
  /** Canal do Instagram escolhido (integracoes_canais.id), a conta da Zernio (accountId) e o @ da conta. */
  canal_id?: string | null;
  conta_id?: string | null;
  conta_usuario?: string | null;
  palavras?: string[];
  correspondencia?: Correspondencia;
  /** Gatilho botao_clicado: titulo do botao (de template ou mensagem fora do fluxo). */
  botao?: string | null;
  /** Cada pessoa recebe o fluxo uma vez (padrao do sistema de agentes de referencia). */
  uma_vez_por_contato?: boolean;
}
export interface DadosRespostaPublica { respostas: string[] }
export interface DadosMensagem {
  texto: string;
  midia_url?: string | null;
  midia_tipo?: 'image' | 'video' | 'file' | null;
  botoes?: Botao[];
  /** WhatsApp fora da janela de 24 h: template aprovado (automacoes_templates.id). */
  template_id?: string | null;
  parametros?: string[];
}
export interface DadosCondicao { campo: 'texto' | 'tag' | 'e_cliente' | 'tem_telefone'; operador: 'contem' | 'igual' | 'existe'; valor?: string | null }
export interface DadosEspera { minutos: number }
export interface DadosAcao {
  tipo: 'cliente' | 'oportunidade' | 'tag';
  tags?: string[];
  funil_id?: string | null;
  etapa_id?: string | null;
  titulo?: string | null;
}

export type DadosNo = DadosGatilho | DadosRespostaPublica | DadosMensagem | DadosCondicao | DadosEspera | DadosAcao | Record<string, never>;
export interface No { id: string; tipo: TipoNo; posicao: { x: number; y: number }; dados: DadosNo }
export interface Fio { id: string; origem: string; porta: string; destino: string }
export interface Grafo { versao: 1; entrada: string; nos: No[]; fios: Fio[]; viewport?: { x: number; y: number; zoom: number } }

export const LIMITES = { nos: 100, fios: 200, bytes: 131072, titulo: 20, texto: 1000, textoComBotoes: 640, esperaMaxMin: 60 * 24 * 7 };
const ID = /^[A-Za-z0-9:_-]{1,80}$/;
const URL_OK = /^https?:\/\/\S+$/i;

const e = (codigo: string, mensagem: string, meta?: Record<string, unknown>) => erroDe(codigo, mensagem, 'grafo', meta);

/** Portas de saida validas de cada no. */
export function portasDe(no: No): string[] {
  if (no.tipo === 'condicao') return ['sim', 'nao'];
  if (no.tipo === 'fim') return [];
  if (no.tipo === 'mensagem') {
    const bs = (no.dados as DadosMensagem).botoes ?? [];
    return ['saida', ...bs.map((b, i) => (b.tipo === 'resposta' ? `botao:${i}` : null)).filter((x): x is string => !!x)];
  }
  return ['saida'];
}

function validarBotoes(canal: CanalFluxo, no: No, erros: ErroDominio[]): void {
  const d = no.dados as DadosMensagem;
  const bs = d.botoes ?? [];
  for (const [i, b] of bs.entries()) {
    if (!b || !['resposta', 'url'].includes(b.tipo)) erros.push(e('botao_invalido', `Botao ${i + 1} do no ${no.id} sem tipo valido`));
    else if (!b.titulo?.trim() || b.titulo.trim().length > LIMITES.titulo) erros.push(e('botao_invalido', `Botao ${i + 1} do no ${no.id}: titulo de 1 a ${LIMITES.titulo} caracteres`));
    else if (b.tipo === 'url' && !URL_OK.test(b.url ?? '')) erros.push(e('botao_invalido', `Botao ${i + 1} do no ${no.id}: link http(s) obrigatorio`));
  }
  const respostas = bs.filter((b) => b?.tipo === 'resposta').length;
  const links = bs.filter((b) => b?.tipo === 'url').length;
  if (canal === 'instagram' && (bs.length > 13 || (links > 0 && bs.length > 3))) erros.push(e('botoes_demais', `No ${no.id}: Instagram aceita ate 13 respostas rapidas, ou ate 3 botoes quando ha link`));
  if (canal === 'whatsapp' && (respostas > 3 || links > 1 || (links === 1 && respostas > 0))) erros.push(e('botoes_demais', `No ${no.id}: WhatsApp aceita ate 3 botoes de resposta ou exatamente 1 link`));
  const titulos = bs.map((b) => b?.titulo?.trim().toLowerCase());
  if (new Set(titulos).size !== titulos.length) erros.push(e('botao_invalido', `No ${no.id}: titulos de botao repetidos`));
  if (bs.length && (d.texto ?? '').length > LIMITES.textoComBotoes) erros.push(e('texto_longo', `No ${no.id}: texto com botoes ate ${LIMITES.textoComBotoes} caracteres`));
}

function validarNo(canal: CanalFluxo, no: No, erros: ErroDominio[]): void {
  const d = (no.dados ?? {}) as Record<string, unknown>;
  switch (no.tipo) {
    case 'gatilho': {
      const g = d as unknown as DadosGatilho;
      if (!TIPOS_GATILHO.includes(g.tipo)) erros.push(e('gatilho_invalido', 'Gatilho sem tipo valido'));
      if (g.tipo === 'comentario_post' && canal !== 'instagram') erros.push(e('gatilho_invalido', 'Comentario em post so existe no Instagram'));
      if (g.tipo === 'comentario_post') {
        const ids = g.post_ids ?? [];
        if (g.modo_posts !== undefined && !['geral', 'especificos'].includes(g.modo_posts)) erros.push(e('gatilho_invalido', 'Modo dos posts geral ou especificos'));
        if (!Array.isArray(ids) || ids.length > MAX_POSTS_GATILHO || ids.some((x) => typeof x !== 'string' || !ID_POST.test(x))) erros.push(e('gatilho_invalido', `Ate ${MAX_POSTS_GATILHO} posts com id valido`));
        else if (g.modo_posts === 'especificos' && !ids.length) erros.push(e('gatilho_invalido', 'Escolha ao menos um post ou use o modo geral'));
      }
      if (g.tipo === 'broadcast' && canal !== 'whatsapp') erros.push(e('gatilho_invalido', 'Broadcast so existe no WhatsApp'));
      if (g.tipo === 'mensagem_palavra' && !(g.palavras ?? []).some((p) => p.trim())) erros.push(e('gatilho_invalido', 'Mensagem com palavra-chave precisa de ao menos uma palavra'));
      if (g.tipo === 'botao_clicado' && !g.botao?.trim()) erros.push(e('gatilho_invalido', 'Clique em botao precisa do titulo do botao'));
      break;
    }
    case 'resposta_publica': {
      const r = (d.respostas as string[] | undefined) ?? [];
      if (canal !== 'instagram') erros.push(e('no_invalido', 'Resposta publica so existe no Instagram'));
      if (!r.length || r.length > 10 || r.some((x) => typeof x !== 'string' || !x.trim() || x.length > LIMITES.texto)) erros.push(e('no_invalido', `No ${no.id}: de 1 a 10 respostas com texto`));
      break;
    }
    case 'mensagem': {
      const m = d as unknown as DadosMensagem;
      if (!m.texto?.trim() && !m.midia_url && !m.template_id) erros.push(e('no_invalido', `No ${no.id}: mensagem sem texto, midia ou template`));
      if ((m.texto ?? '').length > LIMITES.texto) erros.push(e('texto_longo', `No ${no.id}: texto ate ${LIMITES.texto} caracteres`));
      if (m.midia_url && !URL_OK.test(m.midia_url)) erros.push(e('no_invalido', `No ${no.id}: midia precisa de link http(s)`));
      if (m.midia_url && canal === 'instagram' && (m.botoes ?? []).length) erros.push(e('no_invalido', `No ${no.id}: no Instagram midia nao leva botoes`));
      validarBotoes(canal, no, erros);
      break;
    }
    case 'condicao':
      if (!['texto', 'tag', 'e_cliente', 'tem_telefone'].includes(String(d.campo)) || !['contem', 'igual', 'existe'].includes(String(d.operador))) erros.push(e('no_invalido', `No ${no.id}: condicao incompleta`));
      break;
    case 'espera': {
      const min = Number(d.minutos);
      if (!Number.isInteger(min) || min < 1 || min > LIMITES.esperaMaxMin) erros.push(e('no_invalido', `No ${no.id}: espera de 1 a ${LIMITES.esperaMaxMin} minutos`));
      break;
    }
    case 'acao': {
      const a = d as unknown as DadosAcao;
      if (!['cliente', 'oportunidade', 'tag'].includes(a.tipo)) erros.push(e('no_invalido', `No ${no.id}: acao sem tipo`));
      if (a.tipo === 'tag' && !(a.tags ?? []).some((t) => t.trim())) erros.push(e('no_invalido', `No ${no.id}: informe a tag`));
      if (a.tipo === 'oportunidade' && !a.etapa_id) erros.push(e('no_invalido', `No ${no.id}: escolha a etapa do pipeline`));
      break;
    }
    case 'fim':
      break;
    default:
      erros.push(e('no_invalido', `No ${String((no as No).id)} com tipo desconhecido`));
  }
}

/** Valida o grafo inteiro e devolve todos os erros de uma vez. */
export function validarGrafo(canal: CanalFluxo, g: Grafo): ErroDominio[] {
  const erros: ErroDominio[] = [];
  if (!g || g.versao !== 1 || !Array.isArray(g.nos) || !Array.isArray(g.fios)) return [e('grafo_invalido', 'Grafo sem versao 1, nos e fios')];
  if (JSON.stringify(g).length > LIMITES.bytes) erros.push(e('grafo_grande', 'Grafo acima de 128 KB'));
  if (g.nos.length > LIMITES.nos || g.fios.length > LIMITES.fios) erros.push(e('grafo_grande', `Ate ${LIMITES.nos} nos e ${LIMITES.fios} fios`));
  const nos = new Map<string, No>();
  for (const n of g.nos) {
    if (!n || !ID.test(n.id ?? '')) { erros.push(e('no_invalido', 'No com id invalido')); continue; }
    if (nos.has(n.id)) erros.push(e('no_invalido', `No ${n.id} repetido`));
    nos.set(n.id, n);
    validarNo(canal, n, erros);
  }
  const gatilhos = g.nos.filter((n) => n.tipo === 'gatilho');
  if (gatilhos.length !== 1) erros.push(e('gatilho_invalido', 'O fluxo precisa de exatamente um gatilho'));
  if (nos.get(g.entrada)?.tipo !== 'gatilho') erros.push(e('gatilho_invalido', 'A entrada do fluxo precisa ser o gatilho'));
  const usadas = new Set<string>();
  const saida = new Map<string, string[]>();
  for (const f of g.fios) {
    if (!f || !ID.test(f.id ?? '')) { erros.push(e('fio_invalido', 'Fio com id invalido')); continue; }
    const o = nos.get(f.origem);
    const d = nos.get(f.destino);
    if (!o || !d) { erros.push(e('fio_invalido', `Fio ${f.id} liga no inexistente`)); continue; }
    if (f.origem === f.destino) erros.push(e('fio_invalido', `Fio ${f.id} liga o no nele mesmo`));
    if (d.tipo === 'gatilho') erros.push(e('fio_invalido', `Fio ${f.id} entra no gatilho`));
    if (!portasDe(o).includes(f.porta)) erros.push(e('fio_invalido', `Fio ${f.id} sai de porta invalida (${f.porta})`));
    const chave = `${f.origem}|${f.porta}`;
    if (usadas.has(chave)) erros.push(e('fio_invalido', `Porta ${f.porta} do no ${f.origem} com mais de uma saida`));
    usadas.add(chave);
    saida.set(f.origem, [...(saida.get(f.origem) ?? []), f.destino]);
  }
  // Sem ciclo (DFS com cores).
  const cor = new Map<string, 0 | 1 | 2>();
  const ciclo = (id: string): boolean => {
    cor.set(id, 1);
    for (const p of saida.get(id) ?? []) {
      if (cor.get(p) === 1) return true;
      if (!cor.get(p) && ciclo(p)) return true;
    }
    cor.set(id, 2);
    return false;
  };
  if ([...nos.keys()].some((id) => !cor.get(id) && ciclo(id))) erros.push(e('ciclo', 'O fluxo nao pode ter ciclo'));
  // Entrega: alguma mensagem (ou resposta publica no Instagram) alcancavel do gatilho. Broadcast entrega o template.
  const gat = gatilhos[0];
  if (gat && (gat.dados as DadosGatilho).tipo !== 'broadcast') {
    const vistos = new Set<string>();
    const fila = [gat.id];
    while (fila.length) { const x = fila.shift()!; if (vistos.has(x)) continue; vistos.add(x); fila.push(...(saida.get(x) ?? [])); }
    const entrega = [...vistos].some((id) => nos.get(id)?.tipo === 'mensagem' || (canal === 'instagram' && nos.get(id)?.tipo === 'resposta_publica'));
    if (!entrega) erros.push(e('sem_entrega', 'Ligue o gatilho a pelo menos uma mensagem'));
  }
  return erros;
}

export const grafoVazio = (gatilho: DadosGatilho): Grafo => ({
  versao: 1, entrada: 'gatilho', nos: [{ id: 'gatilho', tipo: 'gatilho', posicao: { x: 0, y: 120 }, dados: gatilho }], fios: [],
});

/** Proximo no pela porta (null = fim do ramo). */
export function seguir(g: Grafo, origem: string, porta: string): string | null {
  return g.fios.find((f) => f.origem === origem && f.porta === porta)?.destino ?? null;
}

export function noDe(g: Grafo, id: string): No | null {
  return g.nos.find((n) => n.id === id) ?? null;
}

export const normalizar = (s: string) => s.normalize('NFD').replace(/[̀-ͯ]/g, '').trim().toLowerCase().replace(/\s+/g, ' ');

/** Palavra-chave do gatilho casa com o texto recebido. */
export function casaPalavras(texto: string, palavras: string[] | undefined, modo: Correspondencia = 'contem'): boolean {
  const ps = (palavras ?? []).map(normalizar).filter(Boolean);
  if (modo === 'qualquer' || !ps.length) return true;
  const t = normalizar(texto);
  if (modo === 'exata') return ps.includes(t);
  if (modo === 'palavra') { const tokens = new Set(t.split(/[^a-z0-9]+/).filter(Boolean)); return ps.some((p) => tokens.has(p)); }
  return ps.some((p) => t.includes(p));
}

/** Alvo do gatilho de comentario: geral (todos os posts da conta, inclusive futuros) ou a lista de posts escolhidos. */
export function alvoPosts(g: DadosGatilho): { geral: boolean; ids: string[] } {
  const modo = g.modo_posts ?? ((g.post_ids ?? []).length || g.post_id ? 'especificos' : 'geral');
  if (modo === 'geral') return { geral: true, ids: [] };
  const ids = [...new Set([...(g.post_ids ?? []), ...(g.modo_posts ? [] : g.post_id ? [g.post_id] : [])].filter(Boolean))];
  return { geral: false, ids };
}

/** O comentario (post e conta de origem) cabe no gatilho: conta do canal escolhido e post geral ou da lista. */
export function gatilhoCasaComentario(g: DadosGatilho, ev: { post_id: string; conta_id?: string | null; conta_usuario?: string | null }): boolean {
  if (g.conta_id && ev.conta_id && g.conta_id !== ev.conta_id) return false;
  if (g.conta_usuario && ev.conta_usuario && normalizar(g.conta_usuario.replace(/^@/, '')) !== normalizar(ev.conta_usuario.replace(/^@/, ''))) return false;
  const a = alvoPosts(g);
  return a.geral || a.ids.includes(ev.post_id);
}
