/** Leituras do fluxo: lista com totais, ficha com contadores por no e historico de execucao. */
import type pg from 'pg';
import { decodificarCursor, pagina } from '../../compartilhado/cursor.ts';

export interface FiltroFluxos { canal?: string; estado?: string; busca?: string; cursor?: string; limite?: number }

export async function listarFluxos(c: pg.PoolClient, f: FiltroFluxos = {}) {
  const lim = Math.min(Math.max(f.limite ?? 50, 1), 200);
  const cur = decodificarCursor(f.cursor);
  const r = await c.query(
    `SELECT f.id, f.nome, f.canal, f.gatilho, f.config_gatilho, f.estado, f.versao, f.ativada_em, f.created_at, f.updated_at,
       jsonb_array_length(f.grafo->'nos') AS nos,
       (SELECT count(*) FROM automacoes_execucoes e WHERE e.fluxo_id = f.id)::int AS disparos,
       (SELECT count(*) FROM automacoes_passos p WHERE p.fluxo_id = f.id AND p.evento = 'clique')::int AS cliques,
       (SELECT max(e.created_at) FROM automacoes_execucoes e WHERE e.fluxo_id = f.id) AS ultimo_disparo
     FROM automacoes_fluxos f
     WHERE f.deleted_at IS NULL AND ($1::text IS NULL OR f.canal = $1) AND ($2::text IS NULL OR f.estado = $2)
       AND ($3::text IS NULL OR f.nome ILIKE '%' || $3 || '%')
       AND ($4::timestamptz IS NULL OR (f.created_at, f.id) > ($4::timestamptz, $5::uuid))
     ORDER BY f.created_at, f.id LIMIT $6`,
    [f.canal ?? null, f.estado ?? null, f.busca?.trim() || null, cur?.[0] ?? null, cur?.[1] ?? null, lim + 1],
  );
  return pagina(r.rows, lim);
}

export async function obterFluxo(c: pg.PoolClient, id: string) {
  const r = await c.query(
    `SELECT id, nome, canal, gatilho, config_gatilho, grafo, estado, versao, ativada_em, created_at, updated_at FROM automacoes_fluxos WHERE id = $1 AND deleted_at IS NULL`,
    [id],
  );
  const f = r.rows[0];
  if (!f) return null;
  const cont = await c.query(
    `SELECT no_id, count(*) FILTER (WHERE evento = 'disparo' AND resultado IN ('ok', 'aguardando'))::int AS disparos,
       count(*) FILTER (WHERE evento = 'clique')::int AS cliques,
       count(*) FILTER (WHERE resultado = 'falhou')::int AS falhas,
       count(*) FILTER (WHERE resultado = 'ignorado')::int AS ignorados
     FROM automacoes_passos WHERE fluxo_id = $1 GROUP BY no_id`,
    [id],
  );
  const totais = (await c.query(
    `SELECT count(*)::int AS disparos, count(*) FILTER (WHERE estado = 'concluida')::int AS concluidas, count(*) FILTER (WHERE estado = 'falhou')::int AS falhas,
       count(*) FILTER (WHERE estado IN ('aguardando_clique', 'aguardando_tempo', 'em_andamento'))::int AS em_andamento
     FROM automacoes_execucoes WHERE fluxo_id = $1`,
    [id],
  )).rows[0];
  return { ...f, contadores: Object.fromEntries(cont.rows.map((x) => [x.no_id, { disparos: x.disparos, cliques: x.cliques, falhas: x.falhas, ignorados: x.ignorados }])), totais };
}

export async function listarExecucoes(c: pg.PoolClient, fluxoId: string, limite = 50) {
  const r = await c.query(
    `SELECT e.id, e.contato, e.contato_nome, e.estado, e.erro, e.chave_evento, e.created_at, e.concluida_em, e.contexto->>'texto' AS texto,
       coalesce((SELECT json_agg(json_build_object('no_id', p.no_id, 'tipo_no', p.tipo_no, 'evento', p.evento, 'resultado', p.resultado, 'detalhe', p.detalhe, 'em', p.created_at) ORDER BY p.created_at)
         FROM automacoes_passos p WHERE p.execucao_id = e.id), '[]') AS passos
     FROM automacoes_execucoes e WHERE e.fluxo_id = $1 AND e.deleted_at IS NULL ORDER BY e.created_at DESC LIMIT $2`,
    [fluxoId, Math.min(Math.max(limite, 1), 200)],
  );
  return r.rows;
}

/** Opcoes do editor: etapas dos pipelines (interface publicada do Pipeline), tags (Cadastros) e templates aprovados. */
export async function opcoesEditor(c: pg.PoolClient) {
  const existe = async (t: string) => ((await c.query(`SELECT to_regclass($1) AS t`, [t])).rows[0]?.t ?? null) !== null;
  const etapas = (await existe('pipeline_etapas'))
    ? (await c.query(
        `SELECT e.id, e.nome, f.id AS funil_id, f.nome AS funil FROM pipeline_etapas e JOIN pipeline_funis f ON f.id = e.funil_id AND f.deleted_at IS NULL AND NOT f.arquivado
         WHERE e.deleted_at IS NULL AND e.tipo = 'aberta' ORDER BY f.ordem, f.nome, e.ordem LIMIT 300`,
      )).rows
    : [];
  const tags = (await c.query(`SELECT id, nome, tipo FROM cadastros_classificacoes WHERE deleted_at IS NULL ORDER BY tipo, nome LIMIT 300`)).rows;
  const templates = (await c.query(`SELECT id, nome, idioma, botoes FROM automacoes_templates WHERE estado = 'aprovado' AND deleted_at IS NULL ORDER BY nome`)).rows;
  const canais = (await c.query(`SELECT id, canal, usuario, nome, conta_id FROM integracoes_canais WHERE estado = 'ativo' AND deleted_at IS NULL ORDER BY canal, conectado_em DESC`)).rows;
  return { etapas, tags, templates, canais };
}
