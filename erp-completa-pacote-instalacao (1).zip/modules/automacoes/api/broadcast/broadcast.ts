/**
 * Broadcast do WhatsApp: template aprovado para um segmento de clientes do Cadastros (tag, setor), com
 * agendamento, ritmo de envio (por minuto, em lotes pela fila) e relatorio. Clique em botao de resposta rapida do
 * template registra o clique e pode iniciar a automacao associada (mesmo motor da aba Automacoes).
 */
import { randomUUID } from 'node:crypto';
import { erroDe, fail, ok, okVazio, type ErroDominio, type Result } from '../compartilhado/result.ts';
import type { ContextoCaso } from '../compartilhado/efeitos.ts';
import { normalizar } from '../fluxo/model/grafo.ts';
import { ErroCanal, type CanalEnvio, type TemplateRef } from '../motor/model/portas.ts';

export const TABELA_BROADCASTS = 'automacoes_broadcasts';
export const TIPO_JOB_BROADCAST = 'automacoes.broadcast_lote';
export const JANELA_CLIQUE_MS = 7 * 24 * 3600 * 1000;

export type EstadoBroadcast = 'rascunho' | 'agendado' | 'enviando' | 'concluido' | 'cancelado';
export interface Segmento { tag_ids?: string[]; setor_ids?: string[]; somente_clientes?: boolean }
export interface DadosBroadcast {
  id: string; nome: string; template_id: string; parametros: string[]; segmento: Segmento; agendado_para: string | null;
  ritmo_por_minuto: number; fluxo_id: string | null; estado: EstadoBroadcast; total: number; iniciado_em: string | null; concluido_em: string | null;
}
export type EntradaBroadcast = Partial<Pick<DadosBroadcast, 'parametros' | 'segmento' | 'agendado_para' | 'ritmo_por_minuto' | 'fluxo_id'>> & { nome: string; template_id: string };

function validar(d: DadosBroadcast): ErroDominio[] {
  const e: ErroDominio[] = [];
  if (d.nome.trim().length < 2 || d.nome.length > 120) e.push(erroDe('nome_invalido', 'Nome de 2 a 120 caracteres', 'nome'));
  if (!/^[0-9a-f-]{36}$/.test(d.template_id)) e.push(erroDe('template_invalido', 'Escolha o template', 'template_id'));
  if (!Number.isInteger(d.ritmo_por_minuto) || d.ritmo_por_minuto < 1 || d.ritmo_por_minuto > 600) e.push(erroDe('ritmo_invalido', 'Ritmo de 1 a 600 mensagens por minuto', 'ritmo_por_minuto'));
  if (d.agendado_para && Number.isNaN(Date.parse(d.agendado_para))) e.push(erroDe('data_invalida', 'Data de agendamento invalida', 'agendado_para'));
  if (d.parametros.length > 20 || d.parametros.some((p) => typeof p !== 'string' || p.length > 200)) e.push(erroDe('parametros_invalidos', 'Ate 20 parametros de ate 200 caracteres', 'parametros'));
  return e;
}

export class Broadcast {
  private constructor(private readonly p: DadosBroadcast) {}
  static tryCreate(e: EntradaBroadcast, id: string = randomUUID()): Result<Broadcast> {
    const d: DadosBroadcast = {
      id, nome: (e.nome ?? '').trim(), template_id: e.template_id ?? '', parametros: e.parametros ?? [], segmento: e.segmento ?? { somente_clientes: true },
      agendado_para: e.agendado_para ?? null, ritmo_por_minuto: e.ritmo_por_minuto ?? 30, fluxo_id: e.fluxo_id ?? null, estado: 'rascunho', total: 0, iniciado_em: null, concluido_em: null,
    };
    const erros = validar(d);
    return erros.length ? fail(...erros) : ok(new Broadcast(d));
  }
  static reidratar(d: DadosBroadcast) { return new Broadcast({ ...d }); }
  get id() { return this.p.id; }
  get estado() { return this.p.estado; }
  editar(e: Partial<EntradaBroadcast>): Result<Broadcast> {
    if (this.p.estado !== 'rascunho') return fail(erroDe('transicao_invalida', 'So rascunho pode ser editado', 'estado'));
    const d = { ...this.p, ...Object.fromEntries(Object.entries(e).filter(([, v]) => v !== undefined)) } as DadosBroadcast;
    const erros = validar(d);
    return erros.length ? fail(...erros) : ok(new Broadcast(d));
  }
  com(p: Partial<DadosBroadcast>) { return new Broadcast({ ...this.p, ...p }); }
  paraDados(): DadosBroadcast { return { ...this.p, parametros: [...this.p.parametros], segmento: { ...this.p.segmento } }; }
}

export interface Destinatario { parceiro_id: string; telefone: string }
export interface EnvioPendente { id: string; parceiro_id: string; telefone: string }

export interface RepoBroadcast {
  obter(id: string): Promise<Broadcast | null>;
  inserir(b: Broadcast): Promise<void>;
  atualizar(b: Broadcast): Promise<void>;
  /** Clientes do segmento com telefone (E.164), sem repetir telefone. */
  destinatarios(s: Segmento): Promise<Destinatario[]>;
  criarEnvios(broadcastId: string, ds: Destinatario[]): Promise<number>;
  pendentes(broadcastId: string, limite: number): Promise<EnvioPendente[]>;
  marcarEnvio(id: string, p: { estado: 'enviado' | 'falhou'; id_externo?: string | null; erro?: string | null }): Promise<void>;
  /** Envio recente (enviado ha menos de 7 dias) para o telefone, com o template e a automacao do broadcast. */
  enviosRecentes(telefone: string, desde: Date): Promise<{ envio_id: string; broadcast_id: string; parceiro_id: string; fluxo_id: string | null; botoes: string[]; clicado: boolean }[]>;
  marcarClique(envioId: string, botao: string, quando: Date): Promise<void>;
  fluxoValido(id: string): Promise<boolean>;
}
export interface FilaJobs { agendar(tipo: string, payload: Record<string, unknown>, atrasoSeg: number): Promise<string> }
export interface TemplatesLeitura { template(id: string): Promise<TemplateRef | null> }

type Deps = { repo: RepoBroadcast; templates: TemplatesLeitura; fila: FilaJobs };

export class CriarBroadcast {
  constructor(private readonly d: Deps) {}
  async execute(ctx: ContextoCaso, e: EntradaBroadcast): Promise<Result<{ id: string }>> {
    const r = Broadcast.tryCreate(e);
    if (!r.ok) return r;
    const t = await this.d.templates.template(e.template_id);
    if (!t) return fail(erroDe('template_invalido', 'Template nao encontrado', 'template_id'));
    if (e.fluxo_id && !(await this.d.repo.fluxoValido(e.fluxo_id))) return fail(erroDe('fluxo_invalido', 'Automacao de broadcast do WhatsApp nao encontrada', 'fluxo_id'));
    await this.d.repo.inserir(r.valor);
    await ctx.efeitos.auditar('broadcast.criar', TABELA_BROADCASTS, r.valor.id, undefined, r.valor.paraDados());
    return ok({ id: r.valor.id });
  }
}

export class EditarBroadcast {
  constructor(private readonly d: Deps) {}
  async execute(ctx: ContextoCaso, e: Partial<EntradaBroadcast> & { id: string }): Promise<Result<void>> {
    const b = await this.d.repo.obter(e.id);
    if (!b) return fail(erroDe('nao_encontrado', 'Broadcast nao encontrado'));
    const { id: _id, ...resto } = e;
    const r = b.editar(resto);
    if (!r.ok) return r;
    if (resto.fluxo_id && !(await this.d.repo.fluxoValido(resto.fluxo_id))) return fail(erroDe('fluxo_invalido', 'Automacao de broadcast do WhatsApp nao encontrada', 'fluxo_id'));
    await this.d.repo.atualizar(r.valor);
    await ctx.efeitos.auditar('broadcast.editar', TABELA_BROADCASTS, b.id, b.paraDados(), r.valor.paraDados());
    return okVazio();
  }
}

/** Rascunho -> agendado: exige template aprovado; o primeiro lote sai na data agendada (ou agora). */
export class AgendarBroadcast {
  constructor(private readonly d: Deps & { relogio?: () => Date }) {}
  async execute(ctx: ContextoCaso, e: { id: string }): Promise<Result<{ job_id: string }>> {
    const b = await this.d.repo.obter(e.id);
    if (!b) return fail(erroDe('nao_encontrado', 'Broadcast nao encontrado'));
    if (b.estado !== 'rascunho') return fail(erroDe('transicao_invalida', 'So rascunho pode ser agendado', 'estado'));
    const d = b.paraDados();
    const t = await this.d.templates.template(d.template_id);
    if (!t || t.estado !== 'aprovado') return fail(erroDe('template_nao_aprovado', 'O template precisa estar aprovado pela Meta', 'template_id'));
    const agora = (this.d.relogio ?? (() => new Date()))();
    const atraso = d.agendado_para ? Math.max(0, Math.round((Date.parse(d.agendado_para) - agora.getTime()) / 1000)) : 0;
    await this.d.repo.atualizar(b.com({ estado: 'agendado' }));
    const job = await this.d.fila.agendar(TIPO_JOB_BROADCAST, { broadcast_id: d.id }, atraso);
    await ctx.efeitos.auditar('broadcast.agendar', TABELA_BROADCASTS, d.id, { estado: 'rascunho' }, { estado: 'agendado', agendado_para: d.agendado_para });
    return ok({ job_id: job });
  }
}

export class CancelarBroadcast {
  constructor(private readonly d: Deps) {}
  async execute(ctx: ContextoCaso, e: { id: string }): Promise<Result<void>> {
    const b = await this.d.repo.obter(e.id);
    if (!b) return fail(erroDe('nao_encontrado', 'Broadcast nao encontrado'));
    if (['concluido', 'cancelado'].includes(b.estado)) return fail(erroDe('transicao_invalida', 'Broadcast ja encerrado', 'estado'));
    await this.d.repo.atualizar(b.com({ estado: 'cancelado', concluido_em: new Date().toISOString() }));
    await ctx.efeitos.auditar('broadcast.cancelar', TABELA_BROADCASTS, b.id, { estado: b.estado }, { estado: 'cancelado' });
    return okVazio();
  }
}

/**
 * Lote do broadcast (worker): no primeiro lote resolve os destinatarios do segmento; envia ate `ritmo_por_minuto`
 * templates e reagenda o proximo lote em 60 s (rate limit). Cada envio leva a chave do proprio envio (idempotente).
 */
export class ProcessarLoteBroadcast {
  constructor(private readonly d: Deps & { canal: CanalEnvio; relogio?: () => Date }) {}
  async execute(ctx: ContextoCaso, e: { broadcast_id: string }): Promise<Result<{ enviados: number; falhas: number; restantes: boolean }>> {
    let b = await this.d.repo.obter(e.broadcast_id);
    if (!b || !['agendado', 'enviando'].includes(b.estado)) return ok({ enviados: 0, falhas: 0, restantes: false });
    const agora = (this.d.relogio ?? (() => new Date()))();
    let d = b.paraDados();
    const t = await this.d.templates.template(d.template_id);
    if (!t || t.estado !== 'aprovado') {
      await this.d.repo.atualizar(b.com({ estado: 'cancelado', concluido_em: agora.toISOString() }));
      await ctx.efeitos.auditar('broadcast.cancelar', TABELA_BROADCASTS, d.id, { estado: d.estado }, { estado: 'cancelado', motivo: 'template_nao_aprovado' });
      return ok({ enviados: 0, falhas: 0, restantes: false });
    }
    if (d.estado === 'agendado') {
      const ds = await this.d.repo.destinatarios(d.segmento);
      const total = await this.d.repo.criarEnvios(d.id, ds);
      b = b.com({ estado: 'enviando', total, iniciado_em: agora.toISOString() });
      d = b.paraDados();
      await this.d.repo.atualizar(b);
      await ctx.efeitos.publicar('broadcast.iniciado', { id: d.id, nome: d.nome, template_id: d.template_id, total });
    }
    let enviados = 0;
    let falhas = 0;
    for (const x of await this.d.repo.pendentes(d.id, d.ritmo_por_minuto)) {
      try {
        const r = await this.d.canal.enviarTemplate({ telefone: x.telefone, nome: t.nome, idioma: t.idioma, parametros: d.parametros, chave: `broadcast:${x.id}` });
        await this.d.repo.marcarEnvio(x.id, { estado: 'enviado', id_externo: r.id_externo });
        enviados++;
      } catch (err) {
        if (!(err instanceof ErroCanal) || !err.permanente) {
          // Falha transitoria (limite, rede): o que ja saiu fica gravado e o lote volta mais tarde.
          await this.d.fila.agendar(TIPO_JOB_BROADCAST, { broadcast_id: d.id }, 120);
          return ok({ enviados, falhas, restantes: true });
        }
        await this.d.repo.marcarEnvio(x.id, { estado: 'falhou', erro: err.message.slice(0, 300) });
        falhas++;
      }
    }
    const restantes = (await this.d.repo.pendentes(d.id, 1)).length > 0;
    if (restantes) await this.d.fila.agendar(TIPO_JOB_BROADCAST, { broadcast_id: d.id }, 60);
    else {
      await this.d.repo.atualizar(b.com({ estado: 'concluido', concluido_em: agora.toISOString() }));
      await ctx.efeitos.publicar('broadcast.concluido', { id: d.id, nome: d.nome, total: d.total });
    }
    return ok({ enviados, falhas, restantes });
  }
}

/** Clique em botao de resposta rapida do template: marca o primeiro clique e devolve a automacao associada. */
export class RegistrarCliqueBroadcast {
  constructor(private readonly d: { repo: RepoBroadcast }) {}
  async registrarClique(telefone: string, texto: string, quando: Date) {
    const t = normalizar(texto);
    for (const x of await this.d.repo.enviosRecentes(telefone, new Date(quando.getTime() - JANELA_CLIQUE_MS))) {
      const botao = x.botoes.find((b) => normalizar(b) === t);
      if (!botao) continue;
      if (!x.clicado) await this.d.repo.marcarClique(x.envio_id, botao, quando);
      return { fluxo_id: x.fluxo_id, envio_id: x.envio_id, broadcast_id: x.broadcast_id, parceiro_id: x.parceiro_id };
    }
    return null;
  }
}
