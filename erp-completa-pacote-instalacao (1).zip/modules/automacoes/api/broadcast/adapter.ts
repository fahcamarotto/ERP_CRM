/**
 * Adaptadores do broadcast: repositorio Postgres (segmento lido das tabelas do Cadastros) e relatorio. Entrega e
 * leitura chegam pelo status da mensagem espelhada no Conversas (conversas_mensagens.id_externo, tabela publicada).
 */
import type pg from 'pg';
import { Broadcast, type DadosBroadcast, type Destinatario, type EnvioPendente, type RepoBroadcast, type Segmento } from './broadcast.ts';

const COLUNAS = `id, nome, template_id, parametros, segmento, agendado_para, ritmo_por_minuto, fluxo_id, estado, total, iniciado_em, concluido_em`;
const iso = (v: unknown) => (v === null || v === undefined ? null : v instanceof Date ? v.toISOString() : String(v));
const daLinha = (r: Record<string, unknown>) => Broadcast.reidratar({ ...(r as unknown as DadosBroadcast), agendado_para: iso(r.agendado_para), iniciado_em: iso(r.iniciado_em), concluido_em: iso(r.concluido_em) });

/** Filtro do segmento sobre cadastros_parceiros (cliente ativo com telefone E.164), por tag e setor. */
const FILTRO_SEGMENTO = `p.deleted_at IS NULL AND p.estado = 'ativo' AND p.telefone IS NOT NULL
  AND ($1::boolean IS NOT TRUE OR p.e_cliente)
  AND (cardinality($2::uuid[]) = 0 OR EXISTS (SELECT 1 FROM cadastros_parceiro_tags t WHERE t.parceiro_id = p.id AND t.deleted_at IS NULL AND t.tag_id = ANY ($2::uuid[])))
  AND (cardinality($3::uuid[]) = 0 OR p.setor_id = ANY ($3::uuid[]))`;
const argsSegmento = (s: Segmento) => [s.somente_clientes !== false, s.tag_ids ?? [], s.setor_ids ?? []];

export class BroadcastRepoPg implements RepoBroadcast {
  constructor(private readonly c: pg.PoolClient) {}
  async obter(id: string) {
    const r = await this.c.query(`SELECT ${COLUNAS} FROM automacoes_broadcasts WHERE id = $1 AND deleted_at IS NULL FOR UPDATE`, [id]);
    return r.rows[0] ? daLinha(r.rows[0]) : null;
  }
  async inserir(b: Broadcast) {
    const d = b.paraDados();
    await this.c.query(
      `INSERT INTO automacoes_broadcasts (id, nome, template_id, parametros, segmento, agendado_para, ritmo_por_minuto, fluxo_id, estado, creator_id)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, nucleo_usuario_atual())`,
      [d.id, d.nome, d.template_id, JSON.stringify(d.parametros), JSON.stringify(d.segmento), d.agendado_para, d.ritmo_por_minuto, d.fluxo_id, d.estado],
    );
  }
  async atualizar(b: Broadcast) {
    const d = b.paraDados();
    await this.c.query(
      `UPDATE automacoes_broadcasts SET nome = $2, template_id = $3, parametros = $4, segmento = $5, agendado_para = $6, ritmo_por_minuto = $7, fluxo_id = $8,
         estado = $9, total = $10, iniciado_em = $11, concluido_em = $12 WHERE id = $1`,
      [d.id, d.nome, d.template_id, JSON.stringify(d.parametros), JSON.stringify(d.segmento), d.agendado_para, d.ritmo_por_minuto, d.fluxo_id, d.estado, d.total, d.iniciado_em, d.concluido_em],
    );
  }
  async destinatarios(s: Segmento): Promise<Destinatario[]> {
    const r = await this.c.query(`SELECT DISTINCT ON (p.telefone) p.id AS parceiro_id, p.telefone FROM cadastros_parceiros p WHERE ${FILTRO_SEGMENTO} ORDER BY p.telefone, p.created_at LIMIT 10000`, argsSegmento(s));
    return r.rows;
  }
  async criarEnvios(broadcastId: string, ds: Destinatario[]) {
    if (ds.length) {
      await this.c.query(
        `INSERT INTO automacoes_broadcast_envios (broadcast_id, parceiro_id, telefone)
         SELECT $1, x.parceiro_id, x.telefone FROM jsonb_to_recordset($2::jsonb) AS x(parceiro_id uuid, telefone text)
         ON CONFLICT (tenant_id, workspace_id, broadcast_id, parceiro_id) DO NOTHING`,
        [broadcastId, JSON.stringify(ds)],
      );
    }
    return Number((await this.c.query(`SELECT count(*) AS n FROM automacoes_broadcast_envios WHERE broadcast_id = $1`, [broadcastId])).rows[0].n);
  }
  async pendentes(broadcastId: string, limite: number): Promise<EnvioPendente[]> {
    return (await this.c.query(
      `SELECT id, parceiro_id, telefone FROM automacoes_broadcast_envios WHERE broadcast_id = $1 AND estado = 'pendente' ORDER BY created_at, id LIMIT $2 FOR UPDATE SKIP LOCKED`,
      [broadcastId, limite],
    )).rows;
  }
  async marcarEnvio(id: string, p: { estado: 'enviado' | 'falhou'; id_externo?: string | null; erro?: string | null }) {
    await this.c.query(`UPDATE automacoes_broadcast_envios SET estado = $2, id_externo = $3, erro = $4, enviado_em = CASE WHEN $2 = 'enviado' THEN now() END WHERE id = $1`, [id, p.estado, p.id_externo ?? null, p.erro ?? null]);
  }
  async enviosRecentes(telefone: string, desde: Date) {
    const r = await this.c.query(
      `SELECT e.id AS envio_id, e.broadcast_id, e.parceiro_id, b.fluxo_id, e.clicado_em IS NOT NULL AS clicado,
         coalesce((SELECT array_agg(x->>'texto') FROM jsonb_array_elements(t.botoes) x WHERE x->>'tipo' = 'resposta'), '{}') AS botoes
       FROM automacoes_broadcast_envios e JOIN automacoes_broadcasts b ON b.id = e.broadcast_id JOIN automacoes_templates t ON t.id = b.template_id
       WHERE e.telefone = $1 AND e.enviado_em >= $2 AND e.deleted_at IS NULL ORDER BY e.enviado_em DESC LIMIT 10`,
      [telefone, desde],
    );
    return r.rows;
  }
  async marcarClique(envioId: string, botao: string, quando: Date) {
    await this.c.query(`UPDATE automacoes_broadcast_envios SET clicado_em = coalesce(clicado_em, $2), botao = coalesce(botao, $3) WHERE id = $1`, [envioId, quando, botao]);
  }
  async fluxoValido(id: string) {
    return ((await this.c.query(`SELECT 1 FROM automacoes_fluxos WHERE id = $1 AND canal = 'whatsapp' AND gatilho = 'broadcast' AND deleted_at IS NULL`, [id])).rowCount ?? 0) > 0;
  }
}

/** Quantos clientes o segmento alcanca (previa antes de agendar). */
export async function previaSegmento(c: pg.PoolClient, s: Segmento) {
  return Number((await c.query(`SELECT count(DISTINCT p.telefone) AS n FROM cadastros_parceiros p WHERE ${FILTRO_SEGMENTO}`, argsSegmento(s))).rows[0].n);
}

const RELATORIO = `
  SELECT count(*)::int AS total,
    count(*) FILTER (WHERE x.st IN ('enviado', 'entregue', 'lido'))::int AS enviados,
    count(*) FILTER (WHERE x.st IN ('entregue', 'lido'))::int AS entregues,
    count(*) FILTER (WHERE x.st = 'lido')::int AS lidos,
    count(*) FILTER (WHERE x.st = 'falhou')::int AS falhas,
    count(*) FILTER (WHERE x.st = 'pendente')::int AS pendentes,
    count(*) FILTER (WHERE x.clicado_em IS NOT NULL)::int AS cliques
  FROM (SELECT e.clicado_em, CASE WHEN e.estado <> 'enviado' THEN e.estado WHEN m.status = 'lida' THEN 'lido' WHEN m.status = 'entregue' THEN 'entregue'
          WHEN m.status = 'falhou' THEN 'falhou' ELSE 'enviado' END AS st
        FROM automacoes_broadcast_envios e
        LEFT JOIN LATERAL (SELECT status FROM conversas_mensagens cm WHERE cm.id_externo = e.id_externo AND cm.deleted_at IS NULL LIMIT 1) m ON e.id_externo IS NOT NULL
        WHERE e.broadcast_id = $1 AND e.deleted_at IS NULL) x`;

export async function relatorioBroadcast(c: pg.PoolClient, id: string) {
  return (await c.query(RELATORIO, [id])).rows[0];
}

export async function listarBroadcasts(c: pg.PoolClient) {
  const r = await c.query(
    `SELECT b.${COLUNAS.split(', ').join(', b.')}, b.created_at, t.nome AS template_nome, f.nome AS fluxo_nome FROM automacoes_broadcasts b
     JOIN automacoes_templates t ON t.id = b.template_id LEFT JOIN automacoes_fluxos f ON f.id = b.fluxo_id
     WHERE b.deleted_at IS NULL ORDER BY b.created_at DESC LIMIT 200`,
  );
  return Promise.all(r.rows.map(async (b) => ({ ...b, relatorio: await relatorioBroadcast(c, b.id) })));
}

export async function obterBroadcast(c: pg.PoolClient, id: string) {
  const b = (await c.query(`SELECT ${COLUNAS}, created_at FROM automacoes_broadcasts WHERE id = $1 AND deleted_at IS NULL`, [id])).rows[0];
  if (!b) return null;
  const envios = (await c.query(
    `SELECT e.id, e.telefone, e.estado, e.erro, e.enviado_em, e.clicado_em, e.botao, p.nome FROM automacoes_broadcast_envios e
     JOIN cadastros_parceiros p ON p.id = e.parceiro_id WHERE e.broadcast_id = $1 ORDER BY e.created_at LIMIT 500`,
    [id],
  )).rows;
  return { ...b, relatorio: await relatorioBroadcast(c, id), envios };
}
