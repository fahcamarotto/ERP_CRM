/**
 * Plugin do modulo Automacoes, registrado sozinho com prefixo /api/v1/automacoes.
 * Importar ./tools.ts registra as @tool (MCP e REST) no carregamento.
 */
import type { FastifyPluginAsync } from '@erp/api/sdk';
import './tools.ts';
import { rotasAutomacoes } from './routes.ts';

const plugin: FastifyPluginAsync = async (app) => {
  rotasAutomacoes(app);
};

export default plugin;
