/**
 * Posts do Instagram da conta conectada para o seletor do gatilho de comentario. Fonte: Zernio (GET /inbox/comments
 * por accountId, mais novos primeiro, cursor da Zernio). O vinculo canal -> conta sai de `integracoes_canais`
 * (tabela publicada do Integracoes, so leitura sob RLS). Cada listagem grava o cache `automacoes_posts_instagram`,
 * que renova a URL da miniatura (a do Instagram expira) servida pelo proxy com sessao da API.
 */
import type pg from 'pg';
import { erroDe, FalhaDeCasoDeUso } from '../compartilhado/result.ts';
import { normalizar } from '../fluxo/model/grafo.ts';
import { ErroCanal } from '../motor/model/portas.ts';
import type { ClienteZernioAutomacoes, PostZernio } from '../zernio/cliente.ts';

export interface CanalInstagram { id: string; conta_id: string; usuario: string; nome: string }
export interface PostInstagramDTO {
  id: string; legenda: string; tipo: 'post' | 'reels' | 'carrossel'; publicado_em: string | null; link: string | null;
  comentarios: number | null; curtidas: number | null; miniatura: string | null;
}
export interface FiltroPostsInstagram { canal_id?: string; busca?: string; limite?: number; cursor?: string }

/** Paginas lidas da Zernio por busca de legenda (100 posts cada), para nao varrer o perfil inteiro de uma vez. */
export const PAGINAS_BUSCA = 5;

export async function canalInstagram(c: pg.PoolClient, canalId?: string | null): Promise<CanalInstagram | null> {
  const r = await c.query(
    `SELECT id, conta_id, usuario, nome FROM integracoes_canais
     WHERE canal = 'instagram' AND estado = 'ativo' AND deleted_at IS NULL AND ($1::uuid IS NULL OR id = $1::uuid)
     ORDER BY conectado_em DESC NULLS LAST LIMIT 1`,
    [canalId ?? null],
  );
  return (r.rows[0] as CanalInstagram | undefined) ?? null;
}

export const caminhoMiniatura = (conta: string, post: string) =>
  `/api/v1/automacoes/instagram/posts/${encodeURIComponent(post)}/miniatura?conta=${encodeURIComponent(conta)}`;

/** Grava ou renova os posts no cache do workspace (URL da miniatura e contagens mais recentes). */
export async function gravarCachePosts(c: pg.PoolClient, conta: string, posts: PostZernio[]): Promise<void> {
  if (!posts.length) return;
  await c.query(
    `INSERT INTO automacoes_posts_instagram (conta_id, post_id, legenda, tipo, publicado_em, link, miniatura_url, comentarios, curtidas)
     SELECT $1, x.id, x.legenda, x.tipo, x.publicado_em, x.link, x.miniatura_url, x.comentarios, x.curtidas
     FROM jsonb_to_recordset($2::jsonb) AS x(id text, legenda text, tipo text, publicado_em timestamptz, link text, miniatura_url text, comentarios int, curtidas int)
     ON CONFLICT (tenant_id, workspace_id, conta_id, post_id) DO UPDATE SET
       legenda = EXCLUDED.legenda, tipo = EXCLUDED.tipo, publicado_em = EXCLUDED.publicado_em, link = EXCLUDED.link,
       miniatura_url = COALESCE(EXCLUDED.miniatura_url, automacoes_posts_instagram.miniatura_url),
       comentarios = EXCLUDED.comentarios, curtidas = EXCLUDED.curtidas, deleted_at = NULL`,
    [conta, JSON.stringify(posts.map((p) => ({ ...p, legenda: p.legenda.slice(0, 2200) })))],
  );
}

function falhaZernio(e: unknown): never {
  if (e instanceof ErroCanal) throw new FalhaDeCasoDeUso([erroDe('zernio_indisponivel', e.message)]);
  throw e;
}

/** Marca carrossel nos posts de feed (o link /p/ nao distingue foto de carrossel). */
async function marcarCarrosseis(zernio: ClienteZernioAutomacoes, conta: string, posts: PostZernio[]): Promise<void> {
  const feed = posts.filter((p) => p.tipo === 'post' && p.publicado_em);
  if (!feed.length) return;
  const datas = feed.map((p) => p.publicado_em!).sort();
  const ate = new Date(Date.parse(datas[datas.length - 1]!) + 86_400_000).toISOString();
  const ids = await zernio.carrosseis(conta, datas[0]!, ate);
  for (const p of feed) if (ids.has(p.id)) p.tipo = 'carrossel';
}

export async function listarPostsInstagram(c: pg.PoolClient, zernio: ClienteZernioAutomacoes, f: FiltroPostsInstagram) {
  const canal = await canalInstagram(c, f.canal_id);
  if (!canal) throw new FalhaDeCasoDeUso([erroDe('canal_nao_conectado', 'Nenhum Instagram conectado (Integracoes > Conectores)', 'canal_id')]);
  const limite = Math.min(Math.max(f.limite ?? 24, 1), 50);
  const busca = f.busca?.trim() ? normalizar(f.busca) : '';
  let itens: PostZernio[] = [];
  let cursor: string | null = f.cursor ?? null;
  try {
    if (!busca) {
      const p = await zernio.postsDaConta(canal.conta_id, { limite, cursor });
      itens = p.itens;
      cursor = p.proximo_cursor;
    } else {
      // Busca por legenda: a Zernio nao filtra texto, entao le ate PAGINAS_BUSCA paginas e devolve o cursor de onde parou.
      for (let i = 0; i < PAGINAS_BUSCA && itens.length < limite; i++) {
        const p = await zernio.postsDaConta(canal.conta_id, { limite: 100, cursor });
        await gravarCachePosts(c, canal.conta_id, p.itens);
        itens.push(...p.itens.filter((x) => normalizar(x.legenda).includes(busca)));
        cursor = p.proximo_cursor;
        if (!cursor) break;
      }
    }
    await marcarCarrosseis(zernio, canal.conta_id, itens);
  } catch (e) { falhaZernio(e); }
  await gravarCachePosts(c, canal.conta_id, itens);
  const dto: PostInstagramDTO[] = itens.map((p) => ({
    id: p.id, legenda: p.legenda, tipo: p.tipo, publicado_em: p.publicado_em, link: p.link, comentarios: p.comentarios, curtidas: p.curtidas,
    miniatura: p.miniatura_url ? caminhoMiniatura(canal.conta_id, p.id) : null,
  }));
  return { canal: { id: canal.id, usuario: canal.usuario, nome: canal.nome }, itens: dto, proximo_cursor: cursor };
}

/** URL atual da miniatura no cache (RLS: so posts do workspace da sessao). */
export async function urlMiniatura(c: pg.PoolClient, conta: string, post: string): Promise<string | null> {
  const r = await c.query(
    `SELECT miniatura_url FROM automacoes_posts_instagram WHERE conta_id = $1 AND post_id = $2 AND deleted_at IS NULL`,
    [conta, post],
  );
  return (r.rows[0]?.miniatura_url as string | undefined) ?? null;
}

/** So CDN do Instagram e do Facebook passam pelo proxy (sem SSRF para outro host). */
export function hostMiniaturaPermitido(url: string): boolean {
  try {
    const u = new URL(url);
    return u.protocol === 'https:' && /(^|\.)(cdninstagram\.com|fbcdn\.net)$/.test(u.hostname);
  } catch { return false; }
}
