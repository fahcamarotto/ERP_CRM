/** Rotas REST que nao sao @tool: exclusao logica de automacao e de template (so pessoa ou chave com escrita). */
import { esquemaErro, requer, type FastifyInstance } from '@erp/api/sdk';
import { naTransacao } from './borda.ts';
import { exigirOk } from './compartilhado/result.ts';
import { uuid } from './esquemas.ts';
import { hostMiniaturaPermitido, urlMiniatura } from './instagram/posts.ts';

const tags = ['automacoes'];
const erros = { 400: esquemaErro, 403: esquemaErro, 404: esquemaErro, 409: esquemaErro };
const params = { type: 'object', required: ['id'], properties: { id: uuid } } as const;

export function rotasAutomacoes(app: FastifyInstance): void {
  // Proxy da miniatura do post do Instagram: a URL do CDN expira e e renovada a cada listagem (cache do modulo).
  app.get<{ Params: { post_id: string }; Querystring: { conta: string } }>('/instagram/posts/:post_id/miniatura', {
    preHandler: requer('automacoes.ver'),
    schema: {
      tags, summary: 'Miniatura do post do Instagram (proxy com sessao)',
      params: { type: 'object', required: ['post_id'], properties: { post_id: { type: 'string', pattern: '^[A-Za-z0-9_-]{1,80}$' } } },
      querystring: { type: 'object', additionalProperties: false, required: ['conta'], properties: { conta: { type: 'string', pattern: '^[A-Za-z0-9_-]{4,128}$' } } },
    },
  }, async (req, reply) => {
    const url = await naTransacao(req, async (_casos, _ctx, c) => urlMiniatura(c, req.query.conta, req.params.post_id));
    if (!url || !hostMiniaturaPermitido(url)) return reply.code(404).send({ erro: { codigo: 'nao_encontrado', mensagem: 'Miniatura indisponivel', detalhes: [] } });
    let r: Response;
    try { r = await fetch(url, { signal: AbortSignal.timeout(15_000) }); } catch { r = new Response(null, { status: 502 }); }
    const tipo = r.headers.get('content-type') ?? '';
    if (!r.ok || !tipo.startsWith('image/')) return reply.code(404).send({ erro: { codigo: 'miniatura_expirada', mensagem: 'Miniatura expirada; atualize a lista de posts', detalhes: [] } });
    return reply.header('content-type', tipo).header('cache-control', 'private, max-age=3600').send(Buffer.from(await r.arrayBuffer()));
  });

  app.delete<{ Params: { id: string } }>('/fluxos/:id', {
    preHandler: requer('automacoes.excluir'),
    schema: { tags, summary: 'Exclui automacao pausada ou rascunho (ExcluirFluxo)', params, response: erros },
  }, async (req, reply) => {
    await naTransacao(req, async (casos, ctx) => exigirOk(await casos.excluirFluxo.execute(ctx, { id: req.params.id })));
    return reply.code(204).send();
  });

  app.delete<{ Params: { id: string } }>('/templates/:id', {
    preHandler: requer('automacoes.excluir'),
    schema: { tags, summary: 'Exclui template em rascunho ou rejeitado (ExcluirTemplate)', params, response: erros },
  }, async (req, reply) => {
    await naTransacao(req, async (casos, ctx) => exigirOk(await casos.excluirTemplate.execute(ctx, { id: req.params.id })));
    return reply.code(204).send();
  });
}
