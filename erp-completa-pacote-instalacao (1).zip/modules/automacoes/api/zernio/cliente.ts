/**
 * Cliente HTTP da Zernio usado pelas automacoes (fetch proprio). Base ZERNIO_API_BASE (mock nos testes) ou
 * https://zernio.com/api/v1; chave ZERNIO_API_KEY injetada do cofre por op run. Nunca imprime a chave.
 * Erro 4xx (fora 408 e 429) e recusa permanente do provedor; 5xx, 408, 429 e rede sao transitorios.
 */
import { ErroCanal } from '../motor/model/portas.ts';

type Obj = Record<string, unknown>;
const obj = (v: unknown): Obj => (v && typeof v === 'object' && !Array.isArray(v) ? (v as Obj) : {});
const txt = (v: unknown): string => (typeof v === 'string' ? v : typeof v === 'number' ? String(v) : '');

export const BASE_ZERNIO = 'https://zernio.com/api/v1';

export interface PostZernio {
  id: string; legenda: string; publicado_em: string | null; link: string | null; miniatura_url: string | null;
  comentarios: number | null; curtidas: number | null; tipo: 'post' | 'reels' | 'carrossel';
}

export interface Pedido { metodo: 'GET' | 'POST'; caminho: string; query?: Record<string, string | null | undefined>; corpo?: unknown; idempotencia?: string }

export class ClienteZernioAutomacoes {
  constructor(private readonly o: { base?: string; token?: string; timeoutMs?: number } = {}) {}

  private get base() { return (this.o.base ?? process.env.ZERNIO_API_BASE ?? BASE_ZERNIO).replace(/\/$/, ''); }
  private get token() { return this.o.token ?? process.env.ZERNIO_API_KEY ?? ''; }

  async pedir<T = Obj>(p: Pedido): Promise<T> {
    if (!this.token) throw new ErroCanal('credencial de plataforma da Zernio ausente', false);
    const u = new URL(`${this.base}/${p.caminho.replace(/^\//, '')}`);
    for (const [k, v] of Object.entries(p.query ?? {})) if (v !== null && v !== undefined && v !== '') u.searchParams.set(k, v);
    const headers: Record<string, string> = { authorization: `Bearer ${this.token}`, accept: 'application/json' };
    if (p.corpo !== undefined) headers['content-type'] = 'application/json';
    if (p.idempotencia) headers['idempotency-key'] = p.idempotencia.slice(0, 200);
    let res: Response;
    try {
      res = await fetch(u, { method: p.metodo, headers, body: p.corpo === undefined ? undefined : JSON.stringify(p.corpo), signal: AbortSignal.timeout(this.o.timeoutMs ?? 20_000) });
    } catch (e) {
      throw new ErroCanal(`zernio indisponivel: ${(e as Error).name}`, false);
    }
    const bruto = await res.text();
    let corpo: unknown = null;
    try { corpo = bruto ? JSON.parse(bruto) : null; } catch { corpo = { erro: bruto.slice(0, 200) }; }
    if (!res.ok) {
      const c = obj(corpo);
      const msg = txt(c.error) || txt(obj(c.error).message) || txt(c.message) || `HTTP ${res.status}`;
      throw new ErroCanal(`zernio ${res.status}: ${msg}`.slice(0, 300), res.status < 500 && res.status !== 408 && res.status !== 429);
    }
    return corpo as T;
  }

  /** Resposta publica ao comentario (POST /inbox/comments/{postId}). */
  async responderComentario(conta: string, postId: string, comentarioId: string, texto: string, idem: string) {
    const r = await this.pedir({ metodo: 'POST', caminho: `inbox/comments/${encodeURIComponent(postId)}`, corpo: { accountId: conta, commentId: comentarioId, message: texto }, idempotencia: idem });
    return { id_externo: txt(obj(obj(r).data).commentId) || null };
  }

  /** DM privada a partir do comentario (uma por comentario, ate 7 dias). */
  async respostaPrivada(conta: string, postId: string, comentarioId: string, corpo: Obj, idem: string) {
    const r = await this.pedir({ metodo: 'POST', caminho: `inbox/comments/${encodeURIComponent(postId)}/${encodeURIComponent(comentarioId)}/private-reply`, corpo: { accountId: conta, ...corpo }, idempotencia: idem });
    return { id_externo: txt(obj(r).messageId) || txt(obj(obj(r).data).messageId) || null };
  }

  /** Mensagem numa conversa existente (texto, midia, botoes). */
  async enviarNaConversa(conta: string, conversaId: string, corpo: Obj, idem: string) {
    const r = await this.pedir({ metodo: 'POST', caminho: `inbox/conversations/${encodeURIComponent(conversaId)}/messages`, corpo: { accountId: conta, ...corpo }, idempotencia: idem });
    const d = obj(obj(r).data);
    return { id_externo: txt(d.messageId) || txt(d.platformMessageId) || null };
  }

  /** Template aprovado para um numero (abre conversa nova quando nao existe). */
  async enviarTemplate(conta: string, participante: string, nome: string, idioma: string, parametros: string[], idem: string) {
    const r = await this.pedir({ metodo: 'POST', caminho: 'inbox/conversations', corpo: { accountId: conta, participantId: participante, templateName: nome, templateLanguage: idioma, templateParams: parametros }, idempotencia: idem });
    const d = obj(obj(r).data);
    return { id_externo: txt(d.messageId) || null, conversa_id: txt(d.conversationId) || null };
  }

  async criarTemplate(conta: string, e: { nome: string; idioma: string; categoria: string; componentes: Obj[] }) {
    const r = obj(await this.pedir({ metodo: 'POST', caminho: 'whatsapp/templates', corpo: { accountId: conta, name: e.nome, category: e.categoria, language: e.idioma, components: e.componentes }, idempotencia: `erp-template-${conta}-${e.nome}-${e.idioma}` }));
    const t = obj(r.template);
    return { id_externo: txt(t.id) || null, status: txt(t.status) || 'PENDING' };
  }

  async listarTemplates(conta: string) {
    const r = obj(await this.pedir({ metodo: 'GET', caminho: 'whatsapp/templates', query: { accountId: conta } }));
    const lista = Array.isArray(r.templates) ? r.templates : Array.isArray(r.data) ? r.data : [];
    return lista.map(obj).map((t) => ({
      id: txt(t.id) || null, nome: txt(t.name), idioma: txt(t.language), status: txt(t.status),
      motivo: txt(t.reason) || txt(t.rejected_reason) || txt(t.rejectionReason) || null,
    })).filter((t) => t.nome);
  }

  /**
   * Posts da conta Instagram, mais novos primeiro (GET /inbox/comments?accountId, cursor opaco da Zernio, ate 100 por
   * pagina): id da midia, legenda, data, link, miniatura (URL do Instagram que expira) e contagem de comentarios.
   */
  async postsDaConta(conta: string, o: { limite?: number; cursor?: string | null } = {}): Promise<{ itens: PostZernio[]; proximo_cursor: string | null }> {
    const r = obj(await this.pedir({ metodo: 'GET', caminho: 'inbox/comments', query: { accountId: conta, limit: String(Math.min(Math.max(o.limite ?? 25, 1), 100)), cursor: o.cursor ?? null } }));
    const lista = Array.isArray(r.data) ? r.data : Array.isArray(r.posts) ? r.posts : [];
    const pag = obj(r.pagination);
    const itens = lista.map(obj).filter((p) => txt(p.id) && (!p.accountId || txt(p.accountId) === conta)).map((p): PostZernio => {
      const link = txt(p.permalink) || null;
      const n = (v: unknown) => (typeof v === 'number' && Number.isFinite(v) ? v : null);
      return {
        id: txt(p.id), legenda: txt(p.content ?? p.caption), publicado_em: txt(p.createdTime ?? p.timestamp) || null, link,
        miniatura_url: txt(p.picture ?? p.thumbnailUrl ?? p.thumbnail_url) || null, comentarios: n(p.commentCount), curtidas: n(p.likeCount),
        tipo: /\/reels?\//.test(link ?? '') ? 'reels' : 'post',
      };
    });
    return { itens, proximo_cursor: pag.hasMore === false ? null : txt(pag.nextCursor) || null };
  }

  /**
   * Ids das midias em carrossel publicadas entre duas datas (GET /analytics, campo mediaType). So enriquece o tipo:
   * qualquer falha devolve conjunto vazio e o post fica como post.
   */
  async carrosseis(conta: string, de: string, ate: string): Promise<Set<string>> {
    try {
      const r = obj(await this.pedir({ metodo: 'GET', caminho: 'analytics', query: { accountId: conta, platform: 'instagram', fromDate: de.slice(0, 10), toDate: ate.slice(0, 10), limit: '100' } }));
      const ids = new Set<string>();
      for (const p of (Array.isArray(r.posts) ? r.posts : []).map(obj)) {
        if (txt(p.mediaType).toLowerCase() !== 'carousel') continue;
        for (const pl of (Array.isArray(p.platforms) ? p.platforms : []).map(obj)) if (txt(pl.platformPostId)) ids.add(txt(pl.platformPostId));
      }
      return ids;
    } catch { return new Set(); }
  }

  /** Comentarios de um post (GET /inbox/comments/{postId}), mais novos primeiro quando o provedor ordena. */
  async comentarios(conta: string, postId: string) {
    const r = obj(await this.pedir({ metodo: 'GET', caminho: `inbox/comments/${encodeURIComponent(postId)}`, query: { accountId: conta, limit: '50' } }));
    const lista = Array.isArray(r.comments) ? r.comments : Array.isArray(r.data) ? r.data : [];
    return lista.map(obj).map((c) => {
      const de = obj(c.from ?? c.author);
      return { id: txt(c.id), texto: txt(c.message ?? c.text), autor_id: txt(de.id), autor_usuario: txt(de.username) || null, autor_nome: txt(de.name) || null, criado_em: txt(c.created_time ?? c.createdAt) || null };
    }).filter((c) => c.id && c.autor_id);
  }
}
