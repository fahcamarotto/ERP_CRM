/** JSON Schemas dos DTOs de entrada (validacao Fastify, OpenAPI em /docs e schema das tools MCP). */
export const uuid = { type: 'string', format: 'uuid' } as const;
const texto = (max: number) => ({ type: ['string', 'null'], maxLength: max });

export const canal = { type: 'string', enum: ['instagram', 'whatsapp'] } as const;

const no = {
  type: 'object', required: ['id', 'tipo', 'dados'],
  properties: {
    id: { type: 'string', pattern: '^[A-Za-z0-9:_-]{1,80}$' },
    tipo: { type: 'string', enum: ['gatilho', 'resposta_publica', 'mensagem', 'condicao', 'espera', 'acao', 'fim'] },
    posicao: { type: 'object', properties: { x: { type: 'number' }, y: { type: 'number' } } },
    dados: { type: 'object' },
  },
} as const;
const fio = {
  type: 'object', required: ['id', 'origem', 'porta', 'destino'],
  properties: { id: { type: 'string', maxLength: 80 }, origem: { type: 'string', maxLength: 80 }, porta: { type: 'string', maxLength: 40 }, destino: { type: 'string', maxLength: 80 } },
} as const;
export const grafo = {
  type: 'object', required: ['versao', 'entrada', 'nos', 'fios'],
  description: 'Grafo do editor: nos (gatilho, resposta_publica, mensagem, condicao, espera, acao, fim) e fios entre portas (saida, botao:N, sim, nao).',
  properties: {
    versao: { type: 'integer', enum: [1] }, entrada: { type: 'string', maxLength: 80 },
    nos: { type: 'array', maxItems: 100, items: no }, fios: { type: 'array', maxItems: 200, items: fio },
    viewport: { type: 'object', properties: { x: { type: 'number' }, y: { type: 'number' }, zoom: { type: 'number' } } },
  },
} as const;

export const gatilho = {
  type: 'object', required: ['tipo'],
  properties: {
    tipo: { type: 'string', enum: ['comentario_post', 'mensagem_palavra', 'botao_clicado', 'broadcast'] },
    post_id: texto(200),
    modo_posts: { type: 'string', enum: ['geral', 'especificos'], description: 'Instagram: geral = todos os posts da conta (inclusive futuros); especificos = so post_ids' },
    post_ids: { type: 'array', maxItems: 50, items: { type: 'string', pattern: '^[A-Za-z0-9_-]{1,80}$' } },
    posts: { type: 'array', maxItems: 50, items: { type: 'object', properties: { id: { type: 'string', maxLength: 80 }, legenda: texto(200), tipo: texto(20), publicado_em: texto(40) } } },
    canal_id: { type: ['string', 'null'], format: 'uuid' }, conta_id: texto(128), conta_usuario: texto(120),
    palavras: { type: 'array', maxItems: 20, items: { type: 'string', maxLength: 60 } },
    correspondencia: { type: 'string', enum: ['qualquer', 'contem', 'exata', 'palavra'] }, botao: texto(20), uma_vez_por_contato: { type: 'boolean' },
  },
} as const;

export const propsCriarFluxo = { nome: { type: 'string', minLength: 2, maxLength: 120 }, canal, gatilho, grafo } as const;
export const filtroFluxos = {
  canal, estado: { type: 'string', enum: ['rascunho', 'ativa', 'pausada'] }, busca: { type: 'string', maxLength: 120 },
  limite: { type: 'integer', minimum: 1, maximum: 200, default: 50 }, cursor: { type: 'string', maxLength: 200 },
} as const;

const botaoTemplate = {
  type: 'object', required: ['tipo', 'texto'],
  properties: { tipo: { type: 'string', enum: ['resposta', 'url', 'telefone'] }, texto: { type: 'string', maxLength: 25 }, url: texto(2000), telefone: texto(20) },
} as const;
export const propsTemplate = {
  nome: { type: 'string', minLength: 1, maxLength: 512, description: 'Minusculas, numeros e _ (regra da Meta)' },
  idioma: { type: 'string', maxLength: 5, default: 'pt_BR' },
  categoria: { type: 'string', enum: ['MARKETING', 'UTILITY', 'AUTHENTICATION'] },
  cabecalho: { type: ['object', 'null'], properties: { tipo: { type: 'string', enum: ['texto'] }, texto: { type: 'string', maxLength: 60 } } },
  corpo: { type: 'string', minLength: 1, maxLength: 1024, description: 'Variaveis {{1}}, {{2}}...' },
  exemplos: { type: 'array', maxItems: 20, items: { type: 'string', maxLength: 200 }, description: 'Um exemplo por variavel do corpo' },
  rodape: texto(60),
  botoes: { type: 'array', maxItems: 10, items: botaoTemplate },
} as const;

export const segmento = {
  type: 'object',
  properties: { tag_ids: { type: 'array', maxItems: 50, items: uuid }, setor_ids: { type: 'array', maxItems: 50, items: uuid }, somente_clientes: { type: 'boolean' } },
} as const;
export const propsBroadcast = {
  nome: { type: 'string', minLength: 2, maxLength: 120 }, template_id: uuid,
  parametros: { type: 'array', maxItems: 20, items: { type: 'string', maxLength: 200 } }, segmento,
  agendado_para: { type: ['string', 'null'], format: 'date-time' }, ritmo_por_minuto: { type: 'integer', minimum: 1, maximum: 600 },
  fluxo_id: { type: ['string', 'null'], format: 'uuid', description: 'Automacao de WhatsApp com gatilho broadcast, iniciada no clique de um botao do template' },
} as const;

export const filtroPostsInstagram = {
  canal_id: { type: 'string', format: 'uuid', description: 'Canal Instagram (integracoes_canais.id); vazio usa o unico canal ativo' },
  busca: { type: 'string', maxLength: 120, description: 'Trecho da legenda' },
  limite: { type: 'integer', minimum: 1, maximum: 50, default: 24 },
  cursor: { type: 'string', maxLength: 300 },
} as const;
