/**
 * Repositorios em memoria das portas do Cadastros e porta Efeitos que grava o que foi publicado.
 * Os casos de uso rodam aqui sem banco, sem Fastify e sem o SDK (P3).
 */
import type { ContextoCaso, Efeitos } from '../api/compartilhado/efeitos.ts';
import { Classificacao, type ClassificacaoDados, type TipoClassificacao } from '../api/classificacao/model/classificacao.ts';
import type { ContarUsoClassificacao, GravarClassificacao, ObterClassificacao } from '../api/classificacao/model/portas.ts';
import type { FilaJobs, ImportacaoDados, PortaImportacoes } from '../api/importacao/importar-parceiros.ts';
import type { ContaBancaria, ContaBancariaDados } from '../api/parceiro/model/conta-bancaria.ts';
import type { Endereco, EnderecoDados } from '../api/parceiro/model/endereco.ts';
import { Parceiro, type ParceiroDados } from '../api/parceiro/model/parceiro.ts';
import type { ConsultarClassificacoes, GravarContasBancarias, GravarEnderecos, RepositorioParceiros } from '../api/parceiro/model/portas.ts';
import type { ConsultarReferenciasProjeto, GravarProjeto, ObterProjeto } from '../api/projeto/model/portas.ts';
import { Projeto, type ProjetoDados } from '../api/projeto/model/projeto.ts';

export class EfeitosMemoria implements Efeitos {
  auditoria: { acao: string; entidade: string; id: string | null }[] = [];
  eventos: { evento: string; dados: Record<string, unknown> }[] = [];
  historicos: { entidade: string; id: string; antes: unknown; depois: unknown }[] = [];
  notas: { entidade: string; id: string; corpo: string }[] = [];
  async auditar(acao: string, entidade: string, id: string | null) { this.auditoria.push({ acao, entidade, id }); }
  async publicar(evento: string, dados: Record<string, unknown>) { this.eventos.push({ evento, dados }); }
  async historico(entidade: string, id: string, antes: unknown, depois: unknown) { this.historicos.push({ entidade, id, antes, depois }); }
  async nota(entidade: string, id: string, corpo: string) { this.notas.push({ entidade, id, corpo }); }
}

export function contexto(): ContextoCaso & { efeitos: EfeitosMemoria } {
  return { ator: { tipo: 'usuario', id: '00000000-0000-4000-8000-000000000001' }, efeitos: new EfeitosMemoria() };
}

export class ParceirosMemoria implements RepositorioParceiros, GravarEnderecos, GravarContasBancarias, ConsultarClassificacoes {
  linhas = new Map<string, ParceiroDados & { deleted: boolean }>();
  enderecos = new Map<string, EnderecoDados & { deleted: boolean }>();
  contas = new Map<string, ContaBancariaDados & { deleted: boolean }>();
  projetosDoParceiro = new Map<string, string>();
  classificacoes = new Map<string, TipoClassificacao>();

  private vivo(fn: (d: ParceiroDados) => boolean): Parceiro | null {
    const l = [...this.linhas.values()].find((x) => !x.deleted && fn(x));
    return l ? Parceiro.deDados(l) : null;
  }
  async obterPorId(id: string) { return this.vivo((d) => d.id === id); }
  async buscarPorDocumento(doc: string) { return this.vivo((d) => d.documento === doc); }
  async buscarPorContato(email: string | null, tel: string | null) {
    return this.vivo((d) => (!!email && d.email === email) || (!!tel && d.telefone === tel));
  }
  async inserir(p: Parceiro) {
    const d = p.paraDados();
    if (d.documento && [...this.linhas.values()].some((x) => !x.deleted && x.documento === d.documento)) throw Object.assign(new Error('duplicado'), { code: '23505' });
    this.linhas.set(d.id, { ...d, deleted: false });
  }
  async atualizar(p: Parceiro) {
    const d = p.paraDados();
    const atual = this.linhas.get(d.id);
    if (atual && !atual.deleted) this.linhas.set(d.id, { ...d, deleted: false });
  }
  async excluir(id: string) { const l = this.linhas.get(id); if (l) l.deleted = true; }
  async reapontar(de: string, para: string) {
    let n = 0;
    for (const l of this.linhas.values()) if (!l.deleted && l.parent_id === de && l.id !== para) { l.parent_id = para; n++; }
    for (const e of this.enderecos.values()) if (!e.deleted && e.parceiro_id === de) { e.parceiro_id = para; n++; }
    for (const c of this.contas.values()) if (!c.deleted && c.parceiro_id === de) { c.parceiro_id = para; c.principal = false; n++; }
    for (const [pj, dono] of this.projetosDoParceiro) if (dono === de) { this.projetosDoParceiro.set(pj, para); n++; }
    return n;
  }
  async existentes(ids: string[], tipo: 'tag' | 'setor') { return ids.filter((i) => this.classificacoes.get(i) === tipo); }
  async inserirEndereco(e: Endereco) { this.enderecos.set(e.dados.id, { ...e.dados, deleted: false }); }
  async removerEndereco(pid: string, id: string) {
    const e = this.enderecos.get(id);
    if (!e || e.deleted || e.parceiro_id !== pid) return false;
    e.deleted = true;
    return true;
  }
  async inserirConta(c: ContaBancaria) {
    if (c.dados.principal) for (const x of this.contas.values()) if (x.parceiro_id === c.dados.parceiro_id) x.principal = false;
    this.contas.set(c.dados.id, { ...c.dados, deleted: false });
  }
  async removerConta(pid: string, id: string) {
    const c = this.contas.get(id);
    if (!c || c.deleted || c.parceiro_id !== pid) return false;
    c.deleted = true;
    return true;
  }
}

export class ProjetosMemoria implements ObterProjeto, GravarProjeto, ConsultarReferenciasProjeto {
  linhas = new Map<string, ProjetoDados>();
  parceirosAtivos = new Set<string>();
  usuarios = new Set<string>(['00000000-0000-4000-8000-000000000001']);
  async obterPorId(id: string) { const d = this.linhas.get(id); return d ? Projeto.reidratar(d) : null; }
  async inserir(p: Projeto) { this.linhas.set(p.id, p.paraDados()); }
  async atualizar(p: Projeto) { this.linhas.set(p.id, p.paraDados()); }
  async parceiroAtivo(id: string) { return this.parceirosAtivos.has(id); }
  async usuariosExistentes(ids: string[]) { return ids.filter((i) => this.usuarios.has(i)); }
}

export class ClassificacoesMemoria implements ObterClassificacao, GravarClassificacao, ContarUsoClassificacao {
  linhas = new Map<string, ClassificacaoDados & { deleted: boolean }>();
  uso = new Map<string, number>();
  async obterPorId(id: string) { const d = this.linhas.get(id); return d && !d.deleted ? Classificacao.reidratar(d) : null; }
  async buscarPorNome(tipo: TipoClassificacao, nome: string) {
    const d = [...this.linhas.values()].find((x) => !x.deleted && x.tipo === tipo && x.nome.toLowerCase() === nome.toLowerCase());
    return d ? Classificacao.reidratar(d) : null;
  }
  async inserir(c: Classificacao) { this.linhas.set(c.id, { ...c.paraDados(), deleted: false }); }
  async atualizar(c: Classificacao) { this.linhas.set(c.id, { ...c.paraDados(), deleted: false }); }
  async excluir(id: string) { const d = this.linhas.get(id); if (d) d.deleted = true; }
  async emUso(id: string) { return this.uso.get(id) ?? 0; }
}

export class ImportacoesMemoria implements PortaImportacoes, FilaJobs {
  linhas = new Map<string, ImportacaoDados & { total: number; criados: number; atualizados: number; erros: unknown[]; job_id?: string }>();
  jobs: { id: string; tipo: string; payload: Record<string, unknown> }[] = [];
  async inserir(d: { id: string; nome_arquivo: string; conteudo: string }) { this.linhas.set(d.id, { ...d, estado: 'pendente', total: 0, criados: 0, atualizados: 0, erros: [] }); }
  async obter(id: string) { return this.linhas.get(id) ?? null; }
  async progresso(id: string, p: Parameters<PortaImportacoes['progresso']>[1]) { const l = this.linhas.get(id); if (l) Object.assign(l, p); }
  async enfileirar(tipo: string, payload: Record<string, unknown>) { const id = `job-${this.jobs.length + 1}`; this.jobs.push({ id, tipo, payload }); return id; }
}

/** Identidades por canal em memoria (indice unico canal + id_externo). */
export class IdentidadesMemoria {
  linhas = new Map<string, { parceiro_id: string; usuario: string | null; nome: string | null; foto_url: string | null }>();
  travas: string[] = [];
  async travar(chave: string) { this.travas.push(chave); }
  async parceiroDaIdentidade(canal: string, id: string) { return this.linhas.get(`${canal}:${id}`)?.parceiro_id ?? null; }
  async gravarIdentidade(i: { parceiro_id: string; canal: string; id_externo: string; usuario: string | null; nome: string | null; foto_url: string | null }) {
    const k = `${i.canal}:${i.id_externo}`;
    const a = this.linhas.get(k);
    this.linhas.set(k, a ? { parceiro_id: a.parceiro_id, usuario: i.usuario ?? a.usuario, nome: i.nome ?? a.nome, foto_url: i.foto_url ?? a.foto_url } : { parceiro_id: i.parceiro_id, usuario: i.usuario, nome: i.nome, foto_url: i.foto_url });
  }
}
