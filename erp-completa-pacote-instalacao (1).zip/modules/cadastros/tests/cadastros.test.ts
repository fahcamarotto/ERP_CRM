/**
 * P3 do modulo Cadastros: cada caso de uso com repositorio em memoria.
 * Rodar: node --import tsx --test modules/cadastros/tests/*.test.ts
 */
import assert from 'node:assert/strict';
import { describe, it } from 'node:test';
import { Classificacao } from '../api/classificacao/model/classificacao.ts';
import { CriarClassificacao, ExcluirClassificacao } from '../api/classificacao/use-case/classificacoes.ts';
import { lerCsv } from '../api/importacao/csv.ts';
import { ProcessarImportacao, SolicitarImportacao, TIPO_JOB } from '../api/importacao/importar-parceiros.ts';
import { Documento } from '../api/parceiro/model/documento.ts';
import { Parceiro } from '../api/parceiro/model/parceiro.ts';
import { Telefone } from '../api/parceiro/model/telefone.ts';
import { ArquivarParceiro } from '../api/parceiro/use-case/arquivar-parceiro.ts';
import { CriarParceiro } from '../api/parceiro/use-case/criar-parceiro.ts';
import { EditarParceiro } from '../api/parceiro/use-case/editar-parceiro.ts';
import { AdicionarContaBancaria, AdicionarEndereco, RemoverEndereco } from '../api/parceiro/use-case/enderecos-contas.ts';
import { MesclarDuplicados } from '../api/parceiro/use-case/mesclar-duplicados.ts';
import { CadastrarContatoDeCanal } from '../api/parceiro/use-case/cadastrar-contato-canal.ts';
import { AplicarClienteDeAutomacao } from '../api/parceiro/use-case/cliente-de-automacao.ts';
import { ReceberLead } from '../api/parceiro/use-case/receber-lead.ts';
import { Projeto } from '../api/projeto/model/projeto.ts';
import { CriarProjeto, MudarStatusProjeto } from '../api/projeto/use-case/projetos.ts';
import { ClassificacoesMemoria, contexto, IdentidadesMemoria, ImportacoesMemoria, ParceirosMemoria, ProjetosMemoria } from './memoria.ts';

const CPF = '529.982.247-25';
const CNPJ = '11.222.333/0001-81';

function montar() {
  const repo = new ParceirosMemoria();
  const deps = { repo, classificacoes: repo };
  return { repo, criar: new CriarParceiro(deps), editar: new EditarParceiro(deps) };
}

describe('objetos de valor', () => {
  it('Documento valida CPF e CNPJ pelo digito e normaliza sem mascara', () => {
    const r = Documento.tryCreate(CPF);
    assert.ok(r.ok);
    assert.equal(r.valor.numero, '52998224725');
    assert.equal(r.valor.tipo, 'cpf');
    assert.equal(Documento.create(CNPJ).formatado(), CNPJ);
    const ruim = Documento.tryCreate('111.111.111-11');
    assert.equal(ruim.ok, false);
    assert.throws(() => Documento.create('123'));
  });

  it('Telefone vira E.164 e recusa lixo', () => {
    assert.equal(Telefone.create('(11) 98765-4321').e164, '+5511987654321');
    assert.equal(Telefone.create('+1 415 555 2671').e164, '+14155552671');
    assert.equal(Telefone.tryCreate('abc').ok, false);
  });
});

describe('entidade Parceiro', () => {
  it('tryCreate acumula erros como valor (sem excecao)', () => {
    const r = Parceiro.tryCreate({ tipo: 'empresa', nome: 'X', documento: CPF, email: 'sem-arroba', ranking_cliente: 9 });
    assert.equal(r.ok, false);
    if (!r.ok) {
      const codigos = r.erros.map((e) => e.codigo);
      assert.ok(codigos.includes('email_invalido'));
    }
    const r2 = Parceiro.tryCreate({ tipo: 'empresa', nome: 'X', documento: CPF, ranking_cliente: 9 });
    assert.equal(r2.ok, false);
    if (!r2.ok) assert.deepEqual(r2.erros.map((e) => e.codigo).sort(), ['documento_invalido', 'nome_invalido', 'ranking_invalido']);
  });

  it('editar devolve clone e nao muta o original', () => {
    const p = Parceiro.create({ tipo: 'pessoa', nome: 'Ana Souza' });
    const r = p.editar({ nome: 'Ana B. Souza' });
    assert.ok(r.ok);
    assert.equal(p.props.nome, 'Ana Souza');
    assert.equal(r.valor.props.nome, 'Ana B. Souza');
  });
});

describe('CriarParceiro', () => {
  it('cria, audita e publica cliente.criado', async () => {
    const { repo, criar } = montar();
    const ctx = contexto();
    const r = await criar.execute(ctx, { tipo: 'pessoa', nome: 'Ana Souza', documento: CPF, email: 'ANA@x.com', telefone: '11987654321', e_cliente: true });
    assert.ok(r.ok);
    const salvo = await repo.obterPorId(r.valor.id);
    assert.equal(salvo?.props.email?.valor, 'ana@x.com');
    assert.deepEqual(ctx.efeitos.eventos.map((e) => e.evento), ['cliente.criado']);
    assert.equal(ctx.efeitos.auditoria[0]?.acao, 'parceiro.criar');
  });

  it('recusa documento repetido com conflito', async () => {
    const { criar } = montar();
    await criar.execute(contexto(), { tipo: 'pessoa', nome: 'Ana', documento: CPF });
    const r = await criar.execute(contexto(), { tipo: 'pessoa', nome: 'Outra Ana', documento: '52998224725' });
    assert.equal(r.ok, false);
    if (!r.ok) assert.equal(r.erros[0]?.codigo, 'conflito');
  });

  it('contato so liga em empresa ativa e tag precisa existir', async () => {
    const { repo, criar } = montar();
    const pessoa = await criar.execute(contexto(), { tipo: 'pessoa', nome: 'Bruno' });
    assert.ok(pessoa.ok);
    const r = await criar.execute(contexto(), { tipo: 'pessoa', nome: 'Carla', parent_id: pessoa.valor.id, tag_ids: ['00000000-0000-4000-8000-0000000000aa'] });
    assert.equal(r.ok, false);
    if (!r.ok) assert.deepEqual(r.erros.map((e) => e.codigo).sort(), ['parent_invalido', 'tag_invalida']);
    const emp = await criar.execute(contexto(), { tipo: 'empresa', nome: 'Aurora Ltda', documento: CNPJ });
    assert.ok(emp.ok);
    repo.classificacoes.set('00000000-0000-4000-8000-0000000000aa', 'tag');
    const ok = await criar.execute(contexto(), { tipo: 'pessoa', nome: 'Carla', parent_id: emp.valor.id, tag_ids: ['00000000-0000-4000-8000-0000000000aa'] });
    assert.ok(ok.ok);
  });
});

describe('EditarParceiro e ArquivarParceiro', () => {
  it('edita com historico e evento listando os campos alterados', async () => {
    const { criar, editar } = montar();
    const c = await criar.execute(contexto(), { tipo: 'pessoa', nome: 'Diego' });
    assert.ok(c.ok);
    const ctx = contexto();
    const r = await editar.execute(ctx, { id: c.valor.id, cargo: 'Gerente', e_fornecedor: true });
    assert.ok(r.ok);
    assert.equal(ctx.efeitos.historicos.length, 1);
    const ev = ctx.efeitos.eventos[0]!;
    assert.equal(ev.evento, 'cliente.atualizado');
    assert.deepEqual((ev.dados.campos as string[]).sort(), ['cargo', 'e_fornecedor']);
  });

  it('nao encontrado vira erro nao_encontrado', async () => {
    const { editar } = montar();
    const r = await editar.execute(contexto(), { id: '00000000-0000-4000-8000-0000000000ff', nome: 'X' });
    assert.equal(r.ok, false);
    if (!r.ok) assert.equal(r.erros[0]?.codigo, 'nao_encontrado');
  });

  it('arquiva uma vez, segunda vez e transicao invalida, editar arquivado falha', async () => {
    const { repo, criar, editar } = montar();
    const c = await criar.execute(contexto(), { tipo: 'pessoa', nome: 'Elisa' });
    assert.ok(c.ok);
    const arq = new ArquivarParceiro({ repo });
    assert.ok((await arq.execute(contexto(), { id: c.valor.id })).ok);
    const de_novo = await arq.execute(contexto(), { id: c.valor.id });
    assert.equal(de_novo.ok, false);
    const ed = await editar.execute(contexto(), { id: c.valor.id, nome: 'Elisa F.' });
    assert.equal(ed.ok, false);
    if (!ed.ok) assert.equal(ed.erros[0]?.codigo, 'transicao_invalida');
    assert.ok((await arq.execute(contexto(), { id: c.valor.id, reativar: true })).ok);
  });
});

describe('MesclarDuplicados', () => {
  it('mantido absorve dados e vinculos, duplicado sai e evento lista os removidos', async () => {
    const { repo, criar } = montar();
    const a = await criar.execute(contexto(), { tipo: 'pessoa', nome: 'Fabio Lima', email: 'fabio@x.com' });
    const b = await criar.execute(contexto(), { tipo: 'pessoa', nome: 'Fabio L.', documento: CPF, telefone: '11999990000', ranking_cliente: 4 });
    assert.ok(a.ok && b.ok);
    const deps = { repo, enderecos: repo, contas: repo };
    await new AdicionarEndereco(deps).execute(contexto(), { parceiro_id: b.valor.id, logradouro: 'Rua A', cidade: 'Sao Paulo', uf: 'sp', cep: '01310-100' });
    const ctx = contexto();
    const r = await new MesclarDuplicados({ repo }).execute(ctx, { manter_id: a.valor.id, duplicados_ids: [b.valor.id] });
    assert.ok(r.ok);
    assert.equal(r.valor.movidos, 1);
    const mantido = await repo.obterPorId(a.valor.id);
    assert.equal(mantido?.props.documento?.numero, '52998224725');
    assert.equal(mantido?.props.telefone?.e164, '+5511999990000');
    assert.equal(mantido?.props.rankingCliente, 4);
    assert.equal(await repo.obterPorId(b.valor.id), null);
    assert.ok(ctx.efeitos.eventos.some((e) => e.evento === 'parceiro.mesclado'));
  });

  it('recusa mesclar pessoa com empresa', async () => {
    const { repo, criar } = montar();
    const a = await criar.execute(contexto(), { tipo: 'pessoa', nome: 'Gabi' });
    const b = await criar.execute(contexto(), { tipo: 'empresa', nome: 'Gabi Ltda' });
    assert.ok(a.ok && b.ok);
    const r = await new MesclarDuplicados({ repo }).execute(contexto(), { manter_id: a.valor.id, duplicados_ids: [b.valor.id] });
    assert.equal(r.ok, false);
  });
});

describe('ReceberLead (webhook de landing page)', () => {
  it('cria parceiro novo e publica lead.recebido; segundo envio atualiza o mesmo', async () => {
    const { repo } = montar();
    const caso = new ReceberLead({ repo });
    const ctx = contexto();
    const r1 = await caso.execute(ctx, { nome: 'Helena', email: 'helena@x.com', mensagem: 'Quero orcamento', utm_source: 'google' });
    assert.ok(r1.ok && r1.valor.novo);
    assert.deepEqual(ctx.efeitos.eventos.map((e) => e.evento), ['cliente.criado', 'lead.recebido']);
    assert.equal(ctx.efeitos.notas.length, 1);
    const r2 = await caso.execute(contexto(), { email: 'HELENA@x.com', telefone: '21988887777' });
    assert.ok(r2.ok);
    assert.equal(r2.valor.novo, false);
    assert.equal(r2.valor.id, r1.valor.id);
    assert.equal((await repo.obterPorId(r1.valor.id))?.props.telefone?.e164, '+5521988887777');
  });

  it('lead de fonte (landing page): origem = nome da fonte, destino e tags seguem no lead.recebido, sem duplicar por e-mail', async () => {
    const { repo } = montar();
    const caso = new ReceberLead({ repo });
    const fonteA = { id: 'fa', nome: 'LP Imersao IA', funil_id: 'funil-a', etapa_id: 'etapa-a', tags: ['imersao'], responsavel_id: null };
    const fonteB = { id: 'fb', nome: 'LP Mentoria', funil_id: 'funil-b', etapa_id: null, tags: [], responsavel_id: 'u-1' };
    const ctx = contexto();
    const r1 = await caso.execute(ctx, { nome: 'Rui', email: 'rui@x.com', origem: 'ignorada', fonte: fonteA });
    const r2 = await caso.execute(ctx, { nome: 'Rui', email: 'RUI@x.com', fonte: fonteB });
    assert.ok(r1.ok && r2.ok);
    assert.equal(r2.valor.id, r1.valor.id);
    assert.equal(r2.valor.novo, false);
    assert.equal((await repo.obterPorId(r1.valor.id))?.props.origem, 'LP Imersao IA');
    const leads = ctx.efeitos.eventos.filter((e) => e.evento === 'lead.recebido').map((e) => e.dados);
    assert.deepEqual(leads.map((d) => [d.origem, d.fonte_id, d.funil_id, d.etapa_id, d.canal]), [['LP Imersao IA', 'fa', 'funil-a', 'etapa-a', 'site'], ['LP Mentoria', 'fb', 'funil-b', null, 'site']]);
    assert.deepEqual(leads[0]!.tags, ['imersao']);
    assert.equal(leads[1]!.responsavel_id, 'u-1');
  });

  it('lead sem e-mail nem telefone valido e recusado', async () => {
    const r = await new ReceberLead({ repo: new ParceirosMemoria() }).execute(contexto(), { nome: 'Sem contato', email: 'x' });
    assert.equal(r.ok, false);
  });
});

describe('Enderecos e contas bancarias', () => {
  it('valida e remove so do proprio parceiro; conta principal desmarca a anterior', async () => {
    const { repo, criar } = montar();
    const p = await criar.execute(contexto(), { tipo: 'empresa', nome: 'Iris Ltda' });
    assert.ok(p.ok);
    const deps = { repo, enderecos: repo, contas: repo };
    const ruim = await new AdicionarEndereco(deps).execute(contexto(), { parceiro_id: p.valor.id, logradouro: '', cidade: 'X', cep: '123' });
    assert.equal(ruim.ok, false);
    const e = await new AdicionarEndereco(deps).execute(contexto(), { parceiro_id: p.valor.id, logradouro: 'Rua B', cidade: 'Recife' });
    assert.ok(e.ok);
    assert.equal((await new RemoverEndereco(deps).execute(contexto(), { parceiro_id: 'outro', id: e.valor.id })).ok, false);
    assert.ok((await new RemoverEndereco(deps).execute(contexto(), { parceiro_id: p.valor.id, id: e.valor.id })).ok);
    const conta = new AdicionarContaBancaria(deps);
    const c1 = await conta.execute(contexto(), { parceiro_id: p.valor.id, banco_codigo: '1', agencia: '1234', conta: '5678-9', principal: true });
    const c2 = await conta.execute(contexto(), { parceiro_id: p.valor.id, banco_codigo: '341', agencia: '1', conta: '22', principal: true });
    assert.ok(c1.ok && c2.ok);
    assert.equal(repo.contas.get(c1.valor.id)?.banco_codigo, '001');
    assert.equal(repo.contas.get(c1.valor.id)?.principal, false);
    assert.equal(repo.contas.get(c2.valor.id)?.principal, true);
  });
});

describe('Projeto', () => {
  it('maquina de estados: planejado para em_andamento para concluido; concluido e final', () => {
    const p = Projeto.create({ nome: 'Portal' });
    assert.equal(p.mudarEstado('concluido').ok, false);
    const r = p.mudarEstado('em_andamento');
    assert.ok(r.ok);
    const fim = r.valor.mudarEstado('concluido');
    assert.ok(fim.ok);
    assert.equal(fim.valor.mudarEstado('em_andamento').ok, false);
    assert.equal(fim.valor.editar({ nome: 'Outro' }).ok, false);
  });

  it('CriarProjeto valida cliente e prazo; MudarStatus publica evento', async () => {
    const repo = new ProjetosMemoria();
    const criar = new CriarProjeto({ repo, refs: repo });
    const ruim = await criar.execute(contexto(), { nome: 'P', parceiro_id: '00000000-0000-4000-8000-0000000000bb', inicio: '2026-10-10', prazo: '2026-10-01' });
    assert.equal(ruim.ok, false);
    if (!ruim.ok) assert.deepEqual(ruim.erros.map((e) => e.codigo).sort(), ['nome_invalido', 'prazo_invalido']);
    repo.parceirosAtivos.add('00000000-0000-4000-8000-0000000000bb');
    const ctx = contexto();
    const ok = await criar.execute(ctx, { nome: 'Portal', parceiro_id: '00000000-0000-4000-8000-0000000000bb', orcamento: 1234.567, equipe_ids: ['00000000-0000-4000-8000-000000000001'] });
    assert.ok(ok.ok);
    assert.equal(repo.linhas.get(ok.valor.id)?.orcamento, 1234.57);
    assert.equal(ctx.efeitos.eventos[0]?.evento, 'projeto.criado');
    const ctx2 = contexto();
    assert.ok((await new MudarStatusProjeto({ repo }).execute(ctx2, { id: ok.valor.id, estado: 'em_andamento' })).ok);
    assert.deepEqual(ctx2.efeitos.eventos[0]?.dados, { id: ok.valor.id, de: 'planejado', para: 'em_andamento' });
  });
});

describe('Tags e setores', () => {
  it('nome unico por tipo, cor so por token e exclusao bloqueada em uso', async () => {
    const repo = new ClassificacoesMemoria();
    const criar = new CriarClassificacao({ repo });
    const t = await criar.execute(contexto(), { tipo: 'tag', nome: 'VIP', cor: 'dourado' });
    assert.ok(t.ok);
    const dup = await criar.execute(contexto(), { tipo: 'tag', nome: 'vip' });
    assert.equal(dup.ok, false);
    assert.equal(Classificacao.tryCreate({ tipo: 'tag', nome: 'X', cor: '#ff0000' as never }).ok, false);
    repo.uso.set(t.valor.id, 2);
    const ex = await new ExcluirClassificacao({ repo }).execute(contexto(), { id: t.valor.id });
    assert.equal(ex.ok, false);
    if (!ex.ok) assert.equal(ex.erros[0]?.codigo, 'conflito');
  });
});

describe('ImportarParceirosCSV', () => {
  it('le CSV com aspas e ponto e virgula', () => {
    const { cabecalho, linhas } = lerCsv('﻿nome;email\n"Silva; Joao";j@x.com\r\n"Ana ""A""";\n');
    assert.deepEqual(cabecalho, ['nome', 'email']);
    assert.deepEqual(linhas, [['Silva; Joao', 'j@x.com'], ['Ana "A"', '']]);
  });

  it('solicita (job na fila) e processa: cria, atualiza pelo documento e registra erro por linha', async () => {
    const { repo, criar, editar } = montar();
    await criar.execute(contexto(), { tipo: 'pessoa', nome: 'Ja Existe', documento: CPF });
    const imp = new ImportacoesMemoria();
    let n = 0;
    const solicitar = new SolicitarImportacao({ importacoes: imp, fila: imp, novoId: () => `imp-${++n}` });
    const csv = `nome,documento,email,telefone,e_fornecedor\nNova Pessoa,,nova@x.com,11911112222,nao\nJa Existe Atualizado,${CPF},,,sim\nX,,,,\n`;
    const s = await solicitar.execute(contexto(), { nome_arquivo: 'clientes.csv', conteudo: csv });
    assert.ok(s.ok);
    assert.equal(imp.jobs[0]?.tipo, TIPO_JOB);
    const ctx = contexto();
    const r = await new ProcessarImportacao({ importacoes: imp, repo, criar, editar, porLinha: (fn) => fn() }).execute(ctx, { importacao_id: s.valor.importacao_id });
    assert.ok(r.ok);
    assert.deepEqual(r.valor, { criados: 1, atualizados: 1, erros: 1 });
    assert.equal(imp.linhas.get(s.valor.importacao_id)?.estado, 'concluida');
    assert.equal((await repo.buscarPorDocumento('52998224725'))?.props.eFornecedor, true);
    assert.ok(ctx.efeitos.eventos.some((e) => e.evento === 'importacao.concluida'));
  });

  it('recusa CSV sem coluna nome', async () => {
    const imp = new ImportacoesMemoria();
    const r = await new SolicitarImportacao({ importacoes: imp, fila: imp, novoId: () => 'x' }).execute(contexto(), { nome_arquivo: 'a.csv', conteudo: 'email\na@b.com\n' });
    assert.equal(r.ok, false);
  });
});

describe('CadastrarContatoDeCanal (contato.desconhecido de WhatsApp e Instagram)', () => {
  it('cria cliente com nome, telefone, @usuario e foto; idempotente por id da plataforma e por telefone', async () => {
    const repo = new ParceirosMemoria();
    const ids = new IdentidadesMemoria();
    const caso = new CadastrarContatoDeCanal({ repo, identidades: ids });
    const ctx = contexto();
    const ig = await caso.execute(ctx, { conversa_id: 'conv-ig', canal: 'instagram', contato: '17841400000009', nome: null, usuario: '@ana.loja', foto_url: 'https://cdn.x/p.jpg', mensagem: 'Oi' });
    assert.ok(ig.ok && ig.valor.novo);
    const p = (await repo.obterPorId(ig.valor.parceiro_id))!.paraDados();
    assert.deepEqual([p.nome, p.e_cliente, p.origem, p.telefone], ['@ana.loja', true, 'instagram', null]);
    assert.match(p.observacoes ?? '', /@ana\.loja/);
    assert.deepEqual(ids.linhas.get('instagram:17841400000009'), { parceiro_id: ig.valor.parceiro_id, usuario: 'ana.loja', nome: null, foto_url: 'https://cdn.x/p.jpg' });
    assert.deepEqual(ctx.efeitos.eventos.map((e) => e.evento), ['cliente.criado', 'contato.cadastrado']);
    assert.deepEqual(ctx.efeitos.eventos[1]!.dados, { conversa_id: 'conv-ig', parceiro_id: ig.valor.parceiro_id, canal: 'instagram', contato: '17841400000009', novo: true });
    // Mesmo contato de novo (reimportacao): nao duplica, so devolve o cadastro.
    const ig2 = await caso.execute(contexto(), { conversa_id: 'conv-ig', canal: 'instagram', contato: '17841400000009', nome: 'Ana Souza' });
    assert.ok(ig2.ok && !ig2.valor.novo && ig2.valor.parceiro_id === ig.valor.parceiro_id);
    // WhatsApp: telefone E.164; cliente existente com o mesmo telefone e reaproveitado.
    const wa = await caso.execute(contexto(), { conversa_id: 'conv-wa', canal: 'whatsapp', contato: '+5511987650099', nome: 'Bruno', telefone: '+5511987650099' });
    assert.ok(wa.ok && wa.valor.novo);
    assert.equal((await repo.obterPorId(wa.valor.parceiro_id))!.paraDados().telefone, '+5511987650099');
    ids.linhas.clear();
    const wa2 = await caso.execute(contexto(), { conversa_id: 'conv-wa2', canal: 'whatsapp', contato: '5511987650099', nome: 'Bruno' });
    assert.ok(wa2.ok && !wa2.valor.novo && wa2.valor.parceiro_id === wa.valor.parceiro_id);
    const ruim = await caso.execute(contexto(), { canal: 'telegram', contato: 'x' });
    assert.equal(!ruim.ok && ruim.erros[0]!.codigo, 'canal_invalido');
    assert.ok(ids.travas.length >= 4);
  });
});

describe('AplicarClienteDeAutomacao (automacao.cliente_solicitado)', () => {
  it('cria cliente do contato, cria e aplica tags por nome; repetir nao duplica; so_tags sem cliente ignora', async () => {
    const repo = new ParceirosMemoria();
    const classes = new ClassificacoesMemoria();
    const cadastrar = new CadastrarContatoDeCanal({ repo, identidades: new IdentidadesMemoria() });
    const caso = new AplicarClienteDeAutomacao({ cadastrar, repo, classificacoes: classes });
    const r = await caso.execute(contexto(), { canal: 'instagram', contato: '17841400000077', nome: null, usuario: 'joao.k', tags: ['lead-quente', 'Imersao'], so_tags: false });
    assert.ok(r.ok && r.valor.novo && r.valor.tags === 2);
    const p = (await repo.obterPorId(r.valor.parceiro_id!))!;
    assert.equal(p.props.tagIds.length, 2);
    assert.equal([...classes.linhas.values()].filter((x) => x.tipo === 'tag').length, 2);
    const r2 = await caso.execute(contexto(), { canal: 'instagram', contato: '17841400000077', parceiro_id: r.valor.parceiro_id, tags: ['LEAD-QUENTE', 'novo'], so_tags: true });
    assert.ok(r2.ok && r2.valor.tags === 1 && r2.valor.parceiro_id === r.valor.parceiro_id);
    assert.equal((await repo.obterPorId(r.valor.parceiro_id!))!.props.tagIds.length, 3);
    assert.equal([...classes.linhas.values()].length, 3);
    const r3 = await caso.execute(contexto(), { canal: 'instagram', contato: '17841400000077', parceiro_id: r.valor.parceiro_id, tags: ['novo'], so_tags: true });
    assert.ok(r3.ok && r3.valor.tags === 0);
    const sem = await caso.execute(contexto(), { canal: 'whatsapp', contato: '+5511900001111', tags: ['x'], so_tags: true });
    assert.ok(sem.ok && sem.valor.parceiro_id === null);
  });
});
