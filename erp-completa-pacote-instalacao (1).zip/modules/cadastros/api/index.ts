/**
 * Plugin do modulo Cadastros (M1), registrado sozinho com prefixo /api/v1/cadastros.
 * Importar ./tools.ts registra as @tool (MCP e REST) no carregamento.
 */
import type { FastifyPluginAsync } from '@erp/api/sdk';
import './tools.ts';
import { rotasClassificacao } from './classificacao/routes.ts';
import { rotasImportacao } from './importacao/routes.ts';
import { rotasParceiro } from './parceiro/routes.ts';
import { rotasProjeto } from './projeto/routes.ts';

const plugin: FastifyPluginAsync = async (app) => {
  rotasParceiro(app);
  rotasProjeto(app);
  rotasClassificacao(app);
  rotasImportacao(app);
};

export default plugin;
