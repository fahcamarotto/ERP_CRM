/**
 * Composicao do modulo: liga casos de uso aos adaptadores Postgres para um cliente de transacao.
 * Usada pelas rotas, pelas tools, pelo worker e pelo seed. Nao importa Fastify nem o pool do servidor.
 */
import { randomUUID } from 'node:crypto';
import type pg from 'pg';
import { ClassificacaoRepoPg } from './classificacao/adapter/classificacao-repo-pg.ts';
import { CriarClassificacao, EditarClassificacao, ExcluirClassificacao } from './classificacao/use-case/classificacoes.ts';
import { FilaOutboxPg, ImportacaoRepoPg, porLinhaPg } from './importacao/importacao-repo-pg.ts';
import { ProcessarImportacao, SolicitarImportacao } from './importacao/importar-parceiros.ts';
import { IdentidadeRepoPg } from './parceiro/adapter/identidade-repo-pg.ts';
import { ParceiroRepoPg } from './parceiro/adapter/parceiro-repo-pg.ts';
import { CadastrarContatoDeCanal } from './parceiro/use-case/cadastrar-contato-canal.ts';
import { AplicarClienteDeAutomacao } from './parceiro/use-case/cliente-de-automacao.ts';
import { ArquivarParceiro } from './parceiro/use-case/arquivar-parceiro.ts';
import { CriarParceiro } from './parceiro/use-case/criar-parceiro.ts';
import { EditarParceiro } from './parceiro/use-case/editar-parceiro.ts';
import { AdicionarContaBancaria, AdicionarEndereco, RemoverContaBancaria, RemoverEndereco } from './parceiro/use-case/enderecos-contas.ts';
import { ExcluirParceiro } from './parceiro/use-case/excluir-parceiro.ts';
import { MesclarDuplicados } from './parceiro/use-case/mesclar-duplicados.ts';
import { ReceberLead } from './parceiro/use-case/receber-lead.ts';
import { ProjetoRepoPg } from './projeto/adapter/projeto-repo-pg.ts';
import { CriarProjeto, EditarProjeto, MudarStatusProjeto } from './projeto/use-case/projetos.ts';

export function casosDeUso(c: pg.PoolClient) {
  const parceiros = new ParceiroRepoPg(c);
  const projetos = new ProjetoRepoPg(c);
  const classificacoes = new ClassificacaoRepoPg(c);
  const importacoes = new ImportacaoRepoPg(c);
  const depsParceiro = { repo: parceiros, classificacoes: parceiros };
  const depsVinculos = { repo: parceiros, enderecos: parceiros, contas: parceiros };
  const criarParceiro = new CriarParceiro(depsParceiro);
  const editarParceiro = new EditarParceiro(depsParceiro);
  const cadastrarContatoDeCanal = new CadastrarContatoDeCanal({ repo: parceiros, identidades: new IdentidadeRepoPg(c) });
  return {
    criarParceiro,
    editarParceiro,
    arquivarParceiro: new ArquivarParceiro({ repo: parceiros }),
    excluirParceiro: new ExcluirParceiro({ repo: parceiros }),
    mesclarDuplicados: new MesclarDuplicados({ repo: parceiros }),
    receberLead: new ReceberLead({ repo: parceiros }),
    cadastrarContatoDeCanal,
    aplicarClienteDeAutomacao: new AplicarClienteDeAutomacao({ cadastrar: cadastrarContatoDeCanal, repo: parceiros, classificacoes }),
    adicionarEndereco: new AdicionarEndereco(depsVinculos),
    removerEndereco: new RemoverEndereco(depsVinculos),
    adicionarConta: new AdicionarContaBancaria(depsVinculos),
    removerConta: new RemoverContaBancaria(depsVinculos),
    criarProjeto: new CriarProjeto({ repo: projetos, refs: projetos }),
    editarProjeto: new EditarProjeto({ repo: projetos, refs: projetos }),
    mudarStatusProjeto: new MudarStatusProjeto({ repo: projetos }),
    criarClassificacao: new CriarClassificacao({ repo: classificacoes }),
    editarClassificacao: new EditarClassificacao({ repo: classificacoes }),
    excluirClassificacao: new ExcluirClassificacao({ repo: classificacoes }),
    solicitarImportacao: new SolicitarImportacao({ importacoes, fila: new FilaOutboxPg(c), novoId: randomUUID }),
    processarImportacao: new ProcessarImportacao({ importacoes, repo: parceiros, criar: criarParceiro, editar: editarParceiro, porLinha: porLinhaPg(c) }),
  };
}

export type CasosDeUso = ReturnType<typeof casosDeUso>;
