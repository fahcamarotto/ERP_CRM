/**
 * @tool do modulo (N15): cada chamada vira tool MCP em /mcp e rota REST com o mesmo schema no OpenAPI.
 * Tools de M1.8: clientes.listar, clientes.obter, clientes.criar, projetos.listar; mais clientes.atualizar,
 * fornecedores.listar, projetos.criar e projetos.mudar_status.
 */
import { tool } from '@erp/api/sdk';
import { contextoPg } from './compartilhado/efeitos-pg.ts';
import { exigirOk } from './compartilhado/result.ts';
import { estadosProjeto, paginacao, propsParceiro, propsProjeto, uuid } from './esquemas.ts';
import { casosDeUso } from './fabrica.ts';
import { naoEncontrado } from './borda.ts';
import type { DadosParceiro } from './parceiro/model/parceiro.ts';
import { listarParceiros, obterFichaParceiro } from './parceiro/query/parceiros.ts';
import type { DadosProjeto, EstadoProjeto } from './projeto/model/projeto.ts';
import { listarProjetos, obterProjeto } from './projeto/query/projetos.ts';

type Pag = { busca?: string; limite?: number; cursor?: string; estado?: 'ativo' | 'arquivado' | 'todos' };
const estadoParceiro = { type: 'string', enum: ['ativo', 'arquivado', 'todos'], default: 'ativo' } as const;

tool<Pag>({
  nome: 'clientes.listar', modulo: 'cadastros', titulo: 'Listar clientes', tipo: 'leitura', permissao: 'cadastros.ver',
  descricao: 'Lista clientes (parceiros com e_cliente) do workspace, com busca por nome, documento, e-mail ou telefone e paginacao por cursor.',
  entrada: { type: 'object', properties: { ...paginacao, estado: estadoParceiro } },
  rota: { metodo: 'GET', caminho: '/api/v1/cadastros/clientes' },
  executar: ({ c }, a) => listarParceiros(c, { ...a, papel: 'cliente' }),
});

tool<Pag>({
  nome: 'fornecedores.listar', modulo: 'cadastros', titulo: 'Listar fornecedores', tipo: 'leitura', permissao: 'cadastros.ver',
  descricao: 'Lista fornecedores (parceiros com e_fornecedor) do workspace, com busca e paginacao por cursor.',
  entrada: { type: 'object', properties: { ...paginacao, estado: estadoParceiro } },
  rota: { metodo: 'GET', caminho: '/api/v1/cadastros/fornecedores' },
  executar: ({ c }, a) => listarParceiros(c, { ...a, papel: 'fornecedor' }),
});

tool<{ id: string }>({
  nome: 'clientes.obter', modulo: 'cadastros', titulo: 'Obter cliente ou fornecedor', tipo: 'leitura', permissao: 'cadastros.ver',
  descricao: 'Ficha completa de um parceiro (cliente, fornecedor ou contato) pelo id: dados, tags, setor, enderecos, contas bancarias, contatos e projetos.',
  entrada: { type: 'object', required: ['id'], properties: { id: uuid } },
  rota: { metodo: 'GET', caminho: '/api/v1/cadastros/clientes/:id' },
  executar: async ({ c }, a) => (await obterFichaParceiro(c, a.id)) ?? Promise.reject(naoEncontrado('Parceiro nao encontrado')),
});

tool<Partial<DadosParceiro> & { nome: string }>({
  nome: 'clientes.criar', modulo: 'cadastros', titulo: 'Criar cliente', tipo: 'escrita', permissao: 'cadastros.criar',
  descricao: 'Cria um parceiro (padrao: pessoa e cliente). Valida CPF ou CNPJ e telefone E.164, grava auditoria e publica cliente.criado.',
  entrada: { type: 'object', required: ['nome'], properties: propsParceiro },
  rota: { metodo: 'POST', caminho: '/api/v1/cadastros/clientes' },
  executar: async ({ c, ator, ip }, a) => {
    const { id } = exigirOk(await casosDeUso(c).criarParceiro.execute(contextoPg(c, ator, ip), { tipo: 'pessoa', e_cliente: true, ...a }));
    return obterFichaParceiro(c, id);
  },
});

tool<Partial<DadosParceiro> & { id: string }>({
  nome: 'clientes.atualizar', modulo: 'cadastros', titulo: 'Atualizar cliente', tipo: 'escrita', permissao: 'cadastros.editar',
  descricao: 'Atualiza campos de um parceiro. Grava historico no chatter, auditoria e publica cliente.atualizado.',
  entrada: { type: 'object', required: ['id'], properties: { id: uuid, ...propsParceiro } },
  rota: { metodo: 'PATCH', caminho: '/api/v1/cadastros/clientes/:id' },
  executar: async ({ c, ator, ip }, a) => {
    exigirOk(await casosDeUso(c).editarParceiro.execute(contextoPg(c, ator, ip), a));
    return obterFichaParceiro(c, a.id);
  },
});

tool<{ estado?: EstadoProjeto; parceiro_id?: string; busca?: string; limite?: number; cursor?: string }>({
  nome: 'projetos.listar', modulo: 'cadastros', titulo: 'Listar projetos', tipo: 'leitura', permissao: 'cadastros.ver',
  descricao: 'Lista projetos com cliente, responsavel, equipe, prazo, orcamento e status; filtra por status, cliente ou busca.',
  entrada: { type: 'object', properties: { ...paginacao, estado: { type: 'string', enum: [...estadosProjeto] }, parceiro_id: uuid } },
  rota: { metodo: 'GET', caminho: '/api/v1/cadastros/projetos' },
  executar: ({ c }, a) => listarProjetos(c, a),
});

tool<DadosProjeto>({
  nome: 'projetos.criar', modulo: 'cadastros', titulo: 'Criar projeto', tipo: 'escrita', permissao: 'cadastros.criar',
  descricao: 'Cria projeto no status planejado, com cliente, responsavel, equipe, prazo e orcamento. Publica projeto.criado.',
  entrada: { type: 'object', required: ['nome'], properties: propsProjeto },
  rota: { metodo: 'POST', caminho: '/api/v1/cadastros/projetos' },
  executar: async ({ c, ator, ip }, a) => {
    const { id } = exigirOk(await casosDeUso(c).criarProjeto.execute(contextoPg(c, ator, ip), a));
    return obterProjeto(c, id);
  },
});

tool<{ id: string; estado: EstadoProjeto }>({
  nome: 'projetos.mudar_status', modulo: 'cadastros', titulo: 'Mudar status do projeto', tipo: 'escrita', permissao: 'cadastros.editar',
  descricao: 'Muda o status do projeto respeitando as transicoes (planejado, em_andamento, pausado, concluido, cancelado). Publica projeto.status_alterado.',
  entrada: { type: 'object', required: ['id', 'estado'], properties: { id: uuid, estado: { type: 'string', enum: [...estadosProjeto] } } },
  rota: { metodo: 'POST', caminho: '/api/v1/cadastros/projetos/:id/status' },
  executar: async ({ c, ator, ip }, a) => {
    exigirOk(await casosDeUso(c).mudarStatusProjeto.execute(contextoPg(c, ator, ip), a));
    return obterProjeto(c, a.id);
  },
});
