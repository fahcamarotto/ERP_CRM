/**
 * Entidade Projeto (M1.3): cliente, equipe, prazo, orcamento e status com transicoes validas.
 * Imutavel: toda alteracao devolve um clone novo.
 */
import { randomUUID } from 'node:crypto';
import { erroDe, fail, ok, type ErroDominio, type Result } from '../../compartilhado/result.ts';

export const ESTADOS_PROJETO = ['planejado', 'em_andamento', 'pausado', 'concluido', 'cancelado'] as const;
export type EstadoProjeto = (typeof ESTADOS_PROJETO)[number];

/** Maquina de estados do projeto. Concluido e cancelado sao finais. */
export const TRANSICOES: Record<EstadoProjeto, EstadoProjeto[]> = {
  planejado: ['em_andamento', 'cancelado'],
  em_andamento: ['pausado', 'concluido', 'cancelado'],
  pausado: ['em_andamento', 'cancelado'],
  concluido: [],
  cancelado: [],
};

export interface DadosProjeto {
  nome: string;
  descricao?: string | null;
  parceiro_id?: string | null;
  responsavel_id?: string | null;
  equipe_ids?: string[];
  inicio?: string | null;
  prazo?: string | null;
  orcamento?: number | null;
  moeda?: string;
  extras?: Record<string, unknown>;
}

export interface ProjetoDados {
  id: string;
  nome: string;
  descricao: string | null;
  parceiro_id: string | null;
  responsavel_id: string | null;
  equipe_ids: string[];
  inicio: string | null;
  prazo: string | null;
  orcamento: number | null;
  moeda: string;
  estado: EstadoProjeto;
  extras: Record<string, unknown>;
}

const t = (v?: string | null) => (v ?? '').trim() || null;
const dataValida = (v: string | null) => v === null || (/^\d{4}-\d{2}-\d{2}$/.test(v) && !Number.isNaN(Date.parse(v)));

function validar(d: ProjetoDados): ErroDominio[] {
  const e: ErroDominio[] = [];
  if (d.nome.length < 2 || d.nome.length > 200) e.push(erroDe('nome_invalido', 'Nome deve ter de 2 a 200 caracteres', 'nome'));
  if (!dataValida(d.inicio)) e.push(erroDe('data_invalida', 'Inicio deve ser AAAA-MM-DD', 'inicio'));
  if (!dataValida(d.prazo)) e.push(erroDe('data_invalida', 'Prazo deve ser AAAA-MM-DD', 'prazo'));
  if (d.inicio && d.prazo && dataValida(d.inicio) && dataValida(d.prazo) && d.prazo < d.inicio) e.push(erroDe('prazo_invalido', 'Prazo antes do inicio', 'prazo'));
  if (d.orcamento !== null && (!Number.isFinite(d.orcamento) || d.orcamento < 0)) e.push(erroDe('orcamento_invalido', 'Orcamento deve ser zero ou positivo', 'orcamento'));
  if (!/^[A-Z]{3}$/.test(d.moeda)) e.push(erroDe('moeda_invalida', 'Moeda em ISO 4217 (BRL, USD, EUR)', 'moeda'));
  if (!ESTADOS_PROJETO.includes(d.estado)) e.push(erroDe('estado_invalido', 'Estado invalido', 'estado'));
  return e;
}

export class Projeto {
  private constructor(private readonly d: ProjetoDados) {}

  static tryCreate(e: DadosProjeto, id: string = randomUUID()): Result<Projeto> {
    const d: ProjetoDados = {
      id, nome: (e.nome ?? '').trim(), descricao: t(e.descricao), parceiro_id: t(e.parceiro_id), responsavel_id: t(e.responsavel_id),
      equipe_ids: [...new Set(e.equipe_ids ?? [])], inicio: t(e.inicio), prazo: t(e.prazo),
      orcamento: e.orcamento === undefined || e.orcamento === null ? null : Math.round(Number(e.orcamento) * 100) / 100,
      moeda: (t(e.moeda) ?? 'BRL').toUpperCase(), estado: 'planejado', extras: e.extras ?? {},
    };
    const erros = validar(d);
    return erros.length ? fail(...erros) : ok(new Projeto(d));
  }

  static create(e: DadosProjeto, id?: string): Projeto {
    const r = Projeto.tryCreate(e, id);
    if (!r.ok) throw new Error(r.erros.map((x) => x.mensagem).join('; '));
    return r.valor;
  }

  static reidratar(d: ProjetoDados): Projeto {
    return new Projeto({ ...d, equipe_ids: [...d.equipe_ids], extras: { ...d.extras } });
  }

  get id(): string { return this.d.id; }
  get estado(): EstadoProjeto { return this.d.estado; }

  editar(e: Partial<DadosProjeto>): Result<Projeto> {
    if (this.d.estado === 'concluido' || this.d.estado === 'cancelado') {
      return fail(erroDe('transicao_invalida', `Projeto ${this.d.estado} nao pode ser editado`));
    }
    const tem = (k: keyof DadosProjeto) => e[k] !== undefined;
    const n: ProjetoDados = {
      ...this.d,
      nome: tem('nome') ? (e.nome ?? '').trim() : this.d.nome,
      descricao: tem('descricao') ? t(e.descricao) : this.d.descricao,
      parceiro_id: tem('parceiro_id') ? t(e.parceiro_id) : this.d.parceiro_id,
      responsavel_id: tem('responsavel_id') ? t(e.responsavel_id) : this.d.responsavel_id,
      equipe_ids: tem('equipe_ids') ? [...new Set(e.equipe_ids!)] : [...this.d.equipe_ids],
      inicio: tem('inicio') ? t(e.inicio) : this.d.inicio,
      prazo: tem('prazo') ? t(e.prazo) : this.d.prazo,
      orcamento: tem('orcamento') ? (e.orcamento === null ? null : Math.round(Number(e.orcamento) * 100) / 100) : this.d.orcamento,
      moeda: tem('moeda') ? (t(e.moeda) ?? 'BRL').toUpperCase() : this.d.moeda,
      extras: tem('extras') ? { ...e.extras } : { ...this.d.extras },
    };
    const erros = validar(n);
    return erros.length ? fail(...erros) : ok(new Projeto(n));
  }

  mudarEstado(novo: EstadoProjeto): Result<Projeto> {
    if (!ESTADOS_PROJETO.includes(novo)) return fail(erroDe('estado_invalido', 'Estado invalido', 'estado'));
    if (!TRANSICOES[this.d.estado].includes(novo)) {
      return fail(erroDe('transicao_invalida', `Transicao de ${this.d.estado} para ${novo} nao permitida`, 'estado', { permitidas: TRANSICOES[this.d.estado] }));
    }
    return ok(new Projeto({ ...this.d, estado: novo }));
  }

  paraDados(): ProjetoDados {
    return { ...this.d, equipe_ids: [...this.d.equipe_ids], extras: { ...this.d.extras } };
  }
}
