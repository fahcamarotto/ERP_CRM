/** Portas do repositorio do agregado Projeto, segregadas por operacao. */
import type { Projeto } from './projeto.ts';

export interface ObterProjeto {
  obterPorId(id: string): Promise<Projeto | null>;
}

export interface GravarProjeto {
  inserir(p: Projeto): Promise<void>;
  atualizar(p: Projeto): Promise<void>;
}

/** Referencias externas ao agregado: cliente (parceiro ativo) e usuarios do workspace. */
export interface ConsultarReferenciasProjeto {
  parceiroAtivo(id: string): Promise<boolean>;
  usuariosExistentes(ids: string[]): Promise<string[]>;
}
