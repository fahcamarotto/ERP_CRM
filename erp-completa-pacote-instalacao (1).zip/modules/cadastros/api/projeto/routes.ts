/** Rotas REST do Projeto fora das tools (ficha e edicao). Listar, criar e mudar status sao @tool em ../tools.ts. */
import { esquemaErro, requer, type FastifyInstance } from '@erp/api/sdk';
import { naTransacao, naoEncontrado } from '../borda.ts';
import { exigirOk } from '../compartilhado/result.ts';
import { propsProjeto, uuid } from '../esquemas.ts';
import type { DadosProjeto } from './model/projeto.ts';
import { obterProjeto } from './query/projetos.ts';

const tags = ['cadastros'];
const paramId = { type: 'object', required: ['id'], properties: { id: uuid } } as const;

export function rotasProjeto(app: FastifyInstance): void {
  // Leitura da tabela publicada do nucleo `usuarios` (docs/CONTRATOS.md 2.2): opcoes de responsavel e equipe.
  app.get('/responsaveis', {
    preHandler: requer('cadastros.ver'),
    schema: { tags, summary: 'Usuarios ativos do workspace (responsavel e equipe de projeto)' },
  }, (req) => naTransacao(req, async (_, __, c) => (await c.query('SELECT id, nome FROM usuarios WHERE ativo AND deleted_at IS NULL ORDER BY nome')).rows));

  app.get<{ Params: { id: string } }>('/projetos/:id', {
    preHandler: requer('cadastros.ver'),
    schema: { tags, summary: 'Ficha do projeto com equipe', params: paramId, response: { 404: esquemaErro } },
  }, (req) => naTransacao(req, async (_, __, c) => (await obterProjeto(c, req.params.id)) ?? Promise.reject(naoEncontrado('Projeto nao encontrado'))));

  app.patch<{ Params: { id: string }; Body: Partial<DadosProjeto> }>('/projetos/:id', {
    preHandler: requer('cadastros.editar'),
    schema: {
      tags, summary: 'Edita projeto (EditarProjeto)', params: paramId,
      body: { type: 'object', additionalProperties: false, properties: propsProjeto },
      response: { 400: esquemaErro, 404: esquemaErro, 409: esquemaErro },
    },
  }, (req) => naTransacao(req, async (casos, ctx, c) => {
    exigirOk(await casos.editarProjeto.execute(ctx, { ...req.body, id: req.params.id }));
    return obterProjeto(c, req.params.id);
  }));
}
