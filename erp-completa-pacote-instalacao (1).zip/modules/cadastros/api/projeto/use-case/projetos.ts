/** Casos de uso do Projeto (M1.5): CriarProjeto, EditarProjeto e MudarStatusProjeto. */
import { erroDe, fail, ok, okVazio, type ErroDominio, type Result } from '../../compartilhado/result.ts';
import type { ContextoCaso } from '../../compartilhado/efeitos.ts';
import { Projeto, type DadosProjeto, type EstadoProjeto } from '../model/projeto.ts';
import type { ConsultarReferenciasProjeto, GravarProjeto, ObterProjeto } from '../model/portas.ts';

export interface DepsProjeto {
  repo: ObterProjeto & GravarProjeto;
  refs: ConsultarReferenciasProjeto;
}

async function conferir(refs: ConsultarReferenciasProjeto, p: Projeto, anterior?: Projeto): Promise<ErroDominio[]> {
  const d = p.paraDados();
  const a = anterior?.paraDados();
  const erros: ErroDominio[] = [];
  if (d.parceiro_id && d.parceiro_id !== a?.parceiro_id && !(await refs.parceiroAtivo(d.parceiro_id))) {
    erros.push(erroDe('cliente_invalido', 'Cliente nao encontrado ou arquivado', 'parceiro_id'));
  }
  const usuarios = [...new Set([...(d.responsavel_id ? [d.responsavel_id] : []), ...d.equipe_ids])];
  if (usuarios.length) {
    const ok = new Set(await refs.usuariosExistentes(usuarios));
    const faltam = usuarios.filter((u) => !ok.has(u));
    if (faltam.length) erros.push(erroDe('usuario_invalido', 'Responsavel ou membro da equipe nao encontrado', 'equipe_ids', { faltam }));
  }
  return erros;
}

export class CriarProjeto {
  constructor(private readonly deps: DepsProjeto) {}
  async execute(ctx: ContextoCaso, e: DadosProjeto): Promise<Result<{ id: string }>> {
    const r = Projeto.tryCreate(e);
    if (!r.ok) return r;
    const erros = await conferir(this.deps.refs, r.valor);
    if (erros.length) return fail(...erros);
    await this.deps.repo.inserir(r.valor);
    const d = r.valor.paraDados();
    await ctx.efeitos.auditar('projeto.criar', 'cadastros_projetos', d.id, undefined, d);
    await ctx.efeitos.publicar('projeto.criado', { id: d.id, nome: d.nome, parceiro_id: d.parceiro_id, estado: d.estado, prazo: d.prazo, orcamento: d.orcamento, moeda: d.moeda });
    return ok({ id: d.id });
  }
}

export class EditarProjeto {
  constructor(private readonly deps: DepsProjeto) {}
  async execute(ctx: ContextoCaso, e: { id: string } & Partial<DadosProjeto>): Promise<Result<void>> {
    const { id, ...mud } = e;
    const atual = await this.deps.repo.obterPorId(id);
    if (!atual) return fail(erroDe('nao_encontrado', 'Projeto nao encontrado'));
    const r = atual.editar(mud);
    if (!r.ok) return r;
    const erros = await conferir(this.deps.refs, r.valor, atual);
    if (erros.length) return fail(...erros);
    await this.deps.repo.atualizar(r.valor);
    const antes = atual.paraDados() as unknown as Record<string, unknown>;
    const depois = r.valor.paraDados() as unknown as Record<string, unknown>;
    await ctx.efeitos.historico('cadastros_projetos', id, antes, depois);
    await ctx.efeitos.auditar('projeto.editar', 'cadastros_projetos', id, antes, depois);
    return okVazio();
  }
}

export class MudarStatusProjeto {
  constructor(private readonly deps: { repo: ObterProjeto & GravarProjeto }) {}
  async execute(ctx: ContextoCaso, e: { id: string; estado: EstadoProjeto }): Promise<Result<void>> {
    const atual = await this.deps.repo.obterPorId(e.id);
    if (!atual) return fail(erroDe('nao_encontrado', 'Projeto nao encontrado'));
    const r = atual.mudarEstado(e.estado);
    if (!r.ok) return r;
    await this.deps.repo.atualizar(r.valor);
    await ctx.efeitos.historico('cadastros_projetos', e.id, { estado: atual.estado }, { estado: r.valor.estado });
    await ctx.efeitos.auditar('projeto.mudar_status', 'cadastros_projetos', e.id, { estado: atual.estado }, { estado: r.valor.estado });
    await ctx.efeitos.publicar('projeto.status_alterado', { id: e.id, de: atual.estado, para: r.valor.estado });
    return okVazio();
  }
}
