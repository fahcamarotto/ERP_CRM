/** Consultas de leitura do Projeto: lista com cliente e responsavel, ficha com equipe. */
import type pg from 'pg';
import { decodificarCursor, pagina } from '../../compartilhado/cursor.ts';

const RESUMO = `p.id, p.nome, p.descricao, p.parceiro_id, c.nome AS cliente_nome, p.responsavel_id, u.nome AS responsavel_nome,
  to_char(p.inicio, 'YYYY-MM-DD') AS inicio, to_char(p.prazo, 'YYYY-MM-DD') AS prazo, p.orcamento::float8 AS orcamento, p.moeda,
  p.estado, p.created_at, p.updated_at,
  coalesce((SELECT json_agg(json_build_object('id', m.id, 'nome', m.nome) ORDER BY m.nome) FROM cadastros_projeto_equipe e
            JOIN usuarios m ON m.id = e.usuario_id WHERE e.projeto_id = p.id AND e.deleted_at IS NULL), '[]') AS equipe`;

const JUNCOES = `FROM cadastros_projetos p
  LEFT JOIN cadastros_parceiros c ON c.id = p.parceiro_id AND c.deleted_at IS NULL
  LEFT JOIN usuarios u ON u.id = p.responsavel_id`;

export interface FiltroProjetos {
  estado?: string;
  parceiro_id?: string;
  busca?: string;
  limite?: number;
  cursor?: string;
}

export async function listarProjetos(c: pg.PoolClient, f: FiltroProjetos) {
  const lim = Math.min(Math.max(f.limite ?? 50, 1), 200);
  const cur = decodificarCursor(f.cursor);
  const r = await c.query(
    `SELECT ${RESUMO} ${JUNCOES}
     WHERE p.deleted_at IS NULL AND ($1::text IS NULL OR p.estado = $1) AND ($2::uuid IS NULL OR p.parceiro_id = $2)
       AND ($3::text IS NULL OR p.nome ILIKE '%' || $3 || '%' OR c.nome ILIKE '%' || $3 || '%')
       AND ($4::timestamptz IS NULL OR (p.created_at, p.id) > ($4::timestamptz, $5::uuid))
     ORDER BY p.created_at, p.id LIMIT $6`,
    [f.estado ?? null, f.parceiro_id ?? null, f.busca?.trim() || null, cur?.[0] ?? null, cur?.[1] ?? null, lim + 1],
  );
  return pagina(r.rows, lim);
}

export async function obterProjeto(c: pg.PoolClient, id: string) {
  return (await c.query(`SELECT ${RESUMO}, p.extras ${JUNCOES} WHERE p.id = $1 AND p.deleted_at IS NULL`, [id])).rows[0] ?? null;
}
