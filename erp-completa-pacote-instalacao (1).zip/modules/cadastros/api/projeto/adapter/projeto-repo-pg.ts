/** Adaptador Postgres das portas do agregado Projeto (RLS restringe ao workspace da sessao). */
import type pg from 'pg';
import { Projeto, type ProjetoDados } from '../model/projeto.ts';
import type { ConsultarReferenciasProjeto, GravarProjeto, ObterProjeto } from '../model/portas.ts';

export class ProjetoRepoPg implements ObterProjeto, GravarProjeto, ConsultarReferenciasProjeto {
  constructor(private readonly c: pg.PoolClient) {}

  async obterPorId(id: string): Promise<Projeto | null> {
    const r = await this.c.query(
      `SELECT p.id, p.nome, p.descricao, p.parceiro_id, p.responsavel_id, to_char(p.inicio, 'YYYY-MM-DD') AS inicio,
         to_char(p.prazo, 'YYYY-MM-DD') AS prazo, p.orcamento::float8 AS orcamento, p.moeda, p.estado, p.extras,
         coalesce((SELECT array_agg(e.usuario_id) FROM cadastros_projeto_equipe e WHERE e.projeto_id = p.id AND e.deleted_at IS NULL), '{}') AS equipe_ids
       FROM cadastros_projetos p WHERE p.id = $1 AND p.deleted_at IS NULL`,
      [id],
    );
    return r.rows[0] ? Projeto.reidratar(r.rows[0] as ProjetoDados) : null;
  }

  async inserir(p: Projeto): Promise<void> {
    const d = p.paraDados();
    await this.c.query(
      `INSERT INTO cadastros_projetos (id, nome, descricao, parceiro_id, responsavel_id, inicio, prazo, orcamento, moeda, estado, extras, creator_id)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, nucleo_usuario_atual())`,
      [d.id, d.nome, d.descricao, d.parceiro_id, d.responsavel_id, d.inicio, d.prazo, d.orcamento, d.moeda, d.estado, JSON.stringify(d.extras)],
    );
    await this.sincronizarEquipe(d.id, d.equipe_ids);
  }

  async atualizar(p: Projeto): Promise<void> {
    const d = p.paraDados();
    await this.c.query(
      `UPDATE cadastros_projetos SET nome = $2, descricao = $3, parceiro_id = $4, responsavel_id = $5, inicio = $6, prazo = $7,
         orcamento = $8, moeda = $9, estado = $10, extras = $11 WHERE id = $1 AND deleted_at IS NULL`,
      [d.id, d.nome, d.descricao, d.parceiro_id, d.responsavel_id, d.inicio, d.prazo, d.orcamento, d.moeda, d.estado, JSON.stringify(d.extras)],
    );
    await this.sincronizarEquipe(d.id, d.equipe_ids);
  }

  private async sincronizarEquipe(projetoId: string, ids: string[]): Promise<void> {
    await this.c.query(
      'UPDATE cadastros_projeto_equipe SET deleted_at = now() WHERE projeto_id = $1 AND deleted_at IS NULL AND NOT (usuario_id = ANY ($2::uuid[]))',
      [projetoId, ids],
    );
    if (!ids.length) return;
    await this.c.query(
      `INSERT INTO cadastros_projeto_equipe (projeto_id, usuario_id, creator_id) SELECT $1, u, nucleo_usuario_atual() FROM unnest($2::uuid[]) u
       ON CONFLICT (tenant_id, workspace_id, projeto_id, usuario_id) DO UPDATE SET deleted_at = NULL`,
      [projetoId, ids],
    );
  }

  async parceiroAtivo(id: string): Promise<boolean> {
    const r = await this.c.query("SELECT 1 FROM cadastros_parceiros WHERE id = $1 AND deleted_at IS NULL AND estado = 'ativo'", [id]);
    return (r.rowCount ?? 0) > 0;
  }

  async usuariosExistentes(ids: string[]): Promise<string[]> {
    const r = await this.c.query('SELECT id FROM usuarios WHERE id = ANY ($1::uuid[]) AND deleted_at IS NULL', [ids]);
    return r.rows.map((x) => x.id as string);
  }
}
