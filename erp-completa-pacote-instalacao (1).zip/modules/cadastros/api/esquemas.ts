/** JSON Schemas dos DTOs de entrada (viram validacao Fastify, OpenAPI em /docs e schema das tools MCP). */
export const uuid = { type: 'string', format: 'uuid' } as const;
const texto = (max: number) => ({ type: ['string', 'null'], maxLength: max });

export const propsParceiro = {
  tipo: { type: 'string', enum: ['pessoa', 'empresa'], description: 'pessoa (CPF) ou empresa (CNPJ)' },
  nome: { type: 'string', minLength: 2, maxLength: 200 },
  nome_fantasia: texto(200),
  documento: { ...texto(20), description: 'CPF ou CNPJ, com ou sem mascara' },
  email: texto(254),
  telefone: { ...texto(30), description: 'E.164 (+5511987654321); numero brasileiro sem DDI recebe +55' },
  parent_id: { type: ['string', 'null'], format: 'uuid', description: 'Empresa do contato (so para tipo pessoa)' },
  cargo: texto(120),
  setor_id: { type: ['string', 'null'], format: 'uuid' },
  tag_ids: { type: 'array', items: uuid, maxItems: 50 },
  origem: texto(60),
  ranking_cliente: { type: 'integer', minimum: 0, maximum: 5 },
  ranking_fornecedor: { type: 'integer', minimum: 0, maximum: 5 },
  e_cliente: { type: 'boolean' },
  e_fornecedor: { type: 'boolean' },
  observacoes: texto(4000),
  extras: { type: 'object', description: 'Campos personalizados (modulo cadastros, entidade parceiro)' },
} as const;

export const propsEndereco = {
  tipo: { type: 'string', enum: ['principal', 'cobranca', 'entrega', 'outro'] },
  cep: texto(9), logradouro: { type: 'string', minLength: 1, maxLength: 200 }, numero: texto(20), complemento: texto(120),
  bairro: texto(120), cidade: { type: 'string', minLength: 1, maxLength: 120 }, uf: texto(2), pais: texto(2),
} as const;

export const propsConta = {
  banco_codigo: { type: 'string', maxLength: 3 }, banco_nome: texto(120), agencia: { type: 'string', maxLength: 8 },
  conta: { type: 'string', maxLength: 15 }, tipo: { type: 'string', enum: ['corrente', 'poupanca', 'pagamento'] },
  titular: texto(200), pix_chave: texto(140), principal: { type: 'boolean' },
} as const;

export const propsProjeto = {
  nome: { type: 'string', minLength: 2, maxLength: 200 },
  descricao: texto(4000),
  parceiro_id: { type: ['string', 'null'], format: 'uuid', description: 'Cliente do projeto' },
  responsavel_id: { type: ['string', 'null'], format: 'uuid' },
  equipe_ids: { type: 'array', items: uuid, maxItems: 100 },
  inicio: { type: ['string', 'null'], format: 'date' },
  prazo: { type: ['string', 'null'], format: 'date' },
  orcamento: { type: ['number', 'null'], minimum: 0 },
  moeda: { type: 'string', pattern: '^[A-Z]{3}$' },
  extras: { type: 'object' },
} as const;

export const estadosProjeto = ['planejado', 'em_andamento', 'pausado', 'concluido', 'cancelado'] as const;

export const propsClassificacao = {
  tipo: { type: 'string', enum: ['tag', 'setor'] },
  nome: { type: 'string', minLength: 1, maxLength: 60 },
  cor: { type: 'string', enum: ['acento', 'roxo', 'azul', 'ciano', 'laranja', 'dourado', 'sucesso', 'perigo'] },
  descricao: texto(300),
} as const;

export const paginacao = {
  busca: { type: 'string', maxLength: 120 },
  limite: { type: 'integer', minimum: 1, maximum: 200, default: 50 },
  cursor: { type: 'string', maxLength: 200 },
} as const;
