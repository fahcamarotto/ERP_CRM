/**
 * ImportarParceirosCSV (M1.5, job): a API grava a importacao e a intencao do job na outbox na
 * mesma transacao (SolicitarImportacao); o worker processa (ProcessarImportacao) linha a linha,
 * cria ou atualiza pelo documento ou e-mail, grava o progresso e publica importacao.concluida.
 */
import { erroDe, fail, ok, type ErroDominio, type Result } from '../compartilhado/result.ts';
import type { ContextoCaso } from '../compartilhado/efeitos.ts';
import type { DadosParceiro, TipoParceiro } from '../parceiro/model/parceiro.ts';
import type { BuscarParceiroPorChave } from '../parceiro/model/portas.ts';
import type { CriarParceiro } from '../parceiro/use-case/criar-parceiro.ts';
import type { EditarParceiro } from '../parceiro/use-case/editar-parceiro.ts';
import { lerCsv } from './csv.ts';

export const LIMITE_LINHAS = 5000;
export const TIPO_JOB = 'cadastros.importar_csv';

export interface ImportacaoDados {
  id: string;
  nome_arquivo: string;
  conteudo: string;
  estado: 'pendente' | 'processando' | 'concluida' | 'erro';
}

export interface PortaImportacoes {
  inserir(d: { id: string; nome_arquivo: string; conteudo: string }): Promise<void>;
  obter(id: string): Promise<ImportacaoDados | null>;
  progresso(id: string, p: { estado: ImportacaoDados['estado']; total: number; criados: number; atualizados: number; erros: unknown[]; job_id?: string }): Promise<void>;
}

/** Fila de jobs: grava a intencao na outbox (mesma transacao) e devolve o id do job. */
export interface FilaJobs {
  enfileirar(tipo: string, payload: Record<string, unknown>): Promise<string>;
}

export class SolicitarImportacao {
  constructor(private readonly deps: { importacoes: PortaImportacoes; fila: FilaJobs; novoId: () => string }) {}

  async execute(ctx: ContextoCaso, e: { nome_arquivo: string; conteudo: string }): Promise<Result<{ importacao_id: string; job_id: string }>> {
    const { cabecalho, linhas } = lerCsv(e.conteudo ?? '');
    if (!cabecalho.includes('nome')) return fail(erroDe('csv_invalido', 'CSV sem a coluna obrigatoria nome', 'conteudo'));
    if (linhas.length === 0) return fail(erroDe('csv_invalido', 'CSV sem linhas de dados', 'conteudo'));
    if (linhas.length > LIMITE_LINHAS) return fail(erroDe('csv_invalido', `Maximo de ${LIMITE_LINHAS} linhas por importacao`, 'conteudo'));
    const id = this.deps.novoId();
    await this.deps.importacoes.inserir({ id, nome_arquivo: e.nome_arquivo.slice(0, 200), conteudo: e.conteudo });
    const job = await this.deps.fila.enfileirar(TIPO_JOB, { importacao_id: id });
    await this.deps.importacoes.progresso(id, { estado: 'pendente', total: linhas.length, criados: 0, atualizados: 0, erros: [], job_id: job });
    await ctx.efeitos.auditar('parceiro.importar_csv', 'cadastros_importacoes', id, undefined, { nome_arquivo: e.nome_arquivo, linhas: linhas.length });
    return ok({ importacao_id: id, job_id: job });
  }
}

const SIM = new Set(['1', 'sim', 's', 'true', 'x', 'yes', 'si']);

/** Converte uma linha do CSV na entrada crua do parceiro. Colunas aceitas documentadas no .http. */
export function linhaParaParceiro(cab: string[], l: string[]): DadosParceiro & { empresa_documento?: string } {
  const v = (k: string) => (l[cab.indexOf(k)] ?? '').trim();
  const doc = v('documento').replace(/\D/g, '');
  const tipoCol = v('tipo').toLowerCase();
  const tipo: TipoParceiro = tipoCol === 'empresa' || tipoCol === 'pessoa' ? tipoCol : doc.length === 14 ? 'empresa' : 'pessoa';
  return {
    tipo, nome: v('nome'), nome_fantasia: v('nome_fantasia') || null, documento: v('documento') || null,
    email: v('email') || null, telefone: v('telefone') || null, cargo: v('cargo') || null,
    origem: v('origem') || 'importacao_csv', observacoes: v('observacoes') || null,
    e_cliente: cab.includes('e_cliente') ? SIM.has(v('e_cliente').toLowerCase()) : true,
    e_fornecedor: SIM.has(v('e_fornecedor').toLowerCase()),
    empresa_documento: v('empresa_documento') || undefined,
  };
}

export class ProcessarImportacao {
  constructor(private readonly deps: {
    importacoes: PortaImportacoes;
    repo: BuscarParceiroPorChave;
    criar: CriarParceiro;
    editar: EditarParceiro;
    /** Isola cada linha (savepoint no Postgres): erro numa linha nao derruba as outras. */
    porLinha: <T>(fn: () => Promise<T>) => Promise<T>;
  }) {}

  async execute(ctx: ContextoCaso, e: { importacao_id: string }): Promise<Result<{ criados: number; atualizados: number; erros: number }>> {
    const imp = await this.deps.importacoes.obter(e.importacao_id);
    if (!imp) return fail(erroDe('nao_encontrado', 'Importacao nao encontrada'));
    if (imp.estado === 'concluida') return ok({ criados: 0, atualizados: 0, erros: 0 });
    const { cabecalho, linhas } = lerCsv(imp.conteudo);
    const erros: { linha: number; erros: ErroDominio[] }[] = [];
    let criados = 0;
    let atualizados = 0;
    await this.deps.importacoes.progresso(imp.id, { estado: 'processando', total: linhas.length, criados, atualizados, erros });
    for (let i = 0; i < linhas.length; i++) {
      const { empresa_documento, ...dados } = linhaParaParceiro(cabecalho, linhas[i]!);
      try {
        const r = await this.deps.porLinha(async () => {
          if (empresa_documento) {
            const empresa = await this.deps.repo.buscarPorDocumento(empresa_documento.replace(/\D/g, ''));
            if (empresa) dados.parent_id = empresa.id;
          }
          const docLimpo = dados.documento?.replace(/\D/g, '') || null;
          const existente = (docLimpo ? await this.deps.repo.buscarPorDocumento(docLimpo) : null)
            ?? (dados.email ? await this.deps.repo.buscarPorContato(dados.email.trim().toLowerCase(), null) : null);
          if (existente) {
            const r2 = await this.deps.editar.execute(ctx, { id: existente.id, ...dados, origem: undefined });
            return r2.ok ? ok('atualizado' as const) : fail<'atualizado'>(...r2.erros);
          }
          const r1 = await this.deps.criar.execute(ctx, dados);
          return r1.ok ? ok('criado' as const) : fail<'criado'>(...r1.erros);
        });
        if (!r.ok) erros.push({ linha: i + 2, erros: r.erros });
        else if (r.valor === 'criado') criados++;
        else atualizados++;
      } catch (err) {
        erros.push({ linha: i + 2, erros: [erroDe('erro_banco', (err as Error).message)] });
      }
    }
    await this.deps.importacoes.progresso(imp.id, { estado: 'concluida', total: linhas.length, criados, atualizados, erros: erros.slice(0, 500) });
    await ctx.efeitos.publicar('importacao.concluida', { id: imp.id, total: linhas.length, criados, atualizados, erros: erros.length });
    return ok({ criados, atualizados, erros: erros.length });
  }
}
