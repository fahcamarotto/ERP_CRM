/** Rotas da importacao CSV (job): solicita, lista e consulta o progresso. */
import { esquemaErro, requer, type FastifyInstance } from '@erp/api/sdk';
import { naTransacao, naoEncontrado } from '../borda.ts';
import { exigirOk } from '../compartilhado/result.ts';
import { uuid } from '../esquemas.ts';
import { listarImportacoes, statusImportacao } from './importacao-repo-pg.ts';

const tags = ['cadastros'];

export function rotasImportacao(app: FastifyInstance): void {
  app.post<{ Body: { nome_arquivo: string; conteudo: string } }>('/importacoes', {
    preHandler: requer('cadastros.importar'),
    bodyLimit: 2 * 1024 * 1024,
    schema: {
      tags, summary: 'Importa parceiros de CSV (job na fila; consulte GET /importacoes/:id ou /api/v1/jobs/:job_id)',
      body: { type: 'object', additionalProperties: false, required: ['nome_arquivo', 'conteudo'], properties: {
        nome_arquivo: { type: 'string', minLength: 1, maxLength: 200 }, conteudo: { type: 'string', minLength: 1, maxLength: 2_000_000 },
      } },
      response: { 400: esquemaErro, 403: esquemaErro },
    },
  }, async (req, reply) => reply.code(202).send(await naTransacao(req, async (casos, ctx) => exigirOk(await casos.solicitarImportacao.execute(ctx, req.body)))));

  app.get('/importacoes', {
    preHandler: requer('cadastros.ver'),
    schema: { tags, summary: 'Ultimas 50 importacoes' },
  }, (req) => naTransacao(req, (_, __, c) => listarImportacoes(c)));

  app.get<{ Params: { id: string } }>('/importacoes/:id', {
    preHandler: requer('cadastros.ver'),
    schema: { tags, summary: 'Progresso da importacao', params: { type: 'object', required: ['id'], properties: { id: uuid } }, response: { 404: esquemaErro } },
  }, (req) => naTransacao(req, async (_, __, c) => (await statusImportacao(c, req.params.id)) ?? Promise.reject(naoEncontrado('Importacao nao encontrada'))));
}
