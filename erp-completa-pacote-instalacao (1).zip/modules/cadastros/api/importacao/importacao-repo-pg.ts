/** Adaptadores Postgres da importacao CSV: tabela cadastros_importacoes e fila (outbox do nucleo). */
import type pg from 'pg';
import type { FilaJobs, ImportacaoDados, PortaImportacoes } from './importar-parceiros.ts';

export class ImportacaoRepoPg implements PortaImportacoes {
  constructor(private readonly c: pg.PoolClient) {}

  async inserir(d: { id: string; nome_arquivo: string; conteudo: string }) {
    await this.c.query('INSERT INTO cadastros_importacoes (id, nome_arquivo, conteudo, creator_id) VALUES ($1, $2, $3, nucleo_usuario_atual())', [d.id, d.nome_arquivo, d.conteudo]);
  }

  async obter(id: string): Promise<ImportacaoDados | null> {
    return (await this.c.query('SELECT id, nome_arquivo, conteudo, estado FROM cadastros_importacoes WHERE id = $1 AND deleted_at IS NULL', [id])).rows[0] ?? null;
  }

  async progresso(id: string, p: Parameters<PortaImportacoes['progresso']>[1]) {
    await this.c.query(
      `UPDATE cadastros_importacoes SET estado = $2, total = $3, criados = $4, atualizados = $5, erros = $6, job_id = coalesce($7, job_id),
         concluida_em = CASE WHEN $2 = 'concluida' THEN now() ELSE concluida_em END WHERE id = $1`,
      [id, p.estado, p.total, p.criados, p.atualizados, JSON.stringify(p.erros), p.job_id ?? null],
    );
  }
}

/** Intencao do job gravada na outbox do nucleo, na mesma transacao do caso de uso (docs/CONTRATOS.md 6). */
export class FilaOutboxPg implements FilaJobs {
  constructor(private readonly c: pg.PoolClient) {}
  async enfileirar(tipo: string, payload: Record<string, unknown>): Promise<string> {
    return (await this.c.query('INSERT INTO outbox (tipo, payload) VALUES ($1, $2) RETURNING id', [tipo, JSON.stringify(payload)])).rows[0].id as string;
  }
}

/** Savepoint por linha: erro numa linha volta so aquela linha. */
export function porLinhaPg(c: pg.PoolClient) {
  return async <T>(fn: () => Promise<T>): Promise<T> => {
    await c.query('SAVEPOINT cadastros_linha');
    try {
      const r = await fn();
      if (r && typeof r === 'object' && 'ok' in r && (r as { ok: boolean }).ok === false) await c.query('ROLLBACK TO SAVEPOINT cadastros_linha');
      else await c.query('RELEASE SAVEPOINT cadastros_linha');
      return r;
    } catch (e) {
      await c.query('ROLLBACK TO SAVEPOINT cadastros_linha');
      throw e;
    }
  };
}

export async function statusImportacao(c: pg.PoolClient, id: string) {
  return (await c.query(
    `SELECT id, nome_arquivo, estado, total, criados, atualizados, erros, job_id, created_at, concluida_em
     FROM cadastros_importacoes WHERE id = $1 AND deleted_at IS NULL`, [id])).rows[0] ?? null;
}

export async function listarImportacoes(c: pg.PoolClient) {
  return (await c.query(
    `SELECT id, nome_arquivo, estado, total, criados, atualizados, jsonb_array_length(erros) AS qtd_erros, job_id, created_at, concluida_em
     FROM cadastros_importacoes WHERE deleted_at IS NULL ORDER BY created_at DESC LIMIT 50`)).rows;
}
