/** Casos de uso de Tags e setores (M1.4): criar, editar e excluir (bloqueado enquanto em uso). */
import { erroDe, fail, ok, okVazio, type Result } from '../../compartilhado/result.ts';
import type { ContextoCaso } from '../../compartilhado/efeitos.ts';
import { Classificacao, type CorClassificacao, type TipoClassificacao } from '../model/classificacao.ts';
import type { ContarUsoClassificacao, GravarClassificacao, ObterClassificacao } from '../model/portas.ts';

type Repo = ObterClassificacao & GravarClassificacao & ContarUsoClassificacao;

export class CriarClassificacao {
  constructor(private readonly deps: { repo: Repo }) {}
  async execute(ctx: ContextoCaso, e: { tipo: TipoClassificacao; nome: string; cor?: CorClassificacao; descricao?: string | null }): Promise<Result<{ id: string }>> {
    const r = Classificacao.tryCreate(e);
    if (!r.ok) return r;
    const d = r.valor.paraDados();
    if (await this.deps.repo.buscarPorNome(d.tipo, d.nome)) return fail(erroDe('conflito', `Ja existe ${d.tipo} com este nome`, 'nome'));
    await this.deps.repo.inserir(r.valor);
    await ctx.efeitos.auditar('classificacao.criar', 'cadastros_classificacoes', d.id, undefined, d);
    return ok({ id: d.id });
  }
}

export class EditarClassificacao {
  constructor(private readonly deps: { repo: Repo }) {}
  async execute(ctx: ContextoCaso, e: { id: string; nome?: string; cor?: CorClassificacao; descricao?: string | null }): Promise<Result<void>> {
    const atual = await this.deps.repo.obterPorId(e.id);
    if (!atual) return fail(erroDe('nao_encontrado', 'Tag ou setor nao encontrado'));
    const r = atual.editar(e);
    if (!r.ok) return r;
    const d = r.valor.paraDados();
    const mesmo = await this.deps.repo.buscarPorNome(d.tipo, d.nome);
    if (mesmo && mesmo.id !== d.id) return fail(erroDe('conflito', `Ja existe ${d.tipo} com este nome`, 'nome'));
    await this.deps.repo.atualizar(r.valor);
    await ctx.efeitos.auditar('classificacao.editar', 'cadastros_classificacoes', d.id, atual.paraDados(), d);
    return okVazio();
  }
}

export class ExcluirClassificacao {
  constructor(private readonly deps: { repo: Repo }) {}
  async execute(ctx: ContextoCaso, e: { id: string }): Promise<Result<void>> {
    const atual = await this.deps.repo.obterPorId(e.id);
    if (!atual) return fail(erroDe('nao_encontrado', 'Tag ou setor nao encontrado'));
    const uso = await this.deps.repo.emUso(e.id);
    if (uso > 0) return fail(erroDe('conflito', `Em uso por ${uso} parceiro(s): remova antes de excluir`, undefined, { em_uso: uso }));
    await this.deps.repo.excluir(e.id);
    await ctx.efeitos.auditar('classificacao.excluir', 'cadastros_classificacoes', e.id, atual.paraDados());
    return okVazio();
  }
}
