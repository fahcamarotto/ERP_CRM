/** Rotas REST de Tags e setores (M1.4). */
import { esquemaErro, requer, type FastifyInstance } from '@erp/api/sdk';
import { naTransacao } from '../borda.ts';
import { exigirOk } from '../compartilhado/result.ts';
import { propsClassificacao, uuid } from '../esquemas.ts';
import type { CorClassificacao, TipoClassificacao } from './model/classificacao.ts';
import { listarClassificacoes } from './query/classificacoes.ts';

const tags = ['cadastros'];
const erros = { 400: esquemaErro, 404: esquemaErro, 409: esquemaErro };
const paramId = { type: 'object', required: ['id'], properties: { id: uuid } } as const;
type Corpo = { tipo: TipoClassificacao; nome: string; cor?: CorClassificacao; descricao?: string | null };

export function rotasClassificacao(app: FastifyInstance): void {
  app.get<{ Querystring: { tipo?: 'tag' | 'setor' } }>('/classificacoes', {
    preHandler: requer('cadastros.ver'),
    schema: { tags, summary: 'Lista tags e setores com contagem de uso', querystring: { type: 'object', properties: { tipo: { type: 'string', enum: ['tag', 'setor'] } } } },
  }, (req) => naTransacao(req, (_, __, c) => listarClassificacoes(c, req.query.tipo)));

  app.post<{ Body: Corpo }>('/classificacoes', {
    preHandler: requer('cadastros.criar'),
    schema: { tags, summary: 'Cria tag ou setor', body: { type: 'object', additionalProperties: false, required: ['tipo', 'nome'], properties: propsClassificacao }, response: erros },
  }, async (req, reply) => reply.code(201).send(await naTransacao(req, async (casos, ctx) => exigirOk(await casos.criarClassificacao.execute(ctx, req.body)))));

  app.patch<{ Params: { id: string }; Body: Omit<Partial<Corpo>, 'tipo'> }>('/classificacoes/:id', {
    preHandler: requer('cadastros.editar'),
    schema: {
      tags, summary: 'Edita tag ou setor', params: paramId, response: erros,
      body: { type: 'object', additionalProperties: false, properties: { nome: propsClassificacao.nome, cor: propsClassificacao.cor, descricao: propsClassificacao.descricao } },
    },
  }, async (req, reply) => {
    await naTransacao(req, async (casos, ctx) => exigirOk(await casos.editarClassificacao.execute(ctx, { ...req.body, id: req.params.id })));
    return reply.code(204).send();
  });

  app.delete<{ Params: { id: string } }>('/classificacoes/:id', {
    preHandler: requer('cadastros.excluir'),
    schema: { tags, summary: 'Exclui tag ou setor sem uso', params: paramId, response: erros },
  }, async (req, reply) => {
    await naTransacao(req, async (casos, ctx) => exigirOk(await casos.excluirClassificacao.execute(ctx, { id: req.params.id })));
    return reply.code(204).send();
  });
}
