/** Adaptador Postgres das portas de Classificacao. */
import type pg from 'pg';
import { Classificacao, type ClassificacaoDados, type TipoClassificacao } from '../model/classificacao.ts';
import type { ContarUsoClassificacao, GravarClassificacao, ObterClassificacao } from '../model/portas.ts';

const COLUNAS = 'id, tipo, nome, cor, descricao';

export class ClassificacaoRepoPg implements ObterClassificacao, GravarClassificacao, ContarUsoClassificacao {
  constructor(private readonly c: pg.PoolClient) {}

  async obterPorId(id: string) {
    const r = await this.c.query(`SELECT ${COLUNAS} FROM cadastros_classificacoes WHERE id = $1 AND deleted_at IS NULL`, [id]);
    return r.rows[0] ? Classificacao.reidratar(r.rows[0] as ClassificacaoDados) : null;
  }

  async buscarPorNome(tipo: TipoClassificacao, nome: string) {
    const r = await this.c.query(`SELECT ${COLUNAS} FROM cadastros_classificacoes WHERE tipo = $1 AND lower(nome) = lower($2) AND deleted_at IS NULL`, [tipo, nome]);
    return r.rows[0] ? Classificacao.reidratar(r.rows[0] as ClassificacaoDados) : null;
  }

  async inserir(cl: Classificacao) {
    const d = cl.paraDados();
    await this.c.query(
      'INSERT INTO cadastros_classificacoes (id, tipo, nome, cor, descricao, creator_id) VALUES ($1, $2, $3, $4, $5, nucleo_usuario_atual())',
      [d.id, d.tipo, d.nome, d.cor, d.descricao],
    );
  }

  async atualizar(cl: Classificacao) {
    const d = cl.paraDados();
    await this.c.query('UPDATE cadastros_classificacoes SET nome = $2, cor = $3, descricao = $4 WHERE id = $1 AND deleted_at IS NULL', [d.id, d.nome, d.cor, d.descricao]);
  }

  async excluir(id: string) {
    await this.c.query('UPDATE cadastros_classificacoes SET deleted_at = now() WHERE id = $1 AND deleted_at IS NULL', [id]);
  }

  async emUso(id: string) {
    const r = await this.c.query(
      `SELECT (SELECT count(*) FROM cadastros_parceiros WHERE setor_id = $1 AND deleted_at IS NULL)
            + (SELECT count(*) FROM cadastros_parceiro_tags t JOIN cadastros_parceiros p ON p.id = t.parceiro_id AND p.deleted_at IS NULL
               WHERE t.tag_id = $1 AND t.deleted_at IS NULL) AS n`,
      [id],
    );
    return Number(r.rows[0].n);
  }
}
