/** Entidade Classificacao (M1.4): tag ou setor configuravel, com cor por token do tema. Imutavel. */
import { randomUUID } from 'node:crypto';
import { erroDe, fail, ok, type ErroDominio, type Result } from '../../compartilhado/result.ts';

export type TipoClassificacao = 'tag' | 'setor';
/** Cores permitidas: nomes de token de apps/web/src/estilos/tokens.css (nunca hex). */
export const CORES = ['acento', 'roxo', 'azul', 'ciano', 'laranja', 'dourado', 'sucesso', 'perigo'] as const;
export type CorClassificacao = (typeof CORES)[number];

export interface ClassificacaoDados {
  id: string;
  tipo: TipoClassificacao;
  nome: string;
  cor: CorClassificacao;
  descricao: string | null;
}

function validar(d: ClassificacaoDados): ErroDominio[] {
  const e: ErroDominio[] = [];
  if (d.tipo !== 'tag' && d.tipo !== 'setor') e.push(erroDe('tipo_invalido', 'Tipo deve ser tag ou setor', 'tipo'));
  if (d.nome.length < 1 || d.nome.length > 60) e.push(erroDe('nome_invalido', 'Nome deve ter de 1 a 60 caracteres', 'nome'));
  if (!CORES.includes(d.cor)) e.push(erroDe('cor_invalida', `Cor deve ser um token: ${CORES.join(', ')}`, 'cor'));
  return e;
}

export class Classificacao {
  private constructor(private readonly d: ClassificacaoDados) {}

  static tryCreate(e: { tipo: TipoClassificacao; nome: string; cor?: CorClassificacao; descricao?: string | null }, id: string = randomUUID()): Result<Classificacao> {
    const d: ClassificacaoDados = { id, tipo: e.tipo, nome: (e.nome ?? '').trim(), cor: e.cor ?? 'acento', descricao: (e.descricao ?? '').trim() || null };
    const erros = validar(d);
    return erros.length ? fail(...erros) : ok(new Classificacao(d));
  }

  static create(e: Parameters<typeof Classificacao.tryCreate>[0], id?: string): Classificacao {
    const r = Classificacao.tryCreate(e, id);
    if (!r.ok) throw new Error(r.erros.map((x) => x.mensagem).join('; '));
    return r.valor;
  }

  static reidratar(d: ClassificacaoDados): Classificacao {
    return new Classificacao({ ...d });
  }

  get id(): string { return this.d.id; }

  editar(e: { nome?: string; cor?: CorClassificacao; descricao?: string | null }): Result<Classificacao> {
    const n: ClassificacaoDados = {
      ...this.d,
      nome: e.nome !== undefined ? e.nome.trim() : this.d.nome,
      cor: e.cor ?? this.d.cor,
      descricao: e.descricao !== undefined ? (e.descricao ?? '').trim() || null : this.d.descricao,
    };
    const erros = validar(n);
    return erros.length ? fail(...erros) : ok(new Classificacao(n));
  }

  paraDados(): ClassificacaoDados {
    return { ...this.d };
  }
}
