/** Portas do repositorio de Classificacao (tags e setores). */
import type { Classificacao, TipoClassificacao } from './classificacao.ts';

export interface ObterClassificacao {
  obterPorId(id: string): Promise<Classificacao | null>;
  /** Mesmo nome (sem diferenciar maiusculas) e tipo no workspace. */
  buscarPorNome(tipo: TipoClassificacao, nome: string): Promise<Classificacao | null>;
}

export interface GravarClassificacao {
  inserir(c: Classificacao): Promise<void>;
  atualizar(c: Classificacao): Promise<void>;
  excluir(id: string): Promise<void>;
}

export interface ContarUsoClassificacao {
  /** Quantos parceiros ativos usam a tag ou o setor. */
  emUso(id: string): Promise<number>;
}
