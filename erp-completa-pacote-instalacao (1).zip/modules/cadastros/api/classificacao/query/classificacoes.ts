/** Consulta de Tags e setores com contagem de uso. */
import type pg from 'pg';

export async function listarClassificacoes(c: pg.PoolClient, tipo?: 'tag' | 'setor') {
  const r = await c.query(
    `SELECT cl.id, cl.tipo, cl.nome, cl.cor, cl.descricao, cl.created_at, cl.updated_at,
       CASE WHEN cl.tipo = 'setor'
         THEN (SELECT count(*) FROM cadastros_parceiros p WHERE p.setor_id = cl.id AND p.deleted_at IS NULL)
         ELSE (SELECT count(*) FROM cadastros_parceiro_tags t JOIN cadastros_parceiros p ON p.id = t.parceiro_id AND p.deleted_at IS NULL
               WHERE t.tag_id = cl.id AND t.deleted_at IS NULL) END::int AS em_uso
     FROM cadastros_classificacoes cl WHERE cl.deleted_at IS NULL AND ($1::text IS NULL OR cl.tipo = $1)
     ORDER BY cl.tipo, lower(cl.nome)`,
    [tipo ?? null],
  );
  return r.rows;
}
