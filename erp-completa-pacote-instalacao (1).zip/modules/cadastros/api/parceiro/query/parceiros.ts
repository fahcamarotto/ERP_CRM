/**
 * Consultas de leitura do Parceiro (CQRS): SQL direto devolvendo DTO, sem passar pela entidade.
 * RLS restringe ao workspace da sessao.
 */
import type pg from 'pg';
import { decodificarCursor, pagina } from '../../compartilhado/cursor.ts';

export type PapelParceiro = 'cliente' | 'fornecedor' | 'contato' | 'empresa' | 'pessoa';

export interface FiltroParceiros {
  papel?: PapelParceiro;
  busca?: string;
  estado?: 'ativo' | 'arquivado' | 'todos';
  parent_id?: string;
  tag_id?: string;
  setor_id?: string;
  limite?: number;
  cursor?: string;
}

/** Colunas do DTO de lista (ParceiroResumoDTO). */
const RESUMO = `p.id, p.tipo, p.nome, p.nome_fantasia, p.documento, p.email::text AS email, p.telefone, p.parent_id,
  pai.nome AS empresa_nome, p.cargo, p.setor_id, s.nome AS setor_nome, p.origem, p.ranking_cliente, p.ranking_fornecedor,
  p.e_cliente, p.e_fornecedor, p.estado, p.created_at, p.updated_at,
  coalesce((SELECT json_agg(json_build_object('id', c.id, 'nome', c.nome, 'cor', c.cor) ORDER BY c.nome)
            FROM cadastros_parceiro_tags pt JOIN cadastros_classificacoes c ON c.id = pt.tag_id AND c.deleted_at IS NULL
            WHERE pt.parceiro_id = p.id AND pt.deleted_at IS NULL), '[]') AS tags`;

const JUNCOES = `FROM cadastros_parceiros p
  LEFT JOIN cadastros_parceiros pai ON pai.id = p.parent_id AND pai.deleted_at IS NULL
  LEFT JOIN cadastros_classificacoes s ON s.id = p.setor_id AND s.deleted_at IS NULL`;

/** Mais novos primeiro: lead que acabou de chegar aparece no topo de Clientes. */
export async function listarParceiros(c: pg.PoolClient, f: FiltroParceiros) {
  const lim = Math.min(Math.max(f.limite ?? 50, 1), 200);
  const cur = decodificarCursor(f.cursor);
  const r = await c.query(
    `SELECT ${RESUMO} ${JUNCOES}
     WHERE p.deleted_at IS NULL
       AND ($1::text IS NULL OR ($1 = 'cliente' AND p.e_cliente) OR ($1 = 'fornecedor' AND p.e_fornecedor)
            OR ($1 = 'contato' AND p.tipo = 'pessoa') OR ($1 = 'empresa' AND p.tipo = 'empresa') OR ($1 = 'pessoa' AND p.tipo = 'pessoa'))
       AND ($2::text IS NULL OR p.nome ILIKE '%' || $2 || '%' OR p.nome_fantasia ILIKE '%' || $2 || '%'
            OR p.documento LIKE '%' || regexp_replace($2, '\\D', '', 'g') || '%' AND regexp_replace($2, '\\D', '', 'g') <> ''
            OR p.email::text ILIKE '%' || $2 || '%' OR p.telefone LIKE '%' || regexp_replace($2, '[^0-9+]', '', 'g') || '%' AND regexp_replace($2, '[^0-9]', '', 'g') <> '')
       AND ($3::text = 'todos' OR p.estado = $3)
       AND ($4::uuid IS NULL OR p.parent_id = $4)
       AND ($5::uuid IS NULL OR EXISTS (SELECT 1 FROM cadastros_parceiro_tags t WHERE t.parceiro_id = p.id AND t.tag_id = $5 AND t.deleted_at IS NULL))
       AND ($6::uuid IS NULL OR p.setor_id = $6)
       AND ($7::timestamptz IS NULL OR (p.created_at, p.id) < ($7::timestamptz, $8::uuid))
     ORDER BY p.created_at DESC, p.id DESC LIMIT $9`,
    [f.papel ?? null, f.busca?.trim() || null, f.estado ?? 'ativo', f.parent_id ?? null, f.tag_id ?? null, f.setor_id ?? null,
      cur?.[0] ?? null, cur?.[1] ?? null, lim + 1],
  );
  return pagina(r.rows, lim);
}

/** Ficha do parceiro (M1.7): dados, empresa, setor, tags, enderecos, contas, contatos e projetos. */
export async function obterFichaParceiro(c: pg.PoolClient, id: string) {
  const p = (await c.query(`SELECT ${RESUMO}, p.observacoes, p.extras ${JUNCOES} WHERE p.id = $1 AND p.deleted_at IS NULL`, [id])).rows[0];
  if (!p) return null;
  const [enderecos, contas, contatos, projetos] = await Promise.all([
    c.query(`SELECT id, tipo, cep, logradouro, numero, complemento, bairro, cidade, uf, pais FROM cadastros_enderecos
             WHERE parceiro_id = $1 AND deleted_at IS NULL ORDER BY tipo = 'principal' DESC, created_at`, [id]),
    c.query(`SELECT id, banco_codigo, banco_nome, agencia, conta, tipo, titular, pix_chave, principal FROM cadastros_contas_bancarias
             WHERE parceiro_id = $1 AND deleted_at IS NULL ORDER BY principal DESC, created_at`, [id]),
    c.query(`SELECT id, nome, cargo, email::text AS email, telefone, estado FROM cadastros_parceiros
             WHERE parent_id = $1 AND deleted_at IS NULL ORDER BY nome`, [id]),
    c.query(`SELECT id, nome, estado, prazo, orcamento, moeda FROM cadastros_projetos
             WHERE parceiro_id = $1 AND deleted_at IS NULL ORDER BY created_at DESC`, [id]),
  ]);
  return { ...p, enderecos: enderecos.rows, contas_bancarias: contas.rows, contatos: contatos.rows, projetos: projetos.rows };
}

/**
 * Suspeitas de duplicidade (apoio ao MesclarDuplicados): grupos de parceiros ativos com o mesmo
 * e-mail, telefone ou nome normalizado.
 */
export async function listarDuplicados(c: pg.PoolClient) {
  const r = await c.query(
    `WITH base AS (
       SELECT id, tipo, nome, email::text AS email, telefone, created_at,
              lower(regexp_replace(unaccent_nome, '\\s+', ' ', 'g')) AS nome_norm
       FROM (SELECT *, translate(nome, 'áàâãäéèêëíìîïóòôõöúùûüçÁÀÂÃÄÉÈÊËÍÌÎÏÓÒÔÕÖÚÙÛÜÇ', 'aaaaaeeeeiiiiooooouuuucAAAAAEEEEIIIIOOOOOUUUUC') AS unaccent_nome
             FROM cadastros_parceiros WHERE deleted_at IS NULL AND estado = 'ativo') x
     ), chaves AS (
       SELECT 'email' AS criterio, email AS chave, tipo FROM base WHERE email IS NOT NULL GROUP BY email, tipo HAVING count(*) > 1
       UNION ALL SELECT 'telefone', telefone, tipo FROM base WHERE telefone IS NOT NULL GROUP BY telefone, tipo HAVING count(*) > 1
       UNION ALL SELECT 'nome', nome_norm, tipo FROM base GROUP BY nome_norm, tipo HAVING count(*) > 1
     )
     SELECT k.criterio, k.chave, k.tipo,
            json_agg(json_build_object('id', b.id, 'nome', b.nome, 'email', b.email, 'telefone', b.telefone, 'created_at', b.created_at) ORDER BY b.created_at) AS parceiros
     FROM chaves k JOIN base b ON b.tipo = k.tipo AND (
       (k.criterio = 'email' AND b.email = k.chave) OR (k.criterio = 'telefone' AND b.telefone = k.chave) OR (k.criterio = 'nome' AND b.nome_norm = k.chave))
     GROUP BY k.criterio, k.chave, k.tipo ORDER BY k.criterio, k.chave LIMIT 100`,
  );
  return r.rows;
}
