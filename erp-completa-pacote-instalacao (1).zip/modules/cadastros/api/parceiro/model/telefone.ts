/**
 * Objeto de valor Telefone no formato E.164 (`+5511987654321`). Numero brasileiro sem DDI
 * (10 ou 11 digitos) recebe +55. Imutavel.
 */
import { erroDe, fail, ok, type Result } from '../../compartilhado/result.ts';

export class Telefone {
  private constructor(readonly e164: string) {}

  static tryCreate(bruto: string): Result<Telefone> {
    const texto = String(bruto ?? '').trim();
    let d = texto.replace(/\D/g, '');
    if (!texto.startsWith('+')) {
      if (d.startsWith('00')) d = d.slice(2);
      else if (d.length === 10 || d.length === 11) d = `55${d}`;
    }
    if (!/^[1-9]\d{7,14}$/.test(d)) return fail(erroDe('telefone_invalido', 'Telefone invalido (use o formato E.164, ex.: +5511987654321)', 'telefone'));
    return ok(new Telefone(`+${d}`));
  }

  static create(bruto: string): Telefone {
    const r = Telefone.tryCreate(bruto);
    if (!r.ok) throw new Error(r.erros[0]!.mensagem);
    return r.valor;
  }
}
