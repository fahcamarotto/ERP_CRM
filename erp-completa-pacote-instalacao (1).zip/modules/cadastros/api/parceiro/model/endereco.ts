/** Entidade Endereco do parceiro (M1.2). Varios por parceiro. Imutavel. */
import { randomUUID } from 'node:crypto';
import { erroDe, fail, ok, type ErroDominio, type Result } from '../../compartilhado/result.ts';

export type TipoEndereco = 'principal' | 'cobranca' | 'entrega' | 'outro';

export interface DadosEndereco {
  parceiro_id: string;
  tipo?: TipoEndereco;
  cep?: string | null;
  logradouro: string;
  numero?: string | null;
  complemento?: string | null;
  bairro?: string | null;
  cidade: string;
  uf?: string | null;
  pais?: string | null;
}

export interface EnderecoDados extends Required<Omit<DadosEndereco, 'tipo' | 'pais'>> {
  id: string;
  tipo: TipoEndereco;
  pais: string;
}

const TIPOS: TipoEndereco[] = ['principal', 'cobranca', 'entrega', 'outro'];
const t = (v?: string | null) => (v ?? '').trim() || null;

export class Endereco {
  private constructor(readonly dados: Readonly<EnderecoDados>) {}

  static tryCreate(d: DadosEndereco, id: string = randomUUID()): Result<Endereco> {
    const erros: ErroDominio[] = [];
    const cep = t(d.cep)?.replace(/\D/g, '') ?? null;
    const uf = t(d.uf)?.toUpperCase() ?? null;
    const pais = (t(d.pais) ?? 'BR').toUpperCase();
    const tipo = d.tipo ?? 'principal';
    if (!TIPOS.includes(tipo)) erros.push(erroDe('tipo_invalido', 'Tipo de endereco invalido', 'tipo'));
    if (cep !== null && !/^\d{8}$/.test(cep)) erros.push(erroDe('cep_invalido', 'CEP deve ter 8 digitos', 'cep'));
    if (uf !== null && !/^[A-Z]{2}$/.test(uf)) erros.push(erroDe('uf_invalida', 'UF deve ter 2 letras', 'uf'));
    if (!/^[A-Z]{2}$/.test(pais)) erros.push(erroDe('pais_invalido', 'Pais em ISO 3166 de 2 letras', 'pais'));
    if (!t(d.logradouro)) erros.push(erroDe('obrigatorio', 'Logradouro obrigatorio', 'logradouro'));
    if (!t(d.cidade)) erros.push(erroDe('obrigatorio', 'Cidade obrigatoria', 'cidade'));
    if (erros.length) return fail(...erros);
    return ok(new Endereco({
      id, parceiro_id: d.parceiro_id, tipo, cep, logradouro: t(d.logradouro)!, numero: t(d.numero), complemento: t(d.complemento),
      bairro: t(d.bairro), cidade: t(d.cidade)!, uf, pais,
    }));
  }

  static create(d: DadosEndereco, id?: string): Endereco {
    const r = Endereco.tryCreate(d, id);
    if (!r.ok) throw new Error(r.erros.map((e) => e.mensagem).join('; '));
    return r.valor;
  }
}
