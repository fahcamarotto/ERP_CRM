/**
 * Entidade Parceiro (M1.1): registro unico para pessoa e empresa. Cliente, fornecedor e contato
 * sao papeis do mesmo registro (flags e_cliente, e_fornecedor e parent_id). Imutavel: toda
 * alteracao devolve um clone novo.
 */
import { randomUUID } from 'node:crypto';
import { combinar, erroDe, fail, ok, type ErroDominio, type Result } from '../../compartilhado/result.ts';
import { Documento } from './documento.ts';
import { Email } from './email.ts';
import { Telefone } from './telefone.ts';

export type TipoParceiro = 'pessoa' | 'empresa';
export type EstadoParceiro = 'ativo' | 'arquivado';

export interface ParceiroProps {
  id: string;
  tipo: TipoParceiro;
  nome: string;
  nomeFantasia: string | null;
  documento: Documento | null;
  email: Email | null;
  telefone: Telefone | null;
  parentId: string | null;
  cargo: string | null;
  setorId: string | null;
  tagIds: string[];
  origem: string | null;
  rankingCliente: number;
  rankingFornecedor: number;
  eCliente: boolean;
  eFornecedor: boolean;
  estado: EstadoParceiro;
  observacoes: string | null;
  extras: Record<string, unknown>;
  mescladoEmId: string | null;
}

/** Entrada crua (API, CSV, webhook): strings sem validar. */
export interface DadosParceiro {
  tipo: TipoParceiro;
  nome: string;
  nome_fantasia?: string | null;
  documento?: string | null;
  email?: string | null;
  telefone?: string | null;
  parent_id?: string | null;
  cargo?: string | null;
  setor_id?: string | null;
  tag_ids?: string[];
  origem?: string | null;
  ranking_cliente?: number;
  ranking_fornecedor?: number;
  e_cliente?: boolean;
  e_fornecedor?: boolean;
  observacoes?: string | null;
  extras?: Record<string, unknown>;
}

const limpo = (v: string | null | undefined): string | null => {
  const t = (v ?? '').trim();
  return t ? t : null;
};

function opcional<T>(v: string | null | undefined, criar: (x: string) => Result<T>): Result<T | null> {
  const t = limpo(v);
  return t === null ? ok(null) : criar(t);
}

function validarRegras(p: ParceiroProps): ErroDominio[] {
  const erros: ErroDominio[] = [];
  if (p.tipo !== 'pessoa' && p.tipo !== 'empresa') erros.push(erroDe('tipo_invalido', 'Tipo deve ser pessoa ou empresa', 'tipo'));
  if (p.nome.length < 2 || p.nome.length > 200) erros.push(erroDe('nome_invalido', 'Nome deve ter de 2 a 200 caracteres', 'nome'));
  if (p.documento && p.tipo === 'pessoa' && p.documento.tipo !== 'cpf') erros.push(erroDe('documento_invalido', 'Pessoa usa CPF', 'documento'));
  if (p.documento && p.tipo === 'empresa' && p.documento.tipo !== 'cnpj') erros.push(erroDe('documento_invalido', 'Empresa usa CNPJ', 'documento'));
  if (p.parentId && p.tipo !== 'pessoa') erros.push(erroDe('parent_invalido', 'So pessoa pode ser contato de uma empresa', 'parent_id'));
  if (p.parentId && p.parentId === p.id) erros.push(erroDe('parent_invalido', 'Parceiro nao pode ser contato de si mesmo', 'parent_id'));
  for (const [campo, v] of [['ranking_cliente', p.rankingCliente], ['ranking_fornecedor', p.rankingFornecedor]] as const) {
    if (!Number.isInteger(v) || v < 0 || v > 5) erros.push(erroDe('ranking_invalido', 'Ranking vai de 0 a 5', campo));
  }
  return erros;
}

export class Parceiro {
  private constructor(private readonly p: ParceiroProps) {}

  /** Cria parceiro novo a partir da entrada crua. Erro e valor. */
  static tryCreate(d: DadosParceiro, id: string = randomUUID()): Result<Parceiro> {
    const vos = combinar(
      opcional(d.documento, Documento.tryCreate),
      opcional(d.email, Email.tryCreate),
      opcional(d.telefone, Telefone.tryCreate),
    );
    if (!vos.ok) return fail(...vos.erros);
    const [documento, email, telefone] = vos.valor;
    const props: ParceiroProps = {
      id,
      tipo: d.tipo,
      nome: (d.nome ?? '').trim(),
      nomeFantasia: limpo(d.nome_fantasia),
      documento, email, telefone,
      parentId: limpo(d.parent_id),
      cargo: limpo(d.cargo),
      setorId: limpo(d.setor_id),
      tagIds: [...new Set(d.tag_ids ?? [])],
      origem: limpo(d.origem),
      rankingCliente: d.ranking_cliente ?? 0,
      rankingFornecedor: d.ranking_fornecedor ?? 0,
      eCliente: d.e_cliente ?? false,
      eFornecedor: d.e_fornecedor ?? false,
      estado: 'ativo',
      observacoes: limpo(d.observacoes),
      extras: d.extras ?? {},
      mescladoEmId: null,
    };
    const erros = validarRegras(props);
    return erros.length ? fail(...erros) : ok(new Parceiro(props));
  }

  static create(d: DadosParceiro, id?: string): Parceiro {
    const r = Parceiro.tryCreate(d, id);
    if (!r.ok) throw new Error(r.erros.map((e) => e.mensagem).join('; '));
    return r.valor;
  }

  /** Reidrata do repositorio (dado ja validado na gravacao). */
  static reidratar(props: ParceiroProps): Parceiro {
    return new Parceiro({ ...props, tagIds: [...props.tagIds], extras: { ...props.extras } });
  }

  get id(): string { return this.p.id; }
  get tipo(): TipoParceiro { return this.p.tipo; }
  get estado(): EstadoParceiro { return this.p.estado; }
  get parentId(): string | null { return this.p.parentId; }
  get props(): Readonly<ParceiroProps> { return this.p; }

  /** Edicao parcial: devolve clone validado. Parceiro arquivado nao edita (reativar antes). */
  editar(d: Partial<DadosParceiro>): Result<Parceiro> {
    if (this.p.estado === 'arquivado') return fail(erroDe('transicao_invalida', 'Parceiro arquivado: reative antes de editar'));
    const tem = (k: keyof DadosParceiro) => Object.prototype.hasOwnProperty.call(d, k) && d[k] !== undefined;
    const vos = combinar(
      tem('documento') ? opcional(d.documento, Documento.tryCreate) : ok(this.p.documento),
      tem('email') ? opcional(d.email, Email.tryCreate) : ok(this.p.email),
      tem('telefone') ? opcional(d.telefone, Telefone.tryCreate) : ok(this.p.telefone),
    );
    if (!vos.ok) return fail(...vos.erros);
    const [documento, email, telefone] = vos.valor;
    const novo: ParceiroProps = {
      ...this.p,
      tipo: tem('tipo') ? d.tipo! : this.p.tipo,
      nome: tem('nome') ? (d.nome ?? '').trim() : this.p.nome,
      nomeFantasia: tem('nome_fantasia') ? limpo(d.nome_fantasia) : this.p.nomeFantasia,
      documento, email, telefone,
      parentId: tem('parent_id') ? limpo(d.parent_id) : this.p.parentId,
      cargo: tem('cargo') ? limpo(d.cargo) : this.p.cargo,
      setorId: tem('setor_id') ? limpo(d.setor_id) : this.p.setorId,
      tagIds: tem('tag_ids') ? [...new Set(d.tag_ids!)] : [...this.p.tagIds],
      origem: tem('origem') ? limpo(d.origem) : this.p.origem,
      rankingCliente: tem('ranking_cliente') ? d.ranking_cliente! : this.p.rankingCliente,
      rankingFornecedor: tem('ranking_fornecedor') ? d.ranking_fornecedor! : this.p.rankingFornecedor,
      eCliente: tem('e_cliente') ? d.e_cliente! : this.p.eCliente,
      eFornecedor: tem('e_fornecedor') ? d.e_fornecedor! : this.p.eFornecedor,
      observacoes: tem('observacoes') ? limpo(d.observacoes) : this.p.observacoes,
      extras: tem('extras') ? { ...d.extras } : { ...this.p.extras },
    };
    const erros = validarRegras(novo);
    return erros.length ? fail(...erros) : ok(new Parceiro(novo));
  }

  arquivar(): Result<Parceiro> {
    if (this.p.estado === 'arquivado') return fail(erroDe('transicao_invalida', 'Parceiro ja esta arquivado'));
    return ok(new Parceiro({ ...this.p, estado: 'arquivado' }));
  }

  reativar(): Result<Parceiro> {
    if (this.p.estado === 'ativo') return fail(erroDe('transicao_invalida', 'Parceiro ja esta ativo'));
    return ok(new Parceiro({ ...this.p, estado: 'ativo' }));
  }

  /**
   * Absorve os dados de um duplicado (MesclarDuplicados): campos vazios deste registro recebem
   * os do duplicado, flags e rankings ficam com o maior valor, tags somam.
   */
  absorver(dup: Parceiro): Result<Parceiro> {
    if (dup.id === this.id) return fail(erroDe('mescla_invalida', 'Nao e possivel mesclar o parceiro com ele mesmo'));
    if (dup.tipo !== this.tipo) return fail(erroDe('mescla_invalida', 'So mescla parceiros do mesmo tipo (pessoa com pessoa, empresa com empresa)'));
    const o = dup.props;
    const novo: ParceiroProps = {
      ...this.p,
      nomeFantasia: this.p.nomeFantasia ?? o.nomeFantasia,
      documento: this.p.documento ?? o.documento,
      email: this.p.email ?? o.email,
      telefone: this.p.telefone ?? o.telefone,
      parentId: this.p.parentId ?? (o.parentId === this.id ? null : o.parentId),
      cargo: this.p.cargo ?? o.cargo,
      setorId: this.p.setorId ?? o.setorId,
      tagIds: [...new Set([...this.p.tagIds, ...o.tagIds])],
      origem: this.p.origem ?? o.origem,
      rankingCliente: Math.max(this.p.rankingCliente, o.rankingCliente),
      rankingFornecedor: Math.max(this.p.rankingFornecedor, o.rankingFornecedor),
      eCliente: this.p.eCliente || o.eCliente,
      eFornecedor: this.p.eFornecedor || o.eFornecedor,
      observacoes: [this.p.observacoes, o.observacoes].filter(Boolean).join('\n') || null,
      extras: { ...o.extras, ...this.p.extras },
    };
    const erros = validarRegras(novo);
    return erros.length ? fail(...erros) : ok(new Parceiro(novo));
  }

  /** O duplicado depois da mescla: aponta para o mantido (a exclusao logica fica no repositorio). */
  mescladoEm(destinoId: string): Parceiro {
    return new Parceiro({ ...this.p, documento: null, mescladoEmId: destinoId, estado: 'arquivado' });
  }

  /** Forma plana para persistencia, evento e auditoria. */
  paraDados(): ParceiroDados {
    const p = this.p;
    return {
      id: p.id, tipo: p.tipo, nome: p.nome, nome_fantasia: p.nomeFantasia, documento: p.documento?.numero ?? null,
      email: p.email?.valor ?? null, telefone: p.telefone?.e164 ?? null, parent_id: p.parentId, cargo: p.cargo,
      setor_id: p.setorId, tag_ids: [...p.tagIds], origem: p.origem, ranking_cliente: p.rankingCliente,
      ranking_fornecedor: p.rankingFornecedor, e_cliente: p.eCliente, e_fornecedor: p.eFornecedor, estado: p.estado,
      observacoes: p.observacoes, extras: { ...p.extras }, mesclado_em_id: p.mescladoEmId,
    };
  }

  static deDados(d: ParceiroDados): Parceiro {
    return Parceiro.reidratar({
      id: d.id, tipo: d.tipo, nome: d.nome, nomeFantasia: d.nome_fantasia,
      documento: d.documento ? Documento.create(d.documento) : null,
      email: d.email ? Email.create(d.email) : null,
      telefone: d.telefone ? Telefone.create(d.telefone) : null,
      parentId: d.parent_id, cargo: d.cargo, setorId: d.setor_id, tagIds: d.tag_ids ?? [], origem: d.origem,
      rankingCliente: d.ranking_cliente, rankingFornecedor: d.ranking_fornecedor, eCliente: d.e_cliente,
      eFornecedor: d.e_fornecedor, estado: d.estado, observacoes: d.observacoes, extras: d.extras ?? {},
      mescladoEmId: d.mesclado_em_id,
    });
  }
}

/** DTO de persistencia (colunas da tabela cadastros_parceiros mais tag_ids). */
export interface ParceiroDados {
  id: string;
  tipo: TipoParceiro;
  nome: string;
  nome_fantasia: string | null;
  documento: string | null;
  email: string | null;
  telefone: string | null;
  parent_id: string | null;
  cargo: string | null;
  setor_id: string | null;
  tag_ids: string[];
  origem: string | null;
  ranking_cliente: number;
  ranking_fornecedor: number;
  e_cliente: boolean;
  e_fornecedor: boolean;
  estado: EstadoParceiro;
  observacoes: string | null;
  extras: Record<string, unknown>;
  mesclado_em_id: string | null;
}
