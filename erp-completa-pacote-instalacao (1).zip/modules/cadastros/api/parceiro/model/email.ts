/** Objeto de valor Email: minusculo, sem espacos, formato basico. Imutavel. */
import { erroDe, fail, ok, type Result } from '../../compartilhado/result.ts';

export class Email {
  private constructor(readonly valor: string) {}

  static tryCreate(bruto: string): Result<Email> {
    const v = String(bruto ?? '').trim().toLowerCase();
    if (v.length > 254 || !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v)) return fail(erroDe('email_invalido', 'E-mail invalido', 'email'));
    return ok(new Email(v));
  }

  static create(bruto: string): Email {
    const r = Email.tryCreate(bruto);
    if (!r.ok) throw new Error(r.erros[0]!.mensagem);
    return r.valor;
  }
}
