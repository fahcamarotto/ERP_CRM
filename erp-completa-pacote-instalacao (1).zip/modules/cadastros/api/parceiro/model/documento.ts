/** Objeto de valor Documento: CPF (11 digitos) ou CNPJ (14 digitos) com digito verificador. Imutavel. */
import { erroDe, fail, ok, type Result } from '../../compartilhado/result.ts';

export type TipoDocumento = 'cpf' | 'cnpj';

function dvCpf(d: string): boolean {
  if (/^(\d)\1{10}$/.test(d)) return false;
  const calc = (n: number) => {
    let s = 0;
    for (let i = 0; i < n; i++) s += Number(d[i]) * (n + 1 - i);
    const r = (s * 10) % 11;
    return r === 10 ? 0 : r;
  };
  return calc(9) === Number(d[9]) && calc(10) === Number(d[10]);
}

function dvCnpj(d: string): boolean {
  if (/^(\d)\1{13}$/.test(d)) return false;
  const calc = (n: number) => {
    const pesos = n === 12 ? [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2] : [6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2];
    const s = pesos.reduce((acc, p, i) => acc + p * Number(d[i]), 0);
    const r = s % 11;
    return r < 2 ? 0 : 11 - r;
  };
  return calc(12) === Number(d[12]) && calc(13) === Number(d[13]);
}

export class Documento {
  private constructor(readonly numero: string, readonly tipo: TipoDocumento) {}

  /** Aceita com ou sem mascara. Devolve Result (erro e valor). */
  static tryCreate(bruto: string): Result<Documento> {
    const d = String(bruto ?? '').replace(/\D/g, '');
    if (d.length === 11) return dvCpf(d) ? ok(new Documento(d, 'cpf')) : fail(erroDe('documento_invalido', 'CPF invalido', 'documento'));
    if (d.length === 14) return dvCnpj(d) ? ok(new Documento(d, 'cnpj')) : fail(erroDe('documento_invalido', 'CNPJ invalido', 'documento'));
    return fail(erroDe('documento_invalido', 'Documento deve ser CPF (11 digitos) ou CNPJ (14 digitos)', 'documento'));
  }

  /** Lanca quando invalido. Usar so com dado ja validado (seed, teste, reidratacao do banco). */
  static create(bruto: string): Documento {
    const r = Documento.tryCreate(bruto);
    if (!r.ok) throw new Error(r.erros[0]!.mensagem);
    return r.valor;
  }

  formatado(): string {
    const n = this.numero;
    return this.tipo === 'cpf'
      ? `${n.slice(0, 3)}.${n.slice(3, 6)}.${n.slice(6, 9)}-${n.slice(9)}`
      : `${n.slice(0, 2)}.${n.slice(2, 5)}.${n.slice(5, 8)}/${n.slice(8, 12)}-${n.slice(12)}`;
  }

  igual(outro: Documento | null | undefined): boolean {
    return !!outro && outro.numero === this.numero;
  }
}
