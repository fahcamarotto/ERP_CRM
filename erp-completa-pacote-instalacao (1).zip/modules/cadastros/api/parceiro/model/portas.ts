/**
 * Portas do repositorio do agregado Parceiro, segregadas por operacao (MANUAL secao 5).
 * O caso de uso declara so as que usa; o adaptador Postgres implementa todas; o teste usa a memoria.
 */
import type { ContaBancaria } from './conta-bancaria.ts';
import type { Endereco } from './endereco.ts';
import type { Parceiro } from './parceiro.ts';

export interface ObterParceiro {
  obterPorId(id: string): Promise<Parceiro | null>;
}

export interface BuscarParceiroPorChave {
  buscarPorDocumento(documento: string): Promise<Parceiro | null>;
  /** Primeiro parceiro ativo com o e-mail ou o telefone informado (webhook de landing page, CSV). */
  buscarPorContato(email: string | null, telefone: string | null): Promise<Parceiro | null>;
}

export interface GravarParceiro {
  inserir(p: Parceiro): Promise<void>;
  atualizar(p: Parceiro): Promise<void>;
}

export interface ExcluirParceiro {
  /** Exclusao logica (deleted_at). */
  excluir(id: string): Promise<void>;
}

export interface ReapontarVinculos {
  /** Move contatos, enderecos, contas bancarias e projetos do duplicado para o mantido. Devolve quantos moveu. */
  reapontar(deId: string, paraId: string): Promise<number>;
}

/** Validacao de referencia a classificacao (setor ou tag) do mesmo workspace. */
export interface ConsultarClassificacoes {
  existentes(ids: string[], tipo: 'tag' | 'setor'): Promise<string[]>;
}

/** Identidade do parceiro num canal de mensagem (cadastros_parceiros_identidades). */
export interface IdentidadesCanal {
  /** Trava de transacao por contato (pg_advisory_xact_lock). */
  travar(chave: string): Promise<void>;
  parceiroDaIdentidade(canal: string, idExterno: string): Promise<string | null>;
  /** Insere ou completa (usuario, nome, foto) sem trocar o parceiro ja ligado. */
  gravarIdentidade(i: { parceiro_id: string; canal: 'whatsapp' | 'instagram'; id_externo: string; usuario: string | null; nome: string | null; foto_url: string | null }): Promise<void>;
}

export type RepositorioParceiros = ObterParceiro & BuscarParceiroPorChave & GravarParceiro & ExcluirParceiro & ReapontarVinculos;


export interface GravarEnderecos {
  inserirEndereco(e: Endereco): Promise<void>;
  /** Exclusao logica; false quando nao existe ou e de outro parceiro. */
  removerEndereco(parceiroId: string, id: string): Promise<boolean>;
}

export interface GravarContasBancarias {
  /** Ao inserir conta principal, o adaptador desmarca as outras do mesmo parceiro. */
  inserirConta(c: ContaBancaria): Promise<void>;
  removerConta(parceiroId: string, id: string): Promise<boolean>;
}
