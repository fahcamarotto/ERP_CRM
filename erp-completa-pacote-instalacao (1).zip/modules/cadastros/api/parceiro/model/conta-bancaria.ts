/** Entidade ContaBancaria do parceiro (M1.2). Varias por parceiro, uma principal. Imutavel. */
import { randomUUID } from 'node:crypto';
import { erroDe, fail, ok, type ErroDominio, type Result } from '../../compartilhado/result.ts';

export type TipoConta = 'corrente' | 'poupanca' | 'pagamento';

export interface DadosContaBancaria {
  parceiro_id: string;
  banco_codigo: string;
  banco_nome?: string | null;
  agencia: string;
  conta: string;
  tipo?: TipoConta;
  titular?: string | null;
  pix_chave?: string | null;
  principal?: boolean;
}

export interface ContaBancariaDados {
  id: string;
  parceiro_id: string;
  banco_codigo: string;
  banco_nome: string | null;
  agencia: string;
  conta: string;
  tipo: TipoConta;
  titular: string | null;
  pix_chave: string | null;
  principal: boolean;
}

const t = (v?: string | null) => (v ?? '').trim() || null;

export class ContaBancaria {
  private constructor(readonly dados: Readonly<ContaBancariaDados>) {}

  static tryCreate(d: DadosContaBancaria, id: string = randomUUID()): Result<ContaBancaria> {
    const erros: ErroDominio[] = [];
    const banco = (t(d.banco_codigo) ?? '').padStart(3, '0');
    const agencia = (t(d.agencia) ?? '').replace(/\s/g, '');
    const conta = (t(d.conta) ?? '').replace(/\s/g, '');
    const tipo = d.tipo ?? 'corrente';
    if (!/^\d{3}$/.test(banco)) erros.push(erroDe('banco_invalido', 'Codigo do banco deve ter 3 digitos (COMPE)', 'banco_codigo'));
    if (!/^\d{1,6}(-[\dXx])?$/.test(agencia)) erros.push(erroDe('agencia_invalida', 'Agencia invalida', 'agencia'));
    if (!/^\d{1,13}(-[\dXx])?$/.test(conta)) erros.push(erroDe('conta_invalida', 'Conta invalida', 'conta'));
    if (!['corrente', 'poupanca', 'pagamento'].includes(tipo)) erros.push(erroDe('tipo_invalido', 'Tipo de conta invalido', 'tipo'));
    if (erros.length) return fail(...erros);
    return ok(new ContaBancaria({
      id, parceiro_id: d.parceiro_id, banco_codigo: banco, banco_nome: t(d.banco_nome), agencia, conta, tipo,
      titular: t(d.titular), pix_chave: t(d.pix_chave), principal: d.principal ?? false,
    }));
  }

  static create(d: DadosContaBancaria, id?: string): ContaBancaria {
    const r = ContaBancaria.tryCreate(d, id);
    if (!r.ok) throw new Error(r.erros.map((e) => e.mensagem).join('; '));
    return r.valor;
  }
}
