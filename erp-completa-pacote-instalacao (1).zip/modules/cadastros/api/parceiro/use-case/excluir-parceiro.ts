/** Caso de uso ExcluirParceiro: exclusao logica (deleted_at). Exige cadastros.excluir. */
import { erroDe, fail, okVazio, type Result } from '../../compartilhado/result.ts';
import type { ContextoCaso } from '../../compartilhado/efeitos.ts';
import type { ExcluirParceiro as PortaExcluir, ObterParceiro } from '../model/portas.ts';

export class ExcluirParceiro {
  constructor(private readonly deps: { repo: ObterParceiro & PortaExcluir }) {}

  async execute(ctx: ContextoCaso, entrada: { id: string }): Promise<Result<void>> {
    const atual = await this.deps.repo.obterPorId(entrada.id);
    if (!atual) return fail(erroDe('nao_encontrado', 'Parceiro nao encontrado'));
    await this.deps.repo.excluir(atual.id);
    await ctx.efeitos.auditar('parceiro.excluir', 'cadastros_parceiros', atual.id, atual.paraDados(), undefined);
    await ctx.efeitos.publicar('parceiro.arquivado', { id: atual.id, nome: atual.props.nome, excluido: true });
    return okVazio();
  }
}
