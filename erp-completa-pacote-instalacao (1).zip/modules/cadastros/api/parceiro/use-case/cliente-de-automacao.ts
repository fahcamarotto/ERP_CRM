/**
 * Caso de uso AplicarClienteDeAutomacao (reacao a `automacao.cliente_solicitado` do Automacoes, CONTRATOS
 * 7.1.15): o no "cliente" cria ou acha o cliente do contato (mesma regra idempotente do contato de canal) e o
 * marca como cliente; o no "tag" (`so_tags`) so aplica tags a quem ja tem cadastro. Tags vem por nome: a que
 * nao existe e criada; aplicar de novo nao duplica. Cadastros nao escreve em tabela de outro modulo.
 */
import { ok, type Result } from '../../compartilhado/result.ts';
import type { ContextoCaso } from '../../compartilhado/efeitos.ts';
import { Classificacao } from '../../classificacao/model/classificacao.ts';
import type { GravarClassificacao, ObterClassificacao } from '../../classificacao/model/portas.ts';
import type { GravarParceiro, ObterParceiro } from '../model/portas.ts';
import type { CadastrarContatoDeCanal } from './cadastrar-contato-canal.ts';
import { dadosDoEvento } from './regras-referencia.ts';

export interface EntradaClienteAutomacao {
  canal: string;
  contato: string;
  nome?: string | null;
  parceiro_id?: string | null;
  telefone?: string | null;
  usuario?: string | null;
  tags?: string[];
  so_tags?: boolean;
}

export class AplicarClienteDeAutomacao {
  constructor(private readonly deps: {
    cadastrar: Pick<CadastrarContatoDeCanal, 'execute'>;
    repo: ObterParceiro & GravarParceiro;
    classificacoes: ObterClassificacao & GravarClassificacao;
  }) {}

  async execute(ctx: ContextoCaso, e: EntradaClienteAutomacao): Promise<Result<{ parceiro_id: string | null; tags: number; novo: boolean }>> {
    let id = e.parceiro_id && (await this.deps.repo.obterPorId(e.parceiro_id)) ? e.parceiro_id : null;
    let novo = false;
    if (!id) {
      if (e.so_tags) return ok({ parceiro_id: null, tags: 0, novo: false });
      const r = await this.deps.cadastrar.execute(ctx, { canal: e.canal, contato: e.contato, nome: e.nome, telefone: e.telefone, usuario: e.usuario });
      if (!r.ok) return r;
      id = r.valor.parceiro_id;
      novo = r.valor.novo;
    }
    const p = await this.deps.repo.obterPorId(id);
    if (!p) return ok({ parceiro_id: id, tags: 0, novo });
    const tagIds = new Set(p.props.tagIds);
    let novas = 0;
    for (const nome of [...new Set((e.tags ?? []).map((t) => t.trim()).filter((t) => t.length >= 1 && t.length <= 60))]) {
      let tag = await this.deps.classificacoes.buscarPorNome('tag', nome);
      if (!tag) {
        const c = Classificacao.tryCreate({ tipo: 'tag', nome });
        if (!c.ok) continue;
        await this.deps.classificacoes.inserir(c.valor);
        await ctx.efeitos.auditar('classificacao.criar', 'cadastros_classificacoes', c.valor.id, undefined, c.valor.paraDados());
        tag = c.valor;
      }
      if (!tagIds.has(tag.id)) { tagIds.add(tag.id); novas++; }
    }
    const virarCliente = !e.so_tags && !p.props.eCliente;
    if (!novas && !virarCliente) return ok({ parceiro_id: id, tags: 0, novo });
    const ed = p.editar({ tag_ids: [...tagIds], ...(virarCliente ? { e_cliente: true } : {}) });
    if (!ed.ok) return ed;
    await this.deps.repo.atualizar(ed.valor);
    const antes = p.paraDados() as unknown as Record<string, unknown>;
    const depois = ed.valor.paraDados() as unknown as Record<string, unknown>;
    await ctx.efeitos.historico('cadastros_parceiros', id, antes, depois);
    await ctx.efeitos.auditar('parceiro.automacao', 'cadastros_parceiros', id, { tag_ids: antes.tag_ids, e_cliente: antes.e_cliente }, { tag_ids: depois.tag_ids, e_cliente: depois.e_cliente });
    if (!novo) await ctx.efeitos.publicar('cliente.atualizado', { ...dadosDoEvento(ed.valor), campos: [...(novas ? ['tag_ids'] : []), ...(virarCliente ? ['e_cliente'] : [])] });
    return ok({ parceiro_id: id, tags: novas, novo });
  }
}
