/** Casos de uso de M1.2: adicionar e remover endereco e conta bancaria do parceiro. */
import { erroDe, fail, ok, okVazio, type Result } from '../../compartilhado/result.ts';
import type { ContextoCaso } from '../../compartilhado/efeitos.ts';
import { ContaBancaria, type DadosContaBancaria } from '../model/conta-bancaria.ts';
import { Endereco, type DadosEndereco } from '../model/endereco.ts';
import type { GravarContasBancarias, GravarEnderecos, ObterParceiro } from '../model/portas.ts';

type Deps = { repo: ObterParceiro; enderecos: GravarEnderecos; contas: GravarContasBancarias };

async function parceiroAtivo(deps: Deps, id: string): Promise<Result<void>> {
  const p = await deps.repo.obterPorId(id);
  if (!p) return fail(erroDe('nao_encontrado', 'Parceiro nao encontrado'));
  if (p.estado === 'arquivado') return fail(erroDe('transicao_invalida', 'Parceiro arquivado: reative antes de editar'));
  return okVazio();
}

export class AdicionarEndereco {
  constructor(private readonly deps: Deps) {}
  async execute(ctx: ContextoCaso, d: DadosEndereco): Promise<Result<{ id: string }>> {
    const pr = await parceiroAtivo(this.deps, d.parceiro_id);
    if (!pr.ok) return pr;
    const r = Endereco.tryCreate(d);
    if (!r.ok) return r;
    await this.deps.enderecos.inserirEndereco(r.valor);
    await ctx.efeitos.auditar('parceiro.endereco_adicionar', 'cadastros_enderecos', r.valor.dados.id, undefined, r.valor.dados);
    await ctx.efeitos.nota('cadastros_parceiros', d.parceiro_id, `Endereco adicionado: ${r.valor.dados.logradouro}, ${r.valor.dados.cidade}`);
    return ok({ id: r.valor.dados.id });
  }
}

export class RemoverEndereco {
  constructor(private readonly deps: Deps) {}
  async execute(ctx: ContextoCaso, e: { parceiro_id: string; id: string }): Promise<Result<void>> {
    if (!(await this.deps.enderecos.removerEndereco(e.parceiro_id, e.id))) return fail(erroDe('nao_encontrado', 'Endereco nao encontrado'));
    await ctx.efeitos.auditar('parceiro.endereco_remover', 'cadastros_enderecos', e.id);
    return okVazio();
  }
}

export class AdicionarContaBancaria {
  constructor(private readonly deps: Deps) {}
  async execute(ctx: ContextoCaso, d: DadosContaBancaria): Promise<Result<{ id: string }>> {
    const pr = await parceiroAtivo(this.deps, d.parceiro_id);
    if (!pr.ok) return pr;
    const r = ContaBancaria.tryCreate(d);
    if (!r.ok) return r;
    await this.deps.contas.inserirConta(r.valor);
    // Auditoria sem a chave Pix completa: so os 4 ultimos caracteres.
    const { pix_chave, ...resto } = r.valor.dados;
    await ctx.efeitos.auditar('parceiro.conta_adicionar', 'cadastros_contas_bancarias', resto.id, undefined, { ...resto, pix_chave: pix_chave ? `...${pix_chave.slice(-4)}` : null });
    await ctx.efeitos.nota('cadastros_parceiros', d.parceiro_id, `Conta bancaria adicionada: banco ${resto.banco_codigo} agencia ${resto.agencia}`);
    return ok({ id: resto.id });
  }
}

export class RemoverContaBancaria {
  constructor(private readonly deps: Deps) {}
  async execute(ctx: ContextoCaso, e: { parceiro_id: string; id: string }): Promise<Result<void>> {
    if (!(await this.deps.contas.removerConta(e.parceiro_id, e.id))) return fail(erroDe('nao_encontrado', 'Conta bancaria nao encontrada'));
    await ctx.efeitos.auditar('parceiro.conta_remover', 'cadastros_contas_bancarias', e.id);
    return okVazio();
  }
}
