/** Casos de uso ArquivarParceiro e ReativarParceiro (M1.5): mudanca de estado com auditoria e evento. */
import { erroDe, fail, okVazio, type Result } from '../../compartilhado/result.ts';
import type { ContextoCaso } from '../../compartilhado/efeitos.ts';
import type { GravarParceiro, ObterParceiro } from '../model/portas.ts';

export class ArquivarParceiro {
  constructor(private readonly deps: { repo: ObterParceiro & GravarParceiro }) {}

  async execute(ctx: ContextoCaso, entrada: { id: string; reativar?: boolean }): Promise<Result<void>> {
    const atual = await this.deps.repo.obterPorId(entrada.id);
    if (!atual) return fail(erroDe('nao_encontrado', 'Parceiro nao encontrado'));
    const r = entrada.reativar ? atual.reativar() : atual.arquivar();
    if (!r.ok) return r;
    await this.deps.repo.atualizar(r.valor);
    await ctx.efeitos.historico('cadastros_parceiros', atual.id, { estado: atual.estado }, { estado: r.valor.estado });
    await ctx.efeitos.auditar(entrada.reativar ? 'parceiro.reativar' : 'parceiro.arquivar', 'cadastros_parceiros', atual.id, { estado: atual.estado }, { estado: r.valor.estado });
    if (!entrada.reativar) await ctx.efeitos.publicar('parceiro.arquivado', { id: atual.id, nome: atual.props.nome });
    else await ctx.efeitos.publicar('cliente.atualizado', { id: atual.id, nome: atual.props.nome, campos: ['estado'] });
    return okVazio();
  }
}
