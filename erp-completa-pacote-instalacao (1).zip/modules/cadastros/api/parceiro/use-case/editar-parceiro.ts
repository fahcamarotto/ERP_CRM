/** Caso de uso EditarParceiro (M1.5): edicao parcial com historico no chatter e evento cliente.atualizado. */
import { erroDe, fail, okVazio, type Result } from '../../compartilhado/result.ts';
import type { ContextoCaso } from '../../compartilhado/efeitos.ts';
import type { DadosParceiro } from '../model/parceiro.ts';
import type { GravarParceiro } from '../model/portas.ts';
import { conferirReferencias, dadosDoEvento, type DepsReferencia } from './regras-referencia.ts';

export interface DepsEditarParceiro extends DepsReferencia {
  repo: DepsReferencia['repo'] & GravarParceiro;
}

export class EditarParceiro {
  constructor(private readonly deps: DepsEditarParceiro) {}

  async execute(ctx: ContextoCaso, entrada: { id: string } & Partial<DadosParceiro>): Promise<Result<void>> {
    const { id, ...mudancas } = entrada;
    const atual = await this.deps.repo.obterPorId(id);
    if (!atual) return fail(erroDe('nao_encontrado', 'Parceiro nao encontrado'));
    const r = atual.editar(mudancas);
    if (!r.ok) return r;
    const novo = r.valor;
    const erros = await conferirReferencias(this.deps, novo, atual);
    if (erros.length) return fail(...erros);
    const antes = atual.paraDados();
    const depois = novo.paraDados();
    await this.deps.repo.atualizar(novo);
    await ctx.efeitos.historico('cadastros_parceiros', id, antes as unknown as Record<string, unknown>, depois as unknown as Record<string, unknown>);
    await ctx.efeitos.auditar('parceiro.editar', 'cadastros_parceiros', id, antes, depois);
    const campos = Object.keys(depois).filter((k) => JSON.stringify(antes[k as keyof typeof antes]) !== JSON.stringify(depois[k as keyof typeof depois]));
    await ctx.efeitos.publicar('cliente.atualizado', { ...dadosDoEvento(novo), campos });
    return okVazio();
  }
}
