/**
 * Caso de uso CadastrarContatoDeCanal (M1.6, reacao a `contato.desconhecido` do Conversas): todo contato novo
 * de WhatsApp ou Instagram vira cliente com nome, telefone (WhatsApp), @usuario e id da plataforma (Instagram)
 * e foto. Idempotente: casa primeiro pela identidade do canal (id da plataforma), depois pelo telefone E.164;
 * o mesmo contato nunca duplica. Publica `cliente.criado` (cliente novo) e `contato.cadastrado` (Conversas liga
 * a conversa). Cadastros nao escreve em tabela de outro modulo.
 */
import { erroDe, fail, ok, type Result } from '../../compartilhado/result.ts';
import type { ContextoCaso } from '../../compartilhado/efeitos.ts';
import { Parceiro } from '../model/parceiro.ts';
import type { BuscarParceiroPorChave, GravarParceiro, IdentidadesCanal, ObterParceiro } from '../model/portas.ts';
import { Telefone } from '../model/telefone.ts';
import { dadosDoEvento } from './regras-referencia.ts';

export interface EntradaContatoCanal {
  conversa_id?: string | null;
  canal: string;
  contato: string;
  nome?: string | null;
  telefone?: string | null;
  usuario?: string | null;
  foto_url?: string | null;
  mensagem?: string | null;
}

const CANAIS = ['whatsapp', 'instagram'];

export class CadastrarContatoDeCanal {
  constructor(private readonly deps: { repo: ObterParceiro & BuscarParceiroPorChave & GravarParceiro; identidades: IdentidadesCanal }) {}

  async execute(ctx: ContextoCaso, e: EntradaContatoCanal): Promise<Result<{ parceiro_id: string; novo: boolean }>> {
    if (!CANAIS.includes(e.canal)) return fail(erroDe('canal_invalido', 'Canal deve ser whatsapp ou instagram', 'canal'));
    const idExterno = String(e.contato ?? '').trim();
    if (!/^[0-9A-Za-z_.+-]{3,64}$/.test(idExterno)) return fail(erroDe('contato_invalido', 'Id do contato invalido', 'contato'));
    const tel = e.canal === 'whatsapp' ? Telefone.tryCreate(e.telefone ?? idExterno) : null;
    const telefone = tel?.ok ? tel.valor.e164 : null;
    const usuario = (e.usuario ?? '').trim().replace(/^@/, '').slice(0, 100) || null;
    const foto = e.foto_url && /^https?:\/\//.test(e.foto_url) && e.foto_url.length <= 4000 ? e.foto_url : null;
    // Serializa o mesmo contato entre jobs paralelos (historico e webhook ao mesmo tempo).
    await this.deps.identidades.travar(`${e.canal}:${idExterno}`);

    let parceiroId = await this.deps.identidades.parceiroDaIdentidade(e.canal, idExterno);
    let novo = false;
    if (!parceiroId && telefone) parceiroId = (await this.deps.repo.buscarPorContato(null, telefone))?.id ?? null;
    if (!parceiroId) {
      const nome = (e.nome ?? '').trim() || (usuario ? `@${usuario}` : '') || telefone || `Instagram ${idExterno}`;
      const obs = e.canal === 'instagram'
        ? `Contato do Instagram${usuario ? ` @${usuario}` : ''} (id ${idExterno})`
        : `Contato do WhatsApp ${telefone ?? idExterno}`;
      const r = Parceiro.tryCreate({
        tipo: 'pessoa', nome: nome.length < 2 ? `Contato ${nome}` : nome.slice(0, 200), telefone, origem: e.canal, e_cliente: true, observacoes: obs,
      });
      if (!r.ok) return r;
      await this.deps.repo.inserir(r.valor);
      parceiroId = r.valor.id;
      novo = true;
      await ctx.efeitos.auditar('parceiro.criar', 'cadastros_parceiros', parceiroId, undefined, r.valor.paraDados());
      await ctx.efeitos.publicar('cliente.criado', dadosDoEvento(r.valor));
      if (e.mensagem) await ctx.efeitos.nota('cadastros_parceiros', parceiroId, `Primeira mensagem (${e.canal}): ${e.mensagem.slice(0, 2000)}`);
    }
    await this.deps.identidades.gravarIdentidade({ parceiro_id: parceiroId, canal: e.canal as 'whatsapp' | 'instagram', id_externo: idExterno, usuario, nome: (e.nome ?? '').trim().slice(0, 200) || null, foto_url: foto });
    if (e.conversa_id) await ctx.efeitos.publicar('contato.cadastrado', { conversa_id: e.conversa_id, parceiro_id: parceiroId, canal: e.canal, contato: idExterno, novo });
    return ok({ parceiro_id: parceiroId, novo });
  }
}
