/**
 * Caso de uso MesclarDuplicados (M1.5): o parceiro mantido absorve os dados dos duplicados,
 * contatos, enderecos, contas e projetos sao reapontados, e o duplicado sai por exclusao logica
 * com mesclado_em_id. Publica parceiro.mesclado para outros modulos reapontarem as referencias deles.
 */
import { erroDe, fail, okVazio, type Result } from '../../compartilhado/result.ts';
import type { ContextoCaso } from '../../compartilhado/efeitos.ts';
import type { Parceiro } from '../model/parceiro.ts';
import type { ExcluirParceiro, GravarParceiro, ObterParceiro, ReapontarVinculos } from '../model/portas.ts';

export class MesclarDuplicados {
  constructor(private readonly deps: { repo: ObterParceiro & GravarParceiro & ExcluirParceiro & ReapontarVinculos }) {}

  async execute(ctx: ContextoCaso, entrada: { manter_id: string; duplicados_ids: string[] }): Promise<Result<{ movidos: number }>> {
    const ids = [...new Set(entrada.duplicados_ids)].filter((x) => x !== entrada.manter_id);
    if (ids.length === 0) return fail(erroDe('mescla_invalida', 'Informe ao menos um duplicado diferente do mantido', 'duplicados_ids'));
    const inicial = await this.deps.repo.obterPorId(entrada.manter_id);
    if (!inicial) return fail(erroDe('nao_encontrado', 'Parceiro mantido nao encontrado', 'manter_id'));
    let mantido: Parceiro = inicial;
    const antes = mantido.paraDados();
    const duplicados: Parceiro[] = [];
    for (const id of ids) {
      const d = await this.deps.repo.obterPorId(id);
      if (!d) return fail(erroDe('nao_encontrado', `Duplicado ${id} nao encontrado`, 'duplicados_ids'));
      const r: Result<Parceiro> = mantido.absorver(d);
      if (!r.ok) return r;
      mantido = r.valor;
      duplicados.push(d);
    }
    let movidos = 0;
    for (const d of duplicados) {
      // Libera o documento unico do duplicado antes de o mantido herda-lo.
      await this.deps.repo.atualizar(d.mescladoEm(mantido.id));
      await this.deps.repo.excluir(d.id);
      movidos += await this.deps.repo.reapontar(d.id, mantido.id);
    }
    await this.deps.repo.atualizar(mantido);
    const depois = mantido.paraDados();
    await ctx.efeitos.historico('cadastros_parceiros', mantido.id, antes as unknown as Record<string, unknown>, depois as unknown as Record<string, unknown>);
    await ctx.efeitos.nota('cadastros_parceiros', mantido.id, `Mesclado com ${duplicados.map((d) => d.props.nome).join(', ')}`);
    await ctx.efeitos.auditar('parceiro.mesclar', 'cadastros_parceiros', mantido.id, { mantido: antes, duplicados: duplicados.map((d) => d.paraDados()) }, depois);
    await ctx.efeitos.publicar('parceiro.mesclado', { mantido_id: mantido.id, removidos_ids: duplicados.map((d) => d.id) });
    return { ok: true, valor: { movidos } };
  }
}
