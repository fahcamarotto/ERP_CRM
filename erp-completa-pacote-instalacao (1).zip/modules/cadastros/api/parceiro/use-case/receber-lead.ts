/**
 * Caso de uso ReceberLead (M1.6): formulario de landing page cria ou atualiza o parceiro pelo
 * e-mail ou telefone e publica lead.recebido. O Pipeline, quando instalado, reage ao evento
 * (handler `pipeline:ao:lead.recebido`) e abre a oportunidade no pipeline e na etapa da fonte de lead (landing page). Cadastros nao escreve em tabela de outro modulo.
 */
import { erroDe, fail, ok, type Result } from '../../compartilhado/result.ts';
import type { ContextoCaso } from '../../compartilhado/efeitos.ts';
import { Email } from '../model/email.ts';
import { Parceiro, type DadosParceiro } from '../model/parceiro.ts';
import type { BuscarParceiroPorChave, GravarParceiro, ObterParceiro } from '../model/portas.ts';
import { Telefone } from '../model/telefone.ts';
import { dadosDoEvento } from './regras-referencia.ts';

export interface EntradaLead {
  nome?: string;
  email?: string;
  telefone?: string;
  empresa?: string;
  mensagem?: string;
  origem?: string;
  utm_source?: string;
  utm_medium?: string;
  utm_campaign?: string;
  /** Fonte de lead (landing page) de onde veio: a origem vira o nome dela e o destino segue para o Pipeline. */
  fonte?: FonteDoLead | null;
}

/** Leitura da tabela publicada integracoes_fontes_lead (CONTRATOS 7.1.14). */
export interface FonteDoLead {
  id: string;
  nome: string;
  funil_id: string | null;
  etapa_id: string | null;
  tags: string[];
  responsavel_id: string | null;
}

export class ReceberLead {
  constructor(private readonly deps: { repo: ObterParceiro & BuscarParceiroPorChave & GravarParceiro }) {}

  async execute(ctx: ContextoCaso, e: EntradaLead): Promise<Result<{ id: string; novo: boolean }>> {
    const email = e.email ? Email.tryCreate(e.email) : null;
    const tel = e.telefone ? Telefone.tryCreate(e.telefone) : null;
    const emailOk = email?.ok ? email.valor.valor : null;
    const telOk = tel?.ok ? tel.valor.e164 : null;
    if (!emailOk && !telOk) return fail(erroDe('lead_sem_contato', 'Lead precisa de e-mail ou telefone validos'));
    const origem = (e.fonte?.nome ?? e.origem ?? 'landing').slice(0, 60);
    const utm = { source: e.utm_source ?? null, medium: e.utm_medium ?? null, campaign: e.utm_campaign ?? null };
    let parceiro = await this.deps.repo.buscarPorContato(emailOk, telOk);
    let novo = false;
    if (parceiro) {
      const r = parceiro.estado === 'arquivado' ? parceiro.reativar() : ok(parceiro);
      if (!r.ok) return r;
      const mudancas: Partial<DadosParceiro> = { e_cliente: true };
      if (!parceiro.props.email && emailOk) mudancas.email = emailOk;
      if (!parceiro.props.telefone && telOk) mudancas.telefone = telOk;
      const ed = r.valor.editar(mudancas);
      if (!ed.ok) return ed;
      await this.deps.repo.atualizar(ed.valor);
      await ctx.efeitos.historico('cadastros_parceiros', parceiro.id, parceiro.paraDados() as unknown as Record<string, unknown>, ed.valor.paraDados() as unknown as Record<string, unknown>);
      parceiro = ed.valor;
    } else {
      const nome = (e.nome ?? '').trim() || emailOk || telOk!;
      const r = Parceiro.tryCreate({
        tipo: 'pessoa', nome: nome.length < 2 ? `Lead ${nome}` : nome, email: emailOk, telefone: telOk,
        origem, e_cliente: true, observacoes: e.empresa ? `Empresa informada: ${e.empresa}` : null,
      });
      if (!r.ok) return r;
      parceiro = r.valor;
      await this.deps.repo.inserir(parceiro);
      await ctx.efeitos.auditar('parceiro.criar', 'cadastros_parceiros', parceiro.id, undefined, parceiro.paraDados());
      await ctx.efeitos.publicar('cliente.criado', dadosDoEvento(parceiro));
      novo = true;
    }
    if (e.mensagem) await ctx.efeitos.nota('cadastros_parceiros', parceiro.id, `Lead (${origem}): ${e.mensagem.slice(0, 2000)}`);
    await ctx.efeitos.publicar('lead.recebido', {
      parceiro_id: parceiro.id, novo, nome: parceiro.props.nome, email: emailOk, telefone: telOk,
      empresa: e.empresa ?? null, mensagem: e.mensagem ?? null, origem, utm,
      canal: e.fonte ? 'site' : null, fonte_id: e.fonte?.id ?? null, funil_id: e.fonte?.funil_id ?? null, etapa_id: e.fonte?.etapa_id ?? null,
      tags: e.fonte?.tags ?? [], responsavel_id: e.fonte?.responsavel_id ?? null,
    });
    return ok({ id: parceiro.id, novo });
  }
}
