/** Regras de referencia compartilhadas pelos casos de uso do parceiro (contato, setor, tags, documento unico). */
import { erroDe, type ErroDominio } from '../../compartilhado/result.ts';
import type { Parceiro } from '../model/parceiro.ts';
import type { BuscarParceiroPorChave, ConsultarClassificacoes, ObterParceiro } from '../model/portas.ts';

export interface DepsReferencia {
  repo: ObterParceiro & BuscarParceiroPorChave;
  classificacoes: ConsultarClassificacoes;
}

export async function conferirReferencias(deps: DepsReferencia, p: Parceiro, anterior?: Parceiro): Promise<ErroDominio[]> {
  const erros: ErroDominio[] = [];
  const d = p.props;
  if (d.documento && !d.documento.igual(anterior?.props.documento)) {
    const outro = await deps.repo.buscarPorDocumento(d.documento.numero);
    if (outro && outro.id !== p.id) {
      erros.push(erroDe('conflito', `Ja existe parceiro com este documento (${outro.props.nome})`, 'documento', { parceiro_id: outro.id }));
    }
  }
  if (d.parentId && d.parentId !== anterior?.parentId) {
    const pai = await deps.repo.obterPorId(d.parentId);
    if (!pai) erros.push(erroDe('parent_invalido', 'Empresa do contato nao encontrada', 'parent_id'));
    else if (pai.tipo !== 'empresa') erros.push(erroDe('parent_invalido', 'Contato so pode ser ligado a uma empresa', 'parent_id'));
    else if (pai.estado === 'arquivado') erros.push(erroDe('parent_invalido', 'Empresa do contato esta arquivada', 'parent_id'));
  }
  if (d.setorId && d.setorId !== anterior?.props.setorId) {
    const ok = await deps.classificacoes.existentes([d.setorId], 'setor');
    if (!ok.includes(d.setorId)) erros.push(erroDe('setor_invalido', 'Setor nao encontrado', 'setor_id'));
  }
  if (d.tagIds.length) {
    const ok = new Set(await deps.classificacoes.existentes(d.tagIds, 'tag'));
    const faltam = d.tagIds.filter((t) => !ok.has(t));
    if (faltam.length) erros.push(erroDe('tag_invalida', 'Tag nao encontrada', 'tag_ids', { faltam }));
  }
  return erros;
}

/** Dados publicados nos eventos cliente.criado e cliente.atualizado (contrato em docs/CONTRATOS.md 7.2). */
export function dadosDoEvento(p: Parceiro): Record<string, unknown> {
  const d = p.paraDados();
  return {
    id: d.id, tipo: d.tipo, nome: d.nome, documento: d.documento, email: d.email, telefone: d.telefone,
    e_cliente: d.e_cliente, e_fornecedor: d.e_fornecedor, parent_id: d.parent_id, origem: d.origem,
  };
}
