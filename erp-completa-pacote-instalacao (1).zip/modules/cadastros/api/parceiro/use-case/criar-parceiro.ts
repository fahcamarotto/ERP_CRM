/** Caso de uso CriarParceiro (M1.5): valida, grava, audita e publica cliente.criado. */
import { fail, ok, type Result } from '../../compartilhado/result.ts';
import type { ContextoCaso } from '../../compartilhado/efeitos.ts';
import { Parceiro, type DadosParceiro } from '../model/parceiro.ts';
import type { GravarParceiro } from '../model/portas.ts';
import { conferirReferencias, dadosDoEvento, type DepsReferencia } from './regras-referencia.ts';

export interface DepsCriarParceiro extends DepsReferencia {
  repo: DepsReferencia['repo'] & GravarParceiro;
}

export class CriarParceiro {
  constructor(private readonly deps: DepsCriarParceiro) {}

  async execute(ctx: ContextoCaso, entrada: DadosParceiro): Promise<Result<{ id: string }>> {
    const r = Parceiro.tryCreate(entrada);
    if (!r.ok) return r;
    const p = r.valor;
    const erros = await conferirReferencias(this.deps, p);
    if (erros.length) return fail(...erros);
    await this.deps.repo.inserir(p);
    await ctx.efeitos.auditar('parceiro.criar', 'cadastros_parceiros', p.id, undefined, p.paraDados());
    await ctx.efeitos.publicar('cliente.criado', dadosDoEvento(p));
    return ok({ id: p.id });
  }
}
