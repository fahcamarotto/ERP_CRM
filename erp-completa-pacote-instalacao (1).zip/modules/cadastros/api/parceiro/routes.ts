/**
 * Rotas REST do agregado Parceiro (relativas ao prefixo /api/v1/cadastros). Comando passa pelo
 * caso de uso e a resposta vem da consulta (DTO). Clientes e fornecedores tambem saem como @tool em ../tools.ts.
 */
import { esquemaErro, requer, type FastifyInstance } from '@erp/api/sdk';
import { naTransacao, naoEncontrado } from '../borda.ts';
import { exigirOk } from '../compartilhado/result.ts';
import { paginacao, propsConta, propsEndereco, propsParceiro, uuid } from '../esquemas.ts';
import type { DadosContaBancaria } from './model/conta-bancaria.ts';
import type { DadosEndereco } from './model/endereco.ts';
import type { DadosParceiro } from './model/parceiro.ts';
import { listarDuplicados, listarParceiros, obterFichaParceiro, type FiltroParceiros } from './query/parceiros.ts';

const tags = ['cadastros'];
const erros = { 400: esquemaErro, 403: esquemaErro, 404: esquemaErro, 409: esquemaErro };
const paramId = { type: 'object', required: ['id'], properties: { id: uuid } } as const;

export function rotasParceiro(app: FastifyInstance): void {
  app.get<{ Querystring: FiltroParceiros }>('/parceiros', {
    preHandler: requer('cadastros.ver'),
    schema: {
      tags, summary: 'Lista parceiros por papel (cliente, fornecedor, contato, empresa, pessoa) com busca e cursor',
      querystring: { type: 'object', additionalProperties: false, properties: {
        ...paginacao, papel: { type: 'string', enum: ['cliente', 'fornecedor', 'contato', 'empresa', 'pessoa'] },
        estado: { type: 'string', enum: ['ativo', 'arquivado', 'todos'] }, parent_id: uuid, tag_id: uuid, setor_id: uuid,
      } },
    },
  }, (req) => naTransacao(req, (_, __, c) => listarParceiros(c, req.query)));

  app.get('/parceiros-duplicados', {
    preHandler: requer('cadastros.ver'),
    schema: { tags, summary: 'Grupos de parceiros ativos com o mesmo e-mail, telefone ou nome (apoio a mesclagem)' },
  }, (req) => naTransacao(req, (_, __, c) => listarDuplicados(c)));

  app.get<{ Params: { id: string } }>('/parceiros/:id', {
    preHandler: requer('cadastros.ver'),
    schema: { tags, summary: 'Ficha do parceiro: dados, tags, enderecos, contas, contatos e projetos', params: paramId, response: { 404: esquemaErro } },
  }, (req) => naTransacao(req, async (_, __, c) => (await obterFichaParceiro(c, req.params.id)) ?? Promise.reject(naoEncontrado('Parceiro nao encontrado'))));

  app.post<{ Body: DadosParceiro }>('/parceiros', {
    preHandler: requer('cadastros.criar'),
    schema: { tags, summary: 'Cria parceiro (CriarParceiro)', body: { type: 'object', additionalProperties: false, required: ['tipo', 'nome'], properties: propsParceiro }, response: erros },
  }, async (req, reply) => {
    const ficha = await naTransacao(req, async (casos, ctx, c) => {
      const { id } = exigirOk(await casos.criarParceiro.execute(ctx, req.body));
      return obterFichaParceiro(c, id);
    });
    return reply.code(201).send(ficha);
  });

  app.patch<{ Params: { id: string }; Body: Partial<DadosParceiro> }>('/parceiros/:id', {
    preHandler: requer('cadastros.editar'),
    schema: { tags, summary: 'Edita parceiro (EditarParceiro)', params: paramId, body: { type: 'object', additionalProperties: false, properties: propsParceiro }, response: erros },
  }, (req) => naTransacao(req, async (casos, ctx, c) => {
    exigirOk(await casos.editarParceiro.execute(ctx, { ...req.body, id: req.params.id }));
    return obterFichaParceiro(c, req.params.id);
  }));

  for (const acao of ['arquivar', 'reativar'] as const) {
    app.post<{ Params: { id: string } }>(`/parceiros/:id/${acao}`, {
      preHandler: requer('cadastros.editar'),
      schema: { tags, summary: acao === 'arquivar' ? 'Arquiva parceiro (ArquivarParceiro)' : 'Reativa parceiro arquivado', params: paramId, response: erros },
    }, (req) => naTransacao(req, async (casos, ctx, c) => {
      exigirOk(await casos.arquivarParceiro.execute(ctx, { id: req.params.id, reativar: acao === 'reativar' }));
      return obterFichaParceiro(c, req.params.id);
    }));
  }

  app.delete<{ Params: { id: string } }>('/parceiros/:id', {
    preHandler: requer('cadastros.excluir'),
    schema: { tags, summary: 'Exclusao logica do parceiro', params: paramId, response: erros },
  }, async (req, reply) => {
    await naTransacao(req, async (casos, ctx) => exigirOk(await casos.excluirParceiro.execute(ctx, { id: req.params.id })));
    return reply.code(204).send();
  });

  app.post<{ Body: { manter_id: string; duplicados_ids: string[] } }>('/parceiros/mesclar', {
    preHandler: requer('cadastros.mesclar'),
    schema: {
      tags, summary: 'Mescla duplicados no parceiro mantido (MesclarDuplicados)',
      body: { type: 'object', additionalProperties: false, required: ['manter_id', 'duplicados_ids'], properties: { manter_id: uuid, duplicados_ids: { type: 'array', items: uuid, minItems: 1, maxItems: 20 } } },
      response: erros,
    },
  }, (req) => naTransacao(req, async (casos, ctx, c) => {
    const r = exigirOk(await casos.mesclarDuplicados.execute(ctx, req.body));
    return { ...r, parceiro: await obterFichaParceiro(c, req.body.manter_id) };
  }));

  app.post<{ Params: { id: string }; Body: Omit<DadosEndereco, 'parceiro_id'> }>('/parceiros/:id/enderecos', {
    preHandler: requer('cadastros.editar'),
    schema: { tags, summary: 'Adiciona endereco ao parceiro', params: paramId, body: { type: 'object', additionalProperties: false, required: ['logradouro', 'cidade'], properties: propsEndereco }, response: erros },
  }, async (req, reply) => reply.code(201).send(await naTransacao(req, async (casos, ctx) =>
    exigirOk(await casos.adicionarEndereco.execute(ctx, { ...req.body, parceiro_id: req.params.id })))));

  app.delete<{ Params: { id: string; endereco_id: string } }>('/parceiros/:id/enderecos/:endereco_id', {
    preHandler: requer('cadastros.editar'),
    schema: { tags, summary: 'Remove endereco do parceiro', params: { type: 'object', required: ['id', 'endereco_id'], properties: { id: uuid, endereco_id: uuid } }, response: erros },
  }, async (req, reply) => {
    await naTransacao(req, async (casos, ctx) => exigirOk(await casos.removerEndereco.execute(ctx, { parceiro_id: req.params.id, id: req.params.endereco_id })));
    return reply.code(204).send();
  });

  app.post<{ Params: { id: string }; Body: Omit<DadosContaBancaria, 'parceiro_id'> }>('/parceiros/:id/contas', {
    preHandler: requer('cadastros.editar'),
    schema: { tags, summary: 'Adiciona conta bancaria ao parceiro', params: paramId, body: { type: 'object', additionalProperties: false, required: ['banco_codigo', 'agencia', 'conta'], properties: propsConta }, response: erros },
  }, async (req, reply) => reply.code(201).send(await naTransacao(req, async (casos, ctx) =>
    exigirOk(await casos.adicionarConta.execute(ctx, { ...req.body, parceiro_id: req.params.id })))));

  app.delete<{ Params: { id: string; conta_id: string } }>('/parceiros/:id/contas/:conta_id', {
    preHandler: requer('cadastros.editar'),
    schema: { tags, summary: 'Remove conta bancaria do parceiro', params: { type: 'object', required: ['id', 'conta_id'], properties: { id: uuid, conta_id: uuid } }, response: erros },
  }, async (req, reply) => {
    await naTransacao(req, async (casos, ctx) => exigirOk(await casos.removerConta.execute(ctx, { parceiro_id: req.params.id, id: req.params.conta_id })));
    return reply.code(204).send();
  });
}
