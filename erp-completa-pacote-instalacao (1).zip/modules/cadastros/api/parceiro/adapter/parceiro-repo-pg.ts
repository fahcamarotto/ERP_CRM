/**
 * Adaptador Postgres das portas do agregado Parceiro. Recebe o cliente da transacao aberta por
 * comEscopo (API) ou pelo worker: RLS ja restringe ao tenant e workspace da sessao, entao nenhuma
 * query filtra por tenant_id na mao e nenhuma recebe tenant_id de fora.
 */
import type pg from 'pg';
import type { ContaBancaria } from '../model/conta-bancaria.ts';
import type { Endereco } from '../model/endereco.ts';
import { Parceiro, type ParceiroDados } from '../model/parceiro.ts';
import type { ConsultarClassificacoes, GravarContasBancarias, GravarEnderecos, RepositorioParceiros } from '../model/portas.ts';

const COLUNAS = `p.id, p.tipo, p.nome, p.nome_fantasia, p.documento, p.email::text AS email, p.telefone, p.parent_id, p.cargo,
  p.setor_id, p.origem, p.ranking_cliente, p.ranking_fornecedor, p.e_cliente, p.e_fornecedor, p.estado, p.observacoes,
  p.extras, p.mesclado_em_id,
  coalesce((SELECT array_agg(t.tag_id ORDER BY t.created_at) FROM cadastros_parceiro_tags t
            WHERE t.parceiro_id = p.id AND t.deleted_at IS NULL), '{}') AS tag_ids`;

export class ParceiroRepoPg implements RepositorioParceiros, GravarEnderecos, GravarContasBancarias, ConsultarClassificacoes {
  constructor(private readonly c: pg.PoolClient) {}

  private async um(where: string, args: unknown[]): Promise<Parceiro | null> {
    const r = await this.c.query(`SELECT ${COLUNAS} FROM cadastros_parceiros p WHERE p.deleted_at IS NULL AND ${where} LIMIT 1`, args);
    return r.rows[0] ? Parceiro.deDados(r.rows[0] as ParceiroDados) : null;
  }

  obterPorId(id: string) {
    return this.um('p.id = $1', [id]);
  }

  buscarPorDocumento(documento: string) {
    return this.um('p.documento = $1', [documento]);
  }

  buscarPorContato(email: string | null, telefone: string | null) {
    return this.um(`(($1::text IS NOT NULL AND p.email = $1::citext) OR ($2::text IS NOT NULL AND p.telefone = $2))
      ORDER BY (p.estado = 'ativo') DESC, p.created_at`, [email, telefone]);
  }

  async inserir(p: Parceiro): Promise<void> {
    const d = p.paraDados();
    await this.c.query(
      `INSERT INTO cadastros_parceiros (id, tipo, nome, nome_fantasia, documento, email, telefone, parent_id, cargo, setor_id, origem,
         ranking_cliente, ranking_fornecedor, e_cliente, e_fornecedor, estado, observacoes, extras, creator_id)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, nucleo_usuario_atual())`,
      [d.id, d.tipo, d.nome, d.nome_fantasia, d.documento, d.email, d.telefone, d.parent_id, d.cargo, d.setor_id, d.origem,
        d.ranking_cliente, d.ranking_fornecedor, d.e_cliente, d.e_fornecedor, d.estado, d.observacoes, JSON.stringify(d.extras)],
    );
    await this.sincronizarTags(d.id, d.tag_ids);
  }

  async atualizar(p: Parceiro): Promise<void> {
    const d = p.paraDados();
    await this.c.query(
      `UPDATE cadastros_parceiros SET tipo = $2, nome = $3, nome_fantasia = $4, documento = $5, email = $6, telefone = $7,
         parent_id = $8, cargo = $9, setor_id = $10, origem = $11, ranking_cliente = $12, ranking_fornecedor = $13,
         e_cliente = $14, e_fornecedor = $15, estado = $16, observacoes = $17, extras = $18, mesclado_em_id = $19
       WHERE id = $1 AND deleted_at IS NULL`,
      [d.id, d.tipo, d.nome, d.nome_fantasia, d.documento, d.email, d.telefone, d.parent_id, d.cargo, d.setor_id, d.origem,
        d.ranking_cliente, d.ranking_fornecedor, d.e_cliente, d.e_fornecedor, d.estado, d.observacoes, JSON.stringify(d.extras), d.mesclado_em_id],
    );
    await this.sincronizarTags(d.id, d.tag_ids);
  }

  private async sincronizarTags(parceiroId: string, tagIds: string[]): Promise<void> {
    await this.c.query(
      `UPDATE cadastros_parceiro_tags SET deleted_at = now() WHERE parceiro_id = $1 AND deleted_at IS NULL AND NOT (tag_id = ANY ($2::uuid[]))`,
      [parceiroId, tagIds],
    );
    if (tagIds.length === 0) return;
    await this.c.query(
      `INSERT INTO cadastros_parceiro_tags (parceiro_id, tag_id, creator_id)
       SELECT $1, t, nucleo_usuario_atual() FROM unnest($2::uuid[]) t
       ON CONFLICT (tenant_id, workspace_id, parceiro_id, tag_id) DO UPDATE SET deleted_at = NULL`,
      [parceiroId, tagIds],
    );
  }

  async excluir(id: string): Promise<void> {
    await this.c.query('UPDATE cadastros_parceiros SET deleted_at = now() WHERE id = $1 AND deleted_at IS NULL', [id]);
  }

  async reapontar(deId: string, paraId: string): Promise<number> {
    let n = 0;
    for (const sql of [
      'UPDATE cadastros_parceiros SET parent_id = $2 WHERE parent_id = $1 AND deleted_at IS NULL AND id <> $2',
      'UPDATE cadastros_enderecos SET parceiro_id = $2 WHERE parceiro_id = $1 AND deleted_at IS NULL',
      'UPDATE cadastros_contas_bancarias SET parceiro_id = $2, principal = false WHERE parceiro_id = $1 AND deleted_at IS NULL',
      'UPDATE cadastros_projetos SET parceiro_id = $2 WHERE parceiro_id = $1 AND deleted_at IS NULL',
    ]) {
      n += (await this.c.query(sql, [deId, paraId])).rowCount ?? 0;
    }
    return n;
  }

  async existentes(ids: string[], tipo: 'tag' | 'setor'): Promise<string[]> {
    if (ids.length === 0) return [];
    const r = await this.c.query(
      'SELECT id FROM cadastros_classificacoes WHERE id = ANY ($1::uuid[]) AND tipo = $2 AND deleted_at IS NULL',
      [ids, tipo],
    );
    return r.rows.map((x) => x.id as string);
  }

  async inserirEndereco(e: Endereco): Promise<void> {
    const d = e.dados;
    await this.c.query(
      `INSERT INTO cadastros_enderecos (id, parceiro_id, tipo, cep, logradouro, numero, complemento, bairro, cidade, uf, pais, creator_id)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, nucleo_usuario_atual())`,
      [d.id, d.parceiro_id, d.tipo, d.cep, d.logradouro, d.numero, d.complemento, d.bairro, d.cidade, d.uf, d.pais],
    );
  }

  async removerEndereco(parceiroId: string, id: string): Promise<boolean> {
    const r = await this.c.query('UPDATE cadastros_enderecos SET deleted_at = now() WHERE id = $1 AND parceiro_id = $2 AND deleted_at IS NULL', [id, parceiroId]);
    return (r.rowCount ?? 0) > 0;
  }

  async inserirConta(conta: ContaBancaria): Promise<void> {
    const d = conta.dados;
    if (d.principal) {
      await this.c.query('UPDATE cadastros_contas_bancarias SET principal = false WHERE parceiro_id = $1 AND deleted_at IS NULL', [d.parceiro_id]);
    }
    await this.c.query(
      `INSERT INTO cadastros_contas_bancarias (id, parceiro_id, banco_codigo, banco_nome, agencia, conta, tipo, titular, pix_chave, principal, creator_id)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, nucleo_usuario_atual())`,
      [d.id, d.parceiro_id, d.banco_codigo, d.banco_nome, d.agencia, d.conta, d.tipo, d.titular, d.pix_chave, d.principal],
    );
  }

  async removerConta(parceiroId: string, id: string): Promise<boolean> {
    const r = await this.c.query('UPDATE cadastros_contas_bancarias SET deleted_at = now() WHERE id = $1 AND parceiro_id = $2 AND deleted_at IS NULL', [id, parceiroId]);
    return (r.rowCount ?? 0) > 0;
  }
}
