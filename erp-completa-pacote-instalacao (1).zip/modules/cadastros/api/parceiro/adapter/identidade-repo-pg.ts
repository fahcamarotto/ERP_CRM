/** Adaptador Postgres da identidade do parceiro por canal (cadastros_parceiros_identidades). */
import type pg from 'pg';
import type { IdentidadesCanal } from '../model/portas.ts';

export class IdentidadeRepoPg implements IdentidadesCanal {
  constructor(private readonly c: pg.PoolClient) {}

  async travar(chave: string) {
    await this.c.query(`SELECT pg_advisory_xact_lock(hashtextextended('cadastros:identidade:' || nucleo_workspace_atual()::text || ':' || $1, 0))`, [chave]);
  }

  async parceiroDaIdentidade(canal: string, idExterno: string) {
    const r = await this.c.query(
      `SELECT i.parceiro_id, p.mesclado_em_id FROM cadastros_parceiros_identidades i JOIN cadastros_parceiros p ON p.id = i.parceiro_id
       WHERE i.canal = $1 AND i.id_externo = $2 AND i.deleted_at IS NULL`, [canal, idExterno]);
    const l = r.rows[0];
    return l ? ((l.mesclado_em_id as string | null) ?? (l.parceiro_id as string)) : null;
  }

  async gravarIdentidade(i: { parceiro_id: string; canal: 'whatsapp' | 'instagram'; id_externo: string; usuario: string | null; nome: string | null; foto_url: string | null }) {
    await this.c.query(
      `INSERT INTO cadastros_parceiros_identidades (parceiro_id, canal, id_externo, usuario, nome, foto_url, creator_id)
       VALUES ($1, $2, $3, $4, $5, $6, nucleo_usuario_atual())
       ON CONFLICT (tenant_id, workspace_id, canal, id_externo) WHERE deleted_at IS NULL DO UPDATE SET
         usuario = coalesce(EXCLUDED.usuario, cadastros_parceiros_identidades.usuario),
         nome = coalesce(EXCLUDED.nome, cadastros_parceiros_identidades.nome),
         foto_url = coalesce(EXCLUDED.foto_url, cadastros_parceiros_identidades.foto_url)`,
      [i.parceiro_id, i.canal, i.id_externo, i.usuario, i.nome, i.foto_url]);
  }
}
