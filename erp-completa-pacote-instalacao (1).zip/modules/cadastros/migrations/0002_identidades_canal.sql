-- Identidade do parceiro num canal de mensagem (WhatsApp, Instagram): id da plataforma, @usuario, nome e foto.
-- Unico por canal e id dentro do workspace: o mesmo contato nunca vira dois cadastros. Idempotente.
CREATE TABLE IF NOT EXISTS cadastros_parceiros_identidades (
  id            uuid NOT NULL DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL DEFAULT nucleo_tenant_atual(),
  workspace_id  uuid NOT NULL DEFAULT nucleo_workspace_atual(),
  creator_id    uuid,
  parceiro_id   uuid NOT NULL,
  canal         text NOT NULL CHECK (canal IN ('whatsapp', 'instagram')),
  id_externo    text NOT NULL CHECK (id_externo ~ '^[0-9A-Za-z_.+-]{3,64}$'),
  usuario       text CHECK (usuario IS NULL OR length(usuario) <= 100),
  nome          text CHECK (nome IS NULL OR length(nome) <= 200),
  foto_url      text CHECK (foto_url IS NULL OR (foto_url ~ '^https?://' AND length(foto_url) <= 4000)),
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now(),
  deleted_at    timestamptz,
  PRIMARY KEY (id, tenant_id, workspace_id),
  FOREIGN KEY (workspace_id, tenant_id) REFERENCES workspaces (id, tenant_id),
  FOREIGN KEY (creator_id, tenant_id, workspace_id) REFERENCES usuarios (id, tenant_id, workspace_id),
  FOREIGN KEY (parceiro_id, tenant_id, workspace_id) REFERENCES cadastros_parceiros (id, tenant_id, workspace_id)
);
CREATE UNIQUE INDEX IF NOT EXISTS cadastros_parceiros_identidades_uq
  ON cadastros_parceiros_identidades (tenant_id, workspace_id, canal, id_externo) WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS cadastros_parceiros_identidades_parceiro_idx
  ON cadastros_parceiros_identidades (tenant_id, workspace_id, parceiro_id) WHERE deleted_at IS NULL;
SELECT nucleo_aplicar_padrao('cadastros_parceiros_identidades');

GRANT SELECT, INSERT, UPDATE ON cadastros_parceiros_identidades TO erp_app;
GRANT SELECT, INSERT, UPDATE ON cadastros_parceiros_identidades TO erp_worker;
GRANT SELECT, INSERT, UPDATE ON cadastros_parceiros TO erp_worker;
