-- M1 Cadastros: classificacoes (tags e setores), parceiros (pessoa e empresa), enderecos,
-- contas bancarias, projetos, equipe do projeto e importacoes CSV.
-- Toda tabela: tenant_id e workspace_id do contexto da sessao, PK composta, FK composta, RLS
-- por nucleo_aplicar_padrao, exclusao logica (sem DELETE). Idempotente.

-- M1.4 Tags e setores --------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS cadastros_classificacoes (
  id            uuid NOT NULL DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL DEFAULT nucleo_tenant_atual(),
  workspace_id  uuid NOT NULL DEFAULT nucleo_workspace_atual(),
  creator_id    uuid,
  tipo          text NOT NULL CHECK (tipo IN ('tag', 'setor')),
  nome          text NOT NULL CHECK (length(btrim(nome)) BETWEEN 1 AND 60),
  cor           text NOT NULL DEFAULT 'acento' CHECK (cor IN ('acento', 'roxo', 'azul', 'ciano', 'laranja', 'dourado', 'sucesso', 'perigo')),
  descricao     text,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now(),
  deleted_at    timestamptz,
  PRIMARY KEY (id, tenant_id, workspace_id),
  FOREIGN KEY (workspace_id, tenant_id) REFERENCES workspaces (id, tenant_id),
  FOREIGN KEY (creator_id, tenant_id, workspace_id) REFERENCES usuarios (id, tenant_id, workspace_id)
);
CREATE UNIQUE INDEX IF NOT EXISTS cadastros_classificacoes_nome_uq
  ON cadastros_classificacoes (tenant_id, workspace_id, tipo, lower(nome)) WHERE deleted_at IS NULL;
SELECT nucleo_aplicar_padrao('cadastros_classificacoes');

-- M1.1 Agregado Parceiro -----------------------------------------------------------------
CREATE TABLE IF NOT EXISTS cadastros_parceiros (
  id                  uuid NOT NULL DEFAULT gen_random_uuid(),
  tenant_id           uuid NOT NULL DEFAULT nucleo_tenant_atual(),
  workspace_id        uuid NOT NULL DEFAULT nucleo_workspace_atual(),
  creator_id          uuid,
  tipo                text NOT NULL CHECK (tipo IN ('pessoa', 'empresa')),
  nome                text NOT NULL CHECK (length(btrim(nome)) BETWEEN 2 AND 200),
  nome_fantasia       text,
  documento           text CHECK (documento IS NULL OR documento ~ '^([0-9]{11}|[0-9]{14})$'),
  email               citext,
  telefone            text CHECK (telefone IS NULL OR telefone ~ '^\+[1-9][0-9]{7,14}$'),
  parent_id           uuid,
  cargo               text,
  setor_id            uuid,
  origem              text,
  ranking_cliente     smallint NOT NULL DEFAULT 0 CHECK (ranking_cliente BETWEEN 0 AND 5),
  ranking_fornecedor  smallint NOT NULL DEFAULT 0 CHECK (ranking_fornecedor BETWEEN 0 AND 5),
  e_cliente           boolean NOT NULL DEFAULT false,
  e_fornecedor        boolean NOT NULL DEFAULT false,
  estado              text NOT NULL DEFAULT 'ativo' CHECK (estado IN ('ativo', 'arquivado')),
  observacoes         text,
  mesclado_em_id      uuid,
  extras              jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at          timestamptz NOT NULL DEFAULT now(),
  updated_at          timestamptz NOT NULL DEFAULT now(),
  deleted_at          timestamptz,
  PRIMARY KEY (id, tenant_id, workspace_id),
  FOREIGN KEY (workspace_id, tenant_id) REFERENCES workspaces (id, tenant_id),
  FOREIGN KEY (creator_id, tenant_id, workspace_id) REFERENCES usuarios (id, tenant_id, workspace_id),
  FOREIGN KEY (parent_id, tenant_id, workspace_id) REFERENCES cadastros_parceiros (id, tenant_id, workspace_id),
  FOREIGN KEY (mesclado_em_id, tenant_id, workspace_id) REFERENCES cadastros_parceiros (id, tenant_id, workspace_id),
  FOREIGN KEY (setor_id, tenant_id, workspace_id) REFERENCES cadastros_classificacoes (id, tenant_id, workspace_id),
  CHECK (parent_id IS NULL OR parent_id <> id),
  CHECK (tipo = 'pessoa' OR parent_id IS NULL)
);
CREATE UNIQUE INDEX IF NOT EXISTS cadastros_parceiros_documento_uq
  ON cadastros_parceiros (tenant_id, workspace_id, documento) WHERE documento IS NOT NULL AND deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS cadastros_parceiros_email_idx ON cadastros_parceiros (tenant_id, workspace_id, email) WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS cadastros_parceiros_telefone_idx ON cadastros_parceiros (tenant_id, workspace_id, telefone) WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS cadastros_parceiros_parent_idx ON cadastros_parceiros (tenant_id, workspace_id, parent_id) WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS cadastros_parceiros_lista_idx ON cadastros_parceiros (tenant_id, workspace_id, created_at, id) WHERE deleted_at IS NULL;
SELECT nucleo_aplicar_padrao('cadastros_parceiros');
DROP TRIGGER IF EXISTS cadastros_parceiros_extras ON cadastros_parceiros;
CREATE TRIGGER cadastros_parceiros_extras BEFORE INSERT OR UPDATE OF extras ON cadastros_parceiros
  FOR EACH ROW EXECUTE FUNCTION nucleo_trigger_extras('cadastros', 'parceiro');

CREATE TABLE IF NOT EXISTS cadastros_parceiro_tags (
  id            uuid NOT NULL DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL DEFAULT nucleo_tenant_atual(),
  workspace_id  uuid NOT NULL DEFAULT nucleo_workspace_atual(),
  creator_id    uuid,
  parceiro_id   uuid NOT NULL,
  tag_id        uuid NOT NULL,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now(),
  deleted_at    timestamptz,
  PRIMARY KEY (id, tenant_id, workspace_id),
  FOREIGN KEY (workspace_id, tenant_id) REFERENCES workspaces (id, tenant_id),
  FOREIGN KEY (creator_id, tenant_id, workspace_id) REFERENCES usuarios (id, tenant_id, workspace_id),
  FOREIGN KEY (parceiro_id, tenant_id, workspace_id) REFERENCES cadastros_parceiros (id, tenant_id, workspace_id),
  FOREIGN KEY (tag_id, tenant_id, workspace_id) REFERENCES cadastros_classificacoes (id, tenant_id, workspace_id)
);
CREATE UNIQUE INDEX IF NOT EXISTS cadastros_parceiro_tags_uq ON cadastros_parceiro_tags (tenant_id, workspace_id, parceiro_id, tag_id);
SELECT nucleo_aplicar_padrao('cadastros_parceiro_tags');

-- M1.2 Enderecos e contas bancarias ------------------------------------------------------
CREATE TABLE IF NOT EXISTS cadastros_enderecos (
  id            uuid NOT NULL DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL DEFAULT nucleo_tenant_atual(),
  workspace_id  uuid NOT NULL DEFAULT nucleo_workspace_atual(),
  creator_id    uuid,
  parceiro_id   uuid NOT NULL,
  tipo          text NOT NULL DEFAULT 'principal' CHECK (tipo IN ('principal', 'cobranca', 'entrega', 'outro')),
  cep           text CHECK (cep IS NULL OR cep ~ '^[0-9]{8}$'),
  logradouro    text NOT NULL,
  numero        text,
  complemento   text,
  bairro        text,
  cidade        text NOT NULL,
  uf            text CHECK (uf IS NULL OR uf ~ '^[A-Z]{2}$'),
  pais          text NOT NULL DEFAULT 'BR' CHECK (pais ~ '^[A-Z]{2}$'),
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now(),
  deleted_at    timestamptz,
  PRIMARY KEY (id, tenant_id, workspace_id),
  FOREIGN KEY (workspace_id, tenant_id) REFERENCES workspaces (id, tenant_id),
  FOREIGN KEY (creator_id, tenant_id, workspace_id) REFERENCES usuarios (id, tenant_id, workspace_id),
  FOREIGN KEY (parceiro_id, tenant_id, workspace_id) REFERENCES cadastros_parceiros (id, tenant_id, workspace_id)
);
CREATE INDEX IF NOT EXISTS cadastros_enderecos_parceiro_idx ON cadastros_enderecos (tenant_id, workspace_id, parceiro_id) WHERE deleted_at IS NULL;
SELECT nucleo_aplicar_padrao('cadastros_enderecos');

CREATE TABLE IF NOT EXISTS cadastros_contas_bancarias (
  id                 uuid NOT NULL DEFAULT gen_random_uuid(),
  tenant_id          uuid NOT NULL DEFAULT nucleo_tenant_atual(),
  workspace_id       uuid NOT NULL DEFAULT nucleo_workspace_atual(),
  creator_id         uuid,
  parceiro_id        uuid NOT NULL,
  banco_codigo       text NOT NULL CHECK (banco_codigo ~ '^[0-9]{3}$'),
  banco_nome         text,
  agencia            text NOT NULL CHECK (agencia ~ '^[0-9]{1,6}(-[0-9Xx])?$'),
  conta              text NOT NULL CHECK (conta ~ '^[0-9]{1,13}(-[0-9Xx])?$'),
  tipo               text NOT NULL DEFAULT 'corrente' CHECK (tipo IN ('corrente', 'poupanca', 'pagamento')),
  titular            text,
  pix_chave          text,
  principal          boolean NOT NULL DEFAULT false,
  created_at         timestamptz NOT NULL DEFAULT now(),
  updated_at         timestamptz NOT NULL DEFAULT now(),
  deleted_at         timestamptz,
  PRIMARY KEY (id, tenant_id, workspace_id),
  FOREIGN KEY (workspace_id, tenant_id) REFERENCES workspaces (id, tenant_id),
  FOREIGN KEY (creator_id, tenant_id, workspace_id) REFERENCES usuarios (id, tenant_id, workspace_id),
  FOREIGN KEY (parceiro_id, tenant_id, workspace_id) REFERENCES cadastros_parceiros (id, tenant_id, workspace_id)
);
CREATE INDEX IF NOT EXISTS cadastros_contas_parceiro_idx ON cadastros_contas_bancarias (tenant_id, workspace_id, parceiro_id) WHERE deleted_at IS NULL;
SELECT nucleo_aplicar_padrao('cadastros_contas_bancarias');

-- M1.3 Projeto ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS cadastros_projetos (
  id              uuid NOT NULL DEFAULT gen_random_uuid(),
  tenant_id       uuid NOT NULL DEFAULT nucleo_tenant_atual(),
  workspace_id    uuid NOT NULL DEFAULT nucleo_workspace_atual(),
  creator_id      uuid,
  nome            text NOT NULL CHECK (length(btrim(nome)) BETWEEN 2 AND 200),
  descricao       text,
  parceiro_id     uuid,
  responsavel_id  uuid,
  inicio          date,
  prazo           date,
  orcamento       numeric(14, 2) CHECK (orcamento IS NULL OR orcamento >= 0),
  moeda           text NOT NULL DEFAULT 'BRL' CHECK (moeda ~ '^[A-Z]{3}$'),
  estado          text NOT NULL DEFAULT 'planejado' CHECK (estado IN ('planejado', 'em_andamento', 'pausado', 'concluido', 'cancelado')),
  extras          jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at      timestamptz NOT NULL DEFAULT now(),
  updated_at      timestamptz NOT NULL DEFAULT now(),
  deleted_at      timestamptz,
  PRIMARY KEY (id, tenant_id, workspace_id),
  FOREIGN KEY (workspace_id, tenant_id) REFERENCES workspaces (id, tenant_id),
  FOREIGN KEY (creator_id, tenant_id, workspace_id) REFERENCES usuarios (id, tenant_id, workspace_id),
  FOREIGN KEY (parceiro_id, tenant_id, workspace_id) REFERENCES cadastros_parceiros (id, tenant_id, workspace_id),
  FOREIGN KEY (responsavel_id, tenant_id, workspace_id) REFERENCES usuarios (id, tenant_id, workspace_id),
  CHECK (prazo IS NULL OR inicio IS NULL OR prazo >= inicio)
);
CREATE INDEX IF NOT EXISTS cadastros_projetos_parceiro_idx ON cadastros_projetos (tenant_id, workspace_id, parceiro_id) WHERE deleted_at IS NULL;
SELECT nucleo_aplicar_padrao('cadastros_projetos');
DROP TRIGGER IF EXISTS cadastros_projetos_extras ON cadastros_projetos;
CREATE TRIGGER cadastros_projetos_extras BEFORE INSERT OR UPDATE OF extras ON cadastros_projetos
  FOR EACH ROW EXECUTE FUNCTION nucleo_trigger_extras('cadastros', 'projeto');

CREATE TABLE IF NOT EXISTS cadastros_projeto_equipe (
  id            uuid NOT NULL DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL DEFAULT nucleo_tenant_atual(),
  workspace_id  uuid NOT NULL DEFAULT nucleo_workspace_atual(),
  creator_id    uuid,
  projeto_id    uuid NOT NULL,
  usuario_id    uuid NOT NULL,
  papel         text,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now(),
  deleted_at    timestamptz,
  PRIMARY KEY (id, tenant_id, workspace_id),
  FOREIGN KEY (workspace_id, tenant_id) REFERENCES workspaces (id, tenant_id),
  FOREIGN KEY (creator_id, tenant_id, workspace_id) REFERENCES usuarios (id, tenant_id, workspace_id),
  FOREIGN KEY (projeto_id, tenant_id, workspace_id) REFERENCES cadastros_projetos (id, tenant_id, workspace_id),
  FOREIGN KEY (usuario_id, tenant_id, workspace_id) REFERENCES usuarios (id, tenant_id, workspace_id)
);
CREATE UNIQUE INDEX IF NOT EXISTS cadastros_projeto_equipe_uq ON cadastros_projeto_equipe (tenant_id, workspace_id, projeto_id, usuario_id);
SELECT nucleo_aplicar_padrao('cadastros_projeto_equipe');

-- M1.5 ImportarParceirosCSV (job): status gravado no banco, a tela consulta ate concluir ---
CREATE TABLE IF NOT EXISTS cadastros_importacoes (
  id            uuid NOT NULL DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL DEFAULT nucleo_tenant_atual(),
  workspace_id  uuid NOT NULL DEFAULT nucleo_workspace_atual(),
  creator_id    uuid,
  nome_arquivo  text NOT NULL,
  conteudo      text NOT NULL,
  estado        text NOT NULL DEFAULT 'pendente' CHECK (estado IN ('pendente', 'processando', 'concluida', 'erro')),
  total         integer NOT NULL DEFAULT 0,
  criados       integer NOT NULL DEFAULT 0,
  atualizados   integer NOT NULL DEFAULT 0,
  erros         jsonb NOT NULL DEFAULT '[]'::jsonb,
  job_id        uuid,
  concluida_em  timestamptz,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now(),
  deleted_at    timestamptz,
  PRIMARY KEY (id, tenant_id, workspace_id),
  FOREIGN KEY (workspace_id, tenant_id) REFERENCES workspaces (id, tenant_id),
  FOREIGN KEY (creator_id, tenant_id, workspace_id) REFERENCES usuarios (id, tenant_id, workspace_id)
);
SELECT nucleo_aplicar_padrao('cadastros_importacoes');

-- Papeis de banco: API (erp_app) e worker (erp_worker, importacao CSV e webhook de landing page).
GRANT SELECT, INSERT, UPDATE ON cadastros_classificacoes, cadastros_parceiros, cadastros_parceiro_tags,
  cadastros_enderecos, cadastros_contas_bancarias, cadastros_projetos, cadastros_projeto_equipe,
  cadastros_importacoes TO erp_app;
GRANT SELECT, INSERT, UPDATE ON cadastros_classificacoes, cadastros_parceiros, cadastros_parceiro_tags,
  cadastros_importacoes TO erp_worker;
GRANT SELECT ON cadastros_enderecos, cadastros_contas_bancarias, cadastros_projetos, cadastros_projeto_equipe TO erp_worker;
