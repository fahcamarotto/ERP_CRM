/**
 * Seed demo do Cadastros (D1): setores, tags, empresas com contatos, clientes pessoa fisica,
 * fornecedores, enderecos, contas bancarias e projetos. Idempotente: ids deterministicos por chave
 * e insercao so do que falta, no workspace do contexto (vale para qualquer workspace, inclusive o sandbox D2).
 * Grava pelos adaptadores do modulo para passar pelas mesmas regras das entidades.
 */
import { createHash } from 'node:crypto';
import type { SeedModulo } from '@erp/api/sdk/puro';
import { ClassificacaoRepoPg } from '../api/classificacao/adapter/classificacao-repo-pg.ts';
import { Classificacao, type CorClassificacao } from '../api/classificacao/model/classificacao.ts';
import { ParceiroRepoPg } from '../api/parceiro/adapter/parceiro-repo-pg.ts';
import { ContaBancaria } from '../api/parceiro/model/conta-bancaria.ts';
import { Endereco } from '../api/parceiro/model/endereco.ts';
import { Parceiro, type DadosParceiro } from '../api/parceiro/model/parceiro.ts';
import { ProjetoRepoPg } from '../api/projeto/adapter/projeto-repo-pg.ts';
import { Projeto, type EstadoProjeto } from '../api/projeto/model/projeto.ts';

/** uuid deterministico a partir de uma chave (mesmo id em toda execucao). */
function idDe(chave: string): string {
  const h = createHash('sha256').update(`cadastros-demo:${chave}`).digest('hex');
  return `${h.slice(0, 8)}-${h.slice(8, 12)}-4${h.slice(13, 16)}-a${h.slice(17, 20)}-${h.slice(20, 32)}`;
}

function cnpj(base: string): string {
  const dv = (d: string, pesos: number[]) => { const r = pesos.reduce((a, p, i) => a + p * Number(d[i]), 0) % 11; return r < 2 ? 0 : 11 - r; };
  const d1 = dv(base, [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]);
  return `${base}${d1}${dv(`${base}${d1}`, [6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2])}`;
}

function cpf(base: string): string {
  const dv = (d: string) => { const n = d.length + 1; const s = [...d].reduce((a, x, i) => a + Number(x) * (n - i), 0); const r = (s * 10) % 11; return r === 10 ? 0 : r; };
  const d1 = dv(base);
  return `${base}${d1}${dv(`${base}${d1}`)}`;
}

const SETORES: [string, CorClassificacao][] = [['Tecnologia', 'azul'], ['Varejo', 'laranja'], ['Saúde', 'sucesso'], ['Serviços', 'roxo'], ['Indústria', 'dourado']];
const TAGS: [string, CorClassificacao][] = [['VIP', 'dourado'], ['Recorrente', 'sucesso'], ['Parceiro estratégico', 'roxo'], ['Atenção no pagamento', 'perigo'], ['Novo', 'ciano']];

const EMPRESAS = [
  { k: 'aurora', nome: 'Aurora Tecnologia Ltda', fantasia: 'Aurora Tech', base: '112223330001', setor: 'Tecnologia', tags: ['VIP', 'Recorrente'], cliente: true, fornecedor: false, rc: 5, rf: 0, email: 'contato@auroratech.com.br', tel: '1133224455', cidade: 'São Paulo', uf: 'SP' },
  { k: 'boa-vista', nome: 'Mercado Boa Vista Comércio de Alimentos Ltda', fantasia: 'Mercado Boa Vista', base: '223334440001', setor: 'Varejo', tags: ['Recorrente'], cliente: true, fornecedor: false, rc: 4, rf: 0, email: 'compras@mercadoboavista.com.br', tel: '3132105500', cidade: 'Belo Horizonte', uf: 'MG' },
  { k: 'clinica-vida', nome: 'Clínica Vida Plena S.A.', fantasia: 'Vida Plena', base: '334445550001', setor: 'Saúde', tags: ['Novo'], cliente: true, fornecedor: false, rc: 3, rf: 0, email: 'adm@vidaplena.med.br', tel: '4130307070', cidade: 'Curitiba', uf: 'PR' },
  { k: 'papelaria', nome: 'Papelaria Central Distribuidora Ltda', fantasia: 'Papelaria Central', base: '445556660001', setor: 'Varejo', tags: ['Parceiro estratégico'], cliente: false, fornecedor: true, rc: 0, rf: 4, email: 'vendas@papelariacentral.com.br', tel: '1140028922', cidade: 'Campinas', uf: 'SP' },
  { k: 'nuvem', nome: 'Nuvem Segura Serviços de TI Ltda', fantasia: 'Nuvem Segura', base: '556667770001', setor: 'Tecnologia', tags: ['Parceiro estratégico', 'Recorrente'], cliente: false, fornecedor: true, rc: 0, rf: 5, email: 'financeiro@nuvemsegura.com.br', tel: '2125556677', cidade: 'Rio de Janeiro', uf: 'RJ' },
  { k: 'metalurgica', nome: 'Metalúrgica Sul Indústria e Comércio Ltda', fantasia: 'Metalúrgica Sul', base: '667778880001', setor: 'Indústria', tags: ['Atenção no pagamento'], cliente: true, fornecedor: true, rc: 2, rf: 3, email: 'comercial@metalsul.ind.br', tel: '5134445566', cidade: 'Porto Alegre', uf: 'RS' },
];

const CONTATOS = [
  { k: 'c1', empresa: 'aurora', nome: 'Marina Castro', cargo: 'Diretora de Operações', email: 'marina@auroratech.com.br', tel: '11987650001' },
  { k: 'c2', empresa: 'aurora', nome: 'Rafael Nogueira', cargo: 'Gerente Financeiro', email: 'rafael@auroratech.com.br', tel: '11987650002' },
  { k: 'c3', empresa: 'boa-vista', nome: 'Carla Menezes', cargo: 'Compradora', email: 'carla@mercadoboavista.com.br', tel: '31987650003' },
  { k: 'c4', empresa: 'clinica-vida', nome: 'Dr. Eduardo Lima', cargo: 'Diretor Clínico', email: 'eduardo@vidaplena.med.br', tel: '41987650004' },
  { k: 'c5', empresa: 'papelaria', nome: 'Joana Prado', cargo: 'Executiva de Contas', email: 'joana@papelariacentral.com.br', tel: '19987650005' },
  { k: 'c6', empresa: 'nuvem', nome: 'Thiago Ramos', cargo: 'Gerente de Contas', email: 'thiago@nuvemsegura.com.br', tel: '21987650006' },
  { k: 'c7', empresa: 'metalurgica', nome: 'Luciana Ferraz', cargo: 'Coordenadora de Compras', email: 'luciana@metalsul.ind.br', tel: '51987650007' },
];

const PESSOAS = [
  { k: 'p1', nome: 'Ana Beatriz Souza', base: '123456780', email: 'ana.souza@example.com', tel: '11991234501', tags: ['VIP'], origem: 'indicacao', rc: 5 },
  { k: 'p2', nome: 'Bruno Henrique Alves', base: '234567890', email: 'bruno.alves@example.com', tel: '21991234502', tags: ['Novo'], origem: 'landing', rc: 2 },
  { k: 'p3', nome: 'Camila Rocha', base: '345678901', email: 'camila.rocha@example.com', tel: '31991234503', tags: ['Recorrente'], origem: 'instagram', rc: 4 },
  { k: 'p4', nome: 'Diego Martins', base: '456789012', email: 'diego.martins@example.com', tel: '41991234504', tags: [], origem: 'whatsapp', rc: 3 },
  { k: 'p5', nome: 'Elisa Fernandes', base: '567890123', email: 'elisa.fernandes@example.com', tel: '51991234505', tags: ['Atenção no pagamento'], origem: 'landing', rc: 1 },
];

const PROJETOS: { k: string; nome: string; cliente: string; estado: EstadoProjeto; inicio: string; prazo: string; orcamento: number; descricao: string }[] = [
  { k: 'pj1', nome: 'Implantação do portal de clientes', cliente: 'aurora', estado: 'em_andamento', inicio: '2026-08-01', prazo: '2026-12-15', orcamento: 85000, descricao: 'Portal com login, faturas e chamados.' },
  { k: 'pj2', nome: 'Reforma do layout das lojas', cliente: 'boa-vista', estado: 'planejado', inicio: '2026-11-03', prazo: '2027-02-28', orcamento: 140000, descricao: 'Nova sinalização e gôndolas em 3 unidades.' },
  { k: 'pj3', nome: 'Agenda online de consultas', cliente: 'clinica-vida', estado: 'pausado', inicio: '2026-07-10', prazo: '2026-10-30', orcamento: 32000, descricao: 'Agendamento pelo site com confirmação por WhatsApp.' },
  { k: 'pj4', nome: 'Auditoria de processos fiscais', cliente: 'metalurgica', estado: 'concluido', inicio: '2026-03-01', prazo: '2026-06-30', orcamento: 48000, descricao: 'Revisão de notas e obrigações acessórias.' },
  { k: 'pj5', nome: 'Consultoria de carreira premium', cliente: 'p1', estado: 'em_andamento', inicio: '2026-09-01', prazo: '2026-11-30', orcamento: 6000, descricao: 'Mentoria individual com 8 encontros.' },
];

const semear: SeedModulo = async ({ c, usuarioId, log }) => {
  const parceiros = new ParceiroRepoPg(c);
  const classificacoes = new ClassificacaoRepoPg(c);
  const projetos = new ProjetoRepoPg(c);
  let novos = 0;

  const cls = new Map<string, string>();
  for (const [tipo, lista] of [['setor', SETORES], ['tag', TAGS]] as const) {
    for (const [nome, cor] of lista) {
      const id = idDe(`${tipo}:${nome}`);
      const existente = (await classificacoes.obterPorId(id)) ?? (await classificacoes.buscarPorNome(tipo, nome));
      if (!existente) { await classificacoes.inserir(Classificacao.create({ tipo, nome, cor }, id)); novos++; }
      cls.set(`${tipo}:${nome}`, existente?.id ?? id);
    }
  }

  const ids = new Map<string, string>();
  const garantir = async (k: string, dados: DadosParceiro) => {
    const id = idDe(`parceiro:${k}`);
    const existente = (await parceiros.obterPorId(id)) ?? (dados.documento ? await parceiros.buscarPorDocumento(dados.documento.replace(/\D/g, '')) : null);
    if (!existente) { await parceiros.inserir(Parceiro.create(dados, id)); novos++; }
    ids.set(k, existente?.id ?? id);
    return existente ? null : id;
  };

  for (const e of EMPRESAS) {
    const novo = await garantir(e.k, {
      tipo: 'empresa', nome: e.nome, nome_fantasia: e.fantasia, documento: cnpj(e.base), email: e.email, telefone: e.tel,
      setor_id: cls.get(`setor:${e.setor}`), tag_ids: e.tags.map((t) => cls.get(`tag:${t}`)!), origem: 'seed_demo',
      e_cliente: e.cliente, e_fornecedor: e.fornecedor, ranking_cliente: e.rc, ranking_fornecedor: e.rf,
    });
    if (novo) {
      await parceiros.inserirEndereco(Endereco.create({ parceiro_id: novo, tipo: 'principal', cep: '01310100', logradouro: 'Avenida Principal', numero: String(100 + EMPRESAS.indexOf(e) * 37), bairro: 'Centro', cidade: e.cidade, uf: e.uf }));
      await parceiros.inserirConta(ContaBancaria.create({ parceiro_id: novo, banco_codigo: '341', banco_nome: 'Itaú Unibanco', agencia: '0' + String(1500 + EMPRESAS.indexOf(e)), conta: `${45000 + EMPRESAS.indexOf(e) * 11}-${EMPRESAS.indexOf(e)}`, titular: e.nome, principal: true }));
    }
  }
  for (const ct of CONTATOS) {
    await garantir(ct.k, { tipo: 'pessoa', nome: ct.nome, cargo: ct.cargo, email: ct.email, telefone: ct.tel, parent_id: ids.get(ct.empresa)!, origem: 'seed_demo' });
  }
  for (const p of PESSOAS) {
    const novo = await garantir(p.k, {
      tipo: 'pessoa', nome: p.nome, documento: cpf(p.base), email: p.email, telefone: p.tel, tag_ids: p.tags.map((t) => cls.get(`tag:${t}`)!),
      origem: p.origem, e_cliente: true, ranking_cliente: p.rc,
    });
    if (novo) await parceiros.inserirEndereco(Endereco.create({ parceiro_id: novo, tipo: 'principal', cep: '04538133', logradouro: 'Rua das Flores', numero: String(10 + PESSOAS.indexOf(p)), bairro: 'Jardins', cidade: 'São Paulo', uf: 'SP' }));
  }
  for (const pj of PROJETOS) {
    const id = idDe(`projeto:${pj.k}`);
    if (await projetos.obterPorId(id)) continue;
    const base = Projeto.create({ nome: pj.nome, descricao: pj.descricao, parceiro_id: ids.get(pj.cliente)!, responsavel_id: usuarioId, equipe_ids: [usuarioId], inicio: pj.inicio, prazo: pj.prazo, orcamento: pj.orcamento }, id);
    const caminho: EstadoProjeto[] = pj.estado === 'planejado' ? [] : pj.estado === 'em_andamento' ? ['em_andamento'] : pj.estado === 'pausado' ? ['em_andamento', 'pausado'] : ['em_andamento', pj.estado];
    const final = caminho.reduce((p, e) => { const r = p.mudarEstado(e); if (!r.ok) throw new Error(r.erros[0]!.mensagem); return r.valor; }, base);
    await projetos.inserir(final);
    novos++;
  }
  log(`${novos} registro(s) demo novo(s) (${SETORES.length} setores, ${TAGS.length} tags, ${EMPRESAS.length} empresas, ${CONTATOS.length} contatos, ${PESSOAS.length} pessoas, ${PROJETOS.length} projetos)`);
};

export default semear;
