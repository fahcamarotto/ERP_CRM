/**
 * Handlers de worker do Cadastros (carregados pelo worker do nucleo na partida).
 * `c` ja esta numa transacao do papel erp_worker com o escopo do job (RLS vale).
 */
import type { HandlersModulo } from '@erp/api/sdk/puro';
import { contextoPg } from '../api/compartilhado/efeitos-pg.ts';
import { casosDeUso } from '../api/fabrica.ts';
import { TIPO_JOB } from '../api/importacao/importar-parceiros.ts';
import type { EntradaContatoCanal } from '../api/parceiro/use-case/cadastrar-contato-canal.ts';
import type { EntradaClienteAutomacao } from '../api/parceiro/use-case/cliente-de-automacao.ts';
import type { EntradaLead, FonteDoLead } from '../api/parceiro/use-case/receber-lead.ts';

const SISTEMA = { tipo: 'sistema' as const, id: null };

/** Normaliza o corpo de formulario de landing page (nomes em pt ou en, plano ou dentro de `data`/`fields`). */
export function lerFormulario(corpo: unknown): EntradaLead {
  const raiz = (corpo && typeof corpo === 'object' ? corpo : {}) as Record<string, unknown>;
  const dentro = [raiz.data, raiz.fields, raiz.lead].find((x) => x && typeof x === 'object') as Record<string, unknown> | undefined;
  const f = { ...raiz, ...(dentro ?? {}) };
  const s = (...ks: string[]) => {
    for (const k of ks) {
      const v = f[k];
      if (typeof v === 'string' && v.trim()) return v.trim().slice(0, 2000);
      if (typeof v === 'number') return String(v);
    }
    return undefined;
  };
  return {
    nome: s('nome', 'name', 'full_name', 'nome_completo'),
    email: s('email', 'e-mail', 'mail'),
    telefone: s('telefone', 'phone', 'whatsapp', 'celular', 'phone_number'),
    empresa: s('empresa', 'company', 'organizacao'),
    mensagem: s('mensagem', 'message', 'comentario', 'observacoes'),
    origem: s('origem', 'source', 'form_name', 'pagina') ?? 'landing',
    utm_source: s('utm_source'), utm_medium: s('utm_medium'), utm_campaign: s('utm_campaign'),
  };
}

/** Fonte de lead do envio (integracoes_fontes_lead, so SELECT). Sem id: a fonte padrao (URL antiga) da subconta. */
async function fonteDoLead(c: Parameters<HandlersModulo[string]>[1], id: string | null): Promise<FonteDoLead | null> {
  const r = await c.query(
    `SELECT id, nome, funil_id, etapa_id, tags, responsavel_id FROM integracoes_fontes_lead
     WHERE deleted_at IS NULL AND (($1::uuid IS NOT NULL AND id = $1) OR ($1::uuid IS NULL AND padrao)) LIMIT 1`,
    [id],
  );
  const f = r.rows[0] as FonteDoLead | undefined;
  return f ? { ...f, tags: f.tags ?? [] } : null;
}

const handlers: HandlersModulo = {
  // No "cliente" ou "tag" de uma automacao (CONTRATOS 7.1.15): cria ou acha o cliente e aplica as tags, idempotente.
  'cadastros:ao:automacao.cliente_solicitado': async (d, c) => {
    const dados = (d.payload as { dados?: EntradaClienteAutomacao }).dados;
    if (!dados?.canal || !dados.contato) return;
    const r = await casosDeUso(c).aplicarClienteDeAutomacao.execute(contextoPg(c, SISTEMA), dados);
    if (!r.ok && !['canal_invalido', 'contato_invalido'].includes(r.erros[0]?.codigo ?? '')) throw new Error(r.erros.map((e) => e.mensagem).join('; '));
  },

  // Contato novo de WhatsApp ou Instagram (Conversas) vira cliente; devolve contato.cadastrado para ligar a conversa.
  'cadastros:ao:contato.desconhecido': async (d, c) => {
    const dados = (d.payload as { dados?: EntradaContatoCanal }).dados;
    if (!dados?.canal || !dados.contato) return;
    const r = await casosDeUso(c).cadastrarContatoDeCanal.execute(contextoPg(c, SISTEMA), dados);
    // Dado invalido do remetente nao e reprocessado.
    if (!r.ok && !['canal_invalido', 'contato_invalido'].includes(r.erros[0]?.codigo ?? '')) throw new Error(r.erros.map((e) => e.mensagem).join('; '));
  },

  // M1.5 ImportarParceirosCSV: progresso gravado em cadastros_importacoes.
  [TIPO_JOB]: async (d, c) => {
    const p = d.payload as { importacao_id: string };
    const r = await casosDeUso(c).processarImportacao.execute(contextoPg(c, SISTEMA), { importacao_id: p.importacao_id });
    if (!r.ok) throw new Error(r.erros.map((e) => e.mensagem).join('; '));
  },

  // M1.6 Webhook de landing page: POST /api/v1/webhooks/webhook-landing/<token> (assinatura validada pelo nucleo).
  // Cada fonte de lead tem URL propria; a fonte (tabela publicada do Integracoes) da a origem, as tags e o destino.
  'webhook.recebido.webhook-landing': async (d, c) => {
    const p = d.payload as { recebido_id: string; fonte_id?: string | null };
    const ev = (await c.query('SELECT payload, fonte_id FROM integracoes_eventos_recebidos WHERE id = $1', [p.recebido_id])).rows[0];
    if (!ev) return;
    const fonte = await fonteDoLead(c, p.fonte_id ?? ev.fonte_id ?? null);
    const casos = casosDeUso(c);
    const ctx = contextoPg(c, SISTEMA);
    const r = await casos.receberLead.execute(ctx, { ...lerFormulario(ev.payload), fonte });
    if (!r.ok) {
      // Lead sem contato valido nao e reprocessado: registra o motivo e encerra.
      await c.query(`UPDATE integracoes_eventos_recebidos SET erro = $2 WHERE id = $1`, [p.recebido_id, r.erros.map((e) => e.mensagem).join('; ').slice(0, 500)]);
      return;
    }
    if (fonte?.tags.length) {
      const t = await casos.aplicarClienteDeAutomacao.execute(ctx, { canal: 'landing', contato: r.valor.id, parceiro_id: r.valor.id, tags: fonte.tags, so_tags: true });
      if (!t.ok) throw new Error(t.erros.map((e) => e.mensagem).join('; '));
    }
  },
};

export default handlers;
