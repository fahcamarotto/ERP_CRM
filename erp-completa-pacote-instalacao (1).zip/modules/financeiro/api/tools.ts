/**
 * @tool do modulo (N15): cada chamada vira tool MCP em /mcp e rota REST com o mesmo schema no OpenAPI.
 * Tools de M4.8: financeiro.saldo e lancamentos.listar; mais lancamentos.obter, lancamentos.registrar,
 * lancamentos.estornar, financeiro.transferir, financeiro.fluxo_caixa, financeiro.contas,
 * financeiro.categorias e financeiro.conciliar.
 * Registrar e transferir sao so MCP (sem rota): a rota REST equivalente exige o cabecalho Idempotency-Key.
 */
import { tool } from '@erp/api/sdk';
import { naoEncontrado } from './borda.ts';
import { listarCategorias } from './categoria/query/categorias.ts';
import { contextoPg } from './compartilhado/efeitos-pg.ts';
import { exigirOk } from './compartilhado/result.ts';
import { listarContas, saldos } from './conta/query/contas.ts';
import { chaveIdempotencia, filtroFluxo, filtroLancamentos, propsLancamento, propsTransferencia, uuid } from './esquemas.ts';
import { casosDeUso } from './fabrica.ts';
import type { DadosLancamento } from './lancamento/model/lancamento.ts';
import { fluxoDeCaixa, type FiltroFluxo } from './lancamento/query/fluxo-caixa.ts';
import { listarLancamentos, obterLancamento, type FiltroLancamentos } from './lancamento/query/lancamentos.ts';
import type { EntradaTransferir } from './lancamento/use-case/registrar-lancamento.ts';

tool<{ conta_id?: string; data?: string }>({
  nome: 'financeiro.saldo', modulo: 'financeiro', titulo: 'Saldo das contas', tipo: 'leitura', permissao: 'financeiro.ver',
  descricao: 'Saldo realizado (centavos) de cada conta ativa numa data (padrao: hoje) e total por moeda. Filtra por conta_id.',
  entrada: { type: 'object', properties: { conta_id: uuid, data: { type: 'string', format: 'date' } } },
  rota: { metodo: 'GET', caminho: '/api/v1/financeiro/saldo' },
  executar: ({ c }, a) => saldos(c, a),
});

tool<FiltroLancamentos>({
  nome: 'lancamentos.listar', modulo: 'financeiro', titulo: 'Listar lancamentos', tipo: 'leitura', permissao: 'financeiro.ver',
  descricao: 'Lista entradas, saidas e transferencias (mais recentes primeiro) com conta, categoria, centro de custo e parceiro; filtra por tipo, conta, periodo, situacao (realizado ou previsto), estado e conciliacao.',
  entrada: { type: 'object', properties: filtroLancamentos },
  rota: { metodo: 'GET', caminho: '/api/v1/financeiro/lancamentos' },
  executar: ({ c }, a) => listarLancamentos(c, a),
});

tool<{ id: string }>({
  nome: 'lancamentos.obter', modulo: 'financeiro', titulo: 'Obter lancamento', tipo: 'leitura', permissao: 'financeiro.ver',
  descricao: 'Ficha do lancamento: valores, classificacao, comprovante, estorno e item de extrato conciliado.',
  entrada: { type: 'object', required: ['id'], properties: { id: uuid } },
  rota: { metodo: 'GET', caminho: '/api/v1/financeiro/lancamentos/:id' },
  executar: async ({ c }, a) => (await obterLancamento(c, a.id)) ?? Promise.reject(naoEncontrado('Lancamento nao encontrado')),
});

tool<Omit<DadosLancamento, 'origem'> & { chave_idempotencia: string }>({
  nome: 'lancamentos.registrar', modulo: 'financeiro', titulo: 'Registrar lancamento', tipo: 'escrita', permissao: 'financeiro.criar',
  descricao: 'Registra entrada ou saida em centavos (sem data_caixa fica previsto). chave_idempotencia obrigatoria: repetir a mesma chave devolve o lancamento ja gravado. Publica lancamento.registrado.',
  entrada: { type: 'object', required: ['tipo', 'descricao', 'conta_id', 'valor_centavos', 'data_competencia', 'chave_idempotencia'], properties: { ...propsLancamento, chave_idempotencia: chaveIdempotencia } },
  executar: async ({ c, ator, ip }, a) => {
    const r = exigirOk(await casosDeUso(c).registrarLancamento.execute(contextoPg(c, ator, ip), { ...a, origem: 'manual' }));
    return { ...(await obterLancamento(c, r.id)), repetido: r.repetido };
  },
});

tool<EntradaTransferir & { chave_idempotencia: string }>({
  nome: 'financeiro.transferir', modulo: 'financeiro', titulo: 'Transferir entre contas', tipo: 'escrita', permissao: 'financeiro.criar',
  descricao: 'Transfere valor em centavos entre duas contas ativas da mesma moeda, realizado na data informada. chave_idempotencia obrigatoria. Publica lancamento.registrado.',
  entrada: { type: 'object', required: ['conta_origem_id', 'conta_destino_id', 'valor_centavos', 'data', 'chave_idempotencia'], properties: { ...propsTransferencia, chave_idempotencia: chaveIdempotencia } },
  executar: async ({ c, ator, ip }, a) => {
    const r = exigirOk(await casosDeUso(c).transferir.execute(contextoPg(c, ator, ip), a));
    return { ...(await obterLancamento(c, r.id)), repetido: r.repetido };
  },
});

tool<{ id: string; motivo?: string }>({
  nome: 'lancamentos.estornar', modulo: 'financeiro', titulo: 'Estornar lancamento', tipo: 'escrita', permissao: 'financeiro.estornar',
  descricao: 'Estorna um lancamento ativo: nada e apagado, um lancamento inverso e gerado e o original fica estornado. Publica lancamento.estornado.',
  entrada: { type: 'object', required: ['id'], properties: { id: uuid, motivo: { type: 'string', maxLength: 200 } } },
  rota: { metodo: 'POST', caminho: '/api/v1/financeiro/lancamentos/:id/estorno' },
  executar: async ({ c, ator, ip }, a) => {
    const { estorno_id } = exigirOk(await casosDeUso(c).estornarLancamento.execute(contextoPg(c, ator, ip), a));
    return { original: await obterLancamento(c, a.id), estorno: await obterLancamento(c, estorno_id) };
  },
});

tool<FiltroFluxo>({
  nome: 'financeiro.fluxo_caixa', modulo: 'financeiro', titulo: 'Fluxo de caixa', tipo: 'leitura', permissao: 'financeiro.ver',
  descricao: 'Fluxo de caixa realizado e previsto (centavos) por dia, semana ou mes, com saldo inicial, saldo acumulado e titulos em aberto do modulo Contas. Filtra por conta.',
  entrada: { type: 'object', properties: filtroFluxo },
  rota: { metodo: 'GET', caminho: '/api/v1/financeiro/fluxo-caixa' },
  executar: ({ c }, a) => fluxoDeCaixa(c, a),
});

tool<{ estado?: 'ativa' | 'arquivada' | 'todas' }>({
  nome: 'financeiro.contas', modulo: 'financeiro', titulo: 'Listar contas e caixas', tipo: 'leitura', permissao: 'financeiro.ver',
  descricao: 'Contas bancarias e caixas com saldo atual, valor a realizar e itens de extrato pendentes de conciliacao.',
  entrada: { type: 'object', properties: { estado: { type: 'string', enum: ['ativa', 'arquivada', 'todas'], default: 'ativa' } } },
  rota: { metodo: 'GET', caminho: '/api/v1/financeiro/contas' },
  executar: ({ c }, a) => listarContas(c, a),
});

tool<{ natureza?: 'receita' | 'despesa'; ativas?: boolean }>({
  nome: 'financeiro.categorias', modulo: 'financeiro', titulo: 'Listar categorias', tipo: 'leitura', permissao: 'financeiro.ver',
  descricao: 'Arvore de categorias de receita e despesa (lista ordenada com nivel, caminho e uso).',
  entrada: { type: 'object', properties: { natureza: { type: 'string', enum: ['receita', 'despesa'] }, ativas: { type: 'boolean' } } },
  rota: { metodo: 'GET', caminho: '/api/v1/financeiro/categorias' },
  executar: ({ c }, a) => listarCategorias(c, a),
});

tool<{ id: string; lancamento_id: string }>({
  nome: 'financeiro.conciliar', modulo: 'financeiro', titulo: 'Conciliar item do extrato', tipo: 'escrita', permissao: 'financeiro.conciliar',
  descricao: 'Confirma o par entre um item do extrato bancario e um lancamento (mesma conta e mesmo valor). Lancamento previsto passa a realizado na data do extrato.',
  entrada: { type: 'object', required: ['id', 'lancamento_id'], properties: { id: uuid, lancamento_id: uuid } },
  rota: { metodo: 'POST', caminho: '/api/v1/financeiro/extrato-itens/:id/conciliar' },
  executar: async ({ c, ator, ip }, a) => {
    exigirOk(await casosDeUso(c).conciliar.execute(contextoPg(c, ator, ip), { item_id: a.id, lancamento_id: a.lancamento_id }));
    return obterLancamento(c, a.lancamento_id);
  },
});
