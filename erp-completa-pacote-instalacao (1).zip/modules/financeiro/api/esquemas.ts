/** JSON Schemas dos DTOs de entrada (viram validacao Fastify, OpenAPI em /docs e schema das tools MCP). */
export const uuid = { type: 'string', format: 'uuid' } as const;
const uuidNulo = { type: ['string', 'null'], format: 'uuid' } as const;
const texto = (max: number) => ({ type: ['string', 'null'], maxLength: max });
const data = { type: 'string', format: 'date' } as const;
const dataNula = { type: ['string', 'null'], format: 'date' } as const;
const centavos = { type: 'integer', minimum: 1, maximum: 900_000_000_000_000, description: 'Valor em centavos (inteiro, nunca float): R$ 12,34 = 1234' } as const;

export const tiposConta = ['banco', 'caixa', 'carteira', 'investimento'] as const;
export const propsConta = {
  nome: { type: 'string', minLength: 2, maxLength: 120 },
  tipo: { type: 'string', enum: [...tiposConta] },
  banco_codigo: { ...texto(3), description: 'Codigo COMPE de 3 digitos (341, 001, 237)' },
  banco_nome: texto(120),
  agencia: texto(8),
  numero: texto(15),
  moeda: { type: 'string', pattern: '^[A-Z]{3}$' },
  saldo_inicial_centavos: { type: 'integer', minimum: -900_000_000_000_000, maximum: 900_000_000_000_000 },
  data_saldo_inicial: data,
  extras: { type: 'object', description: 'Campos personalizados (modulo financeiro, entidade conta)' },
} as const;

export const naturezas = ['receita', 'despesa'] as const;
export const propsCategoria = {
  nome: { type: 'string', minLength: 2, maxLength: 80 },
  natureza: { type: 'string', enum: [...naturezas] },
  parent_id: uuidNulo,
  codigo: texto(20),
} as const;

export const propsCentroCusto = {
  codigo: { type: 'string', minLength: 1, maxLength: 20 },
  nome: { type: 'string', minLength: 2, maxLength: 120 },
  descricao: texto(500),
} as const;

export const propsLancamento = {
  tipo: { type: 'string', enum: ['entrada', 'saida'], description: 'entrada ou saida (transferencia usa /transferencias)' },
  descricao: { type: 'string', minLength: 2, maxLength: 200 },
  conta_id: uuid,
  categoria_id: uuidNulo,
  centro_custo_id: uuidNulo,
  parceiro_id: { ...uuidNulo, description: 'Cliente ou fornecedor (cadastros_parceiros)' },
  valor_centavos: centavos,
  moeda: { type: 'string', pattern: '^[A-Z]{3}$', description: 'Padrao: moeda da conta' },
  data_competencia: data,
  data_caixa: { ...dataNula, description: 'Vazio = previsto (ainda nao pago ou recebido)' },
  extras: { type: 'object', description: 'Campos personalizados (modulo financeiro, entidade lancamento)' },
} as const;

export const propsEdicaoLancamento = {
  descricao: propsLancamento.descricao,
  categoria_id: uuidNulo,
  centro_custo_id: uuidNulo,
  parceiro_id: uuidNulo,
  data_competencia: data,
  data_caixa: dataNula,
  extras: { type: 'object' },
} as const;

export const propsTransferencia = {
  conta_origem_id: uuid,
  conta_destino_id: uuid,
  valor_centavos: centavos,
  data,
  descricao: texto(200),
  centro_custo_id: uuidNulo,
} as const;

export const chaveIdempotencia = { type: 'string', minLength: 8, maxLength: 200, description: 'Idempotency-Key: repetir a mesma chave nao duplica o lancamento' } as const;

export const filtroLancamentos = {
  tipo: { type: 'string', enum: ['entrada', 'saida', 'transferencia'] },
  conta_id: uuid,
  categoria_id: uuid,
  centro_custo_id: uuid,
  parceiro_id: uuid,
  situacao: { type: 'string', enum: ['realizado', 'previsto', 'todos'], default: 'todos' },
  estado: { type: 'string', enum: ['ativo', 'estornado', 'todos'], default: 'todos' },
  conciliado: { type: 'boolean' },
  de: data,
  ate: data,
  busca: { type: 'string', maxLength: 120 },
  limite: { type: 'integer', minimum: 1, maximum: 200, default: 50 },
  cursor: { type: 'string', maxLength: 200 },
} as const;

export const filtroFluxo = {
  de: data,
  ate: data,
  conta_id: uuid,
  agrupamento: { type: 'string', enum: ['dia', 'semana', 'mes'], default: 'mes' },
  moeda: { type: 'string', pattern: '^[A-Z]{3}$', default: 'BRL' },
} as const;
