/**
 * Fluxo de caixa (M4.5): realizado (data de caixa) e previsto (lancamentos sem data de caixa, pela
 * competencia, mais titulos em aberto do modulo Contas quando instalado), por periodo e por conta.
 * Valores em centavos. Sem filtro de conta, transferencias entre contas nao entram (efeito zero).
 */
import type pg from 'pg';
import { SQL_SALDO } from '../../conta/query/contas.ts';

export type Agrupamento = 'dia' | 'semana' | 'mes';
const TRUNC: Record<Agrupamento, string> = { dia: 'day', semana: 'week', mes: 'month' };

export interface FiltroFluxo {
  de?: string;
  ate?: string;
  conta_id?: string;
  agrupamento?: Agrupamento;
  moeda?: string;
}

export interface LinhaFluxo {
  periodo: string;
  entradas_realizadas: number;
  saidas_realizadas: number;
  entradas_previstas: number;
  saidas_previstas: number;
  saldo_realizado: number;
  saldo_projetado: number;
}

const EFEITO = `CASE WHEN l.tipo = 'entrada' THEN l.valor_centavos WHEN l.tipo = 'saida' THEN -l.valor_centavos
  WHEN $4::uuid IS NULL THEN 0 WHEN l.conta_destino_id = $4 THEN l.valor_centavos ELSE -l.valor_centavos END`;

function periodoPadrao(): { de: string; ate: string } {
  const h = new Date();
  const de = new Date(Date.UTC(h.getUTCFullYear(), h.getUTCMonth() - 2, 1));
  const ate = new Date(Date.UTC(h.getUTCFullYear(), h.getUTCMonth() + 4, 0));
  return { de: de.toISOString().slice(0, 10), ate: ate.toISOString().slice(0, 10) };
}

/** Titulos em aberto do modulo Contas (tabela publicada contas_documentos), lidos so se a tabela existir. */
async function titulosEmAberto(c: pg.PoolClient, de: string, ate: string, trunc: string): Promise<{ p: string; v: number }[]> {
  const existe = (await c.query("SELECT to_regclass('contas_documentos') IS NOT NULL AS ok")).rows[0]?.ok as boolean;
  if (!existe) return [];
  const cols = new Set((await c.query("SELECT column_name FROM information_schema.columns WHERE table_name = 'contas_documentos'")).rows.map((r) => r.column_name as string));
  const valor = cols.has('saldo_centavos') ? 'd.saldo_centavos' : cols.has('valor_centavos') ? 'd.valor_centavos' : cols.has('valor') ? 'round(d.valor * 100)' : null;
  if (!valor || !cols.has('vencimento') || !cols.has('tipo') || !cols.has('estado')) return [];
  await c.query('SAVEPOINT financeiro_fluxo_contas');
  try {
    const r = await c.query(
      `SELECT to_char(date_trunc($3, d.vencimento), 'YYYY-MM-DD') AS p,
         sum(CASE WHEN d.tipo IN ('fatura', 'receber', 'a_receber') THEN ${valor} WHEN d.tipo IN ('conta_pagar', 'pagar', 'a_pagar', 'reembolso') THEN -${valor} ELSE 0 END)::float8 AS v
       FROM contas_documentos d
       WHERE d.vencimento BETWEEN $1::date AND $2::date AND d.estado NOT IN ('pago', 'paga', 'cancelado', 'cancelada', 'rascunho')
         ${cols.has('deleted_at') ? 'AND d.deleted_at IS NULL' : ''}
       GROUP BY 1`, [de, ate, trunc]);
    await c.query('RELEASE SAVEPOINT financeiro_fluxo_contas');
    return r.rows as { p: string; v: number }[];
  } catch {
    await c.query('ROLLBACK TO SAVEPOINT financeiro_fluxo_contas');
    return [];
  }
}

export async function fluxoDeCaixa(c: pg.PoolClient, f: FiltroFluxo) {
  const padrao = periodoPadrao();
  const de = f.de ?? padrao.de;
  const ate = f.ate ?? padrao.ate;
  const agrupamento: Agrupamento = f.agrupamento ?? 'mes';
  const trunc = TRUNC[agrupamento];
  const moeda = f.moeda ?? 'BRL';
  const conta = f.conta_id ?? null;

  const inicial = (await c.query(
    `SELECT coalesce(sum(${SQL_SALDO('k', '($1::date - 1)')}), 0)::float8 AS s FROM financeiro_contas k
     WHERE k.deleted_at IS NULL AND k.moeda = $2 AND ($3::uuid IS NULL OR k.id = $3)`,
    [de, moeda, conta])).rows[0].s as number;

  const periodos = (await c.query(
    `SELECT to_char(g, 'YYYY-MM-DD') AS p FROM generate_series(date_trunc($3, $1::date), date_trunc($3, $2::date), ('1 ' || $3)::interval) g`,
    [de, ate, trunc])).rows.map((r) => r.p as string);

  const mov = await c.query(
    `SELECT to_char(date_trunc($3, coalesce(l.data_caixa, l.data_competencia)), 'YYYY-MM-DD') AS p, (l.data_caixa IS NOT NULL) AS realizado,
       sum(CASE WHEN (${EFEITO}) > 0 THEN (${EFEITO}) ELSE 0 END)::float8 AS entradas,
       sum(CASE WHEN (${EFEITO}) < 0 THEN -(${EFEITO}) ELSE 0 END)::float8 AS saidas
     FROM financeiro_lancamentos l
     WHERE l.deleted_at IS NULL AND l.moeda = $5 AND ($4::uuid IS NULL OR l.conta_id = $4 OR l.conta_destino_id = $4)
       AND coalesce(l.data_caixa, l.data_competencia) BETWEEN $1::date AND $2::date
     GROUP BY 1, 2`,
    [de, ate, trunc, conta, moeda]);

  const linhas = new Map<string, LinhaFluxo>(periodos.map((p) => [p, {
    periodo: p, entradas_realizadas: 0, saidas_realizadas: 0, entradas_previstas: 0, saidas_previstas: 0, saldo_realizado: 0, saldo_projetado: 0,
  }]));
  for (const m of mov.rows) {
    const l = linhas.get(m.p);
    if (!l) continue;
    if (m.realizado) { l.entradas_realizadas += Number(m.entradas); l.saidas_realizadas += Number(m.saidas); }
    else { l.entradas_previstas += Number(m.entradas); l.saidas_previstas += Number(m.saidas); }
  }
  const titulos = conta === null && moeda === 'BRL' ? await titulosEmAberto(c, de, ate, trunc) : [];
  for (const t of titulos) {
    const l = linhas.get(t.p);
    if (!l) continue;
    if (t.v > 0) l.entradas_previstas += t.v; else l.saidas_previstas += -t.v;
  }
  let realizado = inicial;
  let projetado = inicial;
  for (const l of linhas.values()) {
    realizado += l.entradas_realizadas - l.saidas_realizadas;
    projetado += l.entradas_realizadas - l.saidas_realizadas + l.entradas_previstas - l.saidas_previstas;
    l.saldo_realizado = realizado;
    l.saldo_projetado = projetado;
  }
  const lista = [...linhas.values()];
  const soma = (k: keyof LinhaFluxo) => lista.reduce((a, l) => a + (l[k] as number), 0);
  return {
    de, ate, agrupamento, moeda, conta_id: conta, saldo_inicial: inicial, inclui_titulos_contas: titulos.length > 0, linhas: lista,
    totais: {
      entradas_realizadas: soma('entradas_realizadas'), saidas_realizadas: soma('saidas_realizadas'),
      entradas_previstas: soma('entradas_previstas'), saidas_previstas: soma('saidas_previstas'),
      saldo_final_realizado: realizado, saldo_final_projetado: projetado,
    },
  };
}
