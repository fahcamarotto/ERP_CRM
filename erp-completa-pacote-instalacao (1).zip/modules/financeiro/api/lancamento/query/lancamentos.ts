/** Consultas de leitura do Lancamento: lista com nomes de exibicao, filtros e cursor; ficha com estorno e comprovante. */
import type pg from 'pg';
import { decodificarCursor, pagina } from '../../compartilhado/cursor.ts';

const RESUMO = `l.id, l.tipo, l.descricao, l.conta_id, k.nome AS conta_nome, l.conta_destino_id, kd.nome AS conta_destino_nome,
  l.categoria_id, cat.nome AS categoria_nome, cat.natureza AS categoria_natureza, l.centro_custo_id, cc.codigo AS centro_custo_codigo,
  cc.nome AS centro_custo_nome, l.parceiro_id, p.nome AS parceiro_nome, l.valor_centavos::float8 AS valor_centavos, l.moeda,
  to_char(l.data_competencia, 'YYYY-MM-DD') AS data_competencia, to_char(l.data_caixa, 'YYYY-MM-DD') AS data_caixa,
  l.comprovante_anexo_id, l.conciliado, l.conciliado_em, l.estado, l.estorno_de_id, l.origem, l.created_at, l.updated_at,
  (SELECT e.id FROM financeiro_lancamentos e WHERE e.estorno_de_id = l.id AND e.deleted_at IS NULL) AS estornado_por_id`;

const JUNCOES = `FROM financeiro_lancamentos l
  JOIN financeiro_contas k ON k.id = l.conta_id
  LEFT JOIN financeiro_contas kd ON kd.id = l.conta_destino_id
  LEFT JOIN financeiro_categorias cat ON cat.id = l.categoria_id
  LEFT JOIN financeiro_centros_custo cc ON cc.id = l.centro_custo_id
  LEFT JOIN cadastros_parceiros p ON p.id = l.parceiro_id AND p.deleted_at IS NULL`;

export interface FiltroLancamentos {
  tipo?: 'entrada' | 'saida' | 'transferencia';
  conta_id?: string;
  categoria_id?: string;
  centro_custo_id?: string;
  parceiro_id?: string;
  situacao?: 'realizado' | 'previsto' | 'todos';
  estado?: 'ativo' | 'estornado' | 'todos';
  conciliado?: boolean;
  de?: string;
  ate?: string;
  busca?: string;
  limite?: number;
  cursor?: string;
}

/** Filtro de periodo pela data de caixa (realizado) ou de competencia (previsto). */
export async function listarLancamentos(c: pg.PoolClient, f: FiltroLancamentos) {
  const lim = Math.min(Math.max(f.limite ?? 50, 1), 200);
  const cur = decodificarCursor(f.cursor);
  const r = await c.query(
    `SELECT ${RESUMO} ${JUNCOES}
     WHERE l.deleted_at IS NULL AND ($1::text IS NULL OR l.tipo = $1)
       AND ($2::uuid IS NULL OR l.conta_id = $2 OR l.conta_destino_id = $2) AND ($3::uuid IS NULL OR l.categoria_id = $3)
       AND ($4::uuid IS NULL OR l.centro_custo_id = $4) AND ($5::uuid IS NULL OR l.parceiro_id = $5)
       AND ($6::text = 'todos' OR ($6 = 'realizado') = (l.data_caixa IS NOT NULL))
       AND ($7::text = 'todos' OR l.estado = $7) AND ($8::boolean IS NULL OR l.conciliado = $8)
       AND ($9::date IS NULL OR coalesce(l.data_caixa, l.data_competencia) >= $9) AND ($10::date IS NULL OR coalesce(l.data_caixa, l.data_competencia) <= $10)
       AND ($11::text IS NULL OR l.descricao ILIKE '%' || $11 || '%' OR p.nome ILIKE '%' || $11 || '%' OR cat.nome ILIKE '%' || $11 || '%')
       AND ($12::timestamptz IS NULL OR (l.created_at, l.id) < ($12::timestamptz, $13::uuid))
     ORDER BY l.created_at DESC, l.id DESC LIMIT $14`,
    [f.tipo ?? null, f.conta_id ?? null, f.categoria_id ?? null, f.centro_custo_id ?? null, f.parceiro_id ?? null, f.situacao ?? 'todos',
      f.estado ?? 'todos', f.conciliado ?? null, f.de ?? null, f.ate ?? null, f.busca?.trim() || null, cur?.[0] ?? null, cur?.[1] ?? null, lim + 1],
  );
  return pagina(r.rows, lim);
}

export async function obterLancamento(c: pg.PoolClient, id: string) {
  const r = await c.query(
    `SELECT ${RESUMO}, l.extras, a.nome AS comprovante_nome,
       (SELECT json_build_object('id', i.id, 'data', to_char(i.data, 'YYYY-MM-DD'), 'descricao', i.descricao)
        FROM financeiro_extrato_itens i WHERE i.lancamento_id = l.id AND i.deleted_at IS NULL) AS extrato_item
     ${JUNCOES} LEFT JOIN anexos a ON a.id = l.comprovante_anexo_id AND a.deleted_at IS NULL
     WHERE l.id = $1 AND l.deleted_at IS NULL`, [id]);
  return r.rows[0] ?? null;
}
