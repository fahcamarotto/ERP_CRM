/**
 * Agregado Lancamento (M4.3): entrada, saida ou transferencia, valor em Dinheiro (centavos, nunca float),
 * competencia e caixa. Data de caixa vazia = previsto (ainda nao realizado). Lancamento nunca e apagado:
 * o estorno gera outro lancamento com o sentido invertido e marca o original como estornado.
 * Imutavel: toda alteracao devolve um clone novo.
 */
import { randomUUID } from 'node:crypto';
import { DataIso, Dinheiro } from '../../compartilhado/dinheiro.ts';
import { combinar, erroDe, fail, ok, type ErroDominio, type Result } from '../../compartilhado/result.ts';

export const TIPOS_LANCAMENTO = ['entrada', 'saida', 'transferencia'] as const;
export type TipoLancamento = (typeof TIPOS_LANCAMENTO)[number];
export const ESTADOS_LANCAMENTO = ['ativo', 'estornado'] as const;
export type EstadoLancamento = (typeof ESTADOS_LANCAMENTO)[number];
export const ORIGENS = ['manual', 'transferencia', 'estorno', 'extrato', 'contas', 'seed'] as const;
export type OrigemLancamento = (typeof ORIGENS)[number];

/** Maquina de estados: ativo vira estornado (uma vez); estornado e final. */
export const TRANSICOES: Record<EstadoLancamento, EstadoLancamento[]> = { ativo: ['estornado'], estornado: [] };

export interface DadosLancamento {
  tipo: TipoLancamento;
  descricao: string;
  conta_id: string;
  conta_destino_id?: string | null;
  categoria_id?: string | null;
  centro_custo_id?: string | null;
  parceiro_id?: string | null;
  valor_centavos: number;
  moeda?: string;
  data_competencia: string;
  data_caixa?: string | null;
  origem?: OrigemLancamento;
  chave_idempotencia?: string | null;
  extras?: Record<string, unknown>;
}

/** Campos editaveis depois do registro (valor, conta, tipo e moeda nunca mudam: corrige-se por estorno). */
export type EdicaoLancamento = Partial<Pick<DadosLancamento, 'descricao' | 'categoria_id' | 'centro_custo_id' | 'parceiro_id' | 'data_competencia' | 'data_caixa' | 'extras'>>;

export interface LancamentoDados {
  id: string;
  tipo: TipoLancamento;
  descricao: string;
  conta_id: string;
  conta_destino_id: string | null;
  categoria_id: string | null;
  centro_custo_id: string | null;
  parceiro_id: string | null;
  valor_centavos: number;
  moeda: string;
  data_competencia: string;
  data_caixa: string | null;
  comprovante_anexo_id: string | null;
  conciliado: boolean;
  estado: EstadoLancamento;
  estorno_de_id: string | null;
  origem: OrigemLancamento;
  chave_idempotencia: string | null;
  extras: Record<string, unknown>;
}

const t = (v?: string | null) => (v ?? '').trim() || null;

function validar(d: LancamentoDados): ErroDominio[] {
  const e: ErroDominio[] = [];
  if (!TIPOS_LANCAMENTO.includes(d.tipo)) e.push(erroDe('tipo_invalido', 'Tipo deve ser entrada, saida ou transferencia', 'tipo'));
  if (d.descricao.length < 2 || d.descricao.length > 200) e.push(erroDe('descricao_invalida', 'Descricao deve ter de 2 a 200 caracteres', 'descricao'));
  if (!d.conta_id) e.push(erroDe('conta_obrigatoria', 'Informe a conta', 'conta_id'));
  if (d.tipo === 'transferencia') {
    if (!d.conta_destino_id) e.push(erroDe('conta_destino_obrigatoria', 'Transferencia exige conta de destino', 'conta_destino_id'));
    else if (d.conta_destino_id === d.conta_id) e.push(erroDe('mesma_conta', 'Origem e destino devem ser contas diferentes', 'conta_destino_id'));
  } else if (d.conta_destino_id) {
    e.push(erroDe('conta_destino_indevida', 'Conta de destino so existe em transferencia', 'conta_destino_id'));
  }
  if (d.chave_idempotencia !== null && (d.chave_idempotencia.length < 8 || d.chave_idempotencia.length > 200)) {
    e.push(erroDe('chave_idempotencia_invalida', 'Idempotency-Key deve ter de 8 a 200 caracteres', 'chave_idempotencia'));
  }
  if (!ORIGENS.includes(d.origem)) e.push(erroDe('origem_invalida', 'Origem invalida', 'origem'));
  return e;
}

export class Lancamento {
  private constructor(private readonly d: LancamentoDados) {}

  static tryCreate(e: DadosLancamento, id: string = randomUUID()): Result<Lancamento> {
    const valor = Dinheiro.tryCreate(e.valor_centavos, e.moeda ?? 'BRL');
    const competencia = DataIso.tryCreate(e.data_competencia, 'data_competencia');
    const caixa = t(e.data_caixa) === null ? ok(null) : DataIso.tryCreate(e.data_caixa, 'data_caixa');
    const vos = combinar(valor, competencia, caixa);
    const d: LancamentoDados = {
      id, tipo: e.tipo, descricao: (e.descricao ?? '').trim(), conta_id: t(e.conta_id) ?? '', conta_destino_id: t(e.conta_destino_id),
      categoria_id: t(e.categoria_id), centro_custo_id: t(e.centro_custo_id), parceiro_id: t(e.parceiro_id),
      valor_centavos: vos.ok ? vos.valor[0].centavos : 0, moeda: vos.ok ? vos.valor[0].moeda : 'BRL',
      data_competencia: vos.ok ? vos.valor[1].valor : '', data_caixa: vos.ok ? vos.valor[2]?.valor ?? null : null,
      comprovante_anexo_id: null, conciliado: false, estado: 'ativo', estorno_de_id: null, origem: e.origem ?? 'manual',
      chave_idempotencia: t(e.chave_idempotencia), extras: e.extras ?? {},
    };
    const erros = [...(vos.ok ? [] : vos.erros), ...validar(d)];
    return erros.length ? fail(...erros) : ok(new Lancamento(d));
  }

  static create(e: DadosLancamento, id?: string): Lancamento {
    const r = Lancamento.tryCreate(e, id);
    if (!r.ok) throw new Error(r.erros.map((x) => x.mensagem).join('; '));
    return r.valor;
  }

  static reidratar(d: LancamentoDados): Lancamento {
    return new Lancamento({ ...d, valor_centavos: Number(d.valor_centavos), extras: { ...d.extras } });
  }

  get id(): string { return this.d.id; }
  get tipo(): TipoLancamento { return this.d.tipo; }
  get estado(): EstadoLancamento { return this.d.estado; }
  get conciliado(): boolean { return this.d.conciliado; }
  get valor(): Dinheiro { return Dinheiro.create(this.d.valor_centavos, this.d.moeda); }
  get realizado(): boolean { return this.d.data_caixa !== null; }

  /** Efeito com sinal (centavos) do lancamento sobre uma conta: + entra, - sai, 0 nao toca a conta. */
  efeitoNaConta(contaId: string): number {
    if (this.d.tipo === 'entrada') return this.d.conta_id === contaId ? this.d.valor_centavos : 0;
    if (this.d.tipo === 'saida') return this.d.conta_id === contaId ? -this.d.valor_centavos : 0;
    if (this.d.conta_destino_id === contaId) return this.d.valor_centavos;
    return this.d.conta_id === contaId ? -this.d.valor_centavos : 0;
  }

  editar(e: EdicaoLancamento): Result<Lancamento> {
    if (this.d.estado === 'estornado') return fail(erroDe('transicao_invalida', 'Lancamento estornado nao pode ser editado'));
    const tem = (k: keyof EdicaoLancamento) => e[k] !== undefined;
    if (this.d.conciliado && tem('data_caixa') && t(e.data_caixa) !== this.d.data_caixa) {
      return fail(erroDe('lancamento_conciliado', 'Lancamento conciliado: a data de caixa vem do extrato', 'data_caixa'));
    }
    const competencia = tem('data_competencia') ? DataIso.tryCreate(e.data_competencia, 'data_competencia') : ok(null);
    const caixa = tem('data_caixa') && t(e.data_caixa) !== null ? DataIso.tryCreate(e.data_caixa, 'data_caixa') : ok(null);
    const vos = combinar(competencia, caixa);
    if (!vos.ok) return vos;
    const n: LancamentoDados = {
      ...this.d,
      descricao: tem('descricao') ? (e.descricao ?? '').trim() : this.d.descricao,
      categoria_id: tem('categoria_id') ? t(e.categoria_id) : this.d.categoria_id,
      centro_custo_id: tem('centro_custo_id') ? t(e.centro_custo_id) : this.d.centro_custo_id,
      parceiro_id: tem('parceiro_id') ? t(e.parceiro_id) : this.d.parceiro_id,
      data_competencia: vos.valor[0]?.valor ?? this.d.data_competencia,
      data_caixa: tem('data_caixa') ? vos.valor[1]?.valor ?? null : this.d.data_caixa,
      extras: tem('extras') ? { ...e.extras } : { ...this.d.extras },
    };
    const erros = validar(n);
    return erros.length ? fail(...erros) : ok(new Lancamento(n));
  }

  /**
   * Estorno: devolve o original marcado como estornado e o lancamento inverso (entrada vira saida,
   * saida vira entrada, transferencia troca origem e destino). Previsto estornado continua previsto.
   */
  estornar(hoje: string, motivo: string | null = null, idEstorno: string = randomUUID()): Result<{ original: Lancamento; estorno: Lancamento }> {
    if (this.d.origem === 'estorno') return fail(erroDe('transicao_invalida', 'Estorno nao pode ser estornado', 'estado'));
    if (!TRANSICOES[this.d.estado].includes('estornado')) {
      return fail(erroDe('transicao_invalida', 'Lancamento ja foi estornado', 'estado', { permitidas: TRANSICOES[this.d.estado] }));
    }
    const inverso: TipoLancamento = this.d.tipo === 'entrada' ? 'saida' : this.d.tipo === 'saida' ? 'entrada' : 'transferencia';
    const desc = `Estorno: ${this.d.descricao}${motivo ? ` (${motivo})` : ''}`.slice(0, 200);
    const estorno = new Lancamento({
      ...this.d, id: idEstorno, tipo: inverso, descricao: desc,
      conta_id: this.d.tipo === 'transferencia' ? this.d.conta_destino_id! : this.d.conta_id,
      conta_destino_id: this.d.tipo === 'transferencia' ? this.d.conta_id : null,
      data_competencia: hoje, data_caixa: this.d.data_caixa === null ? null : hoje, comprovante_anexo_id: null, conciliado: false,
      estado: 'ativo', estorno_de_id: this.d.id, origem: 'estorno', chave_idempotencia: null, extras: {},
    });
    return ok({ original: new Lancamento({ ...this.d, estado: 'estornado' }), estorno });
  }

  /** Conciliacao com item de extrato: marca conciliado e, se previsto, realiza na data do extrato. */
  conciliar(dataExtrato: string): Result<Lancamento> {
    if (this.d.estado !== 'ativo') return fail(erroDe('transicao_invalida', 'Lancamento estornado nao pode ser conciliado', 'estado'));
    if (this.d.conciliado) return fail(erroDe('conflito', 'Lancamento ja conciliado', 'lancamento_id'));
    return ok(new Lancamento({ ...this.d, conciliado: true, data_caixa: this.d.data_caixa ?? dataExtrato }));
  }

  anexarComprovante(anexoId: string): Result<Lancamento> {
    if (!/^[0-9a-f-]{36}$/i.test(anexoId)) return fail(erroDe('anexo_invalido', 'Anexo invalido', 'anexo_id'));
    return ok(new Lancamento({ ...this.d, comprovante_anexo_id: anexoId }));
  }

  paraDados(): LancamentoDados {
    return { ...this.d, extras: { ...this.d.extras } };
  }
}

/** Payload publicado em lancamento.registrado (CONTRATOS 7.1.x do Financeiro). */
export function payloadRegistrado(d: LancamentoDados): Record<string, unknown> {
  return {
    id: d.id, tipo: d.tipo, descricao: d.descricao, conta_id: d.conta_id, conta_destino_id: d.conta_destino_id, categoria_id: d.categoria_id,
    centro_custo_id: d.centro_custo_id, parceiro_id: d.parceiro_id, valor_centavos: d.valor_centavos, moeda: d.moeda,
    data_competencia: d.data_competencia, data_caixa: d.data_caixa, origem: d.origem, estorno_de_id: d.estorno_de_id,
  };
}
