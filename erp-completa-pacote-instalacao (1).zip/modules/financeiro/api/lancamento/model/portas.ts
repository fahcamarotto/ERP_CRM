/** Portas do repositorio do agregado Lancamento, segregadas por operacao. */
import type { Lancamento } from './lancamento.ts';

export interface ObterLancamento {
  obterPorId(id: string): Promise<Lancamento | null>;
}

export interface GravarLancamento {
  inserir(l: Lancamento): Promise<void>;
  atualizar(l: Lancamento): Promise<void>;
}

/** Idempotencia: mesma Idempotency-Key devolve o lancamento ja registrado. */
export interface BuscarPorChave {
  buscarPorChave(chave: string): Promise<Lancamento | null>;
}

/** Referencias fora do agregado: contas, categorias e centros do modulo, parceiro do Cadastros, anexo do nucleo. */
export interface ConsultarReferenciasLancamento {
  conta(id: string): Promise<{ ativa: boolean; moeda: string } | null>;
  categoria(id: string): Promise<{ natureza: 'receita' | 'despesa'; ativa: boolean } | null>;
  centroAtivo(id: string): Promise<boolean>;
  parceiroAtivo(id: string): Promise<boolean>;
  anexoDoLancamento(anexoId: string, lancamentoId: string): Promise<boolean>;
}
