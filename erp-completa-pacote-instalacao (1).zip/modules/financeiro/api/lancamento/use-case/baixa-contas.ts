/** Traducao do evento fatura.paga (modulo Contas, M5.2) na entrada do RegistrarLancamento. Funcao pura. */
import { Dinheiro } from '../../compartilhado/dinheiro.ts';
import type { DadosLancamento } from '../model/lancamento.ts';

/**
 * Converte os dados de fatura.paga (modulo Contas, M5.2) na entrada do RegistrarLancamento.
 * Contrato em docs/CONTRATOS.md 7.1.x do Financeiro. Devolve null quando falta valor ou data.
 */
export function lancamentoDaBaixa(evento: { id: string; dados?: Record<string, unknown> }, contaPadrao: string | null): DadosLancamento | null {
  const d = evento.dados ?? {};
  const s = (...ks: string[]) => { for (const k of ks) { const v = d[k]; if (typeof v === 'string' && v.trim()) return v.trim(); } return null; };
  const n = (...ks: string[]) => { for (const k of ks) { const v = d[k]; if (typeof v === 'number' && Number.isFinite(v)) return v; } return null; };
  let centavos = n('valor_pago_centavos', 'valor_centavos');
  if (centavos === null) {
    const bruto = d.valor_pago ?? d.valor;
    if (typeof bruto === 'number' || typeof bruto === 'string') {
      const r = Dinheiro.centavosDeTexto(typeof bruto === 'number' ? bruto.toFixed(2) : bruto);
      centavos = r.ok ? r.valor : null;
    }
  }
  const data = (s('data_pagamento', 'pago_em', 'data') ?? '').slice(0, 10) || null;
  const conta = s('conta_financeira_id', 'conta_id') ?? contaPadrao;
  if (!centavos || !data || !conta) return null;
  const tipoDoc = (s('tipo') ?? 'fatura').toLowerCase();
  const saida = ['conta_pagar', 'pagar', 'a_pagar', 'reembolso'].includes(tipoDoc) || centavos < 0;
  const numero = s('numero');
  return {
    tipo: saida ? 'saida' : 'entrada',
    descricao: `${saida ? 'Pagamento' : 'Recebimento'}${numero ? ` do documento ${numero}` : ' de documento'}`.slice(0, 200),
    conta_id: conta, categoria_id: s('categoria_id'), centro_custo_id: s('centro_custo_id'), parceiro_id: s('parceiro_id'),
    valor_centavos: Math.abs(Math.round(centavos)), moeda: s('moeda') ?? undefined, data_competencia: data, data_caixa: data,
    origem: 'contas', chave_idempotencia: `contas:${evento.id}`,
  };
}
