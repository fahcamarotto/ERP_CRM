/**
 * RegistrarLancamento e Transferir (M4.6). Idempotentes pela Idempotency-Key: repetir a mesma chave
 * devolve o lancamento ja gravado (repetido: true) sem gravar de novo nem publicar evento outra vez.
 */
import type { ContextoCaso } from '../../compartilhado/efeitos.ts';
import { fail, ok, type Result } from '../../compartilhado/result.ts';
import { Lancamento, payloadRegistrado, type DadosLancamento } from '../model/lancamento.ts';
import type { BuscarPorChave, ConsultarReferenciasLancamento, GravarLancamento, ObterLancamento } from '../model/portas.ts';
import { conferirReferencias } from './regras-referencia.ts';

export const TABELA = 'financeiro_lancamentos';
export interface DepsLancamento {
  repo: ObterLancamento & GravarLancamento & BuscarPorChave;
  refs: ConsultarReferenciasLancamento;
}
export type Registrado = { id: string; repetido: boolean };

async function registrar(deps: DepsLancamento, ctx: ContextoCaso, e: DadosLancamento, acao: string): Promise<Result<Registrado>> {
  if (e.chave_idempotencia) {
    const ja = await deps.repo.buscarPorChave(e.chave_idempotencia.trim());
    if (ja) return ok({ id: ja.id, repetido: true });
  }
  // Moeda vem da conta quando nao informada.
  const conta = e.conta_id ? await deps.refs.conta(e.conta_id) : null;
  const r = Lancamento.tryCreate({ ...e, moeda: e.moeda ?? conta?.moeda ?? 'BRL' });
  if (!r.ok) return r;
  const d = r.valor.paraDados();
  const erros = await conferirReferencias(deps.refs, d);
  if (erros.length) return fail(...erros);
  await deps.repo.inserir(r.valor);
  await ctx.efeitos.auditar(acao, TABELA, d.id, undefined, d);
  await ctx.efeitos.publicar('lancamento.registrado', payloadRegistrado(d));
  return ok({ id: d.id, repetido: false });
}

export class RegistrarLancamento {
  constructor(private readonly deps: DepsLancamento) {}
  execute(ctx: ContextoCaso, e: DadosLancamento): Promise<Result<Registrado>> {
    return registrar(this.deps, ctx, e, 'lancamento.registrar');
  }
}

export interface EntradaTransferir {
  conta_origem_id: string;
  conta_destino_id: string;
  valor_centavos: number;
  data: string;
  descricao?: string | null;
  centro_custo_id?: string | null;
  chave_idempotencia?: string | null;
}

export class Transferir {
  constructor(private readonly deps: DepsLancamento) {}
  execute(ctx: ContextoCaso, e: EntradaTransferir): Promise<Result<Registrado>> {
    return registrar(this.deps, ctx, {
      tipo: 'transferencia', descricao: (e.descricao ?? '').trim() || 'Transferencia entre contas', conta_id: e.conta_origem_id,
      conta_destino_id: e.conta_destino_id, centro_custo_id: e.centro_custo_id ?? null, valor_centavos: e.valor_centavos,
      data_competencia: e.data, data_caixa: e.data, origem: 'transferencia', chave_idempotencia: e.chave_idempotencia ?? null,
    }, 'lancamento.transferir');
  }
}
