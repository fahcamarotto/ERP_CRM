/** Regras de referencia do Lancamento: conta ativa na mesma moeda, natureza da categoria, centro e parceiro ativos. */
import { erroDe, type ErroDominio } from '../../compartilhado/result.ts';
import type { LancamentoDados } from '../model/lancamento.ts';
import type { ConsultarReferenciasLancamento } from '../model/portas.ts';

/** Confere so o que mudou em relacao ao anterior (edicao nao barra referencia antiga arquivada). */
export async function conferirReferencias(refs: ConsultarReferenciasLancamento, d: LancamentoDados, anterior?: LancamentoDados): Promise<ErroDominio[]> {
  const erros: ErroDominio[] = [];
  const mudou = (k: keyof LancamentoDados) => !anterior || anterior[k] !== d[k];
  if (!anterior) {
    for (const [campo, id] of [['conta_id', d.conta_id], ['conta_destino_id', d.conta_destino_id]] as const) {
      if (!id) continue;
      const conta = await refs.conta(id);
      if (!conta || !conta.ativa) erros.push(erroDe('conta_invalida', 'Conta nao encontrada ou arquivada', campo));
      else if (conta.moeda !== d.moeda) erros.push(erroDe('moeda_divergente', `Conta movimenta ${conta.moeda}; lancamento em ${d.moeda}`, campo));
    }
  }
  if (d.categoria_id && mudou('categoria_id')) {
    const cat = await refs.categoria(d.categoria_id);
    const esperada = d.tipo === 'entrada' ? 'receita' : d.tipo === 'saida' ? 'despesa' : null;
    if (!cat || !cat.ativa) erros.push(erroDe('categoria_invalida', 'Categoria nao encontrada ou inativa', 'categoria_id'));
    else if (esperada && cat.natureza !== esperada && d.origem !== 'estorno') {
      erros.push(erroDe('natureza_divergente', `Lancamento de ${d.tipo} exige categoria de ${esperada}`, 'categoria_id'));
    }
  }
  if (d.centro_custo_id && mudou('centro_custo_id') && !(await refs.centroAtivo(d.centro_custo_id))) {
    erros.push(erroDe('centro_custo_invalido', 'Centro de custo nao encontrado ou inativo', 'centro_custo_id'));
  }
  if (d.parceiro_id && mudou('parceiro_id') && !(await refs.parceiroAtivo(d.parceiro_id))) {
    erros.push(erroDe('parceiro_invalido', 'Parceiro nao encontrado ou arquivado', 'parceiro_id'));
  }
  return erros;
}
