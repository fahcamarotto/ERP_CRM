/** EditarLancamento, EstornarLancamento (nunca apagar) e AnexarComprovante (M4.3 e M4.6). */
import type { ContextoCaso } from '../../compartilhado/efeitos.ts';
import { erroDe, fail, ok, okVazio, type Result } from '../../compartilhado/result.ts';
import { payloadRegistrado, type EdicaoLancamento } from '../model/lancamento.ts';
import type { ConsultarReferenciasLancamento, GravarLancamento, ObterLancamento } from '../model/portas.ts';
import { TABELA } from './registrar-lancamento.ts';
import { conferirReferencias } from './regras-referencia.ts';

type Deps = { repo: ObterLancamento & GravarLancamento; refs: ConsultarReferenciasLancamento };

export class EditarLancamento {
  constructor(private readonly deps: Deps) {}
  async execute(ctx: ContextoCaso, e: { id: string } & EdicaoLancamento): Promise<Result<void>> {
    const { id, ...mud } = e;
    const atual = await this.deps.repo.obterPorId(id);
    if (!atual) return fail(erroDe('nao_encontrado', 'Lancamento nao encontrado'));
    const r = atual.editar(mud);
    if (!r.ok) return r;
    const antes = atual.paraDados();
    const depois = r.valor.paraDados();
    const erros = await conferirReferencias(this.deps.refs, depois, antes);
    if (erros.length) return fail(...erros);
    await this.deps.repo.atualizar(r.valor);
    await ctx.efeitos.historico(TABELA, id, antes as unknown as Record<string, unknown>, depois as unknown as Record<string, unknown>);
    await ctx.efeitos.auditar('lancamento.editar', TABELA, id, antes, depois);
    return okVazio();
  }
}

export class EstornarLancamento {
  constructor(private readonly deps: { repo: ObterLancamento & GravarLancamento; hoje: () => string }) {}
  async execute(ctx: ContextoCaso, e: { id: string; motivo?: string | null }): Promise<Result<{ estorno_id: string }>> {
    const atual = await this.deps.repo.obterPorId(e.id);
    if (!atual) return fail(erroDe('nao_encontrado', 'Lancamento nao encontrado'));
    const r = atual.estornar(this.deps.hoje(), (e.motivo ?? '').trim() || null);
    if (!r.ok) return r;
    await this.deps.repo.atualizar(r.valor.original);
    await this.deps.repo.inserir(r.valor.estorno);
    const est = r.valor.estorno.paraDados();
    await ctx.efeitos.historico(TABELA, e.id, { estado: 'ativo' }, { estado: 'estornado' });
    await ctx.efeitos.nota(TABELA, e.id, `Estornado pelo lancamento ${est.id}${e.motivo ? `: ${e.motivo}` : ''}`);
    await ctx.efeitos.auditar('lancamento.estornar', TABELA, e.id, atual.paraDados(), { estado: 'estornado', estorno: est });
    await ctx.efeitos.publicar('lancamento.estornado', { id: e.id, estorno_id: est.id, motivo: e.motivo ?? null, valor_centavos: est.valor_centavos, moeda: est.moeda });
    await ctx.efeitos.publicar('lancamento.registrado', payloadRegistrado(est));
    return ok({ estorno_id: est.id });
  }
}

export class AnexarComprovante {
  constructor(private readonly deps: Deps) {}
  async execute(ctx: ContextoCaso, e: { id: string; anexo_id: string }): Promise<Result<void>> {
    const atual = await this.deps.repo.obterPorId(e.id);
    if (!atual) return fail(erroDe('nao_encontrado', 'Lancamento nao encontrado'));
    if (!(await this.deps.refs.anexoDoLancamento(e.anexo_id, e.id))) {
      return fail(erroDe('anexo_invalido', 'Anexo nao encontrado neste lancamento (envie em /api/v1/nucleo/anexos com entidade financeiro_lancamentos)', 'anexo_id'));
    }
    const r = atual.anexarComprovante(e.anexo_id);
    if (!r.ok) return r;
    await this.deps.repo.atualizar(r.valor);
    const antes = { comprovante_anexo_id: atual.paraDados().comprovante_anexo_id };
    await ctx.efeitos.historico(TABELA, e.id, antes, { comprovante_anexo_id: e.anexo_id });
    await ctx.efeitos.auditar('lancamento.anexar_comprovante', TABELA, e.id, antes, { comprovante_anexo_id: e.anexo_id });
    return okVazio();
  }
}
