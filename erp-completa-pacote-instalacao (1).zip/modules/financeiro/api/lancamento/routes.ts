/**
 * Rotas REST do Lancamento fora das tools. POST de lancamento e transferencia exige o cabecalho
 * Idempotency-Key (CONTRATOS 3.1): a mesma chave devolve 200 com o lancamento ja gravado, sem duplicar.
 */
import { erro, esquemaErro, requer, type FastifyInstance } from '@erp/api/sdk';
import { naTransacao } from '../borda.ts';
import { exigirOk } from '../compartilhado/result.ts';
import { propsEdicaoLancamento, propsLancamento, propsTransferencia, uuid } from '../esquemas.ts';
import type { DadosLancamento, EdicaoLancamento } from './model/lancamento.ts';
import { obterLancamento } from './query/lancamentos.ts';
import type { EntradaTransferir } from './use-case/registrar-lancamento.ts';

const tags = ['financeiro'];
const paramId = { type: 'object', required: ['id'], properties: { id: uuid } } as const;
const erros = { 400: esquemaErro, 403: esquemaErro, 404: esquemaErro, 409: esquemaErro };
/** Documenta o cabecalho no OpenAPI; a ausencia e tratada no handler (400 idempotency_key_obrigatoria). */
const cabecalhoIdem = { type: 'object', properties: { 'idempotency-key': { type: 'string', minLength: 8, maxLength: 200, description: 'Obrigatorio: chave unica por operacao' } } } as const;

export function rotasLancamento(app: FastifyInstance): void {
  app.post<{ Body: Omit<DadosLancamento, 'origem' | 'chave_idempotencia'> }>('/lancamentos', {
    preHandler: requer('financeiro.criar'),
    schema: {
      tags, summary: 'Registra entrada ou saida (RegistrarLancamento). Exige Idempotency-Key; repeticao devolve 200 com o mesmo lancamento',
      headers: cabecalhoIdem,
      body: { type: 'object', additionalProperties: false, required: ['tipo', 'descricao', 'conta_id', 'valor_centavos', 'data_competencia'], properties: propsLancamento },
      response: erros,
    },
  }, async (req, reply) => {
    const chave = String(req.headers['idempotency-key'] ?? '').trim();
    if (!chave) return erro(reply, 400, 'idempotency_key_obrigatoria', 'Envie o cabecalho Idempotency-Key');
    const r = await naTransacao(req, async (casos, ctx, c) => {
      const reg = exigirOk(await casos.registrarLancamento.execute(ctx, { ...req.body, origem: 'manual', chave_idempotencia: chave }));
      return { reg, dto: await obterLancamento(c, reg.id) };
    });
    if (r.reg.repetido) reply.header('idempotent-replayed', 'true');
    return reply.code(r.reg.repetido ? 200 : 201).send(r.dto);
  });

  app.post<{ Body: EntradaTransferir }>('/transferencias', {
    preHandler: requer('financeiro.criar'),
    schema: {
      tags, summary: 'Transfere entre contas da mesma moeda (Transferir). Exige Idempotency-Key',
      headers: cabecalhoIdem,
      body: { type: 'object', additionalProperties: false, required: ['conta_origem_id', 'conta_destino_id', 'valor_centavos', 'data'], properties: propsTransferencia },
      response: erros,
    },
  }, async (req, reply) => {
    const chave = String(req.headers['idempotency-key'] ?? '').trim();
    if (!chave) return erro(reply, 400, 'idempotency_key_obrigatoria', 'Envie o cabecalho Idempotency-Key');
    const r = await naTransacao(req, async (casos, ctx, c) => {
      const reg = exigirOk(await casos.transferir.execute(ctx, { ...req.body, chave_idempotencia: chave }));
      return { reg, dto: await obterLancamento(c, reg.id) };
    });
    if (r.reg.repetido) reply.header('idempotent-replayed', 'true');
    return reply.code(r.reg.repetido ? 200 : 201).send(r.dto);
  });

  app.patch<{ Params: { id: string }; Body: EdicaoLancamento }>('/lancamentos/:id', {
    preHandler: requer('financeiro.editar'),
    schema: {
      tags, summary: 'Edita descricao, classificacao e datas (EditarLancamento). Valor, conta e tipo so mudam por estorno', params: paramId,
      body: { type: 'object', additionalProperties: false, properties: propsEdicaoLancamento }, response: erros,
    },
  }, (req) => naTransacao(req, async (casos, ctx, c) => {
    exigirOk(await casos.editarLancamento.execute(ctx, { ...req.body, id: req.params.id }));
    return obterLancamento(c, req.params.id);
  }));

  app.post<{ Params: { id: string }; Body: { anexo_id: string } }>('/lancamentos/:id/comprovante', {
    preHandler: requer('financeiro.editar'),
    schema: {
      tags, summary: 'Liga o comprovante (anexo enviado em /api/v1/nucleo/anexos com entidade financeiro_lancamentos)', params: paramId,
      body: { type: 'object', additionalProperties: false, required: ['anexo_id'], properties: { anexo_id: uuid } }, response: erros,
    },
  }, (req) => naTransacao(req, async (casos, ctx, c) => {
    exigirOk(await casos.anexarComprovante.execute(ctx, { id: req.params.id, anexo_id: req.body.anexo_id }));
    return obterLancamento(c, req.params.id);
  }));

  // Seletor de cliente ou fornecedor: leitura da tabela publicada do Cadastros (CONTRATOS 7.1.1).
  app.get<{ Querystring: { busca?: string } }>('/parceiros-opcoes', {
    preHandler: requer('financeiro.ver'),
    schema: { tags, summary: 'Clientes e fornecedores ativos para o seletor do lancamento', querystring: { type: 'object', additionalProperties: false, properties: { busca: { type: 'string', maxLength: 120 } } } },
  }, (req) => naTransacao(req, async (_, __, c) => (await c.query(
    `SELECT id, nome, e_cliente, e_fornecedor FROM cadastros_parceiros
     WHERE (e_cliente OR e_fornecedor) AND estado = 'ativo' AND deleted_at IS NULL AND ($1::text IS NULL OR nome ILIKE '%' || $1 || '%')
     ORDER BY nome LIMIT 200`, [req.query.busca?.trim() || null])).rows));
}
