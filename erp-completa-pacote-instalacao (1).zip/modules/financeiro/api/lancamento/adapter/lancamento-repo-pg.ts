/** Adaptador Postgres das portas do agregado Lancamento (RLS restringe ao workspace da sessao). */
import type pg from 'pg';
import { Lancamento, type LancamentoDados } from '../model/lancamento.ts';
import type { BuscarPorChave, ConsultarReferenciasLancamento, GravarLancamento, ObterLancamento } from '../model/portas.ts';

export const COLUNAS_LANCAMENTO = `id, tipo, descricao, conta_id, conta_destino_id, categoria_id, centro_custo_id, parceiro_id,
  valor_centavos::float8 AS valor_centavos, moeda, to_char(data_competencia, 'YYYY-MM-DD') AS data_competencia,
  to_char(data_caixa, 'YYYY-MM-DD') AS data_caixa, comprovante_anexo_id, conciliado, estado, estorno_de_id, origem, chave_idempotencia, extras`;

export class LancamentoRepoPg implements ObterLancamento, GravarLancamento, BuscarPorChave, ConsultarReferenciasLancamento {
  constructor(private readonly c: pg.PoolClient) {}

  async obterPorId(id: string): Promise<Lancamento | null> {
    const r = await this.c.query(`SELECT ${COLUNAS_LANCAMENTO} FROM financeiro_lancamentos WHERE id = $1 AND deleted_at IS NULL`, [id]);
    return r.rows[0] ? Lancamento.reidratar(r.rows[0] as LancamentoDados) : null;
  }

  async buscarPorChave(chave: string): Promise<Lancamento | null> {
    const r = await this.c.query(`SELECT ${COLUNAS_LANCAMENTO} FROM financeiro_lancamentos WHERE chave_idempotencia = $1`, [chave]);
    return r.rows[0] ? Lancamento.reidratar(r.rows[0] as LancamentoDados) : null;
  }

  async inserir(l: Lancamento): Promise<void> {
    const d = l.paraDados();
    await this.c.query(
      `INSERT INTO financeiro_lancamentos (id, tipo, descricao, conta_id, conta_destino_id, categoria_id, centro_custo_id, parceiro_id, valor_centavos,
         moeda, data_competencia, data_caixa, comprovante_anexo_id, conciliado, conciliado_em, estado, estorno_de_id, origem, chave_idempotencia, extras, creator_id)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, CASE WHEN $14 THEN now() END, $15, $16, $17, $18, $19, nucleo_usuario_atual())`,
      [d.id, d.tipo, d.descricao, d.conta_id, d.conta_destino_id, d.categoria_id, d.centro_custo_id, d.parceiro_id, d.valor_centavos, d.moeda,
        d.data_competencia, d.data_caixa, d.comprovante_anexo_id, d.conciliado, d.estado, d.estorno_de_id, d.origem, d.chave_idempotencia, JSON.stringify(d.extras)],
    );
  }

  /** Valor, conta, tipo e moeda nao sao atualizados: so mudam por estorno. */
  async atualizar(l: Lancamento): Promise<void> {
    const d = l.paraDados();
    await this.c.query(
      `UPDATE financeiro_lancamentos SET descricao = $2, categoria_id = $3, centro_custo_id = $4, parceiro_id = $5, data_competencia = $6,
         data_caixa = $7, comprovante_anexo_id = $8, conciliado = $9, conciliado_em = CASE WHEN $9 AND NOT conciliado THEN now() ELSE conciliado_em END,
         estado = $10, extras = $11 WHERE id = $1 AND deleted_at IS NULL`,
      [d.id, d.descricao, d.categoria_id, d.centro_custo_id, d.parceiro_id, d.data_competencia, d.data_caixa, d.comprovante_anexo_id, d.conciliado, d.estado, JSON.stringify(d.extras)],
    );
  }

  async conta(id: string) {
    const r = await this.c.query('SELECT ativa, moeda FROM financeiro_contas WHERE id = $1 AND deleted_at IS NULL', [id]);
    return (r.rows[0] as { ativa: boolean; moeda: string } | undefined) ?? null;
  }

  async categoria(id: string) {
    const r = await this.c.query('SELECT natureza, ativa FROM financeiro_categorias WHERE id = $1 AND deleted_at IS NULL', [id]);
    return (r.rows[0] as { natureza: 'receita' | 'despesa'; ativa: boolean } | undefined) ?? null;
  }

  async centroAtivo(id: string) {
    return ((await this.c.query('SELECT 1 FROM financeiro_centros_custo WHERE id = $1 AND ativo AND deleted_at IS NULL', [id])).rowCount ?? 0) > 0;
  }

  /** Leitura da tabela publicada do Cadastros (CONTRATOS 7.1.1). */
  async parceiroAtivo(id: string) {
    return ((await this.c.query("SELECT 1 FROM cadastros_parceiros WHERE id = $1 AND estado = 'ativo' AND deleted_at IS NULL", [id])).rowCount ?? 0) > 0;
  }

  /** Anexo do nucleo (N10) gravado para este lancamento. */
  async anexoDoLancamento(anexoId: string, lancamentoId: string) {
    const r = await this.c.query(
      "SELECT 1 FROM anexos WHERE id = $1 AND entidade = 'financeiro_lancamentos' AND registro_id = $2 AND deleted_at IS NULL", [anexoId, lancamentoId]);
    return (r.rowCount ?? 0) > 0;
  }
}
