/** Casos de uso da Conta (M4.1): CriarConta, EditarConta, ArquivarConta e ReativarConta. */
import type { ContextoCaso } from '../../compartilhado/efeitos.ts';
import { erroDe, fail, ok, okVazio, type Result } from '../../compartilhado/result.ts';
import { Conta, type DadosConta } from '../model/conta.ts';
import type { ConsultarConta, GravarConta, ObterConta } from '../model/portas.ts';

const TABELA = 'financeiro_contas';
export interface DepsConta { repo: ObterConta & GravarConta & ConsultarConta }

export class CriarConta {
  constructor(private readonly deps: DepsConta) {}
  async execute(ctx: ContextoCaso, e: DadosConta): Promise<Result<{ id: string }>> {
    const r = Conta.tryCreate(e);
    if (!r.ok) return r;
    const igual = await this.deps.repo.buscarPorNome(r.valor.nome);
    if (igual) return fail(erroDe('conflito', 'Ja existe conta com este nome', 'nome', { id: igual.id }));
    await this.deps.repo.inserir(r.valor);
    const d = r.valor.paraDados();
    await ctx.efeitos.auditar('conta.criar', TABELA, d.id, undefined, d);
    return ok({ id: d.id });
  }
}

export class EditarConta {
  constructor(private readonly deps: DepsConta) {}
  async execute(ctx: ContextoCaso, e: { id: string } & Partial<DadosConta>): Promise<Result<void>> {
    const { id, ...mud } = e;
    const atual = await this.deps.repo.obterPorId(id);
    if (!atual) return fail(erroDe('nao_encontrado', 'Conta nao encontrada'));
    const r = atual.editar(mud, await this.deps.repo.temLancamentos(id));
    if (!r.ok) return r;
    if (r.valor.nome.toLowerCase() !== atual.nome.toLowerCase()) {
      const igual = await this.deps.repo.buscarPorNome(r.valor.nome);
      if (igual && igual.id !== id) return fail(erroDe('conflito', 'Ja existe conta com este nome', 'nome', { id: igual.id }));
    }
    await this.deps.repo.atualizar(r.valor);
    const antes = atual.paraDados() as unknown as Record<string, unknown>;
    const depois = r.valor.paraDados() as unknown as Record<string, unknown>;
    await ctx.efeitos.historico(TABELA, id, antes, depois);
    await ctx.efeitos.auditar('conta.editar', TABELA, id, antes, depois);
    return okVazio();
  }
}

export class AlternarConta {
  constructor(private readonly deps: { repo: ObterConta & GravarConta }, private readonly acao: 'arquivar' | 'reativar') {}
  async execute(ctx: ContextoCaso, e: { id: string }): Promise<Result<void>> {
    const atual = await this.deps.repo.obterPorId(e.id);
    if (!atual) return fail(erroDe('nao_encontrado', 'Conta nao encontrada'));
    const r = this.acao === 'arquivar' ? atual.arquivar() : atual.reativar();
    if (!r.ok) return r;
    await this.deps.repo.atualizar(r.valor);
    await ctx.efeitos.historico(TABELA, e.id, { ativa: atual.ativa }, { ativa: r.valor.ativa });
    await ctx.efeitos.auditar(`conta.${this.acao}`, TABELA, e.id, { ativa: atual.ativa }, { ativa: r.valor.ativa });
    return okVazio();
  }
}
