/**
 * Entidade Conta financeira (M4.1): banco, agencia, conta, saldo inicial em centavos e moeda.
 * Imutavel: toda alteracao devolve um clone novo. Moeda e saldo inicial so mudam sem lancamentos.
 */
import { randomUUID } from 'node:crypto';
import { DataIso, MAX_CENTAVOS, hojeIso } from '../../compartilhado/dinheiro.ts';
import { erroDe, fail, ok, type ErroDominio, type Result } from '../../compartilhado/result.ts';

export const TIPOS_CONTA = ['banco', 'caixa', 'carteira', 'investimento'] as const;
export type TipoConta = (typeof TIPOS_CONTA)[number];

export interface DadosConta {
  nome: string;
  tipo?: TipoConta;
  banco_codigo?: string | null;
  banco_nome?: string | null;
  agencia?: string | null;
  numero?: string | null;
  moeda?: string;
  saldo_inicial_centavos?: number;
  data_saldo_inicial?: string;
  extras?: Record<string, unknown>;
}

export interface ContaDados {
  id: string;
  nome: string;
  tipo: TipoConta;
  banco_codigo: string | null;
  banco_nome: string | null;
  agencia: string | null;
  numero: string | null;
  moeda: string;
  saldo_inicial_centavos: number;
  data_saldo_inicial: string;
  ativa: boolean;
  extras: Record<string, unknown>;
}

const t = (v?: string | null) => (v ?? '').trim() || null;

function validar(d: ContaDados): ErroDominio[] {
  const e: ErroDominio[] = [];
  if (d.nome.length < 2 || d.nome.length > 120) e.push(erroDe('nome_invalido', 'Nome deve ter de 2 a 120 caracteres', 'nome'));
  if (!TIPOS_CONTA.includes(d.tipo)) e.push(erroDe('tipo_invalido', 'Tipo deve ser banco, caixa, carteira ou investimento', 'tipo'));
  if (d.banco_codigo !== null && !/^\d{3}$/.test(d.banco_codigo)) e.push(erroDe('banco_invalido', 'Codigo do banco tem 3 digitos (COMPE)', 'banco_codigo'));
  if (d.agencia !== null && !/^\d{1,6}(-[\dXx])?$/.test(d.agencia)) e.push(erroDe('agencia_invalida', 'Agencia so com digitos (e digito verificador opcional)', 'agencia'));
  if (d.numero !== null && !/^\d{1,13}(-[\dXx])?$/.test(d.numero)) e.push(erroDe('conta_invalida', 'Numero da conta so com digitos (e digito verificador opcional)', 'numero'));
  if (d.tipo === 'banco' && (d.banco_codigo === null || d.agencia === null || d.numero === null)) {
    e.push(erroDe('dados_bancarios_obrigatorios', 'Conta do tipo banco exige banco, agencia e numero', 'banco_codigo'));
  }
  if (!/^[A-Z]{3}$/.test(d.moeda)) e.push(erroDe('moeda_invalida', 'Moeda em ISO 4217 (BRL, USD, EUR)', 'moeda'));
  if (!Number.isSafeInteger(d.saldo_inicial_centavos) || Math.abs(d.saldo_inicial_centavos) > MAX_CENTAVOS) {
    e.push(erroDe('valor_invalido', 'Saldo inicial deve ser inteiro em centavos', 'saldo_inicial_centavos'));
  }
  const data = DataIso.tryCreate(d.data_saldo_inicial, 'data_saldo_inicial');
  if (!data.ok) e.push(...data.erros);
  return e;
}

export class Conta {
  private constructor(private readonly d: ContaDados) {}

  static tryCreate(e: DadosConta, id: string = randomUUID()): Result<Conta> {
    const d: ContaDados = {
      id, nome: (e.nome ?? '').trim(), tipo: e.tipo ?? 'banco', banco_codigo: t(e.banco_codigo), banco_nome: t(e.banco_nome),
      agencia: t(e.agencia), numero: t(e.numero), moeda: (t(e.moeda) ?? 'BRL').toUpperCase(),
      saldo_inicial_centavos: e.saldo_inicial_centavos ?? 0, data_saldo_inicial: t(e.data_saldo_inicial) ?? hojeIso(),
      ativa: true, extras: e.extras ?? {},
    };
    const erros = validar(d);
    return erros.length ? fail(...erros) : ok(new Conta(d));
  }

  static create(e: DadosConta, id?: string): Conta {
    const r = Conta.tryCreate(e, id);
    if (!r.ok) throw new Error(r.erros.map((x) => x.mensagem).join('; '));
    return r.valor;
  }

  static reidratar(d: ContaDados): Conta {
    return new Conta({ ...d, saldo_inicial_centavos: Number(d.saldo_inicial_centavos), extras: { ...d.extras } });
  }

  get id(): string { return this.d.id; }
  get ativa(): boolean { return this.d.ativa; }
  get moeda(): string { return this.d.moeda; }
  get nome(): string { return this.d.nome; }

  /** Edita dados cadastrais. Moeda e saldo inicial so mudam quando a conta ainda nao tem lancamentos. */
  editar(e: Partial<DadosConta>, temLancamentos: boolean): Result<Conta> {
    const tem = (k: keyof DadosConta) => e[k] !== undefined;
    const n: ContaDados = {
      ...this.d,
      nome: tem('nome') ? (e.nome ?? '').trim() : this.d.nome,
      tipo: tem('tipo') ? e.tipo! : this.d.tipo,
      banco_codigo: tem('banco_codigo') ? t(e.banco_codigo) : this.d.banco_codigo,
      banco_nome: tem('banco_nome') ? t(e.banco_nome) : this.d.banco_nome,
      agencia: tem('agencia') ? t(e.agencia) : this.d.agencia,
      numero: tem('numero') ? t(e.numero) : this.d.numero,
      moeda: tem('moeda') ? (t(e.moeda) ?? 'BRL').toUpperCase() : this.d.moeda,
      saldo_inicial_centavos: tem('saldo_inicial_centavos') ? e.saldo_inicial_centavos! : this.d.saldo_inicial_centavos,
      data_saldo_inicial: tem('data_saldo_inicial') ? (t(e.data_saldo_inicial) ?? this.d.data_saldo_inicial) : this.d.data_saldo_inicial,
      extras: tem('extras') ? { ...e.extras } : { ...this.d.extras },
    };
    const erros = validar(n);
    if (temLancamentos && (n.moeda !== this.d.moeda || n.saldo_inicial_centavos !== this.d.saldo_inicial_centavos || n.data_saldo_inicial !== this.d.data_saldo_inicial)) {
      erros.push(erroDe('conta_com_lancamentos', 'Moeda e saldo inicial nao mudam depois do primeiro lancamento', 'saldo_inicial_centavos'));
    }
    return erros.length ? fail(...erros) : ok(new Conta(n));
  }

  arquivar(): Result<Conta> {
    if (!this.d.ativa) return fail(erroDe('transicao_invalida', 'Conta ja esta arquivada', 'ativa'));
    return ok(new Conta({ ...this.d, ativa: false }));
  }

  reativar(): Result<Conta> {
    if (this.d.ativa) return fail(erroDe('transicao_invalida', 'Conta ja esta ativa', 'ativa'));
    return ok(new Conta({ ...this.d, ativa: true }));
  }

  paraDados(): ContaDados {
    return { ...this.d, extras: { ...this.d.extras } };
  }
}
