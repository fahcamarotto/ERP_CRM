/** Portas do repositorio do agregado Conta, segregadas por operacao. */
import type { Conta } from './conta.ts';

export interface ObterConta {
  obterPorId(id: string): Promise<Conta | null>;
}

export interface GravarConta {
  inserir(c: Conta): Promise<void>;
  atualizar(c: Conta): Promise<void>;
}

export interface ConsultarConta {
  buscarPorNome(nome: string): Promise<Conta | null>;
  temLancamentos(id: string): Promise<boolean>;
}
