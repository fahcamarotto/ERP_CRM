/** Rotas REST da Conta fora das tools (ficha, criar, editar, arquivar, reativar). Listar e @tool financeiro.contas. */
import { esquemaErro, requer, type FastifyInstance } from '@erp/api/sdk';
import { naTransacao, naoEncontrado } from '../borda.ts';
import { exigirOk } from '../compartilhado/result.ts';
import { propsConta, uuid } from '../esquemas.ts';
import type { DadosConta } from './model/conta.ts';
import { obterConta } from './query/contas.ts';

const tags = ['financeiro'];
const paramId = { type: 'object', required: ['id'], properties: { id: uuid } } as const;
const erros = { 400: esquemaErro, 403: esquemaErro, 404: esquemaErro, 409: esquemaErro };

export function rotasConta(app: FastifyInstance): void {
  app.get<{ Params: { id: string } }>('/contas/:id', {
    preHandler: requer('financeiro.ver'),
    schema: { tags, summary: 'Ficha da conta com saldo atual e a realizar (centavos)', params: paramId, response: { 404: esquemaErro } },
  }, (req) => naTransacao(req, async (_, __, c) => (await obterConta(c, req.params.id)) ?? Promise.reject(naoEncontrado('Conta nao encontrada'))));

  app.post<{ Body: DadosConta }>('/contas', {
    preHandler: requer('financeiro.criar'),
    schema: { tags, summary: 'Cria conta ou caixa (CriarConta)', body: { type: 'object', additionalProperties: false, required: ['nome'], properties: propsConta }, response: erros },
  }, async (req, reply) => reply.code(201).send(await naTransacao(req, async (casos, ctx, c) => {
    const { id } = exigirOk(await casos.criarConta.execute(ctx, req.body));
    return obterConta(c, id);
  })));

  app.patch<{ Params: { id: string }; Body: Partial<DadosConta> }>('/contas/:id', {
    preHandler: requer('financeiro.editar'),
    schema: { tags, summary: 'Edita conta (EditarConta); moeda e saldo inicial so sem lancamentos', params: paramId, body: { type: 'object', additionalProperties: false, properties: propsConta }, response: erros },
  }, (req) => naTransacao(req, async (casos, ctx, c) => {
    exigirOk(await casos.editarConta.execute(ctx, { ...req.body, id: req.params.id }));
    return obterConta(c, req.params.id);
  }));

  for (const acao of ['arquivar', 'reativar'] as const) {
    app.post<{ Params: { id: string } }>(`/contas/:id/${acao}`, {
      preHandler: requer('financeiro.editar'),
      schema: { tags, summary: acao === 'arquivar' ? 'Arquiva a conta (sai dos seletores, historico preservado)' : 'Reativa conta arquivada', params: paramId, response: erros },
    }, (req) => naTransacao(req, async (casos, ctx, c) => {
      exigirOk(await (acao === 'arquivar' ? casos.arquivarConta : casos.reativarConta).execute(ctx, { id: req.params.id }));
      return obterConta(c, req.params.id);
    }));
  }
}
