/** Consultas de leitura da Conta: lista com saldo realizado e previsto (centavos) e ficha. */
import type pg from 'pg';

/**
 * Saldo realizado de uma conta ate uma data (inclusive): saldo inicial + entradas - saidas + transferencias
 * recebidas - transferencias enviadas, so com data de caixa preenchida. Estorno e outro lancamento com o
 * sentido invertido, entao original e estorno entram os dois e se anulam.
 */
export const SQL_SALDO = (alias: string, ate: string) => `(${alias}.saldo_inicial_centavos + coalesce((
  SELECT sum(CASE WHEN l.tipo = 'entrada' THEN l.valor_centavos WHEN l.tipo = 'saida' THEN -l.valor_centavos
                  WHEN l.conta_destino_id = ${alias}.id THEN l.valor_centavos ELSE -l.valor_centavos END)
  FROM financeiro_lancamentos l
  WHERE (l.conta_id = ${alias}.id OR l.conta_destino_id = ${alias}.id) AND l.deleted_at IS NULL
    AND l.data_caixa IS NOT NULL AND l.data_caixa >= ${alias}.data_saldo_inicial AND l.data_caixa <= ${ate}), 0))::float8`;

const PREVISTO = (alias: string) => `coalesce((
  SELECT sum(CASE WHEN l.tipo = 'entrada' THEN l.valor_centavos WHEN l.tipo = 'saida' THEN -l.valor_centavos
                  WHEN l.conta_destino_id = ${alias}.id THEN l.valor_centavos ELSE -l.valor_centavos END)
  FROM financeiro_lancamentos l
  WHERE (l.conta_id = ${alias}.id OR l.conta_destino_id = ${alias}.id) AND l.deleted_at IS NULL AND l.data_caixa IS NULL), 0)::float8`;

const RESUMO = `k.id, k.nome, k.tipo, k.banco_codigo, k.banco_nome, k.agencia, k.numero, k.moeda,
  k.saldo_inicial_centavos::float8 AS saldo_inicial_centavos, to_char(k.data_saldo_inicial, 'YYYY-MM-DD') AS data_saldo_inicial,
  k.ativa, k.created_at, k.updated_at, ${SQL_SALDO('k', 'current_date')} AS saldo_centavos, ${PREVISTO('k')} AS a_realizar_centavos,
  (SELECT count(*)::int FROM financeiro_extrato_itens i WHERE i.conta_id = k.id AND i.estado = 'pendente' AND i.deleted_at IS NULL) AS pendentes_conciliacao`;

export async function listarContas(c: pg.PoolClient, f: { estado?: 'ativa' | 'arquivada' | 'todas' } = {}) {
  const estado = f.estado ?? 'ativa';
  const r = await c.query(
    `SELECT ${RESUMO} FROM financeiro_contas k
     WHERE k.deleted_at IS NULL AND ($1 = 'todas' OR k.ativa = ($1 = 'ativa')) ORDER BY k.ativa DESC, k.nome`,
    [estado],
  );
  return r.rows;
}

export async function obterConta(c: pg.PoolClient, id: string) {
  return (await c.query(`SELECT ${RESUMO}, k.extras FROM financeiro_contas k WHERE k.id = $1 AND k.deleted_at IS NULL`, [id])).rows[0] ?? null;
}

/** Saldo por conta numa data e total por moeda (tool financeiro.saldo). */
export async function saldos(c: pg.PoolClient, f: { conta_id?: string; data?: string }) {
  const data = f.data ?? null;
  const r = await c.query(
    `SELECT k.id AS conta_id, k.nome, k.tipo, k.moeda, ${SQL_SALDO('k', 'coalesce($2::date, current_date)')} AS saldo_centavos
     FROM financeiro_contas k WHERE k.deleted_at IS NULL AND k.ativa AND ($1::uuid IS NULL OR k.id = $1) ORDER BY k.nome`,
    [f.conta_id ?? null, data],
  );
  const total: Record<string, number> = {};
  for (const l of r.rows) total[l.moeda] = (total[l.moeda] ?? 0) + Number(l.saldo_centavos);
  return { data: data ?? new Date().toISOString().slice(0, 10), contas: r.rows, total_por_moeda: Object.entries(total).map(([moeda, saldo_centavos]) => ({ moeda, saldo_centavos })) };
}
