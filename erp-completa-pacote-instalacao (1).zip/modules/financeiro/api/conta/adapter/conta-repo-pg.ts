/** Adaptador Postgres das portas do agregado Conta (RLS restringe ao workspace da sessao). */
import type pg from 'pg';
import { Conta, type ContaDados } from '../model/conta.ts';
import type { ConsultarConta, GravarConta, ObterConta } from '../model/portas.ts';

const COLUNAS = `id, nome, tipo, banco_codigo, banco_nome, agencia, numero, moeda, saldo_inicial_centavos::float8 AS saldo_inicial_centavos,
  to_char(data_saldo_inicial, 'YYYY-MM-DD') AS data_saldo_inicial, ativa, extras`;

export class ContaRepoPg implements ObterConta, GravarConta, ConsultarConta {
  constructor(private readonly c: pg.PoolClient) {}

  async obterPorId(id: string): Promise<Conta | null> {
    const r = await this.c.query(`SELECT ${COLUNAS} FROM financeiro_contas WHERE id = $1 AND deleted_at IS NULL`, [id]);
    return r.rows[0] ? Conta.reidratar(r.rows[0] as ContaDados) : null;
  }

  async buscarPorNome(nome: string): Promise<Conta | null> {
    const r = await this.c.query(`SELECT ${COLUNAS} FROM financeiro_contas WHERE lower(nome) = lower($1) AND deleted_at IS NULL`, [nome]);
    return r.rows[0] ? Conta.reidratar(r.rows[0] as ContaDados) : null;
  }

  async temLancamentos(id: string): Promise<boolean> {
    const r = await this.c.query('SELECT 1 FROM financeiro_lancamentos WHERE (conta_id = $1 OR conta_destino_id = $1) AND deleted_at IS NULL LIMIT 1', [id]);
    return (r.rowCount ?? 0) > 0;
  }

  async inserir(x: Conta): Promise<void> {
    const d = x.paraDados();
    await this.c.query(
      `INSERT INTO financeiro_contas (id, nome, tipo, banco_codigo, banco_nome, agencia, numero, moeda, saldo_inicial_centavos, data_saldo_inicial, ativa, extras, creator_id)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, nucleo_usuario_atual())`,
      [d.id, d.nome, d.tipo, d.banco_codigo, d.banco_nome, d.agencia, d.numero, d.moeda, d.saldo_inicial_centavos, d.data_saldo_inicial, d.ativa, JSON.stringify(d.extras)],
    );
  }

  async atualizar(x: Conta): Promise<void> {
    const d = x.paraDados();
    await this.c.query(
      `UPDATE financeiro_contas SET nome = $2, tipo = $3, banco_codigo = $4, banco_nome = $5, agencia = $6, numero = $7, moeda = $8,
         saldo_inicial_centavos = $9, data_saldo_inicial = $10, ativa = $11, extras = $12 WHERE id = $1 AND deleted_at IS NULL`,
      [d.id, d.nome, d.tipo, d.banco_codigo, d.banco_nome, d.agencia, d.numero, d.moeda, d.saldo_inicial_centavos, d.data_saldo_inicial, d.ativa, JSON.stringify(d.extras)],
    );
  }
}
