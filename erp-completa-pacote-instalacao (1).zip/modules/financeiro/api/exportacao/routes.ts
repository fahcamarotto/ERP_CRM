/** Rotas da exportacao contabil (CSV por job): solicitar, listar, status e download. */
import { esquemaErro, requer, type FastifyInstance } from '@erp/api/sdk';
import { naTransacao, naoEncontrado } from '../borda.ts';
import { exigirOk } from '../compartilhado/result.ts';
import { uuid } from '../esquemas.ts';
import { conteudoExportacao, listarExportacoes, statusExportacao } from './exportacao-repo-pg.ts';

const tags = ['financeiro'];
const paramId = { type: 'object', required: ['id'], properties: { id: uuid } } as const;

export function rotasExportacao(app: FastifyInstance): void {
  app.post<{ Body: { de: string; ate: string } }>('/exportacoes', {
    preHandler: requer('financeiro.exportar'),
    schema: {
      tags, summary: 'Gera CSV contabil do periodo pela competencia (job na fila; ExportarContabil)',
      body: { type: 'object', additionalProperties: false, required: ['de', 'ate'], properties: { de: { type: 'string', format: 'date' }, ate: { type: 'string', format: 'date' } } },
      response: { 400: esquemaErro, 403: esquemaErro },
    },
  }, async (req, reply) => reply.code(202).send(await naTransacao(req, async (casos, ctx) => exigirOk(await casos.exportarContabil.execute(ctx, req.body)))));

  app.get('/exportacoes', {
    preHandler: requer('financeiro.ver'),
    schema: { tags, summary: 'Ultimas 30 exportacoes contabeis' },
  }, (req) => naTransacao(req, (_, __, c) => listarExportacoes(c)));

  app.get<{ Params: { id: string } }>('/exportacoes/:id', {
    preHandler: requer('financeiro.ver'),
    schema: { tags, summary: 'Status da exportacao', params: paramId, response: { 404: esquemaErro } },
  }, (req) => naTransacao(req, async (_, __, c) => (await statusExportacao(c, req.params.id)) ?? Promise.reject(naoEncontrado('Exportacao nao encontrada'))));

  app.get<{ Params: { id: string } }>('/exportacoes/:id/csv', {
    preHandler: requer('financeiro.exportar'),
    schema: { tags, summary: 'Baixa o CSV da exportacao concluida (text/csv, separador ;)', params: paramId, response: { 404: esquemaErro } },
  }, async (req, reply) => {
    const r = await naTransacao(req, (_, __, c) => conteudoExportacao(c, req.params.id));
    if (!r) throw naoEncontrado('Exportacao nao encontrada ou ainda em processamento');
    return reply.header('content-type', 'text/csv; charset=utf-8')
      .header('content-disposition', `attachment; filename="contabil-${r.de}-${r.ate}.csv"`).send(r.conteudo);
  });
}
