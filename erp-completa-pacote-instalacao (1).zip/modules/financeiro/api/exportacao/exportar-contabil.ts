/**
 * ExportarContabil (M4.6, CSV por job): a API grava o pedido e a intencao do job na outbox
 * (SolicitarExportacao); o worker monta o CSV do periodo pela competencia (ProcessarExportacao),
 * grava o conteudo e publica exportacao_contabil.concluida.
 */
import { DataIso, formatarCentavos } from '../compartilhado/dinheiro.ts';
import type { ContextoCaso } from '../compartilhado/efeitos.ts';
import { combinar, erroDe, fail, ok, type Result } from '../compartilhado/result.ts';

export const TIPO_JOB_EXPORTACAO = 'financeiro.exportar_contabil';
export const MAX_DIAS = 366;

export interface LinhaContabil {
  id: string;
  data_competencia: string;
  data_caixa: string | null;
  tipo: string;
  descricao: string;
  conta: string;
  conta_destino: string | null;
  categoria_codigo: string | null;
  categoria: string | null;
  centro_custo: string | null;
  parceiro_documento: string | null;
  parceiro: string | null;
  valor_centavos: number;
  moeda: string;
  estado: string;
  conciliado: boolean;
  estorno_de_id: string | null;
}

export interface PortaExportacoes {
  inserir(d: { id: string; de: string; ate: string }): Promise<void>;
  obter(id: string): Promise<{ id: string; de: string; ate: string; estado: string } | null>;
  progresso(id: string, p: { estado: 'pendente' | 'processando' | 'concluida' | 'erro'; total: number; conteudo?: string | null; job_id?: string }): Promise<void>;
  linhas(de: string, ate: string): Promise<LinhaContabil[]>;
}

export interface FilaJobs {
  enfileirar(tipo: string, payload: Record<string, unknown>): Promise<string>;
}

const CABECALHO = ['id', 'data_competencia', 'data_caixa', 'tipo', 'descricao', 'conta', 'conta_destino', 'categoria_codigo', 'categoria',
  'centro_custo', 'parceiro_documento', 'parceiro', 'valor', 'moeda', 'estado', 'conciliado', 'estorno_de_id'];

/** Campo CSV com ; separador, aspas quando preciso e defesa contra formula de planilha (=, +, -, @ no inicio). */
function campo(v: unknown): string {
  let s = v === null || v === undefined ? '' : String(v);
  if (/^[=+\-@]/.test(s) && !/^-?\d+(\.\d+)?$/.test(s)) s = `'${s}`;
  return /[;"\r\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

/** CSV contabil (separador ;, valor com ponto decimal e sinal: saida negativa, transferencia positiva). */
export function gerarCsv(linhas: LinhaContabil[]): string {
  const corpo = linhas.map((l) => {
    const valor = l.tipo === 'saida' ? -l.valor_centavos : l.valor_centavos;
    return [l.id, l.data_competencia, l.data_caixa, l.tipo, l.descricao, l.conta, l.conta_destino, l.categoria_codigo, l.categoria, l.centro_custo,
      l.parceiro_documento, l.parceiro, formatarCentavos(valor), l.moeda, l.estado, l.conciliado ? 'sim' : 'nao', l.estorno_de_id].map(campo).join(';');
  });
  return [CABECALHO.join(';'), ...corpo].join('\r\n') + '\r\n';
}

export class SolicitarExportacao {
  constructor(private readonly deps: { exportacoes: PortaExportacoes; fila: FilaJobs; novoId: () => string }) {}
  async execute(ctx: ContextoCaso, e: { de: string; ate: string }): Promise<Result<{ exportacao_id: string; job_id: string }>> {
    const r = combinar(DataIso.tryCreate(e.de, 'de'), DataIso.tryCreate(e.ate, 'ate'));
    if (!r.ok) return r;
    const [de, ate] = r.valor;
    const dias = de.diasAte(ate);
    if (dias < 0) return fail(erroDe('periodo_invalido', 'Data final antes da inicial', 'ate'));
    if (dias > MAX_DIAS) return fail(erroDe('periodo_invalido', `Periodo maximo de ${MAX_DIAS} dias`, 'ate'));
    const id = this.deps.novoId();
    await this.deps.exportacoes.inserir({ id, de: de.valor, ate: ate.valor });
    const job = await this.deps.fila.enfileirar(TIPO_JOB_EXPORTACAO, { exportacao_id: id });
    await this.deps.exportacoes.progresso(id, { estado: 'pendente', total: 0, job_id: job });
    await ctx.efeitos.auditar('exportacao_contabil.solicitar', 'financeiro_exportacoes', id, undefined, { de: de.valor, ate: ate.valor });
    return ok({ exportacao_id: id, job_id: job });
  }
}

export class ProcessarExportacao {
  constructor(private readonly deps: { exportacoes: PortaExportacoes }) {}
  async execute(ctx: ContextoCaso, e: { exportacao_id: string }): Promise<Result<{ total: number }>> {
    const exp = await this.deps.exportacoes.obter(e.exportacao_id);
    if (!exp) return fail(erroDe('nao_encontrado', 'Exportacao nao encontrada'));
    if (exp.estado === 'concluida') return ok({ total: 0 });
    await this.deps.exportacoes.progresso(exp.id, { estado: 'processando', total: 0 });
    const linhas = await this.deps.exportacoes.linhas(exp.de, exp.ate);
    await this.deps.exportacoes.progresso(exp.id, { estado: 'concluida', total: linhas.length, conteudo: gerarCsv(linhas) });
    await ctx.efeitos.publicar('exportacao_contabil.concluida', { id: exp.id, de: exp.de, ate: exp.ate, total: linhas.length });
    return ok({ total: linhas.length });
  }
}
