/** Adaptador Postgres da exportacao contabil (tabela financeiro_exportacoes) e consultas de status. */
import type pg from 'pg';
import type { LinhaContabil, PortaExportacoes } from './exportar-contabil.ts';

export class ExportacaoRepoPg implements PortaExportacoes {
  constructor(private readonly c: pg.PoolClient) {}

  async inserir(d: { id: string; de: string; ate: string }) {
    await this.c.query('INSERT INTO financeiro_exportacoes (id, de, ate, creator_id) VALUES ($1, $2, $3, nucleo_usuario_atual())', [d.id, d.de, d.ate]);
  }

  async obter(id: string) {
    return (await this.c.query(
      `SELECT id, to_char(de, 'YYYY-MM-DD') AS de, to_char(ate, 'YYYY-MM-DD') AS ate, estado FROM financeiro_exportacoes WHERE id = $1 AND deleted_at IS NULL`, [id])).rows[0] ?? null;
  }

  async progresso(id: string, p: Parameters<PortaExportacoes['progresso']>[1]) {
    await this.c.query(
      `UPDATE financeiro_exportacoes SET estado = $2, total = $3, conteudo = coalesce($4, conteudo), job_id = coalesce($5, job_id),
         concluida_em = CASE WHEN $2 = 'concluida' THEN now() ELSE concluida_em END WHERE id = $1`,
      [id, p.estado, p.total, p.conteudo ?? null, p.job_id ?? null]);
  }

  /** Lancamentos do periodo pela competencia; parceiro lido da tabela publicada do Cadastros. */
  async linhas(de: string, ate: string): Promise<LinhaContabil[]> {
    const r = await this.c.query(
      `SELECT l.id, to_char(l.data_competencia, 'YYYY-MM-DD') AS data_competencia, to_char(l.data_caixa, 'YYYY-MM-DD') AS data_caixa, l.tipo, l.descricao,
         k.nome AS conta, kd.nome AS conta_destino, cat.codigo AS categoria_codigo, cat.nome AS categoria, cc.codigo AS centro_custo,
         p.documento AS parceiro_documento, p.nome AS parceiro, l.valor_centavos::float8 AS valor_centavos, l.moeda, l.estado, l.conciliado, l.estorno_de_id
       FROM financeiro_lancamentos l JOIN financeiro_contas k ON k.id = l.conta_id
       LEFT JOIN financeiro_contas kd ON kd.id = l.conta_destino_id
       LEFT JOIN financeiro_categorias cat ON cat.id = l.categoria_id
       LEFT JOIN financeiro_centros_custo cc ON cc.id = l.centro_custo_id
       LEFT JOIN cadastros_parceiros p ON p.id = l.parceiro_id
       WHERE l.deleted_at IS NULL AND l.data_competencia BETWEEN $1::date AND $2::date
       ORDER BY l.data_competencia, l.created_at, l.id`, [de, ate]);
    return r.rows.map((x) => ({ ...x, valor_centavos: Number(x.valor_centavos) })) as LinhaContabil[];
  }
}

export async function listarExportacoes(c: pg.PoolClient) {
  return (await c.query(
    `SELECT id, to_char(de, 'YYYY-MM-DD') AS de, to_char(ate, 'YYYY-MM-DD') AS ate, estado, total, job_id, created_at, concluida_em
     FROM financeiro_exportacoes WHERE deleted_at IS NULL ORDER BY created_at DESC LIMIT 30`)).rows;
}

export async function statusExportacao(c: pg.PoolClient, id: string) {
  return (await c.query(
    `SELECT id, to_char(de, 'YYYY-MM-DD') AS de, to_char(ate, 'YYYY-MM-DD') AS ate, estado, total, job_id, created_at, concluida_em
     FROM financeiro_exportacoes WHERE id = $1 AND deleted_at IS NULL`, [id])).rows[0] ?? null;
}

export async function conteudoExportacao(c: pg.PoolClient, id: string) {
  return (await c.query(
    `SELECT conteudo, to_char(de, 'YYYYMMDD') AS de, to_char(ate, 'YYYYMMDD') AS ate FROM financeiro_exportacoes
     WHERE id = $1 AND estado = 'concluida' AND deleted_at IS NULL`, [id])).rows[0] ?? null;
}
