/**
 * Plugin do modulo Financeiro (M4), registrado sozinho com prefixo /api/v1/financeiro.
 * Importar ./tools.ts registra as @tool (MCP e REST) no carregamento.
 */
import type { FastifyPluginAsync } from '@erp/api/sdk';
import './tools.ts';
import { rotasCategoria } from './categoria/routes.ts';
import { rotasCentroCusto } from './centro-custo/routes.ts';
import { rotasConciliacao } from './conciliacao/routes.ts';
import { rotasConta } from './conta/routes.ts';
import { rotasExportacao } from './exportacao/routes.ts';
import { rotasLancamento } from './lancamento/routes.ts';

const plugin: FastifyPluginAsync = async (app) => {
  rotasConta(app);
  rotasCategoria(app);
  rotasCentroCusto(app);
  rotasLancamento(app);
  rotasConciliacao(app);
  rotasExportacao(app);
};

export default plugin;
