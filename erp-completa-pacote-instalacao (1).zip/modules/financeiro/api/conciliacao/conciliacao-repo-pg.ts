/** Adaptadores Postgres da conciliacao: extratos, itens, candidatos a par e fila (outbox do nucleo). */
import type pg from 'pg';
import { decodificarCursor, pagina } from '../compartilhado/cursor.ts';
import type { CandidatoPar, ExtratoDados, FilaJobs, ItemDados, PortaExtratos, PortaItens, ProgressoExtrato } from './conciliar.ts';

const COLUNAS_ITEM = `id, extrato_id, conta_id, to_char(data, 'YYYY-MM-DD') AS data, valor_centavos::float8 AS valor_centavos, descricao,
  identificador, estado, sugestao_lancamento_id, lancamento_id`;

export class ConciliacaoRepoPg implements PortaExtratos, PortaItens {
  constructor(private readonly c: pg.PoolClient) {}

  async inserir(d: Omit<ExtratoDados, 'estado'>) {
    await this.c.query('INSERT INTO financeiro_extratos (id, conta_id, nome_arquivo, formato, conteudo, creator_id) VALUES ($1, $2, $3, $4, $5, nucleo_usuario_atual())',
      [d.id, d.conta_id, d.nome_arquivo, d.formato, d.conteudo]);
  }

  async obter(id: string): Promise<ExtratoDados | null> {
    return (await this.c.query('SELECT id, conta_id, nome_arquivo, formato, conteudo, estado FROM financeiro_extratos WHERE id = $1 AND deleted_at IS NULL', [id])).rows[0] ?? null;
  }

  async progresso(id: string, p: ProgressoExtrato) {
    await this.c.query(
      `UPDATE financeiro_extratos SET estado = $2, total = $3, importados = $4, duplicados = $5, sugeridos = $6, erros = $7, job_id = coalesce($8, job_id),
         concluida_em = CASE WHEN $2 = 'concluida' THEN now() ELSE concluida_em END WHERE id = $1`,
      [id, p.estado, p.total, p.importados, p.duplicados, p.sugeridos, JSON.stringify(p.erros), p.job_id ?? null]);
  }

  async contaAtiva(id: string) {
    return ((await this.c.query('SELECT 1 FROM financeiro_contas WHERE id = $1 AND ativa AND deleted_at IS NULL', [id])).rowCount ?? 0) > 0;
  }

  async inserirSeNovo(i: ItemDados) {
    const r = await this.c.query(
      `INSERT INTO financeiro_extrato_itens (id, extrato_id, conta_id, data, valor_centavos, descricao, identificador, estado, creator_id)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, nucleo_usuario_atual())
       ON CONFLICT (tenant_id, workspace_id, conta_id, identificador) WHERE deleted_at IS NULL DO NOTHING`,
      [i.id, i.extrato_id, i.conta_id, i.data, i.valor_centavos, i.descricao, i.identificador, i.estado]);
    return (r.rowCount ?? 0) > 0;
  }

  async obterItem(id: string): Promise<ItemDados | null> {
    const r = await this.c.query(`SELECT ${COLUNAS_ITEM} FROM financeiro_extrato_itens WHERE id = $1 AND deleted_at IS NULL`, [id]);
    return r.rows[0] ? { ...r.rows[0], valor_centavos: Number(r.rows[0].valor_centavos) } : null;
  }

  async atualizarItem(i: ItemDados) {
    await this.c.query(
      `UPDATE financeiro_extrato_itens SET estado = $2, sugestao_lancamento_id = $3, lancamento_id = $4,
         conciliado_em = CASE WHEN $2 = 'conciliado' THEN now() ELSE NULL END WHERE id = $1 AND deleted_at IS NULL`,
      [i.id, i.estado, i.sugestao_lancamento_id, i.lancamento_id]);
  }

  async pendentesSemSugestao(f: { extrato_id?: string; conta_id?: string }) {
    const r = await this.c.query(
      `SELECT ${COLUNAS_ITEM} FROM financeiro_extrato_itens
       WHERE deleted_at IS NULL AND estado = 'pendente' AND sugestao_lancamento_id IS NULL
         AND ($1::uuid IS NULL OR extrato_id = $1) AND ($2::uuid IS NULL OR conta_id = $2) ORDER BY data, created_at LIMIT 5000`,
      [f.extrato_id ?? null, f.conta_id ?? null]);
    return r.rows.map((x) => ({ ...x, valor_centavos: Number(x.valor_centavos) })) as ItemDados[];
  }

  async candidatos(contaId: string, valor: number, de: string, ate: string): Promise<CandidatoPar[]> {
    const r = await this.c.query(
      `SELECT l.id, to_char(coalesce(l.data_caixa, l.data_competencia), 'YYYY-MM-DD') AS data, l.descricao
       FROM financeiro_lancamentos l
       WHERE l.deleted_at IS NULL AND l.estado = 'ativo' AND NOT l.conciliado
         AND coalesce(l.data_caixa, l.data_competencia) BETWEEN $3::date AND $4::date
         AND (CASE WHEN l.tipo = 'entrada' AND l.conta_id = $1 THEN l.valor_centavos
                   WHEN l.tipo = 'saida' AND l.conta_id = $1 THEN -l.valor_centavos
                   WHEN l.tipo = 'transferencia' AND l.conta_destino_id = $1 THEN l.valor_centavos
                   WHEN l.tipo = 'transferencia' AND l.conta_id = $1 THEN -l.valor_centavos END) = $2
         AND NOT EXISTS (SELECT 1 FROM financeiro_extrato_itens i WHERE i.sugestao_lancamento_id = l.id AND i.estado = 'pendente' AND i.deleted_at IS NULL)
       ORDER BY l.created_at LIMIT 50`,
      [contaId, valor, de, ate]);
    return r.rows as CandidatoPar[];
  }
}

/** Intencao do job gravada na outbox do nucleo, na mesma transacao do caso de uso (docs/CONTRATOS.md 6). */
export class FilaOutboxPg implements FilaJobs {
  constructor(private readonly c: pg.PoolClient) {}
  async enfileirar(tipo: string, payload: Record<string, unknown>): Promise<string> {
    return (await this.c.query('INSERT INTO outbox (tipo, payload) VALUES ($1, $2) RETURNING id', [tipo, JSON.stringify(payload)])).rows[0].id as string;
  }
}

export async function listarExtratos(c: pg.PoolClient, f: { conta_id?: string } = {}) {
  return (await c.query(
    `SELECT e.id, e.conta_id, k.nome AS conta_nome, e.nome_arquivo, e.formato, e.estado, e.total, e.importados, e.duplicados, e.sugeridos,
       jsonb_array_length(e.erros) AS qtd_erros, e.job_id, e.created_at, e.concluida_em
     FROM financeiro_extratos e JOIN financeiro_contas k ON k.id = e.conta_id
     WHERE e.deleted_at IS NULL AND ($1::uuid IS NULL OR e.conta_id = $1) ORDER BY e.created_at DESC LIMIT 50`, [f.conta_id ?? null])).rows;
}

export async function statusExtrato(c: pg.PoolClient, id: string) {
  return (await c.query(
    `SELECT e.id, e.conta_id, k.nome AS conta_nome, e.nome_arquivo, e.formato, e.estado, e.total, e.importados, e.duplicados, e.sugeridos, e.erros,
       e.job_id, e.created_at, e.concluida_em
     FROM financeiro_extratos e JOIN financeiro_contas k ON k.id = e.conta_id WHERE e.id = $1 AND e.deleted_at IS NULL`, [id])).rows[0] ?? null;
}

/** Itens do extrato com a sugestao (ou o par conciliado) ja resolvida para exibicao. */
export async function listarItens(c: pg.PoolClient, f: { conta_id?: string; extrato_id?: string; estado?: string; limite?: number; cursor?: string }) {
  const lim = Math.min(Math.max(f.limite ?? 100, 1), 200);
  const cur = decodificarCursor(f.cursor);
  const r = await c.query(
    `SELECT i.id, i.extrato_id, i.conta_id, k.nome AS conta_nome, to_char(i.data, 'YYYY-MM-DD') AS data, i.valor_centavos::float8 AS valor_centavos,
       k.moeda, i.descricao, i.estado, i.sugestao_lancamento_id, i.lancamento_id, i.conciliado_em, i.created_at,
       CASE WHEN l.id IS NULL THEN NULL ELSE json_build_object('id', l.id, 'descricao', l.descricao, 'tipo', l.tipo,
         'valor_centavos', l.valor_centavos::float8, 'data', to_char(coalesce(l.data_caixa, l.data_competencia), 'YYYY-MM-DD'), 'previsto', l.data_caixa IS NULL) END AS par
     FROM financeiro_extrato_itens i JOIN financeiro_contas k ON k.id = i.conta_id
     LEFT JOIN financeiro_lancamentos l ON l.id = coalesce(i.lancamento_id, i.sugestao_lancamento_id) AND l.deleted_at IS NULL
     WHERE i.deleted_at IS NULL AND ($1::uuid IS NULL OR i.conta_id = $1) AND ($2::uuid IS NULL OR i.extrato_id = $2)
       AND ($3::text IS NULL OR i.estado = $3)
       AND ($4::timestamptz IS NULL OR (i.created_at, i.id) > ($4::timestamptz, $5::uuid))
     ORDER BY i.created_at, i.id LIMIT $6`,
    [f.conta_id ?? null, f.extrato_id ?? null, f.estado ?? null, cur?.[0] ?? null, cur?.[1] ?? null, lim + 1]);
  return pagina(r.rows, lim);
}
