/** Rotas da conciliacao (M4.4): importar extrato (job), progresso, itens, sugestao e confirmacao manual. */
import { esquemaErro, requer, type FastifyInstance } from '@erp/api/sdk';
import { naTransacao, naoEncontrado } from '../borda.ts';
import { exigirOk } from '../compartilhado/result.ts';
import { uuid } from '../esquemas.ts';
import { obterLancamento } from '../lancamento/query/lancamentos.ts';
import { listarExtratos, listarItens, statusExtrato } from './conciliacao-repo-pg.ts';
import type { FormatoExtrato } from './extrato.ts';

const tags = ['financeiro'];
const paramId = { type: 'object', required: ['id'], properties: { id: uuid } } as const;
const erros = { 400: esquemaErro, 403: esquemaErro, 404: esquemaErro, 409: esquemaErro };
const uuidNulo = { type: ['string', 'null'], format: 'uuid' } as const;

export function rotasConciliacao(app: FastifyInstance): void {
  app.post<{ Body: { conta_id: string; nome_arquivo: string; conteudo: string; formato?: FormatoExtrato } }>('/extratos', {
    preHandler: requer('financeiro.conciliar'),
    bodyLimit: 6 * 1024 * 1024,
    schema: {
      tags, summary: 'Importa extrato OFX ou CSV (job na fila; consulte GET /extratos/:id ou /api/v1/jobs/:job_id)',
      body: { type: 'object', additionalProperties: false, required: ['conta_id', 'nome_arquivo', 'conteudo'], properties: {
        conta_id: uuid, nome_arquivo: { type: 'string', minLength: 1, maxLength: 200 },
        conteudo: { type: 'string', minLength: 1, maxLength: 5_000_000 }, formato: { type: 'string', enum: ['ofx', 'csv'] },
      } },
      response: erros,
    },
  }, async (req, reply) => reply.code(202).send(await naTransacao(req, async (casos, ctx) => exigirOk(await casos.importarExtrato.execute(ctx, req.body)))));

  app.get<{ Querystring: { conta_id?: string } }>('/extratos', {
    preHandler: requer('financeiro.ver'),
    schema: { tags, summary: 'Ultimos 50 extratos importados', querystring: { type: 'object', additionalProperties: false, properties: { conta_id: uuid } } },
  }, (req) => naTransacao(req, (_, __, c) => listarExtratos(c, req.query)));

  app.get<{ Params: { id: string } }>('/extratos/:id', {
    preHandler: requer('financeiro.ver'),
    schema: { tags, summary: 'Progresso da importacao do extrato', params: paramId, response: { 404: esquemaErro } },
  }, (req) => naTransacao(req, async (_, __, c) => (await statusExtrato(c, req.params.id)) ?? Promise.reject(naoEncontrado('Extrato nao encontrado'))));

  app.get<{ Querystring: { conta_id?: string; extrato_id?: string; estado?: string; limite?: number; cursor?: string } }>('/extrato-itens', {
    preHandler: requer('financeiro.ver'),
    schema: {
      tags, summary: 'Itens de extrato com a sugestao de par (valor igual, data ate 5 dias)',
      querystring: { type: 'object', additionalProperties: false, properties: {
        conta_id: uuid, extrato_id: uuid, estado: { type: 'string', enum: ['pendente', 'conciliado', 'ignorado'] },
        limite: { type: 'integer', minimum: 1, maximum: 200, default: 100 }, cursor: { type: 'string', maxLength: 200 },
      } },
    },
  }, (req) => naTransacao(req, (_, __, c) => listarItens(c, req.query)));

  app.post<{ Body: { conta_id?: string; extrato_id?: string } }>('/extrato-itens/sugerir', {
    preHandler: requer('financeiro.conciliar'),
    schema: { tags, summary: 'Recalcula a sugestao de par dos itens pendentes sem sugestao', body: { type: 'object', additionalProperties: false, properties: { conta_id: uuid, extrato_id: uuid } }, response: erros },
  }, (req) => naTransacao(req, async (casos, ctx) => exigirOk(await casos.sugerirPares.execute(ctx, req.body ?? {}))));

  app.post<{ Params: { id: string }; Body: { descricao?: string | null; categoria_id?: string | null; centro_custo_id?: string | null; parceiro_id?: string | null } }>('/extrato-itens/:id/criar-lancamento', {
    preHandler: requer('financeiro.conciliar'),
    schema: {
      tags, summary: 'Cria o lancamento a partir do item e concilia (idempotente por item)', params: paramId,
      body: { type: 'object', additionalProperties: false, properties: { descricao: { type: ['string', 'null'], maxLength: 200 }, categoria_id: uuidNulo, centro_custo_id: uuidNulo, parceiro_id: uuidNulo } },
      response: erros,
    },
  }, async (req, reply) => reply.code(201).send(await naTransacao(req, async (casos, ctx, c) => {
    const { lancamento_id } = exigirOk(await casos.conciliarCriando.execute(ctx, { ...(req.body ?? {}), item_id: req.params.id }));
    return obterLancamento(c, lancamento_id);
  })));

  for (const acao of ['ignorar', 'reabrir'] as const) {
    app.post<{ Params: { id: string } }>(`/extrato-itens/:id/${acao}`, {
      preHandler: requer('financeiro.conciliar'),
      schema: { tags, summary: acao === 'ignorar' ? 'Ignora item do extrato (tarifa ja lancada, duplicidade do banco)' : 'Reabre item ignorado', params: paramId, response: erros },
    }, async (req, reply) => {
      await naTransacao(req, async (casos, ctx) => exigirOk(await (acao === 'ignorar' ? casos.ignorarItem : casos.reabrirItem).execute(ctx, { item_id: req.params.id })));
      return reply.code(204).send();
    });
  }
}
