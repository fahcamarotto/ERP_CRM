/**
 * Leitura de extrato bancario (M4.4): OFX (SGML ou XML, blocos STMTTRN) e CSV (data, descricao, valor
 * ou credito e debito). Valor com sinal em centavos (credito positivo), sem float. Funcoes puras.
 */
import { createHash } from 'node:crypto';
import { DataIso, Dinheiro } from '../compartilhado/dinheiro.ts';
import { erroDe, type ErroDominio } from '../compartilhado/result.ts';
import { lerCsv } from './csv.ts';

export const FORMATOS = ['ofx', 'csv'] as const;
export type FormatoExtrato = (typeof FORMATOS)[number];
export const LIMITE_ITENS = 10_000;

export interface ItemLido {
  data: string;
  valor_centavos: number;
  descricao: string;
  identificador: string;
}

export interface LeituraExtrato {
  itens: ItemLido[];
  erros: { linha: number; erros: ErroDominio[] }[];
}

export function detectarFormato(conteudo: string): FormatoExtrato {
  return /OFXHEADER|<OFX>|<STMTTRN>/i.test(conteudo.slice(0, 4000)) ? 'ofx' : 'csv';
}

/** Data em AAAA-MM-DD, DD/MM/AAAA, DD-MM-AAAA ou AAAAMMDD (prefixo do DTPOSTED do OFX). */
export function normalizarData(bruto: string): string | null {
  const s = (bruto ?? '').trim();
  let iso: string | null = null;
  let m: RegExpExecArray | null;
  if ((m = /^(\d{4})-(\d{2})-(\d{2})/.exec(s))) iso = `${m[1]}-${m[2]}-${m[3]}`;
  else if ((m = /^(\d{2})[/-](\d{2})[/-](\d{4})$/.exec(s))) iso = `${m[3]}-${m[2]}-${m[1]}`;
  else if ((m = /^(\d{4})(\d{2})(\d{2})/.exec(s))) iso = `${m[1]}-${m[2]}-${m[3]}`;
  return iso && DataIso.tryCreate(iso).ok ? iso : null;
}

/** Identificador estavel de linha sem id do banco: hash de data, valor, descricao e ordem entre linhas iguais. */
function hashLinha(data: string, valor: number, descricao: string, ocorrencia: number): string {
  return 'h:' + createHash('sha256').update(`${data}|${valor}|${descricao.toLowerCase()}|${ocorrencia}`).digest('hex').slice(0, 40);
}

function finalizar(brutos: (Omit<ItemLido, 'identificador'> & { identificador: string | null; linha: number })[], erros: LeituraExtrato['erros']): LeituraExtrato {
  const vistos = new Map<string, number>();
  const itens = brutos.map((b) => {
    if (b.identificador) return { data: b.data, valor_centavos: b.valor_centavos, descricao: b.descricao, identificador: b.identificador.slice(0, 200) };
    const base = `${b.data}|${b.valor_centavos}|${b.descricao.toLowerCase()}`;
    const n = (vistos.get(base) ?? 0) + 1;
    vistos.set(base, n);
    return { data: b.data, valor_centavos: b.valor_centavos, descricao: b.descricao, identificador: hashLinha(b.data, b.valor_centavos, b.descricao, n) };
  });
  return { itens, erros };
}

export function lerOfx(conteudo: string): LeituraExtrato {
  const blocos = conteudo.split(/<STMTTRN>/i).slice(1);
  const brutos: Parameters<typeof finalizar>[0] = [];
  const erros: LeituraExtrato['erros'] = [];
  blocos.forEach((b, i) => {
    const corpo = b.split(/<\/STMTTRN>/i)[0] ?? b;
    const v = (tag: string) => new RegExp(`<${tag}>\\s*([^<\\r\\n]*)`, 'i').exec(corpo)?.[1]?.trim() ?? '';
    const data = normalizarData(v('DTPOSTED'));
    const valor = Dinheiro.centavosDeTexto(v('TRNAMT'));
    const e: ErroDominio[] = [];
    if (!data) e.push(erroDe('data_invalida', `DTPOSTED invalido: ${v('DTPOSTED')}`, 'data'));
    if (!valor.ok) e.push(...valor.erros);
    else if (valor.valor === 0) e.push(erroDe('valor_invalido', 'Transacao com valor zero', 'valor'));
    if (e.length) { erros.push({ linha: i + 1, erros: e }); return; }
    const descricao = (v('MEMO') || v('NAME') || v('TRNTYPE')).slice(0, 300);
    brutos.push({ linha: i + 1, data: data!, valor_centavos: valor.ok ? valor.valor : 0, descricao, identificador: v('FITID') || null });
  });
  return finalizar(brutos, erros);
}

const COL = {
  data: ['data', 'date', 'data_lancamento', 'dt', 'data_movimento'],
  descricao: ['descricao', 'historico', 'description', 'memo', 'lancamento', 'detalhe'],
  valor: ['valor', 'amount', 'value', 'valor_rs'],
  credito: ['credito', 'entrada', 'credit'],
  debito: ['debito', 'saida', 'debit'],
  id: ['id', 'identificador', 'fitid', 'documento', 'num_doc'],
};

export function lerCsvExtrato(conteudo: string): LeituraExtrato {
  const { cabecalho, linhas } = lerCsv(conteudo);
  const cab = cabecalho.map((c) => c.normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/\s+/g, '_'));
  const idx = (nomes: string[]) => cab.findIndex((c) => nomes.includes(c));
  const [iData, iDesc, iValor, iCred, iDeb, iId] = [idx(COL.data), idx(COL.descricao), idx(COL.valor), idx(COL.credito), idx(COL.debito), idx(COL.id)];
  const erros: LeituraExtrato['erros'] = [];
  if (iData < 0 || (iValor < 0 && iCred < 0 && iDeb < 0)) {
    return { itens: [], erros: [{ linha: 1, erros: [erroDe('csv_invalido', 'CSV precisa das colunas data e valor (ou credito e debito)', 'conteudo')] }] };
  }
  const brutos: Parameters<typeof finalizar>[0] = [];
  linhas.forEach((l, i) => {
    const v = (k: number) => (k >= 0 ? (l[k] ?? '').trim() : '');
    const data = normalizarData(v(iData));
    let valor: number | null = null;
    const e: ErroDominio[] = [];
    if (iValor >= 0 && v(iValor)) {
      const r = Dinheiro.centavosDeTexto(v(iValor));
      if (r.ok) valor = r.valor; else e.push(...r.erros);
    } else {
      const c = v(iCred) ? Dinheiro.centavosDeTexto(v(iCred)) : null;
      const d = v(iDeb) ? Dinheiro.centavosDeTexto(v(iDeb)) : null;
      if (c && !c.ok) e.push(...c.erros);
      if (d && !d.ok) e.push(...d.erros);
      if ((c?.ok || d?.ok) && !e.length) valor = (c?.ok ? Math.abs(c.valor) : 0) - (d?.ok ? Math.abs(d.valor) : 0);
    }
    if (!data) e.push(erroDe('data_invalida', `Data invalida: ${v(iData)}`, 'data'));
    if (!e.length && !valor) e.push(erroDe('valor_invalido', 'Linha sem valor ou com valor zero', 'valor'));
    if (e.length) { erros.push({ linha: i + 2, erros: e }); return; }
    brutos.push({ linha: i + 2, data: data!, valor_centavos: valor!, descricao: v(iDesc).slice(0, 300), identificador: v(iId) || null });
  });
  return finalizar(brutos, erros);
}

export function lerExtrato(conteudo: string, formato: FormatoExtrato): LeituraExtrato {
  return formato === 'ofx' ? lerOfx(conteudo) : lerCsvExtrato(conteudo);
}
