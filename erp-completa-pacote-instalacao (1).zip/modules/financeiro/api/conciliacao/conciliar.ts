/**
 * Conciliacao (M4.4) e ImportarExtrato, Conciliar (M4.6). A API grava o extrato e a intencao do job
 * na outbox na mesma transacao (SolicitarImportacaoExtrato); o worker le o arquivo, grava os itens
 * sem duplicar (identificador por conta) e sugere o par de cada item por valor e data (ProcessarExtrato).
 * A confirmacao e manual: Conciliar (com lancamento existente), ConciliarCriando ou IgnorarItem.
 */
import { DataIso } from '../compartilhado/dinheiro.ts';
import type { ContextoCaso } from '../compartilhado/efeitos.ts';
import { erroDe, fail, ok, okVazio, type Result } from '../compartilhado/result.ts';
import type { GravarLancamento, ObterLancamento } from '../lancamento/model/portas.ts';
import type { RegistrarLancamento } from '../lancamento/use-case/registrar-lancamento.ts';
import { detectarFormato, lerExtrato, LIMITE_ITENS, type FormatoExtrato, type ItemLido } from './extrato.ts';

export const TIPO_JOB_EXTRATO = 'financeiro.importar_extrato';
/** Janela de datas (dias) para sugerir o par de um item do extrato. */
export const JANELA_DIAS = 5;
const T_EXTRATOS = 'financeiro_extratos';
const T_ITENS = 'financeiro_extrato_itens';

export interface ExtratoDados {
  id: string;
  conta_id: string;
  nome_arquivo: string;
  formato: FormatoExtrato;
  conteudo: string;
  estado: 'pendente' | 'processando' | 'concluida' | 'erro';
}

export interface ProgressoExtrato {
  estado: ExtratoDados['estado'];
  total: number;
  importados: number;
  duplicados: number;
  sugeridos: number;
  erros: unknown[];
  job_id?: string;
}

export interface PortaExtratos {
  inserir(d: Omit<ExtratoDados, 'estado'>): Promise<void>;
  obter(id: string): Promise<ExtratoDados | null>;
  progresso(id: string, p: ProgressoExtrato): Promise<void>;
  contaAtiva(id: string): Promise<boolean>;
}

export interface ItemDados {
  id: string;
  extrato_id: string;
  conta_id: string;
  data: string;
  valor_centavos: number;
  descricao: string;
  identificador: string;
  estado: 'pendente' | 'conciliado' | 'ignorado';
  sugestao_lancamento_id: string | null;
  lancamento_id: string | null;
}

export interface CandidatoPar {
  id: string;
  data: string;
  descricao: string;
}

export interface PortaItens {
  /** Grava se o identificador ainda nao existe na conta; devolve false para duplicado. */
  inserirSeNovo(i: ItemDados): Promise<boolean>;
  obterItem(id: string): Promise<ItemDados | null>;
  atualizarItem(i: ItemDados): Promise<void>;
  pendentesSemSugestao(f: { extrato_id?: string; conta_id?: string }): Promise<ItemDados[]>;
  /** Lancamentos ativos nao conciliados com efeito exato `valor` na conta, data entre de e ate, sem item conciliado. */
  candidatos(contaId: string, valor: number, de: string, ate: string): Promise<CandidatoPar[]>;
}

export interface FilaJobs {
  enfileirar(tipo: string, payload: Record<string, unknown>): Promise<string>;
}

/** Escolhe o par mais proximo na data (valor ja igual pelo filtro), ignorando os ja reservados. */
export function escolherPar(item: Pick<ItemDados, 'data'>, candidatos: CandidatoPar[], reservados: Set<string> = new Set()): CandidatoPar | null {
  const d = DataIso.create(item.data);
  let melhor: { c: CandidatoPar; dist: number } | null = null;
  for (const c of candidatos) {
    if (reservados.has(c.id)) continue;
    const dist = Math.abs(d.diasAte(DataIso.create(c.data)));
    if (dist <= JANELA_DIAS && (!melhor || dist < melhor.dist)) melhor = { c, dist };
  }
  return melhor?.c ?? null;
}

function deslocar(data: string, dias: number): string {
  const t = Date.parse(`${data}T00:00:00Z`) + dias * 86_400_000;
  return new Date(t).toISOString().slice(0, 10);
}

export class SolicitarImportacaoExtrato {
  constructor(private readonly deps: { extratos: PortaExtratos; fila: FilaJobs; novoId: () => string }) {}

  async execute(ctx: ContextoCaso, e: { conta_id: string; nome_arquivo: string; conteudo: string; formato?: FormatoExtrato }): Promise<Result<{ extrato_id: string; job_id: string }>> {
    if (!(await this.deps.extratos.contaAtiva(e.conta_id))) return fail(erroDe('conta_invalida', 'Conta nao encontrada ou arquivada', 'conta_id'));
    const formato = e.formato ?? detectarFormato(e.conteudo ?? '');
    const leitura = lerExtrato(e.conteudo ?? '', formato);
    if (leitura.itens.length === 0) {
      return fail(erroDe('extrato_invalido', 'Nenhuma transacao valida no arquivo', 'conteudo', { erros: leitura.erros.slice(0, 20) }));
    }
    if (leitura.itens.length > LIMITE_ITENS) return fail(erroDe('extrato_invalido', `Maximo de ${LIMITE_ITENS} transacoes por arquivo`, 'conteudo'));
    const id = this.deps.novoId();
    await this.deps.extratos.inserir({ id, conta_id: e.conta_id, nome_arquivo: e.nome_arquivo.slice(0, 200), formato, conteudo: e.conteudo });
    const job = await this.deps.fila.enfileirar(TIPO_JOB_EXTRATO, { extrato_id: id });
    await this.deps.extratos.progresso(id, { estado: 'pendente', total: leitura.itens.length, importados: 0, duplicados: 0, sugeridos: 0, erros: leitura.erros.slice(0, 500), job_id: job });
    await ctx.efeitos.auditar('extrato.importar', T_EXTRATOS, id, undefined, { conta_id: e.conta_id, nome_arquivo: e.nome_arquivo, formato, itens: leitura.itens.length });
    return ok({ extrato_id: id, job_id: job });
  }
}

export class SugerirPares {
  constructor(private readonly deps: { itens: PortaItens }) {}
  async execute(_ctx: ContextoCaso, f: { extrato_id?: string; conta_id?: string }): Promise<Result<{ sugeridos: number }>> {
    const reservados = new Set<string>();
    let sugeridos = 0;
    for (const item of await this.deps.itens.pendentesSemSugestao(f)) {
      const cands = await this.deps.itens.candidatos(item.conta_id, item.valor_centavos, deslocar(item.data, -JANELA_DIAS), deslocar(item.data, JANELA_DIAS));
      const par = escolherPar(item, cands, reservados);
      if (!par) continue;
      reservados.add(par.id);
      await this.deps.itens.atualizarItem({ ...item, sugestao_lancamento_id: par.id });
      sugeridos++;
    }
    return ok({ sugeridos });
  }
}

export class ProcessarExtrato {
  constructor(private readonly deps: { extratos: PortaExtratos; itens: PortaItens; sugerir: SugerirPares; novoId: () => string }) {}

  async execute(ctx: ContextoCaso, e: { extrato_id: string }): Promise<Result<{ importados: number; duplicados: number; sugeridos: number }>> {
    const ext = await this.deps.extratos.obter(e.extrato_id);
    if (!ext) return fail(erroDe('nao_encontrado', 'Extrato nao encontrado'));
    if (ext.estado === 'concluida') return ok({ importados: 0, duplicados: 0, sugeridos: 0 });
    const leitura = lerExtrato(ext.conteudo, ext.formato);
    const total = leitura.itens.length;
    let importados = 0;
    let duplicados = 0;
    await this.deps.extratos.progresso(ext.id, { estado: 'processando', total, importados, duplicados, sugeridos: 0, erros: leitura.erros.slice(0, 500) });
    for (const it of leitura.itens as ItemLido[]) {
      const novo = await this.deps.itens.inserirSeNovo({
        id: this.deps.novoId(), extrato_id: ext.id, conta_id: ext.conta_id, data: it.data, valor_centavos: it.valor_centavos,
        descricao: it.descricao, identificador: it.identificador, estado: 'pendente', sugestao_lancamento_id: null, lancamento_id: null,
      });
      if (novo) importados++; else duplicados++;
    }
    const s = await this.deps.sugerir.execute(ctx, { extrato_id: ext.id });
    const sugeridos = s.ok ? s.valor.sugeridos : 0;
    await this.deps.extratos.progresso(ext.id, { estado: 'concluida', total, importados, duplicados, sugeridos, erros: leitura.erros.slice(0, 500) });
    await ctx.efeitos.publicar('extrato.importado', { id: ext.id, conta_id: ext.conta_id, total, importados, duplicados, sugeridos, erros: leitura.erros.length });
    return ok({ importados, duplicados, sugeridos });
  }
}

type DepsConciliar = { itens: PortaItens; lancamentos: ObterLancamento & GravarLancamento };

export class Conciliar {
  constructor(private readonly deps: DepsConciliar) {}
  async execute(ctx: ContextoCaso, e: { item_id: string; lancamento_id: string }): Promise<Result<void>> {
    const item = await this.deps.itens.obterItem(e.item_id);
    if (!item) return fail(erroDe('nao_encontrado', 'Item do extrato nao encontrado'));
    if (item.estado !== 'pendente') return fail(erroDe('transicao_invalida', `Item ja esta ${item.estado}`, 'estado'));
    const lanc = await this.deps.lancamentos.obterPorId(e.lancamento_id);
    if (!lanc) return fail(erroDe('nao_encontrado', 'Lancamento nao encontrado'));
    const efeito = lanc.efeitoNaConta(item.conta_id);
    if (efeito === 0) return fail(erroDe('conta_divergente', 'Lancamento nao movimenta a conta do extrato', 'lancamento_id'));
    if (efeito !== item.valor_centavos) {
      return fail(erroDe('valor_divergente', 'Valor do lancamento difere do extrato', 'lancamento_id', { extrato: item.valor_centavos, lancamento: efeito }));
    }
    const r = lanc.conciliar(item.data);
    if (!r.ok) return r;
    await this.deps.lancamentos.atualizar(r.valor);
    await this.deps.itens.atualizarItem({ ...item, estado: 'conciliado', lancamento_id: lanc.id, sugestao_lancamento_id: lanc.id });
    await ctx.efeitos.historico('financeiro_lancamentos', lanc.id, { conciliado: false }, { conciliado: true, extrato_item_id: item.id });
    await ctx.efeitos.auditar('extrato.conciliar', T_ITENS, item.id, { estado: 'pendente' }, { estado: 'conciliado', lancamento_id: lanc.id });
    return okVazio();
  }
}

export class ConciliarCriando {
  constructor(private readonly deps: { itens: PortaItens; registrar: RegistrarLancamento; conciliar: Conciliar }) {}
  async execute(ctx: ContextoCaso, e: { item_id: string; descricao?: string | null; categoria_id?: string | null; centro_custo_id?: string | null; parceiro_id?: string | null }): Promise<Result<{ lancamento_id: string }>> {
    const item = await this.deps.itens.obterItem(e.item_id);
    if (!item) return fail(erroDe('nao_encontrado', 'Item do extrato nao encontrado'));
    if (item.estado !== 'pendente') return fail(erroDe('transicao_invalida', `Item ja esta ${item.estado}`, 'estado'));
    const r = await this.deps.registrar.execute(ctx, {
      tipo: item.valor_centavos > 0 ? 'entrada' : 'saida', descricao: (e.descricao ?? '').trim() || item.descricao || 'Lancamento do extrato',
      conta_id: item.conta_id, categoria_id: e.categoria_id ?? null, centro_custo_id: e.centro_custo_id ?? null, parceiro_id: e.parceiro_id ?? null,
      valor_centavos: Math.abs(item.valor_centavos), data_competencia: item.data, data_caixa: item.data, origem: 'extrato',
      chave_idempotencia: `extrato-item:${item.id}`,
    });
    if (!r.ok) return r;
    const c = await this.deps.conciliar.execute(ctx, { item_id: item.id, lancamento_id: r.valor.id });
    if (!c.ok) return c;
    return ok({ lancamento_id: r.valor.id });
  }
}

export class AlternarItem {
  constructor(private readonly deps: { itens: PortaItens }, private readonly acao: 'ignorar' | 'reabrir') {}
  async execute(ctx: ContextoCaso, e: { item_id: string }): Promise<Result<void>> {
    const item = await this.deps.itens.obterItem(e.item_id);
    if (!item) return fail(erroDe('nao_encontrado', 'Item do extrato nao encontrado'));
    const de = this.acao === 'ignorar' ? 'pendente' : 'ignorado';
    const para = this.acao === 'ignorar' ? 'ignorado' : 'pendente';
    if (item.estado !== de) return fail(erroDe('transicao_invalida', `Item ${item.estado} nao pode ser ${this.acao === 'ignorar' ? 'ignorado' : 'reaberto'}`, 'estado'));
    await this.deps.itens.atualizarItem({ ...item, estado: para });
    await ctx.efeitos.auditar(`extrato.${this.acao}`, T_ITENS, item.id, { estado: de }, { estado: para });
    return okVazio();
  }
}
