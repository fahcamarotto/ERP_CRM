/** Consulta da arvore de categorias (lista plana com nivel, caminho e uso, ordenada pela arvore). */
import type pg from 'pg';

export async function listarCategorias(c: pg.PoolClient, f: { natureza?: string; ativas?: boolean } = {}) {
  const r = await c.query(
    `WITH RECURSIVE arv AS (
       SELECT k.id, k.nome, k.natureza, k.parent_id, k.codigo, k.ativa, k.created_at, k.updated_at, 0 AS nivel,
              lower(k.nome) AS ordem, k.nome::text AS caminho
       FROM financeiro_categorias k WHERE k.parent_id IS NULL AND k.deleted_at IS NULL
       UNION ALL
       SELECT k.id, k.nome, k.natureza, k.parent_id, k.codigo, k.ativa, k.created_at, k.updated_at, arv.nivel + 1,
              arv.ordem || ' / ' || lower(k.nome), arv.caminho || ' / ' || k.nome
       FROM financeiro_categorias k JOIN arv ON k.parent_id = arv.id WHERE k.deleted_at IS NULL AND arv.nivel < 10)
     SELECT arv.*, (SELECT count(*)::int FROM financeiro_lancamentos l WHERE l.categoria_id = arv.id AND l.deleted_at IS NULL) AS em_uso
     FROM arv WHERE ($1::text IS NULL OR arv.natureza = $1) AND ($2::boolean IS NULL OR arv.ativa = $2)
     ORDER BY arv.natureza DESC, arv.ordem`,
    [f.natureza ?? null, f.ativas ?? null],
  );
  return r.rows;
}

export async function obterCategoria(c: pg.PoolClient, id: string) {
  return (await listarCategorias(c)).find((x) => x.id === id) ?? null;
}
