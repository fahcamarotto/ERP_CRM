/** Casos de uso da Categoria (M4.2): CriarCategoria, EditarCategoria e ExcluirCategoria. */
import type { ContextoCaso } from '../../compartilhado/efeitos.ts';
import { erroDe, fail, ok, okVazio, type ErroDominio, type Result } from '../../compartilhado/result.ts';
import { Categoria, conferirArvore, type DadosCategoria } from '../model/categoria.ts';
import type { ConsultarArvore, GravarCategoria, ObterCategoria } from '../model/portas.ts';

const TABELA = 'financeiro_categorias';
export interface DepsCategoria { repo: ObterCategoria & GravarCategoria & ConsultarArvore }

async function conferir(repo: DepsCategoria['repo'], cat: Categoria, alturaFilhos: number): Promise<ErroDominio[]> {
  const d = cat.paraDados();
  const erros: ErroDominio[] = [];
  if (d.parent_id) {
    const mae = await repo.obterPorId(d.parent_id);
    erros.push(...conferirArvore(d, mae?.paraDados() ?? null, mae ? [mae.id, ...(await repo.ancestrais(mae.id))] : [], alturaFilhos));
  }
  const irma = await repo.buscarIrma(d.natureza, d.parent_id, d.nome);
  if (irma && irma.id !== d.id) erros.push(erroDe('conflito', 'Ja existe categoria com este nome neste nivel', 'nome', { id: irma.id }));
  return erros;
}

export class CriarCategoria {
  constructor(private readonly deps: DepsCategoria) {}
  async execute(ctx: ContextoCaso, e: DadosCategoria): Promise<Result<{ id: string }>> {
    const r = Categoria.tryCreate(e);
    if (!r.ok) return r;
    const erros = await conferir(this.deps.repo, r.valor, 0);
    if (erros.length) return fail(...erros);
    await this.deps.repo.inserir(r.valor);
    const d = r.valor.paraDados();
    await ctx.efeitos.auditar('categoria.criar', TABELA, d.id, undefined, d);
    return ok({ id: d.id });
  }
}

export class EditarCategoria {
  constructor(private readonly deps: DepsCategoria) {}
  async execute(ctx: ContextoCaso, e: { id: string } & Partial<Omit<DadosCategoria, 'natureza'>> & { ativa?: boolean }): Promise<Result<void>> {
    const { id, ...mud } = e;
    const atual = await this.deps.repo.obterPorId(id);
    if (!atual) return fail(erroDe('nao_encontrado', 'Categoria nao encontrada'));
    const r = atual.editar(mud);
    if (!r.ok) return r;
    const erros = await conferir(this.deps.repo, r.valor, await this.deps.repo.alturaFilhos(id));
    if (erros.length) return fail(...erros);
    await this.deps.repo.atualizar(r.valor);
    const antes = atual.paraDados() as unknown as Record<string, unknown>;
    const depois = r.valor.paraDados() as unknown as Record<string, unknown>;
    await ctx.efeitos.historico(TABELA, id, antes, depois);
    await ctx.efeitos.auditar('categoria.editar', TABELA, id, antes, depois);
    return okVazio();
  }
}

export class ExcluirCategoria {
  constructor(private readonly deps: DepsCategoria) {}
  async execute(ctx: ContextoCaso, e: { id: string }): Promise<Result<void>> {
    const atual = await this.deps.repo.obterPorId(e.id);
    if (!atual) return fail(erroDe('nao_encontrado', 'Categoria nao encontrada'));
    const uso = await this.deps.repo.uso(e.id);
    if (uso.filhas > 0) return fail(erroDe('conflito', 'Categoria tem subcategorias: exclua ou mova as filhas antes', 'id', uso));
    if (uso.lancamentos > 0) return fail(erroDe('conflito', 'Categoria em uso por lancamentos: desative em vez de excluir', 'id', uso));
    await this.deps.repo.excluir(e.id);
    await ctx.efeitos.auditar('categoria.excluir', TABELA, e.id, atual.paraDados(), undefined);
    return okVazio();
  }
}
