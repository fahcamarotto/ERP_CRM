/** Rotas REST da Categoria fora das tools (criar, editar, excluir). Listar e @tool financeiro.categorias. */
import { esquemaErro, requer, type FastifyInstance } from '@erp/api/sdk';
import { naTransacao } from '../borda.ts';
import { exigirOk } from '../compartilhado/result.ts';
import { propsCategoria, uuid } from '../esquemas.ts';
import type { DadosCategoria } from './model/categoria.ts';
import { obterCategoria } from './query/categorias.ts';

const tags = ['financeiro'];
const paramId = { type: 'object', required: ['id'], properties: { id: uuid } } as const;
const erros = { 400: esquemaErro, 403: esquemaErro, 404: esquemaErro, 409: esquemaErro };
const { natureza: _n, ...propsEdicao } = propsCategoria;

export function rotasCategoria(app: FastifyInstance): void {
  app.post<{ Body: DadosCategoria }>('/categorias', {
    preHandler: requer('financeiro.criar'),
    schema: { tags, summary: 'Cria categoria de receita ou despesa, raiz ou filha (CriarCategoria)', body: { type: 'object', additionalProperties: false, required: ['nome', 'natureza'], properties: propsCategoria }, response: erros },
  }, async (req, reply) => reply.code(201).send(await naTransacao(req, async (casos, ctx, c) => {
    const { id } = exigirOk(await casos.criarCategoria.execute(ctx, req.body));
    return obterCategoria(c, id);
  })));

  app.patch<{ Params: { id: string }; Body: Partial<DadosCategoria> & { ativa?: boolean } }>('/categorias/:id', {
    preHandler: requer('financeiro.editar'),
    schema: { tags, summary: 'Edita, move na arvore ou desativa categoria (natureza nao muda)', params: paramId,
      body: { type: 'object', additionalProperties: false, properties: { ...propsEdicao, ativa: { type: 'boolean' } } }, response: erros },
  }, (req) => naTransacao(req, async (casos, ctx, c) => {
    exigirOk(await casos.editarCategoria.execute(ctx, { ...req.body, id: req.params.id }));
    return obterCategoria(c, req.params.id);
  }));

  app.delete<{ Params: { id: string } }>('/categorias/:id', {
    preHandler: requer('financeiro.excluir'),
    schema: { tags, summary: 'Exclui categoria sem filhas e sem lancamentos (exclusao logica)', params: paramId, response: erros },
  }, async (req, reply) => {
    await naTransacao(req, async (casos, ctx) => exigirOk(await casos.excluirCategoria.execute(ctx, { id: req.params.id })));
    return reply.code(204).send();
  });
}
