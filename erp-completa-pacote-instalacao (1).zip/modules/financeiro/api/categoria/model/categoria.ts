/**
 * Entidade Categoria (M4.2): arvore de receita e despesa. Filha herda a natureza da mae,
 * profundidade maxima 3 e sem ciclo (conferido no caso de uso com a porta da arvore).
 */
import { randomUUID } from 'node:crypto';
import { erroDe, fail, ok, type ErroDominio, type Result } from '../../compartilhado/result.ts';

export const NATUREZAS = ['receita', 'despesa'] as const;
export type Natureza = (typeof NATUREZAS)[number];
export const PROFUNDIDADE_MAXIMA = 3;

export interface DadosCategoria {
  nome: string;
  natureza: Natureza;
  parent_id?: string | null;
  codigo?: string | null;
}

export interface CategoriaDados {
  id: string;
  nome: string;
  natureza: Natureza;
  parent_id: string | null;
  codigo: string | null;
  ativa: boolean;
}

const t = (v?: string | null) => (v ?? '').trim() || null;

function validar(d: CategoriaDados): ErroDominio[] {
  const e: ErroDominio[] = [];
  if (d.nome.length < 2 || d.nome.length > 80) e.push(erroDe('nome_invalido', 'Nome deve ter de 2 a 80 caracteres', 'nome'));
  if (!NATUREZAS.includes(d.natureza)) e.push(erroDe('natureza_invalida', 'Natureza deve ser receita ou despesa', 'natureza'));
  if (d.codigo !== null && !/^[0-9A-Za-z.]{1,20}$/.test(d.codigo)) e.push(erroDe('codigo_invalido', 'Codigo com letras, digitos e ponto (ate 20)', 'codigo'));
  if (d.parent_id !== null && d.parent_id === d.id) e.push(erroDe('ciclo', 'Categoria nao pode ser mae dela mesma', 'parent_id'));
  return e;
}

export class Categoria {
  private constructor(private readonly d: CategoriaDados) {}

  static tryCreate(e: DadosCategoria, id: string = randomUUID()): Result<Categoria> {
    const d: CategoriaDados = { id, nome: (e.nome ?? '').trim(), natureza: e.natureza, parent_id: t(e.parent_id), codigo: t(e.codigo), ativa: true };
    const erros = validar(d);
    return erros.length ? fail(...erros) : ok(new Categoria(d));
  }

  static create(e: DadosCategoria, id?: string): Categoria {
    const r = Categoria.tryCreate(e, id);
    if (!r.ok) throw new Error(r.erros.map((x) => x.mensagem).join('; '));
    return r.valor;
  }

  static reidratar(d: CategoriaDados): Categoria { return new Categoria({ ...d }); }

  get id(): string { return this.d.id; }
  get natureza(): Natureza { return this.d.natureza; }
  get parentId(): string | null { return this.d.parent_id; }
  get nome(): string { return this.d.nome; }
  get ativa(): boolean { return this.d.ativa; }

  /** Natureza nao muda depois de criada (os lancamentos ja classificados dependem dela). */
  editar(e: Partial<Omit<DadosCategoria, 'natureza'>> & { ativa?: boolean }): Result<Categoria> {
    const tem = (k: keyof typeof e) => e[k] !== undefined;
    const n: CategoriaDados = {
      ...this.d,
      nome: tem('nome') ? (e.nome ?? '').trim() : this.d.nome,
      parent_id: tem('parent_id') ? t(e.parent_id) : this.d.parent_id,
      codigo: tem('codigo') ? t(e.codigo) : this.d.codigo,
      ativa: tem('ativa') ? !!e.ativa : this.d.ativa,
    };
    const erros = validar(n);
    return erros.length ? fail(...erros) : ok(new Categoria(n));
  }

  paraDados(): CategoriaDados { return { ...this.d }; }
}

/**
 * Confere a posicao na arvore: mae da mesma natureza, sem ciclo e profundidade ate 3.
 * `ancestrais` sao os ids da mae ate a raiz (mae primeiro); `alturaFilhos` e quantos niveis existem abaixo da categoria.
 */
export function conferirArvore(cat: CategoriaDados, mae: CategoriaDados | null, ancestrais: string[], alturaFilhos = 0): ErroDominio[] {
  if (!cat.parent_id) return [];
  if (!mae) return [erroDe('categoria_mae_invalida', 'Categoria mae nao encontrada', 'parent_id')];
  const e: ErroDominio[] = [];
  if (mae.natureza !== cat.natureza) e.push(erroDe('natureza_divergente', 'Categoria mae tem outra natureza', 'parent_id'));
  if (ancestrais.includes(cat.id)) e.push(erroDe('ciclo', 'A categoria mae nao pode ser uma filha desta categoria', 'parent_id'));
  if (ancestrais.length + 1 + alturaFilhos > PROFUNDIDADE_MAXIMA) e.push(erroDe('profundidade_excedida', `Arvore com no maximo ${PROFUNDIDADE_MAXIMA} niveis`, 'parent_id'));
  return e;
}
