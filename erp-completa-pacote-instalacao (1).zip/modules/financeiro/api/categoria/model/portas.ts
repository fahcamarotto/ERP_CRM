/** Portas do repositorio do agregado Categoria, segregadas por operacao. */
import type { Categoria, Natureza } from './categoria.ts';

export interface ObterCategoria {
  obterPorId(id: string): Promise<Categoria | null>;
}

export interface GravarCategoria {
  inserir(c: Categoria): Promise<void>;
  atualizar(c: Categoria): Promise<void>;
  excluir(id: string): Promise<void>;
}

export interface ConsultarArvore {
  /** Ids da mae ate a raiz (mae primeiro). */
  ancestrais(id: string): Promise<string[]>;
  /** Niveis abaixo da categoria (0 = folha). */
  alturaFilhos(id: string): Promise<number>;
  buscarIrma(natureza: Natureza, parentId: string | null, nome: string): Promise<Categoria | null>;
  /** Filhas vivas e lancamentos que usam a categoria. */
  uso(id: string): Promise<{ filhas: number; lancamentos: number }>;
}
