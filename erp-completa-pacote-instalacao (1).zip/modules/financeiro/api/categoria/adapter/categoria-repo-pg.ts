/** Adaptador Postgres das portas do agregado Categoria. */
import type pg from 'pg';
import { Categoria, type CategoriaDados, type Natureza } from '../model/categoria.ts';
import type { ConsultarArvore, GravarCategoria, ObterCategoria } from '../model/portas.ts';

const COLUNAS = 'id, nome, natureza, parent_id, codigo, ativa';

export class CategoriaRepoPg implements ObterCategoria, GravarCategoria, ConsultarArvore {
  constructor(private readonly c: pg.PoolClient) {}

  async obterPorId(id: string): Promise<Categoria | null> {
    const r = await this.c.query(`SELECT ${COLUNAS} FROM financeiro_categorias WHERE id = $1 AND deleted_at IS NULL`, [id]);
    return r.rows[0] ? Categoria.reidratar(r.rows[0] as CategoriaDados) : null;
  }

  async inserir(x: Categoria): Promise<void> {
    const d = x.paraDados();
    await this.c.query(
      'INSERT INTO financeiro_categorias (id, nome, natureza, parent_id, codigo, ativa, creator_id) VALUES ($1, $2, $3, $4, $5, $6, nucleo_usuario_atual())',
      [d.id, d.nome, d.natureza, d.parent_id, d.codigo, d.ativa],
    );
  }

  async atualizar(x: Categoria): Promise<void> {
    const d = x.paraDados();
    await this.c.query('UPDATE financeiro_categorias SET nome = $2, parent_id = $3, codigo = $4, ativa = $5 WHERE id = $1 AND deleted_at IS NULL',
      [d.id, d.nome, d.parent_id, d.codigo, d.ativa]);
  }

  async excluir(id: string): Promise<void> {
    await this.c.query('UPDATE financeiro_categorias SET deleted_at = now() WHERE id = $1 AND deleted_at IS NULL', [id]);
  }

  async ancestrais(id: string): Promise<string[]> {
    const r = await this.c.query(
      `WITH RECURSIVE a(id, parent_id, n) AS (
         SELECT id, parent_id, 0 FROM financeiro_categorias WHERE id = $1 AND deleted_at IS NULL
         UNION ALL SELECT p.id, p.parent_id, a.n + 1 FROM financeiro_categorias p JOIN a ON p.id = a.parent_id WHERE p.deleted_at IS NULL AND a.n < 10)
       SELECT id FROM a WHERE n > 0 ORDER BY n`, [id]);
    return r.rows.map((x) => x.id as string);
  }

  async alturaFilhos(id: string): Promise<number> {
    const r = await this.c.query(
      `WITH RECURSIVE f(id, n) AS (
         SELECT id, 1 FROM financeiro_categorias WHERE parent_id = $1 AND deleted_at IS NULL
         UNION ALL SELECT c.id, f.n + 1 FROM financeiro_categorias c JOIN f ON c.parent_id = f.id WHERE c.deleted_at IS NULL AND f.n < 10)
       SELECT coalesce(max(n), 0)::int AS h FROM f`, [id]);
    return r.rows[0].h as number;
  }

  async buscarIrma(natureza: Natureza, parentId: string | null, nome: string): Promise<Categoria | null> {
    const r = await this.c.query(
      `SELECT ${COLUNAS} FROM financeiro_categorias WHERE natureza = $1 AND parent_id IS NOT DISTINCT FROM $2::uuid AND lower(nome) = lower($3) AND deleted_at IS NULL`,
      [natureza, parentId, nome]);
    return r.rows[0] ? Categoria.reidratar(r.rows[0] as CategoriaDados) : null;
  }

  async uso(id: string): Promise<{ filhas: number; lancamentos: number }> {
    const r = await this.c.query(
      `SELECT (SELECT count(*)::int FROM financeiro_categorias WHERE parent_id = $1 AND deleted_at IS NULL) AS filhas,
              (SELECT count(*)::int FROM financeiro_lancamentos WHERE categoria_id = $1 AND deleted_at IS NULL) AS lancamentos`, [id]);
    return r.rows[0] as { filhas: number; lancamentos: number };
  }
}
