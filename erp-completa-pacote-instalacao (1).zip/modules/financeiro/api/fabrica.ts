/**
 * Composicao do modulo: liga casos de uso aos adaptadores Postgres para um cliente de transacao.
 * Usada pelas rotas, pelas tools, pelo worker e pelo seed. Nao importa Fastify nem o pool do servidor.
 */
import { randomUUID } from 'node:crypto';
import type pg from 'pg';
import { CategoriaRepoPg } from './categoria/adapter/categoria-repo-pg.ts';
import { CriarCategoria, EditarCategoria, ExcluirCategoria } from './categoria/use-case/categorias.ts';
import { CentroCustoRepoPg } from './centro-custo/adapter/centro-custo-repo-pg.ts';
import { CriarCentroCusto, EditarCentroCusto, ExcluirCentroCusto } from './centro-custo/use-case/centros-custo.ts';
import { hojeIso } from './compartilhado/dinheiro.ts';
import { ConciliacaoRepoPg, FilaOutboxPg } from './conciliacao/conciliacao-repo-pg.ts';
import { AlternarItem, Conciliar, ConciliarCriando, ProcessarExtrato, SolicitarImportacaoExtrato, SugerirPares } from './conciliacao/conciliar.ts';
import { ContaRepoPg } from './conta/adapter/conta-repo-pg.ts';
import { AlternarConta, CriarConta, EditarConta } from './conta/use-case/contas.ts';
import { ExportacaoRepoPg } from './exportacao/exportacao-repo-pg.ts';
import { ProcessarExportacao, SolicitarExportacao } from './exportacao/exportar-contabil.ts';
import { LancamentoRepoPg } from './lancamento/adapter/lancamento-repo-pg.ts';
import { AnexarComprovante, EditarLancamento, EstornarLancamento } from './lancamento/use-case/editar-lancamento.ts';
import { RegistrarLancamento, Transferir } from './lancamento/use-case/registrar-lancamento.ts';

export function casosDeUso(c: pg.PoolClient) {
  const contas = new ContaRepoPg(c);
  const categorias = new CategoriaRepoPg(c);
  const centros = new CentroCustoRepoPg(c);
  const lancamentos = new LancamentoRepoPg(c);
  const conciliacao = new ConciliacaoRepoPg(c);
  const exportacoes = new ExportacaoRepoPg(c);
  const fila = new FilaOutboxPg(c);
  const depsLanc = { repo: lancamentos, refs: lancamentos };
  const registrarLancamento = new RegistrarLancamento(depsLanc);
  const sugerirPares = new SugerirPares({ itens: conciliacao });
  const conciliar = new Conciliar({ itens: conciliacao, lancamentos });
  return {
    criarConta: new CriarConta({ repo: contas }),
    editarConta: new EditarConta({ repo: contas }),
    arquivarConta: new AlternarConta({ repo: contas }, 'arquivar'),
    reativarConta: new AlternarConta({ repo: contas }, 'reativar'),
    criarCategoria: new CriarCategoria({ repo: categorias }),
    editarCategoria: new EditarCategoria({ repo: categorias }),
    excluirCategoria: new ExcluirCategoria({ repo: categorias }),
    criarCentroCusto: new CriarCentroCusto({ repo: centros }),
    editarCentroCusto: new EditarCentroCusto({ repo: centros }),
    excluirCentroCusto: new ExcluirCentroCusto({ repo: centros }),
    registrarLancamento,
    transferir: new Transferir(depsLanc),
    editarLancamento: new EditarLancamento(depsLanc),
    estornarLancamento: new EstornarLancamento({ repo: lancamentos, hoje: hojeIso }),
    anexarComprovante: new AnexarComprovante(depsLanc),
    importarExtrato: new SolicitarImportacaoExtrato({ extratos: conciliacao, fila, novoId: randomUUID }),
    processarExtrato: new ProcessarExtrato({ extratos: conciliacao, itens: conciliacao, sugerir: sugerirPares, novoId: randomUUID }),
    sugerirPares,
    conciliar,
    conciliarCriando: new ConciliarCriando({ itens: conciliacao, registrar: registrarLancamento, conciliar }),
    ignorarItem: new AlternarItem({ itens: conciliacao }, 'ignorar'),
    reabrirItem: new AlternarItem({ itens: conciliacao }, 'reabrir'),
    exportarContabil: new SolicitarExportacao({ exportacoes, fila, novoId: randomUUID }),
    processarExportacao: new ProcessarExportacao({ exportacoes }),
  };
}

export type CasosDeUso = ReturnType<typeof casosDeUso>;
