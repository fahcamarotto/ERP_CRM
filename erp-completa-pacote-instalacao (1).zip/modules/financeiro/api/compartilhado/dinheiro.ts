/**
 * Objetos de valor compartilhados pelos agregados do Financeiro.
 * Dinheiro: centavos inteiros e moeda ISO 4217, nunca float. DataIso: AAAA-MM-DD valida no calendario.
 */
import { erroDe, fail, ok, type Result } from './result.ts';

/** Maior valor aceito (9 trilhoes na unidade da moeda): abaixo de Number.MAX_SAFE_INTEGER. */
export const MAX_CENTAVOS = 900_000_000_000_000;

export class Dinheiro {
  private constructor(readonly centavos: number, readonly moeda: string) {}

  /** Valor positivo em centavos (inteiro). */
  static tryCreate(centavos: unknown, moeda: unknown = 'BRL', campo = 'valor_centavos'): Result<Dinheiro> {
    const m = typeof moeda === 'string' ? moeda.trim().toUpperCase() : '';
    const erros = [];
    if (typeof centavos !== 'number' || !Number.isSafeInteger(centavos)) erros.push(erroDe('valor_invalido', 'Valor deve ser inteiro em centavos', campo));
    else if (centavos <= 0) erros.push(erroDe('valor_invalido', 'Valor deve ser maior que zero', campo));
    else if (centavos > MAX_CENTAVOS) erros.push(erroDe('valor_invalido', 'Valor acima do limite', campo));
    if (!/^[A-Z]{3}$/.test(m)) erros.push(erroDe('moeda_invalida', 'Moeda em ISO 4217 (BRL, USD, EUR)', 'moeda'));
    return erros.length ? fail(...erros) : ok(new Dinheiro(centavos as number, m));
  }

  static create(centavos: number, moeda = 'BRL'): Dinheiro {
    const r = Dinheiro.tryCreate(centavos, moeda);
    if (!r.ok) throw new Error(r.erros.map((e) => e.mensagem).join('; '));
    return r.valor;
  }

  /**
   * Converte texto decimal ("1.234,56", "1234.56", "-89,9") em centavos com sinal, sem passar por float.
   * Ultimo separador (ponto ou virgula) seguido de 1 ou 2 digitos e o decimal; os outros sao milhar.
   */
  static centavosDeTexto(bruto: string): Result<number> {
    const s = (bruto ?? '').trim().replace(/\s/g, '').replace(/^R\$/i, '');
    const m = /^([+-]?)(\d[\d.,]*)$/.exec(s);
    if (!m) return fail(erroDe('valor_invalido', `Valor invalido: ${bruto}`, 'valor'));
    const sinal = m[1] === '-' ? -1 : 1;
    const corpo = m[2]!;
    const dec = /[.,](\d{1,2})$/.exec(corpo);
    const inteiro = (dec ? corpo.slice(0, dec.index) : corpo).replace(/[.,]/g, '');
    const fracao = dec ? dec[1]!.padEnd(2, '0') : '00';
    if (!/^\d+$/.test(inteiro)) return fail(erroDe('valor_invalido', `Valor invalido: ${bruto}`, 'valor'));
    const n = Number(inteiro) * 100 + Number(fracao);
    if (!Number.isSafeInteger(n)) return fail(erroDe('valor_invalido', 'Valor acima do limite', 'valor'));
    return ok(sinal * n);
  }

  somar(o: Dinheiro): Dinheiro { return new Dinheiro(this.centavos + o.centavos, this.moeda); }
  igual(o: Dinheiro): boolean { return this.centavos === o.centavos && this.moeda === o.moeda; }
  /** "1234.56" (ponto decimal, sem milhar): formato do CSV contabil. */
  decimal(): string { return formatarCentavos(this.centavos); }
}

/** Centavos com sinal para texto com ponto decimal ("-12.30"). */
export function formatarCentavos(c: number): string {
  const s = c < 0 ? '-' : '';
  const a = Math.abs(c);
  return `${s}${Math.trunc(a / 100)}.${String(a % 100).padStart(2, '0')}`;
}

export class DataIso {
  private constructor(readonly valor: string) {}
  static tryCreate(bruto: unknown, campo = 'data'): Result<DataIso> {
    const v = typeof bruto === 'string' ? bruto.trim().slice(0, 10) : '';
    if (!/^\d{4}-\d{2}-\d{2}$/.test(v)) return fail(erroDe('data_invalida', 'Data deve ser AAAA-MM-DD', campo));
    const [a, m, d] = v.split('-').map(Number);
    const dt = new Date(Date.UTC(a!, m! - 1, d!));
    if (dt.getUTCFullYear() !== a || dt.getUTCMonth() !== m! - 1 || dt.getUTCDate() !== d) return fail(erroDe('data_invalida', 'Data inexistente no calendario', campo));
    return ok(new DataIso(v));
  }
  static create(bruto: string): DataIso {
    const r = DataIso.tryCreate(bruto);
    if (!r.ok) throw new Error(r.erros[0]!.mensagem);
    return r.valor;
  }
  /** Diferenca em dias (this - outra). */
  diasAte(outra: DataIso): number {
    return Math.round((Date.parse(`${outra.valor}T00:00:00Z`) - Date.parse(`${this.valor}T00:00:00Z`)) / 86_400_000);
  }
}

/** Data de hoje (UTC) em AAAA-MM-DD. */
export const hojeIso = (): string => new Date().toISOString().slice(0, 10);
