/** Consulta dos centros de custo com total realizado no mes corrente (centavos, saidas negativas). */
import type pg from 'pg';

const RESUMO = `k.id, k.codigo, k.nome, k.descricao, k.ativo, k.created_at, k.updated_at,
  (SELECT count(*)::int FROM financeiro_lancamentos l WHERE l.centro_custo_id = k.id AND l.deleted_at IS NULL) AS em_uso,
  coalesce((SELECT sum(CASE WHEN l.tipo = 'entrada' THEN l.valor_centavos WHEN l.tipo = 'saida' THEN -l.valor_centavos ELSE 0 END)
            FROM financeiro_lancamentos l WHERE l.centro_custo_id = k.id AND l.deleted_at IS NULL AND l.data_caixa IS NOT NULL
              AND date_trunc('month', l.data_caixa) = date_trunc('month', current_date)), 0)::float8 AS resultado_mes_centavos`;

export async function listarCentrosCusto(c: pg.PoolClient) {
  return (await c.query(`SELECT ${RESUMO} FROM financeiro_centros_custo k WHERE k.deleted_at IS NULL ORDER BY k.ativo DESC, k.codigo`)).rows;
}

export async function obterCentroCusto(c: pg.PoolClient, id: string) {
  return (await c.query(`SELECT ${RESUMO} FROM financeiro_centros_custo k WHERE k.id = $1 AND k.deleted_at IS NULL`, [id])).rows[0] ?? null;
}
