/** Casos de uso do Centro de custo (M4.2): Criar, Editar e Excluir (so sem lancamentos). */
import type { ContextoCaso } from '../../compartilhado/efeitos.ts';
import { erroDe, fail, ok, okVazio, type Result } from '../../compartilhado/result.ts';
import { CentroCusto, type DadosCentroCusto } from '../model/centro-custo.ts';
import type { GravarCentroCusto, ObterCentroCusto } from '../model/portas.ts';

const TABELA = 'financeiro_centros_custo';
export interface DepsCentro { repo: ObterCentroCusto & GravarCentroCusto }

export class CriarCentroCusto {
  constructor(private readonly deps: DepsCentro) {}
  async execute(ctx: ContextoCaso, e: DadosCentroCusto): Promise<Result<{ id: string }>> {
    const r = CentroCusto.tryCreate(e);
    if (!r.ok) return r;
    const igual = await this.deps.repo.buscarPorCodigo(r.valor.codigo);
    if (igual) return fail(erroDe('conflito', 'Ja existe centro de custo com este codigo', 'codigo', { id: igual.id }));
    await this.deps.repo.inserir(r.valor);
    const d = r.valor.paraDados();
    await ctx.efeitos.auditar('centro_custo.criar', TABELA, d.id, undefined, d);
    return ok({ id: d.id });
  }
}

export class EditarCentroCusto {
  constructor(private readonly deps: DepsCentro) {}
  async execute(ctx: ContextoCaso, e: { id: string } & Partial<DadosCentroCusto> & { ativo?: boolean }): Promise<Result<void>> {
    const { id, ...mud } = e;
    const atual = await this.deps.repo.obterPorId(id);
    if (!atual) return fail(erroDe('nao_encontrado', 'Centro de custo nao encontrado'));
    const r = atual.editar(mud);
    if (!r.ok) return r;
    if (r.valor.codigo !== atual.codigo) {
      const igual = await this.deps.repo.buscarPorCodigo(r.valor.codigo);
      if (igual && igual.id !== id) return fail(erroDe('conflito', 'Ja existe centro de custo com este codigo', 'codigo', { id: igual.id }));
    }
    await this.deps.repo.atualizar(r.valor);
    const antes = atual.paraDados() as unknown as Record<string, unknown>;
    const depois = r.valor.paraDados() as unknown as Record<string, unknown>;
    await ctx.efeitos.historico(TABELA, id, antes, depois);
    await ctx.efeitos.auditar('centro_custo.editar', TABELA, id, antes, depois);
    return okVazio();
  }
}

export class ExcluirCentroCusto {
  constructor(private readonly deps: DepsCentro) {}
  async execute(ctx: ContextoCaso, e: { id: string }): Promise<Result<void>> {
    const atual = await this.deps.repo.obterPorId(e.id);
    if (!atual) return fail(erroDe('nao_encontrado', 'Centro de custo nao encontrado'));
    const uso = await this.deps.repo.emUso(e.id);
    if (uso > 0) return fail(erroDe('conflito', 'Centro de custo em uso por lancamentos: desative em vez de excluir', 'id', { lancamentos: uso }));
    await this.deps.repo.excluir(e.id);
    await ctx.efeitos.auditar('centro_custo.excluir', TABELA, e.id, atual.paraDados(), undefined);
    return okVazio();
  }
}
