/** Entidade Centro de custo (M4.2): codigo unico no workspace, nome e situacao. */
import { randomUUID } from 'node:crypto';
import { erroDe, fail, ok, type ErroDominio, type Result } from '../../compartilhado/result.ts';

export interface DadosCentroCusto {
  codigo: string;
  nome: string;
  descricao?: string | null;
}

export interface CentroCustoDados {
  id: string;
  codigo: string;
  nome: string;
  descricao: string | null;
  ativo: boolean;
}

function validar(d: CentroCustoDados): ErroDominio[] {
  const e: ErroDominio[] = [];
  if (!/^[0-9A-Z.-]{1,20}$/.test(d.codigo)) e.push(erroDe('codigo_invalido', 'Codigo com letras, digitos, ponto ou hifen (ate 20)', 'codigo'));
  if (d.nome.length < 2 || d.nome.length > 120) e.push(erroDe('nome_invalido', 'Nome deve ter de 2 a 120 caracteres', 'nome'));
  if (d.descricao !== null && d.descricao.length > 500) e.push(erroDe('descricao_invalida', 'Descricao com ate 500 caracteres', 'descricao'));
  return e;
}

export class CentroCusto {
  private constructor(private readonly d: CentroCustoDados) {}

  static tryCreate(e: DadosCentroCusto, id: string = randomUUID()): Result<CentroCusto> {
    const d: CentroCustoDados = { id, codigo: (e.codigo ?? '').trim().toUpperCase(), nome: (e.nome ?? '').trim(), descricao: (e.descricao ?? '').trim() || null, ativo: true };
    const erros = validar(d);
    return erros.length ? fail(...erros) : ok(new CentroCusto(d));
  }

  static create(e: DadosCentroCusto, id?: string): CentroCusto {
    const r = CentroCusto.tryCreate(e, id);
    if (!r.ok) throw new Error(r.erros.map((x) => x.mensagem).join('; '));
    return r.valor;
  }

  static reidratar(d: CentroCustoDados): CentroCusto { return new CentroCusto({ ...d }); }

  get id(): string { return this.d.id; }
  get codigo(): string { return this.d.codigo; }
  get ativo(): boolean { return this.d.ativo; }

  editar(e: Partial<DadosCentroCusto> & { ativo?: boolean }): Result<CentroCusto> {
    const n: CentroCustoDados = {
      ...this.d,
      codigo: e.codigo !== undefined ? (e.codigo ?? '').trim().toUpperCase() : this.d.codigo,
      nome: e.nome !== undefined ? (e.nome ?? '').trim() : this.d.nome,
      descricao: e.descricao !== undefined ? (e.descricao ?? '').trim() || null : this.d.descricao,
      ativo: e.ativo !== undefined ? !!e.ativo : this.d.ativo,
    };
    const erros = validar(n);
    return erros.length ? fail(...erros) : ok(new CentroCusto(n));
  }

  paraDados(): CentroCustoDados { return { ...this.d }; }
}
