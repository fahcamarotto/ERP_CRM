/** Portas do repositorio do agregado Centro de custo. */
import type { CentroCusto } from './centro-custo.ts';

export interface ObterCentroCusto {
  obterPorId(id: string): Promise<CentroCusto | null>;
  buscarPorCodigo(codigo: string): Promise<CentroCusto | null>;
}

export interface GravarCentroCusto {
  inserir(c: CentroCusto): Promise<void>;
  atualizar(c: CentroCusto): Promise<void>;
  excluir(id: string): Promise<void>;
  emUso(id: string): Promise<number>;
}
