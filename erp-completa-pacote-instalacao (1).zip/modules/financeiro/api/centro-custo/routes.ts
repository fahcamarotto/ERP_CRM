/** Rotas REST do Centro de custo: listar, criar, editar e excluir. */
import { esquemaErro, requer, type FastifyInstance } from '@erp/api/sdk';
import { naTransacao } from '../borda.ts';
import { exigirOk } from '../compartilhado/result.ts';
import { propsCentroCusto, uuid } from '../esquemas.ts';
import type { DadosCentroCusto } from './model/centro-custo.ts';
import { listarCentrosCusto, obterCentroCusto } from './query/centros-custo.ts';

const tags = ['financeiro'];
const paramId = { type: 'object', required: ['id'], properties: { id: uuid } } as const;
const erros = { 400: esquemaErro, 403: esquemaErro, 404: esquemaErro, 409: esquemaErro };

export function rotasCentroCusto(app: FastifyInstance): void {
  app.get('/centros-custo', {
    preHandler: requer('financeiro.ver'),
    schema: { tags, summary: 'Centros de custo com uso e resultado do mes (centavos)' },
  }, (req) => naTransacao(req, (_, __, c) => listarCentrosCusto(c)));

  app.post<{ Body: DadosCentroCusto }>('/centros-custo', {
    preHandler: requer('financeiro.criar'),
    schema: { tags, summary: 'Cria centro de custo (CriarCentroCusto)', body: { type: 'object', additionalProperties: false, required: ['codigo', 'nome'], properties: propsCentroCusto }, response: erros },
  }, async (req, reply) => reply.code(201).send(await naTransacao(req, async (casos, ctx, c) => {
    const { id } = exigirOk(await casos.criarCentroCusto.execute(ctx, req.body));
    return obterCentroCusto(c, id);
  })));

  app.patch<{ Params: { id: string }; Body: Partial<DadosCentroCusto> & { ativo?: boolean } }>('/centros-custo/:id', {
    preHandler: requer('financeiro.editar'),
    schema: { tags, summary: 'Edita ou desativa centro de custo', params: paramId,
      body: { type: 'object', additionalProperties: false, properties: { ...propsCentroCusto, ativo: { type: 'boolean' } } }, response: erros },
  }, (req) => naTransacao(req, async (casos, ctx, c) => {
    exigirOk(await casos.editarCentroCusto.execute(ctx, { ...req.body, id: req.params.id }));
    return obterCentroCusto(c, req.params.id);
  }));

  app.delete<{ Params: { id: string } }>('/centros-custo/:id', {
    preHandler: requer('financeiro.excluir'),
    schema: { tags, summary: 'Exclui centro de custo sem lancamentos (exclusao logica)', params: paramId, response: erros },
  }, async (req, reply) => {
    await naTransacao(req, async (casos, ctx) => exigirOk(await casos.excluirCentroCusto.execute(ctx, { id: req.params.id })));
    return reply.code(204).send();
  });
}
