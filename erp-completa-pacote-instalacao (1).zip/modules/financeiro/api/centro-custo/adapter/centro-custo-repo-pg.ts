/** Adaptador Postgres das portas do agregado Centro de custo. */
import type pg from 'pg';
import { CentroCusto, type CentroCustoDados } from '../model/centro-custo.ts';
import type { GravarCentroCusto, ObterCentroCusto } from '../model/portas.ts';

const COLUNAS = 'id, codigo, nome, descricao, ativo';

export class CentroCustoRepoPg implements ObterCentroCusto, GravarCentroCusto {
  constructor(private readonly c: pg.PoolClient) {}

  async obterPorId(id: string): Promise<CentroCusto | null> {
    const r = await this.c.query(`SELECT ${COLUNAS} FROM financeiro_centros_custo WHERE id = $1 AND deleted_at IS NULL`, [id]);
    return r.rows[0] ? CentroCusto.reidratar(r.rows[0] as CentroCustoDados) : null;
  }

  async buscarPorCodigo(codigo: string): Promise<CentroCusto | null> {
    const r = await this.c.query(`SELECT ${COLUNAS} FROM financeiro_centros_custo WHERE upper(codigo) = upper($1) AND deleted_at IS NULL`, [codigo]);
    return r.rows[0] ? CentroCusto.reidratar(r.rows[0] as CentroCustoDados) : null;
  }

  async inserir(x: CentroCusto): Promise<void> {
    const d = x.paraDados();
    await this.c.query('INSERT INTO financeiro_centros_custo (id, codigo, nome, descricao, ativo, creator_id) VALUES ($1, $2, $3, $4, $5, nucleo_usuario_atual())',
      [d.id, d.codigo, d.nome, d.descricao, d.ativo]);
  }

  async atualizar(x: CentroCusto): Promise<void> {
    const d = x.paraDados();
    await this.c.query('UPDATE financeiro_centros_custo SET codigo = $2, nome = $3, descricao = $4, ativo = $5 WHERE id = $1 AND deleted_at IS NULL',
      [d.id, d.codigo, d.nome, d.descricao, d.ativo]);
  }

  async excluir(id: string): Promise<void> {
    await this.c.query('UPDATE financeiro_centros_custo SET deleted_at = now() WHERE id = $1 AND deleted_at IS NULL', [id]);
  }

  async emUso(id: string): Promise<number> {
    return (await this.c.query('SELECT count(*)::int AS n FROM financeiro_lancamentos WHERE centro_custo_id = $1 AND deleted_at IS NULL', [id])).rows[0].n as number;
  }
}
