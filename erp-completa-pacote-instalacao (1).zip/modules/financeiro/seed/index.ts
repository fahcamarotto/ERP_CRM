/**
 * Seed demo do Financeiro: contas e caixas, arvore de categorias, centros de custo, lancamentos
 * realizados e previstos dos ultimos e proximos meses (com transferencia e estorno) e um extrato com
 * itens para conciliar. Idempotente: ids deterministicos por chave e insercao so do que falta.
 * Grava pelos adaptadores e entidades do modulo (mesmas regras); parceiros lidos da tabela publicada do Cadastros.
 */
import { createHash } from 'node:crypto';
import type { SeedModulo } from '@erp/api/sdk/puro';
import { CategoriaRepoPg } from '../api/categoria/adapter/categoria-repo-pg.ts';
import { Categoria, type Natureza } from '../api/categoria/model/categoria.ts';
import { CentroCustoRepoPg } from '../api/centro-custo/adapter/centro-custo-repo-pg.ts';
import { CentroCusto } from '../api/centro-custo/model/centro-custo.ts';
import { ConciliacaoRepoPg } from '../api/conciliacao/conciliacao-repo-pg.ts';
import { SugerirPares } from '../api/conciliacao/conciliar.ts';
import { ContaRepoPg } from '../api/conta/adapter/conta-repo-pg.ts';
import { Conta, type DadosConta } from '../api/conta/model/conta.ts';
import { LancamentoRepoPg } from '../api/lancamento/adapter/lancamento-repo-pg.ts';
import { Lancamento, type TipoLancamento } from '../api/lancamento/model/lancamento.ts';

/** uuid deterministico a partir de uma chave (mesmo id em toda execucao). */
function idDe(chave: string): string {
  const h = createHash('sha256').update(`financeiro-demo:${chave}`).digest('hex');
  return `${h.slice(0, 8)}-${h.slice(8, 12)}-4${h.slice(13, 16)}-a${h.slice(17, 20)}-${h.slice(20, 32)}`;
}

/** Data AAAA-MM-DD relativa ao mes corrente (mes 0 = atual), dia limitado ao fim do mes. */
function dia(mes: number, d: number): string {
  const h = new Date();
  const fim = new Date(Date.UTC(h.getUTCFullYear(), h.getUTCMonth() + mes + 1, 0)).getUTCDate();
  return new Date(Date.UTC(h.getUTCFullYear(), h.getUTCMonth() + mes, Math.min(d, fim))).toISOString().slice(0, 10);
}

const CONTAS: (DadosConta & { k: string })[] = [
  { k: 'itau', nome: 'Conta corrente Itaú', tipo: 'banco', banco_codigo: '341', banco_nome: 'Itaú Unibanco', agencia: '1500', numero: '45021-7', saldo_inicial_centavos: 4_850_000, data_saldo_inicial: dia(-3, 1) },
  { k: 'bb', nome: 'Conta Banco do Brasil', tipo: 'banco', banco_codigo: '001', banco_nome: 'Banco do Brasil', agencia: '3344', numero: '98765-0', saldo_inicial_centavos: 1_230_000, data_saldo_inicial: dia(-3, 1) },
  { k: 'caixa', nome: 'Caixa interno', tipo: 'caixa', saldo_inicial_centavos: 80_000, data_saldo_inicial: dia(-3, 1) },
  { k: 'cdb', nome: 'Aplicação CDB liquidez diária', tipo: 'investimento', banco_codigo: '341', banco_nome: 'Itaú Unibanco', agencia: '1500', numero: '880011', saldo_inicial_centavos: 10_000_000, data_saldo_inicial: dia(-3, 1) },
];

const CATEGORIAS: { k: string; nome: string; natureza: Natureza; mae?: string; codigo: string }[] = [
  { k: 'r-vendas', nome: 'Vendas', natureza: 'receita', codigo: '1.1' },
  { k: 'r-servicos', nome: 'Prestação de serviços', natureza: 'receita', mae: 'r-vendas', codigo: '1.1.1' },
  { k: 'r-produtos', nome: 'Venda de produtos', natureza: 'receita', mae: 'r-vendas', codigo: '1.1.2' },
  { k: 'r-financeiras', nome: 'Receitas financeiras', natureza: 'receita', codigo: '1.2' },
  { k: 'r-rendimentos', nome: 'Rendimentos de aplicação', natureza: 'receita', mae: 'r-financeiras', codigo: '1.2.1' },
  { k: 'd-pessoal', nome: 'Pessoal', natureza: 'despesa', codigo: '2.1' },
  { k: 'd-salarios', nome: 'Salários', natureza: 'despesa', mae: 'd-pessoal', codigo: '2.1.1' },
  { k: 'd-beneficios', nome: 'Benefícios', natureza: 'despesa', mae: 'd-pessoal', codigo: '2.1.2' },
  { k: 'd-ocupacao', nome: 'Ocupação', natureza: 'despesa', codigo: '2.2' },
  { k: 'd-aluguel', nome: 'Aluguel', natureza: 'despesa', mae: 'd-ocupacao', codigo: '2.2.1' },
  { k: 'd-energia', nome: 'Energia e internet', natureza: 'despesa', mae: 'd-ocupacao', codigo: '2.2.2' },
  { k: 'd-adm', nome: 'Administrativas', natureza: 'despesa', codigo: '2.3' },
  { k: 'd-software', nome: 'Software e assinaturas', natureza: 'despesa', mae: 'd-adm', codigo: '2.3.1' },
  { k: 'd-contabilidade', nome: 'Contabilidade', natureza: 'despesa', mae: 'd-adm', codigo: '2.3.2' },
  { k: 'd-tarifas', nome: 'Tarifas bancárias', natureza: 'despesa', mae: 'd-adm', codigo: '2.3.3' },
  { k: 'd-impostos', nome: 'Impostos', natureza: 'despesa', codigo: '2.4' },
  { k: 'd-simples', nome: 'Simples Nacional', natureza: 'despesa', mae: 'd-impostos', codigo: '2.4.1' },
];

const CENTROS = [
  { k: 'adm', codigo: 'ADM', nome: 'Administrativo', descricao: 'Diretoria, financeiro e RH' },
  { k: 'com', codigo: 'COM', nome: 'Comercial', descricao: 'Vendas e marketing' },
  { k: 'ope', codigo: 'OPE', nome: 'Operação', descricao: 'Entrega de serviços e produtos' },
  { k: 'ti', codigo: 'TI', nome: 'Tecnologia', descricao: 'Sistemas e infraestrutura' },
];

type L = { k: string; tipo: TipoLancamento; desc: string; conta: string; destino?: string; cat?: string; cc?: string; parceiro?: 'cliente' | 'fornecedor'; p?: number; valor: number; comp: string; caixa: string | null };

/** Lancamentos dos 3 ultimos meses (realizados) e dos 2 proximos (previstos). */
function lancamentos(): L[] {
  const l: L[] = [];
  for (const m of [-3, -2, -1, 0]) {
    const real = (d: number) => (m < 0 || d <= new Date().getUTCDate() ? dia(m, d) : null);
    l.push(
      { k: `serv-a${m}`, tipo: 'entrada', desc: 'Mensalidade de consultoria', conta: 'itau', cat: 'r-servicos', cc: 'com', parceiro: 'cliente', p: 0, valor: 1_850_000, comp: dia(m, 5), caixa: real(5) },
      { k: `serv-b${m}`, tipo: 'entrada', desc: 'Projeto de implantação', conta: 'itau', cat: 'r-servicos', cc: 'ope', parceiro: 'cliente', p: 1, valor: 920_000 + (m + 3) * 35_000, comp: dia(m, 12), caixa: real(12) },
      { k: `prod${m}`, tipo: 'entrada', desc: 'Venda de produtos no balcão', conta: 'caixa', cat: 'r-produtos', cc: 'com', valor: 187_590 + (m + 3) * 4_110, comp: dia(m, 18), caixa: real(18) },
      { k: `alug${m}`, tipo: 'saida', desc: 'Aluguel do escritório', conta: 'itau', cat: 'd-aluguel', cc: 'adm', valor: 650_000, comp: dia(m, 10), caixa: real(10) },
      { k: `sal${m}`, tipo: 'saida', desc: 'Folha de salários', conta: 'itau', cat: 'd-salarios', cc: 'ope', valor: 2_140_000, comp: dia(m, 5), caixa: real(5) },
      { k: `ben${m}`, tipo: 'saida', desc: 'Vale refeição e plano de saúde', conta: 'bb', cat: 'd-beneficios', cc: 'adm', valor: 386_420, comp: dia(m, 8), caixa: real(8) },
      { k: `ener${m}`, tipo: 'saida', desc: 'Energia e internet', conta: 'bb', cat: 'd-energia', cc: 'adm', valor: 61_237 + (m + 3) * 1_190, comp: dia(m, 15), caixa: real(15) },
      { k: `soft${m}`, tipo: 'saida', desc: 'Assinaturas de software', conta: 'itau', cat: 'd-software', cc: 'ti', parceiro: 'fornecedor', p: 0, valor: 129_900, comp: dia(m, 20), caixa: real(20) },
      { k: `cont${m}`, tipo: 'saida', desc: 'Honorários da contabilidade', conta: 'bb', cat: 'd-contabilidade', cc: 'adm', parceiro: 'fornecedor', p: 1, valor: 145_000, comp: dia(m, 22), caixa: real(22) },
      { k: `das${m}`, tipo: 'saida', desc: 'DAS Simples Nacional', conta: 'itau', cat: 'd-simples', cc: 'adm', valor: 231_840 + (m + 3) * 6_300, comp: dia(m, 20), caixa: real(20) },
      { k: `rend${m}`, tipo: 'entrada', desc: 'Rendimento do CDB', conta: 'cdb', cat: 'r-rendimentos', cc: 'adm', valor: 81_250 + (m + 3) * 920, comp: dia(m, 28), caixa: real(28) },
      { k: `tar${m}`, tipo: 'saida', desc: 'Tarifa de manutenção de conta', conta: 'itau', cat: 'd-tarifas', cc: 'adm', valor: 6_490, comp: dia(m, 2), caixa: real(2) },
    );
  }
  for (const m of [1, 2]) {
    l.push(
      { k: `prev-serv${m}`, tipo: 'entrada', desc: 'Mensalidade de consultoria (prevista)', conta: 'itau', cat: 'r-servicos', cc: 'com', parceiro: 'cliente', p: 0, valor: 1_850_000, comp: dia(m, 5), caixa: null },
      { k: `prev-alug${m}`, tipo: 'saida', desc: 'Aluguel do escritório (previsto)', conta: 'itau', cat: 'd-aluguel', cc: 'adm', valor: 650_000, comp: dia(m, 10), caixa: null },
      { k: `prev-sal${m}`, tipo: 'saida', desc: 'Folha de salários (prevista)', conta: 'itau', cat: 'd-salarios', cc: 'ope', valor: 2_140_000, comp: dia(m, 5), caixa: null },
    );
  }
  l.push(
    { k: 'transf-1', tipo: 'transferencia', desc: 'Reforço de caixa', conta: 'itau', destino: 'caixa', cc: 'adm', valor: 50_000, comp: dia(-1, 3), caixa: dia(-1, 3) },
    { k: 'transf-2', tipo: 'transferencia', desc: 'Aplicação no CDB', conta: 'itau', destino: 'cdb', cc: 'adm', valor: 1_000_000, comp: dia(-2, 26), caixa: dia(-2, 26) },
    { k: 'estornar', tipo: 'saida', desc: 'Compra de material em duplicidade', conta: 'bb', cat: 'd-software', cc: 'ti', valor: 34_900, comp: dia(-1, 16), caixa: dia(-1, 16) },
  );
  return l;
}

const semear: SeedModulo = async ({ c, log }) => {
  const contas = new ContaRepoPg(c);
  const categorias = new CategoriaRepoPg(c);
  const centros = new CentroCustoRepoPg(c);
  const lancs = new LancamentoRepoPg(c);
  const conc = new ConciliacaoRepoPg(c);
  let novos = 0;

  const idConta = new Map<string, string>();
  for (const k of CONTAS) {
    const id = idDe(`conta:${k.k}`);
    const { k: _k, ...dados } = k;
    const existente = (await contas.obterPorId(id)) ?? (await contas.buscarPorNome(k.nome));
    if (!existente) { await contas.inserir(Conta.create(dados, id)); novos++; }
    idConta.set(k.k, existente?.id ?? id);
  }

  const idCat = new Map<string, string>();
  for (const k of CATEGORIAS) {
    const id = idDe(`categoria:${k.k}`);
    const mae = k.mae ? idCat.get(k.mae)! : null;
    const existente = (await categorias.obterPorId(id)) ?? (await categorias.buscarIrma(k.natureza, mae, k.nome));
    if (!existente) { await categorias.inserir(Categoria.create({ nome: k.nome, natureza: k.natureza, parent_id: mae, codigo: k.codigo }, id)); novos++; }
    idCat.set(k.k, existente?.id ?? id);
  }

  const idCc = new Map<string, string>();
  for (const k of CENTROS) {
    const id = idDe(`centro:${k.k}`);
    const existente = (await centros.obterPorId(id)) ?? (await centros.buscarPorCodigo(k.codigo));
    if (!existente) { await centros.inserir(CentroCusto.create(k, id)); novos++; }
    idCc.set(k.k, existente?.id ?? id);
  }

  // Parceiros do Cadastros (seed da dependencia roda antes): so leitura da tabela publicada.
  const parceiros = async (papel: 'cliente' | 'fornecedor') => (await c.query(
    `SELECT id FROM cadastros_parceiros WHERE ${papel === 'cliente' ? 'e_cliente' : 'e_fornecedor'} AND estado = 'ativo' AND deleted_at IS NULL ORDER BY created_at, id LIMIT 5`)).rows.map((r) => r.id as string);
  const pp = { cliente: await parceiros('cliente'), fornecedor: await parceiros('fornecedor') };

  for (const l of lancamentos()) {
    const id = idDe(`lancamento:${l.k}`);
    if (await lancs.obterPorId(id)) continue;
    const base = Lancamento.create({
      tipo: l.tipo, descricao: l.desc, conta_id: idConta.get(l.conta)!, conta_destino_id: l.destino ? idConta.get(l.destino)! : null,
      categoria_id: l.cat ? idCat.get(l.cat)! : null, centro_custo_id: l.cc ? idCc.get(l.cc)! : null,
      parceiro_id: l.parceiro ? pp[l.parceiro][l.p ?? 0] ?? null : null, valor_centavos: l.valor, data_competencia: l.comp, data_caixa: l.caixa,
      origem: l.tipo === 'transferencia' ? 'transferencia' : 'seed',
    }, id);
    await lancs.inserir(base);
    novos++;
    if (l.k === 'estornar') {
      const r = base.estornar(dia(-1, 17), 'lançado em duplicidade', idDe('lancamento:estorno'));
      if (!r.ok) throw new Error(r.erros[0]!.mensagem);
      await lancs.atualizar(r.valor.original);
      await lancs.inserir(r.valor.estorno);
      novos++;
    }
  }

  // Extrato demo da conta Itau do mes passado: itens com par sugerido, um sem par (tarifa extra) e itens novos.
  const extratoId = idDe('extrato:itau');
  if (!(await conc.obter(extratoId))) {
    const itau = idConta.get('itau')!;
    const itens = [
      { k: 'e1', data: dia(-1, 5), valor: 1_850_000, desc: 'TED RECEBIDA CONSULTORIA' },
      { k: 'e2', data: dia(-1, 6), valor: -2_140_000, desc: 'PAGTO FOLHA' },
      { k: 'e3', data: dia(-1, 11), valor: -650_000, desc: 'BOLETO ALUGUEL' },
      { k: 'e4', data: dia(-1, 3), valor: -50_000, desc: 'TRANSF ENTRE CONTAS' },
      { k: 'e5', data: dia(-1, 2), valor: -6_490, desc: 'TARIFA PACOTE SERVICOS' },
      { k: 'e6', data: dia(-1, 25), valor: -1_990, desc: 'TARIFA TED' },
      { k: 'e7', data: dia(-1, 27), valor: 312_000, desc: 'PIX RECEBIDO CLIENTE AVULSO' },
    ];
    await conc.inserir({ id: extratoId, conta_id: itau, nome_arquivo: 'extrato-itau-demo.csv', formato: 'csv', conteudo: 'data;descricao;valor\n' });
    for (const it of itens) {
      await conc.inserirSeNovo({ id: idDe(`extrato-item:${it.k}`), extrato_id: extratoId, conta_id: itau, data: it.data, valor_centavos: it.valor,
        descricao: it.desc, identificador: `demo-${it.k}`, estado: 'pendente', sugestao_lancamento_id: null, lancamento_id: null });
    }
    const s = await new SugerirPares({ itens: conc }).execute({ ator: { tipo: 'sistema', id: null }, efeitos: { auditar: async () => {}, publicar: async () => {}, historico: async () => {}, nota: async () => {} } }, { extrato_id: extratoId });
    await conc.progresso(extratoId, { estado: 'concluida', total: itens.length, importados: itens.length, duplicados: 0, sugeridos: s.ok ? s.valor.sugeridos : 0, erros: [] });
    novos += 1 + itens.length;
  }

  log(`${novos} registro(s) demo novo(s) (${CONTAS.length} contas, ${CATEGORIAS.length} categorias, ${CENTROS.length} centros de custo, ${lancamentos().length + 1} lançamentos, 1 extrato)`);
};

export default semear;
