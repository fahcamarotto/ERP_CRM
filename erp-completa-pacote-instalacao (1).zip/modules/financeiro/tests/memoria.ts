/**
 * Repositorios em memoria das portas do Financeiro e porta Efeitos que grava o que foi publicado.
 * Os casos de uso rodam aqui sem banco, sem Fastify e sem o SDK.
 */
import { Categoria, type CategoriaDados, type Natureza } from '../api/categoria/model/categoria.ts';
import type { ConsultarArvore, GravarCategoria, ObterCategoria } from '../api/categoria/model/portas.ts';
import { CentroCusto, type CentroCustoDados } from '../api/centro-custo/model/centro-custo.ts';
import type { GravarCentroCusto, ObterCentroCusto } from '../api/centro-custo/model/portas.ts';
import type { ContextoCaso, Efeitos } from '../api/compartilhado/efeitos.ts';
import type { CandidatoPar, ExtratoDados, FilaJobs, ItemDados, PortaExtratos, PortaItens, ProgressoExtrato } from '../api/conciliacao/conciliar.ts';
import { Conta, type ContaDados } from '../api/conta/model/conta.ts';
import type { ConsultarConta, GravarConta, ObterConta } from '../api/conta/model/portas.ts';
import type { LinhaContabil, PortaExportacoes } from '../api/exportacao/exportar-contabil.ts';
import { Lancamento, type LancamentoDados } from '../api/lancamento/model/lancamento.ts';
import type { BuscarPorChave, ConsultarReferenciasLancamento, GravarLancamento, ObterLancamento } from '../api/lancamento/model/portas.ts';

export class EfeitosMemoria implements Efeitos {
  auditoria: { acao: string; entidade: string; id: string | null }[] = [];
  eventos: { evento: string; dados: Record<string, unknown> }[] = [];
  historicos: { entidade: string; id: string; antes: unknown; depois: unknown }[] = [];
  notas: { entidade: string; id: string; corpo: string }[] = [];
  async auditar(acao: string, entidade: string, id: string | null) { this.auditoria.push({ acao, entidade, id }); }
  async publicar(evento: string, dados: Record<string, unknown>) { this.eventos.push({ evento, dados }); }
  async historico(entidade: string, id: string, antes: unknown, depois: unknown) { this.historicos.push({ entidade, id, antes, depois }); }
  async nota(entidade: string, id: string, corpo: string) { this.notas.push({ entidade, id, corpo }); }
}

export function contexto(): ContextoCaso & { efeitos: EfeitosMemoria } {
  return { ator: { tipo: 'usuario', id: '00000000-0000-4000-8000-000000000001' }, efeitos: new EfeitosMemoria() };
}

export class ContasMemoria implements ObterConta, GravarConta, ConsultarConta {
  linhas = new Map<string, ContaDados>();
  comLancamentos = new Set<string>();
  async obterPorId(id: string) { const d = this.linhas.get(id); return d ? Conta.reidratar(d) : null; }
  async buscarPorNome(nome: string) { const d = [...this.linhas.values()].find((x) => x.nome.toLowerCase() === nome.toLowerCase()); return d ? Conta.reidratar(d) : null; }
  async temLancamentos(id: string) { return this.comLancamentos.has(id); }
  async inserir(c: Conta) { this.linhas.set(c.id, c.paraDados()); }
  async atualizar(c: Conta) { this.linhas.set(c.id, c.paraDados()); }
}

export class CategoriasMemoria implements ObterCategoria, GravarCategoria, ConsultarArvore {
  linhas = new Map<string, CategoriaDados & { deleted: boolean }>();
  usoLancamentos = new Map<string, number>();
  private vivas() { return [...this.linhas.values()].filter((x) => !x.deleted); }
  async obterPorId(id: string) { const d = this.linhas.get(id); return d && !d.deleted ? Categoria.reidratar(d) : null; }
  async inserir(c: Categoria) { this.linhas.set(c.id, { ...c.paraDados(), deleted: false }); }
  async atualizar(c: Categoria) { this.linhas.set(c.id, { ...c.paraDados(), deleted: false }); }
  async excluir(id: string) { const d = this.linhas.get(id); if (d) d.deleted = true; }
  async ancestrais(id: string) {
    const r: string[] = [];
    let atual = this.linhas.get(id)?.parent_id ?? null;
    while (atual && r.length < 10) { r.push(atual); atual = this.linhas.get(atual)?.parent_id ?? null; }
    return r;
  }
  async alturaFilhos(id: string): Promise<number> {
    const filhas = this.vivas().filter((x) => x.parent_id === id);
    if (!filhas.length) return 0;
    return 1 + Math.max(...(await Promise.all(filhas.map((f) => this.alturaFilhos(f.id)))));
  }
  async buscarIrma(natureza: Natureza, parentId: string | null, nome: string) {
    const d = this.vivas().find((x) => x.natureza === natureza && x.parent_id === parentId && x.nome.toLowerCase() === nome.toLowerCase());
    return d ? Categoria.reidratar(d) : null;
  }
  async uso(id: string) { return { filhas: this.vivas().filter((x) => x.parent_id === id).length, lancamentos: this.usoLancamentos.get(id) ?? 0 }; }
}

export class CentrosMemoria implements ObterCentroCusto, GravarCentroCusto {
  linhas = new Map<string, CentroCustoDados & { deleted: boolean }>();
  uso = new Map<string, number>();
  async obterPorId(id: string) { const d = this.linhas.get(id); return d && !d.deleted ? CentroCusto.reidratar(d) : null; }
  async buscarPorCodigo(codigo: string) { const d = [...this.linhas.values()].find((x) => !x.deleted && x.codigo === codigo.toUpperCase()); return d ? CentroCusto.reidratar(d) : null; }
  async inserir(c: CentroCusto) { this.linhas.set(c.id, { ...c.paraDados(), deleted: false }); }
  async atualizar(c: CentroCusto) { this.linhas.set(c.id, { ...c.paraDados(), deleted: false }); }
  async excluir(id: string) { const d = this.linhas.get(id); if (d) d.deleted = true; }
  async emUso(id: string) { return this.uso.get(id) ?? 0; }
}

/** Lancamentos e as referencias que o caso de uso consulta (contas, categorias, centros, parceiros, anexos). */
export class LancamentosMemoria implements ObterLancamento, GravarLancamento, BuscarPorChave, ConsultarReferenciasLancamento {
  linhas = new Map<string, LancamentoDados>();
  contas = new Map<string, { ativa: boolean; moeda: string }>();
  categorias = new Map<string, { natureza: 'receita' | 'despesa'; ativa: boolean }>();
  centros = new Set<string>();
  parceiros = new Set<string>();
  anexos = new Map<string, string>();
  async obterPorId(id: string) { const d = this.linhas.get(id); return d ? Lancamento.reidratar(d) : null; }
  async buscarPorChave(chave: string) { const d = [...this.linhas.values()].find((x) => x.chave_idempotencia === chave); return d ? Lancamento.reidratar(d) : null; }
  async inserir(l: Lancamento) {
    const d = l.paraDados();
    if (d.chave_idempotencia && [...this.linhas.values()].some((x) => x.chave_idempotencia === d.chave_idempotencia)) throw Object.assign(new Error('duplicado'), { code: '23505' });
    this.linhas.set(d.id, d);
  }
  async atualizar(l: Lancamento) { this.linhas.set(l.id, l.paraDados()); }
  async conta(id: string) { return this.contas.get(id) ?? null; }
  async categoria(id: string) { return this.categorias.get(id) ?? null; }
  async centroAtivo(id: string) { return this.centros.has(id); }
  async parceiroAtivo(id: string) { return this.parceiros.has(id); }
  async anexoDoLancamento(anexoId: string, lancamentoId: string) { return this.anexos.get(anexoId) === lancamentoId; }
  /** Efeito com sinal na conta, como o adaptador Postgres calcula para os candidatos. */
  efeito(d: LancamentoDados, conta: string) { return Lancamento.reidratar(d).efeitoNaConta(conta); }
}

export class ConciliacaoMemoria implements PortaExtratos, PortaItens, FilaJobs {
  extratos = new Map<string, ExtratoDados & Partial<ProgressoExtrato>>();
  itens = new Map<string, ItemDados>();
  contasAtivas = new Set<string>();
  jobs: { id: string; tipo: string; payload: Record<string, unknown> }[] = [];
  constructor(private readonly lancs: LancamentosMemoria) {}
  async inserir(d: Omit<ExtratoDados, 'estado'>) { this.extratos.set(d.id, { ...d, estado: 'pendente' }); }
  async obter(id: string) { return this.extratos.get(id) ?? null; }
  async progresso(id: string, p: ProgressoExtrato) { const e = this.extratos.get(id); if (e) Object.assign(e, p); }
  async contaAtiva(id: string) { return this.contasAtivas.has(id); }
  async inserirSeNovo(i: ItemDados) {
    if ([...this.itens.values()].some((x) => x.conta_id === i.conta_id && x.identificador === i.identificador)) return false;
    this.itens.set(i.id, { ...i });
    return true;
  }
  async obterItem(id: string) { const i = this.itens.get(id); return i ? { ...i } : null; }
  async atualizarItem(i: ItemDados) { this.itens.set(i.id, { ...i }); }
  async pendentesSemSugestao(f: { extrato_id?: string; conta_id?: string }) {
    return [...this.itens.values()].filter((i) => i.estado === 'pendente' && !i.sugestao_lancamento_id
      && (!f.extrato_id || i.extrato_id === f.extrato_id) && (!f.conta_id || i.conta_id === f.conta_id)).sort((a, b) => a.data.localeCompare(b.data));
  }
  async candidatos(contaId: string, valor: number, de: string, ate: string): Promise<CandidatoPar[]> {
    const sugeridos = new Set([...this.itens.values()].filter((i) => i.estado === 'pendente').map((i) => i.sugestao_lancamento_id));
    return [...this.lancs.linhas.values()]
      .filter((l) => l.estado === 'ativo' && !l.conciliado && this.lancs.efeito(l, contaId) === valor && !sugeridos.has(l.id))
      .map((l) => ({ id: l.id, data: l.data_caixa ?? l.data_competencia, descricao: l.descricao }))
      .filter((c) => c.data >= de && c.data <= ate);
  }
  async enfileirar(tipo: string, payload: Record<string, unknown>) { const id = `job-${this.jobs.length + 1}`; this.jobs.push({ id, tipo, payload }); return id; }
}

export class ExportacoesMemoria implements PortaExportacoes, FilaJobs {
  linhasExp = new Map<string, { id: string; de: string; ate: string; estado: string; total: number; conteudo?: string | null; job_id?: string }>();
  dados: LinhaContabil[] = [];
  jobs: { id: string; tipo: string; payload: Record<string, unknown> }[] = [];
  async inserir(d: { id: string; de: string; ate: string }) { this.linhasExp.set(d.id, { ...d, estado: 'pendente', total: 0 }); }
  async obter(id: string) { return this.linhasExp.get(id) ?? null; }
  async progresso(id: string, p: Parameters<PortaExportacoes['progresso']>[1]) { const l = this.linhasExp.get(id); if (l) Object.assign(l, p); }
  async linhas(de: string, ate: string) { return this.dados.filter((l) => l.data_competencia >= de && l.data_competencia <= ate); }
  async enfileirar(tipo: string, payload: Record<string, unknown>) { const id = `job-${this.jobs.length + 1}`; this.jobs.push({ id, tipo, payload }); return id; }
}
