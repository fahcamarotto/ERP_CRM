/**
 * Testes do modulo Financeiro: cada caso de uso com repositorio em memoria.
 * Rodar: node --import tsx --test modules/financeiro/tests/*.test.ts
 */
import assert from 'node:assert/strict';
import { describe, it } from 'node:test';
import { Categoria } from '../api/categoria/model/categoria.ts';
import { CriarCategoria, EditarCategoria, ExcluirCategoria } from '../api/categoria/use-case/categorias.ts';
import { CriarCentroCusto, ExcluirCentroCusto } from '../api/centro-custo/use-case/centros-custo.ts';
import { DataIso, Dinheiro } from '../api/compartilhado/dinheiro.ts';
import { AlternarItem, Conciliar, ConciliarCriando, escolherPar, ProcessarExtrato, SolicitarImportacaoExtrato, SugerirPares, TIPO_JOB_EXTRATO } from '../api/conciliacao/conciliar.ts';
import { lerCsvExtrato, lerOfx } from '../api/conciliacao/extrato.ts';
import { Conta } from '../api/conta/model/conta.ts';
import { AlternarConta, CriarConta, EditarConta } from '../api/conta/use-case/contas.ts';
import { gerarCsv, ProcessarExportacao, SolicitarExportacao, TIPO_JOB_EXPORTACAO } from '../api/exportacao/exportar-contabil.ts';
import { Lancamento } from '../api/lancamento/model/lancamento.ts';
import { AnexarComprovante, EditarLancamento, EstornarLancamento } from '../api/lancamento/use-case/editar-lancamento.ts';
import { RegistrarLancamento, Transferir } from '../api/lancamento/use-case/registrar-lancamento.ts';
import { lancamentoDaBaixa } from '../api/lancamento/use-case/baixa-contas.ts';
import { CategoriasMemoria, CentrosMemoria, ConciliacaoMemoria, ContasMemoria, contexto, ExportacoesMemoria, LancamentosMemoria } from './memoria.ts';

const C1 = '11111111-1111-4111-8111-111111111111';
const C2 = '22222222-2222-4222-8222-222222222222';
const CUSD = '33333333-3333-4333-8333-333333333333';
const REC = '44444444-4444-4444-8444-444444444444';
const DESP = '55555555-5555-4555-8555-555555555555';
const CC = '66666666-6666-4666-8666-666666666666';
const PARC = '77777777-7777-4777-8777-777777777777';

function montar() {
  const repo = new LancamentosMemoria();
  repo.contas.set(C1, { ativa: true, moeda: 'BRL' }).set(C2, { ativa: true, moeda: 'BRL' }).set(CUSD, { ativa: true, moeda: 'USD' });
  repo.categorias.set(REC, { natureza: 'receita', ativa: true }).set(DESP, { natureza: 'despesa', ativa: true });
  repo.centros.add(CC);
  repo.parceiros.add(PARC);
  const deps = { repo, refs: repo };
  return { repo, registrar: new RegistrarLancamento(deps), transferir: new Transferir(deps), editar: new EditarLancamento(deps) };
}

const entrada = (x: Record<string, unknown> = {}) => ({
  tipo: 'entrada' as const, descricao: 'Mensalidade', conta_id: C1, categoria_id: REC, centro_custo_id: CC, parceiro_id: PARC,
  valor_centavos: 150_000, data_competencia: '2026-09-05', data_caixa: '2026-09-05', chave_idempotencia: 'chave-teste-0001', ...x,
});

describe('objetos de valor', () => {
  it('Dinheiro aceita so centavos inteiros positivos e moeda ISO', () => {
    assert.equal(Dinheiro.create(1234).decimal(), '12.34');
    assert.equal(Dinheiro.tryCreate(12.5).ok, false);
    assert.equal(Dinheiro.tryCreate(0).ok, false);
    assert.equal(Dinheiro.tryCreate(100, 'reais').ok, false);
    assert.throws(() => Dinheiro.create(-1));
  });

  it('Dinheiro converte texto decimal brasileiro e internacional sem float', () => {
    const v = (s: string) => { const r = Dinheiro.centavosDeTexto(s); assert.ok(r.ok, s); return r.valor; };
    assert.equal(v('1.234,56'), 123456);
    assert.equal(v('1234.56'), 123456);
    assert.equal(v('-89,9'), -8990);
    assert.equal(v('0.10'), 10);
    assert.equal(v('1.234'), 123400);
    assert.equal(v('R$ 2.000,00'), 200000);
    assert.equal(Dinheiro.centavosDeTexto('abc').ok, false);
  });

  it('DataIso recusa data inexistente', () => {
    assert.equal(DataIso.tryCreate('2026-02-30').ok, false);
    assert.equal(DataIso.create('2026-01-01').diasAte(DataIso.create('2026-01-06')), 5);
    assert.throws(() => DataIso.create('01/01/2026'));
  });
});

describe('entidade Lancamento', () => {
  it('tryCreate acumula erros como valor (sem excecao)', () => {
    const r = Lancamento.tryCreate({ tipo: 'transferencia', descricao: 'x', conta_id: C1, conta_destino_id: C1, valor_centavos: 10.5, data_competencia: '2026-13-01' });
    assert.equal(r.ok, false);
    if (!r.ok) {
      const cod = r.erros.map((e) => e.codigo);
      for (const c of ['valor_invalido', 'data_invalida', 'descricao_invalida', 'mesma_conta']) assert.ok(cod.includes(c), c);
    }
    assert.equal(Lancamento.tryCreate({ tipo: 'entrada', descricao: 'ok', conta_id: C1, conta_destino_id: C2, valor_centavos: 1, data_competencia: '2026-01-01' }).ok, false);
  });

  it('editar nao muta o original e bloqueia estornado', () => {
    const l = Lancamento.create(entrada());
    const r = l.editar({ descricao: 'Outra descricao' });
    assert.ok(r.ok);
    assert.equal(l.paraDados().descricao, 'Mensalidade');
    assert.equal(r.valor.paraDados().descricao, 'Outra descricao');
    const est = l.estornar('2026-09-10');
    assert.ok(est.ok);
    assert.equal(est.valor.original.editar({ descricao: 'nova' }).ok, false);
  });

  it('efeito na conta: entrada soma, saida subtrai, transferencia move entre contas', () => {
    const t = Lancamento.create({ tipo: 'transferencia', descricao: 'Transferencia', conta_id: C1, conta_destino_id: C2, valor_centavos: 500, data_competencia: '2026-01-01', data_caixa: '2026-01-01' });
    assert.equal(t.efeitoNaConta(C1), -500);
    assert.equal(t.efeitoNaConta(C2), 500);
    assert.equal(Lancamento.create(entrada()).efeitoNaConta(C2), 0);
  });
});

describe('RegistrarLancamento e Transferir', () => {
  it('registra, audita e publica lancamento.registrado', async () => {
    const { repo, registrar } = montar();
    const ctx = contexto();
    const r = await registrar.execute(ctx, entrada());
    assert.ok(r.ok);
    assert.equal(r.valor.repetido, false);
    assert.equal(repo.linhas.get(r.valor.id)!.moeda, 'BRL');
    assert.deepEqual(ctx.efeitos.eventos.map((e) => e.evento), ['lancamento.registrado']);
    assert.equal(ctx.efeitos.eventos[0]!.dados.valor_centavos, 150_000);
    assert.equal(ctx.efeitos.auditoria[0]!.acao, 'lancamento.registrar');
  });

  it('mesma Idempotency-Key devolve o mesmo lancamento sem duplicar nem publicar de novo', async () => {
    const { repo, registrar } = montar();
    const ctx = contexto();
    const a = await registrar.execute(ctx, entrada());
    const b = await registrar.execute(ctx, entrada({ valor_centavos: 999 }));
    assert.ok(a.ok && b.ok);
    assert.equal(b.valor.id, a.valor.id);
    assert.equal(b.valor.repetido, true);
    assert.equal(repo.linhas.size, 1);
    assert.equal(ctx.efeitos.eventos.length, 1);
  });

  it('recusa categoria de natureza errada, conta arquivada e moeda divergente', async () => {
    const { repo, registrar } = montar();
    const r1 = await registrar.execute(contexto(), entrada({ categoria_id: DESP, chave_idempotencia: 'chave-teste-0002' }));
    assert.equal(r1.ok, false);
    if (!r1.ok) assert.equal(r1.erros[0]!.codigo, 'natureza_divergente');
    repo.contas.set(C2, { ativa: false, moeda: 'BRL' });
    const r2 = await registrar.execute(contexto(), entrada({ conta_id: C2, chave_idempotencia: 'chave-teste-0003' }));
    assert.equal(r2.ok, false);
    const r3 = await registrar.execute(contexto(), entrada({ conta_id: CUSD, moeda: 'BRL', chave_idempotencia: 'chave-teste-0004' }));
    assert.equal(r3.ok, false);
    if (!r3.ok) assert.equal(r3.erros[0]!.codigo, 'moeda_divergente');
    assert.equal(repo.linhas.size, 0);
  });

  it('Transferir exige contas diferentes da mesma moeda e grava realizado', async () => {
    const { repo, transferir } = montar();
    const ok = await transferir.execute(contexto(), { conta_origem_id: C1, conta_destino_id: C2, valor_centavos: 10_000, data: '2026-09-01', chave_idempotencia: 'transf-0001' });
    assert.ok(ok.ok);
    const d = repo.linhas.get(ok.valor.id)!;
    assert.equal(d.tipo, 'transferencia');
    assert.equal(d.data_caixa, '2026-09-01');
    const mesma = await transferir.execute(contexto(), { conta_origem_id: C1, conta_destino_id: C1, valor_centavos: 1, data: '2026-09-01' });
    assert.equal(mesma.ok, false);
    const moeda = await transferir.execute(contexto(), { conta_origem_id: C1, conta_destino_id: CUSD, valor_centavos: 1, data: '2026-09-01' });
    assert.equal(moeda.ok, false);
  });
});

describe('EditarLancamento, EstornarLancamento e AnexarComprovante', () => {
  it('edita classificacao com historico e auditoria; nao encontrado vira nao_encontrado', async () => {
    const { registrar, editar } = montar();
    const r = await registrar.execute(contexto(), entrada({ data_caixa: null }));
    assert.ok(r.ok);
    const ctx = contexto();
    const e = await editar.execute(ctx, { id: r.valor.id, descricao: 'Mensalidade setembro', data_caixa: '2026-09-07' });
    assert.ok(e.ok);
    assert.equal(ctx.efeitos.historicos.length, 1);
    const n = await editar.execute(contexto(), { id: '99999999-9999-4999-8999-999999999999', descricao: 'x' });
    assert.equal(n.ok, false);
    if (!n.ok) assert.equal(n.erros[0]!.codigo, 'nao_encontrado');
  });

  it('estorno gera lancamento inverso, marca o original e nunca apaga; segundo estorno e transicao_invalida', async () => {
    const { repo, registrar } = montar();
    const r = await registrar.execute(contexto(), entrada());
    assert.ok(r.ok);
    const estornar = new EstornarLancamento({ repo, hoje: () => '2026-09-10' });
    const ctx = contexto();
    const e = await estornar.execute(ctx, { id: r.valor.id, motivo: 'duplicado' });
    assert.ok(e.ok);
    assert.equal(repo.linhas.size, 2);
    assert.equal(repo.linhas.get(r.valor.id)!.estado, 'estornado');
    const est = repo.linhas.get(e.valor.estorno_id)!;
    assert.equal(est.tipo, 'saida');
    assert.equal(est.estorno_de_id, r.valor.id);
    assert.equal(est.valor_centavos, 150_000);
    assert.deepEqual(ctx.efeitos.eventos.map((x) => x.evento), ['lancamento.estornado', 'lancamento.registrado']);
    const de2 = await estornar.execute(contexto(), { id: r.valor.id });
    assert.equal(de2.ok, false);
    if (!de2.ok) assert.equal(de2.erros[0]!.codigo, 'transicao_invalida');
    const doEstorno = await estornar.execute(contexto(), { id: e.valor.estorno_id });
    assert.equal(doEstorno.ok, false);
  });

  it('estorno de transferencia troca origem e destino', () => {
    const t = Lancamento.create({ tipo: 'transferencia', descricao: 'Transferencia', conta_id: C1, conta_destino_id: C2, valor_centavos: 700, data_competencia: '2026-01-01', data_caixa: '2026-01-01' });
    const r = t.estornar('2026-01-02');
    assert.ok(r.ok);
    assert.equal(r.valor.estorno.efeitoNaConta(C1), 700);
    assert.equal(r.valor.estorno.efeitoNaConta(C2), -700);
  });

  it('comprovante so aceita anexo gravado para o proprio lancamento', async () => {
    const { repo, registrar } = montar();
    const r = await registrar.execute(contexto(), entrada());
    assert.ok(r.ok);
    const anexar = new AnexarComprovante({ repo, refs: repo });
    const anexo = '88888888-8888-4888-8888-888888888888';
    assert.equal((await anexar.execute(contexto(), { id: r.valor.id, anexo_id: anexo })).ok, false);
    repo.anexos.set(anexo, r.valor.id);
    assert.ok((await anexar.execute(contexto(), { id: r.valor.id, anexo_id: anexo })).ok);
    assert.equal(repo.linhas.get(r.valor.id)!.comprovante_anexo_id, anexo);
  });
});

describe('Conta, Categoria e Centro de custo', () => {
  it('conta banco exige dados bancarios; nome unico e conflito', async () => {
    assert.equal(Conta.tryCreate({ nome: 'Itau', tipo: 'banco' }).ok, false);
    const repo = new ContasMemoria();
    const criar = new CriarConta({ repo });
    const r = await criar.execute(contexto(), { nome: 'Caixa da loja', tipo: 'caixa', saldo_inicial_centavos: 10_000 });
    assert.ok(r.ok);
    const dup = await criar.execute(contexto(), { nome: 'caixa da LOJA', tipo: 'caixa' });
    assert.equal(dup.ok, false);
    if (!dup.ok) assert.equal(dup.erros[0]!.codigo, 'conflito');
  });

  it('saldo inicial e moeda nao mudam depois de lancamentos; arquivar duas vezes e transicao_invalida', async () => {
    const repo = new ContasMemoria();
    const r = await new CriarConta({ repo }).execute(contexto(), { nome: 'Caixa', tipo: 'caixa' });
    assert.ok(r.ok);
    repo.comLancamentos.add(r.valor.id);
    const e = await new EditarConta({ repo }).execute(contexto(), { id: r.valor.id, saldo_inicial_centavos: 5 });
    assert.equal(e.ok, false);
    const arquivar = new AlternarConta({ repo }, 'arquivar');
    assert.ok((await arquivar.execute(contexto(), { id: r.valor.id })).ok);
    const de2 = await arquivar.execute(contexto(), { id: r.valor.id });
    assert.equal(de2.ok, false);
    if (!de2.ok) assert.equal(de2.erros[0]!.codigo, 'transicao_invalida');
  });

  it('categoria filha herda natureza, sem ciclo e com profundidade maxima 3', async () => {
    const repo = new CategoriasMemoria();
    const criar = new CriarCategoria({ repo });
    const a = await criar.execute(contexto(), { nome: 'Pessoal', natureza: 'despesa' });
    assert.ok(a.ok);
    const b = await criar.execute(contexto(), { nome: 'Salarios', natureza: 'despesa', parent_id: a.valor.id });
    assert.ok(b.ok);
    const errada = await criar.execute(contexto(), { nome: 'Vendas', natureza: 'receita', parent_id: a.valor.id });
    assert.equal(errada.ok, false);
    const c = await criar.execute(contexto(), { nome: 'CLT', natureza: 'despesa', parent_id: b.valor.id });
    assert.ok(c.ok);
    const funda = await criar.execute(contexto(), { nome: 'Nivel 4', natureza: 'despesa', parent_id: c.valor.id });
    assert.equal(funda.ok, false);
    const ciclo = await new EditarCategoria({ repo }).execute(contexto(), { id: a.valor.id, parent_id: c.valor.id });
    assert.equal(ciclo.ok, false);
    if (!ciclo.ok) assert.ok(ciclo.erros.some((x) => x.codigo === 'ciclo'));
    const excluirMae = await new ExcluirCategoria({ repo }).execute(contexto(), { id: a.valor.id });
    assert.equal(excluirMae.ok, false);
    assert.ok((await new ExcluirCategoria({ repo }).execute(contexto(), { id: c.valor.id })).ok);
    assert.equal(Categoria.tryCreate({ nome: 'x', natureza: 'receita' }).ok, false);
  });

  it('centro de custo com codigo unico e exclusao so sem uso', async () => {
    const repo = new CentrosMemoria();
    const r = await new CriarCentroCusto({ repo }).execute(contexto(), { codigo: 'adm', nome: 'Administrativo' });
    assert.ok(r.ok);
    assert.equal((await new CriarCentroCusto({ repo }).execute(contexto(), { codigo: 'ADM', nome: 'Outro' })).ok, false);
    repo.uso.set(r.valor.id, 3);
    assert.equal((await new ExcluirCentroCusto({ repo }).execute(contexto(), { id: r.valor.id })).ok, false);
    repo.uso.delete(r.valor.id);
    assert.ok((await new ExcluirCentroCusto({ repo }).execute(contexto(), { id: r.valor.id })).ok);
  });
});

describe('Conciliacao: ImportarExtrato (job), sugestao e Conciliar', () => {
  const OFX = `OFXHEADER:100
<OFX><BANKMSGSRSV1><STMTTRNRS><STMTRS><BANKTRANLIST>
<STMTTRN><TRNTYPE>CREDIT<DTPOSTED>20260906120000[-3:BRT]<TRNAMT>1500.00<FITID>A1<MEMO>TED RECEBIDA</STMTTRN>
<STMTTRN><TRNTYPE>DEBIT<DTPOSTED>20260910<TRNAMT>-65,90<FITID>A2<MEMO>TARIFA</STMTTRN>
<STMTTRN><TRNTYPE>DEBIT<DTPOSTED>xx<TRNAMT>-1<FITID>A3</STMTTRN>
</BANKTRANLIST></STMTRS></STMTTRNRS></BANKMSGSRSV1></OFX>`;

  it('le OFX com valor em centavos e sinal; linha ruim vira erro sem derrubar as outras', () => {
    const r = lerOfx(OFX);
    assert.equal(r.itens.length, 2);
    assert.deepEqual(r.itens.map((i) => [i.data, i.valor_centavos, i.identificador]), [['2026-09-06', 150000, 'A1'], ['2026-09-10', -6590, 'A2']]);
    assert.equal(r.erros.length, 1);
  });

  it('le CSV com credito e debito e gera identificador estavel para linhas iguais', () => {
    const r = lerCsvExtrato('Data;Historico;Credito;Debito\n06/09/2026;PIX;100,00;\n07/09/2026;TARIFA;;2,50\n07/09/2026;TARIFA;;2,50\n');
    assert.equal(r.itens.length, 3);
    assert.deepEqual(r.itens.map((i) => i.valor_centavos), [10000, -250, -250]);
    assert.notEqual(r.itens[1]!.identificador, r.itens[2]!.identificador);
    assert.equal(lerCsvExtrato('a;b\n1;2').itens.length, 0);
  });

  it('escolherPar pega a data mais proxima dentro da janela e respeita reservados', () => {
    const c = [{ id: 'a', data: '2026-09-01', descricao: '' }, { id: 'b', data: '2026-09-05', descricao: '' }, { id: 'c', data: '2026-09-30', descricao: '' }];
    assert.equal(escolherPar({ data: '2026-09-06' }, c)?.id, 'b');
    assert.equal(escolherPar({ data: '2026-09-06' }, c, new Set(['b']))?.id, 'a');
    assert.equal(escolherPar({ data: '2026-09-20' }, c), null);
  });

  it('job importa sem duplicar, sugere par, concilia, cria lancamento do item e ignora', async () => {
    const { repo, registrar } = montar();
    const conc = new ConciliacaoMemoria(repo);
    conc.contasAtivas.add(C1);
    const ja = await registrar.execute(contexto(), entrada({ valor_centavos: 150_000, data_caixa: null, data_competencia: '2026-09-05' }));
    assert.ok(ja.ok);
    const ctx = contexto();
    const sol = await new SolicitarImportacaoExtrato({ extratos: conc, fila: conc, novoId: () => 'e-1' }).execute(ctx, { conta_id: C1, nome_arquivo: 'set.ofx', conteudo: OFX });
    assert.ok(sol.ok);
    assert.equal(conc.jobs[0]!.tipo, TIPO_JOB_EXTRATO);
    let n = 0;
    const sugerir = new SugerirPares({ itens: conc });
    const processar = new ProcessarExtrato({ extratos: conc, itens: conc, sugerir, novoId: () => `i-${++n}` });
    const p1 = await processar.execute(ctx, { extrato_id: 'e-1' });
    assert.ok(p1.ok);
    assert.deepEqual(p1.valor, { importados: 2, duplicados: 0, sugeridos: 1 });
    assert.ok(ctx.efeitos.eventos.some((e) => e.evento === 'extrato.importado'));
    conc.extratos.get('e-1')!.estado = 'pendente';
    const p2 = await processar.execute(ctx, { extrato_id: 'e-1' });
    assert.ok(p2.ok);
    assert.equal(p2.valor.duplicados, 2);

    const credito = [...conc.itens.values()].find((i) => i.valor_centavos === 150_000)!;
    assert.equal(credito.sugestao_lancamento_id, ja.valor.id);
    const conciliar = new Conciliar({ itens: conc, lancamentos: repo });
    const errado = await conciliar.execute(contexto(), { item_id: [...conc.itens.values()].find((i) => i.valor_centavos < 0)!.id, lancamento_id: ja.valor.id });
    assert.equal(errado.ok, false);
    assert.ok((await conciliar.execute(contexto(), { item_id: credito.id, lancamento_id: ja.valor.id })).ok);
    const l = repo.linhas.get(ja.valor.id)!;
    assert.equal(l.conciliado, true);
    assert.equal(l.data_caixa, '2026-09-06');
    const de2 = await conciliar.execute(contexto(), { item_id: credito.id, lancamento_id: ja.valor.id });
    assert.equal(de2.ok, false);

    const tarifa = [...conc.itens.values()].find((i) => i.valor_centavos === -6590)!;
    const criar = new ConciliarCriando({ itens: conc, registrar, conciliar });
    const novo = await criar.execute(contexto(), { item_id: tarifa.id, categoria_id: DESP });
    assert.ok(novo.ok);
    const ln = repo.linhas.get(novo.valor.lancamento_id)!;
    assert.deepEqual([ln.tipo, ln.valor_centavos, ln.conciliado, ln.origem], ['saida', 6590, true, 'extrato']);
    assert.equal(conc.itens.get(tarifa.id)!.estado, 'conciliado');
    const ign = await new AlternarItem({ itens: conc }, 'ignorar').execute(contexto(), { item_id: tarifa.id });
    assert.equal(ign.ok, false);
  });

  it('extrato sem transacao valida e conta arquivada sao recusados', async () => {
    const conc = new ConciliacaoMemoria(new LancamentosMemoria());
    const sol = new SolicitarImportacaoExtrato({ extratos: conc, fila: conc, novoId: () => 'x' });
    assert.equal((await sol.execute(contexto(), { conta_id: C1, nome_arquivo: 'a.csv', conteudo: 'data;valor\n' })).ok, false);
    conc.contasAtivas.add(C1);
    const r = await sol.execute(contexto(), { conta_id: C1, nome_arquivo: 'a.csv', conteudo: 'data;valor\nxx;yy\n' });
    assert.equal(r.ok, false);
    if (!r.ok) assert.equal(r.erros[0]!.codigo, 'extrato_invalido');
  });
});

describe('ExportarContabil (job) e reacao a fatura.paga', () => {
  it('gera CSV com sinal, escapa separador e neutraliza formula', () => {
    const csv = gerarCsv([{ id: 'x', data_competencia: '2026-09-01', data_caixa: null, tipo: 'saida', descricao: '=SOMA(A1);"x"', conta: 'Itau', conta_destino: null,
      categoria_codigo: '2.1', categoria: 'Pessoal', centro_custo: 'ADM', parceiro_documento: null, parceiro: null, valor_centavos: 12345, moeda: 'BRL', estado: 'ativo', conciliado: false, estorno_de_id: null }]);
    const [cab, linha] = csv.split('\r\n');
    assert.ok(cab!.startsWith('id;data_competencia'));
    assert.ok(linha!.includes(';-123.45;'));
    assert.ok(linha!.includes(`"'=SOMA(A1);""x"""`));
  });

  it('solicita e processa a exportacao pelo job, valida periodo', async () => {
    const exp = new ExportacoesMemoria();
    exp.dados.push({ id: 'a', data_competencia: '2026-09-02', data_caixa: '2026-09-02', tipo: 'entrada', descricao: 'Venda', conta: 'Itau', conta_destino: null,
      categoria_codigo: null, categoria: null, centro_custo: null, parceiro_documento: null, parceiro: null, valor_centavos: 100, moeda: 'BRL', estado: 'ativo', conciliado: true, estorno_de_id: null });
    const sol = new SolicitarExportacao({ exportacoes: exp, fila: exp, novoId: () => 'x-1' });
    assert.equal((await sol.execute(contexto(), { de: '2026-09-30', ate: '2026-09-01' })).ok, false);
    const r = await sol.execute(contexto(), { de: '2026-09-01', ate: '2026-09-30' });
    assert.ok(r.ok);
    assert.equal(exp.jobs[0]!.tipo, TIPO_JOB_EXPORTACAO);
    const ctx = contexto();
    const p = await new ProcessarExportacao({ exportacoes: exp }).execute(ctx, { exportacao_id: 'x-1' });
    assert.ok(p.ok);
    assert.equal(p.valor.total, 1);
    assert.ok(exp.linhasExp.get('x-1')!.conteudo!.includes(';1.00;'));
    assert.equal(ctx.efeitos.eventos[0]!.evento, 'exportacao_contabil.concluida');
  });

  it('fatura.paga vira entrada idempotente pelo id do evento; conta a pagar vira saida', () => {
    const e = lancamentoDaBaixa({ id: 'ev-1', dados: { id: 'doc', tipo: 'fatura', numero: 'F-12', valor_pago_centavos: 9900, data_pagamento: '2026-09-15', parceiro_id: PARC } }, C1);
    assert.ok(e);
    assert.deepEqual([e.tipo, e.valor_centavos, e.conta_id, e.chave_idempotencia, e.data_caixa], ['entrada', 9900, C1, 'contas:ev-1', '2026-09-15']);
    const s = lancamentoDaBaixa({ id: 'ev-2', dados: { tipo: 'conta_pagar', valor: '1.250,00', data: '2026-09-16', conta_financeira_id: C2 } }, C1);
    assert.deepEqual([s?.tipo, s?.valor_centavos, s?.conta_id], ['saida', 125000, C2]);
    assert.equal(lancamentoDaBaixa({ id: 'ev-3', dados: { tipo: 'fatura' } }, C1), null);
  });
});
