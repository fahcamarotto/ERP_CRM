/**
 * Handlers de worker do Financeiro (carregados pelo worker do nucleo na partida).
 * `c` ja esta numa transacao do papel erp_worker com o escopo do job (RLS vale).
 */
import type { HandlersModulo } from '@erp/api/sdk/puro';
import { contextoPg } from '../api/compartilhado/efeitos-pg.ts';
import { TIPO_JOB_EXTRATO } from '../api/conciliacao/conciliar.ts';
import { TIPO_JOB_EXPORTACAO } from '../api/exportacao/exportar-contabil.ts';
import { casosDeUso } from '../api/fabrica.ts';
import { lancamentoDaBaixa } from '../api/lancamento/use-case/baixa-contas.ts';

const SISTEMA = { tipo: 'sistema' as const, id: null };

const handlers: HandlersModulo = {
  // M4.4 ImportarExtrato: progresso gravado em financeiro_extratos.
  [TIPO_JOB_EXTRATO]: async (d, c) => {
    const p = d.payload as { extrato_id: string };
    const r = await casosDeUso(c).processarExtrato.execute(contextoPg(c, SISTEMA), { extrato_id: p.extrato_id });
    if (!r.ok) throw new Error(r.erros.map((e) => e.mensagem).join('; '));
  },

  // M4.6 ExportarContabil: CSV gravado em financeiro_exportacoes.
  [TIPO_JOB_EXPORTACAO]: async (d, c) => {
    const p = d.payload as { exportacao_id: string };
    const r = await casosDeUso(c).processarExportacao.execute(contextoPg(c, SISTEMA), { exportacao_id: p.exportacao_id });
    if (!r.ok) throw new Error(r.erros.map((e) => e.mensagem).join('; '));
  },

  // M5.2: cada baixa do modulo Contas vira lancamento realizado (idempotente pelo id do evento).
  'financeiro:ao:fatura.paga': async (d, c) => {
    const ev = d.payload as { id: string; dados?: Record<string, unknown> };
    const padrao = (await c.query("SELECT id FROM financeiro_contas WHERE ativa AND deleted_at IS NULL AND moeda = 'BRL' ORDER BY created_at LIMIT 1")).rows[0]?.id ?? null;
    const entrada = lancamentoDaBaixa(ev, padrao as string | null);
    if (!entrada) return; // evento sem valor, data ou conta: nada a lancar (nao adianta reprocessar)
    const r = await casosDeUso(c).registrarLancamento.execute(contextoPg(c, SISTEMA), entrada);
    if (!r.ok) {
      // Referencia opcional invalida (categoria, centro, parceiro) nao bloqueia a baixa: lanca sem ela.
      const r2 = await casosDeUso(c).registrarLancamento.execute(contextoPg(c, SISTEMA), { ...entrada, categoria_id: null, centro_custo_id: null, parceiro_id: null });
      if (!r2.ok) throw new Error(r2.erros.map((e) => e.mensagem).join('; '));
    }
  },
};

export default handlers;
