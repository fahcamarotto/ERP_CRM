-- M4 Financeiro: contas e caixas, categorias em arvore, centros de custo, lancamentos (Dinheiro em
-- centavos, nunca float), extratos e itens de conciliacao (job), exportacoes contabeis (job).
-- Toda tabela: tenant_id e workspace_id do contexto da sessao, PK composta, FK composta, RLS por
-- nucleo_aplicar_padrao, exclusao logica (sem DELETE). Lancamento nunca e apagado: estorno gera outro.
-- Idempotente.

-- M4.1 Contas e caixas ----------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS financeiro_contas (
  id                     uuid NOT NULL DEFAULT gen_random_uuid(),
  tenant_id              uuid NOT NULL DEFAULT nucleo_tenant_atual(),
  workspace_id           uuid NOT NULL DEFAULT nucleo_workspace_atual(),
  creator_id             uuid,
  nome                   text NOT NULL CHECK (length(btrim(nome)) BETWEEN 2 AND 120),
  tipo                   text NOT NULL DEFAULT 'banco' CHECK (tipo IN ('banco', 'caixa', 'carteira', 'investimento')),
  banco_codigo           text CHECK (banco_codigo IS NULL OR banco_codigo ~ '^[0-9]{3}$'),
  banco_nome             text,
  agencia                text CHECK (agencia IS NULL OR agencia ~ '^[0-9]{1,6}(-[0-9Xx])?$'),
  numero                 text CHECK (numero IS NULL OR numero ~ '^[0-9]{1,13}(-[0-9Xx])?$'),
  moeda                  text NOT NULL DEFAULT 'BRL' CHECK (moeda ~ '^[A-Z]{3}$'),
  saldo_inicial_centavos bigint NOT NULL DEFAULT 0,
  data_saldo_inicial     date NOT NULL DEFAULT current_date,
  ativa                  boolean NOT NULL DEFAULT true,
  extras                 jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at             timestamptz NOT NULL DEFAULT now(),
  updated_at             timestamptz NOT NULL DEFAULT now(),
  deleted_at             timestamptz,
  PRIMARY KEY (id, tenant_id, workspace_id),
  FOREIGN KEY (workspace_id, tenant_id) REFERENCES workspaces (id, tenant_id),
  FOREIGN KEY (creator_id, tenant_id, workspace_id) REFERENCES usuarios (id, tenant_id, workspace_id)
);
CREATE UNIQUE INDEX IF NOT EXISTS financeiro_contas_nome_uq
  ON financeiro_contas (tenant_id, workspace_id, lower(nome)) WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS financeiro_contas_lista_idx ON financeiro_contas (tenant_id, workspace_id, created_at, id) WHERE deleted_at IS NULL;
SELECT nucleo_aplicar_padrao('financeiro_contas');
DROP TRIGGER IF EXISTS financeiro_contas_extras ON financeiro_contas;
CREATE TRIGGER financeiro_contas_extras BEFORE INSERT OR UPDATE OF extras ON financeiro_contas
  FOR EACH ROW EXECUTE FUNCTION nucleo_trigger_extras('financeiro', 'conta');

-- M4.2 Categorias em arvore (receita e despesa) ------------------------------------------------
CREATE TABLE IF NOT EXISTS financeiro_categorias (
  id            uuid NOT NULL DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL DEFAULT nucleo_tenant_atual(),
  workspace_id  uuid NOT NULL DEFAULT nucleo_workspace_atual(),
  creator_id    uuid,
  nome          text NOT NULL CHECK (length(btrim(nome)) BETWEEN 2 AND 80),
  natureza      text NOT NULL CHECK (natureza IN ('receita', 'despesa')),
  parent_id     uuid,
  codigo        text CHECK (codigo IS NULL OR codigo ~ '^[0-9A-Za-z.]{1,20}$'),
  ativa         boolean NOT NULL DEFAULT true,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now(),
  deleted_at    timestamptz,
  PRIMARY KEY (id, tenant_id, workspace_id),
  FOREIGN KEY (workspace_id, tenant_id) REFERENCES workspaces (id, tenant_id),
  FOREIGN KEY (creator_id, tenant_id, workspace_id) REFERENCES usuarios (id, tenant_id, workspace_id),
  FOREIGN KEY (parent_id, tenant_id, workspace_id) REFERENCES financeiro_categorias (id, tenant_id, workspace_id),
  CHECK (parent_id IS NULL OR parent_id <> id)
);
CREATE UNIQUE INDEX IF NOT EXISTS financeiro_categorias_nome_uq
  ON financeiro_categorias (tenant_id, workspace_id, natureza, coalesce(parent_id, '00000000-0000-0000-0000-000000000000'::uuid), lower(nome)) WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS financeiro_categorias_lista_idx ON financeiro_categorias (tenant_id, workspace_id, created_at, id) WHERE deleted_at IS NULL;
SELECT nucleo_aplicar_padrao('financeiro_categorias');

-- M4.2 Centros de custo ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS financeiro_centros_custo (
  id            uuid NOT NULL DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL DEFAULT nucleo_tenant_atual(),
  workspace_id  uuid NOT NULL DEFAULT nucleo_workspace_atual(),
  creator_id    uuid,
  codigo        text NOT NULL CHECK (codigo ~ '^[0-9A-Za-z.-]{1,20}$'),
  nome          text NOT NULL CHECK (length(btrim(nome)) BETWEEN 2 AND 120),
  descricao     text,
  ativo         boolean NOT NULL DEFAULT true,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now(),
  deleted_at    timestamptz,
  PRIMARY KEY (id, tenant_id, workspace_id),
  FOREIGN KEY (workspace_id, tenant_id) REFERENCES workspaces (id, tenant_id),
  FOREIGN KEY (creator_id, tenant_id, workspace_id) REFERENCES usuarios (id, tenant_id, workspace_id)
);
CREATE UNIQUE INDEX IF NOT EXISTS financeiro_centros_custo_codigo_uq
  ON financeiro_centros_custo (tenant_id, workspace_id, upper(codigo)) WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS financeiro_centros_custo_lista_idx ON financeiro_centros_custo (tenant_id, workspace_id, created_at, id) WHERE deleted_at IS NULL;
SELECT nucleo_aplicar_padrao('financeiro_centros_custo');

-- M4.3 Agregado Lancamento --------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS financeiro_lancamentos (
  id                   uuid NOT NULL DEFAULT gen_random_uuid(),
  tenant_id            uuid NOT NULL DEFAULT nucleo_tenant_atual(),
  workspace_id         uuid NOT NULL DEFAULT nucleo_workspace_atual(),
  creator_id           uuid,
  tipo                 text NOT NULL CHECK (tipo IN ('entrada', 'saida', 'transferencia')),
  descricao            text NOT NULL CHECK (length(btrim(descricao)) BETWEEN 2 AND 200),
  conta_id             uuid NOT NULL,
  conta_destino_id     uuid,
  categoria_id         uuid,
  centro_custo_id      uuid,
  parceiro_id          uuid,
  valor_centavos       bigint NOT NULL CHECK (valor_centavos > 0),
  moeda                text NOT NULL DEFAULT 'BRL' CHECK (moeda ~ '^[A-Z]{3}$'),
  data_competencia     date NOT NULL,
  data_caixa           date,
  comprovante_anexo_id uuid,
  conciliado           boolean NOT NULL DEFAULT false,
  conciliado_em        timestamptz,
  estado               text NOT NULL DEFAULT 'ativo' CHECK (estado IN ('ativo', 'estornado')),
  estorno_de_id        uuid,
  origem               text NOT NULL DEFAULT 'manual' CHECK (origem IN ('manual', 'transferencia', 'estorno', 'extrato', 'contas', 'seed')),
  chave_idempotencia   text CHECK (chave_idempotencia IS NULL OR length(chave_idempotencia) BETWEEN 8 AND 200),
  extras               jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at           timestamptz NOT NULL DEFAULT now(),
  updated_at           timestamptz NOT NULL DEFAULT now(),
  deleted_at           timestamptz,
  PRIMARY KEY (id, tenant_id, workspace_id),
  FOREIGN KEY (workspace_id, tenant_id) REFERENCES workspaces (id, tenant_id),
  FOREIGN KEY (creator_id, tenant_id, workspace_id) REFERENCES usuarios (id, tenant_id, workspace_id),
  FOREIGN KEY (conta_id, tenant_id, workspace_id) REFERENCES financeiro_contas (id, tenant_id, workspace_id),
  FOREIGN KEY (conta_destino_id, tenant_id, workspace_id) REFERENCES financeiro_contas (id, tenant_id, workspace_id),
  FOREIGN KEY (categoria_id, tenant_id, workspace_id) REFERENCES financeiro_categorias (id, tenant_id, workspace_id),
  FOREIGN KEY (centro_custo_id, tenant_id, workspace_id) REFERENCES financeiro_centros_custo (id, tenant_id, workspace_id),
  FOREIGN KEY (parceiro_id, tenant_id, workspace_id) REFERENCES cadastros_parceiros (id, tenant_id, workspace_id),
  FOREIGN KEY (comprovante_anexo_id, tenant_id, workspace_id) REFERENCES anexos (id, tenant_id, workspace_id),
  FOREIGN KEY (estorno_de_id, tenant_id, workspace_id) REFERENCES financeiro_lancamentos (id, tenant_id, workspace_id),
  CHECK ((tipo = 'transferencia') = (conta_destino_id IS NOT NULL)),
  CHECK (conta_destino_id IS NULL OR conta_destino_id <> conta_id)
);
CREATE UNIQUE INDEX IF NOT EXISTS financeiro_lancamentos_idem_uq
  ON financeiro_lancamentos (tenant_id, workspace_id, chave_idempotencia) WHERE chave_idempotencia IS NOT NULL;
CREATE UNIQUE INDEX IF NOT EXISTS financeiro_lancamentos_estorno_uq
  ON financeiro_lancamentos (tenant_id, workspace_id, estorno_de_id) WHERE estorno_de_id IS NOT NULL AND deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS financeiro_lancamentos_lista_idx ON financeiro_lancamentos (tenant_id, workspace_id, created_at, id) WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS financeiro_lancamentos_conta_idx ON financeiro_lancamentos (tenant_id, workspace_id, conta_id, data_caixa) WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS financeiro_lancamentos_destino_idx ON financeiro_lancamentos (tenant_id, workspace_id, conta_destino_id, data_caixa) WHERE deleted_at IS NULL AND conta_destino_id IS NOT NULL;
SELECT nucleo_aplicar_padrao('financeiro_lancamentos');
DROP TRIGGER IF EXISTS financeiro_lancamentos_extras ON financeiro_lancamentos;
CREATE TRIGGER financeiro_lancamentos_extras BEFORE INSERT OR UPDATE OF extras ON financeiro_lancamentos
  FOR EACH ROW EXECUTE FUNCTION nucleo_trigger_extras('financeiro', 'lancamento');

-- M4.4 Conciliacao: extratos importados (job) e itens ------------------------------------------
CREATE TABLE IF NOT EXISTS financeiro_extratos (
  id            uuid NOT NULL DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL DEFAULT nucleo_tenant_atual(),
  workspace_id  uuid NOT NULL DEFAULT nucleo_workspace_atual(),
  creator_id    uuid,
  conta_id      uuid NOT NULL,
  nome_arquivo  text NOT NULL,
  formato       text NOT NULL CHECK (formato IN ('ofx', 'csv')),
  conteudo      text NOT NULL,
  estado        text NOT NULL DEFAULT 'pendente' CHECK (estado IN ('pendente', 'processando', 'concluida', 'erro')),
  total         integer NOT NULL DEFAULT 0,
  importados    integer NOT NULL DEFAULT 0,
  duplicados    integer NOT NULL DEFAULT 0,
  sugeridos     integer NOT NULL DEFAULT 0,
  erros         jsonb NOT NULL DEFAULT '[]'::jsonb,
  job_id        uuid,
  concluida_em  timestamptz,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now(),
  deleted_at    timestamptz,
  PRIMARY KEY (id, tenant_id, workspace_id),
  FOREIGN KEY (workspace_id, tenant_id) REFERENCES workspaces (id, tenant_id),
  FOREIGN KEY (creator_id, tenant_id, workspace_id) REFERENCES usuarios (id, tenant_id, workspace_id),
  FOREIGN KEY (conta_id, tenant_id, workspace_id) REFERENCES financeiro_contas (id, tenant_id, workspace_id)
);
CREATE INDEX IF NOT EXISTS financeiro_extratos_lista_idx ON financeiro_extratos (tenant_id, workspace_id, created_at, id) WHERE deleted_at IS NULL;
SELECT nucleo_aplicar_padrao('financeiro_extratos');

CREATE TABLE IF NOT EXISTS financeiro_extrato_itens (
  id                     uuid NOT NULL DEFAULT gen_random_uuid(),
  tenant_id              uuid NOT NULL DEFAULT nucleo_tenant_atual(),
  workspace_id           uuid NOT NULL DEFAULT nucleo_workspace_atual(),
  creator_id             uuid,
  extrato_id             uuid NOT NULL,
  conta_id               uuid NOT NULL,
  data                   date NOT NULL,
  valor_centavos         bigint NOT NULL CHECK (valor_centavos <> 0),
  descricao              text NOT NULL DEFAULT '',
  identificador          text NOT NULL,
  estado                 text NOT NULL DEFAULT 'pendente' CHECK (estado IN ('pendente', 'conciliado', 'ignorado')),
  sugestao_lancamento_id uuid,
  lancamento_id          uuid,
  conciliado_em          timestamptz,
  created_at             timestamptz NOT NULL DEFAULT now(),
  updated_at             timestamptz NOT NULL DEFAULT now(),
  deleted_at             timestamptz,
  PRIMARY KEY (id, tenant_id, workspace_id),
  FOREIGN KEY (workspace_id, tenant_id) REFERENCES workspaces (id, tenant_id),
  FOREIGN KEY (creator_id, tenant_id, workspace_id) REFERENCES usuarios (id, tenant_id, workspace_id),
  FOREIGN KEY (extrato_id, tenant_id, workspace_id) REFERENCES financeiro_extratos (id, tenant_id, workspace_id),
  FOREIGN KEY (conta_id, tenant_id, workspace_id) REFERENCES financeiro_contas (id, tenant_id, workspace_id),
  FOREIGN KEY (sugestao_lancamento_id, tenant_id, workspace_id) REFERENCES financeiro_lancamentos (id, tenant_id, workspace_id),
  FOREIGN KEY (lancamento_id, tenant_id, workspace_id) REFERENCES financeiro_lancamentos (id, tenant_id, workspace_id),
  CHECK ((estado = 'conciliado') = (lancamento_id IS NOT NULL))
);
CREATE UNIQUE INDEX IF NOT EXISTS financeiro_extrato_itens_ident_uq
  ON financeiro_extrato_itens (tenant_id, workspace_id, conta_id, identificador) WHERE deleted_at IS NULL;
CREATE UNIQUE INDEX IF NOT EXISTS financeiro_extrato_itens_lancamento_uq
  ON financeiro_extrato_itens (tenant_id, workspace_id, lancamento_id) WHERE lancamento_id IS NOT NULL AND deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS financeiro_extrato_itens_lista_idx ON financeiro_extrato_itens (tenant_id, workspace_id, created_at, id) WHERE deleted_at IS NULL;
SELECT nucleo_aplicar_padrao('financeiro_extrato_itens');

-- M4.6 ExportarContabil (CSV por job) ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS financeiro_exportacoes (
  id            uuid NOT NULL DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL DEFAULT nucleo_tenant_atual(),
  workspace_id  uuid NOT NULL DEFAULT nucleo_workspace_atual(),
  creator_id    uuid,
  de            date NOT NULL,
  ate           date NOT NULL,
  estado        text NOT NULL DEFAULT 'pendente' CHECK (estado IN ('pendente', 'processando', 'concluida', 'erro')),
  total         integer NOT NULL DEFAULT 0,
  conteudo      text,
  job_id        uuid,
  concluida_em  timestamptz,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now(),
  deleted_at    timestamptz,
  PRIMARY KEY (id, tenant_id, workspace_id),
  FOREIGN KEY (workspace_id, tenant_id) REFERENCES workspaces (id, tenant_id),
  FOREIGN KEY (creator_id, tenant_id, workspace_id) REFERENCES usuarios (id, tenant_id, workspace_id),
  CHECK (ate >= de)
);
CREATE INDEX IF NOT EXISTS financeiro_exportacoes_lista_idx ON financeiro_exportacoes (tenant_id, workspace_id, created_at, id) WHERE deleted_at IS NULL;
SELECT nucleo_aplicar_padrao('financeiro_exportacoes');

GRANT SELECT, INSERT, UPDATE ON financeiro_contas, financeiro_categorias, financeiro_centros_custo, financeiro_lancamentos,
  financeiro_extratos, financeiro_extrato_itens, financeiro_exportacoes TO erp_app;
-- Worker: processa extrato (itens e sugestoes), exportacao e o lancamento vindo da baixa de contas (financeiro:ao:fatura.paga).
GRANT SELECT, INSERT, UPDATE ON financeiro_lancamentos, financeiro_extratos, financeiro_extrato_itens, financeiro_exportacoes TO erp_worker;
GRANT SELECT ON financeiro_contas, financeiro_categorias, financeiro_centros_custo TO erp_worker;
