/**
 * Repositorios em memoria das portas da Folha e porta Efeitos que grava o que foi publicado.
 * Os casos de uso rodam aqui sem banco, sem Fastify e sem o SDK.
 */
import { Beneficio, type BeneficioDados } from '../api/beneficio/model/beneficio.ts';
import type { ConsultarReferenciasBeneficio, ExcluirBeneficio, GravarBeneficio, ObterBeneficio } from '../api/beneficio/model/portas.ts';
import type { ContextoCaso, Efeitos } from '../api/compartilhado/efeitos.ts';
import { Competencia, type CompetenciaDados, type Rateio } from '../api/competencia/model/competencia.ts';
import type {
  BaseCalculo, ConsultarReferenciasFolha, Correio, FilaJobs, GravarCentros, GravarCompetencia, GravarHolerites, GravarRateios,
  GravarVariaveis, ObterCompetencia, ObterHolerite, Relogio,
} from '../api/competencia/model/portas.ts';
import { EventoFolha, type EventoFolhaDados } from '../api/evento/model/evento-folha.ts';
import type { ConsultarReferenciasEvento, GravarEventoFolha, ObterEventoFolha } from '../api/evento/model/portas.ts';
import { Holerite, type BaseFuncionario, type HoleriteDados, type VariavelLancada } from '../api/holerite/model/holerite.ts';

export const USUARIO = '00000000-0000-4000-8000-000000000001';

export class EfeitosMemoria implements Efeitos {
  auditoria: { acao: string; entidade: string; id: string | null; depois?: unknown }[] = [];
  eventos: { evento: string; dados: Record<string, unknown> }[] = [];
  historicos: { entidade: string; id: string; antes: unknown; depois: unknown }[] = [];
  notas: { entidade: string; id: string; corpo: string }[] = [];
  async auditar(acao: string, entidade: string, id: string | null, _antes?: unknown, depois?: unknown) { this.auditoria.push({ acao, entidade, id, depois }); }
  async publicar(evento: string, dados: Record<string, unknown>) { this.eventos.push({ evento, dados }); }
  async historico(entidade: string, id: string, antes: unknown, depois: unknown) { this.historicos.push({ entidade, id, antes, depois }); }
  async nota(entidade: string, id: string, corpo: string) { this.notas.push({ entidade, id, corpo }); }
}

export function contexto(): ContextoCaso & { efeitos: EfeitosMemoria } {
  return { ator: { tipo: 'usuario', id: USUARIO }, efeitos: new EfeitosMemoria() };
}

export class BeneficiosMemoria implements ObterBeneficio, GravarBeneficio, ExcluirBeneficio, ConsultarReferenciasBeneficio {
  linhas = new Map<string, BeneficioDados & { deleted: boolean }>();
  funcionarios = new Set<string>();
  funcoes = new Set<string>();
  async obterPorId(id: string) { const d = this.linhas.get(id); return d && !d.deleted ? Beneficio.reidratar(d) : null; }
  async inserir(b: Beneficio) { this.linhas.set(b.id, { ...b.paraDados(), deleted: false }); }
  async atualizar(b: Beneficio) { this.linhas.set(b.id, { ...b.paraDados(), deleted: false }); }
  async excluir(id: string) { const d = this.linhas.get(id); if (d) d.deleted = true; }
  async funcionarioAtivo(id: string) { return this.funcionarios.has(id); }
  async funcaoAtiva(id: string) { return this.funcoes.has(id); }
}

export class EventosMemoria implements ObterEventoFolha, GravarEventoFolha, ConsultarReferenciasEvento {
  linhas = new Map<string, EventoFolhaDados>();
  funcionarios = new Set<string>();
  async obterPorId(id: string) { const d = this.linhas.get(id); return d ? EventoFolha.reidratar(d) : null; }
  async buscarPorCodigo(codigo: string) { const d = [...this.linhas.values()].find((x) => x.codigo === codigo); return d ? EventoFolha.reidratar(d) : null; }
  async inserir(e: EventoFolha) { this.linhas.set(e.id, e.paraDados()); }
  async atualizar(e: EventoFolha) { this.linhas.set(e.id, e.paraDados()); }
  async funcionarioAtivo(id: string) { return this.funcionarios.has(id); }
}

/** Competencias, base de calculo, holerites, rateios, variaveis, centros, fila e correio num lugar so. */
export class FolhaMemoria implements ObterCompetencia, GravarCompetencia, BaseCalculo, GravarHolerites, ObterHolerite, GravarRateios,
  GravarVariaveis, ConsultarReferenciasFolha, GravarCentros, FilaJobs, Correio, Relogio {
  competencias = new Map<string, CompetenciaDados>();
  base: BaseFuncionario[] = [];
  eventos: EventoFolha[] = [];
  beneficios: Beneficio[] = [];
  variaveis: (VariavelLancada & { id: string; competencia_id: string; deleted: boolean })[] = [];
  holerites = new Map<string, HoleriteDados & { deleted: boolean }>();
  rateios = new Map<string, Rateio[]>();
  centros = new Map<string, string>();
  departamentos = new Set<string>();
  centrosCusto = new Set<string>();
  jobs: { id: string; tipo: string; payload: Record<string, unknown> }[] = [];
  emails: { para: string; holerite_id: string }[] = [];

  async obterPorId(id: string) { const d = this.competencias.get(id); return d ? Competencia.reidratar(d) : null; }
  async buscarPorMes(mes: string) { const d = [...this.competencias.values()].find((x) => x.mes === mes); return d ? Competencia.reidratar(d) : null; }
  async inserir(c: Competencia) { this.competencias.set(c.id, c.paraDados()); }
  async atualizar(c: Competencia) { this.competencias.set(c.id, c.paraDados()); }
  async funcionariosComContrato() { return this.base.map((b) => ({ ...b, centro_custo_id: b.departamento_id ? this.centros.get(b.departamento_id) ?? null : null })); }
  async eventosAtivos() { return this.eventos; }
  async beneficiosAtivos() { return this.beneficios; }
  async variaveisDa(cid: string) { return this.variaveis.filter((v) => v.competencia_id === cid && !v.deleted); }
  async substituirHolerites(cid: string, hs: Holerite[]) {
    for (const h of this.holerites.values()) if (h.competencia_id === cid) h.deleted = true;
    for (const h of hs) this.holerites.set(h.id, { ...h.paraDados(), deleted: false });
  }
  async holeritesDa(cid: string) { return [...this.holerites.values()].filter((h) => h.competencia_id === cid && !h.deleted).map((h) => Holerite.reidratar(h)); }
  async obterHolerite(id: string) { const h = this.holerites.get(id); return h && !h.deleted ? Holerite.reidratar(h) : null; }
  async atualizarHolerite(h: Holerite) { this.holerites.set(h.id, { ...h.paraDados(), deleted: false }); }
  async gravarRateios(cid: string, r: Rateio[]) { this.rateios.set(cid, r); }
  async inserirVariavel(v: Parameters<GravarVariaveis['inserirVariavel']>[0]) { this.variaveis.push({ ...v, deleted: false }); }
  async excluirVariavel(cid: string, id: string) { const v = this.variaveis.find((x) => x.id === id && x.competencia_id === cid && !x.deleted); if (v) v.deleted = true; return !!v; }
  async funcionarioAtivo(id: string) { return this.base.some((b) => b.funcionario_id === id); }
  async eventoVariavelAtivo(id: string) { return this.eventos.some((e) => e.id === id && e.estado === 'ativo' && e.paraDados().recorrencia === 'variavel'); }
  async departamentoExiste(id: string) { return this.departamentos.has(id); }
  async centroCustoAtivo(id: string) { return this.centrosCusto.has(id); }
  async definirCentro(dep: string, centro: string | null) { if (centro) this.centros.set(dep, centro); else this.centros.delete(dep); }
  async enfileirar(tipo: string, payload: Record<string, unknown>) { const id = `job-${this.jobs.length + 1}`; this.jobs.push({ id, tipo, payload }); return id; }
  async enviarHolerite(h: HoleriteDados) { if (!h.email) return null; this.emails.push({ para: h.email, holerite_id: h.id }); return `email-${this.emails.length}`; }
  agora() { return '2026-10-01T12:00:00.000Z'; }
}
