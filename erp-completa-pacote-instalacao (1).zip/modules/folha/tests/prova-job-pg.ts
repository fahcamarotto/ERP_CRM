/**
 * Prova do job de fechamento no Postgres real com o papel erp_worker, dentro de uma transacao que termina em ROLLBACK
 * (nada fica gravado, nenhum e-mail sai). Uso: npx tsx modules/folha/tests/prova-job-pg.ts <competencia_id conferida>
 */
import 'dotenv/config';
import pg from 'pg';
import { contextoPg } from '../api/compartilhado/efeitos-pg.ts';
import { TIPO_JOB_FECHAMENTO } from '../api/competencia/use-case/fechar-competencia.ts';
import { casosDeUso } from '../api/fabrica.ts';
import handlers from '../worker/index.ts';

const id = process.argv[2]!;
const e = process.env;
const dono = new pg.Client({ host: e.PGHOST, port: Number(e.PGPORT), database: e.ERP_DB_NAME, user: e.ERP_DB_OWNER, password: e.ERP_DB_OWNER_PASSWORD });
await dono.connect();
const esc = (await dono.query('SELECT tenant_id, workspace_id FROM folha_competencias WHERE id = $1', [id])).rows[0];
await dono.end();
const pool = new pg.Pool({ host: e.PGHOST, port: Number(e.PGPORT), database: e.ERP_DB_NAME, user: e.ERP_DB_WORKER_USER, password: e.ERP_DB_WORKER_PASSWORD, max: 1 });
const c = await pool.connect();
try {
  await c.query('BEGIN');
  console.log('papel:', (await c.query('SELECT current_user AS u')).rows[0].u);
  await c.query("SELECT set_config('app.tenant_id', $1, true), set_config('app.workspace_id', $2, true)", [esc.tenant_id, esc.workspace_id]);
  const sol = await casosDeUso(c).solicitarFechamento.execute(contextoPg(c, { tipo: 'sistema', id: null }), { id });
  console.log('SolicitarFechamento:', sol.ok ? 'ok' : JSON.stringify(sol.erros));
  const job = (await c.query('SELECT tipo, payload FROM outbox WHERE id = $1', [sol.ok ? sol.valor.job_id : null])).rows[0];
  console.log('outbox job:', job?.tipo, JSON.stringify(job?.payload));
  await handlers[TIPO_JOB_FECHAMENTO]!({ outboxId: 'prova', tenantId: esc.tenant_id, workspaceId: esc.workspace_id, tipo: TIPO_JOB_FECHAMENTO, payload: job.payload }, c);
  const comp = (await c.query('SELECT estado, qtd_holerites, total_custo_centavos::float8 AS custo, fechada_em IS NOT NULL AS tem_data FROM folha_competencias WHERE id = $1', [id])).rows[0];
  console.log('competencia depois do job:', JSON.stringify(comp));
  const hol = (await c.query("SELECT estado, envio_estado, count(*)::int AS n FROM folha_holerites WHERE competencia_id = $1 AND deleted_at IS NULL GROUP BY 1, 2", [id])).rows;
  console.log('holerites:', JSON.stringify(hol));
  const rat = (await c.query('SELECT sum(custo_centavos)::float8 AS soma, count(*)::int AS centros FROM folha_rateios WHERE competencia_id = $1 AND deleted_at IS NULL', [id])).rows[0];
  console.log('rateio:', JSON.stringify(rat), 'soma = custo da competencia:', rat.soma === comp.custo);
  const emails = (await c.query("SELECT count(*)::int AS n FROM emails WHERE template = 'aviso' AND dados->>'holerite_id' IN (SELECT id::text FROM folha_holerites WHERE competencia_id = $1)", [id])).rows[0];
  console.log('e-mails de holerite na fila (emails + outbox email.enviar):', emails.n);
  const ev = (await c.query("SELECT payload->'dados'->>'competencia' AS comp, jsonb_array_length(payload->'dados'->'lancamentos') AS lanc FROM outbox WHERE tipo = 'evento' AND payload->>'evento' = 'folha.fechada' ORDER BY created_at DESC LIMIT 1")).rows[0];
  console.log('evento folha.fechada na outbox:', JSON.stringify(ev));
  const aud = (await c.query("SELECT acao FROM auditoria WHERE entidade = 'folha_competencias' AND entidade_id = $1 ORDER BY created_at", [id])).rows.map((x) => x.acao);
  console.log('trilha de auditoria:', aud.join(' > '));
} finally {
  await c.query('ROLLBACK');
  console.log('ROLLBACK feito');
  c.release();
  await pool.end();
}
