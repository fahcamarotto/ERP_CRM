/**
 * Testes do modulo Folha (M8) com repositorios em memoria.
 * Rodar: node --import tsx --test modules/folha/tests/*.test.ts
 */
import assert from 'node:assert/strict';
import { describe, it } from 'node:test';
import { Beneficio } from '../api/beneficio/model/beneficio.ts';
import { ConcederBeneficio, EditarBeneficio, EncerrarBeneficio } from '../api/beneficio/use-case/beneficios.ts';
import { Dinheiro } from '../api/compartilhado/dinheiro.ts';
import { Competencia, normalizarMes, ratear } from '../api/competencia/model/competencia.ts';
import { AbrirCompetencia, CalcularCompetencia, ConferirCompetencia, ReabrirCompetencia } from '../api/competencia/use-case/competencias.ts';
import { ProcessarFechamento, SolicitarFechamento, TIPO_JOB_FECHAMENTO } from '../api/competencia/use-case/fechar-competencia.ts';
import { DefinirCentroDepartamento, LancarVariavel } from '../api/competencia/use-case/variaveis-centros.ts';
import { EventoFolha } from '../api/evento/model/evento-folha.ts';
import { ArquivarEventoFolha, CriarEventoFolha } from '../api/evento/use-case/eventos.ts';
import { Holerite } from '../api/holerite/model/holerite.ts';
import { gerarPdfHolerite } from '../api/holerite/model/pdf.ts';
import { calcularInss, calcularIrrf } from '../api/holerite/model/tabelas.ts';
import { EnviarHolerite } from '../api/holerite/use-case/enviar-holerite.ts';
import { BeneficiosMemoria, contexto, EventosMemoria, FolhaMemoria } from './memoria.ts';

const F1 = '11111111-1111-4111-8111-111111111111';
const F2 = '22222222-2222-4222-8222-222222222222';
const FUNCAO = '33333333-3333-4333-8333-333333333333';
const DEP = '44444444-4444-4444-8444-444444444444';
const CC = '55555555-5555-4555-8555-555555555555';

function eventosPadrao() {
  return [
    EventoFolha.create({ codigo: 'INSS', nome: 'INSS', natureza: 'desconto', recorrencia: 'fixo', calculo: 'tabela_inss', tipos_contrato: ['clt'] }),
    EventoFolha.create({ codigo: 'IRRF', nome: 'IRRF', natureza: 'desconto', recorrencia: 'fixo', calculo: 'tabela_irrf', tipos_contrato: ['clt'] }),
    EventoFolha.create({ codigo: 'FGTS', nome: 'FGTS', natureza: 'encargo', recorrencia: 'fixo', calculo: 'percentual', percentual: 8, tipos_contrato: ['clt'] }),
    EventoFolha.create({ codigo: 'HE50', nome: 'Hora extra', natureza: 'provento', recorrencia: 'variavel', calculo: 'valor' }),
  ];
}

function montarFolha() {
  const m = new FolhaMemoria();
  m.base = [
    { funcionario_id: F1, nome: 'Ana', email: 'ana@x.demo', matricula: '001', departamento_id: DEP, funcao_id: FUNCAO, centro_custo_id: null, tipo_contrato: 'clt', salario_centavos: 300000, moeda: 'BRL' },
    { funcionario_id: F2, nome: 'Bia', email: null, matricula: '002', departamento_id: null, funcao_id: null, centro_custo_id: null, tipo_contrato: 'estagio', salario_centavos: 150000, moeda: 'BRL' },
  ];
  m.eventos = eventosPadrao();
  m.beneficios = [Beneficio.create({ nome: 'VR', tipo: 'vale_refeicao', abrangencia: 'funcao', funcao_id: FUNCAO, valor_empresa_centavos: 50000, desconto_funcionario_centavos: 2500, inicio: '2026-01-01' })];
  m.departamentos.add(DEP);
  m.centrosCusto.add(CC);
  const repo = m;
  return {
    m,
    abrir: new AbrirCompetencia({ repo }),
    calcular: new CalcularCompetencia({ repo, base: m, holerites: m, relogio: m }),
    conferir: new ConferirCompetencia({ repo, relogio: m }),
    reabrir: new ReabrirCompetencia({ repo }),
    solicitar: new SolicitarFechamento({ repo, fila: m }),
    processar: new ProcessarFechamento({ repo, holerites: m, rateios: m, correio: m, relogio: m }),
    lancar: new LancarVariavel({ repo, variaveis: m, refs: m }),
    centro: new DefinirCentroDepartamento({ centros: m, refs: m }),
  };
}

describe('objetos de valor e tabelas', () => {
  it('Dinheiro aceita centavos inteiros e recusa float, negativo e moeda ruim', () => {
    assert.equal(Dinheiro.create(1050).centavos, 1050);
    assert.equal(Dinheiro.tryCreate(10.5).ok, false);
    assert.equal(Dinheiro.tryCreate(-1).ok, false);
    assert.equal(Dinheiro.tryCreate(100, 'reais').ok, false);
    assert.throws(() => Dinheiro.create(-5));
  });

  it('INSS progressivo 2026 e limitado ao teto', () => {
    assert.equal(calcularInss(162100), 12158);
    assert.equal(calcularInss(300000), 24860); // 121,575 + 115,3656 (9%) + 11,6592 (12%)
    assert.equal(calcularInss(5_000_000), calcularInss(847555));
  });

  it('IRRF zera ate R$ 5.000 pelo redutor e cobra acima de R$ 7.350', () => {
    assert.equal(calcularIrrf(500000, calcularInss(500000)), 0);
    assert.ok(calcularIrrf(1_000_000, calcularInss(1_000_000)) > 0);
    const parcial = calcularIrrf(600000, calcularInss(600000));
    assert.ok(parcial > 0 && parcial < calcularIrrf(1_000_000, calcularInss(1_000_000)));
  });

  it('normalizarMes aceita AAAA-MM e recusa mes 13', () => {
    assert.equal(normalizarMes('2026-10'), '2026-10-01');
    assert.equal(normalizarMes('2026-13'), null);
  });
});

describe('entidades', () => {
  it('Beneficio.tryCreate acumula erros e create lanca', () => {
    const r = Beneficio.tryCreate({ nome: 'X', tipo: 'vale_refeicao', abrangencia: 'funcao', funcionario_id: F1, inicio: '2026-13-01', valor_empresa_centavos: 1.5 });
    assert.equal(r.ok, false);
    if (!r.ok) {
      const codigos = r.erros.map((e) => e.codigo);
      for (const c of ['nome_invalido', 'alvo_invalido', 'valor_invalido', 'data_invalida']) assert.ok(codigos.includes(c), c);
    }
    assert.throws(() => Beneficio.create({ nome: 'VR', tipo: 'vale_refeicao', abrangencia: 'funcionario', inicio: '2026-01-01', valor_empresa_centavos: 100 }));
  });

  it('editar devolve clone sem mutar o original', () => {
    const b = Beneficio.create({ nome: 'VR', tipo: 'vale_refeicao', abrangencia: 'funcionario', funcionario_id: F1, inicio: '2026-01-01', valor_empresa_centavos: 100 });
    const r = b.editar({ valor_empresa_centavos: 200 });
    assert.ok(r.ok);
    assert.equal(b.paraDados().valor_empresa_centavos, 100);
    if (r.ok) assert.equal(r.valor.paraDados().valor_empresa_centavos, 200);
  });

  it('EventoFolha recusa tabela de INSS como provento e variavel com funcionario', () => {
    assert.equal(EventoFolha.tryCreate({ codigo: 'X1', nome: 'Errado', natureza: 'provento', recorrencia: 'fixo', calculo: 'tabela_inss' }).ok, false);
    assert.equal(EventoFolha.tryCreate({ codigo: 'X2', nome: 'Errado', natureza: 'provento', recorrencia: 'variavel', calculo: 'valor', funcionario_id: F1 }).ok, false);
    assert.equal(EventoFolha.create({ codigo: 'he50', nome: 'HE', natureza: 'provento', recorrencia: 'variavel', calculo: 'valor' }).codigo, 'HE50');
  });

  it('Competencia: cada transicao invalida da maquina devolve transicao_invalida', () => {
    const c = Competencia.create({ mes: '2026-10' });
    for (const r of [c.reabrir(), c.iniciarFechamento('j'), c.concluirFechamento('x'), c.conferir(null, 'x')]) {
      assert.equal(r.ok, false);
      if (!r.ok) assert.equal(r.erros[0]!.codigo, 'transicao_invalida');
    }
    const fechada = Competencia.reidratar({ ...c.paraDados(), estado: 'fechada' });
    assert.equal(fechada.aplicarCalculo({ total_proventos_centavos: 0, total_descontos_centavos: 0, total_encargos_centavos: 0, total_beneficios_centavos: 0, total_liquido_centavos: 0, total_custo_centavos: 0, qtd_holerites: 0 }, 'x').ok, false);
    assert.equal(fechada.editar({ observacoes: 'x' }).ok, false);
  });

  it('Holerite.calcular aplica eventos por tipo de contrato, beneficio da funcao e fecha a conta', () => {
    const r = Holerite.calcular({ competencia_id: 'c', mes: '2026-10-01', base: montarFolha().m.base[0]!, eventos: eventosPadrao(), beneficios: montarFolha().m.beneficios, variaveis: [] });
    assert.ok(r.ok);
    if (!r.ok) return;
    const d = r.valor.paraDados();
    assert.equal(d.proventos_centavos, 300000);
    assert.equal(d.liquido_centavos, d.proventos_centavos - d.descontos_centavos);
    assert.equal(d.custo_centavos, d.proventos_centavos + d.encargos_centavos + d.beneficios_centavos);
    assert.equal(d.encargos_centavos, 24000);
    assert.equal(d.beneficios_centavos, 50000);
    assert.ok(d.itens.some((i) => i.codigo === 'INSS'));
    const estagio = Holerite.calcular({ competencia_id: 'c', mes: '2026-10-01', base: montarFolha().m.base[1]!, eventos: eventosPadrao(), beneficios: [], variaveis: [] });
    assert.ok(estagio.ok && estagio.valor.paraDados().descontos_centavos === 0);
  });

  it('ratear soma custo por centro de custo', () => {
    const r = ratear([
      { centro_custo_id: CC, liquido_centavos: 1, encargos_centavos: 2, beneficios_centavos: 3, custo_centavos: 10 },
      { centro_custo_id: CC, liquido_centavos: 1, encargos_centavos: 2, beneficios_centavos: 3, custo_centavos: 20 },
      { centro_custo_id: null, liquido_centavos: 1, encargos_centavos: 0, beneficios_centavos: 0, custo_centavos: 5 },
    ]);
    assert.deepEqual(r.map((x) => [x.centro_custo_id, x.custo_centavos, x.qtd_funcionarios]), [[CC, 30, 2], [null, 5, 1]]);
  });

  it('PDF do holerite e um PDF valido com xref', () => {
    const r = Holerite.calcular({ competencia_id: 'c', mes: '2026-10-01', base: montarFolha().m.base[0]!, eventos: eventosPadrao(), beneficios: [], variaveis: [] });
    assert.ok(r.ok);
    if (!r.ok) return;
    const pdf = gerarPdfHolerite(r.valor.paraDados(), { empresa: 'Empresa Demo', competencia: '2026-10', departamento: 'Comercial', funcao: 'Vendedora' }).toString('latin1');
    assert.ok(pdf.startsWith('%PDF-1.4'));
    assert.ok(pdf.trimEnd().endsWith('%%EOF'));
    const xref = Number(/startxref\n(\d+)/.exec(pdf)![1]);
    assert.equal(pdf.slice(xref, xref + 4), 'xref');
    assert.ok(pdf.includes('Valor liquido'));
  });
});

describe('casos de uso de beneficio e evento', () => {
  it('ConcederBeneficio grava auditoria; funcao inexistente falha; EncerrarBeneficio duas vezes e transicao invalida', async () => {
    const repo = new BeneficiosMemoria();
    repo.funcoes.add(FUNCAO);
    const ctx = contexto();
    const r = await new ConcederBeneficio({ repo, refs: repo }).execute(ctx, { nome: 'Plano', tipo: 'plano_saude', abrangencia: 'funcao', funcao_id: FUNCAO, valor_empresa_centavos: 40000, inicio: '2026-01-01' });
    assert.ok(r.ok);
    assert.equal(ctx.efeitos.auditoria[0]!.acao, 'beneficio.conceder');
    const ruim = await new ConcederBeneficio({ repo, refs: repo }).execute(ctx, { nome: 'Plano', tipo: 'plano_saude', abrangencia: 'funcao', funcao_id: F1, valor_empresa_centavos: 40000, inicio: '2026-01-01' });
    assert.equal(!ruim.ok && ruim.erros[0]!.codigo, 'funcao_invalida');
    if (!r.ok) return;
    const enc = new EncerrarBeneficio({ repo });
    assert.ok((await enc.execute(ctx, { id: r.valor.id, fim: '2026-06-30' })).ok);
    const de_novo = await enc.execute(ctx, { id: r.valor.id, fim: '2026-07-31' });
    assert.equal(!de_novo.ok && de_novo.erros[0]!.codigo, 'transicao_invalida');
    const editar = await new EditarBeneficio({ repo, refs: repo }).execute(ctx, { id: 'nao-existe', nome: 'x' });
    assert.equal(!editar.ok && editar.erros[0]!.codigo, 'nao_encontrado');
  });

  it('CriarEventoFolha recusa codigo repetido com conflito; arquivar duas vezes e invalido', async () => {
    const repo = new EventosMemoria();
    const ctx = contexto();
    const criar = new CriarEventoFolha({ repo, refs: repo });
    const r = await criar.execute(ctx, { codigo: 'BONUS', nome: 'Bonus', natureza: 'provento', recorrencia: 'variavel', calculo: 'valor' });
    assert.ok(r.ok);
    const dup = await criar.execute(ctx, { codigo: 'bonus', nome: 'Outro', natureza: 'provento', recorrencia: 'variavel', calculo: 'valor' });
    assert.equal(!dup.ok && dup.erros[0]!.codigo, 'conflito');
    if (!r.ok) return;
    const arq = new ArquivarEventoFolha({ repo });
    assert.ok((await arq.execute(ctx, { id: r.valor.id, arquivar: true })).ok);
    const r2 = await arq.execute(ctx, { id: r.valor.id, arquivar: true });
    assert.equal(!r2.ok && r2.erros[0]!.codigo, 'transicao_invalida');
  });
});

describe('ciclo da competencia (caso de uso principal)', () => {
  it('abrir, lancar variavel, calcular, conferir, fechar em job, rateio, e-mail e folha.fechada', async () => {
    const s = montarFolha();
    const ctx = contexto();
    assert.ok((await s.centro.execute(ctx, { departamento_id: DEP, centro_custo_id: CC })).ok);
    const ab = await s.abrir.execute(ctx, { mes: '2026-10', pagamento: '2026-11-05' });
    assert.ok(ab.ok);
    if (!ab.ok) return;
    const id = ab.valor.id;
    const dup = await s.abrir.execute(ctx, { mes: '2026-10-01' });
    assert.equal(!dup.ok && dup.erros[0]!.codigo, 'conflito');

    const he = s.m.eventos.find((e) => e.codigo === 'HE50')!;
    assert.ok((await s.lancar.execute(ctx, { competencia_id: id, funcionario_id: F1, evento_id: he.id, valor_centavos: 25000, referencia: '10h' })).ok);
    const lancRuim = await s.lancar.execute(ctx, { competencia_id: id, funcionario_id: F1, evento_id: s.m.eventos[0]!.id, valor_centavos: 100 });
    assert.equal(!lancRuim.ok && lancRuim.erros[0]!.codigo, 'evento_invalido');

    const calc = await s.calcular.execute(ctx, { id });
    assert.ok(calc.ok);
    assert.equal(calc.ok && calc.valor.qtd_holerites, 2);
    assert.ok(ctx.efeitos.eventos.some((e) => e.evento === 'folha.calculada'));
    const ana = [...s.m.holerites.values()].find((h) => h.funcionario_id === F1 && !h.deleted)!;
    assert.equal(ana.proventos_centavos, 325000);
    assert.equal(ana.centro_custo_id, CC);

    // Variavel nova em competencia calculada volta para aberta; recalcula
    assert.ok((await s.lancar.execute(ctx, { competencia_id: id, funcionario_id: F2, evento_id: he.id, valor_centavos: 1000 })).ok);
    assert.equal((await s.m.obterPorId(id))!.estado, 'aberta');
    assert.ok((await s.calcular.execute(ctx, { id })).ok);
    assert.equal([...s.m.holerites.values()].filter((h) => !h.deleted).length, 2);

    const fecharCedo = await s.solicitar.execute(ctx, { id });
    assert.equal(!fecharCedo.ok && fecharCedo.erros[0]!.codigo, 'transicao_invalida');
    assert.ok((await s.conferir.execute(ctx, { id })).ok);
    const sol = await s.solicitar.execute(ctx, { id });
    assert.ok(sol.ok);
    assert.equal(s.m.jobs[0]!.tipo, TIPO_JOB_FECHAMENTO);
    assert.equal((await s.m.obterPorId(id))!.estado, 'fechando');

    const job = await s.processar.execute(contexto(), { competencia_id: id });
    assert.ok(job.ok);
    assert.deepEqual(job.ok && job.valor, { holerites: 2, enviados: 1 });
    const final = (await s.m.obterPorId(id))!.paraDados();
    assert.equal(final.estado, 'fechada');
    const rateio = s.m.rateios.get(id)!;
    assert.equal(rateio.reduce((a, r) => a + r.custo_centavos, 0), final.total_custo_centavos);
    assert.ok(rateio.some((r) => r.centro_custo_id === CC));
    assert.equal(s.m.emails.length, 1);
    const hs = [...s.m.holerites.values()].filter((h) => !h.deleted);
    assert.ok(hs.every((h) => h.estado === 'fechado'));
    assert.deepEqual(hs.map((h) => h.envio_estado).sort(), ['na_fila', 'sem_email']);

    // Reprocessar o job e idempotente; reabrir competencia fechada e invalido
    const de_novo = await s.processar.execute(contexto(), { competencia_id: id });
    assert.deepEqual(de_novo.ok && de_novo.valor, { holerites: 0, enviados: 0 });
    const reab = await s.reabrir.execute(ctx, { id });
    assert.equal(!reab.ok && reab.erros[0]!.codigo, 'transicao_invalida');
    assert.equal((await s.lancar.execute(ctx, { competencia_id: id, funcionario_id: F1, evento_id: he.id, valor_centavos: 1 })).ok, false);

    // Reenvio do holerite: com e-mail vai para a fila; sem e-mail falha com sem_email
    const enviar = new EnviarHolerite({ holerites: s.m, correio: s.m, relogio: s.m, competenciaDe: async () => '2026-10-01' });
    assert.ok((await enviar.execute(ctx, { id: hs.find((h) => h.funcionario_id === F1)!.id })).ok);
    const bia = hs.find((h) => h.funcionario_id === F2)!;
    const semEmail = await enviar.execute(ctx, { id: bia.id });
    assert.equal(!semEmail.ok && semEmail.erros[0]!.codigo, 'sem_email');
  });

  it('job de fechamento: linha boa publica folha.fechada com lancamentos por centro; competencia sem holerites volta para conferida', async () => {
    const s = montarFolha();
    const ctx = contexto();
    const ab = await s.abrir.execute(ctx, { mes: '2026-09' });
    assert.ok(ab.ok);
    if (!ab.ok) return;
    await s.calcular.execute(ctx, { id: ab.valor.id });
    await s.conferir.execute(ctx, { id: ab.valor.id });
    await s.solicitar.execute(ctx, { id: ab.valor.id });
    const ctxJob = contexto();
    assert.ok((await s.processar.execute(ctxJob, { competencia_id: ab.valor.id })).ok);
    const ev = ctxJob.efeitos.eventos.find((e) => e.evento === 'folha.fechada')!;
    assert.equal(ev.dados.competencia, '2026-09');
    assert.ok(Array.isArray(ev.dados.lancamentos) && (ev.dados.lancamentos as unknown[]).length > 0);
    assert.ok(ctxJob.efeitos.auditoria.some((a) => a.acao === 'competencia.fechar'));

    // Competencia em fechando sem holerites (linha ruim): falha registrada, estado volta para conferida
    const vazia = Competencia.reidratar({ ...Competencia.create({ mes: '2026-07' }).paraDados(), estado: 'fechando' });
    await s.m.inserir(vazia);
    const r = await s.processar.execute(contexto(), { competencia_id: vazia.id });
    assert.equal(!r.ok && r.erros[0]!.codigo, 'sem_holerites');
    const depois = (await s.m.obterPorId(vazia.id))!.paraDados();
    assert.equal(depois.estado, 'conferida');
    assert.ok(depois.erro);
  });

  it('calcular sem funcionarios falha e competencia inexistente e nao_encontrado', async () => {
    const s = montarFolha();
    s.m.base = [];
    const ctx = contexto();
    const ab = await s.abrir.execute(ctx, { mes: '2026-08' });
    assert.ok(ab.ok);
    if (!ab.ok) return;
    const r = await s.calcular.execute(ctx, { id: ab.valor.id });
    assert.equal(!r.ok && r.erros[0]!.codigo, 'sem_funcionarios');
    const n = await s.calcular.execute(ctx, { id: 'x' });
    assert.equal(!n.ok && n.erros[0]!.codigo, 'nao_encontrado');
    const centro = await s.centro.execute(ctx, { departamento_id: 'outro', centro_custo_id: CC });
    assert.equal(!centro.ok && centro.erros[0]!.codigo, 'departamento_invalido');
  });
});
