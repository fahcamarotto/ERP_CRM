/**
 * Plugin do modulo Beneficios e folha (M8), registrado sozinho com prefixo /api/v1/folha.
 * Importar ./tools.ts registra as @tool (MCP e REST) no carregamento.
 */
import type { FastifyPluginAsync } from '@erp/api/sdk';
import './tools.ts';
import { rotasBeneficio } from './beneficio/routes.ts';
import { rotasCompetencia } from './competencia/routes.ts';
import { rotasEvento } from './evento/routes.ts';
import { rotasHolerite } from './holerite/routes.ts';

const plugin: FastifyPluginAsync = async (app) => {
  rotasBeneficio(app);
  rotasEvento(app);
  rotasCompetencia(app);
  rotasHolerite(app);
};

export default plugin;
