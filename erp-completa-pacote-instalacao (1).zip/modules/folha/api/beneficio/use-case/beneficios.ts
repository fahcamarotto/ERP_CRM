/** Casos de uso do Beneficio (M8.1): ConcederBeneficio, EditarBeneficio, EncerrarBeneficio e ExcluirBeneficio. */
import type { ContextoCaso } from '../../compartilhado/efeitos.ts';
import { erroDe, fail, ok, okVazio, type ErroDominio, type Result } from '../../compartilhado/result.ts';
import { Beneficio, type DadosBeneficio } from '../model/beneficio.ts';
import type { ConsultarReferenciasBeneficio, ExcluirBeneficio as PortaExcluir, GravarBeneficio, ObterBeneficio } from '../model/portas.ts';

const TABELA = 'folha_beneficios';

export interface DepsBeneficio {
  repo: ObterBeneficio & GravarBeneficio;
  refs: ConsultarReferenciasBeneficio;
}

async function conferir(refs: ConsultarReferenciasBeneficio, b: Beneficio, anterior?: Beneficio): Promise<ErroDominio[]> {
  const d = b.paraDados();
  const a = anterior?.paraDados();
  if (d.funcionario_id && d.funcionario_id !== a?.funcionario_id && !(await refs.funcionarioAtivo(d.funcionario_id))) {
    return [erroDe('funcionario_invalido', 'Funcionario nao encontrado ou desligado', 'funcionario_id')];
  }
  if (d.funcao_id && d.funcao_id !== a?.funcao_id && !(await refs.funcaoAtiva(d.funcao_id))) {
    return [erroDe('funcao_invalida', 'Funcao nao encontrada ou arquivada', 'funcao_id')];
  }
  return [];
}

export class ConcederBeneficio {
  constructor(private readonly deps: DepsBeneficio) {}
  async execute(ctx: ContextoCaso, e: DadosBeneficio): Promise<Result<{ id: string }>> {
    const r = Beneficio.tryCreate(e);
    if (!r.ok) return r;
    const erros = await conferir(this.deps.refs, r.valor);
    if (erros.length) return fail(...erros);
    await this.deps.repo.inserir(r.valor);
    const d = r.valor.paraDados();
    await ctx.efeitos.auditar('beneficio.conceder', TABELA, d.id, undefined, d);
    return ok({ id: d.id });
  }
}

export class EditarBeneficio {
  constructor(private readonly deps: DepsBeneficio) {}
  async execute(ctx: ContextoCaso, e: { id: string } & Partial<DadosBeneficio>): Promise<Result<void>> {
    const { id, ...mud } = e;
    const atual = await this.deps.repo.obterPorId(id);
    if (!atual) return fail(erroDe('nao_encontrado', 'Beneficio nao encontrado'));
    const r = atual.editar(mud);
    if (!r.ok) return r;
    const erros = await conferir(this.deps.refs, r.valor, atual);
    if (erros.length) return fail(...erros);
    await this.deps.repo.atualizar(r.valor);
    const antes = atual.paraDados() as unknown as Record<string, unknown>;
    const depois = r.valor.paraDados() as unknown as Record<string, unknown>;
    await ctx.efeitos.historico(TABELA, id, antes, depois);
    await ctx.efeitos.auditar('beneficio.editar', TABELA, id, antes, depois);
    return okVazio();
  }
}

export class EncerrarBeneficio {
  constructor(private readonly deps: { repo: ObterBeneficio & GravarBeneficio }) {}
  async execute(ctx: ContextoCaso, e: { id: string; fim: string }): Promise<Result<void>> {
    const atual = await this.deps.repo.obterPorId(e.id);
    if (!atual) return fail(erroDe('nao_encontrado', 'Beneficio nao encontrado'));
    const r = atual.encerrar(e.fim);
    if (!r.ok) return r;
    await this.deps.repo.atualizar(r.valor);
    await ctx.efeitos.historico(TABELA, e.id, { estado: atual.estado }, { estado: 'encerrado', fim: e.fim });
    await ctx.efeitos.auditar('beneficio.encerrar', TABELA, e.id, { estado: atual.estado }, { estado: 'encerrado', fim: e.fim });
    return okVazio();
  }
}

export class ExcluirBeneficio {
  constructor(private readonly deps: { repo: ObterBeneficio & PortaExcluir }) {}
  async execute(ctx: ContextoCaso, e: { id: string }): Promise<Result<void>> {
    const atual = await this.deps.repo.obterPorId(e.id);
    if (!atual) return fail(erroDe('nao_encontrado', 'Beneficio nao encontrado'));
    await this.deps.repo.excluir(e.id);
    await ctx.efeitos.auditar('beneficio.excluir', TABELA, e.id, atual.paraDados(), undefined);
    return okVazio();
  }
}
