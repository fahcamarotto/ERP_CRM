/** Consultas de leitura do Beneficio: lista com nome do funcionario ou da funcao (tabelas publicadas do Pessoas). */
import type pg from 'pg';
import { decodificarCursor, pagina } from '../../compartilhado/cursor.ts';

const RESUMO = `b.id, b.nome, b.tipo, b.abrangencia, b.funcionario_id, f.nome AS funcionario_nome, b.funcao_id, fn.nome AS funcao_nome,
  b.valor_empresa_centavos::float8 AS valor_empresa_centavos, b.desconto_funcionario_centavos::float8 AS desconto_funcionario_centavos,
  b.moeda, to_char(b.inicio, 'YYYY-MM-DD') AS inicio, to_char(b.fim, 'YYYY-MM-DD') AS fim, b.estado, b.observacoes, b.extras,
  b.created_at, b.updated_at`;

const JUNCOES = `FROM folha_beneficios b
  LEFT JOIN pessoas_funcionarios f ON f.id = b.funcionario_id
  LEFT JOIN pessoas_funcoes fn ON fn.id = b.funcao_id`;

export interface FiltroBeneficios {
  estado?: string;
  funcionario_id?: string;
  funcao_id?: string;
  busca?: string;
  limite?: number;
  cursor?: string;
}

export async function listarBeneficios(c: pg.PoolClient, f: FiltroBeneficios) {
  const lim = Math.min(Math.max(f.limite ?? 50, 1), 200);
  const cur = decodificarCursor(f.cursor);
  const r = await c.query(
    `SELECT ${RESUMO} ${JUNCOES}
     WHERE b.deleted_at IS NULL AND ($1::text IS NULL OR b.estado = $1) AND ($2::uuid IS NULL OR b.funcionario_id = $2)
       AND ($3::uuid IS NULL OR b.funcao_id = $3)
       AND ($4::text IS NULL OR b.nome ILIKE '%' || $4 || '%' OR f.nome ILIKE '%' || $4 || '%' OR fn.nome ILIKE '%' || $4 || '%')
       AND ($5::timestamptz IS NULL OR (b.created_at, b.id) > ($5::timestamptz, $6::uuid))
     ORDER BY b.created_at, b.id LIMIT $7`,
    [f.estado ?? null, f.funcionario_id ?? null, f.funcao_id ?? null, f.busca?.trim() || null, cur?.[0] ?? null, cur?.[1] ?? null, lim + 1],
  );
  return pagina(r.rows, lim);
}

export async function obterBeneficio(c: pg.PoolClient, id: string) {
  return (await c.query(`SELECT ${RESUMO} ${JUNCOES} WHERE b.id = $1 AND b.deleted_at IS NULL`, [id])).rows[0] ?? null;
}
