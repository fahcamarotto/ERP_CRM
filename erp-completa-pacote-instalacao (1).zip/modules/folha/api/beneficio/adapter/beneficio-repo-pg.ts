/** Adaptador Postgres das portas do agregado Beneficio (RLS restringe ao workspace da sessao). */
import type pg from 'pg';
import { Beneficio, type BeneficioDados } from '../model/beneficio.ts';
import type { ConsultarReferenciasBeneficio, ExcluirBeneficio, GravarBeneficio, ObterBeneficio } from '../model/portas.ts';

export const COLUNAS_BENEFICIO = `id, nome, tipo, abrangencia, funcionario_id, funcao_id, valor_empresa_centavos::float8 AS valor_empresa_centavos,
  desconto_funcionario_centavos::float8 AS desconto_funcionario_centavos, moeda, to_char(inicio, 'YYYY-MM-DD') AS inicio,
  to_char(fim, 'YYYY-MM-DD') AS fim, estado, observacoes, extras`;

export class BeneficioRepoPg implements ObterBeneficio, GravarBeneficio, ExcluirBeneficio, ConsultarReferenciasBeneficio {
  constructor(private readonly c: pg.PoolClient) {}

  async obterPorId(id: string): Promise<Beneficio | null> {
    const r = await this.c.query(`SELECT ${COLUNAS_BENEFICIO} FROM folha_beneficios WHERE id = $1 AND deleted_at IS NULL`, [id]);
    return r.rows[0] ? Beneficio.reidratar(r.rows[0] as BeneficioDados) : null;
  }

  /** Beneficios ativos (para o calculo da competencia). */
  async ativos(): Promise<Beneficio[]> {
    const r = await this.c.query(`SELECT ${COLUNAS_BENEFICIO} FROM folha_beneficios WHERE estado = 'ativo' AND deleted_at IS NULL ORDER BY created_at, id`);
    return r.rows.map((x) => Beneficio.reidratar(x as BeneficioDados));
  }

  async inserir(b: Beneficio): Promise<void> {
    const d = b.paraDados();
    await this.c.query(
      `INSERT INTO folha_beneficios (id, nome, tipo, abrangencia, funcionario_id, funcao_id, valor_empresa_centavos, desconto_funcionario_centavos,
         moeda, inicio, fim, estado, observacoes, extras, creator_id)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, nucleo_usuario_atual())`,
      [d.id, d.nome, d.tipo, d.abrangencia, d.funcionario_id, d.funcao_id, d.valor_empresa_centavos, d.desconto_funcionario_centavos,
        d.moeda, d.inicio, d.fim, d.estado, d.observacoes, JSON.stringify(d.extras)],
    );
  }

  async atualizar(b: Beneficio): Promise<void> {
    const d = b.paraDados();
    await this.c.query(
      `UPDATE folha_beneficios SET nome = $2, tipo = $3, abrangencia = $4, funcionario_id = $5, funcao_id = $6, valor_empresa_centavos = $7,
         desconto_funcionario_centavos = $8, moeda = $9, inicio = $10, fim = $11, estado = $12, observacoes = $13, extras = $14
       WHERE id = $1 AND deleted_at IS NULL`,
      [d.id, d.nome, d.tipo, d.abrangencia, d.funcionario_id, d.funcao_id, d.valor_empresa_centavos, d.desconto_funcionario_centavos,
        d.moeda, d.inicio, d.fim, d.estado, d.observacoes, JSON.stringify(d.extras)],
    );
  }

  async excluir(id: string): Promise<void> {
    await this.c.query('UPDATE folha_beneficios SET deleted_at = now() WHERE id = $1 AND deleted_at IS NULL', [id]);
  }

  async funcionarioAtivo(id: string): Promise<boolean> {
    const r = await this.c.query("SELECT 1 FROM pessoas_funcionarios WHERE id = $1 AND deleted_at IS NULL AND estado <> 'desligado'", [id]);
    return (r.rowCount ?? 0) > 0;
  }

  async funcaoAtiva(id: string): Promise<boolean> {
    const r = await this.c.query("SELECT 1 FROM pessoas_funcoes WHERE id = $1 AND deleted_at IS NULL AND estado = 'ativo'", [id]);
    return (r.rowCount ?? 0) > 0;
  }
}
