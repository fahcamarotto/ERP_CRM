/**
 * Entidade Beneficio (M8.1): concedido a um funcionario ou a todos de uma funcao.
 * Custo da empresa e desconto do funcionario em centavos. Imutavel: toda alteracao devolve um clone.
 */
import { randomUUID } from 'node:crypto';
import { Dinheiro } from '../../compartilhado/dinheiro.ts';
import { erroDe, fail, ok, type ErroDominio, type Result } from '../../compartilhado/result.ts';

export const TIPOS_BENEFICIO = ['vale_transporte', 'vale_refeicao', 'vale_alimentacao', 'plano_saude', 'plano_odonto', 'seguro_vida', 'auxilio', 'outro'] as const;
export type TipoBeneficio = (typeof TIPOS_BENEFICIO)[number];
export const ABRANGENCIAS = ['funcionario', 'funcao'] as const;
export type Abrangencia = (typeof ABRANGENCIAS)[number];
export const ESTADOS_BENEFICIO = ['ativo', 'encerrado'] as const;
export type EstadoBeneficio = (typeof ESTADOS_BENEFICIO)[number];

export interface DadosBeneficio {
  nome: string;
  tipo: TipoBeneficio;
  abrangencia: Abrangencia;
  funcionario_id?: string | null;
  funcao_id?: string | null;
  valor_empresa_centavos?: number;
  desconto_funcionario_centavos?: number;
  moeda?: string;
  inicio: string;
  fim?: string | null;
  observacoes?: string | null;
  extras?: Record<string, unknown>;
}

export interface BeneficioDados {
  id: string;
  nome: string;
  tipo: TipoBeneficio;
  abrangencia: Abrangencia;
  funcionario_id: string | null;
  funcao_id: string | null;
  valor_empresa_centavos: number;
  desconto_funcionario_centavos: number;
  moeda: string;
  inicio: string;
  fim: string | null;
  estado: EstadoBeneficio;
  observacoes: string | null;
  extras: Record<string, unknown>;
}

const t = (v?: string | null) => (v ?? '').trim() || null;
const dataValida = (v: string | null) => v !== null && /^\d{4}-\d{2}-\d{2}$/.test(v) && !Number.isNaN(Date.parse(v));

function validar(d: BeneficioDados): ErroDominio[] {
  const e: ErroDominio[] = [];
  if (d.nome.length < 2 || d.nome.length > 120) e.push(erroDe('nome_invalido', 'Nome deve ter de 2 a 120 caracteres', 'nome'));
  if (!TIPOS_BENEFICIO.includes(d.tipo)) e.push(erroDe('tipo_invalido', 'Tipo de beneficio invalido', 'tipo'));
  if (!ABRANGENCIAS.includes(d.abrangencia)) e.push(erroDe('abrangencia_invalida', 'Abrangencia deve ser funcionario ou funcao', 'abrangencia'));
  if (d.abrangencia === 'funcionario' && (!d.funcionario_id || d.funcao_id)) e.push(erroDe('alvo_invalido', 'Beneficio por funcionario exige so o funcionario', 'funcionario_id'));
  if (d.abrangencia === 'funcao' && (!d.funcao_id || d.funcionario_id)) e.push(erroDe('alvo_invalido', 'Beneficio por funcao exige so a funcao', 'funcao_id'));
  for (const [campo, v] of [['valor_empresa_centavos', d.valor_empresa_centavos], ['desconto_funcionario_centavos', d.desconto_funcionario_centavos]] as const) {
    const r = Dinheiro.tryCreate(v, d.moeda, campo);
    if (!r.ok) e.push(...r.erros);
  }
  if (d.valor_empresa_centavos === 0 && d.desconto_funcionario_centavos === 0) e.push(erroDe('valor_invalido', 'Informe o custo da empresa ou o desconto do funcionario', 'valor_empresa_centavos'));
  if (!dataValida(d.inicio)) e.push(erroDe('data_invalida', 'Inicio deve ser AAAA-MM-DD', 'inicio'));
  if (d.fim !== null && !dataValida(d.fim)) e.push(erroDe('data_invalida', 'Fim deve ser AAAA-MM-DD', 'fim'));
  if (d.fim && dataValida(d.inicio) && d.fim < d.inicio) e.push(erroDe('fim_invalido', 'Fim antes do inicio', 'fim'));
  return e;
}

export class Beneficio {
  private constructor(private readonly d: BeneficioDados) {}

  static tryCreate(e: DadosBeneficio, id: string = randomUUID()): Result<Beneficio> {
    const abrangencia = e.abrangencia;
    const d: BeneficioDados = {
      id, nome: (e.nome ?? '').trim(), tipo: e.tipo, abrangencia,
      funcionario_id: abrangencia === 'funcionario' ? t(e.funcionario_id) : null,
      funcao_id: abrangencia === 'funcao' ? t(e.funcao_id) : null,
      valor_empresa_centavos: e.valor_empresa_centavos ?? 0, desconto_funcionario_centavos: e.desconto_funcionario_centavos ?? 0,
      moeda: (t(e.moeda) ?? 'BRL').toUpperCase(), inicio: t(e.inicio) ?? '', fim: t(e.fim), estado: 'ativo',
      observacoes: t(e.observacoes), extras: e.extras ?? {},
    };
    const erros = validar(d);
    return erros.length ? fail(...erros) : ok(new Beneficio(d));
  }

  static create(e: DadosBeneficio, id?: string): Beneficio {
    const r = Beneficio.tryCreate(e, id);
    if (!r.ok) throw new Error(r.erros.map((x) => x.mensagem).join('; '));
    return r.valor;
  }

  static reidratar(d: BeneficioDados): Beneficio {
    return new Beneficio({ ...d, valor_empresa_centavos: Number(d.valor_empresa_centavos), desconto_funcionario_centavos: Number(d.desconto_funcionario_centavos), extras: { ...d.extras } });
  }

  get id(): string { return this.d.id; }
  get estado(): EstadoBeneficio { return this.d.estado; }

  /** Vale na competencia (mes = AAAA-MM-01) se comecou ate o fim do mes e nao terminou antes do inicio dele. */
  vigenteEm(mes: string): boolean {
    const fimMes = fimDoMes(mes);
    return this.d.estado === 'ativo' && this.d.inicio <= fimMes && (this.d.fim === null || this.d.fim >= mes);
  }

  editar(e: Partial<DadosBeneficio>): Result<Beneficio> {
    if (this.d.estado === 'encerrado') return fail(erroDe('transicao_invalida', 'Beneficio encerrado nao pode ser editado'));
    const tem = (k: keyof DadosBeneficio) => e[k] !== undefined;
    const abrangencia = tem('abrangencia') ? e.abrangencia! : this.d.abrangencia;
    const n: BeneficioDados = {
      ...this.d,
      nome: tem('nome') ? (e.nome ?? '').trim() : this.d.nome,
      tipo: tem('tipo') ? e.tipo! : this.d.tipo,
      abrangencia,
      funcionario_id: abrangencia === 'funcionario' ? (tem('funcionario_id') ? t(e.funcionario_id) : this.d.funcionario_id) : null,
      funcao_id: abrangencia === 'funcao' ? (tem('funcao_id') ? t(e.funcao_id) : this.d.funcao_id) : null,
      valor_empresa_centavos: tem('valor_empresa_centavos') ? e.valor_empresa_centavos! : this.d.valor_empresa_centavos,
      desconto_funcionario_centavos: tem('desconto_funcionario_centavos') ? e.desconto_funcionario_centavos! : this.d.desconto_funcionario_centavos,
      moeda: tem('moeda') ? (t(e.moeda) ?? 'BRL').toUpperCase() : this.d.moeda,
      inicio: tem('inicio') ? t(e.inicio) ?? '' : this.d.inicio,
      fim: tem('fim') ? t(e.fim) : this.d.fim,
      observacoes: tem('observacoes') ? t(e.observacoes) : this.d.observacoes,
      extras: tem('extras') ? { ...e.extras } : { ...this.d.extras },
    };
    const erros = validar(n);
    return erros.length ? fail(...erros) : ok(new Beneficio(n));
  }

  /** Encerra o beneficio na data (padrao: fim ja informado ou hoje). */
  encerrar(fim: string): Result<Beneficio> {
    if (this.d.estado === 'encerrado') return fail(erroDe('transicao_invalida', 'Beneficio ja encerrado', 'estado', { permitidas: [] }));
    if (!dataValida(fim) || fim < this.d.inicio) return fail(erroDe('fim_invalido', 'Fim deve ser AAAA-MM-DD e depois do inicio', 'fim'));
    return ok(new Beneficio({ ...this.d, estado: 'encerrado', fim }));
  }

  paraDados(): BeneficioDados {
    return { ...this.d, extras: { ...this.d.extras } };
  }
}

/** Ultimo dia do mes de uma data AAAA-MM-DD. */
export function fimDoMes(mes: string): string {
  const [a, m] = mes.split('-').map(Number);
  const d = new Date(Date.UTC(a!, m!, 0));
  return d.toISOString().slice(0, 10);
}
