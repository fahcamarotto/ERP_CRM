/** Portas do repositorio do agregado Beneficio, segregadas por operacao. */
import type { Beneficio } from './beneficio.ts';

export interface ObterBeneficio {
  obterPorId(id: string): Promise<Beneficio | null>;
}

export interface GravarBeneficio {
  inserir(b: Beneficio): Promise<void>;
  atualizar(b: Beneficio): Promise<void>;
}

export interface ExcluirBeneficio {
  excluir(id: string): Promise<void>;
}

/** Referencias externas (tabelas publicadas do Pessoas). */
export interface ConsultarReferenciasBeneficio {
  funcionarioAtivo(id: string): Promise<boolean>;
  funcaoAtiva(id: string): Promise<boolean>;
}
