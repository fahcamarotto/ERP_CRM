/** Rotas REST do Beneficio fora das tools: ficha, edicao, encerramento e exclusao logica. */
import { esquemaErro, requer, type FastifyInstance } from '@erp/api/sdk';
import { naTransacao, naoEncontrado } from '../borda.ts';
import { exigirOk } from '../compartilhado/result.ts';
import { propsBeneficio, uuid } from '../esquemas.ts';
import type { DadosBeneficio } from './model/beneficio.ts';
import { obterBeneficio } from './query/beneficios.ts';

const tags = ['folha'];
const erros = { 400: esquemaErro, 403: esquemaErro, 404: esquemaErro, 409: esquemaErro };
const paramId = { type: 'object', required: ['id'], properties: { id: uuid } } as const;

export function rotasBeneficio(app: FastifyInstance): void {
  app.get<{ Params: { id: string } }>('/beneficios/:id', {
    preHandler: requer('folha.ver'),
    schema: { tags, summary: 'Ficha do beneficio', params: paramId, response: { 404: esquemaErro } },
  }, (req) => naTransacao(req, async (_, __, c) => (await obterBeneficio(c, req.params.id)) ?? Promise.reject(naoEncontrado('Beneficio nao encontrado'))));

  app.patch<{ Params: { id: string }; Body: Partial<DadosBeneficio> }>('/beneficios/:id', {
    preHandler: requer('folha.editar'),
    schema: { tags, summary: 'Edita beneficio (EditarBeneficio)', params: paramId, body: { type: 'object', additionalProperties: false, properties: propsBeneficio }, response: erros },
  }, (req) => naTransacao(req, async (casos, ctx, c) => {
    exigirOk(await casos.editarBeneficio.execute(ctx, { ...req.body, id: req.params.id }));
    return obterBeneficio(c, req.params.id);
  }));

  app.post<{ Params: { id: string }; Body: { fim: string } }>('/beneficios/:id/encerrar', {
    preHandler: requer('folha.editar'),
    schema: {
      tags, summary: 'Encerra beneficio na data (EncerrarBeneficio)', params: paramId, response: erros,
      body: { type: 'object', additionalProperties: false, required: ['fim'], properties: { fim: { type: 'string', format: 'date' } } },
    },
  }, (req) => naTransacao(req, async (casos, ctx, c) => {
    exigirOk(await casos.encerrarBeneficio.execute(ctx, { id: req.params.id, fim: req.body.fim }));
    return obterBeneficio(c, req.params.id);
  }));

  app.delete<{ Params: { id: string } }>('/beneficios/:id', {
    preHandler: requer('folha.excluir'),
    schema: { tags, summary: 'Exclui beneficio (exclusao logica)', params: paramId, response: { 404: esquemaErro } },
  }, async (req, reply) => {
    await naTransacao(req, async (casos, ctx) => exigirOk(await casos.excluirBeneficio.execute(ctx, { id: req.params.id })));
    return reply.code(204).send();
  });
}
