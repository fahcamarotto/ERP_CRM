/**
 * Composicao do modulo Folha: liga casos de uso aos adaptadores Postgres para um cliente de transacao.
 * Usada pelas rotas, pelas tools, pelo worker e pelo seed. Nao importa Fastify nem o pool do servidor.
 */
import type pg from 'pg';
import { BeneficioRepoPg } from './beneficio/adapter/beneficio-repo-pg.ts';
import { ConcederBeneficio, EditarBeneficio, EncerrarBeneficio, ExcluirBeneficio } from './beneficio/use-case/beneficios.ts';
import { CompetenciaRepoPg, CorreioPg, FilaOutboxPg, relogioSistema } from './competencia/adapter/competencia-repo-pg.ts';
import { AbrirCompetencia, CalcularCompetencia, ConferirCompetencia, EditarCompetencia, ReabrirCompetencia } from './competencia/use-case/competencias.ts';
import { ProcessarFechamento, SolicitarFechamento } from './competencia/use-case/fechar-competencia.ts';
import { DefinirCentroDepartamento, ExcluirVariavel, LancarVariavel } from './competencia/use-case/variaveis-centros.ts';
import { EventoFolhaRepoPg } from './evento/adapter/evento-repo-pg.ts';
import { ArquivarEventoFolha, CriarEventoFolha, EditarEventoFolha } from './evento/use-case/eventos.ts';
import { mesDaCompetencia } from './holerite/query/holerites.ts';
import { EnviarHolerite } from './holerite/use-case/enviar-holerite.ts';

export function casosDeUso(c: pg.PoolClient) {
  const beneficios = new BeneficioRepoPg(c);
  const eventos = new EventoFolhaRepoPg(c);
  const comp = new CompetenciaRepoPg(c);
  const correio = new CorreioPg(c);
  const relogio = relogioSistema;
  return {
    concederBeneficio: new ConcederBeneficio({ repo: beneficios, refs: beneficios }),
    editarBeneficio: new EditarBeneficio({ repo: beneficios, refs: beneficios }),
    encerrarBeneficio: new EncerrarBeneficio({ repo: beneficios }),
    excluirBeneficio: new ExcluirBeneficio({ repo: beneficios }),
    criarEvento: new CriarEventoFolha({ repo: eventos, refs: eventos }),
    editarEvento: new EditarEventoFolha({ repo: eventos, refs: eventos }),
    arquivarEvento: new ArquivarEventoFolha({ repo: eventos }),
    abrirCompetencia: new AbrirCompetencia({ repo: comp }),
    editarCompetencia: new EditarCompetencia({ repo: comp }),
    calcularCompetencia: new CalcularCompetencia({ repo: comp, base: comp, holerites: comp, relogio }),
    conferirCompetencia: new ConferirCompetencia({ repo: comp, relogio }),
    reabrirCompetencia: new ReabrirCompetencia({ repo: comp }),
    solicitarFechamento: new SolicitarFechamento({ repo: comp, fila: new FilaOutboxPg(c) }),
    processarFechamento: new ProcessarFechamento({ repo: comp, holerites: comp, rateios: comp, correio, relogio }),
    lancarVariavel: new LancarVariavel({ repo: comp, variaveis: comp, refs: comp }),
    excluirVariavel: new ExcluirVariavel({ repo: comp, variaveis: comp }),
    definirCentro: new DefinirCentroDepartamento({ centros: comp, refs: comp }),
    enviarHolerite: new EnviarHolerite({ holerites: comp, correio, relogio, competenciaDe: (id) => mesDaCompetencia(c, id) }),
  };
}

export type CasosDeUso = ReturnType<typeof casosDeUso>;
