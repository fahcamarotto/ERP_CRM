/**
 * @tool do modulo Folha (N15): cada chamada vira tool MCP em /mcp e rota REST com o mesmo schema no OpenAPI.
 * Casos de uso principais: beneficios, eventos de folha, competencia (abrir, calcular, conferir, fechar), variaveis e holerites.
 */
import { tool } from '@erp/api/sdk';
import { naoEncontrado } from './borda.ts';
import type { DadosBeneficio } from './beneficio/model/beneficio.ts';
import { listarBeneficios, obterBeneficio } from './beneficio/query/beneficios.ts';
import { contextoPg } from './compartilhado/efeitos-pg.ts';
import { exigirOk } from './compartilhado/result.ts';
import type { DadosCompetencia } from './competencia/model/competencia.ts';
import { listarCompetencias, obterCompetencia } from './competencia/query/competencias.ts';
import { estadosCompetencia, paginacao, propsBeneficio, propsCompetencia, propsEvento, propsVariavel, uuid } from './esquemas.ts';
import type { DadosEventoFolha } from './evento/model/evento-folha.ts';
import { listarEventos, obterEvento } from './evento/query/eventos.ts';
import { casosDeUso } from './fabrica.ts';
import { listarHolerites, obterHolerite } from './holerite/query/holerites.ts';

type Pag = { busca?: string; limite?: number; cursor?: string };

tool<Pag & { estado?: string; funcionario_id?: string; funcao_id?: string }>({
  nome: 'beneficios.listar', modulo: 'folha', titulo: 'Listar beneficios', tipo: 'leitura', permissao: 'folha.ver',
  descricao: 'Lista beneficios (vale transporte, refeicao, plano de saude...) por funcionario ou por funcao, com custo da empresa e desconto do funcionario em centavos.',
  entrada: { type: 'object', properties: { ...paginacao, estado: { type: 'string', enum: ['ativo', 'encerrado'] }, funcionario_id: uuid, funcao_id: uuid } },
  rota: { metodo: 'GET', caminho: '/api/v1/folha/beneficios' },
  executar: ({ c }, a) => listarBeneficios(c, a),
});

tool<DadosBeneficio>({
  nome: 'beneficios.conceder', modulo: 'folha', titulo: 'Conceder beneficio', tipo: 'escrita', permissao: 'folha.criar',
  descricao: 'Concede um beneficio a um funcionario ou a todos de uma funcao, a partir de uma data. Valores em centavos. Grava auditoria.',
  entrada: { type: 'object', required: ['nome', 'tipo', 'abrangencia', 'inicio'], properties: propsBeneficio },
  rota: { metodo: 'POST', caminho: '/api/v1/folha/beneficios' },
  executar: async ({ c, ator, ip }, a) => {
    const { id } = exigirOk(await casosDeUso(c).concederBeneficio.execute(contextoPg(c, ator, ip), a));
    return obterBeneficio(c, id);
  },
});

tool<Pag & { natureza?: string; recorrencia?: string; estado?: 'ativo' | 'arquivado' | 'todos' }>({
  nome: 'eventos_folha.listar', modulo: 'folha', titulo: 'Listar eventos de folha', tipo: 'leitura', permissao: 'folha.ver',
  descricao: 'Lista as rubricas da folha (proventos, descontos e encargos, fixos ou variaveis) com a forma de calculo.',
  entrada: { type: 'object', properties: { ...paginacao, natureza: { type: 'string', enum: ['provento', 'desconto', 'encargo'] }, recorrencia: { type: 'string', enum: ['fixo', 'variavel'] }, estado: { type: 'string', enum: ['ativo', 'arquivado', 'todos'], default: 'ativo' } } },
  rota: { metodo: 'GET', caminho: '/api/v1/folha/eventos' },
  executar: ({ c }, a) => listarEventos(c, a),
});

tool<DadosEventoFolha>({
  nome: 'eventos_folha.criar', modulo: 'folha', titulo: 'Criar evento de folha', tipo: 'escrita', permissao: 'folha.criar',
  descricao: 'Cria rubrica de provento, desconto ou encargo, fixa ou variavel, por valor em centavos, percentual dos proventos ou tabela de INSS ou IRRF. Codigo unico.',
  entrada: { type: 'object', required: ['codigo', 'nome', 'natureza', 'recorrencia', 'calculo'], properties: propsEvento },
  rota: { metodo: 'POST', caminho: '/api/v1/folha/eventos' },
  executar: async ({ c, ator, ip }, a) => {
    const { id } = exigirOk(await casosDeUso(c).criarEvento.execute(contextoPg(c, ator, ip), a));
    return obterEvento(c, id);
  },
});

tool<{ estado?: string; limite?: number; cursor?: string }>({
  nome: 'competencias.listar', modulo: 'folha', titulo: 'Listar competencias', tipo: 'leitura', permissao: 'folha.ver',
  descricao: 'Lista as competencias mensais da folha com estado (aberta, calculada, conferida, fechando, fechada) e totais em centavos.',
  entrada: { type: 'object', properties: { estado: { type: 'string', enum: [...estadosCompetencia] }, limite: paginacao.limite, cursor: paginacao.cursor } },
  rota: { metodo: 'GET', caminho: '/api/v1/folha/competencias' },
  executar: ({ c }, a) => listarCompetencias(c, a),
});

tool<{ id: string }>({
  nome: 'competencias.obter', modulo: 'folha', titulo: 'Obter competencia', tipo: 'leitura', permissao: 'folha.ver',
  descricao: 'Ficha da competencia com totais, rateio por centro de custo (depois do fechamento) e variaveis lancadas.',
  entrada: { type: 'object', required: ['id'], properties: { id: uuid } },
  rota: { metodo: 'GET', caminho: '/api/v1/folha/competencias/:id' },
  executar: async ({ c }, a) => (await obterCompetencia(c, a.id)) ?? Promise.reject(naoEncontrado('Competencia nao encontrada')),
});

tool<DadosCompetencia>({
  nome: 'competencias.abrir', modulo: 'folha', titulo: 'Abrir competencia', tipo: 'escrita', permissao: 'folha.criar',
  descricao: 'Abre a competencia mensal da folha (AAAA-MM), com data de pagamento opcional. Uma por mes.',
  entrada: { type: 'object', required: ['mes'], properties: propsCompetencia },
  rota: { metodo: 'POST', caminho: '/api/v1/folha/competencias' },
  executar: async ({ c, ator, ip }, a) => {
    const { id } = exigirOk(await casosDeUso(c).abrirCompetencia.execute(contextoPg(c, ator, ip), a));
    return obterCompetencia(c, id);
  },
});

tool<{ id: string }>({
  nome: 'competencias.calcular', modulo: 'folha', titulo: 'Calcular folha', tipo: 'escrita', permissao: 'folha.calcular',
  descricao: 'Calcula (ou recalcula) os holerites da competencia: salario do contrato vigente, eventos fixos e variaveis, INSS, IRRF, encargos e beneficios. Publica folha.calculada.',
  entrada: { type: 'object', required: ['id'], properties: { id: uuid } },
  rota: { metodo: 'POST', caminho: '/api/v1/folha/competencias/:id/calcular' },
  executar: async ({ c, ator, ip }, a) => {
    exigirOk(await casosDeUso(c).calcularCompetencia.execute(contextoPg(c, ator, ip), a));
    return obterCompetencia(c, a.id);
  },
});

tool<{ id: string }>({
  nome: 'competencias.conferir', modulo: 'folha', titulo: 'Conferir folha', tipo: 'escrita', permissao: 'folha.calcular',
  descricao: 'Marca a competencia calculada como conferida (libera o fechamento).',
  entrada: { type: 'object', required: ['id'], properties: { id: uuid } },
  rota: { metodo: 'POST', caminho: '/api/v1/folha/competencias/:id/conferir' },
  executar: async ({ c, ator, ip }, a) => {
    exigirOk(await casosDeUso(c).conferirCompetencia.execute(contextoPg(c, ator, ip), a));
    return obterCompetencia(c, a.id);
  },
});

tool<{ id: string }>({
  nome: 'competencias.fechar', modulo: 'folha', titulo: 'Fechar folha', tipo: 'escrita', permissao: 'folha.fechar',
  descricao: 'Fecha a competencia conferida em job na fila: fecha holerites, grava rateio por centro de custo, envia holerites por e-mail e publica folha.fechada. Devolve job_id (consulte jobs.status).',
  entrada: { type: 'object', required: ['id'], properties: { id: uuid } },
  executar: async ({ c, ator, ip }, a) => exigirOk(await casosDeUso(c).solicitarFechamento.execute(contextoPg(c, ator, ip), a)),
});

tool<{ competencia_id: string; funcionario_id: string; evento_id: string; valor_centavos: number; referencia?: string | null }>({
  nome: 'variaveis.lancar', modulo: 'folha', titulo: 'Lancar variavel na competencia', tipo: 'escrita', permissao: 'folha.editar',
  descricao: 'Lanca evento variavel (hora extra, comissao, falta) de um funcionario na competencia aberta ou calculada. Competencia calculada volta para aberta.',
  entrada: { type: 'object', required: ['competencia_id', 'funcionario_id', 'evento_id', 'valor_centavos'], properties: { competencia_id: uuid, ...propsVariavel } },
  rota: { metodo: 'POST', caminho: '/api/v1/folha/competencias/:competencia_id/variaveis' },
  executar: async ({ c, ator, ip }, a) => {
    exigirOk(await casosDeUso(c).lancarVariavel.execute(contextoPg(c, ator, ip), a));
    return obterCompetencia(c, a.competencia_id);
  },
});

tool<Pag & { competencia_id?: string; funcionario_id?: string }>({
  nome: 'holerites.listar', modulo: 'folha', titulo: 'Listar holerites', tipo: 'leitura', permissao: 'folha.ver',
  descricao: 'Lista holerites por competencia ou funcionario com proventos, descontos, liquido e custo em centavos.',
  entrada: { type: 'object', properties: { ...paginacao, competencia_id: uuid, funcionario_id: uuid } },
  rota: { metodo: 'GET', caminho: '/api/v1/folha/holerites' },
  executar: ({ c }, a) => listarHolerites(c, a),
});

tool<{ id: string }>({
  nome: 'holerites.obter', modulo: 'folha', titulo: 'Obter holerite', tipo: 'leitura', permissao: 'folha.ver',
  descricao: 'Holerite completo com itens (codigo, descricao, referencia e valor). PDF em GET /api/v1/folha/holerites/:id/pdf.',
  entrada: { type: 'object', required: ['id'], properties: { id: uuid } },
  rota: { metodo: 'GET', caminho: '/api/v1/folha/holerites/:id' },
  executar: async ({ c }, a) => (await obterHolerite(c, a.id)) ?? Promise.reject(naoEncontrado('Holerite nao encontrado')),
});
