/** Adaptadores Postgres da Competencia, do calculo (leitura publicada do Pessoas), dos holerites, rateios, variaveis e centros. */
import type pg from 'pg';
import { enviarEmail } from '@erp/api/sdk/puro';
import { Beneficio, type BeneficioDados } from '../../beneficio/model/beneficio.ts';
import { COLUNAS_BENEFICIO } from '../../beneficio/adapter/beneficio-repo-pg.ts';
import { COLUNAS_EVENTO } from '../../evento/adapter/evento-repo-pg.ts';
import { EventoFolha, type EventoFolhaDados } from '../../evento/model/evento-folha.ts';
import { Holerite, type BaseFuncionario, type HoleriteDados, type VariavelLancada } from '../../holerite/model/holerite.ts';
import { formatarCentavos } from '../../holerite/model/pdf.ts';
import { Competencia, type CompetenciaDados, type Rateio } from '../model/competencia.ts';
import type {
  BaseCalculo, ConsultarReferenciasFolha, Correio, FilaJobs, GravarCentros, GravarCompetencia, GravarHolerites, GravarRateios,
  GravarVariaveis, ObterCompetencia, ObterHolerite, Relogio,
} from '../model/portas.ts';

const COLUNAS_COMPETENCIA = `id, to_char(mes, 'YYYY-MM-DD') AS mes, to_char(pagamento, 'YYYY-MM-DD') AS pagamento, moeda, estado,
  total_proventos_centavos::float8 AS total_proventos_centavos, total_descontos_centavos::float8 AS total_descontos_centavos,
  total_encargos_centavos::float8 AS total_encargos_centavos, total_beneficios_centavos::float8 AS total_beneficios_centavos,
  total_liquido_centavos::float8 AS total_liquido_centavos, total_custo_centavos::float8 AS total_custo_centavos, qtd_holerites,
  calculada_em, conferida_em, conferida_por, fechada_em, job_id, erro, observacoes`;

export const COLUNAS_HOLERITE = `id, competencia_id, funcionario_id, funcionario_nome, email, matricula, departamento_id, funcao_id, centro_custo_id,
  tipo_contrato, salario_base_centavos::float8 AS salario_base_centavos, proventos_centavos::float8 AS proventos_centavos,
  descontos_centavos::float8 AS descontos_centavos, encargos_centavos::float8 AS encargos_centavos, beneficios_centavos::float8 AS beneficios_centavos,
  liquido_centavos::float8 AS liquido_centavos, custo_centavos::float8 AS custo_centavos, moeda, itens, estado, envio_estado, email_id, enviado_em`;

const iso = (v: unknown) => (v instanceof Date ? v.toISOString() : (v as string | null));

export class CompetenciaRepoPg implements ObterCompetencia, GravarCompetencia, BaseCalculo, GravarHolerites, ObterHolerite, GravarRateios,
  GravarVariaveis, ConsultarReferenciasFolha, GravarCentros {
  constructor(private readonly c: pg.PoolClient) {}

  private reidratar(row: Record<string, unknown>): Competencia {
    return Competencia.reidratar({ ...row, calculada_em: iso(row.calculada_em), conferida_em: iso(row.conferida_em), fechada_em: iso(row.fechada_em) } as unknown as CompetenciaDados);
  }

  async obterPorId(id: string): Promise<Competencia | null> {
    const r = await this.c.query(`SELECT ${COLUNAS_COMPETENCIA} FROM folha_competencias WHERE id = $1 AND deleted_at IS NULL`, [id]);
    return r.rows[0] ? this.reidratar(r.rows[0]) : null;
  }

  async buscarPorMes(mes: string): Promise<Competencia | null> {
    const r = await this.c.query(`SELECT ${COLUNAS_COMPETENCIA} FROM folha_competencias WHERE mes = $1 AND deleted_at IS NULL`, [mes]);
    return r.rows[0] ? this.reidratar(r.rows[0]) : null;
  }

  async inserir(x: Competencia): Promise<void> {
    const d = x.paraDados();
    await this.c.query(
      `INSERT INTO folha_competencias (id, mes, pagamento, moeda, estado, observacoes, creator_id) VALUES ($1, $2, $3, $4, $5, $6, nucleo_usuario_atual())`,
      [d.id, d.mes, d.pagamento, d.moeda, d.estado, d.observacoes],
    );
  }

  async atualizar(x: Competencia): Promise<void> {
    const d = x.paraDados();
    await this.c.query(
      `UPDATE folha_competencias SET pagamento = $2, moeda = $3, estado = $4, total_proventos_centavos = $5, total_descontos_centavos = $6,
         total_encargos_centavos = $7, total_beneficios_centavos = $8, total_liquido_centavos = $9, total_custo_centavos = $10, qtd_holerites = $11,
         calculada_em = $12, conferida_em = $13, conferida_por = $14, fechada_em = $15, job_id = $16, erro = $17, observacoes = $18
       WHERE id = $1 AND deleted_at IS NULL`,
      [d.id, d.pagamento, d.moeda, d.estado, d.total_proventos_centavos, d.total_descontos_centavos, d.total_encargos_centavos,
        d.total_beneficios_centavos, d.total_liquido_centavos, d.total_custo_centavos, d.qtd_holerites, d.calculada_em, d.conferida_em,
        d.conferida_por, d.fechada_em, d.job_id, d.erro, d.observacoes],
    );
  }

  // BaseCalculo: consulta publicada do Pessoas (docs/CONTRATOS.md 7.1.7) mais o centro de custo do departamento.
  async funcionariosComContrato(): Promise<BaseFuncionario[]> {
    const r = await this.c.query(
      `SELECT f.id AS funcionario_id, f.nome, f.email::text AS email, f.matricula, f.departamento_id, f.funcao_id, cd.centro_custo_id,
         c.tipo AS tipo_contrato, round(c.salario * 100)::float8 AS salario_centavos, c.moeda
       FROM pessoas_funcionarios f
       JOIN pessoas_contratos c ON c.funcionario_id = f.id AND c.estado = 'vigente' AND c.deleted_at IS NULL
       LEFT JOIN folha_centros_departamento cd ON cd.departamento_id = f.departamento_id AND cd.deleted_at IS NULL
       WHERE f.deleted_at IS NULL AND f.estado <> 'desligado' ORDER BY f.nome`,
    );
    return r.rows.map((x) => ({ ...x, salario_centavos: Number(x.salario_centavos) }) as BaseFuncionario);
  }

  async eventosAtivos(): Promise<EventoFolha[]> {
    const r = await this.c.query(`SELECT ${COLUNAS_EVENTO} FROM folha_eventos WHERE estado = 'ativo' AND deleted_at IS NULL ORDER BY codigo`);
    return r.rows.map((x) => EventoFolha.reidratar(x as EventoFolhaDados));
  }

  async beneficiosAtivos(): Promise<Beneficio[]> {
    const r = await this.c.query(`SELECT ${COLUNAS_BENEFICIO} FROM folha_beneficios WHERE estado = 'ativo' AND deleted_at IS NULL ORDER BY created_at, id`);
    return r.rows.map((x) => Beneficio.reidratar(x as BeneficioDados));
  }

  async variaveisDa(competenciaId: string): Promise<VariavelLancada[]> {
    const r = await this.c.query(
      `SELECT funcionario_id, evento_id, valor_centavos::float8 AS valor_centavos, referencia FROM folha_variaveis
       WHERE competencia_id = $1 AND deleted_at IS NULL ORDER BY created_at, id`, [competenciaId]);
    return r.rows.map((x) => ({ ...x, valor_centavos: Number(x.valor_centavos) }) as VariavelLancada);
  }

  // Holerites
  async substituirHolerites(competenciaId: string, holerites: Holerite[]): Promise<void> {
    await this.c.query('UPDATE folha_holerites SET deleted_at = now() WHERE competencia_id = $1 AND deleted_at IS NULL', [competenciaId]);
    for (const h of holerites) {
      const d = h.paraDados();
      await this.c.query(
        `INSERT INTO folha_holerites (id, competencia_id, funcionario_id, funcionario_nome, email, matricula, departamento_id, funcao_id, centro_custo_id,
           tipo_contrato, salario_base_centavos, proventos_centavos, descontos_centavos, encargos_centavos, beneficios_centavos, liquido_centavos,
           custo_centavos, moeda, itens, estado, envio_estado, creator_id)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, $19, $20, $21, nucleo_usuario_atual())`,
        [d.id, d.competencia_id, d.funcionario_id, d.funcionario_nome, d.email, d.matricula, d.departamento_id, d.funcao_id, d.centro_custo_id,
          d.tipo_contrato, d.salario_base_centavos, d.proventos_centavos, d.descontos_centavos, d.encargos_centavos, d.beneficios_centavos,
          d.liquido_centavos, d.custo_centavos, d.moeda, JSON.stringify(d.itens), d.estado, d.envio_estado],
      );
    }
  }

  private holerite(row: Record<string, unknown>): Holerite {
    return Holerite.reidratar({ ...row, enviado_em: iso(row.enviado_em) } as unknown as HoleriteDados);
  }

  async holeritesDa(competenciaId: string): Promise<Holerite[]> {
    const r = await this.c.query(`SELECT ${COLUNAS_HOLERITE} FROM folha_holerites WHERE competencia_id = $1 AND deleted_at IS NULL ORDER BY funcionario_nome`, [competenciaId]);
    return r.rows.map((x) => this.holerite(x));
  }

  async obterHolerite(id: string): Promise<Holerite | null> {
    const r = await this.c.query(`SELECT ${COLUNAS_HOLERITE} FROM folha_holerites WHERE id = $1 AND deleted_at IS NULL`, [id]);
    return r.rows[0] ? this.holerite(r.rows[0]) : null;
  }

  async atualizarHolerite(h: Holerite): Promise<void> {
    const d = h.paraDados();
    await this.c.query(
      'UPDATE folha_holerites SET estado = $2, envio_estado = $3, email_id = $4, enviado_em = $5 WHERE id = $1 AND deleted_at IS NULL',
      [d.id, d.estado, d.envio_estado, d.email_id, d.enviado_em],
    );
  }

  async gravarRateios(competenciaId: string, rateios: Rateio[], moeda: string): Promise<void> {
    await this.c.query('UPDATE folha_rateios SET deleted_at = now() WHERE competencia_id = $1 AND deleted_at IS NULL', [competenciaId]);
    for (const r of rateios) {
      await this.c.query(
        `INSERT INTO folha_rateios (competencia_id, centro_custo_id, liquido_centavos, encargos_centavos, beneficios_centavos, custo_centavos, qtd_funcionarios, moeda, creator_id)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, nucleo_usuario_atual())`,
        [competenciaId, r.centro_custo_id, r.liquido_centavos, r.encargos_centavos, r.beneficios_centavos, r.custo_centavos, r.qtd_funcionarios, moeda],
      );
    }
  }

  // Variaveis
  async inserirVariavel(v: Parameters<GravarVariaveis['inserirVariavel']>[0]): Promise<void> {
    await this.c.query(
      `INSERT INTO folha_variaveis (id, competencia_id, funcionario_id, evento_id, valor_centavos, referencia, creator_id) VALUES ($1, $2, $3, $4, $5, $6, nucleo_usuario_atual())`,
      [v.id, v.competencia_id, v.funcionario_id, v.evento_id, v.valor_centavos, v.referencia],
    );
  }

  async excluirVariavel(competenciaId: string, id: string): Promise<boolean> {
    const r = await this.c.query('UPDATE folha_variaveis SET deleted_at = now() WHERE id = $1 AND competencia_id = $2 AND deleted_at IS NULL', [id, competenciaId]);
    return (r.rowCount ?? 0) > 0;
  }

  // Referencias externas (tabelas publicadas)
  async funcionarioAtivo(id: string): Promise<boolean> {
    return ((await this.c.query("SELECT 1 FROM pessoas_funcionarios WHERE id = $1 AND deleted_at IS NULL AND estado <> 'desligado'", [id])).rowCount ?? 0) > 0;
  }

  async eventoVariavelAtivo(id: string): Promise<boolean> {
    return ((await this.c.query("SELECT 1 FROM folha_eventos WHERE id = $1 AND deleted_at IS NULL AND estado = 'ativo' AND recorrencia = 'variavel'", [id])).rowCount ?? 0) > 0;
  }

  async departamentoExiste(id: string): Promise<boolean> {
    return ((await this.c.query('SELECT 1 FROM pessoas_departamentos WHERE id = $1 AND deleted_at IS NULL', [id])).rowCount ?? 0) > 0;
  }

  async centroCustoAtivo(id: string): Promise<boolean> {
    return ((await this.c.query('SELECT 1 FROM financeiro_centros_custo WHERE id = $1 AND deleted_at IS NULL AND ativo', [id])).rowCount ?? 0) > 0;
  }

  async definirCentro(departamentoId: string, centroCustoId: string | null): Promise<void> {
    if (!centroCustoId) {
      await this.c.query('UPDATE folha_centros_departamento SET deleted_at = now() WHERE departamento_id = $1 AND deleted_at IS NULL', [departamentoId]);
      return;
    }
    await this.c.query(
      `INSERT INTO folha_centros_departamento (departamento_id, centro_custo_id, creator_id) VALUES ($1, $2, nucleo_usuario_atual())
       ON CONFLICT (tenant_id, workspace_id, departamento_id) DO UPDATE SET centro_custo_id = EXCLUDED.centro_custo_id, deleted_at = NULL`,
      [departamentoId, centroCustoId],
    );
  }
}

/** Intencao do job gravada na outbox do nucleo, na mesma transacao do caso de uso (docs/CONTRATOS.md 6). */
export class FilaOutboxPg implements FilaJobs {
  constructor(private readonly c: pg.PoolClient) {}
  async enfileirar(tipo: string, payload: Record<string, unknown>): Promise<string> {
    return (await this.c.query('INSERT INTO outbox (tipo, payload) VALUES ($1, $2) RETURNING id', [tipo, JSON.stringify(payload)])).rows[0].id as string;
  }
}

/** Holerite por e-mail pela fila do nucleo (N17, template aviso); o PDF fica no ERP em /api/v1/folha/holerites/:id/pdf. */
export class CorreioPg implements Correio {
  constructor(private readonly c: pg.PoolClient) {}
  async enviarHolerite(h: HoleriteDados, competencia: string): Promise<string | null> {
    if (!h.email) return null;
    return enviarEmail(this.c, 'aviso', h.email, {
      titulo: `Holerite ${competencia}`,
      mensagem: `Ola, ${h.funcionario_nome}. Seu holerite da competencia ${competencia} esta disponivel no ERP (Pessoas, Beneficios e folha, Holerites). Valor liquido: ${formatarCentavos(h.liquido_centavos)} ${h.moeda}.`,
      holerite_id: h.id,
    });
  }
}

export const relogioSistema: Relogio = { agora: () => new Date().toISOString() };
