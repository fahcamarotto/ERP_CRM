/** Casos de uso de apoio da competencia: LancarVariavel, ExcluirVariavel (M8.2) e DefinirCentroDepartamento (M8.5). */
import { randomUUID } from 'node:crypto';
import { Dinheiro } from '../../compartilhado/dinheiro.ts';
import type { ContextoCaso } from '../../compartilhado/efeitos.ts';
import { erroDe, fail, ok, okVazio, type Result } from '../../compartilhado/result.ts';
import type { ConsultarReferenciasFolha, GravarCentros, GravarCompetencia, GravarVariaveis, ObterCompetencia } from '../model/portas.ts';
import { TABELA } from './competencias.ts';

type Repo = ObterCompetencia & GravarCompetencia;

/** Variavel nova em competencia calculada desatualiza o calculo: a competencia volta para aberta. */
async function desatualizar(repo: Repo, ctx: ContextoCaso, id: string) {
  const c = await repo.obterPorId(id);
  if (c?.estado !== 'calculada') return;
  const r = c.reabrir();
  if (!r.ok) return;
  await repo.atualizar(r.valor);
  await ctx.efeitos.auditar('competencia.reabrir', TABELA, id, { estado: 'calculada' }, { estado: 'aberta', motivo: 'variavel_alterada' });
}

export class LancarVariavel {
  constructor(private readonly deps: { repo: Repo; variaveis: GravarVariaveis; refs: ConsultarReferenciasFolha }) {}
  async execute(ctx: ContextoCaso, e: { competencia_id: string; funcionario_id: string; evento_id: string; valor_centavos: number; referencia?: string | null }): Promise<Result<{ id: string }>> {
    const comp = await this.deps.repo.obterPorId(e.competencia_id);
    if (!comp) return fail(erroDe('nao_encontrado', 'Competencia nao encontrada'));
    if (!comp.aceitaVariaveis) return fail(erroDe('transicao_invalida', `Competencia ${comp.estado} nao aceita variaveis; reabra antes`, 'estado'));
    const v = Dinheiro.tryCreate(e.valor_centavos);
    if (!v.ok) return v;
    if (v.valor.centavos === 0) return fail(erroDe('valor_invalido', 'Valor deve ser maior que zero', 'valor_centavos'));
    if (!(await this.deps.refs.funcionarioAtivo(e.funcionario_id))) return fail(erroDe('funcionario_invalido', 'Funcionario nao encontrado ou desligado', 'funcionario_id'));
    if (!(await this.deps.refs.eventoVariavelAtivo(e.evento_id))) return fail(erroDe('evento_invalido', 'Evento nao encontrado, arquivado ou nao variavel', 'evento_id'));
    const id = randomUUID();
    const d = { id, competencia_id: e.competencia_id, funcionario_id: e.funcionario_id, evento_id: e.evento_id, valor_centavos: v.valor.centavos, referencia: (e.referencia ?? '').trim().slice(0, 60) || null };
    await this.deps.variaveis.inserirVariavel(d);
    await ctx.efeitos.auditar('variavel.lancar', 'folha_variaveis', id, undefined, d);
    await desatualizar(this.deps.repo, ctx, e.competencia_id);
    return ok({ id });
  }
}

export class ExcluirVariavel {
  constructor(private readonly deps: { repo: Repo; variaveis: GravarVariaveis }) {}
  async execute(ctx: ContextoCaso, e: { competencia_id: string; id: string }): Promise<Result<void>> {
    const comp = await this.deps.repo.obterPorId(e.competencia_id);
    if (!comp) return fail(erroDe('nao_encontrado', 'Competencia nao encontrada'));
    if (!comp.aceitaVariaveis) return fail(erroDe('transicao_invalida', `Competencia ${comp.estado} nao aceita alteracao de variaveis`, 'estado'));
    if (!(await this.deps.variaveis.excluirVariavel(e.competencia_id, e.id))) return fail(erroDe('nao_encontrado', 'Variavel nao encontrada'));
    await ctx.efeitos.auditar('variavel.excluir', 'folha_variaveis', e.id, { competencia_id: e.competencia_id }, undefined);
    await desatualizar(this.deps.repo, ctx, e.competencia_id);
    return okVazio();
  }
}

export class DefinirCentroDepartamento {
  constructor(private readonly deps: { centros: GravarCentros; refs: ConsultarReferenciasFolha }) {}
  async execute(ctx: ContextoCaso, e: { departamento_id: string; centro_custo_id: string | null }): Promise<Result<void>> {
    if (!(await this.deps.refs.departamentoExiste(e.departamento_id))) return fail(erroDe('departamento_invalido', 'Departamento nao encontrado', 'departamento_id'));
    if (e.centro_custo_id && !(await this.deps.refs.centroCustoAtivo(e.centro_custo_id))) return fail(erroDe('centro_custo_invalido', 'Centro de custo nao encontrado ou inativo', 'centro_custo_id'));
    await this.deps.centros.definirCentro(e.departamento_id, e.centro_custo_id);
    await ctx.efeitos.auditar('centro_departamento.definir', 'folha_centros_departamento', e.departamento_id, undefined, e);
    return okVazio();
  }
}
