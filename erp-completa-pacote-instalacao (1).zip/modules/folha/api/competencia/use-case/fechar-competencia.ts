/**
 * Fechamento da competencia (M8.3, M8.4, M8.5, M8.7), em job: SolicitarFechamento grava a intencao na outbox
 * na mesma transacao e deixa a competencia em `fechando`; ProcessarFechamento (worker) fecha os holerites,
 * grava o rateio por centro de custo, enfileira o holerite de cada funcionario por e-mail e publica folha.fechada.
 */
import type { ContextoCaso } from '../../compartilhado/efeitos.ts';
import { erroDe, fail, ok, type Result } from '../../compartilhado/result.ts';
import { ratear, totalizar, type Rateio } from '../model/competencia.ts';
import type { Correio, FilaJobs, GravarCompetencia, GravarHolerites, GravarRateios, ObterCompetencia, Relogio } from '../model/portas.ts';
import { TABELA } from './competencias.ts';

export const TIPO_JOB_FECHAMENTO = 'folha.fechar_competencia';

export class SolicitarFechamento {
  constructor(private readonly deps: { repo: ObterCompetencia & GravarCompetencia; fila: FilaJobs }) {}
  async execute(ctx: ContextoCaso, e: { id: string }): Promise<Result<{ competencia_id: string; job_id: string }>> {
    const atual = await this.deps.repo.obterPorId(e.id);
    if (!atual) return fail(erroDe('nao_encontrado', 'Competencia nao encontrada'));
    if (atual.estado !== 'conferida') {
      return fail(erroDe('transicao_invalida', 'So competencia conferida pode ser fechada', 'estado', { permitidas: ['conferida'], atual: atual.estado }));
    }
    const job = await this.deps.fila.enfileirar(TIPO_JOB_FECHAMENTO, { competencia_id: e.id });
    const r = atual.iniciarFechamento(job);
    if (!r.ok) return r;
    await this.deps.repo.atualizar(r.valor);
    await ctx.efeitos.auditar('competencia.solicitar_fechamento', TABELA, e.id, { estado: atual.estado }, { estado: 'fechando', job_id: job });
    return ok({ competencia_id: e.id, job_id: job });
  }
}

export function lancamentosDoRateio(rateios: Rateio[], mes: string, pagamento: string | null, moeda: string) {
  return rateios.map((r) => ({
    tipo: 'saida' as const, origem: 'folha', descricao: `Folha de pagamento ${mes.slice(0, 7)}`, centro_custo_id: r.centro_custo_id,
    valor_centavos: r.custo_centavos, moeda, data_competencia: mes, data_pagamento: pagamento,
  }));
}

export class ProcessarFechamento {
  constructor(private readonly deps: {
    repo: ObterCompetencia & GravarCompetencia;
    holerites: GravarHolerites;
    rateios: GravarRateios;
    correio: Correio;
    relogio: Relogio;
  }) {}

  async execute(ctx: ContextoCaso, e: { competencia_id: string }): Promise<Result<{ holerites: number; enviados: number }>> {
    const atual = await this.deps.repo.obterPorId(e.competencia_id);
    if (!atual) return fail(erroDe('nao_encontrado', 'Competencia nao encontrada'));
    if (atual.estado === 'fechada') return ok({ holerites: 0, enviados: 0 });
    if (atual.estado !== 'fechando') return fail(erroDe('transicao_invalida', `Competencia ${atual.estado} nao esta em fechamento`, 'estado'));
    const agora = this.deps.relogio.agora();
    const lista = await this.deps.holerites.holeritesDa(e.competencia_id);
    if (!lista.length) {
      const f = atual.falharFechamento('Competencia sem holerites');
      if (f.ok) await this.deps.repo.atualizar(f.valor);
      await ctx.efeitos.auditar('competencia.falha_fechamento', TABELA, e.competencia_id, { estado: 'fechando' }, { estado: 'conferida', erro: 'sem_holerites' });
      return fail(erroDe('sem_holerites', 'Competencia sem holerites'));
    }
    const fechados = [];
    for (const h of lista) {
      const r = h.estado === 'fechado' ? ok(h) : h.fechar();
      if (!r.ok) return r;
      fechados.push(r.valor);
    }
    const dados = fechados.map((h) => h.paraDados());
    const totais = totalizar(dados);
    const rateios = ratear(dados);
    const d = atual.paraDados();
    await this.deps.rateios.gravarRateios(e.competencia_id, rateios, d.moeda);
    let enviados = 0;
    for (const h of fechados) {
      const emailId = await this.deps.correio.enviarHolerite(h.paraDados(), d.mes.slice(0, 7));
      const r = h.registrarEnvio(emailId, agora);
      if (!r.ok) return r;
      if (emailId) enviados++;
      await this.deps.holerites.atualizarHolerite(r.valor);
    }
    const r = atual.concluirFechamento(agora);
    if (!r.ok) return r;
    await this.deps.repo.atualizar(r.valor);
    await ctx.efeitos.auditar('competencia.fechar', TABELA, e.competencia_id, { estado: 'fechando' }, { estado: 'fechada', ...totais, rateios });
    await ctx.efeitos.nota(TABELA, e.competencia_id, `Folha fechada: ${totais.qtd_holerites} holerite(s), ${enviados} enviado(s) por e-mail, ${rateios.length} centro(s) de custo.`);
    await ctx.efeitos.publicar('folha.fechada', {
      id: e.competencia_id, competencia: d.mes.slice(0, 7), mes: d.mes, pagamento: d.pagamento, moeda: d.moeda, ...totais,
      rateio: rateios.map((x) => ({ ...x, valor_centavos: x.custo_centavos })),
      lancamentos: lancamentosDoRateio(rateios, d.mes, d.pagamento, d.moeda),
    });
    return ok({ holerites: fechados.length, enviados });
  }
}
