/**
 * Casos de uso da Competencia (M8.3): AbrirCompetencia, EditarCompetencia, CalcularCompetencia,
 * ConferirCompetencia e ReabrirCompetencia. Toda transicao grava auditoria (trilha do fechamento).
 */
import type { ContextoCaso } from '../../compartilhado/efeitos.ts';
import { erroDe, fail, ok, okVazio, type Result } from '../../compartilhado/result.ts';
import { Holerite } from '../../holerite/model/holerite.ts';
import { Competencia, totalizar, type DadosCompetencia } from '../model/competencia.ts';
import type { BaseCalculo, GravarCompetencia, GravarHolerites, ObterCompetencia, Relogio } from '../model/portas.ts';

export const TABELA = 'folha_competencias';
type Repo = ObterCompetencia & GravarCompetencia;

export class AbrirCompetencia {
  constructor(private readonly deps: { repo: Repo }) {}
  async execute(ctx: ContextoCaso, e: DadosCompetencia): Promise<Result<{ id: string }>> {
    const r = Competencia.tryCreate(e);
    if (!r.ok) return r;
    const existente = await this.deps.repo.buscarPorMes(r.valor.mes);
    if (existente) return fail(erroDe('conflito', `Competencia ${r.valor.mes.slice(0, 7)} ja existe`, 'mes', { competencia_id: existente.id }));
    await this.deps.repo.inserir(r.valor);
    const d = r.valor.paraDados();
    await ctx.efeitos.auditar('competencia.abrir', TABELA, d.id, undefined, d);
    return ok({ id: d.id });
  }
}

export class EditarCompetencia {
  constructor(private readonly deps: { repo: Repo }) {}
  async execute(ctx: ContextoCaso, e: { id: string; pagamento?: string | null; observacoes?: string | null }): Promise<Result<void>> {
    const atual = await this.deps.repo.obterPorId(e.id);
    if (!atual) return fail(erroDe('nao_encontrado', 'Competencia nao encontrada'));
    const r = atual.editar(e);
    if (!r.ok) return r;
    await this.deps.repo.atualizar(r.valor);
    const antes = atual.paraDados() as unknown as Record<string, unknown>;
    const depois = r.valor.paraDados() as unknown as Record<string, unknown>;
    await ctx.efeitos.historico(TABELA, e.id, antes, depois);
    await ctx.efeitos.auditar('competencia.editar', TABELA, e.id, antes, depois);
    return okVazio();
  }
}

export class CalcularCompetencia {
  constructor(private readonly deps: { repo: Repo; base: BaseCalculo; holerites: GravarHolerites; relogio: Relogio }) {}
  async execute(ctx: ContextoCaso, e: { id: string }): Promise<Result<{ id: string; qtd_holerites: number }>> {
    const atual = await this.deps.repo.obterPorId(e.id);
    if (!atual) return fail(erroDe('nao_encontrado', 'Competencia nao encontrada'));
    if (atual.estado !== 'aberta' && atual.estado !== 'calculada') {
      return fail(erroDe('transicao_invalida', `Competencia ${atual.estado} nao pode ser calculada`, 'estado', { permitidas: ['aberta', 'calculada'] }));
    }
    const [funcionarios, eventos, beneficios, variaveis] = await Promise.all([
      this.deps.base.funcionariosComContrato(), this.deps.base.eventosAtivos(), this.deps.base.beneficiosAtivos(), this.deps.base.variaveisDa(e.id),
    ]);
    if (!funcionarios.length) return fail(erroDe('sem_funcionarios', 'Nenhum funcionario ativo com contrato vigente no Pessoas'));
    const holerites: Holerite[] = [];
    for (const base of funcionarios) {
      const r = Holerite.calcular({ competencia_id: e.id, mes: atual.mes, base, eventos, beneficios, variaveis });
      if (!r.ok) return r;
      holerites.push(r.valor);
    }
    await this.deps.holerites.substituirHolerites(e.id, holerites);
    const totais = totalizar(holerites.map((h) => h.paraDados()));
    const r = atual.aplicarCalculo(totais, this.deps.relogio.agora());
    if (!r.ok) return r;
    await this.deps.repo.atualizar(r.valor);
    await ctx.efeitos.auditar('competencia.calcular', TABELA, e.id, { estado: atual.estado }, { estado: 'calculada', ...totais });
    await ctx.efeitos.nota(TABELA, e.id, `Folha calculada: ${totais.qtd_holerites} holerite(s), liquido ${totais.total_liquido_centavos} centavos.`);
    await ctx.efeitos.publicar('folha.calculada', { id: e.id, competencia: atual.mes.slice(0, 7), ...totais });
    return ok({ id: e.id, qtd_holerites: totais.qtd_holerites });
  }
}

export class ConferirCompetencia {
  constructor(private readonly deps: { repo: Repo; relogio: Relogio }) {}
  async execute(ctx: ContextoCaso, e: { id: string }): Promise<Result<void>> {
    const atual = await this.deps.repo.obterPorId(e.id);
    if (!atual) return fail(erroDe('nao_encontrado', 'Competencia nao encontrada'));
    const r = atual.conferir(ctx.ator.tipo === 'usuario' ? ctx.ator.id : null, this.deps.relogio.agora());
    if (!r.ok) return r;
    await this.deps.repo.atualizar(r.valor);
    await ctx.efeitos.historico(TABELA, e.id, { estado: atual.estado }, { estado: 'conferida' });
    await ctx.efeitos.auditar('competencia.conferir', TABELA, e.id, { estado: atual.estado }, { estado: 'conferida' });
    return okVazio();
  }
}

export class ReabrirCompetencia {
  constructor(private readonly deps: { repo: Repo }) {}
  async execute(ctx: ContextoCaso, e: { id: string }): Promise<Result<void>> {
    const atual = await this.deps.repo.obterPorId(e.id);
    if (!atual) return fail(erroDe('nao_encontrado', 'Competencia nao encontrada'));
    const r = atual.reabrir();
    if (!r.ok) return r;
    await this.deps.repo.atualizar(r.valor);
    await ctx.efeitos.historico(TABELA, e.id, { estado: atual.estado }, { estado: 'aberta' });
    await ctx.efeitos.auditar('competencia.reabrir', TABELA, e.id, { estado: atual.estado }, { estado: 'aberta' });
    return okVazio();
  }
}
