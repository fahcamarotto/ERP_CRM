/** Rotas REST da Competencia fora das tools: edicao, reabrir, fechar (job 202), variaveis, centros de custo e opcoes da tela. */
import { esquemaErro, requer, type FastifyInstance } from '@erp/api/sdk';
import { naTransacao } from '../borda.ts';
import { exigirOk } from '../compartilhado/result.ts';
import { uuid } from '../esquemas.ts';
import { listarCentrosDepartamento, obterCompetencia, opcoesFolha } from './query/competencias.ts';

const tags = ['folha'];
const erros = { 400: esquemaErro, 403: esquemaErro, 404: esquemaErro, 409: esquemaErro };
const paramId = { type: 'object', required: ['id'], properties: { id: uuid } } as const;

export function rotasCompetencia(app: FastifyInstance): void {
  app.patch<{ Params: { id: string }; Body: { pagamento?: string | null; observacoes?: string | null } }>('/competencias/:id', {
    preHandler: requer('folha.editar'),
    schema: {
      tags, summary: 'Edita data de pagamento e observacoes (EditarCompetencia)', params: paramId, response: erros,
      body: { type: 'object', additionalProperties: false, properties: { pagamento: { type: ['string', 'null'], format: 'date' }, observacoes: { type: ['string', 'null'], maxLength: 2000 } } },
    },
  }, (req) => naTransacao(req, async (casos, ctx, c) => {
    exigirOk(await casos.editarCompetencia.execute(ctx, { ...req.body, id: req.params.id }));
    return obterCompetencia(c, req.params.id);
  }));

  app.post<{ Params: { id: string } }>('/competencias/:id/reabrir', {
    preHandler: requer('folha.calcular'),
    schema: { tags, summary: 'Reabre competencia calculada ou conferida (ReabrirCompetencia)', params: paramId, response: erros },
  }, (req) => naTransacao(req, async (casos, ctx, c) => {
    exigirOk(await casos.reabrirCompetencia.execute(ctx, { id: req.params.id }));
    return obterCompetencia(c, req.params.id);
  }));

  app.post<{ Params: { id: string } }>('/competencias/:id/fechar', {
    preHandler: requer('folha.fechar'),
    schema: { tags, summary: 'Fecha a competencia conferida em job (SolicitarFechamento); consulte GET /competencias/:id ou /api/v1/jobs/:job_id', params: paramId, response: erros },
  }, async (req, reply) => reply.code(202).send(await naTransacao(req, async (casos, ctx) => exigirOk(await casos.solicitarFechamento.execute(ctx, { id: req.params.id })))));

  app.delete<{ Params: { competencia_id: string; id: string } }>('/competencias/:competencia_id/variaveis/:id', {
    preHandler: requer('folha.editar'),
    schema: { tags, summary: 'Exclui variavel da competencia (ExcluirVariavel)', params: { type: 'object', required: ['competencia_id', 'id'], properties: { competencia_id: uuid, id: uuid } }, response: erros },
  }, async (req, reply) => {
    await naTransacao(req, async (casos, ctx) => exigirOk(await casos.excluirVariavel.execute(ctx, req.params)));
    return reply.code(204).send();
  });

  app.get('/centros', {
    preHandler: requer('folha.ver'),
    schema: { tags, summary: 'Departamentos do Pessoas com o centro de custo do Financeiro usado no rateio' },
  }, (req) => naTransacao(req, (_, __, c) => listarCentrosDepartamento(c)));

  app.put<{ Params: { departamento_id: string }; Body: { centro_custo_id: string | null } }>('/centros/:departamento_id', {
    preHandler: requer('folha.editar'),
    schema: {
      tags, summary: 'Define o centro de custo do departamento (DefinirCentroDepartamento); null remove', response: erros,
      params: { type: 'object', required: ['departamento_id'], properties: { departamento_id: uuid } },
      body: { type: 'object', additionalProperties: false, required: ['centro_custo_id'], properties: { centro_custo_id: { type: ['string', 'null'], format: 'uuid' } } },
    },
  }, (req) => naTransacao(req, async (casos, ctx, c) => {
    exigirOk(await casos.definirCentro.execute(ctx, { departamento_id: req.params.departamento_id, centro_custo_id: req.body.centro_custo_id }));
    return listarCentrosDepartamento(c);
  }));

  app.get('/opcoes', {
    preHandler: requer('folha.ver'),
    schema: { tags, summary: 'Opcoes dos seletores: funcionarios ativos, funcoes, centros de custo e eventos variaveis' },
  }, (req) => naTransacao(req, (_, __, c) => opcoesFolha(c)));
}
