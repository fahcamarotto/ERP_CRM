/** Portas do agregado Competencia e do calculo da folha, segregadas por operacao. */
import type { Beneficio } from '../../beneficio/model/beneficio.ts';
import type { EventoFolha } from '../../evento/model/evento-folha.ts';
import type { BaseFuncionario, Holerite, VariavelLancada } from '../../holerite/model/holerite.ts';
import type { Competencia, Rateio } from './competencia.ts';

export interface ObterCompetencia {
  obterPorId(id: string): Promise<Competencia | null>;
  buscarPorMes(mes: string): Promise<Competencia | null>;
}

export interface GravarCompetencia {
  inserir(c: Competencia): Promise<void>;
  atualizar(c: Competencia): Promise<void>;
}

/** Dados de entrada do calculo: funcionarios com contrato vigente (Pessoas 7.1.7), eventos, beneficios e variaveis. */
export interface BaseCalculo {
  funcionariosComContrato(): Promise<BaseFuncionario[]>;
  eventosAtivos(): Promise<EventoFolha[]>;
  beneficiosAtivos(): Promise<Beneficio[]>;
  variaveisDa(competenciaId: string): Promise<VariavelLancada[]>;
}

export interface GravarHolerites {
  /** Troca os holerites calculados da competencia pelos novos (exclusao logica dos anteriores). */
  substituirHolerites(competenciaId: string, holerites: Holerite[]): Promise<void>;
  holeritesDa(competenciaId: string): Promise<Holerite[]>;
  atualizarHolerite(h: Holerite): Promise<void>;
}

export interface ObterHolerite {
  obterHolerite(id: string): Promise<Holerite | null>;
}

export interface GravarRateios {
  gravarRateios(competenciaId: string, rateios: Rateio[], moeda: string): Promise<void>;
}

/** Fila de jobs: grava a intencao na outbox (mesma transacao) e devolve o id do job. */
export interface FilaJobs {
  enfileirar(tipo: string, payload: Record<string, unknown>): Promise<string>;
}

/** Envio do holerite por e-mail pela fila do nucleo (N17). Devolve o id do e-mail ou null sem destinatario. */
export interface Correio {
  enviarHolerite(h: ReturnType<Holerite['paraDados']>, competencia: string): Promise<string | null>;
}

export interface Relogio {
  agora(): string;
}

export interface GravarVariaveis {
  inserirVariavel(v: { id: string; competencia_id: string; funcionario_id: string; evento_id: string; valor_centavos: number; referencia: string | null }): Promise<void>;
  excluirVariavel(competenciaId: string, id: string): Promise<boolean>;
}

export interface ConsultarReferenciasFolha {
  funcionarioAtivo(id: string): Promise<boolean>;
  eventoVariavelAtivo(id: string): Promise<boolean>;
  departamentoExiste(id: string): Promise<boolean>;
  centroCustoAtivo(id: string): Promise<boolean>;
}

export interface GravarCentros {
  definirCentro(departamentoId: string, centroCustoId: string | null): Promise<void>;
}
