/**
 * Entidade Competencia (M8.3): folha mensal com abertura, calculo, conferencia e fechamento.
 * O fechamento roda como job (estado `fechando` ate o worker concluir). Imutavel: metodos devolvem clone.
 */
import { randomUUID } from 'node:crypto';
import { erroDe, fail, ok, type ErroDominio, type Result } from '../../compartilhado/result.ts';
import type { HoleriteDados } from '../../holerite/model/holerite.ts';

export const ESTADOS_COMPETENCIA = ['aberta', 'calculada', 'conferida', 'fechando', 'fechada'] as const;
export type EstadoCompetencia = (typeof ESTADOS_COMPETENCIA)[number];

/** Maquina de estados. Fechada e final; fechando volta a conferida se o job falhar. */
export const TRANSICOES: Record<EstadoCompetencia, EstadoCompetencia[]> = {
  aberta: ['calculada'],
  calculada: ['calculada', 'conferida', 'aberta'],
  conferida: ['aberta', 'fechando'],
  fechando: ['fechada', 'conferida'],
  fechada: [],
};

export interface DadosCompetencia {
  mes: string; // AAAA-MM ou AAAA-MM-01
  pagamento?: string | null;
  moeda?: string;
  observacoes?: string | null;
}

export interface Totais {
  total_proventos_centavos: number;
  total_descontos_centavos: number;
  total_encargos_centavos: number;
  total_beneficios_centavos: number;
  total_liquido_centavos: number;
  total_custo_centavos: number;
  qtd_holerites: number;
}

export interface CompetenciaDados extends Totais {
  id: string;
  mes: string;
  pagamento: string | null;
  moeda: string;
  estado: EstadoCompetencia;
  calculada_em: string | null;
  conferida_em: string | null;
  conferida_por: string | null;
  fechada_em: string | null;
  job_id: string | null;
  erro: string | null;
  observacoes: string | null;
}

export interface Rateio {
  centro_custo_id: string | null;
  liquido_centavos: number;
  encargos_centavos: number;
  beneficios_centavos: number;
  custo_centavos: number;
  qtd_funcionarios: number;
}

const ZERO: Totais = {
  total_proventos_centavos: 0, total_descontos_centavos: 0, total_encargos_centavos: 0, total_beneficios_centavos: 0,
  total_liquido_centavos: 0, total_custo_centavos: 0, qtd_holerites: 0,
};

const t = (v?: string | null) => (v ?? '').trim() || null;
const dataValida = (v: string | null) => v !== null && /^\d{4}-\d{2}-\d{2}$/.test(v) && !Number.isNaN(Date.parse(v));

/** Normaliza AAAA-MM ou AAAA-MM-DD para o dia 1 do mes. */
export function normalizarMes(v: string): string | null {
  const m = /^(\d{4})-(\d{2})(-\d{2})?$/.exec((v ?? '').trim());
  if (!m || Number(m[2]) < 1 || Number(m[2]) > 12 || Number(m[1]) < 2000) return null;
  return `${m[1]}-${m[2]}-01`;
}

function validar(d: CompetenciaDados): ErroDominio[] {
  const e: ErroDominio[] = [];
  if (!normalizarMes(d.mes)) e.push(erroDe('mes_invalido', 'Competencia deve ser AAAA-MM', 'mes'));
  if (d.pagamento !== null && !dataValida(d.pagamento)) e.push(erroDe('data_invalida', 'Pagamento deve ser AAAA-MM-DD', 'pagamento'));
  if (d.pagamento && normalizarMes(d.mes) && d.pagamento < d.mes) e.push(erroDe('pagamento_invalido', 'Pagamento antes do inicio da competencia', 'pagamento'));
  if (!/^[A-Z]{3}$/.test(d.moeda)) e.push(erroDe('moeda_invalida', 'Moeda em ISO 4217 (BRL, USD, EUR)', 'moeda'));
  return e;
}

/** Soma os holerites por centro de custo (o que vai para o Financeiro, M8.5). */
export function ratear(holerites: Pick<HoleriteDados, 'centro_custo_id' | 'liquido_centavos' | 'encargos_centavos' | 'beneficios_centavos' | 'custo_centavos'>[]): Rateio[] {
  const m = new Map<string, Rateio>();
  for (const h of holerites) {
    const k = h.centro_custo_id ?? '';
    const r = m.get(k) ?? { centro_custo_id: h.centro_custo_id, liquido_centavos: 0, encargos_centavos: 0, beneficios_centavos: 0, custo_centavos: 0, qtd_funcionarios: 0 };
    r.liquido_centavos += h.liquido_centavos;
    r.encargos_centavos += h.encargos_centavos;
    r.beneficios_centavos += h.beneficios_centavos;
    r.custo_centavos += h.custo_centavos;
    r.qtd_funcionarios += 1;
    m.set(k, r);
  }
  return [...m.values()].sort((a, b) => b.custo_centavos - a.custo_centavos);
}

/** Totais da competencia a partir dos holerites calculados. */
export function totalizar(holerites: Pick<HoleriteDados, 'proventos_centavos' | 'descontos_centavos' | 'encargos_centavos' | 'beneficios_centavos' | 'liquido_centavos' | 'custo_centavos'>[]): Totais {
  return holerites.reduce<Totais>((a, h) => ({
    total_proventos_centavos: a.total_proventos_centavos + h.proventos_centavos,
    total_descontos_centavos: a.total_descontos_centavos + h.descontos_centavos,
    total_encargos_centavos: a.total_encargos_centavos + h.encargos_centavos,
    total_beneficios_centavos: a.total_beneficios_centavos + h.beneficios_centavos,
    total_liquido_centavos: a.total_liquido_centavos + h.liquido_centavos,
    total_custo_centavos: a.total_custo_centavos + h.custo_centavos,
    qtd_holerites: a.qtd_holerites + 1,
  }), { ...ZERO });
}

export class Competencia {
  private constructor(private readonly d: CompetenciaDados) {}

  static tryCreate(e: DadosCompetencia, id: string = randomUUID()): Result<Competencia> {
    const mes = normalizarMes(e.mes) ?? (e.mes ?? '');
    const d: CompetenciaDados = {
      id, mes, pagamento: t(e.pagamento), moeda: (t(e.moeda) ?? 'BRL').toUpperCase(), estado: 'aberta', ...ZERO,
      calculada_em: null, conferida_em: null, conferida_por: null, fechada_em: null, job_id: null, erro: null, observacoes: t(e.observacoes),
    };
    const erros = validar(d);
    return erros.length ? fail(...erros) : ok(new Competencia(d));
  }

  static create(e: DadosCompetencia, id?: string): Competencia {
    const r = Competencia.tryCreate(e, id);
    if (!r.ok) throw new Error(r.erros.map((x) => x.mensagem).join('; '));
    return r.valor;
  }

  static reidratar(d: CompetenciaDados): Competencia {
    const n = (v: unknown) => Number(v);
    return new Competencia({
      ...d, total_proventos_centavos: n(d.total_proventos_centavos), total_descontos_centavos: n(d.total_descontos_centavos),
      total_encargos_centavos: n(d.total_encargos_centavos), total_beneficios_centavos: n(d.total_beneficios_centavos),
      total_liquido_centavos: n(d.total_liquido_centavos), total_custo_centavos: n(d.total_custo_centavos), qtd_holerites: n(d.qtd_holerites),
    });
  }

  get id(): string { return this.d.id; }
  get mes(): string { return this.d.mes; }
  get estado(): EstadoCompetencia { return this.d.estado; }
  /** Variaveis so entram enquanto a folha nao foi conferida. */
  get aceitaVariaveis(): boolean { return this.d.estado === 'aberta' || this.d.estado === 'calculada'; }

  private ir(novo: EstadoCompetencia, mud: Partial<CompetenciaDados> = {}): Result<Competencia> {
    if (!TRANSICOES[this.d.estado].includes(novo)) {
      return fail(erroDe('transicao_invalida', `Transicao de ${this.d.estado} para ${novo} nao permitida`, 'estado', { permitidas: TRANSICOES[this.d.estado] }));
    }
    return ok(new Competencia({ ...this.d, ...mud, estado: novo }));
  }

  editar(e: Partial<Pick<DadosCompetencia, 'pagamento' | 'observacoes'>>): Result<Competencia> {
    if (this.d.estado === 'fechando' || this.d.estado === 'fechada') return fail(erroDe('transicao_invalida', `Competencia ${this.d.estado} nao pode ser editada`));
    const n = { ...this.d, pagamento: e.pagamento !== undefined ? t(e.pagamento) : this.d.pagamento, observacoes: e.observacoes !== undefined ? t(e.observacoes) : this.d.observacoes };
    const erros = validar(n);
    return erros.length ? fail(...erros) : ok(new Competencia(n));
  }

  aplicarCalculo(totais: Totais, quando: string): Result<Competencia> {
    return this.ir('calculada', { ...totais, calculada_em: quando, erro: null, conferida_em: null, conferida_por: null });
  }

  conferir(usuarioId: string | null, quando: string): Result<Competencia> {
    if (this.d.estado === 'calculada' && this.d.qtd_holerites === 0) return fail(erroDe('sem_holerites', 'Competencia sem holerites para conferir'));
    if (this.d.estado !== 'calculada') return this.ir('conferida');
    return this.ir('conferida', { conferida_em: quando, conferida_por: usuarioId });
  }

  reabrir(): Result<Competencia> {
    return this.ir('aberta', { conferida_em: null, conferida_por: null });
  }

  iniciarFechamento(jobId: string): Result<Competencia> {
    return this.ir('fechando', { job_id: jobId, erro: null });
  }

  concluirFechamento(quando: string): Result<Competencia> {
    return this.ir('fechada', { fechada_em: quando, erro: null });
  }

  falharFechamento(motivo: string): Result<Competencia> {
    return this.ir('conferida', { erro: motivo.slice(0, 500) });
  }

  paraDados(): CompetenciaDados {
    return { ...this.d };
  }
}
