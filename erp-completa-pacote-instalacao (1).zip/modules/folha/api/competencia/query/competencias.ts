/** Consultas de leitura da Competencia: lista, ficha com rateio e variaveis, centros por departamento e opcoes de selecao. */
import type pg from 'pg';
import { decodificarCursor, pagina } from '../../compartilhado/cursor.ts';

const RESUMO = `c.id, to_char(c.mes, 'YYYY-MM') AS competencia, to_char(c.mes, 'YYYY-MM-DD') AS mes, to_char(c.pagamento, 'YYYY-MM-DD') AS pagamento,
  c.moeda, c.estado, c.total_proventos_centavos::float8 AS total_proventos_centavos, c.total_descontos_centavos::float8 AS total_descontos_centavos,
  c.total_encargos_centavos::float8 AS total_encargos_centavos, c.total_beneficios_centavos::float8 AS total_beneficios_centavos,
  c.total_liquido_centavos::float8 AS total_liquido_centavos, c.total_custo_centavos::float8 AS total_custo_centavos, c.qtd_holerites,
  c.calculada_em, c.conferida_em, u.nome AS conferida_por_nome, c.fechada_em, c.job_id, c.erro, c.observacoes, c.created_at, c.updated_at`;

export async function listarCompetencias(c: pg.PoolClient, f: { estado?: string; limite?: number; cursor?: string }) {
  const lim = Math.min(Math.max(f.limite ?? 50, 1), 200);
  const cur = decodificarCursor(f.cursor);
  const r = await c.query(
    `SELECT ${RESUMO} FROM folha_competencias c LEFT JOIN usuarios u ON u.id = c.conferida_por
     WHERE c.deleted_at IS NULL AND ($1::text IS NULL OR c.estado = $1)
       AND ($2::timestamptz IS NULL OR (c.created_at, c.id) > ($2::timestamptz, $3::uuid))
     ORDER BY c.created_at, c.id LIMIT $4`,
    [f.estado ?? null, cur?.[0] ?? null, cur?.[1] ?? null, lim + 1],
  );
  return pagina(r.rows, lim);
}

export async function obterCompetencia(c: pg.PoolClient, id: string) {
  const r = await c.query(
    `SELECT ${RESUMO},
       coalesce((SELECT json_agg(json_build_object('centro_custo_id', ra.centro_custo_id, 'centro_custo_nome', cc.nome, 'centro_custo_codigo', cc.codigo,
         'liquido_centavos', ra.liquido_centavos, 'encargos_centavos', ra.encargos_centavos, 'beneficios_centavos', ra.beneficios_centavos,
         'custo_centavos', ra.custo_centavos, 'qtd_funcionarios', ra.qtd_funcionarios) ORDER BY ra.custo_centavos DESC)
         FROM folha_rateios ra LEFT JOIN financeiro_centros_custo cc ON cc.id = ra.centro_custo_id
         WHERE ra.competencia_id = c.id AND ra.deleted_at IS NULL), '[]') AS rateios,
       coalesce((SELECT json_agg(json_build_object('id', v.id, 'funcionario_id', v.funcionario_id, 'funcionario_nome', f.nome, 'evento_id', v.evento_id,
         'evento_codigo', e.codigo, 'evento_nome', e.nome, 'natureza', e.natureza, 'valor_centavos', v.valor_centavos, 'referencia', v.referencia) ORDER BY f.nome, e.codigo)
         FROM folha_variaveis v JOIN pessoas_funcionarios f ON f.id = v.funcionario_id JOIN folha_eventos e ON e.id = v.evento_id
         WHERE v.competencia_id = c.id AND v.deleted_at IS NULL), '[]') AS variaveis
     FROM folha_competencias c LEFT JOIN usuarios u ON u.id = c.conferida_por WHERE c.id = $1 AND c.deleted_at IS NULL`,
    [id],
  );
  return r.rows[0] ?? null;
}

/** Departamentos do Pessoas com o centro de custo do Financeiro usado no rateio (M8.5). */
export async function listarCentrosDepartamento(c: pg.PoolClient) {
  return (await c.query(
    `SELECT d.id AS departamento_id, d.nome AS departamento_nome, cd.centro_custo_id, cc.nome AS centro_custo_nome, cc.codigo AS centro_custo_codigo
     FROM pessoas_departamentos d
     LEFT JOIN folha_centros_departamento cd ON cd.departamento_id = d.id AND cd.deleted_at IS NULL
     LEFT JOIN financeiro_centros_custo cc ON cc.id = cd.centro_custo_id
     WHERE d.deleted_at IS NULL ORDER BY d.nome`)).rows;
}

/** Opcoes dos seletores da tela: funcionarios ativos, funcoes, centros de custo e eventos variaveis. */
export async function opcoesFolha(c: pg.PoolClient) {
  const [funcionarios, funcoes, centros, variaveis] = await Promise.all([
    c.query("SELECT id, nome FROM pessoas_funcionarios WHERE deleted_at IS NULL AND estado <> 'desligado' ORDER BY nome"),
    c.query("SELECT id, nome FROM pessoas_funcoes WHERE deleted_at IS NULL AND estado = 'ativo' ORDER BY nome"),
    c.query('SELECT id, codigo, nome FROM financeiro_centros_custo WHERE deleted_at IS NULL AND ativo ORDER BY nome'),
    c.query("SELECT id, codigo, nome, natureza FROM folha_eventos WHERE deleted_at IS NULL AND estado = 'ativo' AND recorrencia = 'variavel' ORDER BY codigo"),
  ]);
  return { funcionarios: funcionarios.rows, funcoes: funcoes.rows, centros_custo: centros.rows, eventos_variaveis: variaveis.rows };
}
