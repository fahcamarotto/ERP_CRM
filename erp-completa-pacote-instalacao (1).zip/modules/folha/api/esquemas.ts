/** JSON Schemas dos DTOs de entrada (viram validacao Fastify, OpenAPI em /docs e schema das tools MCP). */
import { TIPOS_BENEFICIO } from './beneficio/model/beneficio.ts';
import { CALCULOS, NATUREZAS, RECORRENCIAS, TIPOS_CONTRATO } from './evento/model/evento-folha.ts';
import { ESTADOS_COMPETENCIA } from './competencia/model/competencia.ts';

export const uuid = { type: 'string', format: 'uuid' } as const;
const texto = (max: number) => ({ type: ['string', 'null'], maxLength: max });
const centavos = (descricao: string) => ({ type: 'integer', minimum: 0, maximum: 9_000_000_000_000, description: descricao });

export const propsBeneficio = {
  nome: { type: 'string', minLength: 2, maxLength: 120 },
  tipo: { type: 'string', enum: [...TIPOS_BENEFICIO] },
  abrangencia: { type: 'string', enum: ['funcionario', 'funcao'], description: 'funcionario (um so) ou funcao (todos os funcionarios da funcao)' },
  funcionario_id: { type: ['string', 'null'], format: 'uuid' },
  funcao_id: { type: ['string', 'null'], format: 'uuid' },
  valor_empresa_centavos: centavos('Custo mensal da empresa em centavos'),
  desconto_funcionario_centavos: centavos('Desconto mensal no holerite (coparticipacao) em centavos'),
  moeda: { type: 'string', pattern: '^[A-Z]{3}$' },
  inicio: { type: 'string', format: 'date' },
  fim: { type: ['string', 'null'], format: 'date' },
  observacoes: texto(2000),
  extras: { type: 'object', description: 'Campos personalizados (modulo folha, entidade beneficio)' },
} as const;

export const propsEvento = {
  codigo: { type: 'string', pattern: '^[A-Za-z0-9_]{2,20}$', description: 'Codigo da rubrica (ex.: HE50, FGTS)' },
  nome: { type: 'string', minLength: 2, maxLength: 120 },
  natureza: { type: 'string', enum: [...NATUREZAS] },
  recorrencia: { type: 'string', enum: [...RECORRENCIAS], description: 'fixo entra todo mes; variavel so com lancamento na competencia' },
  calculo: { type: 'string', enum: [...CALCULOS], description: 'valor em centavos, percentual sobre os proventos ou tabela legal de INSS e IRRF' },
  valor_centavos: { type: ['integer', 'null'], minimum: 0 },
  percentual: { type: ['number', 'null'], minimum: 0, maximum: 100 },
  funcionario_id: { type: ['string', 'null'], format: 'uuid', description: 'Evento fixo de um funcionario so (vazio = todos)' },
  tipos_contrato: { type: 'array', items: { type: 'string', enum: [...TIPOS_CONTRATO] }, maxItems: 6, description: 'Vazio = todos os contratos' },
  descricao: texto(1000),
} as const;

export const propsCompetencia = {
  mes: { type: 'string', pattern: '^\\d{4}-\\d{2}(-01)?$', description: 'Competencia AAAA-MM' },
  pagamento: { type: ['string', 'null'], format: 'date' },
  moeda: { type: 'string', pattern: '^[A-Z]{3}$' },
  observacoes: texto(2000),
} as const;

export const propsVariavel = {
  funcionario_id: uuid,
  evento_id: uuid,
  valor_centavos: { type: 'integer', minimum: 1, maximum: 9_000_000_000_000 },
  referencia: texto(60),
} as const;

export const estadosCompetencia = ESTADOS_COMPETENCIA;

export const paginacao = {
  busca: { type: 'string', maxLength: 120 },
  limite: { type: 'integer', minimum: 1, maximum: 200, default: 50 },
  cursor: { type: 'string', maxLength: 200 },
} as const;
