/** Consultas de leitura do Holerite: lista por competencia e ficha com itens, nomes de departamento, funcao e centro de custo. */
import type pg from 'pg';
import { decodificarCursor, pagina } from '../../compartilhado/cursor.ts';

const RESUMO = `h.id, h.competencia_id, to_char(c.mes, 'YYYY-MM') AS competencia, h.funcionario_id, h.funcionario_nome, h.email, h.matricula,
  h.departamento_id, d.nome AS departamento_nome, h.funcao_id, fn.nome AS funcao_nome, h.centro_custo_id, cc.nome AS centro_custo_nome,
  h.tipo_contrato, h.salario_base_centavos::float8 AS salario_base_centavos, h.proventos_centavos::float8 AS proventos_centavos,
  h.descontos_centavos::float8 AS descontos_centavos, h.encargos_centavos::float8 AS encargos_centavos,
  h.beneficios_centavos::float8 AS beneficios_centavos, h.liquido_centavos::float8 AS liquido_centavos, h.custo_centavos::float8 AS custo_centavos,
  h.moeda, h.estado, h.envio_estado, h.enviado_em, h.created_at, h.updated_at`;

const JUNCOES = `FROM folha_holerites h
  JOIN folha_competencias c ON c.id = h.competencia_id
  LEFT JOIN pessoas_departamentos d ON d.id = h.departamento_id
  LEFT JOIN pessoas_funcoes fn ON fn.id = h.funcao_id
  LEFT JOIN financeiro_centros_custo cc ON cc.id = h.centro_custo_id`;

export interface FiltroHolerites {
  competencia_id?: string;
  funcionario_id?: string;
  busca?: string;
  limite?: number;
  cursor?: string;
}

export async function listarHolerites(c: pg.PoolClient, f: FiltroHolerites) {
  const lim = Math.min(Math.max(f.limite ?? 50, 1), 200);
  const cur = decodificarCursor(f.cursor);
  const r = await c.query(
    `SELECT ${RESUMO} ${JUNCOES}
     WHERE h.deleted_at IS NULL AND ($1::uuid IS NULL OR h.competencia_id = $1) AND ($2::uuid IS NULL OR h.funcionario_id = $2)
       AND ($3::text IS NULL OR h.funcionario_nome ILIKE '%' || $3 || '%')
       AND ($4::timestamptz IS NULL OR (h.created_at, h.id) > ($4::timestamptz, $5::uuid))
     ORDER BY h.created_at, h.id LIMIT $6`,
    [f.competencia_id ?? null, f.funcionario_id ?? null, f.busca?.trim() || null, cur?.[0] ?? null, cur?.[1] ?? null, lim + 1],
  );
  return pagina(r.rows, lim);
}

export async function obterHolerite(c: pg.PoolClient, id: string) {
  return (await c.query(`SELECT ${RESUMO}, h.itens, c.estado AS competencia_estado ${JUNCOES} WHERE h.id = $1 AND h.deleted_at IS NULL`, [id])).rows[0] ?? null;
}

/** Nome do workspace para o cabecalho do PDF (tabela do nucleo, leitura permitida). */
export async function nomeEmpresa(c: pg.PoolClient): Promise<string> {
  const r = await c.query('SELECT nome FROM workspaces WHERE id = nucleo_workspace_atual()');
  return (r.rows[0]?.nome as string | undefined) ?? 'ERP';
}

export async function mesDaCompetencia(c: pg.PoolClient, id: string): Promise<string | null> {
  return ((await c.query("SELECT to_char(mes, 'YYYY-MM-DD') AS mes FROM folha_competencias WHERE id = $1", [id])).rows[0]?.mes as string | undefined) ?? null;
}
