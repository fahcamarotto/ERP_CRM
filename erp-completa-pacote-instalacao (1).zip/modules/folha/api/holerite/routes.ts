/** Rotas REST do Holerite fora das tools: PDF e reenvio por e-mail. */
import { esquemaErro, requer, type FastifyInstance } from '@erp/api/sdk';
import { naTransacao, naoEncontrado } from '../borda.ts';
import { exigirOk } from '../compartilhado/result.ts';
import { uuid } from '../esquemas.ts';
import type { HoleriteDados } from './model/holerite.ts';
import { gerarPdfHolerite } from './model/pdf.ts';
import { nomeEmpresa, obterHolerite } from './query/holerites.ts';

const tags = ['folha'];
const paramId = { type: 'object', required: ['id'], properties: { id: uuid } } as const;

export function rotasHolerite(app: FastifyInstance): void {
  app.get<{ Params: { id: string } }>('/holerites/:id/pdf', {
    preHandler: requer('folha.ver'),
    schema: { tags, summary: 'Holerite em PDF (application/pdf)', params: paramId, response: { 404: esquemaErro } },
  }, async (req, reply) => {
    const { h, empresa } = await naTransacao(req, async (_, __, c) => {
      const h = await obterHolerite(c, req.params.id);
      if (!h) throw naoEncontrado('Holerite nao encontrado');
      return { h, empresa: await nomeEmpresa(c) };
    });
    const pdf = gerarPdfHolerite(h as HoleriteDados, { empresa, competencia: h.competencia, departamento: h.departamento_nome, funcao: h.funcao_nome });
    const arquivo = `holerite-${h.competencia}-${String(h.funcionario_nome).normalize('NFD').replace(/[^A-Za-z0-9]+/g, '-').toLowerCase()}.pdf`;
    return reply.type('application/pdf').header('content-disposition', `inline; filename="${arquivo}"`).send(pdf);
  });

  app.post<{ Params: { id: string } }>('/holerites/:id/enviar', {
    preHandler: requer('folha.editar'),
    schema: { tags, summary: 'Reenvia o holerite por e-mail pela fila (EnviarHolerite)', params: paramId, response: { 400: esquemaErro, 404: esquemaErro, 409: esquemaErro } },
  }, async (req, reply) => reply.code(202).send(await naTransacao(req, async (casos, ctx) => exigirOk(await casos.enviarHolerite.execute(ctx, { id: req.params.id })))));
}
