/**
 * Tabelas legais de 2026 usadas pelos eventos com calculo `tabela_inss` e `tabela_irrf` (valores em centavos).
 * INSS: progressiva por faixa sobre os proventos, ate o teto. IRRF: tabela mensal sobre a base
 * (proventos menos o maior entre INSS e o desconto simplificado), com o redutor da Lei 15.270/2025.
 */
import { arredondar } from '../../compartilhado/dinheiro.ts';

export const INSS_2026: readonly { ate: number; aliquota: number }[] = [
  { ate: 162100, aliquota: 0.075 },
  { ate: 290284, aliquota: 0.09 },
  { ate: 435427, aliquota: 0.12 },
  { ate: 847555, aliquota: 0.14 },
];

export const IRRF_2026: readonly { ate: number; aliquota: number; deduzir: number }[] = [
  { ate: 242880, aliquota: 0, deduzir: 0 },
  { ate: 282665, aliquota: 0.075, deduzir: 18216 },
  { ate: 375105, aliquota: 0.15, deduzir: 39416 },
  { ate: 466468, aliquota: 0.225, deduzir: 67549 },
  { ate: Number.MAX_SAFE_INTEGER, aliquota: 0.275, deduzir: 90873 },
];

export const DESCONTO_SIMPLIFICADO = 60720;
export const REDUTOR_ISENCAO_ATE = 500000;
export const REDUTOR_PARCIAL_ATE = 735000;

/** INSS do empregado: soma progressiva das faixas, limitada ao teto. */
export function calcularInss(proventos: number): number {
  let anterior = 0;
  let total = 0;
  for (const f of INSS_2026) {
    if (proventos <= anterior) break;
    total += (Math.min(proventos, f.ate) - anterior) * f.aliquota;
    anterior = f.ate;
  }
  return arredondar(total);
}

/** IRRF mensal com o redutor: ate R$ 5.000 isento; ate R$ 7.350 reducao de 978,62 menos 0,133145 x rendimento. */
export function calcularIrrf(proventos: number, inss: number): number {
  const base = Math.max(0, proventos - Math.max(inss, DESCONTO_SIMPLIFICADO));
  const faixa = IRRF_2026.find((f) => base <= f.ate)!;
  const imposto = Math.max(0, arredondar(base * faixa.aliquota - faixa.deduzir));
  let reducao = 0;
  if (proventos <= REDUTOR_ISENCAO_ATE) reducao = imposto;
  else if (proventos <= REDUTOR_PARCIAL_ATE) reducao = Math.max(0, arredondar(97862 - 0.133145 * proventos));
  return Math.max(0, imposto - reducao);
}
