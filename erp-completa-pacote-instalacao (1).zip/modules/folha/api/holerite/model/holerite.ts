/**
 * Entidade Holerite (M8.4): foto do calculo de um funcionario numa competencia, com os itens
 * (proventos, descontos, encargos e beneficios). Calculado na competencia, fechado no fechamento.
 */
import { randomUUID } from 'node:crypto';
import { arredondar } from '../../compartilhado/dinheiro.ts';
import { erroDe, fail, ok, type Result } from '../../compartilhado/result.ts';
import type { Beneficio } from '../../beneficio/model/beneficio.ts';
import type { EventoFolha } from '../../evento/model/evento-folha.ts';
import { calcularInss, calcularIrrf } from './tabelas.ts';

export const NATUREZAS_ITEM = ['provento', 'desconto', 'encargo', 'beneficio'] as const;
export type NaturezaItem = (typeof NATUREZAS_ITEM)[number];

export interface ItemHolerite {
  codigo: string;
  nome: string;
  natureza: NaturezaItem;
  referencia: string | null;
  valor_centavos: number;
}

/** Funcionario com contrato vigente (consulta publicada do Pessoas, 7.1.7). */
export interface BaseFuncionario {
  funcionario_id: string;
  nome: string;
  email: string | null;
  matricula: string | null;
  departamento_id: string | null;
  funcao_id: string | null;
  centro_custo_id: string | null;
  tipo_contrato: string;
  salario_centavos: number;
  moeda: string;
}

export interface VariavelLancada {
  funcionario_id: string;
  evento_id: string;
  valor_centavos: number;
  referencia: string | null;
}

export interface HoleriteDados {
  id: string;
  competencia_id: string;
  funcionario_id: string;
  funcionario_nome: string;
  email: string | null;
  matricula: string | null;
  departamento_id: string | null;
  funcao_id: string | null;
  centro_custo_id: string | null;
  tipo_contrato: string;
  salario_base_centavos: number;
  proventos_centavos: number;
  descontos_centavos: number;
  encargos_centavos: number;
  beneficios_centavos: number;
  liquido_centavos: number;
  custo_centavos: number;
  moeda: string;
  itens: ItemHolerite[];
  estado: 'calculado' | 'fechado';
  envio_estado: 'nao_enviado' | 'na_fila' | 'sem_email';
  email_id: string | null;
  enviado_em: string | null;
}

const soma = (itens: ItemHolerite[], n: NaturezaItem) => itens.filter((i) => i.natureza === n).reduce((a, i) => a + i.valor_centavos, 0);
const pct = (v: number | null) => (v === null ? null : `${String(v).replace('.', ',')}%`);

export class Holerite {
  private constructor(private readonly d: HoleriteDados) {}

  /**
   * Calcula o holerite. Ordem: salario e proventos (fixos e variaveis), INSS sobre os proventos, IRRF sobre a base,
   * descontos e encargos percentuais sobre os proventos, beneficios (custo da empresa e coparticipacao).
   */
  static calcular(e: { competencia_id: string; mes: string; base: BaseFuncionario; eventos: EventoFolha[]; beneficios: Beneficio[]; variaveis: VariavelLancada[] }, id: string = randomUUID()): Result<Holerite> {
    const b = e.base;
    if (!Number.isSafeInteger(b.salario_centavos) || b.salario_centavos < 0) return fail(erroDe('salario_invalido', `Salario invalido para ${b.nome}`, 'salario'));
    const itens: ItemHolerite[] = [{ codigo: 'SALARIO', nome: 'Salario base', natureza: 'provento', referencia: '30d', valor_centavos: b.salario_centavos }];
    const aplicaveis = e.eventos.filter((ev) => ev.estado === 'ativo' && ev.aplicaA(b.tipo_contrato));
    const porId = new Map(aplicaveis.map((ev) => [ev.id, ev]));
    const fixos = aplicaveis.filter((ev) => { const d = ev.paraDados(); return d.recorrencia === 'fixo' && (!d.funcionario_id || d.funcionario_id === b.funcionario_id); });
    const item = (ev: EventoFolha, valor: number, referencia: string | null): ItemHolerite => {
      const d = ev.paraDados();
      return { codigo: d.codigo, nome: d.nome, natureza: d.natureza, referencia, valor_centavos: Math.max(0, arredondar(valor)) };
    };
    // 1) proventos fixos por valor e variaveis de provento
    for (const ev of fixos) { const d = ev.paraDados(); if (d.natureza === 'provento' && d.calculo === 'valor') itens.push(item(ev, d.valor_centavos ?? 0, null)); }
    const variaveis = e.variaveis.filter((v) => v.funcionario_id === b.funcionario_id && porId.has(v.evento_id));
    for (const v of variaveis) { const ev = porId.get(v.evento_id)!; if (ev.paraDados().natureza === 'provento') itens.push(item(ev, v.valor_centavos, v.referencia)); }
    // 2) proventos percentuais sobre o salario
    for (const ev of fixos) { const d = ev.paraDados(); if (d.natureza === 'provento' && d.calculo === 'percentual') itens.push(item(ev, b.salario_centavos * (d.percentual ?? 0) / 100, pct(d.percentual))); }
    const proventos = soma(itens, 'provento');
    // 3) INSS e IRRF
    let inss = 0;
    for (const ev of fixos) {
      const d = ev.paraDados();
      if (d.calculo === 'tabela_inss') { inss = calcularInss(proventos); itens.push(item(ev, inss, 'tabela 2026')); }
    }
    for (const ev of fixos) {
      const d = ev.paraDados();
      if (d.calculo === 'tabela_irrf') { const v = calcularIrrf(proventos, inss); if (v > 0) itens.push(item(ev, v, 'tabela 2026')); }
    }
    // 4) descontos e encargos por valor ou percentual sobre os proventos; variaveis de desconto e encargo
    for (const ev of fixos) {
      const d = ev.paraDados();
      if (d.natureza === 'provento' || d.calculo === 'tabela_inss' || d.calculo === 'tabela_irrf') continue;
      if (d.calculo === 'valor') itens.push(item(ev, d.valor_centavos ?? 0, null));
      else itens.push(item(ev, proventos * (d.percentual ?? 0) / 100, pct(d.percentual)));
    }
    for (const v of variaveis) { const ev = porId.get(v.evento_id)!; if (ev.paraDados().natureza !== 'provento') itens.push(item(ev, v.valor_centavos, v.referencia)); }
    // 5) beneficios do funcionario ou da funcao vigentes no mes
    for (const ben of e.beneficios) {
      const d = ben.paraDados();
      const alvo = d.abrangencia === 'funcionario' ? d.funcionario_id === b.funcionario_id : !!b.funcao_id && d.funcao_id === b.funcao_id;
      if (!alvo || !ben.vigenteEm(e.mes)) continue;
      if (d.valor_empresa_centavos > 0) itens.push({ codigo: `BEN_${d.tipo.toUpperCase()}`.slice(0, 20), nome: d.nome, natureza: 'beneficio', referencia: null, valor_centavos: d.valor_empresa_centavos });
      if (d.desconto_funcionario_centavos > 0) itens.push({ codigo: `DESC_${d.tipo.toUpperCase()}`.slice(0, 20), nome: `Coparticipacao ${d.nome}`, natureza: 'desconto', referencia: null, valor_centavos: d.desconto_funcionario_centavos });
    }
    const valores = itens.filter((i) => i.valor_centavos > 0 || i.codigo === 'SALARIO');
    const descontos = soma(valores, 'desconto');
    const encargos = soma(valores, 'encargo');
    const beneficios = soma(valores, 'beneficio');
    return ok(new Holerite({
      id, competencia_id: e.competencia_id, funcionario_id: b.funcionario_id, funcionario_nome: b.nome, email: b.email, matricula: b.matricula,
      departamento_id: b.departamento_id, funcao_id: b.funcao_id, centro_custo_id: b.centro_custo_id, tipo_contrato: b.tipo_contrato,
      salario_base_centavos: b.salario_centavos, proventos_centavos: proventos, descontos_centavos: descontos, encargos_centavos: encargos,
      beneficios_centavos: beneficios, liquido_centavos: proventos - descontos, custo_centavos: proventos + encargos + beneficios,
      moeda: b.moeda, itens: valores, estado: 'calculado', envio_estado: 'nao_enviado', email_id: null, enviado_em: null,
    }));
  }

  static reidratar(d: HoleriteDados): Holerite {
    const n = (v: unknown) => Number(v);
    return new Holerite({
      ...d, salario_base_centavos: n(d.salario_base_centavos), proventos_centavos: n(d.proventos_centavos), descontos_centavos: n(d.descontos_centavos),
      encargos_centavos: n(d.encargos_centavos), beneficios_centavos: n(d.beneficios_centavos), liquido_centavos: n(d.liquido_centavos),
      custo_centavos: n(d.custo_centavos), itens: (d.itens ?? []).map((i) => ({ ...i, valor_centavos: n(i.valor_centavos) })),
    });
  }

  get id(): string { return this.d.id; }
  get estado(): HoleriteDados['estado'] { return this.d.estado; }

  fechar(): Result<Holerite> {
    if (this.d.estado === 'fechado') return fail(erroDe('transicao_invalida', 'Holerite ja fechado', 'estado', { permitidas: [] }));
    return ok(new Holerite({ ...this.d, estado: 'fechado' }));
  }

  /** Registra o envio pela fila (email_id) ou a falta de e-mail do funcionario. */
  registrarEnvio(emailId: string | null, quando: string): Result<Holerite> {
    if (this.d.estado !== 'fechado') return fail(erroDe('transicao_invalida', 'Holerite so e enviado depois do fechamento da competencia', 'estado'));
    if (!emailId) return ok(new Holerite({ ...this.d, envio_estado: 'sem_email' }));
    return ok(new Holerite({ ...this.d, envio_estado: 'na_fila', email_id: emailId, enviado_em: quando }));
  }

  paraDados(): HoleriteDados {
    return { ...this.d, itens: this.d.itens.map((i) => ({ ...i })) };
  }
}
