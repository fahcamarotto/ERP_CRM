/**
 * PDF do holerite (M8.4) sem dependencia externa: PDF 1.4 de uma pagina A4, fonte Helvetica,
 * texto ASCII (acentos removidos), xref com offsets exatos. Recebe os dados ja calculados.
 */
import type { HoleriteDados } from './holerite.ts';

export interface CabecalhoPdf {
  empresa: string;
  competencia: string; // AAAA-MM
  departamento: string | null;
  funcao: string | null;
}

const ascii = (s: string) => s.normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^\x20-\x7e]/g, ' ');
const esc = (s: string) => ascii(s).replace(/\\/g, '\\\\').replace(/\(/g, '\\(').replace(/\)/g, '\\)');

export function formatarCentavos(c: number): string {
  const neg = c < 0;
  const [int, dec] = (Math.abs(c) / 100).toFixed(2).split('.');
  return `${neg ? '-' : ''}${int!.replace(/\B(?=(\d{3})+(?!\d))/g, '.')},${dec}`;
}

export function gerarPdfHolerite(h: HoleriteDados, cab: CabecalhoPdf): Buffer {
  const linhas: string[] = [];
  let y = 800;
  const texto = (x: number, s: string, tam = 10, negrito = false) => linhas.push(`BT /${negrito ? 'F2' : 'F1'} ${tam} Tf ${x} ${y} Td (${esc(s)}) Tj ET`);
  const direita = (xFim: number, s: string, tam = 10, negrito = false) => texto(xFim - ascii(s).length * tam * 0.5, s, tam, negrito);
  const regua = () => { linhas.push(`0.5 w 40 ${y - 6} m 555 ${y - 6} l S`); };

  texto(40, cab.empresa, 14, true); y -= 18;
  texto(40, `Recibo de pagamento de salario, competencia ${cab.competencia}`, 10); y -= 24;
  texto(40, `Funcionario: ${h.funcionario_nome}`, 10, true);
  direita(555, `Matricula: ${h.matricula ?? '-'}`); y -= 14;
  texto(40, `Departamento: ${cab.departamento ?? '-'}`);
  direita(555, `Funcao: ${cab.funcao ?? '-'}`); y -= 14;
  texto(40, `Contrato: ${h.tipo_contrato.toUpperCase()}`);
  direita(555, `Salario base: ${formatarCentavos(h.salario_base_centavos)} ${h.moeda}`); y -= 10;
  regua(); y -= 20;
  texto(40, 'Codigo', 9, true); texto(120, 'Descricao', 9, true); texto(330, 'Referencia', 9, true);
  direita(470, 'Proventos', 9, true); direita(555, 'Descontos', 9, true); y -= 6;
  regua(); y -= 16;
  for (const i of h.itens.filter((x) => x.natureza === 'provento' || x.natureza === 'desconto')) {
    texto(40, i.codigo, 9); texto(120, i.nome.slice(0, 40), 9); texto(330, i.referencia ?? '', 9);
    if (i.natureza === 'provento') direita(470, formatarCentavos(i.valor_centavos), 9);
    else direita(555, formatarCentavos(i.valor_centavos), 9);
    y -= 14;
    if (y < 160) break;
  }
  regua(); y -= 18;
  texto(330, 'Totais', 10, true);
  direita(470, formatarCentavos(h.proventos_centavos), 10, true);
  direita(555, formatarCentavos(h.descontos_centavos), 10, true); y -= 22;
  texto(330, 'Valor liquido', 12, true);
  direita(555, `${formatarCentavos(h.liquido_centavos)} ${h.moeda}`, 12, true); y -= 30;
  const encargos = h.itens.filter((x) => x.natureza === 'encargo' || x.natureza === 'beneficio');
  if (encargos.length) {
    texto(40, 'Encargos e beneficios pagos pela empresa (nao descontados)', 9, true); y -= 14;
    for (const i of encargos) { texto(40, `${i.nome}`, 9); direita(555, formatarCentavos(i.valor_centavos), 9); y -= 12; if (y < 80) break; }
  }
  y = 60;
  texto(40, 'Documento gerado pelo ERP. Valores em centavos convertidos para moeda com duas casas.', 7);

  const conteudo = linhas.join('\n');
  const objetos = [
    '<< /Type /Catalog /Pages 2 0 R >>',
    '<< /Type /Pages /Kids [3 0 R] /Count 1 >>',
    '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 4 0 R /F2 5 0 R >> >> /Contents 6 0 R >>',
    '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>',
    '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>',
    `<< /Length ${conteudo.length} >>\nstream\n${conteudo}\nendstream`,
  ];
  let pdf = '%PDF-1.4\n';
  const offsets: number[] = [];
  objetos.forEach((o, i) => { offsets.push(pdf.length); pdf += `${i + 1} 0 obj\n${o}\nendobj\n`; });
  const xref = pdf.length;
  pdf += `xref\n0 ${objetos.length + 1}\n0000000000 65535 f \n${offsets.map((o) => `${String(o).padStart(10, '0')} 00000 n \n`).join('')}`;
  pdf += `trailer\n<< /Size ${objetos.length + 1} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF\n`;
  return Buffer.from(pdf, 'latin1');
}
