/** EnviarHolerite (M8.4): reenvia o holerite de uma competencia fechada por e-mail, pela fila do nucleo. */
import type { ContextoCaso } from '../../compartilhado/efeitos.ts';
import { erroDe, fail, ok, type Result } from '../../compartilhado/result.ts';
import type { Correio, GravarHolerites, ObterHolerite, Relogio } from '../../competencia/model/portas.ts';

export class EnviarHolerite {
  constructor(private readonly deps: { holerites: ObterHolerite & Pick<GravarHolerites, 'atualizarHolerite'>; correio: Correio; relogio: Relogio; competenciaDe: (id: string) => Promise<string | null> }) {}
  async execute(ctx: ContextoCaso, e: { id: string }): Promise<Result<{ email_id: string | null }>> {
    const h = await this.deps.holerites.obterHolerite(e.id);
    if (!h) return fail(erroDe('nao_encontrado', 'Holerite nao encontrado'));
    const d = h.paraDados();
    if (d.estado !== 'fechado') return fail(erroDe('transicao_invalida', 'Holerite so e enviado depois do fechamento da competencia', 'estado'));
    if (!d.email) return fail(erroDe('sem_email', 'Funcionario sem e-mail no Pessoas', 'email'));
    const mes = (await this.deps.competenciaDe(d.competencia_id)) ?? '';
    const emailId = await this.deps.correio.enviarHolerite(d, mes.slice(0, 7));
    const r = h.registrarEnvio(emailId, this.deps.relogio.agora());
    if (!r.ok) return r;
    await this.deps.holerites.atualizarHolerite(r.valor);
    await ctx.efeitos.auditar('holerite.enviar', 'folha_holerites', e.id, { envio_estado: d.envio_estado }, { envio_estado: r.valor.paraDados().envio_estado, email_id: emailId });
    await ctx.efeitos.nota('folha_holerites', e.id, 'Holerite enviado para a fila de e-mail.');
    return ok({ email_id: emailId });
  }
}
