/** Objeto de valor Dinheiro: centavos inteiros (nunca float) e moeda ISO 4217. */
import { erroDe, fail, ok, type Result } from './result.ts';

export class Dinheiro {
  private constructor(readonly centavos: number, readonly moeda: string) {}

  /** Aceita centavos inteiros nao negativos. `campo` aparece no erro. */
  static tryCreate(centavos: unknown, moeda = 'BRL', campo = 'valor_centavos'): Result<Dinheiro> {
    const m = String(moeda ?? '').toUpperCase();
    if (!/^[A-Z]{3}$/.test(m)) return fail(erroDe('moeda_invalida', 'Moeda em ISO 4217 (BRL, USD, EUR)', 'moeda'));
    if (typeof centavos !== 'number' || !Number.isSafeInteger(centavos) || centavos < 0) {
      return fail(erroDe('valor_invalido', 'Valor em centavos deve ser inteiro e nao negativo', campo));
    }
    return ok(new Dinheiro(centavos, m));
  }

  static create(centavos: number, moeda = 'BRL'): Dinheiro {
    const r = Dinheiro.tryCreate(centavos, moeda);
    if (!r.ok) throw new Error(r.erros[0]!.mensagem);
    return r.valor;
  }
}

/** Arredondamento bancario simples para centavos (meio para cima). */
export const arredondar = (v: number): number => Math.round(v + Number.EPSILON);
