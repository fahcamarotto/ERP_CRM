/** Consultas de leitura do EventoFolha. */
import type pg from 'pg';
import { decodificarCursor, pagina } from '../../compartilhado/cursor.ts';

const RESUMO = `e.id, e.codigo, e.nome, e.natureza, e.recorrencia, e.calculo, e.valor_centavos::float8 AS valor_centavos,
  e.percentual::float8 AS percentual, e.funcionario_id, f.nome AS funcionario_nome, e.tipos_contrato, e.estado, e.descricao, e.created_at, e.updated_at`;

export interface FiltroEventos {
  natureza?: string;
  recorrencia?: string;
  estado?: 'ativo' | 'arquivado' | 'todos';
  busca?: string;
  limite?: number;
  cursor?: string;
}

export async function listarEventos(c: pg.PoolClient, f: FiltroEventos) {
  const lim = Math.min(Math.max(f.limite ?? 50, 1), 200);
  const cur = decodificarCursor(f.cursor);
  const estado = f.estado === 'todos' ? null : (f.estado ?? 'ativo');
  const r = await c.query(
    `SELECT ${RESUMO} FROM folha_eventos e LEFT JOIN pessoas_funcionarios f ON f.id = e.funcionario_id
     WHERE e.deleted_at IS NULL AND ($1::text IS NULL OR e.natureza = $1) AND ($2::text IS NULL OR e.recorrencia = $2)
       AND ($3::text IS NULL OR e.estado = $3) AND ($4::text IS NULL OR e.nome ILIKE '%' || $4 || '%' OR e.codigo ILIKE '%' || $4 || '%')
       AND ($5::timestamptz IS NULL OR (e.created_at, e.id) > ($5::timestamptz, $6::uuid))
     ORDER BY e.created_at, e.id LIMIT $7`,
    [f.natureza ?? null, f.recorrencia ?? null, estado, f.busca?.trim() || null, cur?.[0] ?? null, cur?.[1] ?? null, lim + 1],
  );
  return pagina(r.rows, lim);
}

export async function obterEvento(c: pg.PoolClient, id: string) {
  return (await c.query(`SELECT ${RESUMO} FROM folha_eventos e LEFT JOIN pessoas_funcionarios f ON f.id = e.funcionario_id WHERE e.id = $1 AND e.deleted_at IS NULL`, [id])).rows[0] ?? null;
}
