/** Portas do repositorio do agregado EventoFolha, segregadas por operacao. */
import type { EventoFolha } from './evento-folha.ts';

export interface ObterEventoFolha {
  obterPorId(id: string): Promise<EventoFolha | null>;
  buscarPorCodigo(codigo: string): Promise<EventoFolha | null>;
}

export interface GravarEventoFolha {
  inserir(e: EventoFolha): Promise<void>;
  atualizar(e: EventoFolha): Promise<void>;
}

export interface ConsultarReferenciasEvento {
  funcionarioAtivo(id: string): Promise<boolean>;
}
