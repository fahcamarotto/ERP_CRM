/**
 * Entidade EventoFolha (M8.2): rubrica de provento, desconto ou encargo, fixa ou variavel.
 * Calculo por valor (centavos), percentual sobre os proventos ou pelas tabelas de INSS e IRRF.
 * Fixo entra em toda competencia (para todos ou para um funcionario); variavel so com lancamento na competencia.
 */
import { randomUUID } from 'node:crypto';
import { Dinheiro } from '../../compartilhado/dinheiro.ts';
import { erroDe, fail, ok, type ErroDominio, type Result } from '../../compartilhado/result.ts';

export const NATUREZAS = ['provento', 'desconto', 'encargo'] as const;
export type Natureza = (typeof NATUREZAS)[number];
export const RECORRENCIAS = ['fixo', 'variavel'] as const;
export type Recorrencia = (typeof RECORRENCIAS)[number];
export const CALCULOS = ['valor', 'percentual', 'tabela_inss', 'tabela_irrf'] as const;
export type Calculo = (typeof CALCULOS)[number];
export const TIPOS_CONTRATO = ['clt', 'pj', 'estagio', 'temporario', 'aprendiz', 'autonomo'] as const;
export type TipoContrato = (typeof TIPOS_CONTRATO)[number];
export const ESTADOS_EVENTO = ['ativo', 'arquivado'] as const;
export type EstadoEvento = (typeof ESTADOS_EVENTO)[number];

export interface DadosEventoFolha {
  codigo: string;
  nome: string;
  natureza: Natureza;
  recorrencia: Recorrencia;
  calculo: Calculo;
  valor_centavos?: number | null;
  percentual?: number | null;
  funcionario_id?: string | null;
  tipos_contrato?: TipoContrato[];
  descricao?: string | null;
}

export interface EventoFolhaDados {
  id: string;
  codigo: string;
  nome: string;
  natureza: Natureza;
  recorrencia: Recorrencia;
  calculo: Calculo;
  valor_centavos: number | null;
  percentual: number | null;
  funcionario_id: string | null;
  tipos_contrato: TipoContrato[];
  estado: EstadoEvento;
  descricao: string | null;
}

const t = (v?: string | null) => (v ?? '').trim() || null;

function validar(d: EventoFolhaDados): ErroDominio[] {
  const e: ErroDominio[] = [];
  if (!/^[A-Z0-9_]{2,20}$/.test(d.codigo)) e.push(erroDe('codigo_invalido', 'Codigo com 2 a 20 letras maiusculas, digitos ou _', 'codigo'));
  if (d.nome.length < 2 || d.nome.length > 120) e.push(erroDe('nome_invalido', 'Nome deve ter de 2 a 120 caracteres', 'nome'));
  if (!NATUREZAS.includes(d.natureza)) e.push(erroDe('natureza_invalida', 'Natureza deve ser provento, desconto ou encargo', 'natureza'));
  if (!RECORRENCIAS.includes(d.recorrencia)) e.push(erroDe('recorrencia_invalida', 'Recorrencia deve ser fixo ou variavel', 'recorrencia'));
  if (!CALCULOS.includes(d.calculo)) e.push(erroDe('calculo_invalido', 'Calculo invalido', 'calculo'));
  if (d.calculo === 'valor' && d.recorrencia === 'fixo') {
    const r = Dinheiro.tryCreate(d.valor_centavos);
    if (!r.ok) e.push(...r.erros);
  }
  if (d.calculo === 'percentual' && (d.percentual === null || !Number.isFinite(d.percentual) || d.percentual < 0 || d.percentual > 100)) {
    e.push(erroDe('percentual_invalido', 'Percentual entre 0 e 100', 'percentual'));
  }
  if ((d.calculo === 'tabela_inss' || d.calculo === 'tabela_irrf') && (d.natureza !== 'desconto' || d.recorrencia !== 'fixo')) {
    e.push(erroDe('calculo_invalido', 'Tabela de INSS ou IRRF so vale para desconto fixo', 'calculo'));
  }
  if (d.recorrencia === 'variavel' && d.funcionario_id) e.push(erroDe('alvo_invalido', 'Evento variavel e lancado por funcionario na competencia', 'funcionario_id'));
  if (d.tipos_contrato.some((x) => !TIPOS_CONTRATO.includes(x))) e.push(erroDe('tipo_contrato_invalido', 'Tipo de contrato invalido', 'tipos_contrato'));
  return e;
}

export class EventoFolha {
  private constructor(private readonly d: EventoFolhaDados) {}

  static tryCreate(e: DadosEventoFolha, id: string = randomUUID()): Result<EventoFolha> {
    const d: EventoFolhaDados = {
      id, codigo: (e.codigo ?? '').trim().toUpperCase(), nome: (e.nome ?? '').trim(), natureza: e.natureza, recorrencia: e.recorrencia,
      calculo: e.calculo,
      valor_centavos: e.calculo === 'valor' ? (e.valor_centavos ?? null) : null,
      percentual: e.calculo === 'percentual' ? (e.percentual === undefined || e.percentual === null ? null : Number(e.percentual)) : null,
      funcionario_id: t(e.funcionario_id), tipos_contrato: [...new Set(e.tipos_contrato ?? [])], estado: 'ativo', descricao: t(e.descricao),
    };
    const erros = validar(d);
    return erros.length ? fail(...erros) : ok(new EventoFolha(d));
  }

  static create(e: DadosEventoFolha, id?: string): EventoFolha {
    const r = EventoFolha.tryCreate(e, id);
    if (!r.ok) throw new Error(r.erros.map((x) => x.mensagem).join('; '));
    return r.valor;
  }

  static reidratar(d: EventoFolhaDados): EventoFolha {
    return new EventoFolha({
      ...d, valor_centavos: d.valor_centavos === null ? null : Number(d.valor_centavos),
      percentual: d.percentual === null ? null : Number(d.percentual), tipos_contrato: [...(d.tipos_contrato ?? [])],
    });
  }

  get id(): string { return this.d.id; }
  get codigo(): string { return this.d.codigo; }
  get estado(): EstadoEvento { return this.d.estado; }

  /** O evento vale para este tipo de contrato (lista vazia = todos). */
  aplicaA(tipoContrato: string): boolean {
    return this.d.tipos_contrato.length === 0 || (this.d.tipos_contrato as string[]).includes(tipoContrato);
  }

  editar(e: Partial<DadosEventoFolha>): Result<EventoFolha> {
    if (this.d.estado === 'arquivado') return fail(erroDe('transicao_invalida', 'Evento arquivado nao pode ser editado'));
    const tem = (k: keyof DadosEventoFolha) => e[k] !== undefined;
    const calculo = tem('calculo') ? e.calculo! : this.d.calculo;
    const n: EventoFolhaDados = {
      ...this.d,
      codigo: tem('codigo') ? (e.codigo ?? '').trim().toUpperCase() : this.d.codigo,
      nome: tem('nome') ? (e.nome ?? '').trim() : this.d.nome,
      natureza: tem('natureza') ? e.natureza! : this.d.natureza,
      recorrencia: tem('recorrencia') ? e.recorrencia! : this.d.recorrencia,
      calculo,
      valor_centavos: calculo === 'valor' ? (tem('valor_centavos') ? (e.valor_centavos ?? null) : this.d.valor_centavos) : null,
      percentual: calculo === 'percentual' ? (tem('percentual') ? (e.percentual === null ? null : Number(e.percentual)) : this.d.percentual) : null,
      funcionario_id: tem('funcionario_id') ? t(e.funcionario_id) : this.d.funcionario_id,
      tipos_contrato: tem('tipos_contrato') ? [...new Set(e.tipos_contrato!)] : [...this.d.tipos_contrato],
      descricao: tem('descricao') ? t(e.descricao) : this.d.descricao,
    };
    const erros = validar(n);
    return erros.length ? fail(...erros) : ok(new EventoFolha(n));
  }

  arquivar(): Result<EventoFolha> {
    if (this.d.estado === 'arquivado') return fail(erroDe('transicao_invalida', 'Evento ja arquivado', 'estado', { permitidas: ['ativo'] }));
    return ok(new EventoFolha({ ...this.d, estado: 'arquivado' }));
  }

  reativar(): Result<EventoFolha> {
    if (this.d.estado === 'ativo') return fail(erroDe('transicao_invalida', 'Evento ja ativo', 'estado', { permitidas: ['arquivado'] }));
    return ok(new EventoFolha({ ...this.d, estado: 'ativo' }));
  }

  paraDados(): EventoFolhaDados {
    return { ...this.d, tipos_contrato: [...this.d.tipos_contrato] };
  }
}
