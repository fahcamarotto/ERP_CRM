/** Casos de uso do EventoFolha (M8.2): CriarEventoFolha, EditarEventoFolha e ArquivarEventoFolha (arquivar ou reativar). */
import type { ContextoCaso } from '../../compartilhado/efeitos.ts';
import { erroDe, fail, ok, okVazio, type Result } from '../../compartilhado/result.ts';
import { EventoFolha, type DadosEventoFolha } from '../model/evento-folha.ts';
import type { ConsultarReferenciasEvento, GravarEventoFolha, ObterEventoFolha } from '../model/portas.ts';

const TABELA = 'folha_eventos';

export interface DepsEvento {
  repo: ObterEventoFolha & GravarEventoFolha;
  refs: ConsultarReferenciasEvento;
}

export class CriarEventoFolha {
  constructor(private readonly deps: DepsEvento) {}
  async execute(ctx: ContextoCaso, e: DadosEventoFolha): Promise<Result<{ id: string }>> {
    const r = EventoFolha.tryCreate(e);
    if (!r.ok) return r;
    const d = r.valor.paraDados();
    const existente = await this.deps.repo.buscarPorCodigo(d.codigo);
    if (existente) return fail(erroDe('conflito', `Ja existe evento com o codigo ${d.codigo}`, 'codigo', { evento_id: existente.id }));
    if (d.funcionario_id && !(await this.deps.refs.funcionarioAtivo(d.funcionario_id))) {
      return fail(erroDe('funcionario_invalido', 'Funcionario nao encontrado ou desligado', 'funcionario_id'));
    }
    await this.deps.repo.inserir(r.valor);
    await ctx.efeitos.auditar('evento_folha.criar', TABELA, d.id, undefined, d);
    return ok({ id: d.id });
  }
}

export class EditarEventoFolha {
  constructor(private readonly deps: DepsEvento) {}
  async execute(ctx: ContextoCaso, e: { id: string } & Partial<DadosEventoFolha>): Promise<Result<void>> {
    const { id, ...mud } = e;
    const atual = await this.deps.repo.obterPorId(id);
    if (!atual) return fail(erroDe('nao_encontrado', 'Evento de folha nao encontrado'));
    const r = atual.editar(mud);
    if (!r.ok) return r;
    const d = r.valor.paraDados();
    if (d.codigo !== atual.codigo) {
      const outro = await this.deps.repo.buscarPorCodigo(d.codigo);
      if (outro && outro.id !== id) return fail(erroDe('conflito', `Ja existe evento com o codigo ${d.codigo}`, 'codigo', { evento_id: outro.id }));
    }
    if (d.funcionario_id && d.funcionario_id !== atual.paraDados().funcionario_id && !(await this.deps.refs.funcionarioAtivo(d.funcionario_id))) {
      return fail(erroDe('funcionario_invalido', 'Funcionario nao encontrado ou desligado', 'funcionario_id'));
    }
    await this.deps.repo.atualizar(r.valor);
    const antes = atual.paraDados() as unknown as Record<string, unknown>;
    const depois = d as unknown as Record<string, unknown>;
    await ctx.efeitos.historico(TABELA, id, antes, depois);
    await ctx.efeitos.auditar('evento_folha.editar', TABELA, id, antes, depois);
    return okVazio();
  }
}

export class ArquivarEventoFolha {
  constructor(private readonly deps: { repo: ObterEventoFolha & GravarEventoFolha }) {}
  async execute(ctx: ContextoCaso, e: { id: string; arquivar: boolean }): Promise<Result<void>> {
    const atual = await this.deps.repo.obterPorId(e.id);
    if (!atual) return fail(erroDe('nao_encontrado', 'Evento de folha nao encontrado'));
    const r = e.arquivar ? atual.arquivar() : atual.reativar();
    if (!r.ok) return r;
    await this.deps.repo.atualizar(r.valor);
    await ctx.efeitos.historico(TABELA, e.id, { estado: atual.estado }, { estado: r.valor.estado });
    await ctx.efeitos.auditar(e.arquivar ? 'evento_folha.arquivar' : 'evento_folha.reativar', TABELA, e.id, { estado: atual.estado }, { estado: r.valor.estado });
    return okVazio();
  }
}
