/** Rotas REST do EventoFolha fora das tools: ficha, edicao, arquivar e reativar. */
import { esquemaErro, requer, type FastifyInstance } from '@erp/api/sdk';
import { naTransacao, naoEncontrado } from '../borda.ts';
import { exigirOk } from '../compartilhado/result.ts';
import { propsEvento, uuid } from '../esquemas.ts';
import type { DadosEventoFolha } from './model/evento-folha.ts';
import { obterEvento } from './query/eventos.ts';

const tags = ['folha'];
const erros = { 400: esquemaErro, 403: esquemaErro, 404: esquemaErro, 409: esquemaErro };
const paramId = { type: 'object', required: ['id'], properties: { id: uuid } } as const;

export function rotasEvento(app: FastifyInstance): void {
  app.get<{ Params: { id: string } }>('/eventos/:id', {
    preHandler: requer('folha.ver'),
    schema: { tags, summary: 'Ficha do evento de folha', params: paramId, response: { 404: esquemaErro } },
  }, (req) => naTransacao(req, async (_, __, c) => (await obterEvento(c, req.params.id)) ?? Promise.reject(naoEncontrado('Evento de folha nao encontrado'))));

  app.patch<{ Params: { id: string }; Body: Partial<DadosEventoFolha> }>('/eventos/:id', {
    preHandler: requer('folha.editar'),
    schema: { tags, summary: 'Edita evento de folha (EditarEventoFolha)', params: paramId, body: { type: 'object', additionalProperties: false, properties: propsEvento }, response: erros },
  }, (req) => naTransacao(req, async (casos, ctx, c) => {
    exigirOk(await casos.editarEvento.execute(ctx, { ...req.body, id: req.params.id }));
    return obterEvento(c, req.params.id);
  }));

  app.post<{ Params: { id: string }; Body: { estado: 'ativo' | 'arquivado' } }>('/eventos/:id/estado', {
    preHandler: requer('folha.editar'),
    schema: {
      tags, summary: 'Arquiva ou reativa evento de folha (ArquivarEventoFolha)', params: paramId, response: erros,
      body: { type: 'object', additionalProperties: false, required: ['estado'], properties: { estado: { type: 'string', enum: ['ativo', 'arquivado'] } } },
    },
  }, (req) => naTransacao(req, async (casos, ctx, c) => {
    exigirOk(await casos.arquivarEvento.execute(ctx, { id: req.params.id, arquivar: req.body.estado === 'arquivado' }));
    return obterEvento(c, req.params.id);
  }));
}
