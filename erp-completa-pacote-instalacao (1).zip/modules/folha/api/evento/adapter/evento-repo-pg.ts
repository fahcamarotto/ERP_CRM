/** Adaptador Postgres das portas do agregado EventoFolha. */
import type pg from 'pg';
import { EventoFolha, type EventoFolhaDados } from '../model/evento-folha.ts';
import type { ConsultarReferenciasEvento, GravarEventoFolha, ObterEventoFolha } from '../model/portas.ts';

export const COLUNAS_EVENTO = `id, codigo, nome, natureza, recorrencia, calculo, valor_centavos::float8 AS valor_centavos, percentual::float8 AS percentual,
  funcionario_id, tipos_contrato, estado, descricao`;

export class EventoFolhaRepoPg implements ObterEventoFolha, GravarEventoFolha, ConsultarReferenciasEvento {
  constructor(private readonly c: pg.PoolClient) {}

  async obterPorId(id: string): Promise<EventoFolha | null> {
    const r = await this.c.query(`SELECT ${COLUNAS_EVENTO} FROM folha_eventos WHERE id = $1 AND deleted_at IS NULL`, [id]);
    return r.rows[0] ? EventoFolha.reidratar(r.rows[0] as EventoFolhaDados) : null;
  }

  async buscarPorCodigo(codigo: string): Promise<EventoFolha | null> {
    const r = await this.c.query(`SELECT ${COLUNAS_EVENTO} FROM folha_eventos WHERE codigo = $1 AND deleted_at IS NULL`, [codigo]);
    return r.rows[0] ? EventoFolha.reidratar(r.rows[0] as EventoFolhaDados) : null;
  }

  /** Eventos ativos (para o calculo da competencia). */
  async ativos(): Promise<EventoFolha[]> {
    const r = await this.c.query(`SELECT ${COLUNAS_EVENTO} FROM folha_eventos WHERE estado = 'ativo' AND deleted_at IS NULL ORDER BY codigo`);
    return r.rows.map((x) => EventoFolha.reidratar(x as EventoFolhaDados));
  }

  async inserir(e: EventoFolha): Promise<void> {
    const d = e.paraDados();
    await this.c.query(
      `INSERT INTO folha_eventos (id, codigo, nome, natureza, recorrencia, calculo, valor_centavos, percentual, funcionario_id, tipos_contrato, estado, descricao, creator_id)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, nucleo_usuario_atual())`,
      [d.id, d.codigo, d.nome, d.natureza, d.recorrencia, d.calculo, d.valor_centavos, d.percentual, d.funcionario_id, d.tipos_contrato, d.estado, d.descricao],
    );
  }

  async atualizar(e: EventoFolha): Promise<void> {
    const d = e.paraDados();
    await this.c.query(
      `UPDATE folha_eventos SET codigo = $2, nome = $3, natureza = $4, recorrencia = $5, calculo = $6, valor_centavos = $7, percentual = $8,
         funcionario_id = $9, tipos_contrato = $10, estado = $11, descricao = $12 WHERE id = $1 AND deleted_at IS NULL`,
      [d.id, d.codigo, d.nome, d.natureza, d.recorrencia, d.calculo, d.valor_centavos, d.percentual, d.funcionario_id, d.tipos_contrato, d.estado, d.descricao],
    );
  }

  async funcionarioAtivo(id: string): Promise<boolean> {
    const r = await this.c.query("SELECT 1 FROM pessoas_funcionarios WHERE id = $1 AND deleted_at IS NULL AND estado <> 'desligado'", [id]);
    return (r.rowCount ?? 0) > 0;
  }
}
