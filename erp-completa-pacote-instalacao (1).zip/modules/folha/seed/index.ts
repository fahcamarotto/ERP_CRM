/**
 * Seed demo da Folha: rubricas (INSS, IRRF, FGTS, encargos e variaveis), beneficios por funcao e por funcionario,
 * centro de custo por departamento e tres competencias (fechada, calculada e aberta com variaveis).
 * Idempotente por id deterministico. Grava pelas entidades e adaptadores do modulo, sem publicar evento.
 * Funcionarios, funcoes, departamentos e centros de custo so por SELECT das tabelas publicadas (Pessoas e Financeiro).
 */
import { createHash } from 'node:crypto';
import type { SeedModulo } from '@erp/api/sdk/puro';
import { BeneficioRepoPg } from '../api/beneficio/adapter/beneficio-repo-pg.ts';
import { Beneficio, type DadosBeneficio } from '../api/beneficio/model/beneficio.ts';
import { CompetenciaRepoPg } from '../api/competencia/adapter/competencia-repo-pg.ts';
import { Competencia, ratear, totalizar } from '../api/competencia/model/competencia.ts';
import { EventoFolhaRepoPg } from '../api/evento/adapter/evento-repo-pg.ts';
import { EventoFolha, type DadosEventoFolha } from '../api/evento/model/evento-folha.ts';
import { Holerite } from '../api/holerite/model/holerite.ts';

function idDe(chave: string): string {
  const h = createHash('sha256').update(`folha-demo:${chave}`).digest('hex');
  return `${h.slice(0, 8)}-${h.slice(8, 12)}-4${h.slice(13, 16)}-a${h.slice(17, 20)}-${h.slice(20, 32)}`;
}

const CLT = ['clt', 'temporario', 'aprendiz'] as const;

const EVENTOS: (DadosEventoFolha & { k: string })[] = [
  { k: 'inss', codigo: 'INSS', nome: 'INSS', natureza: 'desconto', recorrencia: 'fixo', calculo: 'tabela_inss', tipos_contrato: [...CLT], descricao: 'Tabela progressiva 2026' },
  { k: 'irrf', codigo: 'IRRF', nome: 'Imposto de renda retido', natureza: 'desconto', recorrencia: 'fixo', calculo: 'tabela_irrf', tipos_contrato: [...CLT, 'estagio'], descricao: 'Tabela mensal 2026 com redutor da Lei 15.270/2025' },
  { k: 'fgts', codigo: 'FGTS', nome: 'FGTS', natureza: 'encargo', recorrencia: 'fixo', calculo: 'percentual', percentual: 8, tipos_contrato: ['clt', 'temporario'] },
  { k: 'fgts-apr', codigo: 'FGTS_APR', nome: 'FGTS aprendiz', natureza: 'encargo', recorrencia: 'fixo', calculo: 'percentual', percentual: 2, tipos_contrato: ['aprendiz'] },
  { k: 'inss-pat', codigo: 'INSS_PAT', nome: 'INSS patronal', natureza: 'encargo', recorrencia: 'fixo', calculo: 'percentual', percentual: 20, tipos_contrato: [...CLT] },
  { k: 'he50', codigo: 'HE50', nome: 'Horas extras 50%', natureza: 'provento', recorrencia: 'variavel', calculo: 'valor' },
  { k: 'comissao', codigo: 'COMISSAO', nome: 'Comissão sobre vendas', natureza: 'provento', recorrencia: 'variavel', calculo: 'valor' },
  { k: 'faltas', codigo: 'FALTAS', nome: 'Faltas e atrasos', natureza: 'desconto', recorrencia: 'variavel', calculo: 'valor' },
  { k: 'adiant', codigo: 'ADIANT', nome: 'Adiantamento salarial', natureza: 'desconto', recorrencia: 'variavel', calculo: 'valor' },
];

const MAPA_CENTRO: [RegExp, string][] = [[/comerc/i, 'COM'], [/opera/i, 'OPE'], [/tecno|ti\b/i, 'TI'], [/.*/, 'ADM']];

const semear: SeedModulo = async ({ c, log }) => {
  const eventos = new EventoFolhaRepoPg(c);
  const beneficios = new BeneficioRepoPg(c);
  const comp = new CompetenciaRepoPg(c);
  let novos = 0;

  for (const { k, ...e } of EVENTOS) {
    const id = idDe(`evento:${k}`);
    if ((await eventos.obterPorId(id)) || (await eventos.buscarPorCodigo(e.codigo))) continue;
    await eventos.inserir(EventoFolha.create(e, id));
    novos++;
  }

  const funcionarios = (await c.query(
    `SELECT f.id, f.nome, f.funcao_id FROM pessoas_funcionarios f JOIN pessoas_contratos ct ON ct.funcionario_id = f.id AND ct.estado = 'vigente' AND ct.deleted_at IS NULL
     WHERE f.deleted_at IS NULL AND f.estado <> 'desligado' ORDER BY ct.salario DESC, f.nome`)).rows as { id: string; nome: string; funcao_id: string | null }[];
  const funcoes = [...new Set(funcionarios.map((f) => f.funcao_id).filter((x): x is string => !!x))];

  // Gratificacao fixa do funcionario de maior salario
  if (funcionarios[0]) {
    const id = idDe('evento:grat');
    if (!(await eventos.obterPorId(id)) && !(await eventos.buscarPorCodigo('GRAT_FUNCAO'))) {
      await eventos.inserir(EventoFolha.create({ codigo: 'GRAT_FUNCAO', nome: 'Gratificação de função', natureza: 'provento', recorrencia: 'fixo', calculo: 'valor', valor_centavos: 150000, funcionario_id: funcionarios[0].id }, id));
      novos++;
    }
  }

  const bens: (DadosBeneficio & { k: string })[] = [
    ...funcoes.map((f, i) => ({ k: `vr:${f}`, nome: 'Vale refeição', tipo: 'vale_refeicao' as const, abrangencia: 'funcao' as const, funcao_id: f, valor_empresa_centavos: 66000, desconto_funcionario_centavos: 3300, inicio: '2026-01-01', observacoes: i === 0 ? 'R$ 30 por dia útil' : null })),
    ...funcoes.slice(0, 3).map((f) => ({ k: `saude:${f}`, nome: 'Plano de saúde enfermaria', tipo: 'plano_saude' as const, abrangencia: 'funcao' as const, funcao_id: f, valor_empresa_centavos: 48000, desconto_funcionario_centavos: 9600, inicio: '2026-01-01' })),
    ...funcionarios.slice(-2).map((f) => ({ k: `vt:${f.id}`, nome: 'Vale transporte', tipo: 'vale_transporte' as const, abrangencia: 'funcionario' as const, funcionario_id: f.id, valor_empresa_centavos: 35200, desconto_funcionario_centavos: 10800, inicio: '2026-03-01' })),
  ];
  for (const { k, ...b } of bens) {
    const id = idDe(`beneficio:${k}`);
    if (await beneficios.obterPorId(id)) continue;
    await beneficios.inserir(Beneficio.create(b, id));
    novos++;
  }

  // Centro de custo por departamento (so cria o que falta)
  const centros = (await c.query('SELECT id, codigo FROM financeiro_centros_custo WHERE deleted_at IS NULL AND ativo')).rows as { id: string; codigo: string }[];
  const deps = (await c.query(
    `SELECT d.id, d.nome FROM pessoas_departamentos d WHERE d.deleted_at IS NULL
       AND NOT EXISTS (SELECT 1 FROM folha_centros_departamento cd WHERE cd.departamento_id = d.id)`)).rows as { id: string; nome: string }[];
  for (const d of deps) {
    const codigo = MAPA_CENTRO.find(([re]) => re.test(d.nome))![1];
    const centro = centros.find((x) => x.codigo === codigo) ?? centros[0];
    if (!centro) break;
    await comp.definirCentro(d.id, centro.id);
    novos++;
  }

  if (!funcionarios.length) {
    log(`${novos} registro(s) demo novo(s) (sem funcionários com contrato vigente: competências não semeadas)`);
    return;
  }

  // Competencias: 2026-08 fechada, 2026-09 calculada, 2026-10 aberta com variaveis
  const agora = new Date().toISOString();
  const calcular = async (c0: Competencia) => {
    const base = await comp.funcionariosComContrato();
    const [evs, bns, vars] = await Promise.all([comp.eventosAtivos(), comp.beneficiosAtivos(), comp.variaveisDa(c0.id)]);
    const hs: Holerite[] = base.map((b) => {
      const r = Holerite.calcular({ competencia_id: c0.id, mes: c0.mes, base: b, eventos: evs, beneficios: bns, variaveis: vars }, idDe(`holerite:${c0.mes}:${b.funcionario_id}`));
      if (!r.ok) throw new Error(r.erros[0]!.mensagem);
      return r.valor;
    });
    await comp.substituirHolerites(c0.id, hs);
    const r = c0.aplicarCalculo(totalizar(hs.map((h) => h.paraDados())), agora);
    if (!r.ok) throw new Error(r.erros[0]!.mensagem);
    await comp.atualizar(r.valor);
    return { comp: r.valor, hs };
  };
  const variavel = async (cid: string, k: string, f: { id: string } | undefined, evento: string, valor: number, referencia: string) => {
    const ev = await eventos.buscarPorCodigo(evento);
    if (!f || !ev) return;
    await comp.inserirVariavel({ id: idDe(`variavel:${cid}:${k}`), competencia_id: cid, funcionario_id: f.id, evento_id: ev.id, valor_centavos: valor, referencia });
  };
  const PLANO: { mes: string; pagamento: string; final: 'fechada' | 'calculada' | 'aberta' }[] = [
    { mes: '2026-08-01', pagamento: '2026-09-05', final: 'fechada' },
    { mes: '2026-09-01', pagamento: '2026-10-05', final: 'calculada' },
    { mes: '2026-10-01', pagamento: '2026-11-05', final: 'aberta' },
  ];
  for (const p of PLANO) {
    const id = idDe(`competencia:${p.mes}`);
    if ((await comp.obterPorId(id)) || (await comp.buscarPorMes(p.mes))) continue;
    const nova = Competencia.create({ mes: p.mes, pagamento: p.pagamento }, id);
    await comp.inserir(nova);
    novos++;
    await variavel(id, 'he', funcionarios[2], 'HE50', 42000 + PLANO.indexOf(p) * 5000, '8h');
    await variavel(id, 'com', funcionarios[1], 'COMISSAO', 180000, 'vendas do mês');
    if (p.final !== 'fechada') await variavel(id, 'falta', funcionarios[funcionarios.length - 1], 'FALTAS', 8500, '1 dia');
    if (p.final === 'aberta') continue;
    const { comp: calc, hs } = await calcular(nova);
    if (p.final === 'calculada') continue;
    const conferida = calc.conferir(null, agora);
    const fechando = conferida.ok ? conferida.valor.iniciarFechamento(idDe(`job:${p.mes}`)) : conferida;
    const fechada = fechando.ok ? fechando.valor.concluirFechamento(agora) : fechando;
    if (!fechada.ok) throw new Error(fechada.erros[0]!.mensagem);
    const fechados = hs.map((h) => { const r = h.fechar(); if (!r.ok) throw new Error(r.erros[0]!.mensagem); return r.valor; });
    for (const h of fechados) await comp.atualizarHolerite(h);
    await comp.gravarRateios(id, ratear(fechados.map((h) => h.paraDados())), 'BRL');
    await comp.atualizar(fechada.valor);
  }

  log(`${novos} registro(s) demo novo(s) (${EVENTOS.length + 1} eventos, ${bens.length} benefícios, ${deps.length} centros por departamento, ${PLANO.length} competências)`);
};

export default semear;
