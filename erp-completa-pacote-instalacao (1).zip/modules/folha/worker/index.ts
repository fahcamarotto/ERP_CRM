/**
 * Handlers de worker da Folha (carregados pelo worker do nucleo na partida).
 * `c` ja esta numa transacao do papel erp_worker com o escopo do job (RLS vale).
 */
import type { HandlersModulo } from '@erp/api/sdk/puro';
import { contextoPg } from '../api/compartilhado/efeitos-pg.ts';
import { TIPO_JOB_FECHAMENTO } from '../api/competencia/use-case/fechar-competencia.ts';
import { casosDeUso } from '../api/fabrica.ts';

const SISTEMA = { tipo: 'sistema' as const, id: null };
/** Erros de regra: o estado ja foi gravado (ou nao ha o que fazer); nao adianta repetir o job. */
const FINAIS = new Set(['sem_holerites', 'nao_encontrado', 'transicao_invalida']);

const handlers: HandlersModulo = {
  // M8.3 Fechamento da competencia: holerites fechados, rateio, e-mails na fila e folha.fechada.
  [TIPO_JOB_FECHAMENTO]: async (d, c) => {
    const p = d.payload as { competencia_id: string };
    const r = await casosDeUso(c).processarFechamento.execute(contextoPg(c, SISTEMA), { competencia_id: p.competencia_id });
    if (r.ok || r.erros.every((e) => FINAIS.has(e.codigo))) return;
    throw new Error(r.erros.map((e) => e.mensagem).join('; ')); // throw = retry com backoff
  },
};

export default handlers;
