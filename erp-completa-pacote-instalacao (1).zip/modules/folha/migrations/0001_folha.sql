-- Modulo Beneficios e folha (M8): beneficios, eventos de folha (rubricas), competencias, variaveis,
-- holerites, centro de custo por departamento e rateio do fechamento. Valores sempre em centavos (bigint).
-- Idempotente. Leitura de Pessoas e Financeiro so por tabela publicada (docs/CONTRATOS.md 7.1).

-- M8.1 Beneficios por funcionario ou por funcao ------------------------------------------------
CREATE TABLE IF NOT EXISTS folha_beneficios (
  id                            uuid NOT NULL DEFAULT gen_random_uuid(),
  tenant_id                     uuid NOT NULL DEFAULT nucleo_tenant_atual(),
  workspace_id                  uuid NOT NULL DEFAULT nucleo_workspace_atual(),
  creator_id                    uuid,
  nome                          text NOT NULL CHECK (length(btrim(nome)) BETWEEN 2 AND 120),
  tipo                          text NOT NULL CHECK (tipo IN ('vale_transporte', 'vale_refeicao', 'vale_alimentacao', 'plano_saude', 'plano_odonto', 'seguro_vida', 'auxilio', 'outro')),
  abrangencia                   text NOT NULL CHECK (abrangencia IN ('funcionario', 'funcao')),
  funcionario_id                uuid,
  funcao_id                     uuid,
  valor_empresa_centavos        bigint NOT NULL DEFAULT 0 CHECK (valor_empresa_centavos >= 0),
  desconto_funcionario_centavos bigint NOT NULL DEFAULT 0 CHECK (desconto_funcionario_centavos >= 0),
  moeda                         text NOT NULL DEFAULT 'BRL' CHECK (moeda ~ '^[A-Z]{3}$'),
  inicio                        date NOT NULL,
  fim                           date,
  estado                        text NOT NULL DEFAULT 'ativo' CHECK (estado IN ('ativo', 'encerrado')),
  observacoes                   text,
  extras                        jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at                    timestamptz NOT NULL DEFAULT now(),
  updated_at                    timestamptz NOT NULL DEFAULT now(),
  deleted_at                    timestamptz,
  PRIMARY KEY (id, tenant_id, workspace_id),
  FOREIGN KEY (workspace_id, tenant_id) REFERENCES workspaces (id, tenant_id),
  FOREIGN KEY (creator_id, tenant_id, workspace_id) REFERENCES usuarios (id, tenant_id, workspace_id),
  FOREIGN KEY (funcionario_id, tenant_id, workspace_id) REFERENCES pessoas_funcionarios (id, tenant_id, workspace_id),
  FOREIGN KEY (funcao_id, tenant_id, workspace_id) REFERENCES pessoas_funcoes (id, tenant_id, workspace_id),
  CHECK ((abrangencia = 'funcionario' AND funcionario_id IS NOT NULL AND funcao_id IS NULL)
      OR (abrangencia = 'funcao' AND funcao_id IS NOT NULL AND funcionario_id IS NULL)),
  CHECK (fim IS NULL OR fim >= inicio)
);
CREATE INDEX IF NOT EXISTS folha_beneficios_lista_idx ON folha_beneficios (tenant_id, workspace_id, created_at, id) WHERE deleted_at IS NULL;
SELECT nucleo_aplicar_padrao('folha_beneficios');
DROP TRIGGER IF EXISTS folha_beneficios_extras ON folha_beneficios;
CREATE TRIGGER folha_beneficios_extras BEFORE INSERT OR UPDATE OF extras ON folha_beneficios
  FOR EACH ROW EXECUTE FUNCTION nucleo_trigger_extras('folha', 'beneficio');

-- M8.2 Eventos de folha (rubricas): provento, desconto e encargo, fixos ou variaveis -------------
CREATE TABLE IF NOT EXISTS folha_eventos (
  id              uuid NOT NULL DEFAULT gen_random_uuid(),
  tenant_id       uuid NOT NULL DEFAULT nucleo_tenant_atual(),
  workspace_id    uuid NOT NULL DEFAULT nucleo_workspace_atual(),
  creator_id      uuid,
  codigo          text NOT NULL CHECK (codigo ~ '^[A-Z0-9_]{2,20}$'),
  nome            text NOT NULL CHECK (length(btrim(nome)) BETWEEN 2 AND 120),
  natureza        text NOT NULL CHECK (natureza IN ('provento', 'desconto', 'encargo')),
  recorrencia     text NOT NULL CHECK (recorrencia IN ('fixo', 'variavel')),
  calculo         text NOT NULL CHECK (calculo IN ('valor', 'percentual', 'tabela_inss', 'tabela_irrf')),
  valor_centavos  bigint CHECK (valor_centavos IS NULL OR valor_centavos >= 0),
  percentual      numeric(7, 4) CHECK (percentual IS NULL OR (percentual >= 0 AND percentual <= 100)),
  funcionario_id  uuid,
  tipos_contrato  text[] NOT NULL DEFAULT '{}',
  estado          text NOT NULL DEFAULT 'ativo' CHECK (estado IN ('ativo', 'arquivado')),
  descricao       text,
  created_at      timestamptz NOT NULL DEFAULT now(),
  updated_at      timestamptz NOT NULL DEFAULT now(),
  deleted_at      timestamptz,
  PRIMARY KEY (id, tenant_id, workspace_id),
  FOREIGN KEY (workspace_id, tenant_id) REFERENCES workspaces (id, tenant_id),
  FOREIGN KEY (creator_id, tenant_id, workspace_id) REFERENCES usuarios (id, tenant_id, workspace_id),
  FOREIGN KEY (funcionario_id, tenant_id, workspace_id) REFERENCES pessoas_funcionarios (id, tenant_id, workspace_id),
  CHECK (calculo <> 'valor' OR recorrencia = 'variavel' OR valor_centavos IS NOT NULL),
  CHECK (calculo <> 'percentual' OR percentual IS NOT NULL),
  CHECK (calculo NOT IN ('tabela_inss', 'tabela_irrf') OR (natureza = 'desconto' AND recorrencia = 'fixo'))
);
CREATE UNIQUE INDEX IF NOT EXISTS folha_eventos_codigo_uq ON folha_eventos (tenant_id, workspace_id, codigo) WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS folha_eventos_lista_idx ON folha_eventos (tenant_id, workspace_id, created_at, id) WHERE deleted_at IS NULL;
SELECT nucleo_aplicar_padrao('folha_eventos');

-- Centro de custo por departamento (M8.5): define o rateio do custo da folha no Financeiro --------
CREATE TABLE IF NOT EXISTS folha_centros_departamento (
  id               uuid NOT NULL DEFAULT gen_random_uuid(),
  tenant_id        uuid NOT NULL DEFAULT nucleo_tenant_atual(),
  workspace_id     uuid NOT NULL DEFAULT nucleo_workspace_atual(),
  creator_id       uuid,
  departamento_id  uuid NOT NULL,
  centro_custo_id  uuid NOT NULL,
  created_at       timestamptz NOT NULL DEFAULT now(),
  updated_at       timestamptz NOT NULL DEFAULT now(),
  deleted_at       timestamptz,
  PRIMARY KEY (id, tenant_id, workspace_id),
  FOREIGN KEY (workspace_id, tenant_id) REFERENCES workspaces (id, tenant_id),
  FOREIGN KEY (creator_id, tenant_id, workspace_id) REFERENCES usuarios (id, tenant_id, workspace_id),
  FOREIGN KEY (departamento_id, tenant_id, workspace_id) REFERENCES pessoas_departamentos (id, tenant_id, workspace_id),
  FOREIGN KEY (centro_custo_id, tenant_id, workspace_id) REFERENCES financeiro_centros_custo (id, tenant_id, workspace_id)
);
CREATE UNIQUE INDEX IF NOT EXISTS folha_centros_departamento_uq ON folha_centros_departamento (tenant_id, workspace_id, departamento_id);
SELECT nucleo_aplicar_padrao('folha_centros_departamento');

-- M8.3 Competencia mensal: aberta, calculada, conferida, fechando (job) e fechada ---------------
CREATE TABLE IF NOT EXISTS folha_competencias (
  id                      uuid NOT NULL DEFAULT gen_random_uuid(),
  tenant_id               uuid NOT NULL DEFAULT nucleo_tenant_atual(),
  workspace_id            uuid NOT NULL DEFAULT nucleo_workspace_atual(),
  creator_id              uuid,
  mes                     date NOT NULL CHECK (extract(day FROM mes) = 1),
  pagamento               date,
  moeda                   text NOT NULL DEFAULT 'BRL' CHECK (moeda ~ '^[A-Z]{3}$'),
  estado                  text NOT NULL DEFAULT 'aberta' CHECK (estado IN ('aberta', 'calculada', 'conferida', 'fechando', 'fechada')),
  total_proventos_centavos bigint NOT NULL DEFAULT 0,
  total_descontos_centavos bigint NOT NULL DEFAULT 0,
  total_encargos_centavos  bigint NOT NULL DEFAULT 0,
  total_beneficios_centavos bigint NOT NULL DEFAULT 0,
  total_liquido_centavos   bigint NOT NULL DEFAULT 0,
  total_custo_centavos     bigint NOT NULL DEFAULT 0,
  qtd_holerites           integer NOT NULL DEFAULT 0,
  calculada_em            timestamptz,
  conferida_em            timestamptz,
  conferida_por           uuid,
  fechada_em              timestamptz,
  job_id                  uuid,
  erro                    text,
  observacoes             text,
  created_at              timestamptz NOT NULL DEFAULT now(),
  updated_at              timestamptz NOT NULL DEFAULT now(),
  deleted_at              timestamptz,
  PRIMARY KEY (id, tenant_id, workspace_id),
  FOREIGN KEY (workspace_id, tenant_id) REFERENCES workspaces (id, tenant_id),
  FOREIGN KEY (creator_id, tenant_id, workspace_id) REFERENCES usuarios (id, tenant_id, workspace_id),
  FOREIGN KEY (conferida_por, tenant_id, workspace_id) REFERENCES usuarios (id, tenant_id, workspace_id),
  CHECK (pagamento IS NULL OR pagamento >= mes)
);
CREATE UNIQUE INDEX IF NOT EXISTS folha_competencias_mes_uq ON folha_competencias (tenant_id, workspace_id, mes) WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS folha_competencias_lista_idx ON folha_competencias (tenant_id, workspace_id, created_at, id) WHERE deleted_at IS NULL;
SELECT nucleo_aplicar_padrao('folha_competencias');

-- Lancamentos variaveis da competencia (hora extra, comissao, falta) -----------------------------
CREATE TABLE IF NOT EXISTS folha_variaveis (
  id              uuid NOT NULL DEFAULT gen_random_uuid(),
  tenant_id       uuid NOT NULL DEFAULT nucleo_tenant_atual(),
  workspace_id    uuid NOT NULL DEFAULT nucleo_workspace_atual(),
  creator_id      uuid,
  competencia_id  uuid NOT NULL,
  funcionario_id  uuid NOT NULL,
  evento_id       uuid NOT NULL,
  valor_centavos  bigint NOT NULL CHECK (valor_centavos > 0),
  referencia      text,
  created_at      timestamptz NOT NULL DEFAULT now(),
  updated_at      timestamptz NOT NULL DEFAULT now(),
  deleted_at      timestamptz,
  PRIMARY KEY (id, tenant_id, workspace_id),
  FOREIGN KEY (workspace_id, tenant_id) REFERENCES workspaces (id, tenant_id),
  FOREIGN KEY (creator_id, tenant_id, workspace_id) REFERENCES usuarios (id, tenant_id, workspace_id),
  FOREIGN KEY (competencia_id, tenant_id, workspace_id) REFERENCES folha_competencias (id, tenant_id, workspace_id),
  FOREIGN KEY (funcionario_id, tenant_id, workspace_id) REFERENCES pessoas_funcionarios (id, tenant_id, workspace_id),
  FOREIGN KEY (evento_id, tenant_id, workspace_id) REFERENCES folha_eventos (id, tenant_id, workspace_id)
);
CREATE INDEX IF NOT EXISTS folha_variaveis_competencia_idx ON folha_variaveis (tenant_id, workspace_id, competencia_id) WHERE deleted_at IS NULL;
SELECT nucleo_aplicar_padrao('folha_variaveis');

-- M8.4 Holerite por funcionario (foto do calculo; itens no jsonb, filhos do agregado) -----------
CREATE TABLE IF NOT EXISTS folha_holerites (
  id                    uuid NOT NULL DEFAULT gen_random_uuid(),
  tenant_id             uuid NOT NULL DEFAULT nucleo_tenant_atual(),
  workspace_id          uuid NOT NULL DEFAULT nucleo_workspace_atual(),
  creator_id            uuid,
  competencia_id        uuid NOT NULL,
  funcionario_id        uuid NOT NULL,
  funcionario_nome      text NOT NULL,
  email                 text,
  matricula             text,
  departamento_id       uuid,
  funcao_id             uuid,
  centro_custo_id       uuid,
  tipo_contrato         text NOT NULL,
  salario_base_centavos bigint NOT NULL CHECK (salario_base_centavos >= 0),
  proventos_centavos    bigint NOT NULL DEFAULT 0,
  descontos_centavos    bigint NOT NULL DEFAULT 0,
  encargos_centavos     bigint NOT NULL DEFAULT 0,
  beneficios_centavos   bigint NOT NULL DEFAULT 0,
  liquido_centavos      bigint NOT NULL DEFAULT 0,
  custo_centavos        bigint NOT NULL DEFAULT 0,
  moeda                 text NOT NULL DEFAULT 'BRL',
  itens                 jsonb NOT NULL DEFAULT '[]'::jsonb,
  estado                text NOT NULL DEFAULT 'calculado' CHECK (estado IN ('calculado', 'fechado')),
  envio_estado          text NOT NULL DEFAULT 'nao_enviado' CHECK (envio_estado IN ('nao_enviado', 'na_fila', 'sem_email')),
  email_id              uuid,
  enviado_em            timestamptz,
  created_at            timestamptz NOT NULL DEFAULT now(),
  updated_at            timestamptz NOT NULL DEFAULT now(),
  deleted_at            timestamptz,
  PRIMARY KEY (id, tenant_id, workspace_id),
  FOREIGN KEY (workspace_id, tenant_id) REFERENCES workspaces (id, tenant_id),
  FOREIGN KEY (creator_id, tenant_id, workspace_id) REFERENCES usuarios (id, tenant_id, workspace_id),
  FOREIGN KEY (competencia_id, tenant_id, workspace_id) REFERENCES folha_competencias (id, tenant_id, workspace_id),
  FOREIGN KEY (funcionario_id, tenant_id, workspace_id) REFERENCES pessoas_funcionarios (id, tenant_id, workspace_id),
  FOREIGN KEY (departamento_id, tenant_id, workspace_id) REFERENCES pessoas_departamentos (id, tenant_id, workspace_id),
  FOREIGN KEY (funcao_id, tenant_id, workspace_id) REFERENCES pessoas_funcoes (id, tenant_id, workspace_id),
  FOREIGN KEY (centro_custo_id, tenant_id, workspace_id) REFERENCES financeiro_centros_custo (id, tenant_id, workspace_id),
  CHECK (liquido_centavos = proventos_centavos - descontos_centavos),
  CHECK (custo_centavos = proventos_centavos + encargos_centavos + beneficios_centavos)
);
CREATE UNIQUE INDEX IF NOT EXISTS folha_holerites_uq ON folha_holerites (tenant_id, workspace_id, competencia_id, funcionario_id) WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS folha_holerites_lista_idx ON folha_holerites (tenant_id, workspace_id, created_at, id) WHERE deleted_at IS NULL;
SELECT nucleo_aplicar_padrao('folha_holerites');

-- M8.5 Rateio do fechamento por centro de custo (o que vai para o Financeiro) -------------------
CREATE TABLE IF NOT EXISTS folha_rateios (
  id                uuid NOT NULL DEFAULT gen_random_uuid(),
  tenant_id         uuid NOT NULL DEFAULT nucleo_tenant_atual(),
  workspace_id      uuid NOT NULL DEFAULT nucleo_workspace_atual(),
  creator_id        uuid,
  competencia_id    uuid NOT NULL,
  centro_custo_id   uuid,
  liquido_centavos  bigint NOT NULL DEFAULT 0,
  encargos_centavos bigint NOT NULL DEFAULT 0,
  beneficios_centavos bigint NOT NULL DEFAULT 0,
  custo_centavos    bigint NOT NULL CHECK (custo_centavos >= 0),
  qtd_funcionarios  integer NOT NULL DEFAULT 0,
  moeda             text NOT NULL DEFAULT 'BRL',
  created_at        timestamptz NOT NULL DEFAULT now(),
  updated_at        timestamptz NOT NULL DEFAULT now(),
  deleted_at        timestamptz,
  PRIMARY KEY (id, tenant_id, workspace_id),
  FOREIGN KEY (workspace_id, tenant_id) REFERENCES workspaces (id, tenant_id),
  FOREIGN KEY (creator_id, tenant_id, workspace_id) REFERENCES usuarios (id, tenant_id, workspace_id),
  FOREIGN KEY (competencia_id, tenant_id, workspace_id) REFERENCES folha_competencias (id, tenant_id, workspace_id),
  FOREIGN KEY (centro_custo_id, tenant_id, workspace_id) REFERENCES financeiro_centros_custo (id, tenant_id, workspace_id)
);
CREATE UNIQUE INDEX IF NOT EXISTS folha_rateios_uq ON folha_rateios (tenant_id, workspace_id, competencia_id, coalesce(centro_custo_id, '00000000-0000-0000-0000-000000000000'::uuid)) WHERE deleted_at IS NULL;
SELECT nucleo_aplicar_padrao('folha_rateios');

-- Papeis de banco: API (erp_app) e worker (erp_worker, fechamento da competencia e envio do holerite).
GRANT SELECT, INSERT, UPDATE ON folha_beneficios, folha_eventos, folha_centros_departamento, folha_competencias,
  folha_variaveis, folha_holerites, folha_rateios TO erp_app;
GRANT SELECT, INSERT, UPDATE ON folha_competencias, folha_holerites, folha_rateios TO erp_worker;
GRANT SELECT ON folha_beneficios, folha_eventos, folha_centros_departamento, folha_variaveis TO erp_worker;
