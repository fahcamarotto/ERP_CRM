/**
 * Seed demo do Treinamento (M11): tres cursos publicados com modulos, aulas em YouTube, Vimeo, Panda e Bunny,
 * pre-requisitos de curso e de aula, material de apoio, trilhas ligadas as funcoes do Pessoas e matriculas
 * com progresso parcial e uma concluida com certificado. Idempotente: ids deterministicos por chave e insercao
 * so do que falta. Grava pelos adaptadores e entidades do modulo. Pessoas e funcoes vem por SELECT das tabelas
 * publicadas do Pessoas (o seed do Pessoas roda antes).
 */
import { createHash } from 'node:crypto';
import type { SeedModulo } from '@erp/api/sdk/puro';
import { CursoRepoPg } from '../api/curso/adapter/curso-repo-pg.ts';
import { Aula } from '../api/curso/model/aula.ts';
import { Curso } from '../api/curso/model/curso.ts';
import { Material, type TipoMaterial } from '../api/curso/model/material.ts';
import { ModuloCurso } from '../api/curso/model/modulo.ts';
import { MatriculaRepoPg } from '../api/matricula/adapter/matricula-repo-pg.ts';
import { Matricula } from '../api/matricula/model/matricula.ts';
import { TrilhaRepoPg } from '../api/trilha/adapter/trilha-repo-pg.ts';
import { Trilha } from '../api/trilha/model/trilha.ts';

/** uuid deterministico a partir de uma chave (mesmo id em toda execucao). */
function idDe(chave: string): string {
  const h = createHash('sha256').update(`treinamento-demo:${chave}`).digest('hex');
  return `${h.slice(0, 8)}-${h.slice(8, 12)}-4${h.slice(13, 16)}-a${h.slice(17, 20)}-${h.slice(20, 32)}`;
}

type AulaSeed = { k: string; titulo: string; provedor: string; video: string; min: number; pre?: string; materiais?: [string, TipoMaterial, string][] };
type CursoSeed = { k: string; titulo: string; descricao: string; pre?: string; certificado: boolean; modulos: { k: string; titulo: string; aulas: AulaSeed[] }[] };

const PANDA = 'vz-7b1e2c3d-4a5';
const BUNNY = '284190';

const CURSOS: CursoSeed[] = [
  {
    k: 'integracao', titulo: 'Integração de novos colaboradores', certificado: true,
    descricao: 'Boas-vindas, cultura, ferramentas do dia a dia e políticas da empresa.',
    modulos: [
      { k: 'm1', titulo: 'Boas-vindas', aulas: [
        { k: 'a1', titulo: 'Nossa história e nossos valores', provedor: 'youtube', video: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ', min: 8,
          materiais: [['Manual do colaborador', 'pdf', 'https://exemplo.com.br/treinamento/manual-colaborador.pdf']] },
        { k: 'a2', titulo: 'Como funciona a sua primeira semana', provedor: 'vimeo', video: '76979871', min: 6, pre: 'a1' },
      ] },
      { k: 'm2', titulo: 'Ferramentas e políticas', aulas: [
        { k: 'a3', titulo: 'Acessos, e-mail e agenda', provedor: 'panda', video: `${PANDA}/3f2a9c41-7d6e-4b8a-9c1d-2e3f4a5b6c7d`, min: 12, pre: 'a2',
          materiais: [['Checklist de acessos', 'planilha', 'https://exemplo.com.br/treinamento/checklist-acessos.xlsx']] },
        { k: 'a4', titulo: 'Política de conduta e LGPD', provedor: 'bunny', video: `${BUNNY}/8a7b6c5d-4e3f-4a1b-9c2d-1e0f2a3b4c5d`, min: 15, pre: 'a3' },
      ] },
    ],
  },
  {
    k: 'atendimento', titulo: 'Atendimento ao cliente', certificado: true, pre: 'integracao',
    descricao: 'Do primeiro contato ao pós-venda: escuta ativa, tom de voz e resolução no primeiro atendimento.',
    modulos: [
      { k: 'm1', titulo: 'Fundamentos', aulas: [
        { k: 'a1', titulo: 'Escuta ativa e empatia', provedor: 'youtube', video: 'dQw4w9WgXcQ', min: 10,
          materiais: [['Roteiro de atendimento', 'apresentacao', 'https://exemplo.com.br/treinamento/roteiro-atendimento.pptx']] },
        { k: 'a2', titulo: 'Tom de voz por canal', provedor: 'vimeo', video: '76979871', min: 9, pre: 'a1' },
      ] },
      { k: 'm2', titulo: 'Na prática', aulas: [
        { k: 'a3', titulo: 'Como lidar com reclamações', provedor: 'panda', video: `${PANDA}/5b4c3d2e-1f0a-4b9c-8d7e-6f5a4b3c2d1e`, min: 14, pre: 'a2' },
      ] },
    ],
  },
  {
    k: 'seguranca', titulo: 'Segurança da informação no dia a dia', certificado: false,
    descricao: 'Senhas, golpes por mensagem e cuidado com dados de clientes.',
    modulos: [
      { k: 'm1', titulo: 'Essencial', aulas: [
        { k: 'a1', titulo: 'Senhas fortes e autenticação em dois fatores', provedor: 'bunny', video: `${BUNNY}/1c2d3e4f-5a6b-4c7d-8e9f-0a1b2c3d4e5f`, min: 7 },
        { k: 'a2', titulo: 'Golpes por WhatsApp e e-mail', provedor: 'youtube', video: 'https://youtu.be/dQw4w9WgXcQ', min: 9,
          materiais: [['Guia rápido de segurança', 'link', 'https://exemplo.com.br/treinamento/guia-seguranca']] },
      ] },
    ],
  },
];

const semear: SeedModulo = async ({ c, log }) => {
  const cursos = new CursoRepoPg(c);
  const trilhas = new TrilhaRepoPg(c);
  const matriculas = new MatriculaRepoPg(c);
  let novos = 0;
  const idCurso = new Map<string, string>();
  const idAula = new Map<string, string>();

  for (const cs of CURSOS) {
    const id = idDe(`curso:${cs.k}`);
    const existente = (await cursos.obterPorId(id)) ?? (await cursos.buscarPorTitulo(cs.titulo));
    idCurso.set(cs.k, existente?.id ?? id);
    if (existente) {
      for (const m of cs.modulos) for (const a of m.aulas) idAula.set(`${cs.k}:${a.k}`, idDe(`aula:${cs.k}:${a.k}`));
      continue;
    }
    // Nasce publicado: modulos e aulas entram na mesma transacao logo abaixo.
    const pub = Curso.create({ titulo: cs.titulo, descricao: cs.descricao, prerequisito_curso_id: cs.pre ? idCurso.get(cs.pre)! : null, emite_certificado: cs.certificado }, id).mudarEstado('publicado');
    if (!pub.ok) throw new Error(pub.erros[0]!.mensagem);
    await cursos.inserir(pub.valor);
    novos++;
    let ordemAula = 1;
    for (const [i, m] of cs.modulos.entries()) {
      const mid = idDe(`modulo:${cs.k}:${m.k}`);
      await cursos.inserirModulo(ModuloCurso.create({ curso_id: id, titulo: m.titulo, ordem: i + 1 }, mid));
      novos++;
      for (const a of m.aulas) {
        const aid = idDe(`aula:${cs.k}:${a.k}`);
        idAula.set(`${cs.k}:${a.k}`, aid);
        await cursos.inserirAula(Aula.create({
          curso_id: id, modulo_id: mid, titulo: a.titulo, ordem: ordemAula++, provedor: a.provedor, video_id: a.video, duracao_min: a.min,
          prerequisito_aula_id: a.pre ? idAula.get(`${cs.k}:${a.pre}`)! : null,
        }, aid));
        novos++;
        for (const [j, [titulo, tipo, url]] of (a.materiais ?? []).entries()) {
          await cursos.inserirMaterial(Material.create({ aula_id: aid, titulo, tipo, url }, idDe(`material:${cs.k}:${a.k}:${j}`)));
          novos++;
        }
      }
    }
  }

  // Trilhas ligadas as duas primeiras funcoes ativas do Pessoas (tabela publicada).
  const funcoes = (await c.query("SELECT id, nome FROM pessoas_funcoes WHERE estado = 'ativo' AND deleted_at IS NULL ORDER BY created_at, id LIMIT 2")).rows as { id: string; nome: string }[];
  const TRILHAS = [
    { k: 'integracao', nome: 'Trilha de integração', descricao: 'Todo colaborador novo percorre esta trilha na primeira semana.', funcao: funcoes[0]?.id ?? null, cursos: ['integracao', 'seguranca'] },
    { k: 'atendimento', nome: 'Trilha de atendimento', descricao: 'Formação de quem fala com o cliente.', funcao: funcoes[1]?.id ?? null, cursos: ['integracao', 'atendimento'] },
  ];
  for (const t of TRILHAS) {
    const id = idDe(`trilha:${t.k}`);
    if ((await trilhas.obterPorId(id)) ?? (await trilhas.buscarPorNome(t.nome))) continue;
    await trilhas.inserir(Trilha.create({ nome: t.nome, descricao: t.descricao, funcao_id: t.funcao, curso_ids: t.cursos.map((k) => idCurso.get(k)!) }, id));
    novos++;
  }

  // Matriculas: progresso parcial, uma concluida com certificado e uma recem-iniciada.
  const pessoas = (await c.query("SELECT id FROM pessoas_funcionarios WHERE estado <> 'desligado' AND deleted_at IS NULL ORDER BY created_at, id LIMIT 4")).rows as { id: string }[];
  const PLANO: { p: number; curso: string; aulas: string[]; trilha?: string }[] = [
    { p: 0, curso: 'integracao', aulas: ['a1', 'a2', 'a3', 'a4'], trilha: 'integracao' },
    { p: 0, curso: 'seguranca', aulas: ['a1'], trilha: 'integracao' },
    { p: 1, curso: 'integracao', aulas: ['a1', 'a2'], trilha: 'atendimento' },
    { p: 2, curso: 'integracao', aulas: [] },
    { p: 3, curso: 'seguranca', aulas: ['a1', 'a2'] },
  ];
  for (const pl of PLANO) {
    const pessoa = pessoas[pl.p];
    if (!pessoa) continue;
    const cursoId = idCurso.get(pl.curso)!;
    const id = idDe(`matricula:${pl.p}:${pl.curso}`);
    if ((await matriculas.obterPorId(id)) ?? (await matriculas.matriculaViva(pessoa.id, cursoId))) continue;
    const curso = (await matriculas.curso(cursoId))!;
    let m = Matricula.create({ funcionario_id: pessoa.id, curso_id: cursoId, trilha_id: pl.trilha ? idDe(`trilha:${pl.trilha}`) : null, origem: pl.trilha ? 'trilha' : 'manual' }, id);
    for (const a of pl.aulas) {
      const r = m.concluirAula(idAula.get(`${pl.curso}:${a}`)!, { aulas: curso.aulas, emite_certificado: curso.emite_certificado, prerequisito_pendente: null });
      if (!r.ok) throw new Error(r.erros[0]!.mensagem);
      m = r.valor.matricula;
    }
    await matriculas.inserir(m);
    novos++;
  }

  log(`${novos} registro(s) demo novo(s) (${CURSOS.length} cursos, ${TRILHAS.length} trilhas, ${Math.min(pessoas.length, 4)} pessoas com matrícula)`);
};

export default semear;
