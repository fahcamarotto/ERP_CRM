/**
 * @tool do modulo (N15): cada chamada vira tool MCP em /mcp e rota REST com o mesmo schema no OpenAPI.
 * Casos de uso principais do M11: cursos (listar, obter, criar, publicar), aulas.criar, trilhas (listar, criar, atribuir),
 * matriculas (listar, criar, registrar progresso) e certificados.verificar.
 */
import { tool } from '@erp/api/sdk';
import { naoEncontrado } from './borda.ts';
import { contextoPg } from './compartilhado/efeitos-pg.ts';
import { exigirOk } from './compartilhado/result.ts';
import type { DadosAula } from './curso/model/aula.ts';
import type { DadosCurso, EstadoCurso } from './curso/model/curso.ts';
import { listarCursos, obterCurso } from './curso/query/cursos.ts';
import { estadosCurso, estadosMatricula, paginacao, propsAula, propsCurso, propsTrilha, uuid } from './esquemas.ts';
import { casosDeUso } from './fabrica.ts';
import { listarMatriculas, obterCertificado, obterMatricula, type FiltroMatriculas } from './matricula/query/matriculas.ts';
import type { DadosTrilha } from './trilha/model/trilha.ts';
import { listarTrilhas, obterTrilha } from './trilha/query/trilhas.ts';

const M = 'treinamento';
const BASE = '/api/v1/treinamento';

tool<{ estado?: EstadoCurso; busca?: string; limite?: number; cursor?: string }>({
  nome: 'cursos.listar', modulo: M, titulo: 'Listar cursos', tipo: 'leitura', permissao: 'treinamento.ver',
  descricao: 'Lista cursos de treinamento com estado (rascunho, publicado, arquivado), total de modulos, aulas, duracao e matriculas.',
  entrada: { type: 'object', properties: { ...paginacao, estado: { type: 'string', enum: [...estadosCurso] } } },
  rota: { metodo: 'GET', caminho: `${BASE}/cursos` },
  executar: ({ c }, a) => listarCursos(c, a),
});

tool<{ id: string }>({
  nome: 'cursos.obter', modulo: M, titulo: 'Obter curso', tipo: 'leitura', permissao: 'treinamento.ver',
  descricao: 'Ficha do curso com modulos e aulas em ordem (provedor e id do video, pre-requisito, duracao) e material de apoio de cada aula.',
  entrada: { type: 'object', required: ['id'], properties: { id: uuid } },
  rota: { metodo: 'GET', caminho: `${BASE}/cursos/:id` },
  executar: async ({ c }, a) => (await obterCurso(c, a.id)) ?? Promise.reject(naoEncontrado('Curso nao encontrado')),
});

tool<DadosCurso>({
  nome: 'cursos.criar', modulo: M, titulo: 'Criar curso', tipo: 'escrita', permissao: 'treinamento.criar',
  descricao: 'Cria curso em rascunho, com pre-requisito opcional de outro curso (sem ciclo) e certificado interno ligado por padrao.',
  entrada: { type: 'object', required: ['titulo'], properties: propsCurso },
  rota: { metodo: 'POST', caminho: `${BASE}/cursos` },
  executar: async ({ c, ator, ip }, a) => {
    const { id } = exigirOk(await casosDeUso(c).criarCurso.execute(contextoPg(c, ator, ip), a));
    return obterCurso(c, id);
  },
});

tool<{ id: string; estado: EstadoCurso }>({
  nome: 'cursos.mudar_estado', modulo: M, titulo: 'Publicar ou arquivar curso', tipo: 'escrita', permissao: 'treinamento.editar',
  descricao: 'Muda o estado do curso (rascunho, publicado, arquivado). Publicar exige ao menos uma aula e publica curso.publicado.',
  entrada: { type: 'object', required: ['id', 'estado'], properties: { id: uuid, estado: { type: 'string', enum: [...estadosCurso] } } },
  rota: { metodo: 'POST', caminho: `${BASE}/cursos/:id/estado` },
  executar: async ({ c, ator, ip }, a) => {
    exigirOk(await casosDeUso(c).mudarEstadoCurso.execute(contextoPg(c, ator, ip), a));
    return obterCurso(c, a.id);
  },
});

tool<Omit<DadosAula, 'ordem'> & { ordem?: number }>({
  nome: 'aulas.criar', modulo: M, titulo: 'Criar aula', tipo: 'escrita', permissao: 'treinamento.criar',
  descricao: 'Cria aula num modulo do curso com video externo (YouTube, Vimeo, Panda Video ou Bunny Stream: guarda so o id; aceita URL colada) e pre-requisito opcional.',
  entrada: { type: 'object', required: ['curso_id', 'modulo_id', 'titulo'], properties: { curso_id: uuid, ...propsAula } },
  rota: { metodo: 'POST', caminho: `${BASE}/cursos/:curso_id/aulas` },
  executar: async ({ c, ator, ip }, a) => {
    exigirOk(await casosDeUso(c).criarAula.execute(contextoPg(c, ator, ip), a));
    return obterCurso(c, a.curso_id);
  },
});

tool<{ estado?: 'ativa' | 'arquivada'; busca?: string; limite?: number; cursor?: string }>({
  nome: 'trilhas.listar', modulo: M, titulo: 'Listar trilhas', tipo: 'leitura', permissao: 'treinamento.ver',
  descricao: 'Lista trilhas de treinamento com a funcao ligada, os cursos em ordem e quantas pessoas ja receberam a trilha.',
  entrada: { type: 'object', properties: { ...paginacao, estado: { type: 'string', enum: ['ativa', 'arquivada'] } } },
  rota: { metodo: 'GET', caminho: `${BASE}/trilhas` },
  executar: ({ c }, a) => listarTrilhas(c, a),
});

tool<DadosTrilha>({
  nome: 'trilhas.criar', modulo: M, titulo: 'Criar trilha', tipo: 'escrita', permissao: 'treinamento.criar',
  descricao: 'Cria trilha com cursos em ordem e funcao opcional do Pessoas; funcionario admitido nessa funcao recebe a trilha automaticamente.',
  entrada: { type: 'object', required: ['nome'], properties: propsTrilha },
  rota: { metodo: 'POST', caminho: `${BASE}/trilhas` },
  executar: async ({ c, ator, ip }, a) => {
    const { id } = exigirOk(await casosDeUso(c).criarTrilha.execute(contextoPg(c, ator, ip), a));
    return obterTrilha(c, id);
  },
});

tool<{ id: string; funcionario_id: string }>({
  nome: 'trilhas.atribuir', modulo: M, titulo: 'Atribuir trilha a uma pessoa', tipo: 'escrita', permissao: 'treinamento.editar',
  descricao: 'Matricula o funcionario em cada curso publicado da trilha. Idempotente: matricula ja existente e mantida; devolve criadas, ja_matriculado e ignorados.',
  entrada: { type: 'object', required: ['id', 'funcionario_id'], properties: { id: uuid, funcionario_id: uuid } },
  rota: { metodo: 'POST', caminho: `${BASE}/trilhas/:id/atribuir` },
  executar: async ({ c, ator, ip }, a) =>
    exigirOk(await casosDeUso(c).atribuirTrilha.execute(contextoPg(c, ator, ip), { trilha_id: a.id, funcionario_id: a.funcionario_id })),
});

tool<FiltroMatriculas>({
  nome: 'matriculas.listar', modulo: M, titulo: 'Listar progresso', tipo: 'leitura', permissao: 'treinamento.ver',
  descricao: 'Progresso por pessoa e curso: estado, aulas concluidas, percentual, data de conclusao e codigo do certificado. Filtra por estado, pessoa, curso ou trilha.',
  entrada: {
    type: 'object',
    properties: { ...paginacao, estado: { type: 'string', enum: [...estadosMatricula] }, funcionario_id: uuid, curso_id: uuid, trilha_id: uuid },
  },
  rota: { metodo: 'GET', caminho: `${BASE}/matriculas` },
  executar: ({ c }, a) => listarMatriculas(c, a),
});

tool<{ funcionario_id: string; curso_id: string }>({
  nome: 'matriculas.criar', modulo: M, titulo: 'Matricular pessoa em curso', tipo: 'escrita', permissao: 'treinamento.criar',
  descricao: 'Matricula um funcionario ativo num curso publicado. Recusa matricula duplicada (409) e publica matricula.criada.',
  entrada: { type: 'object', required: ['funcionario_id', 'curso_id'], properties: { funcionario_id: uuid, curso_id: uuid } },
  rota: { metodo: 'POST', caminho: `${BASE}/matriculas` },
  executar: async ({ c, ator, ip }, a) => {
    const { id } = exigirOk(await casosDeUso(c).matricular.execute(contextoPg(c, ator, ip), a));
    return obterMatricula(c, id);
  },
});

tool<{ id: string; aula_id: string }>({
  nome: 'matriculas.concluir_aula', modulo: M, titulo: 'Registrar aula concluida', tipo: 'escrita', permissao: 'treinamento.editar',
  descricao: 'Marca a aula como concluida na matricula respeitando pre-requisitos de aula e de curso. Ao concluir a ultima aula fecha o curso, gera o certificado interno e publica matricula.concluida.',
  entrada: { type: 'object', required: ['id', 'aula_id'], properties: { id: uuid, aula_id: uuid } },
  rota: { metodo: 'POST', caminho: `${BASE}/matriculas/:id/progresso` },
  executar: async ({ c, ator, ip }, a) => {
    exigirOk(await casosDeUso(c).concluirAula.execute(contextoPg(c, ator, ip), { matricula_id: a.id, aula_id: a.aula_id, gestor: true }));
    return obterMatricula(c, a.id);
  },
});

tool<{ codigo: string }>({
  nome: 'certificados.verificar', modulo: M, titulo: 'Verificar certificado', tipo: 'leitura', permissao: 'treinamento.ver',
  descricao: 'Confere um certificado interno pelo codigo TRN-XXXX-XXXX: pessoa, curso, data de conclusao e carga horaria.',
  entrada: { type: 'object', required: ['codigo'], properties: { codigo: { type: 'string', pattern: '^[Tt][Rr][Nn]-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}$' } } },
  rota: { metodo: 'GET', caminho: `${BASE}/certificados/:codigo` },
  executar: async ({ c }, a) => (await obterCertificado(c, a.codigo)) ?? Promise.reject(naoEncontrado('Certificado nao encontrado')),
});
