/** JSON Schemas dos DTOs de entrada (viram validacao Fastify, OpenAPI em /docs e schema das tools MCP). */
export const uuid = { type: 'string', format: 'uuid' } as const;
const uuidNulo = { type: ['string', 'null'], format: 'uuid' } as const;
const texto = (max: number) => ({ type: ['string', 'null'], maxLength: max });

export const estadosCurso = ['rascunho', 'publicado', 'arquivado'] as const;
export const estadosMatricula = ['em_andamento', 'concluida', 'cancelada'] as const;
export const provedores = ['youtube', 'vimeo', 'panda', 'bunny'] as const;
export const tiposMaterial = ['pdf', 'planilha', 'apresentacao', 'link', 'outro'] as const;

export const propsCurso = {
  titulo: { type: 'string', minLength: 2, maxLength: 200 },
  descricao: texto(4000),
  prerequisito_curso_id: { ...uuidNulo, description: 'Curso que precisa estar concluido antes de registrar progresso neste' },
  emite_certificado: { type: 'boolean', description: 'Gera codigo de certificado interno ao concluir' },
  extras: { type: 'object', description: 'Campos personalizados (modulo treinamento, entidade curso)' },
} as const;

export const propsModulo = {
  titulo: { type: 'string', minLength: 2, maxLength: 200 },
  ordem: { type: 'integer', minimum: 1, maximum: 10000 },
} as const;

export const propsAula = {
  modulo_id: uuid,
  titulo: { type: 'string', minLength: 2, maxLength: 200 },
  descricao: texto(4000),
  ordem: { type: 'integer', minimum: 1, maximum: 10000 },
  provedor: { type: ['string', 'null'], enum: [...provedores, null], description: 'Player externo: youtube, vimeo, panda ou bunny' },
  video_id: { ...texto(500), description: 'Id do video ou URL colada (Panda e Bunny: <biblioteca>/<id>)' },
  duracao_min: { type: 'integer', minimum: 0, maximum: 1440 },
  prerequisito_aula_id: { ...uuidNulo, description: 'Aula do mesmo curso que precisa estar concluida antes' },
} as const;

export const propsMaterial = {
  titulo: { type: 'string', minLength: 2, maxLength: 200 },
  tipo: { type: 'string', enum: [...tiposMaterial] },
  url: { type: 'string', minLength: 8, maxLength: 2000, description: 'Link http(s) do arquivo ou pagina' },
} as const;

export const propsTrilha = {
  nome: { type: 'string', minLength: 2, maxLength: 200 },
  descricao: texto(4000),
  funcao_id: { ...uuidNulo, description: 'Funcao do Pessoas: quem for admitido nela recebe a trilha' },
  curso_ids: { type: 'array', items: uuid, maxItems: 100, description: 'Cursos em ordem' },
  extras: { type: 'object' },
} as const;

export const paginacao = {
  busca: { type: 'string', maxLength: 120 },
  limite: { type: 'integer', minimum: 1, maximum: 200, default: 50 },
  cursor: { type: 'string', maxLength: 200 },
} as const;
