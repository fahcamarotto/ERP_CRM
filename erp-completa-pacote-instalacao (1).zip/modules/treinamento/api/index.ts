/**
 * Plugin do modulo Treinamento (M11), registrado sozinho com prefixo /api/v1/treinamento.
 * Importar ./tools.ts registra as @tool (MCP e REST) no carregamento.
 */
import type { FastifyPluginAsync } from '@erp/api/sdk';
import './tools.ts';
import { rotasCurso } from './curso/routes.ts';
import { rotasMatricula } from './matricula/routes.ts';
import { rotasTrilha } from './trilha/routes.ts';

const plugin: FastifyPluginAsync = async (app) => {
  rotasCurso(app);
  rotasTrilha(app);
  rotasMatricula(app);
};

export default plugin;
