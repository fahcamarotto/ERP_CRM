/**
 * Casos de uso da Matricula (M11.4 e M11.5): Matricular, ConcluirAula (progresso, conclusao e certificado),
 * CancelarMatricula, AtribuirTrilha e AtribuirTrilhaDaFuncao (reacao a funcionario.admitido do Pessoas).
 */
import { erroDe, fail, ok, okVazio, type Result } from '../../compartilhado/result.ts';
import type { ContextoCaso } from '../../compartilhado/efeitos.ts';
import { Matricula, type DadosMatricula, type OrigemMatricula } from '../model/matricula.ts';
import type { ConsultarParaMatricula, GravarMatricula, ObterMatricula } from '../model/portas.ts';

export interface DepsMatricula {
  repo: ObterMatricula & GravarMatricula;
  consultas: ConsultarParaMatricula;
}

const TABELA = 'treinamento_matriculas';

/** Cria uma matricula: pessoa ativa, curso publicado e sem matricula viva no mesmo curso. */
async function matricular(deps: DepsMatricula, ctx: ContextoCaso, e: DadosMatricula): Promise<Result<{ id: string }>> {
  const r = Matricula.tryCreate(e);
  if (!r.ok) return r;
  const pessoa = await deps.consultas.funcionarioAtivo(e.funcionario_id);
  if (!pessoa) return fail(erroDe('funcionario_invalido', 'Funcionario nao encontrado ou desligado', 'funcionario_id'));
  const curso = await deps.consultas.curso(e.curso_id);
  if (!curso) return fail(erroDe('curso_invalido', 'Curso nao encontrado', 'curso_id'));
  if (curso.estado !== 'publicado') return fail(erroDe('curso_nao_publicado', 'Curso precisa estar publicado para receber matricula', 'curso_id'));
  const viva = await deps.repo.matriculaViva(e.funcionario_id, e.curso_id);
  if (viva) return fail(erroDe('conflito', 'Pessoa ja matriculada neste curso', 'curso_id', { matricula_id: viva.id }));
  await deps.repo.inserir(r.valor);
  const d = r.valor.paraDados();
  await ctx.efeitos.auditar('matricula.criar', TABELA, d.id, undefined, d);
  await ctx.efeitos.nota(TABELA, d.id, `${pessoa.nome} matriculado(a) em ${curso.titulo}`);
  await ctx.efeitos.publicar('matricula.criada', { id: d.id, funcionario_id: d.funcionario_id, curso_id: d.curso_id, trilha_id: d.trilha_id, origem: d.origem });
  return ok({ id: d.id });
}

export class Matricular {
  constructor(private readonly deps: DepsMatricula) {}
  execute(ctx: ContextoCaso, e: { funcionario_id: string; curso_id: string }): Promise<Result<{ id: string }>> {
    return matricular(this.deps, ctx, { ...e, origem: 'manual' });
  }
}

export interface EntradaConcluirAula {
  matricula_id: string;
  aula_id: string;
  /** Quem tem treinamento.editar registra progresso de qualquer pessoa; os demais so o proprio. */
  gestor: boolean;
}

export class ConcluirAula {
  constructor(private readonly deps: DepsMatricula, private readonly relogio: () => Date = () => new Date()) {}
  async execute(ctx: ContextoCaso, e: EntradaConcluirAula): Promise<Result<{ concluiu_curso: boolean; certificado_codigo: string | null }>> {
    const atual = await this.deps.repo.obterPorId(e.matricula_id);
    if (!atual) return fail(erroDe('nao_encontrado', 'Matricula nao encontrada'));
    if (!e.gestor) {
      const meu = ctx.ator.tipo === 'usuario' && ctx.ator.id ? await this.deps.consultas.funcionarioDoUsuario(ctx.ator.id) : null;
      if (meu !== atual.funcionarioId) return fail(erroDe('sem_permissao', 'So a propria pessoa ou um gestor registra este progresso'));
    }
    const curso = await this.deps.consultas.curso(atual.cursoId);
    if (!curso) return fail(erroDe('curso_invalido', 'Curso da matricula nao encontrado'));
    const pendente = curso.prerequisito_curso_id && !(await this.deps.consultas.cursoConcluido(atual.funcionarioId, curso.prerequisito_curso_id))
      ? curso.prerequisito_curso_id : null;
    const r = atual.concluirAula(e.aula_id, { aulas: curso.aulas, emite_certificado: curso.emite_certificado, prerequisito_pendente: pendente }, this.relogio());
    if (!r.ok) return r;
    const { matricula, concluiuCurso, nova } = r.valor;
    const d = matricula.paraDados();
    if (nova) {
      await this.deps.repo.atualizar(matricula);
      await ctx.efeitos.auditar('matricula.concluir_aula', TABELA, d.id, { aulas: atual.aulasConcluidas.length }, { aulas: d.aulas_concluidas.length, aula_id: e.aula_id });
    }
    if (concluiuCurso) {
      await ctx.efeitos.historico(TABELA, d.id, { estado: atual.estado }, { estado: d.estado, certificado_codigo: d.certificado_codigo });
      await ctx.efeitos.nota(TABELA, d.id, d.certificado_codigo ? `Curso concluido. Certificado ${d.certificado_codigo}` : 'Curso concluido');
      await ctx.efeitos.publicar('matricula.concluida', {
        id: d.id, funcionario_id: d.funcionario_id, curso_id: d.curso_id, trilha_id: d.trilha_id, concluida_em: d.concluida_em, certificado_codigo: d.certificado_codigo,
      });
    }
    return ok({ concluiu_curso: concluiuCurso, certificado_codigo: d.certificado_codigo });
  }
}

export class CancelarMatricula {
  constructor(private readonly deps: DepsMatricula) {}
  async execute(ctx: ContextoCaso, e: { id: string }): Promise<Result<void>> {
    const atual = await this.deps.repo.obterPorId(e.id);
    if (!atual) return fail(erroDe('nao_encontrado', 'Matricula nao encontrada'));
    const r = atual.cancelar();
    if (!r.ok) return r;
    await this.deps.repo.atualizar(r.valor);
    await ctx.efeitos.historico(TABELA, e.id, { estado: atual.estado }, { estado: r.valor.estado });
    await ctx.efeitos.auditar('matricula.cancelar', TABELA, e.id, { estado: atual.estado }, { estado: r.valor.estado });
    return okVazio();
  }
}

export interface ResultadoAtribuicao {
  trilha_id: string;
  funcionario_id: string;
  criadas: string[];
  ja_matriculado: string[];
  ignorados: { curso_id: string; motivo: string }[];
}

/** Matricula a pessoa em cada curso publicado da trilha. Idempotente: quem ja tem matricula viva e mantido. */
async function atribuir(deps: DepsMatricula, ctx: ContextoCaso, trilhaId: string, funcionarioId: string, origem: OrigemMatricula): Promise<Result<ResultadoAtribuicao>> {
  const trilha = await deps.consultas.trilha(trilhaId);
  if (!trilha) return fail(erroDe('nao_encontrado', 'Trilha nao encontrada', 'trilha_id'));
  if (trilha.estado !== 'ativa') return fail(erroDe('transicao_invalida', 'Trilha arquivada nao pode ser atribuida', 'trilha_id'));
  if (!(await deps.consultas.funcionarioAtivo(funcionarioId))) return fail(erroDe('funcionario_invalido', 'Funcionario nao encontrado ou desligado', 'funcionario_id'));
  const res: ResultadoAtribuicao = { trilha_id: trilhaId, funcionario_id: funcionarioId, criadas: [], ja_matriculado: [], ignorados: [] };
  for (const cursoId of trilha.curso_ids) {
    const viva = await deps.repo.matriculaViva(funcionarioId, cursoId);
    if (viva) { res.ja_matriculado.push(cursoId); continue; }
    const r = await matricular(deps, ctx, { funcionario_id: funcionarioId, curso_id: cursoId, trilha_id: trilhaId, origem });
    if (r.ok) res.criadas.push(r.valor.id);
    else res.ignorados.push({ curso_id: cursoId, motivo: r.erros[0]!.codigo });
  }
  await ctx.efeitos.auditar('trilha.atribuir', 'treinamento_trilhas', trilhaId, undefined, res);
  await ctx.efeitos.nota('treinamento_trilhas', trilhaId, `Trilha atribuida (${origem}): ${res.criadas.length} matricula(s) nova(s)`);
  return ok(res);
}

export class AtribuirTrilha {
  constructor(private readonly deps: DepsMatricula) {}
  execute(ctx: ContextoCaso, e: { trilha_id: string; funcionario_id: string }): Promise<Result<ResultadoAtribuicao>> {
    return atribuir(this.deps, ctx, e.trilha_id, e.funcionario_id, 'trilha');
  }
}

/** Payload do evento funcionario.admitido (CONTRATOS 7.1.7). */
export interface EventoAdmissao {
  id: string;
  evento?: string;
  dados: { id: string; funcao_id?: string | null; nome?: string };
}

export class AtribuirTrilhaDaFuncao {
  constructor(private readonly deps: DepsMatricula) {}
  async execute(ctx: ContextoCaso, ev: EventoAdmissao): Promise<Result<{ trilhas: number; matriculas: number }>> {
    const funcao = ev.dados?.funcao_id;
    if (!ev.dados?.id || !funcao) return ok({ trilhas: 0, matriculas: 0 });
    const trilhas = await this.deps.consultas.trilhasAtivasDaFuncao(funcao);
    let matriculas = 0;
    for (const t of trilhas) {
      const r = await atribuir(this.deps, ctx, t, ev.dados.id, 'admissao');
      if (!r.ok) return r;
      matriculas += r.valor.criadas.length;
    }
    return ok({ trilhas: trilhas.length, matriculas });
  }
}
