/**
 * Rotas REST da Matricula fora das tools: area de membros (ficha), progresso da propria pessoa, cancelamento
 * e "eu" (funcionario ligado ao usuario da sessao).
 */
import { esquemaErro, permissoesDe, requer, sessaoDe, type FastifyInstance } from '@erp/api/sdk';
import { naTransacao, naoEncontrado } from '../borda.ts';
import { exigirOk } from '../compartilhado/result.ts';
import { uuid } from '../esquemas.ts';
import { obterMatricula } from './query/matriculas.ts';

const tags = ['treinamento'];
const paramId = { type: 'object', required: ['id'], properties: { id: uuid } } as const;
const erros = { 400: esquemaErro, 403: esquemaErro, 404: esquemaErro, 409: esquemaErro };

export function rotasMatricula(app: FastifyInstance): void {
  app.get('/eu', {
    preHandler: requer('treinamento.ver'),
    schema: { tags, summary: 'Funcionario do usuario da sessao (null se nao houver)' },
  }, (req) => naTransacao(req, async (_, __, c) => {
    const s = sessaoDe(req);
    if (s.tipo !== 'usuario') return { funcionario_id: null };
    const r = await c.query('SELECT id FROM pessoas_funcionarios WHERE usuario_id = $1 AND deleted_at IS NULL LIMIT 1', [s.usuarioId]);
    return { funcionario_id: (r.rows[0]?.id as string | undefined) ?? null };
  }));

  app.get<{ Params: { id: string } }>('/matriculas/:id', {
    preHandler: requer('treinamento.ver'),
    schema: { tags, summary: 'Area de membros: matricula com curso, aulas, materiais e progresso', params: paramId, response: { 404: esquemaErro } },
  }, (req) => naTransacao(req, async (_, __, c) => (await obterMatricula(c, req.params.id)) ?? Promise.reject(naoEncontrado('Matricula nao encontrada'))));

  app.post<{ Params: { id: string; aula_id: string } }>('/matriculas/:id/aulas/:aula_id/concluir', {
    preHandler: requer('treinamento.ver'),
    schema: {
      tags, summary: 'Marca aula concluida (ConcluirAula): a propria pessoa ou quem tem treinamento.editar',
      params: { type: 'object', required: ['id', 'aula_id'], properties: { id: uuid, aula_id: uuid } }, response: erros,
    },
  }, async (req) => {
    const gestor = (await permissoesDe(req)).has('treinamento.editar');
    return naTransacao(req, async (casos, ctx, c) => {
      exigirOk(await casos.concluirAula.execute(ctx, { matricula_id: req.params.id, aula_id: req.params.aula_id, gestor }));
      return obterMatricula(c, req.params.id);
    });
  });

  app.post<{ Params: { id: string } }>('/matriculas/:id/cancelar', {
    preHandler: requer('treinamento.editar'),
    schema: { tags, summary: 'Cancela matricula em andamento (CancelarMatricula)', params: paramId, response: erros },
  }, (req) => naTransacao(req, async (casos, ctx, c) => {
    exigirOk(await casos.cancelarMatricula.execute(ctx, { id: req.params.id }));
    return obterMatricula(c, req.params.id);
  }));
}
