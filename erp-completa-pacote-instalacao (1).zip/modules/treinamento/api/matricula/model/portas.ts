/** Portas do agregado Matricula, segregadas por operacao. */
import type { Matricula } from './matricula.ts';

export interface ObterMatricula {
  obterPorId(id: string): Promise<Matricula | null>;
  /** Matricula viva (em andamento ou concluida) da pessoa no curso. */
  matriculaViva(funcionarioId: string, cursoId: string): Promise<Matricula | null>;
}

export interface GravarMatricula {
  inserir(m: Matricula): Promise<void>;
  /** Atualiza estado, conclusao e certificado e grava as aulas concluidas que faltam. */
  atualizar(m: Matricula): Promise<void>;
}

export interface CursoParaMatricula {
  id: string;
  titulo: string;
  estado: 'rascunho' | 'publicado' | 'arquivado';
  emite_certificado: boolean;
  prerequisito_curso_id: string | null;
  aulas: { id: string; prerequisito_aula_id: string | null }[];
}

/** Leituras fora do agregado: pessoa (tabela publicada do Pessoas), curso e trilha do proprio modulo. */
export interface ConsultarParaMatricula {
  funcionarioAtivo(id: string): Promise<{ id: string; nome: string; usuario_id: string | null } | null>;
  funcionarioDoUsuario(usuarioId: string): Promise<string | null>;
  curso(id: string): Promise<CursoParaMatricula | null>;
  cursoConcluido(funcionarioId: string, cursoId: string): Promise<boolean>;
  trilha(id: string): Promise<{ id: string; estado: 'ativa' | 'arquivada'; curso_ids: string[] } | null>;
  trilhasAtivasDaFuncao(funcaoId: string): Promise<string[]>;
}
