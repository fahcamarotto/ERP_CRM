/**
 * Entidade Matricula (M11.4): progresso de uma pessoa (funcionario do Pessoas) em um curso, conclusao e certificado interno.
 * Regras de pre-requisito (curso e aula) e conclusao automatica moram aqui. Imutavel: devolve clone.
 */
import { randomUUID } from 'node:crypto';
import { erroDe, fail, ok, type ErroDominio, type Result } from '../../compartilhado/result.ts';
import { CodigoCertificado } from './certificado.ts';

export const ESTADOS_MATRICULA = ['em_andamento', 'concluida', 'cancelada'] as const;
export type EstadoMatricula = (typeof ESTADOS_MATRICULA)[number];
export const ORIGENS = ['manual', 'trilha', 'admissao'] as const;
export type OrigemMatricula = (typeof ORIGENS)[number];

export const TRANSICOES_MATRICULA: Record<EstadoMatricula, EstadoMatricula[]> = {
  em_andamento: ['concluida', 'cancelada'],
  concluida: [],
  cancelada: [],
};

export interface DadosMatricula {
  funcionario_id: string;
  curso_id: string;
  trilha_id?: string | null;
  origem?: OrigemMatricula;
}

export interface MatriculaDados {
  id: string;
  funcionario_id: string;
  curso_id: string;
  trilha_id: string | null;
  origem: OrigemMatricula;
  estado: EstadoMatricula;
  concluida_em: string | null;
  certificado_codigo: string | null;
  aulas_concluidas: string[];
}

/** O que a matricula precisa saber do curso para registrar progresso. */
export interface CursoParaProgresso {
  aulas: { id: string; prerequisito_aula_id: string | null }[];
  emite_certificado: boolean;
  /** Curso pre-requisito ainda nao concluido pela pessoa (null quando nao ha ou ja concluiu). */
  prerequisito_pendente: string | null;
}

const uuidOk = (v: string) => /^[0-9a-f-]{36}$/i.test(v);

function validar(d: MatriculaDados): ErroDominio[] {
  const e: ErroDominio[] = [];
  if (!uuidOk(d.funcionario_id)) e.push(erroDe('funcionario_invalido', 'Funcionario obrigatorio', 'funcionario_id'));
  if (!uuidOk(d.curso_id)) e.push(erroDe('curso_invalido', 'Curso obrigatorio', 'curso_id'));
  if (d.trilha_id !== null && !uuidOk(d.trilha_id)) e.push(erroDe('trilha_invalida', 'Trilha invalida', 'trilha_id'));
  if (!ORIGENS.includes(d.origem)) e.push(erroDe('origem_invalida', 'Origem invalida', 'origem'));
  return e;
}

export class Matricula {
  private constructor(private readonly d: MatriculaDados) {}

  static tryCreate(e: DadosMatricula, id: string = randomUUID()): Result<Matricula> {
    const d: MatriculaDados = {
      id, funcionario_id: (e.funcionario_id ?? '').trim(), curso_id: (e.curso_id ?? '').trim(), trilha_id: e.trilha_id?.trim() || null,
      origem: e.origem ?? (e.trilha_id ? 'trilha' : 'manual'), estado: 'em_andamento', concluida_em: null, certificado_codigo: null, aulas_concluidas: [],
    };
    const erros = validar(d);
    return erros.length ? fail(...erros) : ok(new Matricula(d));
  }

  static create(e: DadosMatricula, id?: string): Matricula {
    const r = Matricula.tryCreate(e, id);
    if (!r.ok) throw new Error(r.erros.map((x) => x.mensagem).join('; '));
    return r.valor;
  }

  static reidratar(d: MatriculaDados): Matricula {
    return new Matricula({ ...d, aulas_concluidas: [...d.aulas_concluidas] });
  }

  get id(): string { return this.d.id; }
  get estado(): EstadoMatricula { return this.d.estado; }
  get funcionarioId(): string { return this.d.funcionario_id; }
  get cursoId(): string { return this.d.curso_id; }
  get aulasConcluidas(): string[] { return [...this.d.aulas_concluidas]; }

  /**
   * Marca a aula como concluida. Idempotente para aula ja concluida. Quando todas as aulas do curso estao concluidas,
   * a matricula vira `concluida` e recebe o codigo de certificado (se o curso emite).
   */
  concluirAula(aulaId: string, curso: CursoParaProgresso, agora: Date = new Date()): Result<{ matricula: Matricula; concluiuCurso: boolean; nova: boolean }> {
    if (this.d.estado !== 'em_andamento') {
      return fail(erroDe('transicao_invalida', `Matricula ${this.d.estado} nao aceita progresso`, 'estado'));
    }
    const aula = curso.aulas.find((a) => a.id === aulaId);
    if (!aula) return fail(erroDe('aula_invalida', 'Aula nao pertence a este curso', 'aula_id'));
    if (curso.prerequisito_pendente) {
      return fail(erroDe('prerequisito_pendente', 'Conclua o curso pre-requisito antes', 'curso_id', { curso_id: curso.prerequisito_pendente }));
    }
    const feitas = new Set(this.d.aulas_concluidas);
    if (feitas.has(aulaId)) return ok({ matricula: this, concluiuCurso: false, nova: false });
    if (aula.prerequisito_aula_id && !feitas.has(aula.prerequisito_aula_id)) {
      return fail(erroDe('prerequisito_pendente', 'Conclua a aula pre-requisito antes', 'aula_id', { aula_id: aula.prerequisito_aula_id }));
    }
    feitas.add(aulaId);
    const todas = curso.aulas.every((a) => feitas.has(a.id));
    const n: MatriculaDados = {
      ...this.d,
      aulas_concluidas: [...this.d.aulas_concluidas, aulaId],
      ...(todas ? {
        estado: 'concluida' as const,
        concluida_em: agora.toISOString(),
        certificado_codigo: curso.emite_certificado ? CodigoCertificado.gerar(this.d.id).valor : null,
      } : {}),
    };
    return ok({ matricula: new Matricula(n), concluiuCurso: todas, nova: true });
  }

  cancelar(): Result<Matricula> {
    if (!TRANSICOES_MATRICULA[this.d.estado].includes('cancelada')) {
      return fail(erroDe('transicao_invalida', `Matricula ${this.d.estado} nao pode ser cancelada`, 'estado', { permitidas: TRANSICOES_MATRICULA[this.d.estado] }));
    }
    return ok(new Matricula({ ...this.d, estado: 'cancelada' }));
  }

  /** Percentual de 0 a 100 dado o total de aulas do curso. */
  percentual(totalAulas: number): number {
    if (this.d.estado === 'concluida') return 100;
    return totalAulas ? Math.floor((this.d.aulas_concluidas.length * 100) / totalAulas) : 0;
  }

  paraDados(): MatriculaDados {
    return { ...this.d, aulas_concluidas: [...this.d.aulas_concluidas] };
  }
}
