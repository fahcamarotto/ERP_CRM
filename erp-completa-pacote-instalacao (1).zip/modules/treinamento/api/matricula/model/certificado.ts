/** Objeto de valor CodigoCertificado (M11.4): codigo interno verificavel `TRN-XXXX-XXXX`, derivado da matricula. */
import { createHash } from 'node:crypto';
import { erroDe, fail, ok, type Result } from '../../compartilhado/result.ts';

const FORMATO = /^TRN-[0-9A-F]{4}-[0-9A-F]{4}$/;

export class CodigoCertificado {
  private constructor(readonly valor: string) {}

  /** Deterministico: a mesma matricula sempre gera o mesmo codigo. */
  static gerar(matriculaId: string): CodigoCertificado {
    const h = createHash('sha256').update(`treinamento-certificado:${matriculaId}`).digest('hex').toUpperCase();
    return new CodigoCertificado(`TRN-${h.slice(0, 4)}-${h.slice(4, 8)}`);
  }

  static tryCreate(bruto: string): Result<CodigoCertificado> {
    const v = (bruto ?? '').trim().toUpperCase();
    return FORMATO.test(v) ? ok(new CodigoCertificado(v)) : fail(erroDe('certificado_invalido', 'Codigo de certificado no formato TRN-XXXX-XXXX', 'codigo'));
  }

  static create(bruto: string): CodigoCertificado {
    const r = CodigoCertificado.tryCreate(bruto);
    if (!r.ok) throw new Error(r.erros[0]!.mensagem);
    return r.valor;
  }
}
