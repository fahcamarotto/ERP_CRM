/**
 * Adaptador Postgres das portas do agregado Matricula. Pessoa lida da tabela publicada pessoas_funcionarios
 * (CONTRATOS 7.1.7); nada e gravado fora das tabelas treinamento_*.
 */
import type pg from 'pg';
import { Matricula, type MatriculaDados } from '../model/matricula.ts';
import type { ConsultarParaMatricula, CursoParaMatricula, GravarMatricula, ObterMatricula } from '../model/portas.ts';

const SELECAO = `SELECT m.id, m.funcionario_id, m.curso_id, m.trilha_id, m.origem, m.estado, m.concluida_em, m.certificado_codigo,
  coalesce((SELECT array_agg(p.aula_id ORDER BY p.concluida_em) FROM treinamento_progresso p WHERE p.matricula_id = m.id AND p.deleted_at IS NULL), '{}') AS aulas_concluidas
  FROM treinamento_matriculas m`;

function deLinha(l: Record<string, unknown>): Matricula {
  const conc = l.concluida_em as Date | string | null;
  return Matricula.reidratar({ ...(l as unknown as MatriculaDados), concluida_em: conc ? new Date(conc).toISOString() : null });
}

export class MatriculaRepoPg implements ObterMatricula, GravarMatricula, ConsultarParaMatricula {
  constructor(private readonly c: pg.PoolClient) {}

  async obterPorId(id: string): Promise<Matricula | null> {
    const r = await this.c.query(`${SELECAO} WHERE m.id = $1 AND m.deleted_at IS NULL`, [id]);
    return r.rows[0] ? deLinha(r.rows[0]) : null;
  }

  async matriculaViva(funcionarioId: string, cursoId: string): Promise<Matricula | null> {
    const r = await this.c.query(`${SELECAO} WHERE m.funcionario_id = $1 AND m.curso_id = $2 AND m.estado <> 'cancelada' AND m.deleted_at IS NULL`, [funcionarioId, cursoId]);
    return r.rows[0] ? deLinha(r.rows[0]) : null;
  }

  async inserir(m: Matricula): Promise<void> {
    const d = m.paraDados();
    await this.c.query(
      `INSERT INTO treinamento_matriculas (id, funcionario_id, curso_id, trilha_id, origem, estado, concluida_em, certificado_codigo, creator_id)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, nucleo_usuario_atual())`,
      [d.id, d.funcionario_id, d.curso_id, d.trilha_id, d.origem, d.estado, d.concluida_em, d.certificado_codigo],
    );
    await this.gravarProgresso(d);
  }

  async atualizar(m: Matricula): Promise<void> {
    const d = m.paraDados();
    await this.c.query(
      'UPDATE treinamento_matriculas SET estado = $2, concluida_em = $3, certificado_codigo = $4 WHERE id = $1 AND deleted_at IS NULL',
      [d.id, d.estado, d.concluida_em, d.certificado_codigo],
    );
    await this.gravarProgresso(d);
  }

  private async gravarProgresso(d: MatriculaDados): Promise<void> {
    if (!d.aulas_concluidas.length) return;
    await this.c.query(
      `INSERT INTO treinamento_progresso (matricula_id, aula_id, creator_id) SELECT $1, a, nucleo_usuario_atual() FROM unnest($2::uuid[]) a
       ON CONFLICT (tenant_id, workspace_id, matricula_id, aula_id) DO UPDATE SET deleted_at = NULL`,
      [d.id, d.aulas_concluidas],
    );
  }

  async funcionarioAtivo(id: string) {
    const r = await this.c.query("SELECT id, nome, usuario_id FROM pessoas_funcionarios WHERE id = $1 AND estado <> 'desligado' AND deleted_at IS NULL", [id]);
    return (r.rows[0] as { id: string; nome: string; usuario_id: string | null } | undefined) ?? null;
  }

  async funcionarioDoUsuario(usuarioId: string): Promise<string | null> {
    const r = await this.c.query('SELECT id FROM pessoas_funcionarios WHERE usuario_id = $1 AND deleted_at IS NULL LIMIT 1', [usuarioId]);
    return (r.rows[0]?.id as string | undefined) ?? null;
  }

  async curso(id: string): Promise<CursoParaMatricula | null> {
    const r = await this.c.query(
      `SELECT c.id, c.titulo, c.estado, c.emite_certificado, c.prerequisito_curso_id,
         coalesce((SELECT json_agg(json_build_object('id', a.id, 'prerequisito_aula_id', a.prerequisito_aula_id) ORDER BY a.ordem)
           FROM treinamento_aulas a WHERE a.curso_id = c.id AND a.deleted_at IS NULL), '[]'::json) AS aulas
       FROM treinamento_cursos c WHERE c.id = $1 AND c.deleted_at IS NULL`,
      [id],
    );
    return (r.rows[0] as CursoParaMatricula | undefined) ?? null;
  }

  async cursoConcluido(funcionarioId: string, cursoId: string): Promise<boolean> {
    const r = await this.c.query(
      "SELECT 1 FROM treinamento_matriculas WHERE funcionario_id = $1 AND curso_id = $2 AND estado = 'concluida' AND deleted_at IS NULL", [funcionarioId, cursoId]);
    return (r.rowCount ?? 0) > 0;
  }

  async trilha(id: string) {
    const r = await this.c.query(
      `SELECT t.id, t.estado, coalesce((SELECT array_agg(tc.curso_id ORDER BY tc.ordem) FROM treinamento_trilha_cursos tc
         WHERE tc.trilha_id = t.id AND tc.deleted_at IS NULL), '{}') AS curso_ids
       FROM treinamento_trilhas t WHERE t.id = $1 AND t.deleted_at IS NULL`,
      [id],
    );
    return (r.rows[0] as { id: string; estado: 'ativa' | 'arquivada'; curso_ids: string[] } | undefined) ?? null;
  }

  async trilhasAtivasDaFuncao(funcaoId: string): Promise<string[]> {
    const r = await this.c.query("SELECT id FROM treinamento_trilhas WHERE funcao_id = $1 AND estado = 'ativa' AND deleted_at IS NULL ORDER BY created_at", [funcaoId]);
    return r.rows.map((x) => x.id as string);
  }
}
