/**
 * Consultas de leitura da Matricula: aba Progresso (percentual por pessoa e curso), area de membros
 * (curso com aulas, materiais e o que ja foi concluido) e verificacao de certificado.
 */
import type pg from 'pg';
import { decodificarCursor, pagina } from '../../compartilhado/cursor.ts';
import { AULAS_JSON, MODULOS_JSON } from '../../curso/query/cursos.ts';

const RESUMO = `m.id, m.funcionario_id, f.nome AS funcionario_nome, m.curso_id, c.titulo AS curso_titulo, m.trilha_id, t.nome AS trilha_nome,
  m.origem, m.estado, m.concluida_em, m.certificado_codigo, m.created_at, m.updated_at,
  (SELECT count(*)::int FROM treinamento_aulas a WHERE a.curso_id = m.curso_id AND a.deleted_at IS NULL) AS total_aulas,
  (SELECT count(*)::int FROM treinamento_progresso p JOIN treinamento_aulas a ON a.id = p.aula_id AND a.deleted_at IS NULL
    WHERE p.matricula_id = m.id AND p.deleted_at IS NULL) AS aulas_concluidas`;

const JUNCOES = `FROM treinamento_matriculas m
  JOIN treinamento_cursos c ON c.id = m.curso_id
  LEFT JOIN pessoas_funcionarios f ON f.id = m.funcionario_id
  LEFT JOIN treinamento_trilhas t ON t.id = m.trilha_id`;

const comPercentual = <T extends { estado: string; total_aulas: number; aulas_concluidas: number }>(l: T) =>
  ({ ...l, percentual: l.estado === 'concluida' ? 100 : l.total_aulas ? Math.floor((l.aulas_concluidas * 100) / l.total_aulas) : 0 });

export interface FiltroMatriculas {
  estado?: string;
  funcionario_id?: string;
  curso_id?: string;
  trilha_id?: string;
  busca?: string;
  limite?: number;
  cursor?: string;
}

export async function listarMatriculas(c: pg.PoolClient, f: FiltroMatriculas) {
  const lim = Math.min(Math.max(f.limite ?? 50, 1), 200);
  const cur = decodificarCursor(f.cursor);
  const r = await c.query(
    `SELECT ${RESUMO} ${JUNCOES}
     WHERE m.deleted_at IS NULL AND ($1::text IS NULL OR m.estado = $1) AND ($2::uuid IS NULL OR m.funcionario_id = $2)
       AND ($3::uuid IS NULL OR m.curso_id = $3) AND ($4::uuid IS NULL OR m.trilha_id = $4)
       AND ($5::text IS NULL OR f.nome ILIKE '%' || $5 || '%' OR c.titulo ILIKE '%' || $5 || '%')
       AND ($6::timestamptz IS NULL OR (m.created_at, m.id) > ($6::timestamptz, $7::uuid))
     ORDER BY m.created_at, m.id LIMIT $8`,
    [f.estado ?? null, f.funcionario_id ?? null, f.curso_id ?? null, f.trilha_id ?? null, f.busca?.trim() || null, cur?.[0] ?? null, cur?.[1] ?? null, lim + 1],
  );
  const p = pagina(r.rows, lim);
  return { ...p, itens: p.itens.map(comPercentual) };
}

/** Area de membros (M11.3): matricula com o curso inteiro e a lista de aulas concluidas. */
export async function obterMatricula(c: pg.PoolClient, id: string) {
  const r = await c.query(
    `SELECT ${RESUMO}, c.descricao AS curso_descricao, c.emite_certificado, c.prerequisito_curso_id, pc.titulo AS prerequisito_titulo,
       ${MODULOS_JSON} AS modulos, ${AULAS_JSON} AS aulas,
       coalesce((SELECT json_agg(p.aula_id) FROM treinamento_progresso p WHERE p.matricula_id = m.id AND p.deleted_at IS NULL), '[]'::json) AS concluidas
     ${JUNCOES} LEFT JOIN treinamento_cursos pc ON pc.id = c.prerequisito_curso_id
     WHERE m.id = $1 AND m.deleted_at IS NULL`,
    [id],
  );
  return r.rows[0] ? comPercentual(r.rows[0]) : null;
}

/** Verificacao do certificado interno pelo codigo. */
export async function obterCertificado(c: pg.PoolClient, codigo: string) {
  const r = await c.query(
    `SELECT m.certificado_codigo AS codigo, m.id AS matricula_id, f.nome AS funcionario_nome, c.titulo AS curso_titulo, m.concluida_em,
       (SELECT coalesce(sum(a.duracao_min), 0)::int FROM treinamento_aulas a WHERE a.curso_id = c.id AND a.deleted_at IS NULL) AS carga_min
     ${JUNCOES} WHERE m.certificado_codigo = upper($1) AND m.estado = 'concluida' AND m.deleted_at IS NULL`,
    [codigo],
  );
  return r.rows[0] ?? null;
}

/** Opcoes dos formularios: pessoas ativas e funcoes (tabelas publicadas do Pessoas, CONTRATOS 7.1.7). */
export async function opcoesPessoas(c: pg.PoolClient) {
  const f = await c.query("SELECT id, nome, funcao_id, usuario_id FROM pessoas_funcionarios WHERE estado <> 'desligado' AND deleted_at IS NULL ORDER BY nome LIMIT 500");
  const fn = await c.query("SELECT id, nome FROM pessoas_funcoes WHERE estado = 'ativo' AND deleted_at IS NULL ORDER BY nome LIMIT 500");
  return { funcionarios: f.rows, funcoes: fn.rows };
}
