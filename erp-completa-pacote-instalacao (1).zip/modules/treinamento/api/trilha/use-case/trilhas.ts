/** Casos de uso da Trilha (M11.5): CriarTrilha, EditarTrilha, ArquivarTrilha e ReativarTrilha. */
import { erroDe, fail, ok, okVazio, type ErroDominio, type Result } from '../../compartilhado/result.ts';
import type { ContextoCaso } from '../../compartilhado/efeitos.ts';
import { Trilha, type DadosTrilha } from '../model/trilha.ts';
import type { ConsultarReferenciasTrilha, GravarTrilha, ObterTrilha } from '../model/portas.ts';

export interface DepsTrilha {
  repo: ObterTrilha & GravarTrilha;
  refs: ConsultarReferenciasTrilha;
}

const TABELA = 'treinamento_trilhas';

async function conferir(deps: DepsTrilha, t: Trilha, anterior?: Trilha): Promise<ErroDominio[]> {
  const erros: ErroDominio[] = [];
  const d = t.paraDados();
  const dono = await deps.repo.buscarPorNome(d.nome);
  if (dono && dono.id !== d.id) erros.push(erroDe('conflito', 'Ja existe trilha com este nome', 'nome', { trilha_id: dono.id }));
  if (d.funcao_id && d.funcao_id !== anterior?.funcaoId && !(await deps.refs.funcaoAtiva(d.funcao_id))) {
    erros.push(erroDe('funcao_invalida', 'Funcao nao encontrada ou arquivada', 'funcao_id'));
  }
  if (d.curso_ids.length) {
    const existem = new Set(await deps.refs.cursosExistentes(d.curso_ids));
    const faltam = d.curso_ids.filter((x) => !existem.has(x));
    if (faltam.length) erros.push(erroDe('curso_invalido', 'Curso da trilha nao encontrado', 'curso_ids', { faltam }));
  }
  return erros;
}

export class CriarTrilha {
  constructor(private readonly deps: DepsTrilha) {}
  async execute(ctx: ContextoCaso, e: DadosTrilha): Promise<Result<{ id: string }>> {
    const r = Trilha.tryCreate(e);
    if (!r.ok) return r;
    const erros = await conferir(this.deps, r.valor);
    if (erros.length) return fail(...erros);
    await this.deps.repo.inserir(r.valor);
    const d = r.valor.paraDados();
    await ctx.efeitos.auditar('trilha.criar', TABELA, d.id, undefined, d);
    return ok({ id: d.id });
  }
}

export class EditarTrilha {
  constructor(private readonly deps: DepsTrilha) {}
  async execute(ctx: ContextoCaso, e: { id: string } & Partial<DadosTrilha>): Promise<Result<void>> {
    const { id, ...mud } = e;
    const atual = await this.deps.repo.obterPorId(id);
    if (!atual) return fail(erroDe('nao_encontrado', 'Trilha nao encontrada'));
    const r = atual.editar(mud);
    if (!r.ok) return r;
    const erros = await conferir(this.deps, r.valor, atual);
    if (erros.length) return fail(...erros);
    await this.deps.repo.atualizar(r.valor);
    const antes = atual.paraDados() as unknown as Record<string, unknown>;
    const depois = r.valor.paraDados() as unknown as Record<string, unknown>;
    await ctx.efeitos.historico(TABELA, id, antes, depois);
    await ctx.efeitos.auditar('trilha.editar', TABELA, id, antes, depois);
    return okVazio();
  }
}

abstract class MudarSituacao {
  constructor(private readonly deps: { repo: ObterTrilha & GravarTrilha }) {}
  protected abstract aplicar(t: Trilha): Result<Trilha>;
  protected abstract acao: string;
  async execute(ctx: ContextoCaso, e: { id: string }): Promise<Result<void>> {
    const atual = await this.deps.repo.obterPorId(e.id);
    if (!atual) return fail(erroDe('nao_encontrado', 'Trilha nao encontrada'));
    const r = this.aplicar(atual);
    if (!r.ok) return r;
    await this.deps.repo.atualizar(r.valor);
    await ctx.efeitos.historico(TABELA, e.id, { estado: atual.estado }, { estado: r.valor.estado });
    await ctx.efeitos.auditar(this.acao, TABELA, e.id, { estado: atual.estado }, { estado: r.valor.estado });
    return okVazio();
  }
}

export class ArquivarTrilha extends MudarSituacao {
  protected acao = 'trilha.arquivar';
  protected aplicar(t: Trilha) { return t.arquivar(); }
}

export class ReativarTrilha extends MudarSituacao {
  protected acao = 'trilha.reativar';
  protected aplicar(t: Trilha) { return t.reativar(); }
}
