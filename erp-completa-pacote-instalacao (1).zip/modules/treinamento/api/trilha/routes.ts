/** Rotas REST da Trilha fora das tools: ficha, edicao, arquivar, reativar e opcoes do Pessoas. */
import { esquemaErro, requer, type FastifyInstance } from '@erp/api/sdk';
import { naTransacao, naoEncontrado } from '../borda.ts';
import { exigirOk } from '../compartilhado/result.ts';
import { propsTrilha, uuid } from '../esquemas.ts';
import { opcoesPessoas } from '../matricula/query/matriculas.ts';
import type { DadosTrilha } from './model/trilha.ts';
import { obterTrilha } from './query/trilhas.ts';

const tags = ['treinamento'];
const paramId = { type: 'object', required: ['id'], properties: { id: uuid } } as const;
const erros = { 400: esquemaErro, 403: esquemaErro, 404: esquemaErro, 409: esquemaErro };

export function rotasTrilha(app: FastifyInstance): void {
  // Leitura das tabelas publicadas pessoas_funcionarios e pessoas_funcoes (CONTRATOS 7.1.7).
  app.get('/opcoes', {
    preHandler: requer('treinamento.ver'),
    schema: { tags, summary: 'Pessoas ativas e funcoes (seletores de matricula e trilha)' },
  }, (req) => naTransacao(req, async (_, __, c) => opcoesPessoas(c)));

  app.get<{ Params: { id: string } }>('/trilhas/:id', {
    preHandler: requer('treinamento.ver'),
    schema: { tags, summary: 'Ficha da trilha com cursos em ordem', params: paramId, response: { 404: esquemaErro } },
  }, (req) => naTransacao(req, async (_, __, c) => (await obterTrilha(c, req.params.id)) ?? Promise.reject(naoEncontrado('Trilha nao encontrada'))));

  app.patch<{ Params: { id: string }; Body: Partial<DadosTrilha> }>('/trilhas/:id', {
    preHandler: requer('treinamento.editar'),
    schema: { tags, summary: 'Edita trilha (EditarTrilha)', params: paramId, body: { type: 'object', additionalProperties: false, properties: propsTrilha }, response: erros },
  }, (req) => naTransacao(req, async (casos, ctx, c) => {
    exigirOk(await casos.editarTrilha.execute(ctx, { ...req.body, id: req.params.id }));
    return obterTrilha(c, req.params.id);
  }));

  for (const acao of ['arquivar', 'reativar'] as const) {
    app.post<{ Params: { id: string } }>(`/trilhas/:id/${acao}`, {
      preHandler: requer('treinamento.editar'),
      schema: { tags, summary: `${acao === 'arquivar' ? 'Arquiva' : 'Reativa'} trilha`, params: paramId, response: erros },
    }, (req) => naTransacao(req, async (casos, ctx, c) => {
      const caso = acao === 'arquivar' ? casos.arquivarTrilha : casos.reativarTrilha;
      exigirOk(await caso.execute(ctx, { id: req.params.id }));
      return obterTrilha(c, req.params.id);
    }));
  }
}
