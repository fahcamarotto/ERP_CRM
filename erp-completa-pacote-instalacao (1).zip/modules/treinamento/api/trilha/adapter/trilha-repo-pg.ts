/** Adaptador Postgres das portas do agregado Trilha. Funcao lida da tabela publicada pessoas_funcoes (CONTRATOS 7.1). */
import type pg from 'pg';
import { Trilha, type TrilhaDados } from '../model/trilha.ts';
import type { ConsultarReferenciasTrilha, GravarTrilha, ObterTrilha } from '../model/portas.ts';

const SELECAO = `SELECT t.id, t.nome, t.descricao, t.funcao_id, t.estado, t.extras,
  coalesce((SELECT array_agg(tc.curso_id ORDER BY tc.ordem) FROM treinamento_trilha_cursos tc WHERE tc.trilha_id = t.id AND tc.deleted_at IS NULL), '{}') AS curso_ids
  FROM treinamento_trilhas t`;

export class TrilhaRepoPg implements ObterTrilha, GravarTrilha, ConsultarReferenciasTrilha {
  constructor(private readonly c: pg.PoolClient) {}

  async obterPorId(id: string): Promise<Trilha | null> {
    const r = await this.c.query(`${SELECAO} WHERE t.id = $1 AND t.deleted_at IS NULL`, [id]);
    return r.rows[0] ? Trilha.reidratar(r.rows[0] as TrilhaDados) : null;
  }

  async buscarPorNome(nome: string): Promise<Trilha | null> {
    const r = await this.c.query(`${SELECAO} WHERE lower(t.nome) = lower($1) AND t.deleted_at IS NULL`, [nome]);
    return r.rows[0] ? Trilha.reidratar(r.rows[0] as TrilhaDados) : null;
  }

  async inserir(t: Trilha): Promise<void> {
    const d = t.paraDados();
    await this.c.query(
      `INSERT INTO treinamento_trilhas (id, nome, descricao, funcao_id, estado, extras, creator_id) VALUES ($1, $2, $3, $4, $5, $6, nucleo_usuario_atual())`,
      [d.id, d.nome, d.descricao, d.funcao_id, d.estado, JSON.stringify(d.extras)],
    );
    await this.sincronizarCursos(d.id, d.curso_ids);
  }

  async atualizar(t: Trilha): Promise<void> {
    const d = t.paraDados();
    await this.c.query(
      'UPDATE treinamento_trilhas SET nome = $2, descricao = $3, funcao_id = $4, estado = $5, extras = $6 WHERE id = $1 AND deleted_at IS NULL',
      [d.id, d.nome, d.descricao, d.funcao_id, d.estado, JSON.stringify(d.extras)],
    );
    await this.sincronizarCursos(d.id, d.curso_ids);
  }

  /** Ligacao N para N com ordem: sai quem nao esta na lista, entra ou volta quem esta, na posicao da lista. */
  private async sincronizarCursos(trilhaId: string, ids: string[]): Promise<void> {
    await this.c.query(
      'UPDATE treinamento_trilha_cursos SET deleted_at = now() WHERE trilha_id = $1 AND deleted_at IS NULL AND NOT (curso_id = ANY ($2::uuid[]))',
      [trilhaId, ids],
    );
    if (!ids.length) return;
    await this.c.query(
      `INSERT INTO treinamento_trilha_cursos (trilha_id, curso_id, ordem, creator_id)
       SELECT $1, x.curso_id, x.ordem::int, nucleo_usuario_atual() FROM unnest($2::uuid[]) WITH ORDINALITY AS x(curso_id, ordem)
       ON CONFLICT (tenant_id, workspace_id, trilha_id, curso_id) DO UPDATE SET deleted_at = NULL, ordem = EXCLUDED.ordem`,
      [trilhaId, ids],
    );
  }

  async funcaoAtiva(id: string): Promise<boolean> {
    const r = await this.c.query("SELECT 1 FROM pessoas_funcoes WHERE id = $1 AND estado = 'ativo' AND deleted_at IS NULL", [id]);
    return (r.rowCount ?? 0) > 0;
  }

  async cursosExistentes(ids: string[]): Promise<string[]> {
    const r = await this.c.query('SELECT id FROM treinamento_cursos WHERE id = ANY ($1::uuid[]) AND deleted_at IS NULL', [ids]);
    return r.rows.map((x) => x.id as string);
  }
}
