/**
 * Entidade Trilha (M11.5): sequencia de cursos para uma funcao do Pessoas.
 * Funcionario admitido na funcao recebe a trilha (reacao a funcionario.admitido). Imutavel.
 */
import { randomUUID } from 'node:crypto';
import { erroDe, fail, ok, type ErroDominio, type Result } from '../../compartilhado/result.ts';

export const ESTADOS_TRILHA = ['ativa', 'arquivada'] as const;
export type EstadoTrilha = (typeof ESTADOS_TRILHA)[number];

export interface DadosTrilha {
  nome: string;
  descricao?: string | null;
  funcao_id?: string | null;
  curso_ids?: string[];
  extras?: Record<string, unknown>;
}

export interface TrilhaDados {
  id: string;
  nome: string;
  descricao: string | null;
  funcao_id: string | null;
  curso_ids: string[];
  estado: EstadoTrilha;
  extras: Record<string, unknown>;
}

const t = (v?: string | null) => (v ?? '').trim() || null;

function validar(d: TrilhaDados): ErroDominio[] {
  const e: ErroDominio[] = [];
  if (d.nome.length < 2 || d.nome.length > 200) e.push(erroDe('nome_invalido', 'Nome deve ter de 2 a 200 caracteres', 'nome'));
  if (d.descricao && d.descricao.length > 4000) e.push(erroDe('descricao_invalida', 'Descricao com no maximo 4000 caracteres', 'descricao'));
  if (d.curso_ids.length > 100) e.push(erroDe('cursos_invalidos', 'No maximo 100 cursos por trilha', 'curso_ids'));
  return e;
}

export class Trilha {
  private constructor(private readonly d: TrilhaDados) {}

  static tryCreate(e: DadosTrilha, id: string = randomUUID()): Result<Trilha> {
    const d: TrilhaDados = {
      id, nome: (e.nome ?? '').trim(), descricao: t(e.descricao), funcao_id: t(e.funcao_id),
      curso_ids: [...new Set(e.curso_ids ?? [])], estado: 'ativa', extras: e.extras ?? {},
    };
    const erros = validar(d);
    return erros.length ? fail(...erros) : ok(new Trilha(d));
  }

  static create(e: DadosTrilha, id?: string): Trilha {
    const r = Trilha.tryCreate(e, id);
    if (!r.ok) throw new Error(r.erros.map((x) => x.mensagem).join('; '));
    return r.valor;
  }

  static reidratar(d: TrilhaDados): Trilha {
    return new Trilha({ ...d, curso_ids: [...d.curso_ids], extras: { ...(d.extras ?? {}) } });
  }

  get id(): string { return this.d.id; }
  get nome(): string { return this.d.nome; }
  get estado(): EstadoTrilha { return this.d.estado; }
  get funcaoId(): string | null { return this.d.funcao_id; }
  get cursoIds(): string[] { return [...this.d.curso_ids]; }

  editar(e: Partial<DadosTrilha>): Result<Trilha> {
    if (this.d.estado === 'arquivada') return fail(erroDe('transicao_invalida', 'Trilha arquivada nao pode ser editada; reative antes'));
    const tem = (k: keyof DadosTrilha) => e[k] !== undefined;
    const n: TrilhaDados = {
      ...this.d,
      nome: tem('nome') ? (e.nome ?? '').trim() : this.d.nome,
      descricao: tem('descricao') ? t(e.descricao) : this.d.descricao,
      funcao_id: tem('funcao_id') ? t(e.funcao_id) : this.d.funcao_id,
      curso_ids: tem('curso_ids') ? [...new Set(e.curso_ids!)] : [...this.d.curso_ids],
      extras: tem('extras') ? { ...e.extras } : { ...this.d.extras },
    };
    const erros = validar(n);
    return erros.length ? fail(...erros) : ok(new Trilha(n));
  }

  arquivar(): Result<Trilha> {
    if (this.d.estado === 'arquivada') return fail(erroDe('transicao_invalida', 'Trilha ja arquivada', 'estado'));
    return ok(new Trilha({ ...this.d, estado: 'arquivada' }));
  }

  reativar(): Result<Trilha> {
    if (this.d.estado === 'ativa') return fail(erroDe('transicao_invalida', 'Trilha ja ativa', 'estado'));
    return ok(new Trilha({ ...this.d, estado: 'ativa' }));
  }

  paraDados(): TrilhaDados {
    return { ...this.d, curso_ids: [...this.d.curso_ids], extras: { ...this.d.extras } };
  }
}
