/** Portas do agregado Trilha, segregadas por operacao. */
import type { Trilha } from './trilha.ts';

export interface ObterTrilha {
  obterPorId(id: string): Promise<Trilha | null>;
  buscarPorNome(nome: string): Promise<Trilha | null>;
}

export interface GravarTrilha {
  inserir(t: Trilha): Promise<void>;
  atualizar(t: Trilha): Promise<void>;
}

/** Referencias fora do agregado: funcao publicada pelo Pessoas e cursos do proprio modulo. */
export interface ConsultarReferenciasTrilha {
  funcaoAtiva(id: string): Promise<boolean>;
  cursosExistentes(ids: string[]): Promise<string[]>;
}
