/** Consultas de leitura da Trilha: lista com funcao e cursos em ordem, mais contagem de pessoas atribuidas. */
import type pg from 'pg';
import { decodificarCursor, pagina } from '../../compartilhado/cursor.ts';

const RESUMO = `t.id, t.nome, t.descricao, t.funcao_id, f.nome AS funcao_nome, t.estado, t.created_at, t.updated_at,
  coalesce((SELECT json_agg(json_build_object('id', c.id, 'titulo', c.titulo, 'estado', c.estado, 'ordem', tc.ordem) ORDER BY tc.ordem)
    FROM treinamento_trilha_cursos tc JOIN treinamento_cursos c ON c.id = tc.curso_id AND c.deleted_at IS NULL
    WHERE tc.trilha_id = t.id AND tc.deleted_at IS NULL), '[]'::json) AS cursos,
  (SELECT count(DISTINCT m.funcionario_id)::int FROM treinamento_matriculas m WHERE m.trilha_id = t.id AND m.estado <> 'cancelada' AND m.deleted_at IS NULL) AS pessoas`;

const JUNCOES = 'FROM treinamento_trilhas t LEFT JOIN pessoas_funcoes f ON f.id = t.funcao_id AND f.deleted_at IS NULL';

export async function listarTrilhas(c: pg.PoolClient, f: { estado?: string; busca?: string; limite?: number; cursor?: string }) {
  const lim = Math.min(Math.max(f.limite ?? 50, 1), 200);
  const cur = decodificarCursor(f.cursor);
  const r = await c.query(
    `SELECT ${RESUMO} ${JUNCOES}
     WHERE t.deleted_at IS NULL AND ($1::text IS NULL OR t.estado = $1) AND ($2::text IS NULL OR t.nome ILIKE '%' || $2 || '%' OR f.nome ILIKE '%' || $2 || '%')
       AND ($3::timestamptz IS NULL OR (t.created_at, t.id) > ($3::timestamptz, $4::uuid))
     ORDER BY t.created_at, t.id LIMIT $5`,
    [f.estado ?? null, f.busca?.trim() || null, cur?.[0] ?? null, cur?.[1] ?? null, lim + 1],
  );
  return pagina(r.rows, lim);
}

export async function obterTrilha(c: pg.PoolClient, id: string) {
  return (await c.query(`SELECT ${RESUMO}, t.extras ${JUNCOES} WHERE t.id = $1 AND t.deleted_at IS NULL`, [id])).rows[0] ?? null;
}
