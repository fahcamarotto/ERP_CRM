/** Entidade filha ModuloCurso (M11.1): agrupa as aulas do curso, em ordem. */
import { randomUUID } from 'node:crypto';
import { erroDe, fail, ok, type ErroDominio, type Result } from '../../compartilhado/result.ts';

export interface ModuloCursoDados {
  id: string;
  curso_id: string;
  titulo: string;
  ordem: number;
}

function validar(d: ModuloCursoDados): ErroDominio[] {
  const e: ErroDominio[] = [];
  if (d.titulo.length < 2 || d.titulo.length > 200) e.push(erroDe('titulo_invalido', 'Titulo deve ter de 2 a 200 caracteres', 'titulo'));
  if (!Number.isInteger(d.ordem) || d.ordem < 1) e.push(erroDe('ordem_invalida', 'Ordem deve ser inteiro a partir de 1', 'ordem'));
  return e;
}

export class ModuloCurso {
  private constructor(private readonly d: ModuloCursoDados) {}

  static tryCreate(e: { curso_id: string; titulo: string; ordem: number }, id: string = randomUUID()): Result<ModuloCurso> {
    const d: ModuloCursoDados = { id, curso_id: e.curso_id, titulo: (e.titulo ?? '').trim(), ordem: Number(e.ordem) };
    const erros = validar(d);
    return erros.length ? fail(...erros) : ok(new ModuloCurso(d));
  }

  static create(e: { curso_id: string; titulo: string; ordem: number }, id?: string): ModuloCurso {
    const r = ModuloCurso.tryCreate(e, id);
    if (!r.ok) throw new Error(r.erros.map((x) => x.mensagem).join('; '));
    return r.valor;
  }

  static reidratar(d: ModuloCursoDados): ModuloCurso { return new ModuloCurso({ ...d }); }

  get id(): string { return this.d.id; }
  get cursoId(): string { return this.d.curso_id; }

  editar(e: { titulo?: string; ordem?: number }): Result<ModuloCurso> {
    const n: ModuloCursoDados = {
      ...this.d,
      titulo: e.titulo !== undefined ? e.titulo.trim() : this.d.titulo,
      ordem: e.ordem !== undefined ? Number(e.ordem) : this.d.ordem,
    };
    const erros = validar(n);
    return erros.length ? fail(...erros) : ok(new ModuloCurso(n));
  }

  paraDados(): ModuloCursoDados { return { ...this.d }; }
}
