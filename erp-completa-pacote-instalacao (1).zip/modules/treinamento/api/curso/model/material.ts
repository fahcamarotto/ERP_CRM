/** Entidade filha Material de apoio (M11.6): link ou arquivo publicado anexado a uma aula. */
import { randomUUID } from 'node:crypto';
import { erroDe, fail, ok, type ErroDominio, type Result } from '../../compartilhado/result.ts';

export const TIPOS_MATERIAL = ['pdf', 'planilha', 'apresentacao', 'link', 'outro'] as const;
export type TipoMaterial = (typeof TIPOS_MATERIAL)[number];

export interface MaterialDados {
  id: string;
  aula_id: string;
  titulo: string;
  tipo: TipoMaterial;
  url: string;
}

function validar(d: MaterialDados): ErroDominio[] {
  const e: ErroDominio[] = [];
  if (d.titulo.length < 2 || d.titulo.length > 200) e.push(erroDe('titulo_invalido', 'Titulo deve ter de 2 a 200 caracteres', 'titulo'));
  if (!TIPOS_MATERIAL.includes(d.tipo)) e.push(erroDe('tipo_invalido', 'Tipo de material invalido', 'tipo', { permitidos: [...TIPOS_MATERIAL] }));
  let urlOk = /^https?:\/\//i.test(d.url) && d.url.length <= 2000;
  if (urlOk) { try { new URL(d.url); } catch { urlOk = false; } }
  if (!urlOk) e.push(erroDe('url_invalida', 'URL deve comecar com http:// ou https://', 'url'));
  return e;
}

export class Material {
  private constructor(private readonly d: MaterialDados) {}

  static tryCreate(e: { aula_id: string; titulo: string; tipo?: string; url: string }, id: string = randomUUID()): Result<Material> {
    const d: MaterialDados = { id, aula_id: e.aula_id, titulo: (e.titulo ?? '').trim(), tipo: (e.tipo ?? 'link') as TipoMaterial, url: (e.url ?? '').trim() };
    const erros = validar(d);
    return erros.length ? fail(...erros) : ok(new Material(d));
  }

  static create(e: { aula_id: string; titulo: string; tipo?: string; url: string }, id?: string): Material {
    const r = Material.tryCreate(e, id);
    if (!r.ok) throw new Error(r.erros.map((x) => x.mensagem).join('; '));
    return r.valor;
  }

  static reidratar(d: MaterialDados): Material { return new Material({ ...d }); }

  get id(): string { return this.d.id; }
  paraDados(): MaterialDados { return { ...this.d }; }
}
