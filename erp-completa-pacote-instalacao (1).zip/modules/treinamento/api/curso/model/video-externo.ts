/**
 * Objeto de valor VideoExterno (M11.2): provedor e id do video. O sistema guarda so o id, nunca o arquivo.
 * Aceita o id puro ou a URL colada do provedor e extrai o id.
 * Panda Video e Bunny Stream precisam da biblioteca no id: `<biblioteca>/<id do video>`.
 */
import { erroDe, fail, ok, type Result } from '../../compartilhado/result.ts';

export const PROVEDORES = ['youtube', 'vimeo', 'panda', 'bunny'] as const;
export type Provedor = (typeof PROVEDORES)[number];

const GUID = '[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}';

const FORMATO: Record<Provedor, RegExp> = {
  youtube: /^[A-Za-z0-9_-]{11}$/,
  vimeo: /^\d{6,12}$/,
  panda: new RegExp(`^vz-[a-z0-9-]{3,60}/${GUID}$`),
  bunny: new RegExp(`^\\d{1,10}/${GUID}$`),
};

/** Extrai o id de uma URL comum do provedor; devolve o texto como veio quando nao reconhece. */
function extrair(provedor: Provedor, bruto: string): string {
  const v = bruto.trim();
  if (!/^https?:\/\//i.test(v)) return v;
  let u: URL;
  try { u = new URL(v); } catch { return v; }
  if (provedor === 'youtube') {
    if (u.hostname.endsWith('youtu.be')) return u.pathname.slice(1).split('/')[0] ?? v;
    const q = u.searchParams.get('v');
    if (q) return q;
    const m = u.pathname.match(/\/(?:embed|shorts|live)\/([A-Za-z0-9_-]{11})/);
    return m?.[1] ?? v;
  }
  if (provedor === 'vimeo') return u.pathname.match(/(\d{6,12})(?:\/|$)/)?.[1] ?? v;
  if (provedor === 'panda') {
    const zona = u.hostname.match(/^player-(vz-[a-z0-9-]+)\.tv\.pandavideo\.com\.br$/)?.[1];
    const id = u.searchParams.get('v');
    return zona && id ? `${zona}/${id}` : v;
  }
  const m = u.pathname.match(new RegExp(`/(?:embed|play)/(\\d{1,10})/(${GUID})`));
  return m ? `${m[1]}/${m[2]}` : v;
}

export class VideoExterno {
  private constructor(readonly provedor: Provedor, readonly id: string) {}

  static tryCreate(provedor: string, bruto: string): Result<VideoExterno> {
    if (!PROVEDORES.includes(provedor as Provedor)) {
      return fail(erroDe('provedor_invalido', 'Provedor deve ser youtube, vimeo, panda ou bunny', 'provedor', { permitidos: [...PROVEDORES] }));
    }
    const p = provedor as Provedor;
    const id = extrair(p, bruto ?? '');
    if (!FORMATO[p].test(id)) {
      return fail(erroDe('video_invalido', `Id de video invalido para ${p}`, 'video_id', { exemplo: EXEMPLO[p] }));
    }
    return ok(new VideoExterno(p, id));
  }

  static create(provedor: string, bruto: string): VideoExterno {
    const r = VideoExterno.tryCreate(provedor, bruto);
    if (!r.ok) throw new Error(r.erros[0]!.mensagem);
    return r.valor;
  }

  /** URL do player embutido (iframe) do provedor. */
  urlEmbed(): string {
    return urlEmbed(this.provedor, this.id);
  }
}

export const EXEMPLO: Record<Provedor, string> = {
  youtube: 'dQw4w9WgXcQ',
  vimeo: '76979871',
  panda: 'vz-1a2b3c4d-5e6/0f1e2d3c-4b5a-6978-8a9b-0c1d2e3f4a5b',
  bunny: '123456/0f1e2d3c-4b5a-6978-8a9b-0c1d2e3f4a5b',
};

export function urlEmbed(provedor: Provedor, id: string): string {
  if (provedor === 'youtube') return `https://www.youtube-nocookie.com/embed/${id}`;
  if (provedor === 'vimeo') return `https://player.vimeo.com/video/${id}`;
  const [biblioteca, video] = id.split('/');
  if (provedor === 'panda') return `https://player-${biblioteca}.tv.pandavideo.com.br/embed/?v=${video}`;
  return `https://iframe.mediadelivery.net/embed/${biblioteca}/${video}`;
}
