/** Portas do agregado Curso (curso, modulos, aulas e materiais), segregadas por operacao. */
import type { Aula } from './aula.ts';
import type { Curso } from './curso.ts';
import type { Material } from './material.ts';
import type { ModuloCurso } from './modulo.ts';

export interface ObterCurso {
  obterPorId(id: string): Promise<Curso | null>;
  buscarPorTitulo(titulo: string): Promise<Curso | null>;
}

export interface GravarCurso {
  inserir(c: Curso): Promise<void>;
  atualizar(c: Curso): Promise<void>;
  excluir(id: string): Promise<void>;
}

/** Leitura que cruza o agregado: cadeia de pre-requisitos e uso do curso em matriculas e trilhas. */
export interface ConsultarCursos {
  /** Id do pre-requisito de cada curso da cadeia (para detectar ciclo). */
  prerequisitoDe(cursoId: string): Promise<string | null>;
  contarAulas(cursoId: string): Promise<number>;
  matriculasAtivas(cursoId: string): Promise<number>;
}

export interface GravarModulos {
  obterModulo(id: string): Promise<ModuloCurso | null>;
  inserirModulo(m: ModuloCurso): Promise<void>;
  atualizarModulo(m: ModuloCurso): Promise<void>;
  excluirModulo(id: string): Promise<void>;
  contarAulasDoModulo(moduloId: string): Promise<number>;
  proximaOrdemModulo(cursoId: string): Promise<number>;
}

export interface GravarAulas {
  obterAula(id: string): Promise<Aula | null>;
  inserirAula(a: Aula): Promise<void>;
  atualizarAula(a: Aula): Promise<void>;
  excluirAula(id: string): Promise<void>;
  proximaOrdemAula(cursoId: string): Promise<number>;
  /** Aulas vivas que dependem desta (pre-requisito). */
  dependentesDaAula(aulaId: string): Promise<string[]>;
}

export interface GravarMateriais {
  obterMaterial(id: string): Promise<Material | null>;
  inserirMaterial(m: Material): Promise<void>;
  excluirMaterial(id: string): Promise<void>;
}
