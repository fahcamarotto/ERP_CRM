/**
 * Entidade Curso (M11.1): titulo, descricao, pre-requisito de outro curso, certificado interno e estado.
 * Imutavel: toda alteracao devolve um clone novo.
 */
import { randomUUID } from 'node:crypto';
import { erroDe, fail, ok, type ErroDominio, type Result } from '../../compartilhado/result.ts';

export const ESTADOS_CURSO = ['rascunho', 'publicado', 'arquivado'] as const;
export type EstadoCurso = (typeof ESTADOS_CURSO)[number];

/** Maquina de estados do curso. Publicar exige ao menos uma aula (regra do caso de uso). */
export const TRANSICOES_CURSO: Record<EstadoCurso, EstadoCurso[]> = {
  rascunho: ['publicado', 'arquivado'],
  publicado: ['rascunho', 'arquivado'],
  arquivado: ['rascunho'],
};

export interface DadosCurso {
  titulo: string;
  descricao?: string | null;
  prerequisito_curso_id?: string | null;
  emite_certificado?: boolean;
  extras?: Record<string, unknown>;
}

export interface CursoDados {
  id: string;
  titulo: string;
  descricao: string | null;
  prerequisito_curso_id: string | null;
  emite_certificado: boolean;
  estado: EstadoCurso;
  extras: Record<string, unknown>;
}

const t = (v?: string | null) => (v ?? '').trim() || null;

function validar(d: CursoDados): ErroDominio[] {
  const e: ErroDominio[] = [];
  if (d.titulo.length < 2 || d.titulo.length > 200) e.push(erroDe('titulo_invalido', 'Titulo deve ter de 2 a 200 caracteres', 'titulo'));
  if (d.descricao && d.descricao.length > 4000) e.push(erroDe('descricao_invalida', 'Descricao com no maximo 4000 caracteres', 'descricao'));
  if (d.prerequisito_curso_id && d.prerequisito_curso_id === d.id) e.push(erroDe('prerequisito_invalido', 'Curso nao pode ser pre-requisito de si mesmo', 'prerequisito_curso_id'));
  if (!ESTADOS_CURSO.includes(d.estado)) e.push(erroDe('estado_invalido', 'Estado invalido', 'estado'));
  return e;
}

export class Curso {
  private constructor(private readonly d: CursoDados) {}

  static tryCreate(e: DadosCurso, id: string = randomUUID()): Result<Curso> {
    const d: CursoDados = {
      id, titulo: (e.titulo ?? '').trim(), descricao: t(e.descricao), prerequisito_curso_id: t(e.prerequisito_curso_id),
      emite_certificado: e.emite_certificado ?? true, estado: 'rascunho', extras: e.extras ?? {},
    };
    const erros = validar(d);
    return erros.length ? fail(...erros) : ok(new Curso(d));
  }

  static create(e: DadosCurso, id?: string): Curso {
    const r = Curso.tryCreate(e, id);
    if (!r.ok) throw new Error(r.erros.map((x) => x.mensagem).join('; '));
    return r.valor;
  }

  static reidratar(d: CursoDados): Curso {
    return new Curso({ ...d, extras: { ...(d.extras ?? {}) } });
  }

  get id(): string { return this.d.id; }
  get titulo(): string { return this.d.titulo; }
  get estado(): EstadoCurso { return this.d.estado; }
  get prerequisitoId(): string | null { return this.d.prerequisito_curso_id; }

  editar(e: Partial<DadosCurso>): Result<Curso> {
    if (this.d.estado === 'arquivado') return fail(erroDe('transicao_invalida', 'Curso arquivado nao pode ser editado; volte para rascunho'));
    const tem = (k: keyof DadosCurso) => e[k] !== undefined;
    const n: CursoDados = {
      ...this.d,
      titulo: tem('titulo') ? (e.titulo ?? '').trim() : this.d.titulo,
      descricao: tem('descricao') ? t(e.descricao) : this.d.descricao,
      prerequisito_curso_id: tem('prerequisito_curso_id') ? t(e.prerequisito_curso_id) : this.d.prerequisito_curso_id,
      emite_certificado: tem('emite_certificado') ? !!e.emite_certificado : this.d.emite_certificado,
      extras: tem('extras') ? { ...e.extras } : { ...this.d.extras },
    };
    const erros = validar(n);
    return erros.length ? fail(...erros) : ok(new Curso(n));
  }

  mudarEstado(novo: EstadoCurso): Result<Curso> {
    if (!ESTADOS_CURSO.includes(novo)) return fail(erroDe('estado_invalido', 'Estado invalido', 'estado'));
    if (!TRANSICOES_CURSO[this.d.estado].includes(novo)) {
      return fail(erroDe('transicao_invalida', `Transicao de ${this.d.estado} para ${novo} nao permitida`, 'estado', { permitidas: TRANSICOES_CURSO[this.d.estado] }));
    }
    return ok(new Curso({ ...this.d, estado: novo }));
  }

  paraDados(): CursoDados {
    return { ...this.d, extras: { ...this.d.extras } };
  }
}
