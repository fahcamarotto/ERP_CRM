/**
 * Entidade filha Aula (M11.1 e M11.2): ordem dentro do curso, video externo (so o id) e pre-requisito de outra aula.
 * Imutavel: toda alteracao devolve um clone novo.
 */
import { randomUUID } from 'node:crypto';
import { erroDe, fail, ok, type ErroDominio, type Result } from '../../compartilhado/result.ts';
import { VideoExterno, type Provedor } from './video-externo.ts';

export interface DadosAula {
  curso_id: string;
  modulo_id: string;
  titulo: string;
  descricao?: string | null;
  ordem: number;
  provedor?: string | null;
  video_id?: string | null;
  duracao_min?: number;
  prerequisito_aula_id?: string | null;
}

export interface AulaDados {
  id: string;
  curso_id: string;
  modulo_id: string;
  titulo: string;
  descricao: string | null;
  ordem: number;
  provedor: Provedor | null;
  video_id: string | null;
  duracao_min: number;
  prerequisito_aula_id: string | null;
}

const t = (v?: string | null) => (v ?? '').trim() || null;

function video(provedor?: string | null, id?: string | null): Result<VideoExterno | null> {
  const p = t(provedor);
  const v = t(id);
  if (!p && !v) return ok(null);
  if (!p) return fail(erroDe('provedor_invalido', 'Informe o provedor do video', 'provedor'));
  if (!v) return fail(erroDe('video_invalido', 'Informe o id do video', 'video_id'));
  return VideoExterno.tryCreate(p, v);
}

function validar(d: AulaDados): ErroDominio[] {
  const e: ErroDominio[] = [];
  if (d.titulo.length < 2 || d.titulo.length > 200) e.push(erroDe('titulo_invalido', 'Titulo deve ter de 2 a 200 caracteres', 'titulo'));
  if (d.descricao && d.descricao.length > 4000) e.push(erroDe('descricao_invalida', 'Descricao com no maximo 4000 caracteres', 'descricao'));
  if (!Number.isInteger(d.ordem) || d.ordem < 1) e.push(erroDe('ordem_invalida', 'Ordem deve ser inteiro a partir de 1', 'ordem'));
  if (!Number.isInteger(d.duracao_min) || d.duracao_min < 0 || d.duracao_min > 1440) e.push(erroDe('duracao_invalida', 'Duracao de 0 a 1440 minutos', 'duracao_min'));
  if (d.prerequisito_aula_id && d.prerequisito_aula_id === d.id) e.push(erroDe('prerequisito_invalido', 'Aula nao pode ser pre-requisito de si mesma', 'prerequisito_aula_id'));
  return e;
}

export class Aula {
  private constructor(private readonly d: AulaDados) {}

  static tryCreate(e: DadosAula, id: string = randomUUID()): Result<Aula> {
    const base = {
      id, curso_id: e.curso_id, modulo_id: e.modulo_id, titulo: (e.titulo ?? '').trim(), descricao: t(e.descricao),
      ordem: Number(e.ordem), duracao_min: Number(e.duracao_min ?? 0), prerequisito_aula_id: t(e.prerequisito_aula_id),
    };
    const v = video(e.provedor, e.video_id);
    const d: AulaDados = { ...base, provedor: v.ok ? v.valor?.provedor ?? null : null, video_id: v.ok ? v.valor?.id ?? null : null };
    const erros = [...(v.ok ? [] : v.erros), ...validar(d)];
    return erros.length ? fail(...erros) : ok(new Aula(d));
  }

  static create(e: DadosAula, id?: string): Aula {
    const r = Aula.tryCreate(e, id);
    if (!r.ok) throw new Error(r.erros.map((x) => x.mensagem).join('; '));
    return r.valor;
  }

  static reidratar(d: AulaDados): Aula { return new Aula({ ...d }); }

  get id(): string { return this.d.id; }
  get cursoId(): string { return this.d.curso_id; }
  get moduloId(): string { return this.d.modulo_id; }
  get prerequisitoId(): string | null { return this.d.prerequisito_aula_id; }
  get temVideo(): boolean { return this.d.video_id !== null; }

  editar(e: Partial<Omit<DadosAula, 'curso_id'>>): Result<Aula> {
    const tem = (k: keyof Omit<DadosAula, 'curso_id'>) => e[k] !== undefined;
    const trocaVideo = tem('provedor') || tem('video_id');
    const v = trocaVideo
      ? video(tem('provedor') ? e.provedor : this.d.provedor, tem('video_id') ? e.video_id : this.d.video_id)
      : ok(this.d.video_id ? VideoExterno.create(this.d.provedor!, this.d.video_id) : null);
    const n: AulaDados = {
      ...this.d,
      modulo_id: tem('modulo_id') ? e.modulo_id! : this.d.modulo_id,
      titulo: tem('titulo') ? (e.titulo ?? '').trim() : this.d.titulo,
      descricao: tem('descricao') ? t(e.descricao) : this.d.descricao,
      ordem: tem('ordem') ? Number(e.ordem) : this.d.ordem,
      duracao_min: tem('duracao_min') ? Number(e.duracao_min) : this.d.duracao_min,
      prerequisito_aula_id: tem('prerequisito_aula_id') ? t(e.prerequisito_aula_id) : this.d.prerequisito_aula_id,
      provedor: v.ok ? v.valor?.provedor ?? null : this.d.provedor,
      video_id: v.ok ? v.valor?.id ?? null : this.d.video_id,
    };
    const erros = [...(v.ok ? [] : v.erros), ...validar(n)];
    return erros.length ? fail(...erros) : ok(new Aula(n));
  }

  paraDados(): AulaDados { return { ...this.d }; }
}

