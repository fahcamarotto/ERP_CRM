/** Consultas de leitura do Curso: lista com contagens e ficha com modulos, aulas e materiais. */
import type pg from 'pg';
import { decodificarCursor, pagina } from '../../compartilhado/cursor.ts';

const RESUMO = `c.id, c.titulo, c.descricao, c.prerequisito_curso_id, pc.titulo AS prerequisito_titulo, c.emite_certificado, c.estado,
  c.created_at, c.updated_at,
  (SELECT count(*)::int FROM treinamento_modulos m WHERE m.curso_id = c.id AND m.deleted_at IS NULL) AS total_modulos,
  (SELECT count(*)::int FROM treinamento_aulas a WHERE a.curso_id = c.id AND a.deleted_at IS NULL) AS total_aulas,
  (SELECT coalesce(sum(a.duracao_min), 0)::int FROM treinamento_aulas a WHERE a.curso_id = c.id AND a.deleted_at IS NULL) AS duracao_total_min,
  (SELECT count(*)::int FROM treinamento_matriculas x WHERE x.curso_id = c.id AND x.estado <> 'cancelada' AND x.deleted_at IS NULL) AS total_matriculas`;

const JUNCOES = `FROM treinamento_cursos c LEFT JOIN treinamento_cursos pc ON pc.id = c.prerequisito_curso_id AND pc.deleted_at IS NULL`;

export interface FiltroCursos {
  estado?: string;
  busca?: string;
  limite?: number;
  cursor?: string;
}

export async function listarCursos(c: pg.PoolClient, f: FiltroCursos) {
  const lim = Math.min(Math.max(f.limite ?? 50, 1), 200);
  const cur = decodificarCursor(f.cursor);
  const r = await c.query(
    `SELECT ${RESUMO} ${JUNCOES}
     WHERE c.deleted_at IS NULL AND ($1::text IS NULL OR c.estado = $1) AND ($2::text IS NULL OR c.titulo ILIKE '%' || $2 || '%')
       AND ($3::timestamptz IS NULL OR (c.created_at, c.id) > ($3::timestamptz, $4::uuid))
     ORDER BY c.created_at, c.id LIMIT $5`,
    [f.estado ?? null, f.busca?.trim() || null, cur?.[0] ?? null, cur?.[1] ?? null, lim + 1],
  );
  return pagina(r.rows, lim);
}

/** Aulas do curso em ordem com os materiais (json). Reaproveitada pela area de membros da matricula. */
export const AULAS_JSON = `coalesce((SELECT json_agg(json_build_object(
    'id', a.id, 'modulo_id', a.modulo_id, 'titulo', a.titulo, 'descricao', a.descricao, 'ordem', a.ordem, 'provedor', a.provedor,
    'video_id', a.video_id, 'duracao_min', a.duracao_min, 'prerequisito_aula_id', a.prerequisito_aula_id,
    'materiais', coalesce((SELECT json_agg(json_build_object('id', mt.id, 'titulo', mt.titulo, 'tipo', mt.tipo, 'url', mt.url) ORDER BY mt.created_at)
      FROM treinamento_materiais mt WHERE mt.aula_id = a.id AND mt.deleted_at IS NULL), '[]'::json)
  ) ORDER BY md.ordem, a.ordem, a.created_at) FROM treinamento_aulas a JOIN treinamento_modulos md ON md.id = a.modulo_id AND md.deleted_at IS NULL
  WHERE a.curso_id = c.id AND a.deleted_at IS NULL), '[]'::json)`;

export const MODULOS_JSON = `coalesce((SELECT json_agg(json_build_object('id', m.id, 'titulo', m.titulo, 'ordem', m.ordem) ORDER BY m.ordem, m.created_at)
  FROM treinamento_modulos m WHERE m.curso_id = c.id AND m.deleted_at IS NULL), '[]'::json)`;

export async function obterCurso(c: pg.PoolClient, id: string) {
  const r = await c.query(`SELECT ${RESUMO}, c.extras, ${MODULOS_JSON} AS modulos, ${AULAS_JSON} AS aulas ${JUNCOES} WHERE c.id = $1 AND c.deleted_at IS NULL`, [id]);
  return r.rows[0] ?? null;
}
