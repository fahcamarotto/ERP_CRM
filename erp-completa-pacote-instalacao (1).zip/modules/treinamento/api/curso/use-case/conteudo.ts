/**
 * Casos de uso do conteudo do curso (M11.1, M11.2 e M11.6): modulos, aulas com video externo e pre-requisito,
 * e material de apoio anexado a aula. Toda mudanca grava auditoria e nota no chatter do curso.
 */
import { erroDe, fail, ok, okVazio, type Result } from '../../compartilhado/result.ts';
import type { ContextoCaso } from '../../compartilhado/efeitos.ts';
import { Aula, type DadosAula } from '../model/aula.ts';
import { Material } from '../model/material.ts';
import { ModuloCurso } from '../model/modulo.ts';
import type { GravarAulas, GravarMateriais, GravarModulos, ObterCurso } from '../model/portas.ts';

const CURSOS = 'treinamento_cursos';

export interface DepsConteudo {
  cursos: ObterCurso;
  modulos: GravarModulos;
  aulas: GravarAulas;
  materiais: GravarMateriais;
}

async function cursoEditavel(deps: DepsConteudo, cursoId: string): Promise<Result<void>> {
  const c = await deps.cursos.obterPorId(cursoId);
  if (!c) return fail(erroDe('nao_encontrado', 'Curso nao encontrado', 'curso_id'));
  if (c.estado === 'arquivado') return fail(erroDe('transicao_invalida', 'Curso arquivado nao aceita mudanca de conteudo'));
  return okVazio();
}

export class CriarModulo {
  constructor(private readonly deps: DepsConteudo) {}
  async execute(ctx: ContextoCaso, e: { curso_id: string; titulo: string; ordem?: number }): Promise<Result<{ id: string }>> {
    const ed = await cursoEditavel(this.deps, e.curso_id);
    if (!ed.ok) return ed;
    const ordem = e.ordem ?? (await this.deps.modulos.proximaOrdemModulo(e.curso_id));
    const r = ModuloCurso.tryCreate({ curso_id: e.curso_id, titulo: e.titulo, ordem });
    if (!r.ok) return r;
    await this.deps.modulos.inserirModulo(r.valor);
    const d = r.valor.paraDados();
    await ctx.efeitos.auditar('curso.modulo_criar', 'treinamento_modulos', d.id, undefined, d);
    await ctx.efeitos.nota(CURSOS, e.curso_id, `Modulo adicionado: ${d.titulo}`);
    return ok({ id: d.id });
  }
}

export class EditarModulo {
  constructor(private readonly deps: DepsConteudo) {}
  async execute(ctx: ContextoCaso, e: { id: string; titulo?: string; ordem?: number }): Promise<Result<void>> {
    const atual = await this.deps.modulos.obterModulo(e.id);
    if (!atual) return fail(erroDe('nao_encontrado', 'Modulo nao encontrado'));
    const ed = await cursoEditavel(this.deps, atual.cursoId);
    if (!ed.ok) return ed;
    const r = atual.editar(e);
    if (!r.ok) return r;
    await this.deps.modulos.atualizarModulo(r.valor);
    await ctx.efeitos.auditar('curso.modulo_editar', 'treinamento_modulos', e.id, atual.paraDados(), r.valor.paraDados());
    return okVazio();
  }
}

export class ExcluirModulo {
  constructor(private readonly deps: DepsConteudo) {}
  async execute(ctx: ContextoCaso, e: { id: string }): Promise<Result<void>> {
    const atual = await this.deps.modulos.obterModulo(e.id);
    if (!atual) return fail(erroDe('nao_encontrado', 'Modulo nao encontrado'));
    const n = await this.deps.modulos.contarAulasDoModulo(e.id);
    if (n > 0) return fail(erroDe('conflito', 'Modulo com aulas; mova ou exclua as aulas antes', 'id', { aulas: n }));
    await this.deps.modulos.excluirModulo(e.id);
    await ctx.efeitos.auditar('curso.modulo_excluir', 'treinamento_modulos', e.id, atual.paraDados(), undefined);
    return okVazio();
  }
}

/** Modulo pertence ao curso e pre-requisito existe, e do mesmo curso e nao fecha ciclo. */
async function conferirAula(deps: DepsConteudo, a: Aula): Promise<Result<void>> {
  const m = await deps.modulos.obterModulo(a.moduloId);
  if (!m || m.cursoId !== a.cursoId) return fail(erroDe('modulo_invalido', 'Modulo nao encontrado neste curso', 'modulo_id'));
  let atual = a.prerequisitoId;
  for (let i = 0; atual && i < 500; i++) {
    if (atual === a.id) return fail(erroDe('prerequisito_ciclico', 'Pre-requisito cria ciclo entre aulas', 'prerequisito_aula_id'));
    const pre = await deps.aulas.obterAula(atual);
    if (!pre || pre.cursoId !== a.cursoId) return fail(erroDe('prerequisito_invalido', 'Aula pre-requisito nao encontrada neste curso', 'prerequisito_aula_id'));
    atual = pre.prerequisitoId;
  }
  return okVazio();
}

export class CriarAula {
  constructor(private readonly deps: DepsConteudo) {}
  async execute(ctx: ContextoCaso, e: Omit<DadosAula, 'ordem'> & { ordem?: number }): Promise<Result<{ id: string }>> {
    const ed = await cursoEditavel(this.deps, e.curso_id);
    if (!ed.ok) return ed;
    const ordem = e.ordem ?? (await this.deps.aulas.proximaOrdemAula(e.curso_id));
    const r = Aula.tryCreate({ ...e, ordem });
    if (!r.ok) return r;
    const c = await conferirAula(this.deps, r.valor);
    if (!c.ok) return c;
    await this.deps.aulas.inserirAula(r.valor);
    const d = r.valor.paraDados();
    await ctx.efeitos.auditar('curso.aula_criar', 'treinamento_aulas', d.id, undefined, d);
    await ctx.efeitos.nota(CURSOS, e.curso_id, `Aula adicionada: ${d.titulo}`);
    return ok({ id: d.id });
  }
}

export class EditarAula {
  constructor(private readonly deps: DepsConteudo) {}
  async execute(ctx: ContextoCaso, e: { id: string } & Partial<Omit<DadosAula, 'curso_id'>>): Promise<Result<void>> {
    const { id, ...mud } = e;
    const atual = await this.deps.aulas.obterAula(id);
    if (!atual) return fail(erroDe('nao_encontrado', 'Aula nao encontrada'));
    const ed = await cursoEditavel(this.deps, atual.cursoId);
    if (!ed.ok) return ed;
    const r = atual.editar(mud);
    if (!r.ok) return r;
    const c = await conferirAula(this.deps, r.valor);
    if (!c.ok) return c;
    await this.deps.aulas.atualizarAula(r.valor);
    const antes = atual.paraDados() as unknown as Record<string, unknown>;
    const depois = r.valor.paraDados() as unknown as Record<string, unknown>;
    await ctx.efeitos.historico('treinamento_aulas', id, antes, depois);
    await ctx.efeitos.auditar('curso.aula_editar', 'treinamento_aulas', id, antes, depois);
    return okVazio();
  }
}

export class ExcluirAula {
  constructor(private readonly deps: DepsConteudo) {}
  async execute(ctx: ContextoCaso, e: { id: string }): Promise<Result<void>> {
    const atual = await this.deps.aulas.obterAula(e.id);
    if (!atual) return fail(erroDe('nao_encontrado', 'Aula nao encontrada'));
    const dep = await this.deps.aulas.dependentesDaAula(e.id);
    if (dep.length) return fail(erroDe('conflito', 'Outra aula exige esta como pre-requisito', 'id', { dependentes: dep }));
    await this.deps.aulas.excluirAula(e.id);
    const d = atual.paraDados();
    await ctx.efeitos.auditar('curso.aula_excluir', 'treinamento_aulas', e.id, d, undefined);
    await ctx.efeitos.nota(CURSOS, d.curso_id, `Aula removida: ${d.titulo}`);
    return okVazio();
  }
}

export class AdicionarMaterial {
  constructor(private readonly deps: DepsConteudo) {}
  async execute(ctx: ContextoCaso, e: { aula_id: string; titulo: string; tipo?: string; url: string }): Promise<Result<{ id: string }>> {
    const aula = await this.deps.aulas.obterAula(e.aula_id);
    if (!aula) return fail(erroDe('nao_encontrado', 'Aula nao encontrada', 'aula_id'));
    const r = Material.tryCreate(e);
    if (!r.ok) return r;
    await this.deps.materiais.inserirMaterial(r.valor);
    const d = r.valor.paraDados();
    await ctx.efeitos.auditar('curso.material_adicionar', 'treinamento_materiais', d.id, undefined, d);
    return ok({ id: d.id });
  }
}

export class RemoverMaterial {
  constructor(private readonly deps: DepsConteudo) {}
  async execute(ctx: ContextoCaso, e: { id: string }): Promise<Result<void>> {
    const atual = await this.deps.materiais.obterMaterial(e.id);
    if (!atual) return fail(erroDe('nao_encontrado', 'Material nao encontrado'));
    await this.deps.materiais.excluirMaterial(e.id);
    await ctx.efeitos.auditar('curso.material_remover', 'treinamento_materiais', e.id, atual.paraDados(), undefined);
    return okVazio();
  }
}
