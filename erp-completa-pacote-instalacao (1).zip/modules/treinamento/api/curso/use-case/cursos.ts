/** Casos de uso do Curso (M11.1): CriarCurso, EditarCurso, MudarEstadoCurso e ExcluirCurso. */
import { erroDe, fail, ok, okVazio, type ErroDominio, type Result } from '../../compartilhado/result.ts';
import type { ContextoCaso } from '../../compartilhado/efeitos.ts';
import { Curso, type DadosCurso, type EstadoCurso } from '../model/curso.ts';
import type { ConsultarCursos, GravarCurso, ObterCurso } from '../model/portas.ts';

export interface DepsCurso {
  repo: ObterCurso & GravarCurso;
  consultas: ConsultarCursos;
}

const TABELA = 'treinamento_cursos';

/** Pre-requisito existe e nao fecha ciclo (A exige B que exige A). */
async function conferir(deps: DepsCurso, c: Curso, anterior?: Curso): Promise<ErroDominio[]> {
  const erros: ErroDominio[] = [];
  const d = c.paraDados();
  const dono = await deps.repo.buscarPorTitulo(d.titulo);
  if (dono && dono.id !== d.id) erros.push(erroDe('conflito', 'Ja existe curso com este titulo', 'titulo', { curso_id: dono.id }));
  const pre = d.prerequisito_curso_id;
  if (pre && pre !== anterior?.prerequisitoId) {
    if (!(await deps.repo.obterPorId(pre))) return [...erros, erroDe('prerequisito_invalido', 'Curso pre-requisito nao encontrado', 'prerequisito_curso_id')];
    let atual: string | null = pre;
    for (let i = 0; atual && i < 100; i++) {
      if (atual === d.id) return [...erros, erroDe('prerequisito_ciclico', 'Pre-requisito cria ciclo entre cursos', 'prerequisito_curso_id')];
      atual = await deps.consultas.prerequisitoDe(atual);
    }
  }
  return erros;
}

export class CriarCurso {
  constructor(private readonly deps: DepsCurso) {}
  async execute(ctx: ContextoCaso, e: DadosCurso): Promise<Result<{ id: string }>> {
    const r = Curso.tryCreate(e);
    if (!r.ok) return r;
    const erros = await conferir(this.deps, r.valor);
    if (erros.length) return fail(...erros);
    await this.deps.repo.inserir(r.valor);
    const d = r.valor.paraDados();
    await ctx.efeitos.auditar('curso.criar', TABELA, d.id, undefined, d);
    return ok({ id: d.id });
  }
}

export class EditarCurso {
  constructor(private readonly deps: DepsCurso) {}
  async execute(ctx: ContextoCaso, e: { id: string } & Partial<DadosCurso>): Promise<Result<void>> {
    const { id, ...mud } = e;
    const atual = await this.deps.repo.obterPorId(id);
    if (!atual) return fail(erroDe('nao_encontrado', 'Curso nao encontrado'));
    const r = atual.editar(mud);
    if (!r.ok) return r;
    const erros = await conferir(this.deps, r.valor, atual);
    if (erros.length) return fail(...erros);
    await this.deps.repo.atualizar(r.valor);
    const antes = atual.paraDados() as unknown as Record<string, unknown>;
    const depois = r.valor.paraDados() as unknown as Record<string, unknown>;
    await ctx.efeitos.historico(TABELA, id, antes, depois);
    await ctx.efeitos.auditar('curso.editar', TABELA, id, antes, depois);
    return okVazio();
  }
}

export class MudarEstadoCurso {
  constructor(private readonly deps: DepsCurso) {}
  async execute(ctx: ContextoCaso, e: { id: string; estado: EstadoCurso }): Promise<Result<void>> {
    const atual = await this.deps.repo.obterPorId(e.id);
    if (!atual) return fail(erroDe('nao_encontrado', 'Curso nao encontrado'));
    const r = atual.mudarEstado(e.estado);
    if (!r.ok) return r;
    if (e.estado === 'publicado' && (await this.deps.consultas.contarAulas(e.id)) === 0) {
      return fail(erroDe('curso_sem_aulas', 'Cadastre ao menos uma aula antes de publicar', 'estado'));
    }
    await this.deps.repo.atualizar(r.valor);
    await ctx.efeitos.historico(TABELA, e.id, { estado: atual.estado }, { estado: r.valor.estado });
    await ctx.efeitos.auditar('curso.mudar_estado', TABELA, e.id, { estado: atual.estado }, { estado: r.valor.estado });
    if (e.estado === 'publicado') await ctx.efeitos.publicar('curso.publicado', { id: e.id, titulo: atual.titulo });
    return okVazio();
  }
}

export class ExcluirCurso {
  constructor(private readonly deps: DepsCurso) {}
  async execute(ctx: ContextoCaso, e: { id: string }): Promise<Result<void>> {
    const atual = await this.deps.repo.obterPorId(e.id);
    if (!atual) return fail(erroDe('nao_encontrado', 'Curso nao encontrado'));
    const ativas = await this.deps.consultas.matriculasAtivas(e.id);
    if (ativas > 0) return fail(erroDe('conflito', 'Curso com matriculas em andamento; arquive em vez de excluir', 'id', { matriculas: ativas }));
    await this.deps.repo.excluir(e.id);
    await ctx.efeitos.auditar('curso.excluir', TABELA, e.id, atual.paraDados(), undefined);
    return okVazio();
  }
}
