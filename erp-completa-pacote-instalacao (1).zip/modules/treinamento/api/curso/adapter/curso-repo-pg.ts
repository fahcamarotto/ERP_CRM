/** Adaptador Postgres das portas do agregado Curso (RLS restringe ao workspace da sessao). */
import type pg from 'pg';
import { Aula, type AulaDados } from '../model/aula.ts';
import { Curso, type CursoDados } from '../model/curso.ts';
import { Material, type MaterialDados } from '../model/material.ts';
import { ModuloCurso, type ModuloCursoDados } from '../model/modulo.ts';
import type { ConsultarCursos, GravarAulas, GravarCurso, GravarMateriais, GravarModulos, ObterCurso } from '../model/portas.ts';

const COLUNAS = 'id, titulo, descricao, prerequisito_curso_id, emite_certificado, estado, extras';
const COLUNAS_AULA = 'id, curso_id, modulo_id, titulo, descricao, ordem, provedor, video_id, duracao_min, prerequisito_aula_id';

export class CursoRepoPg implements ObterCurso, GravarCurso, ConsultarCursos, GravarModulos, GravarAulas, GravarMateriais {
  constructor(private readonly c: pg.PoolClient) {}

  async obterPorId(id: string): Promise<Curso | null> {
    const r = await this.c.query(`SELECT ${COLUNAS} FROM treinamento_cursos WHERE id = $1 AND deleted_at IS NULL`, [id]);
    return r.rows[0] ? Curso.reidratar(r.rows[0] as CursoDados) : null;
  }

  async buscarPorTitulo(titulo: string): Promise<Curso | null> {
    const r = await this.c.query(`SELECT ${COLUNAS} FROM treinamento_cursos WHERE lower(titulo) = lower($1) AND deleted_at IS NULL`, [titulo]);
    return r.rows[0] ? Curso.reidratar(r.rows[0] as CursoDados) : null;
  }

  async inserir(x: Curso): Promise<void> {
    const d = x.paraDados();
    await this.c.query(
      `INSERT INTO treinamento_cursos (id, titulo, descricao, prerequisito_curso_id, emite_certificado, estado, extras, creator_id)
       VALUES ($1, $2, $3, $4, $5, $6, $7, nucleo_usuario_atual())`,
      [d.id, d.titulo, d.descricao, d.prerequisito_curso_id, d.emite_certificado, d.estado, JSON.stringify(d.extras)],
    );
  }

  async atualizar(x: Curso): Promise<void> {
    const d = x.paraDados();
    await this.c.query(
      `UPDATE treinamento_cursos SET titulo = $2, descricao = $3, prerequisito_curso_id = $4, emite_certificado = $5, estado = $6, extras = $7
       WHERE id = $1 AND deleted_at IS NULL`,
      [d.id, d.titulo, d.descricao, d.prerequisito_curso_id, d.emite_certificado, d.estado, JSON.stringify(d.extras)],
    );
  }

  async excluir(id: string): Promise<void> {
    await this.c.query('UPDATE treinamento_cursos SET deleted_at = now() WHERE id = $1 AND deleted_at IS NULL', [id]);
  }

  async prerequisitoDe(cursoId: string): Promise<string | null> {
    const r = await this.c.query('SELECT prerequisito_curso_id FROM treinamento_cursos WHERE id = $1 AND deleted_at IS NULL', [cursoId]);
    return (r.rows[0]?.prerequisito_curso_id as string | null) ?? null;
  }

  async contarAulas(cursoId: string): Promise<number> {
    const r = await this.c.query('SELECT count(*)::int AS n FROM treinamento_aulas WHERE curso_id = $1 AND deleted_at IS NULL', [cursoId]);
    return r.rows[0].n as number;
  }

  async matriculasAtivas(cursoId: string): Promise<number> {
    const r = await this.c.query(
      "SELECT count(*)::int AS n FROM treinamento_matriculas WHERE curso_id = $1 AND estado = 'em_andamento' AND deleted_at IS NULL", [cursoId]);
    return r.rows[0].n as number;
  }

  // Modulos ------------------------------------------------------------------------------
  async obterModulo(id: string): Promise<ModuloCurso | null> {
    const r = await this.c.query('SELECT id, curso_id, titulo, ordem FROM treinamento_modulos WHERE id = $1 AND deleted_at IS NULL', [id]);
    return r.rows[0] ? ModuloCurso.reidratar(r.rows[0] as ModuloCursoDados) : null;
  }

  async inserirModulo(m: ModuloCurso): Promise<void> {
    const d = m.paraDados();
    await this.c.query('INSERT INTO treinamento_modulos (id, curso_id, titulo, ordem, creator_id) VALUES ($1, $2, $3, $4, nucleo_usuario_atual())',
      [d.id, d.curso_id, d.titulo, d.ordem]);
  }

  async atualizarModulo(m: ModuloCurso): Promise<void> {
    const d = m.paraDados();
    await this.c.query('UPDATE treinamento_modulos SET titulo = $2, ordem = $3 WHERE id = $1 AND deleted_at IS NULL', [d.id, d.titulo, d.ordem]);
  }

  async excluirModulo(id: string): Promise<void> {
    await this.c.query('UPDATE treinamento_modulos SET deleted_at = now() WHERE id = $1 AND deleted_at IS NULL', [id]);
  }

  async contarAulasDoModulo(moduloId: string): Promise<number> {
    const r = await this.c.query('SELECT count(*)::int AS n FROM treinamento_aulas WHERE modulo_id = $1 AND deleted_at IS NULL', [moduloId]);
    return r.rows[0].n as number;
  }

  async proximaOrdemModulo(cursoId: string): Promise<number> {
    const r = await this.c.query('SELECT coalesce(max(ordem), 0) + 1 AS n FROM treinamento_modulos WHERE curso_id = $1 AND deleted_at IS NULL', [cursoId]);
    return r.rows[0].n as number;
  }

  // Aulas --------------------------------------------------------------------------------
  async obterAula(id: string): Promise<Aula | null> {
    const r = await this.c.query(`SELECT ${COLUNAS_AULA} FROM treinamento_aulas WHERE id = $1 AND deleted_at IS NULL`, [id]);
    return r.rows[0] ? Aula.reidratar(r.rows[0] as AulaDados) : null;
  }

  async inserirAula(a: Aula): Promise<void> {
    const d = a.paraDados();
    await this.c.query(
      `INSERT INTO treinamento_aulas (id, curso_id, modulo_id, titulo, descricao, ordem, provedor, video_id, duracao_min, prerequisito_aula_id, creator_id)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, nucleo_usuario_atual())`,
      [d.id, d.curso_id, d.modulo_id, d.titulo, d.descricao, d.ordem, d.provedor, d.video_id, d.duracao_min, d.prerequisito_aula_id],
    );
  }

  async atualizarAula(a: Aula): Promise<void> {
    const d = a.paraDados();
    await this.c.query(
      `UPDATE treinamento_aulas SET modulo_id = $2, titulo = $3, descricao = $4, ordem = $5, provedor = $6, video_id = $7, duracao_min = $8,
         prerequisito_aula_id = $9 WHERE id = $1 AND deleted_at IS NULL`,
      [d.id, d.modulo_id, d.titulo, d.descricao, d.ordem, d.provedor, d.video_id, d.duracao_min, d.prerequisito_aula_id],
    );
  }

  async excluirAula(id: string): Promise<void> {
    await this.c.query('UPDATE treinamento_materiais SET deleted_at = now() WHERE aula_id = $1 AND deleted_at IS NULL', [id]);
    await this.c.query('UPDATE treinamento_aulas SET deleted_at = now() WHERE id = $1 AND deleted_at IS NULL', [id]);
  }

  async proximaOrdemAula(cursoId: string): Promise<number> {
    const r = await this.c.query('SELECT coalesce(max(ordem), 0) + 1 AS n FROM treinamento_aulas WHERE curso_id = $1 AND deleted_at IS NULL', [cursoId]);
    return r.rows[0].n as number;
  }

  async dependentesDaAula(aulaId: string): Promise<string[]> {
    const r = await this.c.query('SELECT id FROM treinamento_aulas WHERE prerequisito_aula_id = $1 AND deleted_at IS NULL', [aulaId]);
    return r.rows.map((x) => x.id as string);
  }

  // Materiais ----------------------------------------------------------------------------
  async obterMaterial(id: string): Promise<Material | null> {
    const r = await this.c.query('SELECT id, aula_id, titulo, tipo, url FROM treinamento_materiais WHERE id = $1 AND deleted_at IS NULL', [id]);
    return r.rows[0] ? Material.reidratar(r.rows[0] as MaterialDados) : null;
  }

  async inserirMaterial(m: Material): Promise<void> {
    const d = m.paraDados();
    await this.c.query('INSERT INTO treinamento_materiais (id, aula_id, titulo, tipo, url, creator_id) VALUES ($1, $2, $3, $4, $5, nucleo_usuario_atual())',
      [d.id, d.aula_id, d.titulo, d.tipo, d.url]);
  }

  async excluirMaterial(id: string): Promise<void> {
    await this.c.query('UPDATE treinamento_materiais SET deleted_at = now() WHERE id = $1 AND deleted_at IS NULL', [id]);
  }
}
