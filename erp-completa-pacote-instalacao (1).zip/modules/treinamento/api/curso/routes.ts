/**
 * Rotas REST do Curso fora das tools: edicao e exclusao do curso, modulos, aulas e material de apoio.
 * Listar, obter, criar, publicar e criar aula sao @tool em ../tools.ts.
 */
import { esquemaErro, requer, type FastifyInstance } from '@erp/api/sdk';
import { naTransacao } from '../borda.ts';
import { exigirOk } from '../compartilhado/result.ts';
import { propsAula, propsCurso, propsMaterial, propsModulo, uuid } from '../esquemas.ts';
import type { DadosAula } from './model/aula.ts';
import type { DadosCurso } from './model/curso.ts';
import { obterCurso } from './query/cursos.ts';

const tags = ['treinamento'];
const paramId = { type: 'object', required: ['id'], properties: { id: uuid } } as const;
const erros = { 400: esquemaErro, 403: esquemaErro, 404: esquemaErro, 409: esquemaErro };

export function rotasCurso(app: FastifyInstance): void {
  app.patch<{ Params: { id: string }; Body: Partial<DadosCurso> }>('/cursos/:id', {
    preHandler: requer('treinamento.editar'),
    schema: { tags, summary: 'Edita curso (EditarCurso)', params: paramId, body: { type: 'object', additionalProperties: false, properties: propsCurso }, response: erros },
  }, (req) => naTransacao(req, async (casos, ctx, c) => {
    exigirOk(await casos.editarCurso.execute(ctx, { ...req.body, id: req.params.id }));
    return obterCurso(c, req.params.id);
  }));

  app.delete<{ Params: { id: string } }>('/cursos/:id', {
    preHandler: requer('treinamento.excluir'),
    schema: { tags, summary: 'Exclui curso sem matricula em andamento (ExcluirCurso, exclusao logica)', params: paramId, response: erros },
  }, async (req, reply) => {
    await naTransacao(req, async (casos, ctx) => exigirOk(await casos.excluirCurso.execute(ctx, { id: req.params.id })));
    return reply.code(204).send();
  });

  app.post<{ Params: { id: string }; Body: { titulo: string; ordem?: number } }>('/cursos/:id/modulos', {
    preHandler: requer('treinamento.criar'),
    schema: {
      tags, summary: 'Cria modulo do curso (CriarModulo)', params: paramId,
      body: { type: 'object', additionalProperties: false, required: ['titulo'], properties: propsModulo }, response: erros,
    },
  }, async (req, reply) => {
    const dto = await naTransacao(req, async (casos, ctx, c) => {
      exigirOk(await casos.criarModulo.execute(ctx, { ...req.body, curso_id: req.params.id }));
      return obterCurso(c, req.params.id);
    });
    return reply.code(201).send(dto);
  });

  app.patch<{ Params: { id: string }; Body: { titulo?: string; ordem?: number } }>('/modulos/:id', {
    preHandler: requer('treinamento.editar'),
    schema: { tags, summary: 'Edita modulo (EditarModulo)', params: paramId, body: { type: 'object', additionalProperties: false, properties: propsModulo }, response: erros },
  }, (req) => naTransacao(req, async (casos, ctx) => {
    exigirOk(await casos.editarModulo.execute(ctx, { ...req.body, id: req.params.id }));
    return { ok: true };
  }));

  app.delete<{ Params: { id: string } }>('/modulos/:id', {
    preHandler: requer('treinamento.excluir'),
    schema: { tags, summary: 'Exclui modulo sem aulas (ExcluirModulo)', params: paramId, response: erros },
  }, async (req, reply) => {
    await naTransacao(req, async (casos, ctx) => exigirOk(await casos.excluirModulo.execute(ctx, { id: req.params.id })));
    return reply.code(204).send();
  });

  app.patch<{ Params: { id: string }; Body: Partial<Omit<DadosAula, 'curso_id'>> }>('/aulas/:id', {
    preHandler: requer('treinamento.editar'),
    schema: { tags, summary: 'Edita aula, video externo e pre-requisito (EditarAula)', params: paramId, body: { type: 'object', additionalProperties: false, properties: propsAula }, response: erros },
  }, (req) => naTransacao(req, async (casos, ctx) => {
    exigirOk(await casos.editarAula.execute(ctx, { ...req.body, id: req.params.id }));
    return { ok: true };
  }));

  app.delete<{ Params: { id: string } }>('/aulas/:id', {
    preHandler: requer('treinamento.excluir'),
    schema: { tags, summary: 'Exclui aula que nao e pre-requisito de outra (ExcluirAula)', params: paramId, response: erros },
  }, async (req, reply) => {
    await naTransacao(req, async (casos, ctx) => exigirOk(await casos.excluirAula.execute(ctx, { id: req.params.id })));
    return reply.code(204).send();
  });

  app.post<{ Params: { id: string }; Body: { titulo: string; tipo?: string; url: string } }>('/aulas/:id/materiais', {
    preHandler: requer('treinamento.criar'),
    schema: {
      tags, summary: 'Anexa material de apoio a aula (AdicionarMaterial)', params: paramId,
      body: { type: 'object', additionalProperties: false, required: ['titulo', 'url'], properties: propsMaterial }, response: erros,
    },
  }, async (req, reply) => {
    const r = await naTransacao(req, async (casos, ctx) => exigirOk(await casos.adicionarMaterial.execute(ctx, { ...req.body, aula_id: req.params.id })));
    return reply.code(201).send(r);
  });

  app.delete<{ Params: { id: string } }>('/materiais/:id', {
    preHandler: requer('treinamento.excluir'),
    schema: { tags, summary: 'Remove material de apoio (RemoverMaterial)', params: paramId, response: erros },
  }, async (req, reply) => {
    await naTransacao(req, async (casos, ctx) => exigirOk(await casos.removerMaterial.execute(ctx, { id: req.params.id })));
    return reply.code(204).send();
  });
}
