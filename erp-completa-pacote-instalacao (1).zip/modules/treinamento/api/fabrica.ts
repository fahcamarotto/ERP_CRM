/**
 * Composicao do modulo: liga casos de uso aos adaptadores Postgres para um cliente de transacao.
 * Usada pelas rotas, pelas tools, pelo worker e pelo seed. Nao importa Fastify nem o pool do servidor.
 */
import type pg from 'pg';
import { CursoRepoPg } from './curso/adapter/curso-repo-pg.ts';
import { AdicionarMaterial, CriarAula, CriarModulo, EditarAula, EditarModulo, ExcluirAula, ExcluirModulo, RemoverMaterial } from './curso/use-case/conteudo.ts';
import { CriarCurso, EditarCurso, ExcluirCurso, MudarEstadoCurso } from './curso/use-case/cursos.ts';
import { MatriculaRepoPg } from './matricula/adapter/matricula-repo-pg.ts';
import { AtribuirTrilha, AtribuirTrilhaDaFuncao, CancelarMatricula, ConcluirAula, Matricular } from './matricula/use-case/matriculas.ts';
import { TrilhaRepoPg } from './trilha/adapter/trilha-repo-pg.ts';
import { ArquivarTrilha, CriarTrilha, EditarTrilha, ReativarTrilha } from './trilha/use-case/trilhas.ts';

export function casosDeUso(c: pg.PoolClient) {
  const cursos = new CursoRepoPg(c);
  const trilhas = new TrilhaRepoPg(c);
  const matriculas = new MatriculaRepoPg(c);
  const depsCurso = { repo: cursos, consultas: cursos };
  const depsConteudo = { cursos, modulos: cursos, aulas: cursos, materiais: cursos };
  const depsTrilha = { repo: trilhas, refs: trilhas };
  const depsMatricula = { repo: matriculas, consultas: matriculas };
  return {
    criarCurso: new CriarCurso(depsCurso),
    editarCurso: new EditarCurso(depsCurso),
    mudarEstadoCurso: new MudarEstadoCurso(depsCurso),
    excluirCurso: new ExcluirCurso(depsCurso),
    criarModulo: new CriarModulo(depsConteudo),
    editarModulo: new EditarModulo(depsConteudo),
    excluirModulo: new ExcluirModulo(depsConteudo),
    criarAula: new CriarAula(depsConteudo),
    editarAula: new EditarAula(depsConteudo),
    excluirAula: new ExcluirAula(depsConteudo),
    adicionarMaterial: new AdicionarMaterial(depsConteudo),
    removerMaterial: new RemoverMaterial(depsConteudo),
    criarTrilha: new CriarTrilha(depsTrilha),
    editarTrilha: new EditarTrilha(depsTrilha),
    arquivarTrilha: new ArquivarTrilha({ repo: trilhas }),
    reativarTrilha: new ReativarTrilha({ repo: trilhas }),
    matricular: new Matricular(depsMatricula),
    concluirAula: new ConcluirAula(depsMatricula),
    cancelarMatricula: new CancelarMatricula(depsMatricula),
    atribuirTrilha: new AtribuirTrilha(depsMatricula),
    atribuirTrilhaDaFuncao: new AtribuirTrilhaDaFuncao(depsMatricula),
  };
}

export type CasosDeUso = ReturnType<typeof casosDeUso>;
