-- M11 Treinamento: cursos com modulos, aulas (player externo) e material de apoio, trilhas por funcao,
-- matriculas com progresso por aula e certificado interno.
-- Toda tabela: tenant_id e workspace_id do contexto da sessao, PK composta, FK composta, RLS
-- por nucleo_aplicar_padrao, exclusao logica (sem DELETE). Idempotente.
-- Referencia ao Pessoas so por tabela publicada (CONTRATOS 7.1.7): pessoas_funcionarios e pessoas_funcoes.

-- M11.1 Cursos ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS treinamento_cursos (
  id                     uuid NOT NULL DEFAULT gen_random_uuid(),
  tenant_id              uuid NOT NULL DEFAULT nucleo_tenant_atual(),
  workspace_id           uuid NOT NULL DEFAULT nucleo_workspace_atual(),
  creator_id             uuid,
  titulo                 text NOT NULL CHECK (length(btrim(titulo)) BETWEEN 2 AND 200),
  descricao              text,
  prerequisito_curso_id  uuid,
  emite_certificado      boolean NOT NULL DEFAULT true,
  estado                 text NOT NULL DEFAULT 'rascunho' CHECK (estado IN ('rascunho', 'publicado', 'arquivado')),
  extras                 jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at             timestamptz NOT NULL DEFAULT now(),
  updated_at             timestamptz NOT NULL DEFAULT now(),
  deleted_at             timestamptz,
  PRIMARY KEY (id, tenant_id, workspace_id),
  FOREIGN KEY (workspace_id, tenant_id) REFERENCES workspaces (id, tenant_id),
  FOREIGN KEY (creator_id, tenant_id, workspace_id) REFERENCES usuarios (id, tenant_id, workspace_id),
  FOREIGN KEY (prerequisito_curso_id, tenant_id, workspace_id) REFERENCES treinamento_cursos (id, tenant_id, workspace_id),
  CHECK (prerequisito_curso_id IS NULL OR prerequisito_curso_id <> id)
);
CREATE UNIQUE INDEX IF NOT EXISTS treinamento_cursos_titulo_uq
  ON treinamento_cursos (tenant_id, workspace_id, lower(titulo)) WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS treinamento_cursos_lista_idx ON treinamento_cursos (tenant_id, workspace_id, created_at, id) WHERE deleted_at IS NULL;
SELECT nucleo_aplicar_padrao('treinamento_cursos');
DROP TRIGGER IF EXISTS treinamento_cursos_extras ON treinamento_cursos;
CREATE TRIGGER treinamento_cursos_extras BEFORE INSERT OR UPDATE OF extras ON treinamento_cursos
  FOR EACH ROW EXECUTE FUNCTION nucleo_trigger_extras('treinamento', 'curso');

CREATE TABLE IF NOT EXISTS treinamento_modulos (
  id            uuid NOT NULL DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL DEFAULT nucleo_tenant_atual(),
  workspace_id  uuid NOT NULL DEFAULT nucleo_workspace_atual(),
  creator_id    uuid,
  curso_id      uuid NOT NULL,
  titulo        text NOT NULL CHECK (length(btrim(titulo)) BETWEEN 2 AND 200),
  ordem         integer NOT NULL CHECK (ordem >= 1),
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now(),
  deleted_at    timestamptz,
  PRIMARY KEY (id, tenant_id, workspace_id),
  FOREIGN KEY (workspace_id, tenant_id) REFERENCES workspaces (id, tenant_id),
  FOREIGN KEY (creator_id, tenant_id, workspace_id) REFERENCES usuarios (id, tenant_id, workspace_id),
  FOREIGN KEY (curso_id, tenant_id, workspace_id) REFERENCES treinamento_cursos (id, tenant_id, workspace_id)
);
CREATE INDEX IF NOT EXISTS treinamento_modulos_curso_idx ON treinamento_modulos (tenant_id, workspace_id, curso_id, ordem) WHERE deleted_at IS NULL;
SELECT nucleo_aplicar_padrao('treinamento_modulos');

-- M11.2 Player externo: guarda so o provedor e o id do video ------------------------------
CREATE TABLE IF NOT EXISTS treinamento_aulas (
  id                    uuid NOT NULL DEFAULT gen_random_uuid(),
  tenant_id             uuid NOT NULL DEFAULT nucleo_tenant_atual(),
  workspace_id          uuid NOT NULL DEFAULT nucleo_workspace_atual(),
  creator_id            uuid,
  curso_id              uuid NOT NULL,
  modulo_id             uuid NOT NULL,
  titulo                text NOT NULL CHECK (length(btrim(titulo)) BETWEEN 2 AND 200),
  descricao             text,
  ordem                 integer NOT NULL CHECK (ordem >= 1),
  provedor              text CHECK (provedor IS NULL OR provedor IN ('youtube', 'vimeo', 'panda', 'bunny')),
  video_id              text CHECK (video_id IS NULL OR length(video_id) BETWEEN 1 AND 120),
  duracao_min           integer NOT NULL DEFAULT 0 CHECK (duracao_min BETWEEN 0 AND 1440),
  prerequisito_aula_id  uuid,
  created_at            timestamptz NOT NULL DEFAULT now(),
  updated_at            timestamptz NOT NULL DEFAULT now(),
  deleted_at            timestamptz,
  PRIMARY KEY (id, tenant_id, workspace_id),
  FOREIGN KEY (workspace_id, tenant_id) REFERENCES workspaces (id, tenant_id),
  FOREIGN KEY (creator_id, tenant_id, workspace_id) REFERENCES usuarios (id, tenant_id, workspace_id),
  FOREIGN KEY (curso_id, tenant_id, workspace_id) REFERENCES treinamento_cursos (id, tenant_id, workspace_id),
  FOREIGN KEY (modulo_id, tenant_id, workspace_id) REFERENCES treinamento_modulos (id, tenant_id, workspace_id),
  FOREIGN KEY (prerequisito_aula_id, tenant_id, workspace_id) REFERENCES treinamento_aulas (id, tenant_id, workspace_id),
  CHECK ((provedor IS NULL) = (video_id IS NULL)),
  CHECK (prerequisito_aula_id IS NULL OR prerequisito_aula_id <> id)
);
CREATE INDEX IF NOT EXISTS treinamento_aulas_curso_idx ON treinamento_aulas (tenant_id, workspace_id, curso_id, ordem) WHERE deleted_at IS NULL;
SELECT nucleo_aplicar_padrao('treinamento_aulas');

-- M11.6 Material de apoio anexado a aula ---------------------------------------------------
CREATE TABLE IF NOT EXISTS treinamento_materiais (
  id            uuid NOT NULL DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL DEFAULT nucleo_tenant_atual(),
  workspace_id  uuid NOT NULL DEFAULT nucleo_workspace_atual(),
  creator_id    uuid,
  aula_id       uuid NOT NULL,
  titulo        text NOT NULL CHECK (length(btrim(titulo)) BETWEEN 2 AND 200),
  tipo          text NOT NULL DEFAULT 'link' CHECK (tipo IN ('pdf', 'planilha', 'apresentacao', 'link', 'outro')),
  url           text NOT NULL CHECK (url ~ '^https?://' AND length(url) <= 2000),
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now(),
  deleted_at    timestamptz,
  PRIMARY KEY (id, tenant_id, workspace_id),
  FOREIGN KEY (workspace_id, tenant_id) REFERENCES workspaces (id, tenant_id),
  FOREIGN KEY (creator_id, tenant_id, workspace_id) REFERENCES usuarios (id, tenant_id, workspace_id),
  FOREIGN KEY (aula_id, tenant_id, workspace_id) REFERENCES treinamento_aulas (id, tenant_id, workspace_id)
);
CREATE INDEX IF NOT EXISTS treinamento_materiais_aula_idx ON treinamento_materiais (tenant_id, workspace_id, aula_id) WHERE deleted_at IS NULL;
SELECT nucleo_aplicar_padrao('treinamento_materiais');

-- M11.5 Trilhas por funcao ----------------------------------------------------------------
CREATE TABLE IF NOT EXISTS treinamento_trilhas (
  id            uuid NOT NULL DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL DEFAULT nucleo_tenant_atual(),
  workspace_id  uuid NOT NULL DEFAULT nucleo_workspace_atual(),
  creator_id    uuid,
  nome          text NOT NULL CHECK (length(btrim(nome)) BETWEEN 2 AND 200),
  descricao     text,
  funcao_id     uuid,
  estado        text NOT NULL DEFAULT 'ativa' CHECK (estado IN ('ativa', 'arquivada')),
  extras        jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now(),
  deleted_at    timestamptz,
  PRIMARY KEY (id, tenant_id, workspace_id),
  FOREIGN KEY (workspace_id, tenant_id) REFERENCES workspaces (id, tenant_id),
  FOREIGN KEY (creator_id, tenant_id, workspace_id) REFERENCES usuarios (id, tenant_id, workspace_id),
  FOREIGN KEY (funcao_id, tenant_id, workspace_id) REFERENCES pessoas_funcoes (id, tenant_id, workspace_id)
);
CREATE UNIQUE INDEX IF NOT EXISTS treinamento_trilhas_nome_uq
  ON treinamento_trilhas (tenant_id, workspace_id, lower(nome)) WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS treinamento_trilhas_funcao_idx ON treinamento_trilhas (tenant_id, workspace_id, funcao_id) WHERE deleted_at IS NULL;
SELECT nucleo_aplicar_padrao('treinamento_trilhas');
DROP TRIGGER IF EXISTS treinamento_trilhas_extras ON treinamento_trilhas;
CREATE TRIGGER treinamento_trilhas_extras BEFORE INSERT OR UPDATE OF extras ON treinamento_trilhas
  FOR EACH ROW EXECUTE FUNCTION nucleo_trigger_extras('treinamento', 'trilha');

CREATE TABLE IF NOT EXISTS treinamento_trilha_cursos (
  id            uuid NOT NULL DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL DEFAULT nucleo_tenant_atual(),
  workspace_id  uuid NOT NULL DEFAULT nucleo_workspace_atual(),
  creator_id    uuid,
  trilha_id     uuid NOT NULL,
  curso_id      uuid NOT NULL,
  ordem         integer NOT NULL CHECK (ordem >= 1),
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now(),
  deleted_at    timestamptz,
  PRIMARY KEY (id, tenant_id, workspace_id),
  FOREIGN KEY (workspace_id, tenant_id) REFERENCES workspaces (id, tenant_id),
  FOREIGN KEY (creator_id, tenant_id, workspace_id) REFERENCES usuarios (id, tenant_id, workspace_id),
  FOREIGN KEY (trilha_id, tenant_id, workspace_id) REFERENCES treinamento_trilhas (id, tenant_id, workspace_id),
  FOREIGN KEY (curso_id, tenant_id, workspace_id) REFERENCES treinamento_cursos (id, tenant_id, workspace_id)
);
CREATE UNIQUE INDEX IF NOT EXISTS treinamento_trilha_cursos_uq ON treinamento_trilha_cursos (tenant_id, workspace_id, trilha_id, curso_id);
SELECT nucleo_aplicar_padrao('treinamento_trilha_cursos');

-- M11.4 Progresso por pessoa, conclusao e certificado interno --------------------------------
CREATE TABLE IF NOT EXISTS treinamento_matriculas (
  id                  uuid NOT NULL DEFAULT gen_random_uuid(),
  tenant_id           uuid NOT NULL DEFAULT nucleo_tenant_atual(),
  workspace_id        uuid NOT NULL DEFAULT nucleo_workspace_atual(),
  creator_id          uuid,
  funcionario_id      uuid NOT NULL,
  curso_id            uuid NOT NULL,
  trilha_id           uuid,
  origem              text NOT NULL DEFAULT 'manual' CHECK (origem IN ('manual', 'trilha', 'admissao')),
  estado              text NOT NULL DEFAULT 'em_andamento' CHECK (estado IN ('em_andamento', 'concluida', 'cancelada')),
  concluida_em        timestamptz,
  certificado_codigo  text CHECK (certificado_codigo IS NULL OR certificado_codigo ~ '^TRN-[0-9A-F]{4}-[0-9A-F]{4}$'),
  created_at          timestamptz NOT NULL DEFAULT now(),
  updated_at          timestamptz NOT NULL DEFAULT now(),
  deleted_at          timestamptz,
  PRIMARY KEY (id, tenant_id, workspace_id),
  FOREIGN KEY (workspace_id, tenant_id) REFERENCES workspaces (id, tenant_id),
  FOREIGN KEY (creator_id, tenant_id, workspace_id) REFERENCES usuarios (id, tenant_id, workspace_id),
  FOREIGN KEY (funcionario_id, tenant_id, workspace_id) REFERENCES pessoas_funcionarios (id, tenant_id, workspace_id),
  FOREIGN KEY (curso_id, tenant_id, workspace_id) REFERENCES treinamento_cursos (id, tenant_id, workspace_id),
  FOREIGN KEY (trilha_id, tenant_id, workspace_id) REFERENCES treinamento_trilhas (id, tenant_id, workspace_id),
  CHECK ((estado = 'concluida') = (concluida_em IS NOT NULL))
);
-- Uma matricula viva por pessoa e curso (cancelada libera nova matricula).
CREATE UNIQUE INDEX IF NOT EXISTS treinamento_matriculas_uq
  ON treinamento_matriculas (tenant_id, workspace_id, funcionario_id, curso_id) WHERE deleted_at IS NULL AND estado <> 'cancelada';
CREATE UNIQUE INDEX IF NOT EXISTS treinamento_matriculas_certificado_uq
  ON treinamento_matriculas (tenant_id, workspace_id, certificado_codigo) WHERE certificado_codigo IS NOT NULL;
CREATE INDEX IF NOT EXISTS treinamento_matriculas_lista_idx ON treinamento_matriculas (tenant_id, workspace_id, created_at, id) WHERE deleted_at IS NULL;
SELECT nucleo_aplicar_padrao('treinamento_matriculas');

CREATE TABLE IF NOT EXISTS treinamento_progresso (
  id            uuid NOT NULL DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL DEFAULT nucleo_tenant_atual(),
  workspace_id  uuid NOT NULL DEFAULT nucleo_workspace_atual(),
  creator_id    uuid,
  matricula_id  uuid NOT NULL,
  aula_id       uuid NOT NULL,
  concluida_em  timestamptz NOT NULL DEFAULT now(),
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now(),
  deleted_at    timestamptz,
  PRIMARY KEY (id, tenant_id, workspace_id),
  FOREIGN KEY (workspace_id, tenant_id) REFERENCES workspaces (id, tenant_id),
  FOREIGN KEY (creator_id, tenant_id, workspace_id) REFERENCES usuarios (id, tenant_id, workspace_id),
  FOREIGN KEY (matricula_id, tenant_id, workspace_id) REFERENCES treinamento_matriculas (id, tenant_id, workspace_id),
  FOREIGN KEY (aula_id, tenant_id, workspace_id) REFERENCES treinamento_aulas (id, tenant_id, workspace_id)
);
CREATE UNIQUE INDEX IF NOT EXISTS treinamento_progresso_uq ON treinamento_progresso (tenant_id, workspace_id, matricula_id, aula_id);
SELECT nucleo_aplicar_padrao('treinamento_progresso');

-- Papeis de banco: API (erp_app) e worker (erp_worker, trilha da funcao na admissao).
GRANT SELECT, INSERT, UPDATE ON treinamento_cursos, treinamento_modulos, treinamento_aulas, treinamento_materiais,
  treinamento_trilhas, treinamento_trilha_cursos, treinamento_matriculas, treinamento_progresso TO erp_app;
GRANT SELECT, INSERT, UPDATE ON treinamento_matriculas TO erp_worker;
GRANT SELECT ON treinamento_cursos, treinamento_modulos, treinamento_aulas, treinamento_trilhas, treinamento_trilha_cursos,
  treinamento_progresso TO erp_worker;
