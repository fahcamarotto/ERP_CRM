/**
 * P3 do modulo Treinamento: objetos de valor, entidades e cada caso de uso com repositorio em memoria.
 * Rodar: node --import tsx --test modules/treinamento/tests/*.test.ts
 */
import assert from 'node:assert/strict';
import { randomUUID } from 'node:crypto';
import { describe, it } from 'node:test';
import { Aula } from '../api/curso/model/aula.ts';
import { Curso } from '../api/curso/model/curso.ts';
import { Material } from '../api/curso/model/material.ts';
import { urlEmbed, VideoExterno } from '../api/curso/model/video-externo.ts';
import { AdicionarMaterial, CriarAula, CriarModulo, EditarAula, ExcluirAula, ExcluirModulo } from '../api/curso/use-case/conteudo.ts';
import { CriarCurso, EditarCurso, ExcluirCurso, MudarEstadoCurso } from '../api/curso/use-case/cursos.ts';
import { CodigoCertificado } from '../api/matricula/model/certificado.ts';
import { Matricula } from '../api/matricula/model/matricula.ts';
import { AtribuirTrilha, AtribuirTrilhaDaFuncao, CancelarMatricula, ConcluirAula, Matricular } from '../api/matricula/use-case/matriculas.ts';
import { Trilha } from '../api/trilha/model/trilha.ts';
import { ArquivarTrilha, CriarTrilha, EditarTrilha } from '../api/trilha/use-case/trilhas.ts';
import { contexto, CursosMemoria, MatriculasMemoria, TrilhasMemoria, USUARIO } from './memoria.ts';

const GUID = '0f1e2d3c-4b5a-6978-8a9b-0c1d2e3f4a5b';

function montarCursos() {
  const repo = new CursosMemoria();
  const depsCurso = { repo, consultas: repo };
  const depsConteudo = { cursos: repo, modulos: repo, aulas: repo, materiais: repo };
  return {
    repo,
    criarCurso: new CriarCurso(depsCurso), editarCurso: new EditarCurso(depsCurso), mudar: new MudarEstadoCurso(depsCurso), excluir: new ExcluirCurso(depsCurso),
    criarModulo: new CriarModulo(depsConteudo), excluirModulo: new ExcluirModulo(depsConteudo), criarAula: new CriarAula(depsConteudo),
    editarAula: new EditarAula(depsConteudo), excluirAula: new ExcluirAula(depsConteudo), material: new AdicionarMaterial(depsConteudo),
  };
}

function montarMatriculas() {
  const repo = new MatriculasMemoria();
  const deps = { repo, consultas: repo };
  const pessoa = { id: randomUUID(), nome: 'Ana Lima', usuario_id: USUARIO, funcao_id: randomUUID() };
  repo.pessoas.set(pessoa.id, pessoa);
  const a1 = randomUUID(), a2 = randomUUID(), a3 = randomUUID();
  const base = { id: randomUUID(), titulo: 'Integracao', estado: 'publicado' as const, emite_certificado: true, prerequisito_curso_id: null,
    aulas: [{ id: a1, prerequisito_aula_id: null }, { id: a2, prerequisito_aula_id: a1 }, { id: a3, prerequisito_aula_id: null }] };
  const avancado = { id: randomUUID(), titulo: 'Atendimento', estado: 'publicado' as const, emite_certificado: false, prerequisito_curso_id: base.id,
    aulas: [{ id: randomUUID(), prerequisito_aula_id: null }] };
  repo.cursos.set(base.id, base);
  repo.cursos.set(avancado.id, avancado);
  return {
    repo, pessoa, base, avancado, aulas: [a1, a2, a3],
    matricular: new Matricular(deps), concluir: new ConcluirAula(deps, () => new Date('2026-10-01T12:00:00Z')),
    cancelar: new CancelarMatricula(deps), atribuir: new AtribuirTrilha(deps), daFuncao: new AtribuirTrilhaDaFuncao(deps),
  };
}

describe('VideoExterno (M11.2)', () => {
  it('aceita id puro e URL colada dos quatro provedores, guardando so o id', () => {
    assert.equal(VideoExterno.create('youtube', 'https://www.youtube.com/watch?v=dQw4w9WgXcQ&t=10').id, 'dQw4w9WgXcQ');
    assert.equal(VideoExterno.create('youtube', 'https://youtu.be/dQw4w9WgXcQ').id, 'dQw4w9WgXcQ');
    assert.equal(VideoExterno.create('vimeo', 'https://vimeo.com/76979871').id, '76979871');
    assert.equal(VideoExterno.create('panda', `https://player-vz-1a2b3c4d-5e6.tv.pandavideo.com.br/embed/?v=${GUID}`).id, `vz-1a2b3c4d-5e6/${GUID}`);
    assert.equal(VideoExterno.create('bunny', `https://iframe.mediadelivery.net/embed/123456/${GUID}`).id, `123456/${GUID}`);
  });
  it('recusa id fora do formato e provedor desconhecido', () => {
    const r = VideoExterno.tryCreate('youtube', 'curto');
    assert.equal(r.ok, false);
    assert.equal(!r.ok && r.erros[0]!.codigo, 'video_invalido');
    const p = VideoExterno.tryCreate('dailymotion', 'x');
    assert.equal(!p.ok && p.erros[0]!.codigo, 'provedor_invalido');
    assert.throws(() => VideoExterno.create('vimeo', 'abc'));
  });
  it('monta a URL do player embutido', () => {
    assert.equal(urlEmbed('youtube', 'dQw4w9WgXcQ'), 'https://www.youtube-nocookie.com/embed/dQw4w9WgXcQ');
    assert.equal(urlEmbed('bunny', `123456/${GUID}`), `https://iframe.mediadelivery.net/embed/123456/${GUID}`);
    assert.equal(VideoExterno.create('vimeo', '76979871').urlEmbed(), 'https://player.vimeo.com/video/76979871');
  });
});

describe('Entidades', () => {
  it('Curso.tryCreate acumula erros e editar nao muta o original', () => {
    const r = Curso.tryCreate({ titulo: 'x', descricao: 'd'.repeat(4001) });
    assert.equal(!r.ok && r.erros.length, 2);
    const c = Curso.create({ titulo: 'Integracao' });
    const e = c.editar({ titulo: 'Integracao 2' });
    assert.ok(e.ok);
    assert.equal(c.titulo, 'Integracao');
    assert.equal(e.ok && e.valor.titulo, 'Integracao 2');
  });
  it('Curso: transicao invalida (arquivado -> publicado) e arquivado nao edita', () => {
    const arq = Curso.create({ titulo: 'Integracao' }).mudarEstado('arquivado');
    assert.ok(arq.ok);
    const r = arq.ok ? arq.valor.mudarEstado('publicado') : null;
    assert.equal(r && !r.ok && r.erros[0]!.codigo, 'transicao_invalida');
    const ed = arq.ok ? arq.valor.editar({ titulo: 'Outro' }) : null;
    assert.equal(ed && !ed.ok && ed.erros[0]!.codigo, 'transicao_invalida');
  });
  it('Aula exige provedor e id juntos; Material exige URL http(s)', () => {
    const a = Aula.tryCreate({ curso_id: GUID, modulo_id: GUID, titulo: 'Aula', ordem: 1, provedor: 'youtube' });
    assert.equal(!a.ok && a.erros[0]!.codigo, 'video_invalido');
    const sem = Aula.create({ curso_id: GUID, modulo_id: GUID, titulo: 'Aula sem video', ordem: 1 });
    assert.equal(sem.temVideo, false);
    assert.equal(Material.tryCreate({ aula_id: GUID, titulo: 'Apostila', url: 'ftp://x' }).ok, false);
    assert.equal(Material.tryCreate({ aula_id: GUID, titulo: 'Apostila', url: 'https://exemplo.com/a.pdf', tipo: 'pdf' }).ok, true);
  });
  it('CodigoCertificado e deterministico e valida formato', () => {
    const id = randomUUID();
    assert.equal(CodigoCertificado.gerar(id).valor, CodigoCertificado.gerar(id).valor);
    assert.match(CodigoCertificado.gerar(id).valor, /^TRN-[0-9A-F]{4}-[0-9A-F]{4}$/);
    assert.equal(CodigoCertificado.tryCreate('trn-abcd-1234').ok, true);
    assert.throws(() => CodigoCertificado.create('XYZ'));
  });
  it('Trilha arquivada nao edita e nao arquiva de novo', () => {
    const t = Trilha.create({ nome: 'Integracao' }).arquivar();
    assert.ok(t.ok);
    assert.equal(t.ok && !t.valor.arquivar().ok, true);
    assert.equal(t.ok && !t.valor.editar({ nome: 'X' }).ok, true);
  });
});

describe('Cursos, modulos, aulas e material (M11.1, M11.2, M11.6)', () => {
  it('cria curso, modulo, aulas em ordem com pre-requisito, anexa material e publica', async () => {
    const m = montarCursos();
    const ctx = contexto();
    const c = await m.criarCurso.execute(ctx, { titulo: 'Integracao' });
    assert.ok(c.ok);
    const cursoId = c.ok ? c.valor.id : '';
    const semAula = await m.mudar.execute(ctx, { id: cursoId, estado: 'publicado' });
    assert.equal(!semAula.ok && semAula.erros[0]!.codigo, 'curso_sem_aulas');
    const mod = await m.criarModulo.execute(ctx, { curso_id: cursoId, titulo: 'Boas-vindas' });
    const modId = mod.ok ? mod.valor.id : '';
    const a1 = await m.criarAula.execute(ctx, { curso_id: cursoId, modulo_id: modId, titulo: 'Historia', provedor: 'youtube', video_id: 'https://youtu.be/dQw4w9WgXcQ' });
    const a1Id = a1.ok ? a1.valor.id : '';
    const a2 = await m.criarAula.execute(ctx, { curso_id: cursoId, modulo_id: modId, titulo: 'Primeira semana', provedor: 'vimeo', video_id: '76979871', prerequisito_aula_id: a1Id });
    assert.ok(a2.ok);
    assert.equal(m.repo.aulas.get(a1Id)!.video_id, 'dQw4w9WgXcQ');
    assert.equal(m.repo.aulas.get(a2.ok ? a2.valor.id : '')!.ordem, 2);
    const mat = await m.material.execute(ctx, { aula_id: a1Id, titulo: 'Manual', tipo: 'pdf', url: 'https://exemplo.com/manual.pdf' });
    assert.ok(mat.ok);
    const pub = await m.mudar.execute(ctx, { id: cursoId, estado: 'publicado' });
    assert.ok(pub.ok);
    assert.deepEqual(ctx.efeitos.eventos.map((e) => e.evento), ['curso.publicado']);
    assert.ok(ctx.efeitos.auditoria.some((a) => a.acao === 'curso.aula_criar'));
  });
  it('titulo duplicado vira conflito e pre-requisito ciclico e recusado', async () => {
    const m = montarCursos();
    const ctx = contexto();
    const a = await m.criarCurso.execute(ctx, { titulo: 'Base' });
    const dup = await m.criarCurso.execute(ctx, { titulo: 'base' });
    assert.equal(!dup.ok && dup.erros[0]!.codigo, 'conflito');
    const b = await m.criarCurso.execute(ctx, { titulo: 'Avancado', prerequisito_curso_id: a.ok ? a.valor.id : '' });
    assert.ok(b.ok);
    const ciclo = await m.editarCurso.execute(ctx, { id: a.ok ? a.valor.id : '', prerequisito_curso_id: b.ok ? b.valor.id : '' });
    assert.equal(!ciclo.ok && ciclo.erros[0]!.codigo, 'prerequisito_ciclico');
    const inexistente = await m.criarCurso.execute(ctx, { titulo: 'Outro', prerequisito_curso_id: randomUUID() });
    assert.equal(!inexistente.ok && inexistente.erros[0]!.codigo, 'prerequisito_invalido');
  });
  it('aula: modulo de outro curso, ciclo de pre-requisito, exclusao bloqueada por dependente e nao encontrado', async () => {
    const m = montarCursos();
    const ctx = contexto();
    const c1 = await m.criarCurso.execute(ctx, { titulo: 'Curso um' });
    const c2 = await m.criarCurso.execute(ctx, { titulo: 'Curso dois' });
    const id1 = c1.ok ? c1.valor.id : '', id2 = c2.ok ? c2.valor.id : '';
    const mod2 = await m.criarModulo.execute(ctx, { curso_id: id2, titulo: 'Modulo do dois' });
    const errada = await m.criarAula.execute(ctx, { curso_id: id1, modulo_id: mod2.ok ? mod2.valor.id : '', titulo: 'Aula' });
    assert.equal(!errada.ok && errada.erros[0]!.codigo, 'modulo_invalido');
    const mod1 = await m.criarModulo.execute(ctx, { curso_id: id1, titulo: 'Modulo do um' });
    const mid = mod1.ok ? mod1.valor.id : '';
    const x = await m.criarAula.execute(ctx, { curso_id: id1, modulo_id: mid, titulo: 'Aula X' });
    const y = await m.criarAula.execute(ctx, { curso_id: id1, modulo_id: mid, titulo: 'Aula Y', prerequisito_aula_id: x.ok ? x.valor.id : '' });
    const ciclo = await m.editarAula.execute(ctx, { id: x.ok ? x.valor.id : '', prerequisito_aula_id: y.ok ? y.valor.id : '' });
    assert.equal(!ciclo.ok && ciclo.erros[0]!.codigo, 'prerequisito_ciclico');
    const bloqueada = await m.excluirAula.execute(ctx, { id: x.ok ? x.valor.id : '' });
    assert.equal(!bloqueada.ok && bloqueada.erros[0]!.codigo, 'conflito');
    const modComAula = await m.excluirModulo.execute(ctx, { id: mid });
    assert.equal(!modComAula.ok && modComAula.erros[0]!.codigo, 'conflito');
    const nada = await m.editarAula.execute(ctx, { id: randomUUID(), titulo: 'Nova' });
    assert.equal(!nada.ok && nada.erros[0]!.codigo, 'nao_encontrado');
  });
  it('excluir curso com matricula em andamento e conflito; sem matricula exclui', async () => {
    const m = montarCursos();
    const ctx = contexto();
    const c = await m.criarCurso.execute(ctx, { titulo: 'Excluivel' });
    const id = c.ok ? c.valor.id : '';
    m.repo.ativas.set(id, 2);
    const r = await m.excluir.execute(ctx, { id });
    assert.equal(!r.ok && r.erros[0]!.codigo, 'conflito');
    m.repo.ativas.set(id, 0);
    assert.ok((await m.excluir.execute(ctx, { id })).ok);
    assert.equal(await m.repo.obterPorId(id), null);
  });
});

describe('Trilhas (M11.5)', () => {
  it('cria com funcao e cursos validos; recusa funcao e curso inexistentes; arquivada nao edita', async () => {
    const repo = new TrilhasMemoria();
    const funcao = randomUUID(), curso = randomUUID();
    repo.funcoes.add(funcao);
    repo.cursos.add(curso);
    const deps = { repo, refs: repo };
    const ctx = contexto();
    const ok1 = await new CriarTrilha(deps).execute(ctx, { nome: 'Integracao', funcao_id: funcao, curso_ids: [curso, curso] });
    assert.ok(ok1.ok);
    assert.deepEqual(repo.linhas.get(ok1.ok ? ok1.valor.id : '')!.curso_ids, [curso]);
    const ruim = await new CriarTrilha(deps).execute(ctx, { nome: 'Outra', funcao_id: randomUUID(), curso_ids: [randomUUID()] });
    assert.deepEqual(!ruim.ok && ruim.erros.map((e) => e.codigo), ['funcao_invalida', 'curso_invalido']);
    const id = ok1.ok ? ok1.valor.id : '';
    assert.ok((await new ArquivarTrilha({ repo }).execute(ctx, { id })).ok);
    const ed = await new EditarTrilha(deps).execute(ctx, { id, nome: 'Nova' });
    assert.equal(!ed.ok && ed.erros[0]!.codigo, 'transicao_invalida');
  });
});

describe('Matriculas, progresso e certificado (M11.4 e M11.5)', () => {
  it('matricula, respeita pre-requisito de aula, conclui o curso e gera certificado', async () => {
    const m = montarMatriculas();
    const ctx = contexto();
    const r = await m.matricular.execute(ctx, { funcionario_id: m.pessoa.id, curso_id: m.base.id });
    assert.ok(r.ok);
    const id = r.ok ? r.valor.id : '';
    const dup = await m.matricular.execute(ctx, { funcionario_id: m.pessoa.id, curso_id: m.base.id });
    assert.equal(!dup.ok && dup.erros[0]!.codigo, 'conflito');
    const [a1, a2, a3] = m.aulas;
    const antes = await m.concluir.execute(ctx, { matricula_id: id, aula_id: a2!, gestor: false });
    assert.equal(!antes.ok && antes.erros[0]!.codigo, 'prerequisito_pendente');
    assert.ok((await m.concluir.execute(ctx, { matricula_id: id, aula_id: a1!, gestor: false })).ok);
    assert.ok((await m.concluir.execute(ctx, { matricula_id: id, aula_id: a1!, gestor: false })).ok, 'idempotente');
    assert.ok((await m.concluir.execute(ctx, { matricula_id: id, aula_id: a2!, gestor: false })).ok);
    const fim = await m.concluir.execute(ctx, { matricula_id: id, aula_id: a3!, gestor: false });
    assert.ok(fim.ok && fim.valor.concluiu_curso);
    const d = m.repo.linhas.get(id)!;
    assert.equal(d.estado, 'concluida');
    assert.equal(d.concluida_em, '2026-10-01T12:00:00.000Z');
    assert.equal(d.certificado_codigo, CodigoCertificado.gerar(id).valor);
    assert.deepEqual(ctx.efeitos.eventos.map((e) => e.evento), ['matricula.criada', 'matricula.concluida']);
    const depois = await m.concluir.execute(ctx, { matricula_id: id, aula_id: a1!, gestor: true });
    assert.equal(!depois.ok && depois.erros[0]!.codigo, 'transicao_invalida');
    const cancelar = await m.cancelar.execute(ctx, { id });
    assert.equal(!cancelar.ok && cancelar.erros[0]!.codigo, 'transicao_invalida');
  });
  it('outra pessoa sem gestor recebe sem_permissao; gestor registra; aula de outro curso e invalida', async () => {
    const m = montarMatriculas();
    const r = await m.matricular.execute(contexto(), { funcionario_id: m.pessoa.id, curso_id: m.base.id });
    const id = r.ok ? r.valor.id : '';
    const estranho = await m.concluir.execute(contexto(randomUUID()), { matricula_id: id, aula_id: m.aulas[0]!, gestor: false });
    assert.equal(!estranho.ok && estranho.erros[0]!.codigo, 'sem_permissao');
    assert.ok((await m.concluir.execute(contexto(randomUUID()), { matricula_id: id, aula_id: m.aulas[0]!, gestor: true })).ok);
    const fora = await m.concluir.execute(contexto(), { matricula_id: id, aula_id: randomUUID(), gestor: true });
    assert.equal(!fora.ok && fora.erros[0]!.codigo, 'aula_invalida');
    const nada = await m.concluir.execute(contexto(), { matricula_id: randomUUID(), aula_id: m.aulas[0]!, gestor: true });
    assert.equal(!nada.ok && nada.erros[0]!.codigo, 'nao_encontrado');
  });
  it('pre-requisito de curso bloqueia progresso ate o curso base ser concluido; curso sem certificado nao gera codigo', async () => {
    const m = montarMatriculas();
    const ctx = contexto();
    const r = await m.matricular.execute(ctx, { funcionario_id: m.pessoa.id, curso_id: m.avancado.id });
    const id = r.ok ? r.valor.id : '';
    const aula = m.avancado.aulas[0]!.id;
    const bloqueio = await m.concluir.execute(ctx, { matricula_id: id, aula_id: aula, gestor: true });
    assert.equal(!bloqueio.ok && bloqueio.erros[0]!.codigo, 'prerequisito_pendente');
    const base = Matricula.create({ funcionario_id: m.pessoa.id, curso_id: m.base.id });
    let x = base;
    for (const a of m.aulas) { const rr = x.concluirAula(a, { aulas: m.base.aulas, emite_certificado: true, prerequisito_pendente: null }); assert.ok(rr.ok); x = rr.ok ? rr.valor.matricula : x; }
    await m.repo.inserir(x);
    const libera = await m.concluir.execute(ctx, { matricula_id: id, aula_id: aula, gestor: true });
    assert.ok(libera.ok && libera.valor.concluiu_curso);
    assert.equal(libera.ok && libera.valor.certificado_codigo, null);
  });
  it('curso em rascunho e pessoa inexistente nao matriculam; cancelar libera nova matricula', async () => {
    const m = montarMatriculas();
    const ctx = contexto();
    m.repo.cursos.set(m.base.id, { ...m.base, estado: 'rascunho' });
    const rasc = await m.matricular.execute(ctx, { funcionario_id: m.pessoa.id, curso_id: m.base.id });
    assert.equal(!rasc.ok && rasc.erros[0]!.codigo, 'curso_nao_publicado');
    const ninguem = await m.matricular.execute(ctx, { funcionario_id: randomUUID(), curso_id: m.avancado.id });
    assert.equal(!ninguem.ok && ninguem.erros[0]!.codigo, 'funcionario_invalido');
    const r = await m.matricular.execute(ctx, { funcionario_id: m.pessoa.id, curso_id: m.avancado.id });
    assert.ok((await m.cancelar.execute(ctx, { id: r.ok ? r.valor.id : '' })).ok);
    assert.ok((await m.matricular.execute(ctx, { funcionario_id: m.pessoa.id, curso_id: m.avancado.id })).ok);
  });
  it('atribuir trilha matricula nos cursos publicados e e idempotente; admissao usa a trilha da funcao', async () => {
    const m = montarMatriculas();
    const rascunho = { id: randomUUID(), titulo: 'Rascunho', estado: 'rascunho' as const, emite_certificado: true, prerequisito_curso_id: null, aulas: [] };
    m.repo.cursos.set(rascunho.id, rascunho);
    const trilha = { id: randomUUID(), estado: 'ativa' as const, curso_ids: [m.base.id, m.avancado.id, rascunho.id], funcao_id: m.pessoa.funcao_id };
    m.repo.trilhas.set(trilha.id, trilha);
    const ctx = contexto();
    const r1 = await m.atribuir.execute(ctx, { trilha_id: trilha.id, funcionario_id: m.pessoa.id });
    assert.ok(r1.ok);
    assert.equal(r1.ok && r1.valor.criadas.length, 2);
    assert.deepEqual(r1.ok && r1.valor.ignorados, [{ curso_id: rascunho.id, motivo: 'curso_nao_publicado' }]);
    const r2 = await m.atribuir.execute(ctx, { trilha_id: trilha.id, funcionario_id: m.pessoa.id });
    assert.equal(r2.ok && r2.valor.criadas.length, 0);
    assert.equal(r2.ok && r2.valor.ja_matriculado.length, 2);

    const outra = { id: randomUUID(), nome: 'Bruno Reis', usuario_id: null, funcao_id: m.pessoa.funcao_id };
    m.repo.pessoas.set(outra.id, outra);
    const ev = { id: randomUUID(), evento: 'funcionario.admitido', dados: { id: outra.id, funcao_id: outra.funcao_id } };
    const adm = await m.daFuncao.execute(ctx, ev);
    assert.deepEqual(adm.ok && adm.valor, { trilhas: 1, matriculas: 2 });
    const repetido = await m.daFuncao.execute(ctx, ev);
    assert.deepEqual(repetido.ok && repetido.valor, { trilhas: 1, matriculas: 0 });
    assert.ok([...m.repo.linhas.values()].filter((l) => l.funcionario_id === outra.id).every((l) => l.origem === 'admissao'));
    const semFuncao = await m.daFuncao.execute(ctx, { id: randomUUID(), dados: { id: outra.id, funcao_id: null } });
    assert.deepEqual(semFuncao.ok && semFuncao.valor, { trilhas: 0, matriculas: 0 });
    m.repo.trilhas.set(trilha.id, { ...trilha, estado: 'arquivada' });
    const arq = await m.atribuir.execute(ctx, { trilha_id: trilha.id, funcionario_id: m.pessoa.id });
    assert.equal(!arq.ok && arq.erros[0]!.codigo, 'transicao_invalida');
  });
});
