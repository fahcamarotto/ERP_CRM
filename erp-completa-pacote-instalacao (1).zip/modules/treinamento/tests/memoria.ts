/**
 * Repositorios em memoria das portas do Treinamento e porta Efeitos que grava o que foi publicado.
 * Os casos de uso rodam aqui sem banco, sem Fastify e sem o SDK (P3).
 */
import type { ContextoCaso, Efeitos } from '../api/compartilhado/efeitos.ts';
import { Aula, type AulaDados } from '../api/curso/model/aula.ts';
import { Curso, type CursoDados } from '../api/curso/model/curso.ts';
import { Material, type MaterialDados } from '../api/curso/model/material.ts';
import { ModuloCurso, type ModuloCursoDados } from '../api/curso/model/modulo.ts';
import type { ConsultarCursos, GravarAulas, GravarCurso, GravarMateriais, GravarModulos, ObterCurso } from '../api/curso/model/portas.ts';
import { Matricula, type MatriculaDados } from '../api/matricula/model/matricula.ts';
import type { ConsultarParaMatricula, CursoParaMatricula, GravarMatricula, ObterMatricula } from '../api/matricula/model/portas.ts';
import type { ConsultarReferenciasTrilha, GravarTrilha, ObterTrilha } from '../api/trilha/model/portas.ts';
import { Trilha, type TrilhaDados } from '../api/trilha/model/trilha.ts';

export const USUARIO = '00000000-0000-4000-8000-000000000001';

export class EfeitosMemoria implements Efeitos {
  auditoria: { acao: string; entidade: string; id: string | null }[] = [];
  eventos: { evento: string; dados: Record<string, unknown> }[] = [];
  historicos: { entidade: string; id: string; antes: unknown; depois: unknown }[] = [];
  notas: { entidade: string; id: string; corpo: string }[] = [];
  async auditar(acao: string, entidade: string, id: string | null) { this.auditoria.push({ acao, entidade, id }); }
  async publicar(evento: string, dados: Record<string, unknown>) { this.eventos.push({ evento, dados }); }
  async historico(entidade: string, id: string, antes: unknown, depois: unknown) { this.historicos.push({ entidade, id, antes, depois }); }
  async nota(entidade: string, id: string, corpo: string) { this.notas.push({ entidade, id, corpo }); }
}

export function contexto(usuarioId = USUARIO): ContextoCaso & { efeitos: EfeitosMemoria } {
  return { ator: { tipo: 'usuario', id: usuarioId }, efeitos: new EfeitosMemoria() };
}

type Vivo<T> = T & { deleted: boolean };

export class CursosMemoria implements ObterCurso, GravarCurso, ConsultarCursos, GravarModulos, GravarAulas, GravarMateriais {
  cursos = new Map<string, Vivo<CursoDados>>();
  modulos = new Map<string, Vivo<ModuloCursoDados>>();
  aulas = new Map<string, Vivo<AulaDados>>();
  materiais = new Map<string, Vivo<MaterialDados>>();
  /** curso_id -> quantidade de matriculas em andamento (preenchido pelo teste). */
  ativas = new Map<string, number>();

  async obterPorId(id: string) { const l = this.cursos.get(id); return l && !l.deleted ? Curso.reidratar(l) : null; }
  async buscarPorTitulo(titulo: string) {
    const l = [...this.cursos.values()].find((x) => !x.deleted && x.titulo.toLowerCase() === titulo.toLowerCase());
    return l ? Curso.reidratar(l) : null;
  }
  async inserir(c: Curso) { this.cursos.set(c.id, { ...c.paraDados(), deleted: false }); }
  async atualizar(c: Curso) { this.cursos.set(c.id, { ...c.paraDados(), deleted: false }); }
  async excluir(id: string) { this.cursos.get(id)!.deleted = true; }
  async prerequisitoDe(id: string) { return this.cursos.get(id)?.prerequisito_curso_id ?? null; }
  async contarAulas(id: string) { return [...this.aulas.values()].filter((a) => !a.deleted && a.curso_id === id).length; }
  async matriculasAtivas(id: string) { return this.ativas.get(id) ?? 0; }

  async obterModulo(id: string) { const l = this.modulos.get(id); return l && !l.deleted ? ModuloCurso.reidratar(l) : null; }
  async inserirModulo(m: ModuloCurso) { this.modulos.set(m.id, { ...m.paraDados(), deleted: false }); }
  async atualizarModulo(m: ModuloCurso) { this.modulos.set(m.id, { ...m.paraDados(), deleted: false }); }
  async excluirModulo(id: string) { this.modulos.get(id)!.deleted = true; }
  async contarAulasDoModulo(id: string) { return [...this.aulas.values()].filter((a) => !a.deleted && a.modulo_id === id).length; }
  async proximaOrdemModulo(cursoId: string) { return Math.max(0, ...[...this.modulos.values()].filter((m) => !m.deleted && m.curso_id === cursoId).map((m) => m.ordem)) + 1; }

  async obterAula(id: string) { const l = this.aulas.get(id); return l && !l.deleted ? Aula.reidratar(l) : null; }
  async inserirAula(a: Aula) { this.aulas.set(a.id, { ...a.paraDados(), deleted: false }); }
  async atualizarAula(a: Aula) { this.aulas.set(a.id, { ...a.paraDados(), deleted: false }); }
  async excluirAula(id: string) { this.aulas.get(id)!.deleted = true; }
  async proximaOrdemAula(cursoId: string) { return Math.max(0, ...[...this.aulas.values()].filter((a) => !a.deleted && a.curso_id === cursoId).map((a) => a.ordem)) + 1; }
  async dependentesDaAula(id: string) { return [...this.aulas.values()].filter((a) => !a.deleted && a.prerequisito_aula_id === id).map((a) => a.id); }

  async obterMaterial(id: string) { const l = this.materiais.get(id); return l && !l.deleted ? Material.reidratar(l) : null; }
  async inserirMaterial(m: Material) { this.materiais.set(m.id, { ...m.paraDados(), deleted: false }); }
  async excluirMaterial(id: string) { this.materiais.get(id)!.deleted = true; }
}

export class TrilhasMemoria implements ObterTrilha, GravarTrilha, ConsultarReferenciasTrilha {
  linhas = new Map<string, TrilhaDados>();
  funcoes = new Set<string>();
  cursos = new Set<string>();
  async obterPorId(id: string) { const l = this.linhas.get(id); return l ? Trilha.reidratar(l) : null; }
  async buscarPorNome(nome: string) {
    const l = [...this.linhas.values()].find((x) => x.nome.toLowerCase() === nome.toLowerCase());
    return l ? Trilha.reidratar(l) : null;
  }
  async inserir(t: Trilha) { this.linhas.set(t.id, t.paraDados()); }
  async atualizar(t: Trilha) { this.linhas.set(t.id, t.paraDados()); }
  async funcaoAtiva(id: string) { return this.funcoes.has(id); }
  async cursosExistentes(ids: string[]) { return ids.filter((i) => this.cursos.has(i)); }
}

export class MatriculasMemoria implements ObterMatricula, GravarMatricula, ConsultarParaMatricula {
  linhas = new Map<string, MatriculaDados>();
  pessoas = new Map<string, { id: string; nome: string; usuario_id: string | null; funcao_id?: string }>();
  cursos = new Map<string, CursoParaMatricula>();
  trilhas = new Map<string, { id: string; estado: 'ativa' | 'arquivada'; curso_ids: string[]; funcao_id?: string }>();

  async obterPorId(id: string) { const l = this.linhas.get(id); return l ? Matricula.reidratar(l) : null; }
  async matriculaViva(f: string, c: string) {
    const l = [...this.linhas.values()].find((x) => x.funcionario_id === f && x.curso_id === c && x.estado !== 'cancelada');
    return l ? Matricula.reidratar(l) : null;
  }
  async inserir(m: Matricula) { this.linhas.set(m.id, m.paraDados()); }
  async atualizar(m: Matricula) { this.linhas.set(m.id, m.paraDados()); }
  async funcionarioAtivo(id: string) { const p = this.pessoas.get(id); return p ? { id: p.id, nome: p.nome, usuario_id: p.usuario_id } : null; }
  async funcionarioDoUsuario(u: string) { return [...this.pessoas.values()].find((p) => p.usuario_id === u)?.id ?? null; }
  async curso(id: string) { return this.cursos.get(id) ?? null; }
  async cursoConcluido(f: string, c: string) { return [...this.linhas.values()].some((x) => x.funcionario_id === f && x.curso_id === c && x.estado === 'concluida'); }
  async trilha(id: string) { const t = this.trilhas.get(id); return t ? { id: t.id, estado: t.estado, curso_ids: [...t.curso_ids] } : null; }
  async trilhasAtivasDaFuncao(f: string) { return [...this.trilhas.values()].filter((t) => t.estado === 'ativa' && t.funcao_id === f).map((t) => t.id); }
}
