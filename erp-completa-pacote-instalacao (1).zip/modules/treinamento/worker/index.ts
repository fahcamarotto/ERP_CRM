/**
 * Handlers de worker do Treinamento (carregados pelo worker do nucleo na partida).
 * `c` ja esta numa transacao do papel erp_worker com o escopo do job (RLS vale).
 */
import type { HandlersModulo } from '@erp/api/sdk/puro';
import { contextoPg } from '../api/compartilhado/efeitos-pg.ts';
import { casosDeUso } from '../api/fabrica.ts';
import type { EventoAdmissao } from '../api/matricula/use-case/matriculas.ts';

const SISTEMA = { tipo: 'sistema' as const, id: null };

const handlers: HandlersModulo = {
  // M11.5 Reacao a funcionario.admitido do Pessoas (CONTRATOS 7.1.7): matricula nas trilhas ativas da funcao.
  // Idempotente: matricula viva no mesmo curso e mantida, entao retry nao duplica.
  'treinamento:ao:funcionario.admitido': async (d, c) => {
    const ev = d.payload as EventoAdmissao;
    if (!ev?.dados?.id) return; // payload fora do contrato: nada a reprocessar
    const r = await casosDeUso(c).atribuirTrilhaDaFuncao.execute(contextoPg(c, SISTEMA), ev);
    if (!r.ok) throw new Error(r.erros.map((e) => e.mensagem).join('; '));
  },
};

export default handlers;
