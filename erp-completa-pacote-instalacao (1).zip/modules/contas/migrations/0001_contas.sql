-- M5 Contas a receber e a pagar: documentos (fatura, conta a pagar, nota de credito e reembolso na
-- mesma tabela), baixas parciais e totais, recorrencias (job), regua de cobranca e cobrancas (fila).
-- Dinheiro sempre em centavos inteiros (bigint). Toda tabela: tenant_id e workspace_id do contexto da
-- sessao, PK composta, FK composta, RLS por nucleo_aplicar_padrao, exclusao logica (sem DELETE). Idempotente.

-- M5.3 Recorrencias (criada antes do documento, que aponta para ela) --------------------------------
CREATE TABLE IF NOT EXISTS contas_recorrencias (
  id                   uuid NOT NULL DEFAULT gen_random_uuid(),
  tenant_id            uuid NOT NULL DEFAULT nucleo_tenant_atual(),
  workspace_id         uuid NOT NULL DEFAULT nucleo_workspace_atual(),
  creator_id           uuid,
  tipo                 text NOT NULL CHECK (tipo IN ('fatura', 'conta_pagar')),
  parceiro_id          uuid NOT NULL,
  descricao            text NOT NULL CHECK (length(btrim(descricao)) BETWEEN 2 AND 200),
  valor_centavos       bigint NOT NULL CHECK (valor_centavos > 0),
  moeda                text NOT NULL DEFAULT 'BRL' CHECK (moeda ~ '^[A-Z]{3}$'),
  frequencia           text NOT NULL CHECK (frequencia IN ('mensal', 'trimestral', 'anual')),
  dia_vencimento       integer NOT NULL CHECK (dia_vencimento BETWEEN 1 AND 28),
  antecedencia_dias    integer NOT NULL DEFAULT 5 CHECK (antecedencia_dias BETWEEN 0 AND 60),
  inicio               date NOT NULL,
  fim                  date,
  proxima_em           date,
  estado               text NOT NULL DEFAULT 'ativa' CHECK (estado IN ('ativa', 'pausada', 'encerrada')),
  categoria_id         uuid,
  centro_custo_id      uuid,
  conta_financeira_id  uuid,
  gerados              integer NOT NULL DEFAULT 0 CHECK (gerados >= 0),
  ultimo_documento_id  uuid,
  created_at           timestamptz NOT NULL DEFAULT now(),
  updated_at           timestamptz NOT NULL DEFAULT now(),
  deleted_at           timestamptz,
  PRIMARY KEY (id, tenant_id, workspace_id),
  CHECK (fim IS NULL OR fim >= inicio),
  FOREIGN KEY (workspace_id, tenant_id) REFERENCES workspaces (id, tenant_id),
  FOREIGN KEY (creator_id, tenant_id, workspace_id) REFERENCES usuarios (id, tenant_id, workspace_id),
  FOREIGN KEY (parceiro_id, tenant_id, workspace_id) REFERENCES cadastros_parceiros (id, tenant_id, workspace_id),
  FOREIGN KEY (categoria_id, tenant_id, workspace_id) REFERENCES financeiro_categorias (id, tenant_id, workspace_id),
  FOREIGN KEY (centro_custo_id, tenant_id, workspace_id) REFERENCES financeiro_centros_custo (id, tenant_id, workspace_id),
  FOREIGN KEY (conta_financeira_id, tenant_id, workspace_id) REFERENCES financeiro_contas (id, tenant_id, workspace_id)
);
CREATE INDEX IF NOT EXISTS contas_recorrencias_lista_idx ON contas_recorrencias (tenant_id, workspace_id, created_at, id) WHERE deleted_at IS NULL;
SELECT nucleo_aplicar_padrao('contas_recorrencias');

-- M5.1 Documento: fatura, conta a pagar, nota de credito e reembolso ---------------------------------
CREATE TABLE IF NOT EXISTS contas_documentos (
  id                     uuid NOT NULL DEFAULT gen_random_uuid(),
  tenant_id              uuid NOT NULL DEFAULT nucleo_tenant_atual(),
  workspace_id           uuid NOT NULL DEFAULT nucleo_workspace_atual(),
  creator_id             uuid,
  tipo                   text NOT NULL CHECK (tipo IN ('fatura', 'conta_pagar', 'nota_credito', 'reembolso')),
  numero                 text NOT NULL CHECK (length(numero) BETWEEN 1 AND 60),
  parceiro_id            uuid NOT NULL,
  descricao              text CHECK (descricao IS NULL OR length(descricao) <= 200),
  emissao                date NOT NULL DEFAULT current_date,
  vencimento             date NOT NULL,
  condicao_pagamento     text NOT NULL DEFAULT 'a_vista'
                         CHECK (condicao_pagamento IN ('a_vista', '7_dias', '15_dias', '30_dias', '45_dias', '60_dias', '90_dias', 'personalizada')),
  moeda                  text NOT NULL DEFAULT 'BRL' CHECK (moeda ~ '^[A-Z]{3}$'),
  itens                  jsonb NOT NULL DEFAULT '[]'::jsonb CHECK (jsonb_typeof(itens) = 'array'),
  valor_centavos         bigint NOT NULL CHECK (valor_centavos > 0),
  desconto_centavos      bigint NOT NULL DEFAULT 0 CHECK (desconto_centavos >= 0),
  multa_pct              numeric(5,2) NOT NULL DEFAULT 0 CHECK (multa_pct BETWEEN 0 AND 20),
  juros_mes_pct          numeric(5,2) NOT NULL DEFAULT 0 CHECK (juros_mes_pct BETWEEN 0 AND 10),
  pago_centavos          bigint NOT NULL DEFAULT 0 CHECK (pago_centavos >= 0),
  saldo_centavos         bigint NOT NULL CHECK (saldo_centavos >= 0),
  estado                 text NOT NULL DEFAULT 'em_aberto' CHECK (estado IN ('em_aberto', 'parcial', 'pago', 'cancelado')),
  categoria_id           uuid,
  centro_custo_id        uuid,
  conta_financeira_id    uuid,
  documento_origem_id    uuid,
  recorrencia_id         uuid,
  competencia            date,
  observacoes            text CHECK (observacoes IS NULL OR length(observacoes) <= 2000),
  cancelado_motivo       text,
  pago_em                date,
  vencida_em             date,
  chave_idempotencia     text,
  extras                 jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at             timestamptz NOT NULL DEFAULT now(),
  updated_at             timestamptz NOT NULL DEFAULT now(),
  deleted_at             timestamptz,
  PRIMARY KEY (id, tenant_id, workspace_id),
  CHECK (vencimento >= emissao),
  CHECK (desconto_centavos < valor_centavos),
  CHECK (saldo_centavos = valor_centavos - desconto_centavos - pago_centavos),
  CHECK ((estado = 'pago') = (saldo_centavos = 0 AND estado <> 'cancelado')),
  FOREIGN KEY (workspace_id, tenant_id) REFERENCES workspaces (id, tenant_id),
  FOREIGN KEY (creator_id, tenant_id, workspace_id) REFERENCES usuarios (id, tenant_id, workspace_id),
  FOREIGN KEY (parceiro_id, tenant_id, workspace_id) REFERENCES cadastros_parceiros (id, tenant_id, workspace_id),
  FOREIGN KEY (categoria_id, tenant_id, workspace_id) REFERENCES financeiro_categorias (id, tenant_id, workspace_id),
  FOREIGN KEY (centro_custo_id, tenant_id, workspace_id) REFERENCES financeiro_centros_custo (id, tenant_id, workspace_id),
  FOREIGN KEY (conta_financeira_id, tenant_id, workspace_id) REFERENCES financeiro_contas (id, tenant_id, workspace_id),
  FOREIGN KEY (documento_origem_id, tenant_id, workspace_id) REFERENCES contas_documentos (id, tenant_id, workspace_id),
  FOREIGN KEY (recorrencia_id, tenant_id, workspace_id) REFERENCES contas_recorrencias (id, tenant_id, workspace_id)
);
CREATE UNIQUE INDEX IF NOT EXISTS contas_documentos_numero_uq
  ON contas_documentos (tenant_id, workspace_id, tipo, numero) WHERE deleted_at IS NULL;
CREATE UNIQUE INDEX IF NOT EXISTS contas_documentos_chave_uq
  ON contas_documentos (tenant_id, workspace_id, chave_idempotencia) WHERE chave_idempotencia IS NOT NULL;
CREATE UNIQUE INDEX IF NOT EXISTS contas_documentos_competencia_uq
  ON contas_documentos (tenant_id, workspace_id, recorrencia_id, competencia) WHERE recorrencia_id IS NOT NULL AND competencia IS NOT NULL AND deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS contas_documentos_lista_idx ON contas_documentos (tenant_id, workspace_id, created_at, id) WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS contas_documentos_vencimento_idx ON contas_documentos (tenant_id, workspace_id, estado, vencimento) WHERE deleted_at IS NULL;
SELECT nucleo_aplicar_padrao('contas_documentos');
DROP TRIGGER IF EXISTS contas_documentos_extras ON contas_documentos;
CREATE TRIGGER contas_documentos_extras BEFORE INSERT OR UPDATE OF extras ON contas_documentos
  FOR EACH ROW EXECUTE FUNCTION nucleo_trigger_extras('contas', 'documento');

-- M5.2 Baixas (parcial e total). Cada baixa publica fatura.paga e vira lancamento no Financeiro --------
CREATE TABLE IF NOT EXISTS contas_baixas (
  id                   uuid NOT NULL DEFAULT gen_random_uuid(),
  tenant_id            uuid NOT NULL DEFAULT nucleo_tenant_atual(),
  workspace_id         uuid NOT NULL DEFAULT nucleo_workspace_atual(),
  creator_id           uuid,
  documento_id         uuid NOT NULL,
  data                 date NOT NULL,
  valor_centavos       bigint NOT NULL CHECK (valor_centavos > 0),
  juros_centavos       bigint NOT NULL DEFAULT 0 CHECK (juros_centavos >= 0),
  multa_centavos       bigint NOT NULL DEFAULT 0 CHECK (multa_centavos >= 0),
  desconto_centavos    bigint NOT NULL DEFAULT 0 CHECK (desconto_centavos >= 0),
  total_centavos       bigint NOT NULL CHECK (total_centavos > 0),
  forma                text NOT NULL DEFAULT 'transferencia' CHECK (forma IN ('pix', 'boleto', 'dinheiro', 'transferencia', 'cartao', 'outro')),
  conta_financeira_id  uuid,
  origem               text NOT NULL DEFAULT 'manual' CHECK (origem IN ('manual', 'webhook', 'seed')),
  id_externo           text,
  chave_idempotencia   text,
  created_at           timestamptz NOT NULL DEFAULT now(),
  updated_at           timestamptz NOT NULL DEFAULT now(),
  deleted_at           timestamptz,
  PRIMARY KEY (id, tenant_id, workspace_id),
  CHECK (total_centavos = valor_centavos + juros_centavos + multa_centavos - desconto_centavos),
  FOREIGN KEY (workspace_id, tenant_id) REFERENCES workspaces (id, tenant_id),
  FOREIGN KEY (creator_id, tenant_id, workspace_id) REFERENCES usuarios (id, tenant_id, workspace_id),
  FOREIGN KEY (documento_id, tenant_id, workspace_id) REFERENCES contas_documentos (id, tenant_id, workspace_id),
  FOREIGN KEY (conta_financeira_id, tenant_id, workspace_id) REFERENCES financeiro_contas (id, tenant_id, workspace_id)
);
CREATE UNIQUE INDEX IF NOT EXISTS contas_baixas_chave_uq
  ON contas_baixas (tenant_id, workspace_id, chave_idempotencia) WHERE chave_idempotencia IS NOT NULL;
CREATE UNIQUE INDEX IF NOT EXISTS contas_baixas_externo_uq
  ON contas_baixas (tenant_id, workspace_id, id_externo) WHERE id_externo IS NOT NULL;
CREATE INDEX IF NOT EXISTS contas_baixas_documento_idx ON contas_baixas (tenant_id, workspace_id, documento_id) WHERE deleted_at IS NULL;
SELECT nucleo_aplicar_padrao('contas_baixas');

-- M5.4 Regua de cobranca (uma por workspace) -------------------------------------------------------
CREATE TABLE IF NOT EXISTS contas_reguas (
  id            uuid NOT NULL DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL DEFAULT nucleo_tenant_atual(),
  workspace_id  uuid NOT NULL DEFAULT nucleo_workspace_atual(),
  creator_id    uuid,
  ativa         boolean NOT NULL DEFAULT true,
  etapas        jsonb NOT NULL DEFAULT '[]'::jsonb CHECK (jsonb_typeof(etapas) = 'array'),
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now(),
  deleted_at    timestamptz,
  PRIMARY KEY (id, tenant_id, workspace_id),
  FOREIGN KEY (workspace_id, tenant_id) REFERENCES workspaces (id, tenant_id),
  FOREIGN KEY (creator_id, tenant_id, workspace_id) REFERENCES usuarios (id, tenant_id, workspace_id)
);
CREATE UNIQUE INDEX IF NOT EXISTS contas_reguas_uma_uq ON contas_reguas (tenant_id, workspace_id) WHERE deleted_at IS NULL;
SELECT nucleo_aplicar_padrao('contas_reguas');

-- M5.4 e M5.5 Cobrancas (email, WhatsApp, Pix e boleto), processadas pela fila ------------------------
CREATE TABLE IF NOT EXISTS contas_cobrancas (
  id             uuid NOT NULL DEFAULT gen_random_uuid(),
  tenant_id      uuid NOT NULL DEFAULT nucleo_tenant_atual(),
  workspace_id   uuid NOT NULL DEFAULT nucleo_workspace_atual(),
  creator_id     uuid,
  documento_id   uuid NOT NULL,
  canal          text NOT NULL CHECK (canal IN ('email', 'whatsapp', 'pix', 'boleto')),
  etapa          text NOT NULL DEFAULT 'manual' CHECK (etapa ~ '^(manual|D[+-]?[0-9]{1,2})$'),
  agendada_para  timestamptz NOT NULL DEFAULT now(),
  estado         text NOT NULL DEFAULT 'agendada'
                 CHECK (estado IN ('agendada', 'enviada', 'aguardando_conector', 'sem_contato', 'cancelada', 'erro')),
  destino        text,
  referencia     text,
  erro           text,
  enviada_em     timestamptz,
  job_id         uuid,
  created_at     timestamptz NOT NULL DEFAULT now(),
  updated_at     timestamptz NOT NULL DEFAULT now(),
  deleted_at     timestamptz,
  PRIMARY KEY (id, tenant_id, workspace_id),
  FOREIGN KEY (workspace_id, tenant_id) REFERENCES workspaces (id, tenant_id),
  FOREIGN KEY (creator_id, tenant_id, workspace_id) REFERENCES usuarios (id, tenant_id, workspace_id),
  FOREIGN KEY (documento_id, tenant_id, workspace_id) REFERENCES contas_documentos (id, tenant_id, workspace_id)
);
CREATE UNIQUE INDEX IF NOT EXISTS contas_cobrancas_etapa_uq
  ON contas_cobrancas (tenant_id, workspace_id, documento_id, etapa, canal) WHERE etapa <> 'manual' AND deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS contas_cobrancas_lista_idx ON contas_cobrancas (tenant_id, workspace_id, created_at, id) WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS contas_cobrancas_documento_idx ON contas_cobrancas (tenant_id, workspace_id, documento_id) WHERE deleted_at IS NULL;
SELECT nucleo_aplicar_padrao('contas_cobrancas');

-- Papeis de banco: API (erp_app) e worker (erp_worker: recorrencia, vencimento, cobranca e webhook pix-boleto).
GRANT SELECT, INSERT, UPDATE ON contas_recorrencias, contas_documentos, contas_baixas, contas_reguas, contas_cobrancas TO erp_app;
GRANT SELECT, INSERT, UPDATE ON contas_recorrencias, contas_documentos, contas_baixas, contas_cobrancas TO erp_worker;
GRANT SELECT ON contas_reguas TO erp_worker;
