/**
 * Porta da fila de jobs do modulo (N12): grava a intencao na outbox na mesma transacao do caso de uso.
 * `disponivelEm` (ISO) agenda o job para o futuro; null roda assim que o worker reclamar.
 */
export interface FilaJobs {
  enfileirar(tipo: string, payload: Record<string, unknown>, disponivelEm?: string | null): Promise<string>;
}

/** Tipos de job proprios do modulo (handler com o mesmo nome em modules/contas/worker/index.ts). */
export const JOBS = {
  cobrar: 'contas.cobrar',
  verificarVencimento: 'contas.verificar_vencimento',
  gerarRecorrencia: 'contas.gerar_recorrencia',
} as const;

/** Inicio do dia em UTC para uma data AAAA-MM-DD (instante em que o job fica disponivel). */
export const inicioDoDia = (data: string, hora = '00:00:00'): string => `${data}T${hora}Z`;
