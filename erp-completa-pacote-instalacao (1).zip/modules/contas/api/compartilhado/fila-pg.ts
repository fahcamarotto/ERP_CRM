/** Adaptador Postgres da porta FilaJobs: INSERT na outbox do nucleo (job proprio do modulo, CONTRATOS 6). */
import type pg from 'pg';
import type { FilaJobs } from './fila.ts';

export class FilaOutboxPg implements FilaJobs {
  constructor(private readonly c: pg.PoolClient) {}
  async enfileirar(tipo: string, payload: Record<string, unknown>, disponivelEm: string | null = null): Promise<string> {
    const r = await this.c.query(
      `INSERT INTO outbox (tipo, payload, disponivel_em) VALUES ($1, $2, coalesce($3::timestamptz, now())) RETURNING id`,
      [tipo, JSON.stringify(payload), disponivelEm],
    );
    return r.rows[0].id as string;
  }
}
