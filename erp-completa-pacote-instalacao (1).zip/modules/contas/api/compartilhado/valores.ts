/**
 * Objetos de valor compartilhados pelos agregados de Contas.
 * Centavos: inteiro seguro, nunca float. DataIso: AAAA-MM-DD valida no calendario.
 */
import { erroDe, fail, ok, type Result } from './result.ts';

/** Maior valor aceito (9 trilhoes na unidade da moeda): abaixo de Number.MAX_SAFE_INTEGER. */
export const MAX_CENTAVOS = 900_000_000_000_000;

export class Centavos {
  private constructor(readonly valor: number) {}
  /** Inteiro em centavos; `positivo` exige maior que zero, senao aceita zero. */
  static tryCreate(bruto: unknown, campo: string, positivo = true): Result<Centavos> {
    if (typeof bruto !== 'number' || !Number.isSafeInteger(bruto)) return fail(erroDe('valor_invalido', 'Valor deve ser inteiro em centavos', campo));
    if (positivo ? bruto <= 0 : bruto < 0) return fail(erroDe('valor_invalido', positivo ? 'Valor deve ser maior que zero' : 'Valor nao pode ser negativo', campo));
    if (bruto > MAX_CENTAVOS) return fail(erroDe('valor_invalido', 'Valor acima do limite', campo));
    return ok(new Centavos(bruto));
  }
  static create(bruto: number, campo = 'valor_centavos', positivo = true): Centavos {
    const r = Centavos.tryCreate(bruto, campo, positivo);
    if (!r.ok) throw new Error(r.erros[0]!.mensagem);
    return r.valor;
  }
}

export class Moeda {
  private constructor(readonly codigo: string) {}
  static tryCreate(bruto: unknown): Result<Moeda> {
    const m = typeof bruto === 'string' ? bruto.trim().toUpperCase() : '';
    return /^[A-Z]{3}$/.test(m) ? ok(new Moeda(m)) : fail(erroDe('moeda_invalida', 'Moeda em ISO 4217 (BRL, USD, EUR)', 'moeda'));
  }
  static create(bruto: string): Moeda {
    const r = Moeda.tryCreate(bruto);
    if (!r.ok) throw new Error(r.erros[0]!.mensagem);
    return r.valor;
  }
}

export class DataIso {
  private constructor(readonly valor: string) {}
  static tryCreate(bruto: unknown, campo = 'data'): Result<DataIso> {
    const v = typeof bruto === 'string' ? bruto.trim().slice(0, 10) : '';
    if (!/^\d{4}-\d{2}-\d{2}$/.test(v)) return fail(erroDe('data_invalida', 'Data deve ser AAAA-MM-DD', campo));
    const [a, m, d] = v.split('-').map(Number);
    const dt = new Date(Date.UTC(a!, m! - 1, d!));
    if (dt.getUTCFullYear() !== a || dt.getUTCMonth() !== m! - 1 || dt.getUTCDate() !== d) return fail(erroDe('data_invalida', 'Data inexistente no calendario', campo));
    return ok(new DataIso(v));
  }
  static create(bruto: string, campo = 'data'): DataIso {
    const r = DataIso.tryCreate(bruto, campo);
    if (!r.ok) throw new Error(r.erros[0]!.mensagem);
    return r.valor;
  }
}

/** Data de hoje (UTC) em AAAA-MM-DD. */
export const hojeIso = (): string => new Date().toISOString().slice(0, 10);

/** Soma dias a uma data AAAA-MM-DD. */
export function somarDias(data: string, dias: number): string {
  const d = new Date(`${data}T00:00:00Z`);
  d.setUTCDate(d.getUTCDate() + dias);
  return d.toISOString().slice(0, 10);
}

/** Diferenca em dias (b - a). */
export function diasEntre(a: string, b: string): number {
  return Math.round((Date.parse(`${b}T00:00:00Z`) - Date.parse(`${a}T00:00:00Z`)) / 86_400_000);
}

/** Soma meses mantendo o dia (1 a 28, sempre existe em todo mes). */
export function somarMeses(data: string, meses: number, dia: number): string {
  const [a, m] = data.split('-').map(Number);
  const d = new Date(Date.UTC(a!, m! - 1 + meses, dia));
  return d.toISOString().slice(0, 10);
}
