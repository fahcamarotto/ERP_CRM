/**
 * Agregado Recorrencia (M5.3): gera fatura ou conta a pagar mensal, trimestral ou anual por job.
 * `proxima_em` e o vencimento do proximo documento; o job roda `antecedencia_dias` antes.
 * Imutavel: toda mudanca devolve um clone novo.
 */
import { randomUUID } from 'node:crypto';
import { erroDe, fail, ok, type ErroDominio, type Result } from '../../compartilhado/result.ts';
import { Centavos, DataIso, Moeda, somarDias, somarMeses } from '../../compartilhado/valores.ts';

export const FREQUENCIAS = ['mensal', 'trimestral', 'anual'] as const;
export type Frequencia = (typeof FREQUENCIAS)[number];
export const MESES: Record<Frequencia, number> = { mensal: 1, trimestral: 3, anual: 12 };

export const TIPOS_RECORRENCIA = ['fatura', 'conta_pagar'] as const;
export type TipoRecorrencia = (typeof TIPOS_RECORRENCIA)[number];

export const ESTADOS_RECORRENCIA = ['ativa', 'pausada', 'encerrada'] as const;
export type EstadoRecorrencia = (typeof ESTADOS_RECORRENCIA)[number];

export const TRANSICOES_RECORRENCIA: Record<EstadoRecorrencia, EstadoRecorrencia[]> = {
  ativa: ['pausada', 'encerrada'],
  pausada: ['ativa', 'encerrada'],
  encerrada: [],
};

export interface DadosRecorrencia {
  tipo: TipoRecorrencia;
  parceiro_id: string;
  descricao: string;
  valor_centavos: number;
  moeda?: string | null;
  frequencia: Frequencia;
  dia_vencimento: number;
  antecedencia_dias?: number | null;
  inicio: string;
  fim?: string | null;
  categoria_id?: string | null;
  centro_custo_id?: string | null;
  conta_financeira_id?: string | null;
}

export interface RecorrenciaDados {
  id: string;
  tipo: TipoRecorrencia;
  parceiro_id: string;
  descricao: string;
  valor_centavos: number;
  moeda: string;
  frequencia: Frequencia;
  dia_vencimento: number;
  antecedencia_dias: number;
  inicio: string;
  fim: string | null;
  proxima_em: string | null;
  estado: EstadoRecorrencia;
  categoria_id: string | null;
  centro_custo_id: string | null;
  conta_financeira_id: string | null;
  gerados: number;
  ultimo_documento_id: string | null;
}

const t = (v?: string | null) => (v ?? '').trim() || null;

/** Primeira data com o dia de vencimento a partir de `inicio` (inclusive). */
export function primeiraData(inicio: string, dia: number): string {
  const [a, m, d] = inicio.split('-').map(Number);
  return d! <= dia ? somarMeses(`${a}-${String(m).padStart(2, '0')}-01`, 0, dia) : somarMeses(`${a}-${String(m).padStart(2, '0')}-01`, 1, dia);
}

function validar(d: RecorrenciaDados): ErroDominio[] {
  const e: ErroDominio[] = [];
  if (!TIPOS_RECORRENCIA.includes(d.tipo)) e.push(erroDe('tipo_invalido', 'Tipo deve ser fatura ou conta_pagar', 'tipo'));
  if (!d.parceiro_id) e.push(erroDe('parceiro_obrigatorio', 'Informe o parceiro', 'parceiro_id'));
  if (d.descricao.length < 2 || d.descricao.length > 200) e.push(erroDe('descricao_invalida', 'Descricao de 2 a 200 caracteres', 'descricao'));
  const v = Centavos.tryCreate(d.valor_centavos, 'valor_centavos');
  if (!v.ok) e.push(...v.erros);
  const m = Moeda.tryCreate(d.moeda);
  if (!m.ok) e.push(...m.erros);
  if (!FREQUENCIAS.includes(d.frequencia)) e.push(erroDe('frequencia_invalida', 'Frequencia deve ser mensal, trimestral ou anual', 'frequencia'));
  if (!Number.isInteger(d.dia_vencimento) || d.dia_vencimento < 1 || d.dia_vencimento > 28) e.push(erroDe('dia_invalido', 'Dia de vencimento de 1 a 28', 'dia_vencimento'));
  if (!Number.isInteger(d.antecedencia_dias) || d.antecedencia_dias < 0 || d.antecedencia_dias > 60) e.push(erroDe('antecedencia_invalida', 'Antecedencia de 0 a 60 dias', 'antecedencia_dias'));
  const ri = DataIso.tryCreate(d.inicio, 'inicio');
  if (!ri.ok) e.push(...ri.erros);
  if (d.fim) {
    const rf = DataIso.tryCreate(d.fim, 'fim');
    if (!rf.ok) e.push(...rf.erros);
    else if (ri.ok && d.fim < d.inicio) e.push(erroDe('fim_invalido', 'Fim antes do inicio', 'fim'));
  }
  return e;
}

export class Recorrencia {
  private constructor(private readonly d: RecorrenciaDados) {}

  static tryCreate(e: DadosRecorrencia, id: string = randomUUID()): Result<Recorrencia> {
    const d: RecorrenciaDados = {
      id, tipo: e.tipo, parceiro_id: t(e.parceiro_id) ?? '', descricao: (e.descricao ?? '').trim(), valor_centavos: e.valor_centavos,
      moeda: (t(e.moeda) ?? 'BRL').toUpperCase(), frequencia: e.frequencia, dia_vencimento: Number(e.dia_vencimento),
      antecedencia_dias: e.antecedencia_dias ?? 5, inicio: t(e.inicio) ?? '', fim: t(e.fim), proxima_em: null, estado: 'ativa',
      categoria_id: t(e.categoria_id), centro_custo_id: t(e.centro_custo_id), conta_financeira_id: t(e.conta_financeira_id),
      gerados: 0, ultimo_documento_id: null,
    };
    const erros = validar(d);
    if (erros.length) return fail(...erros);
    d.proxima_em = primeiraData(d.inicio, d.dia_vencimento);
    if (d.fim && d.proxima_em > d.fim) return fail(erroDe('fim_invalido', 'Nenhum vencimento entre inicio e fim', 'fim'));
    return ok(new Recorrencia(d));
  }

  static create(e: DadosRecorrencia, id?: string): Recorrencia {
    const r = Recorrencia.tryCreate(e, id);
    if (!r.ok) throw new Error(r.erros.map((x) => x.mensagem).join('; '));
    return r.valor;
  }

  static reidratar(d: RecorrenciaDados): Recorrencia { return new Recorrencia({ ...d }); }

  get id(): string { return this.d.id; }
  get estado(): EstadoRecorrencia { return this.d.estado; }
  get proximaEm(): string | null { return this.d.proxima_em; }

  /** Dia em que o job de geracao fica disponivel: proxima_em menos a antecedencia. */
  get geracaoEm(): string | null { return this.d.proxima_em ? somarDias(this.d.proxima_em, -this.d.antecedencia_dias) : null; }

  editar(e: Partial<Omit<DadosRecorrencia, 'tipo' | 'inicio'>>): Result<Recorrencia> {
    if (this.d.estado === 'encerrada') return fail(erroDe('transicao_invalida', 'Recorrencia encerrada nao pode ser editada', 'estado'));
    const tem = (k: keyof DadosRecorrencia) => (e as Record<string, unknown>)[k] !== undefined;
    const n: RecorrenciaDados = {
      ...this.d,
      parceiro_id: tem('parceiro_id') ? t(e.parceiro_id) ?? '' : this.d.parceiro_id,
      descricao: tem('descricao') ? (e.descricao ?? '').trim() : this.d.descricao,
      valor_centavos: tem('valor_centavos') ? e.valor_centavos! : this.d.valor_centavos,
      moeda: tem('moeda') ? (t(e.moeda) ?? 'BRL').toUpperCase() : this.d.moeda,
      frequencia: tem('frequencia') ? e.frequencia! : this.d.frequencia,
      dia_vencimento: tem('dia_vencimento') ? Number(e.dia_vencimento) : this.d.dia_vencimento,
      antecedencia_dias: tem('antecedencia_dias') ? e.antecedencia_dias ?? 5 : this.d.antecedencia_dias,
      fim: tem('fim') ? t(e.fim) : this.d.fim,
      categoria_id: tem('categoria_id') ? t(e.categoria_id) : this.d.categoria_id,
      centro_custo_id: tem('centro_custo_id') ? t(e.centro_custo_id) : this.d.centro_custo_id,
      conta_financeira_id: tem('conta_financeira_id') ? t(e.conta_financeira_id) : this.d.conta_financeira_id,
    };
    const erros = validar(n);
    if (erros.length) return fail(...erros);
    if (n.proxima_em && n.dia_vencimento !== this.d.dia_vencimento) n.proxima_em = primeiraData(`${n.proxima_em.slice(0, 7)}-01`, n.dia_vencimento);
    return ok(new Recorrencia(n));
  }

  mudarEstado(novo: EstadoRecorrencia): Result<Recorrencia> {
    if (!ESTADOS_RECORRENCIA.includes(novo)) return fail(erroDe('estado_invalido', 'Estado invalido', 'estado'));
    if (!TRANSICOES_RECORRENCIA[this.d.estado].includes(novo)) {
      return fail(erroDe('transicao_invalida', `Recorrencia ${this.d.estado} nao pode ir para ${novo}`, 'estado', { permitidas: TRANSICOES_RECORRENCIA[this.d.estado] }));
    }
    return ok(new Recorrencia({ ...this.d, estado: novo }));
  }

  /** Dados do documento da competencia atual (proxima_em). */
  emissao(hoje: string): { tipo: TipoRecorrencia; parceiro_id: string; descricao: string; valor_centavos: number; moeda: string; emissao: string; vencimento: string; condicao_pagamento: 'personalizada'; competencia: string; recorrencia_id: string; categoria_id: string | null; centro_custo_id: string | null; conta_financeira_id: string | null } {
    const venc = this.d.proxima_em!;
    return {
      tipo: this.d.tipo, parceiro_id: this.d.parceiro_id, descricao: this.d.descricao, valor_centavos: this.d.valor_centavos, moeda: this.d.moeda,
      emissao: hoje < venc ? hoje : venc, vencimento: venc, condicao_pagamento: 'personalizada', competencia: venc, recorrencia_id: this.d.id,
      categoria_id: this.d.categoria_id, centro_custo_id: this.d.centro_custo_id, conta_financeira_id: this.d.conta_financeira_id,
    };
  }

  /** Depois de gerar o documento da competencia: avanca a proxima data e encerra ao passar do fim. */
  avancar(documentoId: string): Result<Recorrencia> {
    if (this.d.estado !== 'ativa' || !this.d.proxima_em) return fail(erroDe('transicao_invalida', `Recorrencia ${this.d.estado} nao gera documento`, 'estado'));
    const proxima = somarMeses(this.d.proxima_em, MESES[this.d.frequencia], this.d.dia_vencimento);
    const acabou = !!this.d.fim && proxima > this.d.fim;
    return ok(new Recorrencia({
      ...this.d, gerados: this.d.gerados + 1, ultimo_documento_id: documentoId,
      proxima_em: acabou ? null : proxima, estado: acabou ? 'encerrada' : 'ativa',
    }));
  }

  paraDados(): RecorrenciaDados { return { ...this.d }; }
}
