/** Portas do agregado Recorrencia. */
import type { Recorrencia } from './recorrencia.ts';

export interface ObterRecorrencia {
  obterPorId(id: string): Promise<Recorrencia | null>;
}

export interface GravarRecorrencia {
  inserir(r: Recorrencia): Promise<void>;
  atualizar(r: Recorrencia): Promise<void>;
}
