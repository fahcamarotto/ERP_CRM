/**
 * ConfigurarRecorrencia (M5.6), EditarRecorrencia, MudarEstadoRecorrencia e GerarDocumentoRecorrente
 * (job `contas.gerar_recorrencia`, M5.3). A geracao emite o documento pelo EmitirDocumento com a chave
 * `recorrencia:<id>:<competencia>`: repetir o job nunca duplica o documento da competencia.
 */
import type { ContextoCaso } from '../../compartilhado/efeitos.ts';
import { JOBS, inicioDoDia, type FilaJobs } from '../../compartilhado/fila.ts';
import { erroDe, fail, ok, type ErroDominio, type Result } from '../../compartilhado/result.ts';
import { hojeIso } from '../../compartilhado/valores.ts';
import type { ConsultarReferenciasDocumento } from '../../documento/model/portas.ts';
import type { EmitirDocumento } from '../../documento/use-case/emitir-documento.ts';
import { Recorrencia, type DadosRecorrencia, type EstadoRecorrencia, type RecorrenciaDados } from '../model/recorrencia.ts';
import type { GravarRecorrencia, ObterRecorrencia } from '../model/portas.ts';

type Deps = { repo: ObterRecorrencia & GravarRecorrencia; refs: ConsultarReferenciasDocumento; fila: FilaJobs; hoje?: () => string };

async function conferir(refs: ConsultarReferenciasDocumento, d: RecorrenciaDados, a?: RecorrenciaDados): Promise<ErroDominio[]> {
  const e: ErroDominio[] = [];
  const mudou = (k: keyof RecorrenciaDados) => !a || a[k] !== d[k];
  if (mudou('parceiro_id') && !(await refs.parceiroAtivo(d.parceiro_id))) e.push(erroDe('parceiro_invalido', 'Parceiro nao encontrado ou arquivado', 'parceiro_id'));
  if (d.conta_financeira_id && mudou('conta_financeira_id') && !(await refs.contaFinanceiraAtiva(d.conta_financeira_id))) e.push(erroDe('conta_invalida', 'Conta financeira nao encontrada ou inativa', 'conta_financeira_id'));
  if (d.categoria_id && mudou('categoria_id') && !(await refs.categoriaAtiva(d.categoria_id))) e.push(erroDe('categoria_invalida', 'Categoria nao encontrada ou inativa', 'categoria_id'));
  if (d.centro_custo_id && mudou('centro_custo_id') && !(await refs.centroAtivo(d.centro_custo_id))) e.push(erroDe('centro_invalido', 'Centro de custo nao encontrado ou inativo', 'centro_custo_id'));
  return e;
}

/** Agenda o job de geracao da competencia atual (antecedencia antes do vencimento; se ja passou, agora). */
async function agendar(fila: FilaJobs, r: Recorrencia, hoje: string): Promise<string | null> {
  if (r.estado !== 'ativa' || !r.proximaEm || !r.geracaoEm) return null;
  const quando = r.geracaoEm <= hoje ? null : inicioDoDia(r.geracaoEm, '09:00:00');
  return fila.enfileirar(JOBS.gerarRecorrencia, { recorrencia_id: r.id, competencia: r.proximaEm }, quando);
}

export class ConfigurarRecorrencia {
  constructor(private readonly deps: Deps) {}
  async execute(ctx: ContextoCaso, e: DadosRecorrencia, id?: string): Promise<Result<{ id: string }>> {
    const r = Recorrencia.tryCreate(e, id);
    if (!r.ok) return r;
    const erros = await conferir(this.deps.refs, r.valor.paraDados());
    if (erros.length) return fail(...erros);
    await this.deps.repo.inserir(r.valor);
    const d = r.valor.paraDados();
    await agendar(this.deps.fila, r.valor, (this.deps.hoje ?? hojeIso)());
    await ctx.efeitos.auditar('recorrencia.configurar', 'contas_recorrencias', d.id, undefined, d);
    return ok({ id: d.id });
  }
}

export class EditarRecorrencia {
  constructor(private readonly deps: Deps) {}
  async execute(ctx: ContextoCaso, e: { id: string } & Partial<DadosRecorrencia>): Promise<Result<void>> {
    const { id, ...mud } = e;
    const atual = await this.deps.repo.obterPorId(id);
    if (!atual) return fail(erroDe('nao_encontrado', 'Recorrencia nao encontrada'));
    const r = atual.editar(mud);
    if (!r.ok) return r;
    const antes = atual.paraDados();
    const depois = r.valor.paraDados();
    const erros = await conferir(this.deps.refs, depois, antes);
    if (erros.length) return fail(...erros);
    await this.deps.repo.atualizar(r.valor);
    if (depois.proxima_em !== antes.proxima_em || depois.antecedencia_dias !== antes.antecedencia_dias) await agendar(this.deps.fila, r.valor, (this.deps.hoje ?? hojeIso)());
    await ctx.efeitos.historico('contas_recorrencias', id, antes as unknown as Record<string, unknown>, depois as unknown as Record<string, unknown>);
    await ctx.efeitos.auditar('recorrencia.editar', 'contas_recorrencias', id, antes, depois);
    return ok(undefined);
  }
}

export class MudarEstadoRecorrencia {
  constructor(private readonly deps: Deps) {}
  async execute(ctx: ContextoCaso, e: { id: string; estado: EstadoRecorrencia }): Promise<Result<void>> {
    const atual = await this.deps.repo.obterPorId(e.id);
    if (!atual) return fail(erroDe('nao_encontrado', 'Recorrencia nao encontrada'));
    const r = atual.mudarEstado(e.estado);
    if (!r.ok) return r;
    await this.deps.repo.atualizar(r.valor);
    if (e.estado === 'ativa') await agendar(this.deps.fila, r.valor, (this.deps.hoje ?? hojeIso)());
    await ctx.efeitos.historico('contas_recorrencias', e.id, { estado: atual.estado }, { estado: r.valor.estado });
    await ctx.efeitos.auditar('recorrencia.mudar_estado', 'contas_recorrencias', e.id, { estado: atual.estado }, { estado: r.valor.estado });
    return ok(undefined);
  }
}

export class GerarDocumentoRecorrente {
  constructor(private readonly deps: Deps & { emitir: EmitirDocumento }) {}
  /** `competencia` vem do job: se a recorrencia ja avancou (job velho ou repetido), nao gera nada. */
  async execute(ctx: ContextoCaso, e: { recorrencia_id: string; competencia?: string | null }): Promise<Result<{ documento_id: string | null; repetido: boolean }>> {
    const atual = await this.deps.repo.obterPorId(e.recorrencia_id);
    if (!atual) return fail(erroDe('nao_encontrado', 'Recorrencia nao encontrada'));
    if (atual.estado !== 'ativa' || !atual.proximaEm) {
      if (e.competencia) return ok({ documento_id: null, repetido: true });
      return fail(erroDe('transicao_invalida', `Recorrencia ${atual.estado} nao gera documento`, 'estado'));
    }
    if (e.competencia && e.competencia !== atual.proximaEm) return ok({ documento_id: null, repetido: true });
    const hoje = (this.deps.hoje ?? hojeIso)();
    const comp = atual.proximaEm;
    const emitido = await this.deps.emitir.execute(ctx, { ...atual.emissao(hoje), chave_idempotencia: `recorrencia:${atual.id}:${comp}` });
    if (!emitido.ok) return emitido;
    const r = atual.avancar(emitido.valor.id);
    if (!r.ok) return r;
    await this.deps.repo.atualizar(r.valor);
    await agendar(this.deps.fila, r.valor, hoje);
    await ctx.efeitos.historico('contas_recorrencias', atual.id, { proxima_em: comp, gerados: atual.paraDados().gerados }, { proxima_em: r.valor.proximaEm, gerados: r.valor.paraDados().gerados });
    await ctx.efeitos.auditar('recorrencia.gerar', 'contas_recorrencias', atual.id, { proxima_em: comp }, { proxima_em: r.valor.proximaEm, documento_id: emitido.valor.id });
    return ok({ documento_id: emitido.valor.id, repetido: emitido.valor.repetido });
  }
}
