/** Rotas REST da Recorrencia fora das tools: ficha, edicao, estado e gerar agora. */
import { esquemaErro, requer, type FastifyInstance } from '@erp/api/sdk';
import { naTransacao, naoEncontrado } from '../borda.ts';
import { exigirOk } from '../compartilhado/result.ts';
import { estadosRecorrencia, propsRecorrencia, uuid } from '../esquemas.ts';
import type { DadosRecorrencia, EstadoRecorrencia } from './model/recorrencia.ts';
import { obterRecorrencia } from './query/recorrencias.ts';

const tags = ['contas'];
const paramId = { type: 'object', required: ['id'], properties: { id: uuid } } as const;
const erros = { 400: esquemaErro, 403: esquemaErro, 404: esquemaErro, 409: esquemaErro };
const { tipo: _t, inicio: _i, ...propsEdicao } = propsRecorrencia;

export function rotasRecorrencia(app: FastifyInstance): void {
  app.get<{ Params: { id: string } }>('/recorrencias/:id', {
    preHandler: requer('contas.ver'),
    schema: { tags, summary: 'Ficha da recorrencia com os documentos gerados', params: paramId, response: { 404: esquemaErro } },
  }, (req) => naTransacao(req, async (_, __, c) => (await obterRecorrencia(c, req.params.id)) ?? Promise.reject(naoEncontrado('Recorrencia nao encontrada'))));

  app.patch<{ Params: { id: string }; Body: Partial<DadosRecorrencia> }>('/recorrencias/:id', {
    preHandler: requer('contas.editar'),
    schema: { tags, summary: 'Edita recorrencia (valor, dia, frequencia, fim, classificacao)', params: paramId,
      body: { type: 'object', additionalProperties: false, properties: propsEdicao }, response: erros },
  }, (req) => naTransacao(req, async (casos, ctx, c) => {
    exigirOk(await casos.editarRecorrencia.execute(ctx, { ...req.body, id: req.params.id }));
    return obterRecorrencia(c, req.params.id);
  }));

  app.post<{ Params: { id: string }; Body: { estado: EstadoRecorrencia } }>('/recorrencias/:id/estado', {
    preHandler: requer('contas.editar'),
    schema: { tags, summary: 'Pausa, reativa ou encerra a recorrencia', params: paramId,
      body: { type: 'object', additionalProperties: false, required: ['estado'], properties: { estado: estadosRecorrencia } }, response: erros },
  }, (req) => naTransacao(req, async (casos, ctx, c) => {
    exigirOk(await casos.mudarEstadoRecorrencia.execute(ctx, { id: req.params.id, estado: req.body.estado }));
    return obterRecorrencia(c, req.params.id);
  }));

  app.post<{ Params: { id: string } }>('/recorrencias/:id/gerar', {
    preHandler: requer('contas.criar'),
    schema: { tags, summary: 'Gera agora o documento da proxima competencia (mesmo caso de uso do job, idempotente por competencia)', params: paramId, response: erros },
  }, (req) => naTransacao(req, async (casos, ctx, c) => {
    const r = exigirOk(await casos.gerarDocumentoRecorrente.execute(ctx, { recorrencia_id: req.params.id }));
    return { ...r, recorrencia: await obterRecorrencia(c, req.params.id) };
  }));
}
