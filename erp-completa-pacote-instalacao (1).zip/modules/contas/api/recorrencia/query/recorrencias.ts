/** Consultas de leitura da Recorrencia: lista com parceiro e ficha com os documentos gerados. */
import type pg from 'pg';
import { decodificarCursor, pagina } from '../../compartilhado/cursor.ts';

const RESUMO = `r.id, r.tipo, r.parceiro_id, coalesce(p.nome_fantasia, p.nome) AS parceiro_nome, r.descricao, r.valor_centavos::float8 AS valor_centavos,
  r.moeda, r.frequencia, r.dia_vencimento, r.antecedencia_dias, to_char(r.inicio, 'YYYY-MM-DD') AS inicio, to_char(r.fim, 'YYYY-MM-DD') AS fim,
  to_char(r.proxima_em, 'YYYY-MM-DD') AS proxima_em, r.estado, r.gerados, r.ultimo_documento_id, r.categoria_id, r.centro_custo_id,
  r.conta_financeira_id, r.created_at, r.updated_at`;

export async function listarRecorrencias(c: pg.PoolClient, f: { estado?: string; tipo?: string; limite?: number; cursor?: string }) {
  const lim = Math.min(Math.max(f.limite ?? 50, 1), 200);
  const cur = decodificarCursor(f.cursor);
  const r = await c.query(
    `SELECT ${RESUMO} FROM contas_recorrencias r LEFT JOIN cadastros_parceiros p ON p.id = r.parceiro_id
     WHERE r.deleted_at IS NULL AND ($1::text IS NULL OR r.estado = $1) AND ($2::text IS NULL OR r.tipo = $2)
       AND ($3::timestamptz IS NULL OR (r.created_at, r.id) > ($3::timestamptz, $4::uuid))
     ORDER BY r.created_at, r.id LIMIT $5`,
    [f.estado ?? null, f.tipo ?? null, cur?.[0] ?? null, cur?.[1] ?? null, lim + 1],
  );
  return pagina(r.rows, lim);
}

export async function obterRecorrencia(c: pg.PoolClient, id: string) {
  const r = await c.query(
    `SELECT ${RESUMO},
       coalesce((SELECT json_agg(json_build_object('id', d.id, 'numero', d.numero, 'vencimento', to_char(d.vencimento, 'YYYY-MM-DD'),
                  'saldo_centavos', d.saldo_centavos, 'estado', d.estado) ORDER BY d.vencimento DESC)
                 FROM contas_documentos d WHERE d.recorrencia_id = r.id AND d.deleted_at IS NULL), '[]') AS documentos
     FROM contas_recorrencias r LEFT JOIN cadastros_parceiros p ON p.id = r.parceiro_id WHERE r.id = $1 AND r.deleted_at IS NULL`, [id]);
  return r.rows[0] ?? null;
}
