/** Adaptador Postgres das portas da Recorrencia (RLS restringe ao workspace da sessao ou do job). */
import type pg from 'pg';
import { Recorrencia, type RecorrenciaDados } from '../model/recorrencia.ts';
import type { GravarRecorrencia, ObterRecorrencia } from '../model/portas.ts';

export class RecorrenciaRepoPg implements ObterRecorrencia, GravarRecorrencia {
  constructor(private readonly c: pg.PoolClient) {}

  async obterPorId(id: string): Promise<Recorrencia | null> {
    const r = await this.c.query(
      `SELECT id, tipo, parceiro_id, descricao, valor_centavos::float8 AS valor_centavos, moeda, frequencia, dia_vencimento, antecedencia_dias,
         to_char(inicio, 'YYYY-MM-DD') AS inicio, to_char(fim, 'YYYY-MM-DD') AS fim, to_char(proxima_em, 'YYYY-MM-DD') AS proxima_em, estado,
         categoria_id, centro_custo_id, conta_financeira_id, gerados, ultimo_documento_id
       FROM contas_recorrencias WHERE id = $1 AND deleted_at IS NULL`, [id]);
    return r.rows[0] ? Recorrencia.reidratar(r.rows[0] as RecorrenciaDados) : null;
  }

  async inserir(rec: Recorrencia): Promise<void> {
    const d = rec.paraDados();
    await this.c.query(
      `INSERT INTO contas_recorrencias (id, tipo, parceiro_id, descricao, valor_centavos, moeda, frequencia, dia_vencimento, antecedencia_dias,
         inicio, fim, proxima_em, estado, categoria_id, centro_custo_id, conta_financeira_id, gerados, ultimo_documento_id, creator_id)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, nucleo_usuario_atual())`,
      [d.id, d.tipo, d.parceiro_id, d.descricao, d.valor_centavos, d.moeda, d.frequencia, d.dia_vencimento, d.antecedencia_dias, d.inicio, d.fim,
        d.proxima_em, d.estado, d.categoria_id, d.centro_custo_id, d.conta_financeira_id, d.gerados, d.ultimo_documento_id],
    );
  }

  async atualizar(rec: Recorrencia): Promise<void> {
    const d = rec.paraDados();
    await this.c.query(
      `UPDATE contas_recorrencias SET parceiro_id = $2, descricao = $3, valor_centavos = $4, moeda = $5, frequencia = $6, dia_vencimento = $7,
         antecedencia_dias = $8, fim = $9, proxima_em = $10, estado = $11, categoria_id = $12, centro_custo_id = $13, conta_financeira_id = $14,
         gerados = $15, ultimo_documento_id = $16 WHERE id = $1 AND deleted_at IS NULL`,
      [d.id, d.parceiro_id, d.descricao, d.valor_centavos, d.moeda, d.frequencia, d.dia_vencimento, d.antecedencia_dias, d.fim, d.proxima_em,
        d.estado, d.categoria_id, d.centro_custo_id, d.conta_financeira_id, d.gerados, d.ultimo_documento_id],
    );
  }
}
