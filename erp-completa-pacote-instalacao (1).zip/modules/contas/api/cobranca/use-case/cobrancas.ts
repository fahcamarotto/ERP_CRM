/**
 * GerarCobranca (M5.6), ProcessarCobranca (job `contas.cobrar`, M5.4), ConfigurarRegua (M5.4) e
 * ConfirmarPagamento (webhook Pix e boleto, M5.5). Nenhum envio acontece na request: tudo pela fila.
 */
import type { ContextoCaso } from '../../compartilhado/efeitos.ts';
import { JOBS, type FilaJobs } from '../../compartilhado/fila.ts';
import { erroDe, fail, ok, okVazio, type Result } from '../../compartilhado/result.ts';
import { Centavos, DataIso } from '../../compartilhado/valores.ts';
import type { ObterDocumento } from '../../documento/model/portas.ts';
import type { Baixar } from '../../documento/use-case/baixar.ts';
import { Cobranca, Regua, type EtapaRegua } from '../model/cobranca.ts';
import type { ContatoParceiro, GravarCobranca, GravarRegua, LerRegua, Mensageiro, ObterCobranca } from '../model/portas.ts';

/** Slug do conector do nucleo por canal (CONTRATOS 7.1.14). */
export const CONECTOR_DO_CANAL = { email: 'resend', whatsapp: 'whatsapp', pix: 'pix-boleto', boleto: 'pix-boleto' } as const;

export class GerarCobranca {
  constructor(private readonly deps: { documentos: ObterDocumento; cobrancas: GravarCobranca; fila: FilaJobs }) {}
  async execute(ctx: ContextoCaso, e: { documento_id: string; canal: string }): Promise<Result<{ cobranca_id: string; job_id: string }>> {
    const doc = await this.deps.documentos.obterPorId(e.documento_id);
    if (!doc) return fail(erroDe('nao_encontrado', 'Documento nao encontrado'));
    if (!doc.aberto) return fail(erroDe('transicao_invalida', `Documento ${doc.estado} nao aceita cobranca`, 'estado'));
    if (doc.natureza !== 'receber') return fail(erroDe('tipo_invalido', 'Cobranca so para documento a receber (fatura)', 'documento_id'));
    const r = Cobranca.tryCreate({ documento_id: doc.id, canal: e.canal });
    if (!r.ok) return r;
    const jobId = await this.deps.fila.enfileirar(JOBS.cobrar, { cobranca_id: r.valor.id });
    const c = r.valor.comJob(jobId);
    await this.deps.cobrancas.inserir(c);
    await ctx.efeitos.auditar('cobranca.gerar', 'contas_cobrancas', c.id, undefined, c.paraDados());
    return ok({ cobranca_id: c.id, job_id: jobId });
  }
}

export interface DepsProcessar {
  cobrancas: ObterCobranca & GravarCobranca;
  documentos: ObterDocumento;
  contatos: ContatoParceiro;
  mensageiro: Mensageiro;
}

export class ProcessarCobranca {
  constructor(private readonly deps: DepsProcessar) {}
  async execute(ctx: ContextoCaso, e: { cobranca_id: string }): Promise<Result<{ estado: string }>> {
    const cob = await this.deps.cobrancas.obterPorId(e.cobranca_id);
    if (!cob) return fail(erroDe('nao_encontrado', 'Cobranca nao encontrada'));
    if (cob.estado !== 'agendada') return ok({ estado: cob.estado });
    const doc = await this.deps.documentos.obterPorId(cob.documentoId);
    const fechar = async (estado: Parameters<Cobranca['concluir']>[0], x: Parameters<Cobranca['concluir']>[1] = {}) => {
      const r = cob.concluir(estado, x);
      if (!r.ok) return r;
      await this.deps.cobrancas.atualizar(r.valor);
      await ctx.efeitos.auditar('cobranca.processar', 'contas_cobrancas', cob.id, { estado: 'agendada' }, { estado, destino: x.destino ?? null, erro: x.erro ?? null });
      return ok({ estado });
    };
    if (!doc || !doc.aberto) return fechar('cancelada', { erro: 'Documento quitado, cancelado ou removido' });
    const d = doc.paraDados();
    const contato = await this.deps.contatos.contato(d.parceiro_id);
    const valor = (d.saldo_centavos / 100).toFixed(2);
    const conector = await this.deps.mensageiro.estadoConector(CONECTOR_DO_CANAL[cob.canal]);
    if (cob.canal === 'email') {
      if (!contato?.email) return fechar('sem_contato', { erro: 'Parceiro sem email' });
      const emailId = await this.deps.mensageiro.email(contato.email, { nome: contato.nome, numero: d.numero, valor: `${d.moeda} ${valor}`, vencimento: d.vencimento });
      await ctx.efeitos.nota('contas_documentos', d.id, `Cobranca ${cob.paraDados().etapa} por email para ${contato.email}.`);
      return fechar('enviada', { destino: contato.email, referencia: emailId });
    }
    if (cob.canal === 'whatsapp') {
      if (!contato?.telefone) return fechar('sem_contato', { erro: 'Parceiro sem telefone' });
      return fechar('aguardando_conector', {
        destino: contato.telefone,
        erro: conector === 'ativo' ? 'Envio pelo WhatsApp aguarda a interface publicada de envio' : `Conector whatsapp ${conector ?? 'nao configurado'}`,
      });
    }
    // Pix e boleto: o provedor de pagamento gera a cobranca; sem conector ativo a cobranca fica aguardando.
    return fechar('aguardando_conector', {
      erro: conector === 'ativo' ? 'Geracao de Pix e boleto aguarda a interface publicada do provedor' : `Conector pix-boleto ${conector ?? 'nao configurado'}`,
    });
  }
}

export class ConfigurarRegua {
  constructor(private readonly deps: { reguas: LerRegua & GravarRegua }) {}
  async execute(ctx: ContextoCaso, e: { ativa?: boolean; etapas?: Partial<EtapaRegua>[] }): Promise<Result<void>> {
    const r = Regua.tryCreate(e);
    if (!r.ok) return r;
    const antes = await this.deps.reguas.regua();
    await this.deps.reguas.salvarRegua(r.valor);
    await ctx.efeitos.auditar('regua.configurar', 'contas_reguas', null, antes ? { ativa: antes.ativa, etapas: antes.etapas } : undefined, { ativa: r.valor.ativa, etapas: r.valor.etapas });
    return okVazio();
  }
}

/**
 * Corpo do webhook do provedor de pagamento (`webhook.recebido.pix-boleto`). Aceita os nomes comuns de
 * provedores: documento por id, numero ou referencia externa; valor em centavos ou decimal; id do evento.
 */
export interface PagamentoConfirmado { id_externo: string; documento_id: string | null; numero: string | null; valor_centavos: number | null; data: string | null; forma: 'pix' | 'boleto' }

export function lerPagamento(corpo: unknown, idRecebido: string): Result<PagamentoConfirmado> {
  const raiz = (corpo && typeof corpo === 'object' ? corpo : {}) as Record<string, unknown>;
  const dentro = [raiz.data, raiz.payment, raiz.pix, raiz.cobranca].find((x) => x && typeof x === 'object') as Record<string, unknown> | undefined;
  const f = { ...raiz, ...(dentro ?? {}) };
  const s = (...ks: string[]) => { for (const k of ks) { const v = f[k]; if (typeof v === 'string' && v.trim()) return v.trim(); if (typeof v === 'number') return String(v); } return null; };
  const documento = s('documento_id', 'external_reference', 'externalReference', 'reference', 'referencia');
  const numero = s('numero', 'invoice_number', 'seu_numero');
  const uuid = documento && /^[0-9a-f-]{36}$/i.test(documento) ? documento : null;
  let centavos: number | null = null;
  const vc = f.valor_centavos ?? f.amount_cents;
  if (typeof vc === 'number' && Number.isSafeInteger(vc)) centavos = vc;
  else {
    const v = s('valor', 'value', 'amount', 'valor_pago');
    if (v && /^\d+([.,]\d{1,2})?$/.test(v)) { const [i, dec = ''] = v.split(/[.,]/); centavos = Number(i) * 100 + Number(dec.padEnd(2, '0')); }
  }
  const data = (s('data_pagamento', 'paymentDate', 'pago_em', 'paid_at', 'horario') ?? '').slice(0, 10) || null;
  const forma = /boleto|bank_slip/i.test(s('forma', 'billingType', 'tipo', 'method') ?? '') ? 'boleto' : 'pix';
  const id = s('id', 'txid', 'endToEndId', 'event_id') ?? idRecebido;
  const status = (s('status', 'event', 'situacao') ?? 'pago').toLowerCase();
  if (!/(pago|paid|confirm|received|recebid|concluid|liquidad)/.test(status)) return fail(erroDe('evento_ignorado', `Status ${status} nao confirma pagamento`));
  if (!uuid && !numero) return fail(erroDe('documento_obrigatorio', 'Webhook sem documento_id, referencia ou numero'));
  if (centavos !== null && !Centavos.tryCreate(centavos, 'valor').ok) return fail(erroDe('valor_invalido', 'Valor do pagamento invalido'));
  if (data && !DataIso.tryCreate(data).ok) return fail(erroDe('data_invalida', 'Data do pagamento invalida'));
  return ok({ id_externo: `pix-boleto:${id}`, documento_id: uuid, numero, valor_centavos: centavos, data, forma });
}

export interface LocalizarDocumento { idPorNumero(numero: string): Promise<string | null> }

/** Baixa idempotente pelo id externo: o mesmo evento do provedor nunca baixa duas vezes. */
export class ConfirmarPagamento {
  constructor(private readonly deps: { baixar: Baixar; localizar: LocalizarDocumento; documentos: ObterDocumento }) {}
  async execute(ctx: ContextoCaso, p: PagamentoConfirmado): Promise<Result<{ baixa_id: string; repetido: boolean }>> {
    const id = p.documento_id ?? (p.numero ? await this.deps.localizar.idPorNumero(p.numero) : null);
    if (!id) return fail(erroDe('nao_encontrado', 'Documento do pagamento nao encontrado'));
    // Valor pago acima do saldo (pagamento em atraso): o saldo e amortizado e o excedente entra como juros.
    const doc = await this.deps.documentos.obterPorId(id);
    const saldo = doc?.saldoCentavos ?? 0;
    const excedente = p.valor_centavos !== null && doc?.aberto && p.valor_centavos > saldo ? p.valor_centavos - saldo : 0;
    const r = await this.deps.baixar.execute(ctx, {
      documento_id: id, valor_centavos: excedente ? saldo : p.valor_centavos, juros_centavos: excedente || null,
      data: p.data, forma: p.forma, id_externo: p.id_externo, origem: 'webhook',
    });
    if (!r.ok) return r;
    return ok({ baixa_id: r.valor.baixa_id, repetido: r.valor.repetido });
  }
}
