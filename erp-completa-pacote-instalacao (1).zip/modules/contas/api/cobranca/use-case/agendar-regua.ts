/**
 * Agenda a regua de cobranca de um documento a receber (M5.4): uma cobranca por etapa, cada uma com o
 * job `contas.cobrar` disponivel no dia da etapa (12:00 UTC, manha no Brasil). Etapa ja passada nao entra.
 */
import { JOBS, inicioDoDia, type FilaJobs } from '../../compartilhado/fila.ts';
import { somarDias } from '../../compartilhado/valores.ts';
import { Cobranca, REGUA_PADRAO, etapaRotulo, type Regua } from '../model/cobranca.ts';
import type { GravarCobranca, LerRegua } from '../model/portas.ts';

export interface DepsRegua {
  cobrancas: GravarCobranca & LerRegua;
  fila: FilaJobs;
}

export async function agendarRegua(deps: DepsRegua, documento: { id: string; vencimento: string }, hoje: string): Promise<number> {
  const regua: Regua | null = await deps.cobrancas.regua();
  if (regua && !regua.ativa) return 0;
  const etapas = regua ? regua.etapas : REGUA_PADRAO;
  let n = 0;
  for (const e of etapas) {
    const dia = somarDias(documento.vencimento, e.dias);
    if (dia < hoje) continue;
    const quando = inicioDoDia(dia, '12:00:00');
    const c = Cobranca.create({ documento_id: documento.id, canal: e.canal, etapa: etapaRotulo(e.dias), agendada_para: quando });
    const jobId = await deps.fila.enfileirar(JOBS.cobrar, { cobranca_id: c.id }, quando);
    await deps.cobrancas.inserir(c.comJob(jobId));
    n++;
  }
  return n;
}
