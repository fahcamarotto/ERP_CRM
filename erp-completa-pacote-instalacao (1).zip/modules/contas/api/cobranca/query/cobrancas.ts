/** Consultas de leitura da Cobranca e da Regua. */
import type pg from 'pg';
import { decodificarCursor, pagina } from '../../compartilhado/cursor.ts';
import { REGUA_PADRAO } from '../model/cobranca.ts';

export interface FiltroCobrancas { estado?: string; canal?: string; documento_id?: string; limite?: number; cursor?: string }

export async function listarCobrancas(c: pg.PoolClient, f: FiltroCobrancas) {
  const lim = Math.min(Math.max(f.limite ?? 50, 1), 200);
  const cur = decodificarCursor(f.cursor);
  const r = await c.query(
    `SELECT x.id, x.documento_id, d.numero AS documento_numero, d.tipo AS documento_tipo, coalesce(p.nome_fantasia, p.nome) AS parceiro_nome,
       x.canal, x.etapa, x.agendada_para, x.estado, x.destino, x.referencia, x.erro, x.enviada_em, x.job_id,
       d.saldo_centavos::float8 AS saldo_centavos, d.moeda, to_char(d.vencimento, 'YYYY-MM-DD') AS vencimento, x.created_at
     FROM contas_cobrancas x JOIN contas_documentos d ON d.id = x.documento_id LEFT JOIN cadastros_parceiros p ON p.id = d.parceiro_id
     WHERE x.deleted_at IS NULL AND ($1::text IS NULL OR x.estado = $1) AND ($2::text IS NULL OR x.canal = $2) AND ($3::uuid IS NULL OR x.documento_id = $3)
       AND ($4::timestamptz IS NULL OR (x.created_at, x.id) > ($4::timestamptz, $5::uuid))
     ORDER BY x.created_at, x.id LIMIT $6`,
    [f.estado ?? null, f.canal ?? null, f.documento_id ?? null, cur?.[0] ?? null, cur?.[1] ?? null, lim + 1],
  );
  return pagina(r.rows, lim);
}

/** Regua do workspace (padrao se nunca configurada) e estado dos conectores de envio. */
export async function obterRegua(c: pg.PoolClient) {
  const r = await c.query('SELECT ativa, etapas, updated_at FROM contas_reguas WHERE deleted_at IS NULL LIMIT 1');
  const k = await c.query("SELECT slug, estado FROM conectores WHERE slug IN ('resend', 'whatsapp', 'pix-boleto') AND deleted_at IS NULL");
  const conectores = Object.fromEntries(k.rows.map((x) => [x.slug as string, x.estado as string]));
  return r.rows[0]
    ? { ativa: r.rows[0].ativa as boolean, etapas: r.rows[0].etapas, padrao: false, updated_at: r.rows[0].updated_at, conectores }
    : { ativa: true, etapas: REGUA_PADRAO, padrao: true, updated_at: null, conectores };
}
