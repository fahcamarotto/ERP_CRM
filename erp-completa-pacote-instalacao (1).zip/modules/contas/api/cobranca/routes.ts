/** Rotas REST da Regua de cobranca (M5.4). Gerar e listar cobrancas sao @tool em ../tools.ts. */
import { esquemaErro, requer, type FastifyInstance } from '@erp/api/sdk';
import { naTransacao } from '../borda.ts';
import { exigirOk } from '../compartilhado/result.ts';
import { propsRegua } from '../esquemas.ts';
import type { EtapaRegua } from './model/cobranca.ts';
import { obterRegua } from './query/cobrancas.ts';

const tags = ['contas'];

export function rotasCobranca(app: FastifyInstance): void {
  app.get('/regua', {
    preHandler: requer('contas.ver'),
    schema: { tags, summary: 'Regua de cobranca do workspace (padrao se nunca configurada) e estado dos conectores de envio' },
  }, (req) => naTransacao(req, (_, __, c) => obterRegua(c)));

  app.put<{ Body: { ativa?: boolean; etapas: EtapaRegua[] } }>('/regua', {
    preHandler: requer('contas.editar'),
    schema: {
      tags, summary: 'Configura a regua (ConfigurarRegua): etapas em dias relativos ao vencimento, por email ou whatsapp',
      body: { type: 'object', additionalProperties: false, required: ['etapas'], properties: propsRegua },
      response: { 400: esquemaErro, 403: esquemaErro },
    },
  }, (req) => naTransacao(req, async (casos, ctx, c) => {
    exigirOk(await casos.configurarRegua.execute(ctx, req.body));
    return obterRegua(c);
  }));
}
