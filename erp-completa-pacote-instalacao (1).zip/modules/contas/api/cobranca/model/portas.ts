/** Portas da Cobranca e da Regua, segregadas por operacao. */
import type { Cobranca, Regua } from './cobranca.ts';

export interface ObterCobranca {
  obterPorId(id: string): Promise<Cobranca | null>;
}

export interface GravarCobranca {
  inserir(c: Cobranca): Promise<void>;
  atualizar(c: Cobranca): Promise<void>;
  /** Cancela as agendadas de um documento (quitado ou cancelado). Devolve quantas. */
  cancelarAgendadas(documentoId: string): Promise<number>;
}

export interface LerRegua {
  regua(): Promise<Regua | null>;
}

export interface GravarRegua {
  salvarRegua(r: Regua): Promise<void>;
}

/** Contato do parceiro (leitura da tabela publicada cadastros_parceiros). */
export interface ContatoParceiro {
  contato(parceiroId: string): Promise<{ nome: string; email: string | null; telefone: string | null } | null>;
}

/** Envio pelo nucleo: email pela fila (N17) e estado do conector (sem credencial). */
export interface Mensageiro {
  email(para: string, dados: Record<string, unknown>): Promise<string>;
  estadoConector(slug: string): Promise<string | null>;
}
