/**
 * Cobranca (M5.4 e M5.5) e Regua de cobranca configuravel. A cobranca nasce `agendada` e o job
 * `contas.cobrar` decide o estado final pelo canal: email enviado pela fila do nucleo (N17), WhatsApp,
 * Pix e boleto dependem do conector ativo. Imutavel: toda mudanca devolve um clone novo.
 */
import { randomUUID } from 'node:crypto';
import { erroDe, fail, ok, type ErroDominio, type Result } from '../../compartilhado/result.ts';

export const CANAIS = ['email', 'whatsapp', 'pix', 'boleto'] as const;
export type Canal = (typeof CANAIS)[number];
/** Canais da regua automatica (lembrete); Pix e boleto sao meios de pagamento gerados sob demanda. */
export const CANAIS_REGUA = ['email', 'whatsapp'] as const;
export type CanalRegua = (typeof CANAIS_REGUA)[number];

export const ESTADOS_COBRANCA = ['agendada', 'enviada', 'aguardando_conector', 'sem_contato', 'cancelada', 'erro'] as const;
export type EstadoCobranca = (typeof ESTADOS_COBRANCA)[number];

/** So `agendada` muda; os demais sao finais. */
export const TRANSICOES_COBRANCA: Record<EstadoCobranca, EstadoCobranca[]> = {
  agendada: ['enviada', 'aguardando_conector', 'sem_contato', 'cancelada', 'erro'],
  enviada: [], aguardando_conector: [], sem_contato: [], cancelada: [], erro: [],
};

export interface CobrancaDados {
  id: string;
  documento_id: string;
  canal: Canal;
  etapa: string;
  agendada_para: string;
  estado: EstadoCobranca;
  destino: string | null;
  referencia: string | null;
  erro: string | null;
  enviada_em: string | null;
  job_id: string | null;
}

/** Etapa da regua: dias relativos ao vencimento (negativo antes, 0 no dia, positivo em atraso). */
export interface EtapaRegua { dias: number; canal: CanalRegua }

export const etapaRotulo = (dias: number) => (dias === 0 ? 'D0' : dias > 0 ? `D+${dias}` : `D${dias}`);

/** Regua padrao: 3 dias antes por email, no dia por email e WhatsApp, 3 e 7 dias depois. */
export const REGUA_PADRAO: EtapaRegua[] = [
  { dias: -3, canal: 'email' }, { dias: 0, canal: 'email' }, { dias: 0, canal: 'whatsapp' }, { dias: 3, canal: 'email' }, { dias: 7, canal: 'whatsapp' },
];

export class Regua {
  private constructor(readonly ativa: boolean, readonly etapas: EtapaRegua[]) {}
  static tryCreate(e: { ativa?: boolean; etapas?: Partial<EtapaRegua>[] }): Result<Regua> {
    const erros: ErroDominio[] = [];
    const etapas = e.etapas ?? [];
    if (etapas.length > 12) erros.push(erroDe('regua_invalida', 'No maximo 12 etapas', 'etapas'));
    const vistas = new Set<string>();
    etapas.forEach((x, i) => {
      if (!Number.isInteger(x.dias) || x.dias! < -30 || x.dias! > 90) erros.push(erroDe('regua_invalida', `Etapa ${i + 1}: dias inteiro de -30 a 90`, `etapas.${i}.dias`));
      if (!CANAIS_REGUA.includes(x.canal as CanalRegua)) erros.push(erroDe('regua_invalida', `Etapa ${i + 1}: canal email ou whatsapp`, `etapas.${i}.canal`));
      const k = `${x.dias}|${x.canal}`;
      if (vistas.has(k)) erros.push(erroDe('regua_invalida', `Etapa ${i + 1} repetida`, `etapas.${i}`));
      vistas.add(k);
    });
    if (erros.length) return fail(...erros);
    const ordenadas = (etapas as EtapaRegua[]).map((x) => ({ dias: x.dias, canal: x.canal })).sort((a, b) => a.dias - b.dias || a.canal.localeCompare(b.canal));
    return ok(new Regua(e.ativa ?? true, ordenadas));
  }
  static create(e: { ativa?: boolean; etapas?: EtapaRegua[] }): Regua {
    const r = Regua.tryCreate(e);
    if (!r.ok) throw new Error(r.erros[0]!.mensagem);
    return r.valor;
  }
}

export class Cobranca {
  private constructor(private readonly d: CobrancaDados) {}

  static tryCreate(e: { documento_id: string; canal: string; etapa?: string; agendada_para?: string }, id: string = randomUUID()): Result<Cobranca> {
    const erros: ErroDominio[] = [];
    if (!e.documento_id) erros.push(erroDe('documento_obrigatorio', 'Informe o documento', 'documento_id'));
    if (!CANAIS.includes(e.canal as Canal)) erros.push(erroDe('canal_invalido', 'Canal deve ser email, whatsapp, pix ou boleto', 'canal'));
    const etapa = e.etapa ?? 'manual';
    if (!/^(manual|D[+-]?[0-9]{1,2})$/.test(etapa)) erros.push(erroDe('etapa_invalida', 'Etapa invalida', 'etapa'));
    if (erros.length) return fail(...erros);
    return ok(new Cobranca({
      id, documento_id: e.documento_id, canal: e.canal as Canal, etapa, agendada_para: e.agendada_para ?? new Date().toISOString(),
      estado: 'agendada', destino: null, referencia: null, erro: null, enviada_em: null, job_id: null,
    }));
  }

  static create(e: { documento_id: string; canal: string; etapa?: string; agendada_para?: string }, id?: string): Cobranca {
    const r = Cobranca.tryCreate(e, id);
    if (!r.ok) throw new Error(r.erros[0]!.mensagem);
    return r.valor;
  }

  static reidratar(d: CobrancaDados): Cobranca { return new Cobranca({ ...d }); }

  get id(): string { return this.d.id; }
  get documentoId(): string { return this.d.documento_id; }
  get canal(): Canal { return this.d.canal; }
  get estado(): EstadoCobranca { return this.d.estado; }

  comJob(jobId: string): Cobranca { return new Cobranca({ ...this.d, job_id: jobId }); }

  /** Resultado do processamento: so sai de `agendada`. */
  concluir(estado: Exclude<EstadoCobranca, 'agendada'>, x: { destino?: string | null; referencia?: string | null; erro?: string | null } = {}): Result<Cobranca> {
    if (!TRANSICOES_COBRANCA[this.d.estado].includes(estado)) {
      return fail(erroDe('transicao_invalida', `Cobranca ${this.d.estado} nao pode ir para ${estado}`, 'estado', { permitidas: TRANSICOES_COBRANCA[this.d.estado] }));
    }
    return ok(new Cobranca({
      ...this.d, estado, destino: x.destino ?? this.d.destino, referencia: x.referencia ?? this.d.referencia,
      erro: x.erro ? x.erro.slice(0, 500) : null, enviada_em: estado === 'enviada' ? new Date().toISOString() : this.d.enviada_em,
    }));
  }

  paraDados(): CobrancaDados { return { ...this.d }; }
}
