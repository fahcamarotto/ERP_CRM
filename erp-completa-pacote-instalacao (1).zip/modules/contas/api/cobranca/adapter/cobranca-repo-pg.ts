/**
 * Adaptador Postgres da Cobranca, da Regua, do contato do parceiro (tabela publicada cadastros_parceiros)
 * e do envio pelo nucleo (email.enviar pela fila e conectores.obter, nunca credencial).
 */
import type pg from 'pg';
import { conectores, enviarEmail } from '@erp/api/sdk/puro';
import { Cobranca, Regua, type CobrancaDados, type EtapaRegua } from '../model/cobranca.ts';
import type { ContatoParceiro, GravarCobranca, GravarRegua, LerRegua, Mensageiro, ObterCobranca } from '../model/portas.ts';

export class CobrancaRepoPg implements ObterCobranca, GravarCobranca, LerRegua, GravarRegua, ContatoParceiro, Mensageiro {
  constructor(private readonly c: pg.PoolClient) {}

  async obterPorId(id: string): Promise<Cobranca | null> {
    const r = await this.c.query(
      `SELECT id, documento_id, canal, etapa, agendada_para::text AS agendada_para, estado, destino, referencia, erro,
         enviada_em::text AS enviada_em, job_id FROM contas_cobrancas WHERE id = $1 AND deleted_at IS NULL`, [id]);
    return r.rows[0] ? Cobranca.reidratar(r.rows[0] as CobrancaDados) : null;
  }

  async inserir(cob: Cobranca): Promise<void> {
    const d = cob.paraDados();
    await this.c.query(
      `INSERT INTO contas_cobrancas (id, documento_id, canal, etapa, agendada_para, estado, job_id, creator_id)
       VALUES ($1, $2, $3, $4, $5, $6, $7, nucleo_usuario_atual())
       ON CONFLICT (tenant_id, workspace_id, documento_id, etapa, canal) WHERE etapa <> 'manual' AND deleted_at IS NULL DO NOTHING`,
      [d.id, d.documento_id, d.canal, d.etapa, d.agendada_para, d.estado, d.job_id],
    );
  }

  async atualizar(cob: Cobranca): Promise<void> {
    const d = cob.paraDados();
    await this.c.query(
      'UPDATE contas_cobrancas SET estado = $2, destino = $3, referencia = $4, erro = $5, enviada_em = $6 WHERE id = $1 AND deleted_at IS NULL',
      [d.id, d.estado, d.destino, d.referencia, d.erro, d.enviada_em],
    );
  }

  async cancelarAgendadas(documentoId: string): Promise<number> {
    const r = await this.c.query(
      "UPDATE contas_cobrancas SET estado = 'cancelada', erro = 'Documento quitado ou cancelado' WHERE documento_id = $1 AND estado = 'agendada' AND deleted_at IS NULL",
      [documentoId]);
    return r.rowCount ?? 0;
  }

  async regua(): Promise<Regua | null> {
    const r = await this.c.query('SELECT ativa, etapas FROM contas_reguas WHERE deleted_at IS NULL LIMIT 1');
    return r.rows[0] ? Regua.create({ ativa: r.rows[0].ativa as boolean, etapas: r.rows[0].etapas as EtapaRegua[] }) : null;
  }

  async salvarRegua(rg: Regua): Promise<void> {
    const u = await this.c.query('UPDATE contas_reguas SET ativa = $1, etapas = $2 WHERE deleted_at IS NULL', [rg.ativa, JSON.stringify(rg.etapas)]);
    if (!u.rowCount) await this.c.query('INSERT INTO contas_reguas (ativa, etapas, creator_id) VALUES ($1, $2, nucleo_usuario_atual())', [rg.ativa, JSON.stringify(rg.etapas)]);
  }

  async contato(parceiroId: string) {
    const r = await this.c.query('SELECT coalesce(nome_fantasia, nome) AS nome, email::text AS email, telefone FROM cadastros_parceiros WHERE id = $1 AND deleted_at IS NULL', [parceiroId]);
    return (r.rows[0] as { nome: string; email: string | null; telefone: string | null }) ?? null;
  }

  email(para: string, dados: Record<string, unknown>): Promise<string> { return enviarEmail(this.c, 'cobranca', para, dados); }

  async estadoConector(slug: string): Promise<string | null> { return (await conectores.obter(this.c, slug))?.estado ?? null; }
}
