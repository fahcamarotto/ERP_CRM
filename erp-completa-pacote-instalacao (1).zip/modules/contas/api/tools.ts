/**
 * @tool do modulo (N15): cada chamada vira tool MCP em /mcp e, com `rota`, rota REST com o mesmo schema.
 * Tools de M5.8: fatura.criar, fatura.baixar e faturas.vencidas; mais faturas.listar, fatura.obter,
 * fatura.cancelar, cobranca.gerar, cobrancas.listar, recorrencia.configurar e recorrencias.listar.
 * fatura.criar e fatura.baixar sao so MCP (com chave_idempotencia): a rota REST equivalente exige o
 * cabecalho Idempotency-Key (CONTRATOS 3.1) e mora em documento/routes.ts.
 */
import { tool } from '@erp/api/sdk';
import { naoEncontrado } from './borda.ts';
import { listarCobrancas, type FiltroCobrancas } from './cobranca/query/cobrancas.ts';
import { contextoPg } from './compartilhado/efeitos-pg.ts';
import { exigirOk } from './compartilhado/result.ts';
import type { DadosEmissao } from './documento/model/documento.ts';
import { listarDocumentos, listarVencidas, obterDocumento, type FiltroDocumentos } from './documento/query/documentos.ts';
import type { EntradaBaixar } from './documento/use-case/baixar.ts';
import { canalCobranca, chaveIdempotencia, filtroDocumentos, paginacao, propsBaixa, propsDocumento, propsRecorrencia, uuid } from './esquemas.ts';
import { casosDeUso } from './fabrica.ts';
import type { DadosRecorrencia } from './recorrencia/model/recorrencia.ts';
import { listarRecorrencias, obterRecorrencia } from './recorrencia/query/recorrencias.ts';

tool<FiltroDocumentos>({
  nome: 'faturas.listar', modulo: 'contas', titulo: 'Listar documentos a receber e a pagar', tipo: 'leitura', permissao: 'contas.ver',
  descricao: 'Lista faturas, contas a pagar, notas de credito e reembolsos com saldo em centavos e atraso calculado. Filtra por aba, tipo, estado, situacao (abertos, atrasados, pagos, cancelados), parceiro e vencimento.',
  entrada: { type: 'object', properties: filtroDocumentos },
  rota: { metodo: 'GET', caminho: '/api/v1/contas/documentos' },
  executar: ({ c }, a) => listarDocumentos(c, a),
});

tool<{ id: string }>({
  nome: 'fatura.obter', modulo: 'contas', titulo: 'Obter documento', tipo: 'leitura', permissao: 'contas.ver',
  descricao: 'Ficha do documento pelo id: itens, valores em centavos, saldo, multa e juros sugeridos se atrasado, baixas e cobrancas.',
  entrada: { type: 'object', required: ['id'], properties: { id: uuid } },
  rota: { metodo: 'GET', caminho: '/api/v1/contas/documentos/:id' },
  executar: async ({ c }, a) => (await obterDocumento(c, a.id)) ?? Promise.reject(naoEncontrado('Documento nao encontrado')),
});

tool<{ natureza?: 'receber' | 'pagar'; parceiro_id?: string; limite?: number }>({
  nome: 'faturas.vencidas', modulo: 'contas', titulo: 'Documentos vencidos', tipo: 'leitura', permissao: 'contas.ver',
  descricao: 'Documentos vencidos e ainda em aberto, do mais atrasado ao mais recente, com dias de atraso, contato do parceiro e soma do saldo em centavos. natureza receber (faturas) ou pagar.',
  entrada: { type: 'object', properties: { natureza: { type: 'string', enum: ['receber', 'pagar'] }, parceiro_id: uuid, limite: paginacao.limite } },
  rota: { metodo: 'GET', caminho: '/api/v1/contas/vencidas' },
  executar: ({ c }, a) => listarVencidas(c, a),
});

tool<DadosEmissao & { chave_idempotencia: string }>({
  nome: 'fatura.criar', modulo: 'contas', titulo: 'Emitir documento', tipo: 'escrita', permissao: 'contas.criar',
  descricao: 'Emite fatura (padrao), conta a pagar, nota de credito ou reembolso com numero da sequencia. Valor pelos itens (preco em centavos) ou valor_centavos. chave_idempotencia obrigatoria: repetir a mesma chave devolve o documento ja emitido. Publica fatura.emitida e agenda a regua de cobranca.',
  entrada: { type: 'object', required: ['parceiro_id', 'chave_idempotencia'], properties: { ...propsDocumento, chave_idempotencia: chaveIdempotencia } },
  executar: async ({ c, ator, ip }, a) => {
    const r = exigirOk(await casosDeUso(c).emitirDocumento.execute(contextoPg(c, ator, ip), { ...a, tipo: a.tipo ?? 'fatura' }));
    return { ...(await obterDocumento(c, r.id)), repetido: r.repetido };
  },
});

tool<Omit<EntradaBaixar, 'origem' | 'id_externo'> & { id: string; chave_idempotencia: string }>({
  nome: 'fatura.baixar', modulo: 'contas', titulo: 'Baixar documento', tipo: 'escrita', permissao: 'contas.baixar',
  descricao: 'Registra pagamento parcial ou total de um documento (padrao: o saldo todo, hoje). Juros e multa somam, desconto abate. chave_idempotencia obrigatoria. Publica fatura.paga, que vira lancamento realizado no Financeiro.',
  entrada: { type: 'object', required: ['id', 'chave_idempotencia'], properties: { id: uuid, ...propsBaixa, chave_idempotencia: chaveIdempotencia } },
  executar: async ({ c, ator, ip }, a) => {
    const { id, ...resto } = a;
    const r = exigirOk(await casosDeUso(c).baixar.execute(contextoPg(c, ator, ip), { ...resto, documento_id: id }));
    return { ...(await obterDocumento(c, r.documento_id)), baixa_id: r.baixa_id, repetido: r.repetido };
  },
});

tool<{ id: string; motivo?: string }>({
  nome: 'fatura.cancelar', modulo: 'contas', titulo: 'Cancelar documento', tipo: 'escrita', permissao: 'contas.excluir',
  descricao: 'Cancela documento em aberto sem baixa (CancelarDocumento) e cancela as cobrancas agendadas. Documento parcial ou pago nao cancela.',
  entrada: { type: 'object', required: ['id'], properties: { id: uuid, motivo: { type: 'string', maxLength: 500 } } },
  rota: { metodo: 'POST', caminho: '/api/v1/contas/documentos/:id/cancelar' },
  executar: async ({ c, ator, ip }, a) => {
    exigirOk(await casosDeUso(c).cancelarDocumento.execute(contextoPg(c, ator, ip), a));
    return obterDocumento(c, a.id);
  },
});

tool<{ id: string; canal: string }>({
  nome: 'cobranca.gerar', modulo: 'contas', titulo: 'Gerar cobranca', tipo: 'escrita', permissao: 'contas.cobrar',
  descricao: 'Gera cobranca de uma fatura em aberto por email, whatsapp, pix ou boleto (GerarCobranca). O envio sai pela fila: devolve cobranca_id e job_id.',
  entrada: { type: 'object', required: ['id', 'canal'], properties: { id: uuid, canal: canalCobranca } },
  rota: { metodo: 'POST', caminho: '/api/v1/contas/documentos/:id/cobrancas' },
  executar: async ({ c, ator, ip }, a) => exigirOk(await casosDeUso(c).gerarCobranca.execute(contextoPg(c, ator, ip), { documento_id: a.id, canal: a.canal })),
});

tool<FiltroCobrancas>({
  nome: 'cobrancas.listar', modulo: 'contas', titulo: 'Listar cobrancas', tipo: 'leitura', permissao: 'contas.ver',
  descricao: 'Lista cobrancas (regua automatica e manuais) com canal, etapa, estado e documento. Filtra por estado, canal e documento.',
  entrada: { type: 'object', properties: {
    limite: paginacao.limite, cursor: paginacao.cursor, documento_id: uuid, canal: canalCobranca,
    estado: { type: 'string', enum: ['agendada', 'enviada', 'aguardando_conector', 'sem_contato', 'cancelada', 'erro'] },
  } },
  rota: { metodo: 'GET', caminho: '/api/v1/contas/cobrancas' },
  executar: ({ c }, a) => listarCobrancas(c, a),
});

tool<DadosRecorrencia>({
  nome: 'recorrencia.configurar', modulo: 'contas', titulo: 'Configurar recorrencia', tipo: 'escrita', permissao: 'contas.criar',
  descricao: 'Cria recorrencia mensal, trimestral ou anual de fatura ou conta a pagar (ConfigurarRecorrencia). O documento de cada competencia e gerado por job antecedencia_dias antes do vencimento.',
  entrada: { type: 'object', required: ['tipo', 'parceiro_id', 'descricao', 'valor_centavos', 'frequencia', 'dia_vencimento', 'inicio'], properties: propsRecorrencia },
  rota: { metodo: 'POST', caminho: '/api/v1/contas/recorrencias' },
  executar: async ({ c, ator, ip }, a) => {
    const { id } = exigirOk(await casosDeUso(c).configurarRecorrencia.execute(contextoPg(c, ator, ip), a));
    return obterRecorrencia(c, id);
  },
});

tool<{ estado?: string; tipo?: string; limite?: number; cursor?: string }>({
  nome: 'recorrencias.listar', modulo: 'contas', titulo: 'Listar recorrencias', tipo: 'leitura', permissao: 'contas.ver',
  descricao: 'Lista recorrencias com proxima data, frequencia, valor em centavos e quantidade gerada.',
  entrada: { type: 'object', properties: {
    limite: paginacao.limite, cursor: paginacao.cursor, estado: { type: 'string', enum: ['ativa', 'pausada', 'encerrada'] }, tipo: { type: 'string', enum: ['fatura', 'conta_pagar'] },
  } },
  rota: { metodo: 'GET', caminho: '/api/v1/contas/recorrencias' },
  executar: ({ c }, a) => listarRecorrencias(c, a),
});
