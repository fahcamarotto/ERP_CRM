/**
 * Plugin do modulo Contas a receber e a pagar (M5), registrado sozinho com prefixo /api/v1/contas.
 * Importar ./tools.ts registra as @tool (MCP e REST) no carregamento.
 */
import type { FastifyPluginAsync } from '@erp/api/sdk';
import './tools.ts';
import { rotasCobranca } from './cobranca/routes.ts';
import { rotasDocumento } from './documento/routes.ts';
import { rotasRecorrencia } from './recorrencia/routes.ts';

const plugin: FastifyPluginAsync = async (app) => {
  rotasDocumento(app);
  rotasCobranca(app);
  rotasRecorrencia(app);
};

export default plugin;
