/**
 * Composicao do modulo: liga casos de uso aos adaptadores Postgres para um cliente de transacao.
 * Usada pelas rotas, pelas tools, pelo worker e pelo seed. Nao importa Fastify nem o pool do servidor.
 */
import type pg from 'pg';
import { CobrancaRepoPg } from './cobranca/adapter/cobranca-repo-pg.ts';
import { ConfigurarRegua, ConfirmarPagamento, GerarCobranca, ProcessarCobranca } from './cobranca/use-case/cobrancas.ts';
import { FilaOutboxPg } from './compartilhado/fila-pg.ts';
import { DocumentoRepoPg } from './documento/adapter/documento-repo-pg.ts';
import { Baixar, CancelarDocumento, VerificarVencimento } from './documento/use-case/baixar.ts';
import { EditarDocumento, EmitirDocumento } from './documento/use-case/emitir-documento.ts';
import { RecorrenciaRepoPg } from './recorrencia/adapter/recorrencia-repo-pg.ts';
import { ConfigurarRecorrencia, EditarRecorrencia, GerarDocumentoRecorrente, MudarEstadoRecorrencia } from './recorrencia/use-case/recorrencias.ts';

export function casosDeUso(c: pg.PoolClient) {
  const documentos = new DocumentoRepoPg(c);
  const cobrancas = new CobrancaRepoPg(c);
  const recorrencias = new RecorrenciaRepoPg(c);
  const fila = new FilaOutboxPg(c);
  const emitirDocumento = new EmitirDocumento({ repo: documentos, numeracao: documentos, refs: documentos, cobrancas, fila });
  const baixar = new Baixar({ repo: documentos, baixas: documentos, refs: documentos, cobrancas });
  const depsRec = { repo: recorrencias, refs: documentos, fila };
  return {
    emitirDocumento,
    editarDocumento: new EditarDocumento({ repo: documentos, refs: documentos, fila }),
    baixar,
    cancelarDocumento: new CancelarDocumento({ repo: documentos, cobrancas }),
    verificarVencimento: new VerificarVencimento({ repo: documentos }),
    gerarCobranca: new GerarCobranca({ documentos, cobrancas, fila }),
    processarCobranca: new ProcessarCobranca({ cobrancas, documentos, contatos: cobrancas, mensageiro: cobrancas }),
    configurarRegua: new ConfigurarRegua({ reguas: cobrancas }),
    confirmarPagamento: new ConfirmarPagamento({ baixar, localizar: documentos, documentos }),
    configurarRecorrencia: new ConfigurarRecorrencia(depsRec),
    editarRecorrencia: new EditarRecorrencia(depsRec),
    mudarEstadoRecorrencia: new MudarEstadoRecorrencia(depsRec),
    gerarDocumentoRecorrente: new GerarDocumentoRecorrente({ ...depsRec, emitir: emitirDocumento }),
  };
}

export type CasosDeUso = ReturnType<typeof casosDeUso>;
