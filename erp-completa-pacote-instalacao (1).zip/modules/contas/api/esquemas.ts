/** JSON Schemas dos DTOs de entrada (viram validacao Fastify, OpenAPI em /docs e schema das tools MCP). */
import { CANAIS, CANAIS_REGUA } from './cobranca/model/cobranca.ts';
import { CONDICOES, FORMAS_BAIXA, TIPOS_DOCUMENTO } from './documento/model/documento.ts';
import { ESTADOS_RECORRENCIA, FREQUENCIAS, TIPOS_RECORRENCIA } from './recorrencia/model/recorrencia.ts';

export const uuid = { type: 'string', format: 'uuid' } as const;
const uuidNulo = { type: ['string', 'null'], format: 'uuid' } as const;
const texto = (max: number) => ({ type: ['string', 'null'], maxLength: max });
const data = { type: ['string', 'null'], format: 'date', description: 'AAAA-MM-DD' } as const;
const centavos = (d: string) => ({ type: ['integer', 'null'], minimum: 0, maximum: 900_000_000_000_000, description: `${d} em centavos (inteiro)` });

export const paginacao = {
  busca: { type: 'string', maxLength: 120 },
  limite: { type: 'integer', minimum: 1, maximum: 200, default: 50 },
  cursor: { type: 'string', maxLength: 200 },
} as const;

export const chaveIdempotencia = { type: 'string', minLength: 8, maxLength: 200, description: 'Idempotency-Key: repetir a mesma chave nao duplica' } as const;

export const propsItem = {
  type: 'object', additionalProperties: false, required: ['descricao', 'preco_centavos'],
  properties: {
    descricao: { type: 'string', minLength: 1, maxLength: 200 },
    quantidade: { type: 'number', exclusiveMinimum: 0, maximum: 1_000_000, default: 1 },
    preco_centavos: { type: 'integer', minimum: 0, maximum: 900_000_000_000_000 },
  },
} as const;

export const propsDocumento = {
  tipo: { type: 'string', enum: [...TIPOS_DOCUMENTO], description: 'fatura (a receber), conta_pagar, nota_credito ou reembolso' },
  parceiro_id: uuid,
  descricao: texto(200),
  emissao: data,
  vencimento: { ...data, description: 'AAAA-MM-DD; sem vencimento usa a condicao de pagamento' },
  condicao_pagamento: { type: ['string', 'null'], enum: [...Object.keys(CONDICOES), null] },
  moeda: { type: ['string', 'null'], pattern: '^[A-Za-z]{3}$' },
  itens: { type: ['array', 'null'], maxItems: 200, items: propsItem },
  valor_centavos: { ...centavos('Valor total quando nao ha itens'), minimum: 1 },
  desconto_centavos: centavos('Desconto'),
  multa_pct: { type: ['number', 'null'], minimum: 0, maximum: 20 },
  juros_mes_pct: { type: ['number', 'null'], minimum: 0, maximum: 10 },
  categoria_id: uuidNulo,
  centro_custo_id: uuidNulo,
  conta_financeira_id: { ...uuidNulo, description: 'Conta do Financeiro que recebe ou paga (padrao na baixa)' },
  documento_origem_id: { ...uuidNulo, description: 'Fatura de origem (so nota de credito)' },
  observacoes: texto(2000),
  extras: { type: 'object', description: 'Campos personalizados (modulo contas, entidade documento)' },
} as const;

export const propsEdicaoDocumento = {
  descricao: propsDocumento.descricao, vencimento: data, observacoes: propsDocumento.observacoes,
  categoria_id: uuidNulo, centro_custo_id: uuidNulo, conta_financeira_id: uuidNulo,
  multa_pct: propsDocumento.multa_pct, juros_mes_pct: propsDocumento.juros_mes_pct, extras: propsDocumento.extras,
} as const;

export const propsBaixa = {
  valor_centavos: { ...centavos('Principal amortizado; padrao: o saldo todo'), minimum: 1 },
  data: { ...data, description: 'Data do pagamento (padrao: hoje)' },
  juros_centavos: centavos('Juros pagos'),
  multa_centavos: centavos('Multa paga'),
  desconto_centavos: centavos('Desconto concedido na baixa'),
  forma: { type: ['string', 'null'], enum: [...FORMAS_BAIXA, null] },
  conta_financeira_id: uuidNulo,
} as const;

export const propsRecorrencia = {
  tipo: { type: 'string', enum: [...TIPOS_RECORRENCIA] },
  parceiro_id: uuid,
  descricao: { type: 'string', minLength: 2, maxLength: 200 },
  valor_centavos: { type: 'integer', minimum: 1, maximum: 900_000_000_000_000 },
  moeda: { type: ['string', 'null'], pattern: '^[A-Za-z]{3}$' },
  frequencia: { type: 'string', enum: [...FREQUENCIAS] },
  dia_vencimento: { type: 'integer', minimum: 1, maximum: 28 },
  antecedencia_dias: { type: ['integer', 'null'], minimum: 0, maximum: 60 },
  inicio: { type: 'string', format: 'date' },
  fim: data,
  categoria_id: uuidNulo,
  centro_custo_id: uuidNulo,
  conta_financeira_id: uuidNulo,
} as const;

export const estadosRecorrencia = { type: 'string', enum: [...ESTADOS_RECORRENCIA] } as const;
export const canalCobranca = { type: 'string', enum: [...CANAIS] } as const;

export const propsRegua = {
  ativa: { type: 'boolean' },
  etapas: {
    type: 'array', maxItems: 12,
    items: { type: 'object', additionalProperties: false, required: ['dias', 'canal'], properties: {
      dias: { type: 'integer', minimum: -30, maximum: 90, description: 'Dias em relacao ao vencimento (negativo antes)' },
      canal: { type: 'string', enum: [...CANAIS_REGUA] },
    } },
  },
} as const;

export const filtroDocumentos = {
  ...paginacao,
  aba: { type: 'string', enum: ['a-receber', 'a-pagar', 'notas-credito'] },
  tipo: { type: 'string', enum: [...TIPOS_DOCUMENTO] },
  estado: { type: 'string', enum: ['em_aberto', 'parcial', 'pago', 'cancelado'] },
  situacao: { type: 'string', enum: ['abertos', 'atrasados', 'pagos', 'cancelados'] },
  parceiro_id: uuid,
  vence_ate: { type: 'string', format: 'date' },
} as const;
