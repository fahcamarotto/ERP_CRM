/**
 * Rotas REST do Documento fora das tools. POST de emissao e de baixa exige o cabecalho Idempotency-Key
 * (CONTRATOS 3.1, M5.8): a mesma chave devolve 200 com o documento ja gravado, sem duplicar.
 */
import { erro, esquemaErro, requer, type FastifyInstance } from '@erp/api/sdk';
import { naTransacao } from '../borda.ts';
import { exigirOk } from '../compartilhado/result.ts';
import { propsBaixa, propsDocumento, propsEdicaoDocumento, uuid } from '../esquemas.ts';
import type { DadosEmissao, EdicaoDocumento, EntradaBaixa } from './model/documento.ts';
import { obterDocumento, opcoes, resumo } from './query/documentos.ts';

const tags = ['contas'];
const paramId = { type: 'object', required: ['id'], properties: { id: uuid } } as const;
const erros = { 400: esquemaErro, 403: esquemaErro, 404: esquemaErro, 409: esquemaErro };
/** Documenta o cabecalho no OpenAPI; a ausencia e tratada no handler (400 idempotency_key_obrigatoria). */
const cabecalhoIdem = { type: 'object', properties: { 'idempotency-key': { type: 'string', minLength: 8, maxLength: 200, description: 'Obrigatorio: chave unica por operacao' } } } as const;

export function rotasDocumento(app: FastifyInstance): void {
  app.post<{ Body: DadosEmissao }>('/documentos', {
    preHandler: requer('contas.criar'),
    schema: {
      tags, summary: 'Emite documento (EmitirDocumento). Exige Idempotency-Key; repeticao devolve 200 com o mesmo documento',
      headers: cabecalhoIdem,
      body: { type: 'object', additionalProperties: false, required: ['tipo', 'parceiro_id'], properties: propsDocumento },
      response: erros,
    },
  }, async (req, reply) => {
    const chave = String(req.headers['idempotency-key'] ?? '').trim();
    if (!chave) return erro(reply, 400, 'idempotency_key_obrigatoria', 'Envie o cabecalho Idempotency-Key');
    const r = await naTransacao(req, async (casos, ctx, c) => {
      const reg = exigirOk(await casos.emitirDocumento.execute(ctx, { ...req.body, chave_idempotencia: chave }));
      return { reg, dto: await obterDocumento(c, reg.id) };
    });
    if (r.reg.repetido) reply.header('idempotent-replayed', 'true');
    return reply.code(r.reg.repetido ? 200 : 201).send(r.dto);
  });

  app.patch<{ Params: { id: string }; Body: EdicaoDocumento }>('/documentos/:id', {
    preHandler: requer('contas.editar'),
    schema: {
      tags, summary: 'Edita vencimento, descricao, classificacao e encargos (EditarDocumento). Valor e parceiro nao mudam depois de emitido', params: paramId,
      body: { type: 'object', additionalProperties: false, properties: propsEdicaoDocumento }, response: erros,
    },
  }, (req) => naTransacao(req, async (casos, ctx, c) => {
    exigirOk(await casos.editarDocumento.execute(ctx, { ...req.body, id: req.params.id }));
    return obterDocumento(c, req.params.id);
  }));

  app.post<{ Params: { id: string }; Body: EntradaBaixa & { conta_financeira_id?: string | null } }>('/documentos/:id/baixas', {
    preHandler: requer('contas.baixar'),
    schema: {
      tags, summary: 'Baixa parcial ou total (Baixar). Exige Idempotency-Key. Publica fatura.paga (lancamento no Financeiro)', params: paramId,
      headers: cabecalhoIdem, body: { type: 'object', additionalProperties: false, properties: propsBaixa }, response: erros,
    },
  }, async (req, reply) => {
    const chave = String(req.headers['idempotency-key'] ?? '').trim();
    if (!chave) return erro(reply, 400, 'idempotency_key_obrigatoria', 'Envie o cabecalho Idempotency-Key');
    const r = await naTransacao(req, async (casos, ctx, c) => {
      const reg = exigirOk(await casos.baixar.execute(ctx, { ...(req.body ?? {}), documento_id: req.params.id, chave_idempotencia: chave }));
      return { reg, dto: await obterDocumento(c, reg.documento_id) };
    });
    if (r.reg.repetido) reply.header('idempotent-replayed', 'true');
    return reply.code(r.reg.repetido ? 200 : 201).send({ ...r.dto, baixa_id: r.reg.baixa_id });
  });

  app.get('/resumo', {
    preHandler: requer('contas.ver'),
    schema: { tags, summary: 'Totais por aba e moeda: em aberto, atrasado (em destaque) e pago no mes, em centavos' },
  }, (req) => naTransacao(req, (_, __, c) => resumo(c)));

  app.get('/opcoes', {
    preHandler: requer('contas.ver'),
    schema: { tags, summary: 'Opcoes dos seletores: parceiros (Cadastros), contas, categorias e centros (Financeiro) e faturas de origem' },
  }, (req) => naTransacao(req, (_, __, c) => opcoes(c)));
}
