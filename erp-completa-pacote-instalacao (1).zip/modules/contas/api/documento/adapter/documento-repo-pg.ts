/**
 * Adaptador Postgres das portas do Documento e da Baixa (RLS restringe ao workspace da sessao ou do job).
 * Referencias externas so por leitura das tabelas publicadas (CONTRATOS 7.1): cadastros_parceiros e
 * financeiro_contas, financeiro_categorias, financeiro_centros_custo.
 */
import type pg from 'pg';
import { proximoNumero } from '@erp/api/sdk/puro';
import type { LocalizarDocumento } from '../../cobranca/use-case/cobrancas.ts';
import { Documento, type DocumentoDados } from '../model/documento.ts';
import type { BaixaDados, BuscarDocumentoPorChave, ConsultarReferenciasDocumento, GravarBaixa, GravarDocumento, Numeracao, ObterDocumento } from '../model/portas.ts';

export const COLUNAS_DOCUMENTO = `d.id, d.tipo, d.numero, d.parceiro_id, d.descricao, to_char(d.emissao, 'YYYY-MM-DD') AS emissao,
  to_char(d.vencimento, 'YYYY-MM-DD') AS vencimento, d.condicao_pagamento, d.moeda, d.itens, d.valor_centavos::float8 AS valor_centavos,
  d.desconto_centavos::float8 AS desconto_centavos, d.multa_pct::float8 AS multa_pct, d.juros_mes_pct::float8 AS juros_mes_pct,
  d.pago_centavos::float8 AS pago_centavos, d.saldo_centavos::float8 AS saldo_centavos, d.estado, d.categoria_id, d.centro_custo_id,
  d.conta_financeira_id, d.documento_origem_id, d.recorrencia_id, to_char(d.competencia, 'YYYY-MM-DD') AS competencia, d.observacoes,
  d.cancelado_motivo, to_char(d.pago_em, 'YYYY-MM-DD') AS pago_em, to_char(d.vencida_em, 'YYYY-MM-DD') AS vencida_em, d.chave_idempotencia, d.extras`;

const COLUNAS_BAIXA = `id, documento_id, to_char(data, 'YYYY-MM-DD') AS data, valor_centavos::float8 AS valor_centavos, juros_centavos::float8 AS juros_centavos,
  multa_centavos::float8 AS multa_centavos, desconto_centavos::float8 AS desconto_centavos, total_centavos::float8 AS total_centavos, forma,
  conta_financeira_id, origem, id_externo, chave_idempotencia`;

export class DocumentoRepoPg implements ObterDocumento, GravarDocumento, BuscarDocumentoPorChave, Numeracao, ConsultarReferenciasDocumento, GravarBaixa, LocalizarDocumento {
  constructor(private readonly c: pg.PoolClient) {}

  private async um(where: string, v: unknown[]): Promise<Documento | null> {
    const r = await this.c.query(`SELECT ${COLUNAS_DOCUMENTO} FROM contas_documentos d WHERE ${where} AND d.deleted_at IS NULL`, v);
    return r.rows[0] ? Documento.reidratar(r.rows[0] as DocumentoDados) : null;
  }

  obterPorId(id: string) { return this.um('d.id = $1', [id]); }
  porChave(chave: string) { return this.um('d.chave_idempotencia = $1', [chave]); }

  async idPorNumero(numero: string): Promise<string | null> {
    const r = await this.c.query("SELECT id FROM contas_documentos WHERE numero = $1 AND tipo = 'fatura' AND deleted_at IS NULL", [numero]);
    return (r.rows[0]?.id as string) ?? null;
  }

  async inserir(doc: Documento): Promise<void> {
    const d = doc.paraDados();
    await this.c.query(
      `INSERT INTO contas_documentos (id, tipo, numero, parceiro_id, descricao, emissao, vencimento, condicao_pagamento, moeda, itens,
         valor_centavos, desconto_centavos, multa_pct, juros_mes_pct, pago_centavos, saldo_centavos, estado, categoria_id, centro_custo_id,
         conta_financeira_id, documento_origem_id, recorrencia_id, competencia, observacoes, chave_idempotencia, extras, creator_id)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22, $23, $24, $25, $26, nucleo_usuario_atual())`,
      [d.id, d.tipo, d.numero, d.parceiro_id, d.descricao, d.emissao, d.vencimento, d.condicao_pagamento, d.moeda, JSON.stringify(d.itens),
        d.valor_centavos, d.desconto_centavos, d.multa_pct, d.juros_mes_pct, d.pago_centavos, d.saldo_centavos, d.estado, d.categoria_id,
        d.centro_custo_id, d.conta_financeira_id, d.documento_origem_id, d.recorrencia_id, d.competencia, d.observacoes, d.chave_idempotencia,
        JSON.stringify(d.extras)],
    );
  }

  async atualizar(doc: Documento): Promise<void> {
    const d = doc.paraDados();
    await this.c.query(
      `UPDATE contas_documentos SET descricao = $2, vencimento = $3, condicao_pagamento = $4, multa_pct = $5, juros_mes_pct = $6,
         pago_centavos = $7, saldo_centavos = $8, estado = $9, categoria_id = $10, centro_custo_id = $11, conta_financeira_id = $12,
         observacoes = $13, cancelado_motivo = $14, pago_em = $15, vencida_em = $16, extras = $17
       WHERE id = $1 AND deleted_at IS NULL`,
      [d.id, d.descricao, d.vencimento, d.condicao_pagamento, d.multa_pct, d.juros_mes_pct, d.pago_centavos, d.saldo_centavos, d.estado,
        d.categoria_id, d.centro_custo_id, d.conta_financeira_id, d.observacoes, d.cancelado_motivo, d.pago_em, d.vencida_em, JSON.stringify(d.extras)],
    );
  }

  proximoNumero(codigo: string): Promise<string> { return proximoNumero(this.c, codigo); }

  private async existe(sql: string, v: unknown[]): Promise<boolean> {
    return ((await this.c.query(sql, v)).rowCount ?? 0) > 0;
  }
  parceiroAtivo(id: string) { return this.existe("SELECT 1 FROM cadastros_parceiros WHERE id = $1 AND estado = 'ativo' AND deleted_at IS NULL", [id]); }
  contaFinanceiraAtiva(id: string) { return this.existe('SELECT 1 FROM financeiro_contas WHERE id = $1 AND ativa AND deleted_at IS NULL', [id]); }
  categoriaAtiva(id: string) { return this.existe('SELECT 1 FROM financeiro_categorias WHERE id = $1 AND ativa AND deleted_at IS NULL', [id]); }
  centroAtivo(id: string) { return this.existe('SELECT 1 FROM financeiro_centros_custo WHERE id = $1 AND ativo AND deleted_at IS NULL', [id]); }
  documentoDoParceiro(id: string, parceiroId: string) {
    return this.existe("SELECT 1 FROM contas_documentos WHERE id = $1 AND parceiro_id = $2 AND tipo = 'fatura' AND deleted_at IS NULL", [id, parceiroId]);
  }

  async inserirBaixa(b: BaixaDados): Promise<void> {
    await this.c.query(
      `INSERT INTO contas_baixas (id, documento_id, data, valor_centavos, juros_centavos, multa_centavos, desconto_centavos, total_centavos,
         forma, conta_financeira_id, origem, id_externo, chave_idempotencia, creator_id)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, nucleo_usuario_atual())`,
      [b.id, b.documento_id, b.data, b.valor_centavos, b.juros_centavos, b.multa_centavos, b.desconto_centavos, b.total_centavos,
        b.forma, b.conta_financeira_id, b.origem, b.id_externo, b.chave_idempotencia],
    );
  }

  async baixaRepetida(chave: string | null, idExterno: string | null): Promise<BaixaDados | null> {
    const r = await this.c.query(
      `SELECT ${COLUNAS_BAIXA} FROM contas_baixas WHERE (chave_idempotencia = $1 OR id_externo = $2) LIMIT 1`, [chave, idExterno]);
    return (r.rows[0] as BaixaDados) ?? null;
  }
}
