/**
 * Baixar (M5.2) e CancelarDocumento (M5.6), mais VerificarVencimento (job do aviso de vencido, M5.8).
 * Cada baixa grava a linha em contas_baixas e publica `fatura.paga`; o Financeiro reage com
 * `financeiro:ao:fatura.paga` e registra o lancamento realizado (CONTRATOS 7.1.4). Baixa idempotente pela
 * Idempotency-Key ou pelo id externo do provedor (webhook Pix e boleto, M5.5).
 */
import { randomUUID } from 'node:crypto';
import type { GravarCobranca } from '../../cobranca/model/portas.ts';
import type { ContextoCaso } from '../../compartilhado/efeitos.ts';
import { erroDe, fail, ok, okVazio, type Result } from '../../compartilhado/result.ts';
import { diasEntre, hojeIso } from '../../compartilhado/valores.ts';
import type { EntradaBaixa } from '../model/documento.ts';
import type { BaixaDados, ConsultarReferenciasDocumento, GravarBaixa, GravarDocumento, ObterDocumento } from '../model/portas.ts';

export interface EntradaBaixar extends EntradaBaixa {
  documento_id: string;
  conta_financeira_id?: string | null;
  chave_idempotencia?: string | null;
  id_externo?: string | null;
  origem?: BaixaDados['origem'];
}

export interface DepsBaixar {
  repo: ObterDocumento & GravarDocumento;
  baixas: GravarBaixa;
  refs: ConsultarReferenciasDocumento;
  cobrancas: Pick<GravarCobranca, 'cancelarAgendadas'>;
  hoje?: () => string;
}

export class Baixar {
  constructor(private readonly deps: DepsBaixar) {}

  async execute(ctx: ContextoCaso, e: EntradaBaixar): Promise<Result<{ baixa_id: string; documento_id: string; repetido: boolean }>> {
    const chave = e.chave_idempotencia?.trim() || null;
    const externo = e.id_externo?.trim() || null;
    if (chave || externo) {
      const ja = await this.deps.baixas.baixaRepetida(chave, externo);
      if (ja) return ok({ baixa_id: ja.id, documento_id: ja.documento_id, repetido: true });
    }
    const atual = await this.deps.repo.obterPorId(e.documento_id);
    if (!atual) return fail(erroDe('nao_encontrado', 'Documento nao encontrado'));
    const hoje = (this.deps.hoje ?? hojeIso)();
    const r = atual.baixar(e, hoje);
    if (!r.ok) return r;
    const antes = atual.paraDados();
    const depois = r.valor.documento.paraDados();
    const conta = e.conta_financeira_id?.trim() || antes.conta_financeira_id;
    if (conta && conta !== antes.conta_financeira_id && !(await this.deps.refs.contaFinanceiraAtiva(conta))) {
      return fail(erroDe('conta_invalida', 'Conta financeira nao encontrada ou inativa', 'conta_financeira_id'));
    }
    const b = r.valor.baixa;
    const baixa: BaixaDados = {
      id: randomUUID(), documento_id: antes.id, data: b.data, valor_centavos: b.valor_centavos, juros_centavos: b.juros_centavos,
      multa_centavos: b.multa_centavos, desconto_centavos: b.desconto_centavos, total_centavos: b.total_centavos, forma: b.forma,
      conta_financeira_id: conta ?? null, origem: e.origem ?? 'manual', id_externo: externo, chave_idempotencia: chave,
    };
    await this.deps.baixas.inserirBaixa(baixa);
    await this.deps.repo.atualizar(r.valor.documento);
    if (b.quitado) await this.deps.cobrancas.cancelarAgendadas(antes.id);
    const resumo = (x: typeof antes) => ({ estado: x.estado, pago_centavos: x.pago_centavos, saldo_centavos: x.saldo_centavos, pago_em: x.pago_em });
    await ctx.efeitos.historico('contas_documentos', antes.id, resumo(antes), resumo(depois));
    await ctx.efeitos.auditar('documento.baixar', 'contas_documentos', antes.id, resumo(antes), { ...resumo(depois), baixa });
    const sinal = r.valor.documento.natureza === 'receber' ? 1 : -1;
    await ctx.efeitos.publicar('fatura.paga', {
      id: antes.id, baixa_id: baixa.id, tipo: antes.tipo, numero: antes.numero, parceiro_id: antes.parceiro_id,
      natureza: r.valor.documento.natureza, valor_pago_centavos: sinal * b.total_centavos, principal_centavos: b.valor_centavos,
      juros_centavos: b.juros_centavos, multa_centavos: b.multa_centavos, desconto_centavos: b.desconto_centavos,
      saldo_centavos: depois.saldo_centavos, quitado: b.quitado, data_pagamento: b.data, forma: b.forma, moeda: antes.moeda,
      conta_financeira_id: baixa.conta_financeira_id, categoria_id: antes.categoria_id, centro_custo_id: antes.centro_custo_id, origem: baixa.origem,
    });
    return ok({ baixa_id: baixa.id, documento_id: antes.id, repetido: false });
  }
}

export class CancelarDocumento {
  constructor(private readonly deps: { repo: ObterDocumento & GravarDocumento; cobrancas: Pick<GravarCobranca, 'cancelarAgendadas'> }) {}
  async execute(ctx: ContextoCaso, e: { id: string; motivo?: string | null }): Promise<Result<void>> {
    const atual = await this.deps.repo.obterPorId(e.id);
    if (!atual) return fail(erroDe('nao_encontrado', 'Documento nao encontrado'));
    const r = atual.cancelar(e.motivo);
    if (!r.ok) return r;
    await this.deps.repo.atualizar(r.valor);
    const n = await this.deps.cobrancas.cancelarAgendadas(e.id);
    const de = { estado: atual.estado };
    const para = { estado: r.valor.estado, cancelado_motivo: r.valor.paraDados().cancelado_motivo, cobrancas_canceladas: n };
    await ctx.efeitos.historico('contas_documentos', e.id, de, para);
    await ctx.efeitos.auditar('documento.cancelar', 'contas_documentos', e.id, de, para);
    return okVazio();
  }
}

/**
 * Job `contas.verificar_vencimento`: no dia seguinte ao vencimento, se o documento segue aberto e o aviso
 * ainda nao saiu, marca e publica `fatura.vencida`. Documento pago, cancelado ou com vencimento novo: nada.
 */
export class VerificarVencimento {
  constructor(private readonly deps: { repo: ObterDocumento & GravarDocumento; hoje?: () => string }) {}
  async execute(ctx: ContextoCaso, e: { documento_id: string }): Promise<Result<{ publicado: boolean }>> {
    const atual = await this.deps.repo.obterPorId(e.documento_id);
    if (!atual) return ok({ publicado: false });
    const hoje = (this.deps.hoje ?? hojeIso)();
    const r = atual.marcarVencida(hoje);
    if (!r.ok) return ok({ publicado: false });
    await this.deps.repo.atualizar(r.valor);
    const d = r.valor.paraDados();
    await ctx.efeitos.auditar('documento.vencido', 'contas_documentos', d.id, { vencida_em: null }, { vencida_em: d.vencida_em });
    await ctx.efeitos.nota('contas_documentos', d.id, `Documento ${d.numero} vencido em ${d.vencimento}, saldo ${(d.saldo_centavos / 100).toFixed(2)} ${d.moeda}.`);
    await ctx.efeitos.publicar('fatura.vencida', {
      id: d.id, tipo: d.tipo, numero: d.numero, parceiro_id: d.parceiro_id, natureza: atual.natureza, vencimento: d.vencimento,
      saldo_centavos: d.saldo_centavos, moeda: d.moeda, dias_atraso: diasEntre(d.vencimento, hoje),
    });
    return ok({ publicado: true });
  }
}
