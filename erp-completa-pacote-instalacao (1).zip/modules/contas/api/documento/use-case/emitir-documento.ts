/**
 * EmitirDocumento (M5.6): valida, numera pela sequencia do nucleo (N6), grava, publica `fatura.emitida`,
 * agenda o aviso de vencimento e, se for a receber, a regua de cobranca. Idempotente pela
 * Idempotency-Key: a mesma chave devolve o documento ja gravado (repetido = true).
 */
import { agendarRegua } from '../../cobranca/use-case/agendar-regua.ts';
import type { GravarCobranca, LerRegua } from '../../cobranca/model/portas.ts';
import type { ContextoCaso } from '../../compartilhado/efeitos.ts';
import { JOBS, inicioDoDia, type FilaJobs } from '../../compartilhado/fila.ts';
import { erroDe, fail, ok, type ErroDominio, type Result } from '../../compartilhado/result.ts';
import { hojeIso, somarDias } from '../../compartilhado/valores.ts';
import { Documento, SEQUENCIA, type DadosEmissao, type DocumentoDados } from '../model/documento.ts';
import type { BuscarDocumentoPorChave, ConsultarReferenciasDocumento, GravarDocumento, Numeracao, ObterDocumento } from '../model/portas.ts';

export interface DepsEmitir {
  repo: ObterDocumento & GravarDocumento & BuscarDocumentoPorChave;
  numeracao: Numeracao;
  refs: ConsultarReferenciasDocumento;
  cobrancas: GravarCobranca & LerRegua;
  fila: FilaJobs;
  hoje?: () => string;
}

/** Confere as referencias externas (parceiro, conta, categoria, centro, documento de origem). */
export async function conferirReferencias(refs: ConsultarReferenciasDocumento, d: DocumentoDados, anterior?: DocumentoDados): Promise<ErroDominio[]> {
  const e: ErroDominio[] = [];
  const mudou = (k: keyof DocumentoDados) => !anterior || anterior[k] !== d[k];
  if (mudou('parceiro_id') && !(await refs.parceiroAtivo(d.parceiro_id))) e.push(erroDe('parceiro_invalido', 'Parceiro nao encontrado ou arquivado', 'parceiro_id'));
  if (d.conta_financeira_id && mudou('conta_financeira_id') && !(await refs.contaFinanceiraAtiva(d.conta_financeira_id))) e.push(erroDe('conta_invalida', 'Conta financeira nao encontrada ou inativa', 'conta_financeira_id'));
  if (d.categoria_id && mudou('categoria_id') && !(await refs.categoriaAtiva(d.categoria_id))) e.push(erroDe('categoria_invalida', 'Categoria nao encontrada ou inativa', 'categoria_id'));
  if (d.centro_custo_id && mudou('centro_custo_id') && !(await refs.centroAtivo(d.centro_custo_id))) e.push(erroDe('centro_invalido', 'Centro de custo nao encontrado ou inativo', 'centro_custo_id'));
  if (d.documento_origem_id && mudou('documento_origem_id') && !(await refs.documentoDoParceiro(d.documento_origem_id, d.parceiro_id))) {
    e.push(erroDe('origem_invalida', 'Documento de origem nao encontrado para este parceiro', 'documento_origem_id'));
  }
  return e;
}

/** Payload publicado em fatura.emitida (CONTRATOS 7.1.5). */
export const dadosEmitida = (d: DocumentoDados) => ({
  id: d.id, tipo: d.tipo, numero: d.numero, parceiro_id: d.parceiro_id, natureza: d.tipo === 'fatura' ? 'receber' : 'pagar',
  valor_centavos: d.valor_centavos, desconto_centavos: d.desconto_centavos, saldo_centavos: d.saldo_centavos, moeda: d.moeda,
  emissao: d.emissao, vencimento: d.vencimento, recorrencia_id: d.recorrencia_id, competencia: d.competencia,
});

export class EmitirDocumento {
  constructor(private readonly deps: DepsEmitir) {}

  async execute(ctx: ContextoCaso, e: DadosEmissao & { chave_idempotencia?: string | null }): Promise<Result<{ id: string; repetido: boolean }>> {
    const chave = e.chave_idempotencia?.trim() || null;
    if (chave) {
      const ja = await this.deps.repo.porChave(chave);
      if (ja) return ok({ id: ja.id, repetido: true });
    }
    const hoje = (this.deps.hoje ?? hojeIso)();
    const r = Documento.tryCreate(e, undefined, hoje);
    if (!r.ok) return r;
    const erros = await conferirReferencias(this.deps.refs, r.valor.paraDados());
    if (erros.length) return fail(...erros);
    const numero = await this.deps.numeracao.proximoNumero(SEQUENCIA[r.valor.tipo]);
    const doc = r.valor.numerar(numero, chave);
    await this.deps.repo.inserir(doc);
    const d = doc.paraDados();
    await ctx.efeitos.auditar('documento.emitir', 'contas_documentos', d.id, undefined, d);
    await ctx.efeitos.publicar('fatura.emitida', dadosEmitida(d));
    await this.deps.fila.enfileirar(JOBS.verificarVencimento, { documento_id: d.id, vencimento: d.vencimento }, inicioDoDia(somarDias(d.vencimento, 1)));
    if (doc.natureza === 'receber') await agendarRegua(this.deps, { id: d.id, vencimento: d.vencimento }, hoje);
    return ok({ id: d.id, repetido: false });
  }
}

/** EditarDocumento: so em aberto ou parcial; mudar o vencimento reagenda o aviso de vencido. */
export class EditarDocumento {
  constructor(private readonly deps: { repo: ObterDocumento & GravarDocumento; refs: ConsultarReferenciasDocumento; fila: FilaJobs }) {}
  async execute(ctx: ContextoCaso, e: { id: string } & Parameters<Documento['editar']>[0]): Promise<Result<void>> {
    const { id, ...mud } = e;
    const atual = await this.deps.repo.obterPorId(id);
    if (!atual) return fail(erroDe('nao_encontrado', 'Documento nao encontrado'));
    const r = atual.editar(mud);
    if (!r.ok) return r;
    const antes = atual.paraDados();
    const depois = r.valor.paraDados();
    const erros = await conferirReferencias(this.deps.refs, depois, antes);
    if (erros.length) return fail(...erros);
    await this.deps.repo.atualizar(r.valor);
    if (depois.vencimento !== antes.vencimento) {
      await this.deps.fila.enfileirar(JOBS.verificarVencimento, { documento_id: id, vencimento: depois.vencimento }, inicioDoDia(somarDias(depois.vencimento, 1)));
    }
    await ctx.efeitos.historico('contas_documentos', id, antes as unknown as Record<string, unknown>, depois as unknown as Record<string, unknown>);
    await ctx.efeitos.auditar('documento.editar', 'contas_documentos', id, antes, depois);
    return ok(undefined);
  }
}
