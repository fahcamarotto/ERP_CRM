/** Objeto de valor Item do documento: descricao, quantidade e preco unitario em centavos. Total sem float no dinheiro. */
import { combinar, erroDe, fail, ok, type ErroDominio, type Result } from '../../compartilhado/result.ts';
import { Centavos } from '../../compartilhado/valores.ts';

export interface ItemDados {
  descricao: string;
  quantidade: number;
  preco_centavos: number;
}

export class Item {
  private constructor(readonly descricao: string, readonly quantidade: number, readonly precoCentavos: number) {}

  static tryCreate(e: Partial<ItemDados>, i = 0): Result<Item> {
    const erros: ErroDominio[] = [];
    const descricao = (e.descricao ?? '').trim();
    if (descricao.length < 1 || descricao.length > 200) erros.push(erroDe('item_invalido', `Item ${i + 1}: descricao de 1 a 200 caracteres`, `itens.${i}.descricao`));
    const q = Number(e.quantidade ?? 1);
    if (!Number.isFinite(q) || q <= 0 || q > 1_000_000 || Math.round(q * 1000) !== q * 1000) {
      erros.push(erroDe('item_invalido', `Item ${i + 1}: quantidade maior que zero, ate 3 casas`, `itens.${i}.quantidade`));
    }
    const p = Centavos.tryCreate(e.preco_centavos, `itens.${i}.preco_centavos`, false);
    if (!p.ok) erros.push(...p.erros);
    if (erros.length) return fail(...erros);
    return ok(new Item(descricao, q, (p as { ok: true; valor: Centavos }).valor.valor));
  }

  static create(e: ItemDados): Item {
    const r = Item.tryCreate(e);
    if (!r.ok) throw new Error(r.erros[0]!.mensagem);
    return r.valor;
  }

  static lista(itens: Partial<ItemDados>[]): Result<Item[]> {
    if (itens.length > 200) return fail(erroDe('item_invalido', 'No maximo 200 itens', 'itens'));
    return combinar(...itens.map((x, i) => Item.tryCreate(x, i))) as Result<Item[]>;
  }

  /** Total do item em centavos (arredondamento bancario simples ao centavo). */
  get totalCentavos(): number { return Math.round(this.quantidade * this.precoCentavos); }

  paraDados(): ItemDados { return { descricao: this.descricao, quantidade: this.quantidade, preco_centavos: this.precoCentavos }; }
}
