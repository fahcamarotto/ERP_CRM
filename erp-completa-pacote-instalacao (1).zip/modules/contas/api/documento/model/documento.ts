/**
 * Agregado Documento (M5.1): fatura, conta a pagar, nota de credito e reembolso na mesma tabela (campo tipo),
 * com numero por sequencia, parceiro, itens, vencimento, condicao de pagamento, valor, juros, multa, desconto
 * e estado. Baixa parcial e total (M5.2) e cancelamento pela maquina de estados. Imutavel: toda mudanca
 * devolve um clone novo.
 */
import { randomUUID } from 'node:crypto';
import { erroDe, fail, ok, type ErroDominio, type Result } from '../../compartilhado/result.ts';
import { Centavos, DataIso, Moeda, diasEntre, hojeIso, somarDias } from '../../compartilhado/valores.ts';
import { Item, type ItemDados } from './item.ts';

export const TIPOS_DOCUMENTO = ['fatura', 'conta_pagar', 'nota_credito', 'reembolso'] as const;
export type TipoDocumento = (typeof TIPOS_DOCUMENTO)[number];

/** Receber entra no caixa; pagar sai. Nota de credito e credito devolvido ao cliente (sai). */
export const NATUREZA: Record<TipoDocumento, 'receber' | 'pagar'> = { fatura: 'receber', conta_pagar: 'pagar', nota_credito: 'pagar', reembolso: 'pagar' };

/** Codigo da sequencia do nucleo (N6) por tipo: FATURA-000001, CONTA-PAGAR-000001... */
export const SEQUENCIA: Record<TipoDocumento, string> = { fatura: 'fatura', conta_pagar: 'conta-pagar', nota_credito: 'nota-credito', reembolso: 'reembolso' };

export const ESTADOS_DOCUMENTO = ['em_aberto', 'parcial', 'pago', 'cancelado'] as const;
export type EstadoDocumento = (typeof ESTADOS_DOCUMENTO)[number];

/** Maquina de estados. Pago e cancelado sao finais; parcial so sai por nova baixa. */
export const TRANSICOES: Record<EstadoDocumento, EstadoDocumento[]> = {
  em_aberto: ['parcial', 'pago', 'cancelado'],
  parcial: ['parcial', 'pago'],
  pago: [],
  cancelado: [],
};

/** Condicao de pagamento: dias entre emissao e vencimento. `personalizada` usa o vencimento informado. */
export const CONDICOES: Record<string, number | null> = { a_vista: 0, '7_dias': 7, '15_dias': 15, '30_dias': 30, '45_dias': 45, '60_dias': 60, '90_dias': 90, personalizada: null };
export type CondicaoPagamento = keyof typeof CONDICOES;

export const FORMAS_BAIXA = ['pix', 'boleto', 'dinheiro', 'transferencia', 'cartao', 'outro'] as const;
export type FormaBaixa = (typeof FORMAS_BAIXA)[number];

export interface DadosEmissao {
  tipo: TipoDocumento;
  parceiro_id: string;
  descricao?: string | null;
  emissao?: string | null;
  vencimento?: string | null;
  condicao_pagamento?: string | null;
  moeda?: string | null;
  itens?: Partial<ItemDados>[] | null;
  /** Usado quando nao ha itens; com itens o valor e a soma deles. */
  valor_centavos?: number | null;
  desconto_centavos?: number | null;
  multa_pct?: number | null;
  juros_mes_pct?: number | null;
  categoria_id?: string | null;
  centro_custo_id?: string | null;
  conta_financeira_id?: string | null;
  documento_origem_id?: string | null;
  recorrencia_id?: string | null;
  competencia?: string | null;
  observacoes?: string | null;
  extras?: Record<string, unknown>;
}

export type EdicaoDocumento = Partial<Pick<DadosEmissao, 'descricao' | 'vencimento' | 'observacoes' | 'categoria_id' | 'centro_custo_id' | 'conta_financeira_id' | 'multa_pct' | 'juros_mes_pct' | 'extras'>>;

export interface DocumentoDados {
  id: string;
  tipo: TipoDocumento;
  numero: string | null;
  parceiro_id: string;
  descricao: string | null;
  emissao: string;
  vencimento: string;
  condicao_pagamento: CondicaoPagamento;
  moeda: string;
  itens: ItemDados[];
  valor_centavos: number;
  desconto_centavos: number;
  multa_pct: number;
  juros_mes_pct: number;
  pago_centavos: number;
  saldo_centavos: number;
  estado: EstadoDocumento;
  categoria_id: string | null;
  centro_custo_id: string | null;
  conta_financeira_id: string | null;
  documento_origem_id: string | null;
  recorrencia_id: string | null;
  competencia: string | null;
  observacoes: string | null;
  cancelado_motivo: string | null;
  pago_em: string | null;
  vencida_em: string | null;
  chave_idempotencia: string | null;
  extras: Record<string, unknown>;
}

export interface EntradaBaixa {
  valor_centavos?: number | null;
  data?: string | null;
  juros_centavos?: number | null;
  multa_centavos?: number | null;
  desconto_centavos?: number | null;
  forma?: string | null;
}

export interface Encargos { dias_atraso: number; multa_centavos: number; juros_centavos: number }

const t = (v?: string | null) => (v ?? '').trim() || null;
const pct = (v: unknown) => (v === undefined || v === null ? 0 : Math.round(Number(v) * 100) / 100);

function validar(d: DocumentoDados): ErroDominio[] {
  const e: ErroDominio[] = [];
  if (!TIPOS_DOCUMENTO.includes(d.tipo)) e.push(erroDe('tipo_invalido', 'Tipo deve ser fatura, conta_pagar, nota_credito ou reembolso', 'tipo'));
  if (!d.parceiro_id) e.push(erroDe('parceiro_obrigatorio', 'Informe o parceiro (cliente ou fornecedor)', 'parceiro_id'));
  if (d.descricao && d.descricao.length > 200) e.push(erroDe('descricao_invalida', 'Descricao com ate 200 caracteres', 'descricao'));
  if (d.observacoes && d.observacoes.length > 2000) e.push(erroDe('observacoes_invalidas', 'Observacoes com ate 2000 caracteres', 'observacoes'));
  for (const [campo, v] of [['emissao', d.emissao], ['vencimento', d.vencimento]] as const) {
    const r = DataIso.tryCreate(v, campo);
    if (!r.ok) e.push(...r.erros);
  }
  if (d.competencia) { const r = DataIso.tryCreate(d.competencia, 'competencia'); if (!r.ok) e.push(...r.erros); }
  if (!e.some((x) => x.campo === 'vencimento' || x.campo === 'emissao') && d.vencimento < d.emissao) e.push(erroDe('vencimento_invalido', 'Vencimento antes da emissao', 'vencimento'));
  if (!(d.condicao_pagamento in CONDICOES)) e.push(erroDe('condicao_invalida', 'Condicao de pagamento invalida', 'condicao_pagamento'));
  const m = Moeda.tryCreate(d.moeda);
  if (!m.ok) e.push(...m.erros);
  const v = Centavos.tryCreate(d.valor_centavos, 'valor_centavos');
  if (!v.ok) e.push(...v.erros);
  const desc = Centavos.tryCreate(d.desconto_centavos, 'desconto_centavos', false);
  if (!desc.ok) e.push(...desc.erros);
  if (v.ok && desc.ok && d.desconto_centavos >= d.valor_centavos) e.push(erroDe('desconto_invalido', 'Desconto deve ser menor que o valor', 'desconto_centavos'));
  if (!Number.isFinite(d.multa_pct) || d.multa_pct < 0 || d.multa_pct > 20) e.push(erroDe('multa_invalida', 'Multa de 0 a 20%', 'multa_pct'));
  if (!Number.isFinite(d.juros_mes_pct) || d.juros_mes_pct < 0 || d.juros_mes_pct > 10) e.push(erroDe('juros_invalidos', 'Juros de 0 a 10% ao mes', 'juros_mes_pct'));
  if (d.tipo !== 'nota_credito' && d.documento_origem_id) e.push(erroDe('origem_invalida', 'Documento de origem so vale para nota de credito', 'documento_origem_id'));
  return e;
}

export class Documento {
  private constructor(private readonly d: DocumentoDados) {}

  static tryCreate(e: DadosEmissao, id: string = randomUUID(), hoje: string = hojeIso()): Result<Documento> {
    const erros: ErroDominio[] = [];
    let itens: ItemDados[] = [];
    let valor = e.valor_centavos ?? 0;
    if (e.itens && e.itens.length) {
      const r = Item.lista(e.itens);
      if (!r.ok) erros.push(...r.erros);
      else { itens = r.valor.map((i) => i.paraDados()); valor = r.valor.reduce((s, i) => s + i.totalCentavos, 0); }
    } else if (e.valor_centavos === undefined || e.valor_centavos === null) {
      erros.push(erroDe('valor_obrigatorio', 'Informe os itens ou o valor em centavos', 'valor_centavos'));
    }
    const emissao = t(e.emissao) ?? hoje;
    const condicao = (t(e.condicao_pagamento) ?? (t(e.vencimento) ? 'personalizada' : 'a_vista')) as CondicaoPagamento;
    const dias = CONDICOES[condicao];
    const vencimento = t(e.vencimento) ?? (dias === null || dias === undefined || !DataIso.tryCreate(emissao).ok ? '' : somarDias(emissao, dias));
    const desconto = e.desconto_centavos ?? 0;
    const d: DocumentoDados = {
      id, tipo: e.tipo, numero: null, parceiro_id: t(e.parceiro_id) ?? '', descricao: t(e.descricao), emissao, vencimento, condicao_pagamento: condicao,
      moeda: (t(e.moeda) ?? 'BRL').toUpperCase(), itens, valor_centavos: valor, desconto_centavos: desconto,
      multa_pct: pct(e.multa_pct), juros_mes_pct: pct(e.juros_mes_pct), pago_centavos: 0, saldo_centavos: valor - desconto, estado: 'em_aberto',
      categoria_id: t(e.categoria_id), centro_custo_id: t(e.centro_custo_id), conta_financeira_id: t(e.conta_financeira_id),
      documento_origem_id: t(e.documento_origem_id), recorrencia_id: t(e.recorrencia_id), competencia: t(e.competencia),
      observacoes: t(e.observacoes), cancelado_motivo: null, pago_em: null, vencida_em: null, chave_idempotencia: null, extras: e.extras ?? {},
    };
    erros.push(...validar(d).filter((x) => !(erros.some((y) => y.campo === 'valor_centavos') && x.campo === 'valor_centavos')));
    return erros.length ? fail(...erros) : ok(new Documento(d));
  }

  static create(e: DadosEmissao, id?: string, hoje?: string): Documento {
    const r = Documento.tryCreate(e, id, hoje);
    if (!r.ok) throw new Error(r.erros.map((x) => x.mensagem).join('; '));
    return r.valor;
  }

  static reidratar(d: DocumentoDados): Documento {
    return new Documento({ ...d, itens: d.itens.map((i) => ({ ...i })), extras: { ...d.extras }, multa_pct: Number(d.multa_pct), juros_mes_pct: Number(d.juros_mes_pct) });
  }

  get id(): string { return this.d.id; }
  get tipo(): TipoDocumento { return this.d.tipo; }
  get estado(): EstadoDocumento { return this.d.estado; }
  get natureza(): 'receber' | 'pagar' { return NATUREZA[this.d.tipo]; }
  get saldoCentavos(): number { return this.d.saldo_centavos; }
  get vencimento(): string { return this.d.vencimento; }
  get aberto(): boolean { return this.d.estado === 'em_aberto' || this.d.estado === 'parcial'; }

  /** Atrasado: aberto e vencimento antes de hoje. */
  atrasado(hoje: string = hojeIso()): boolean { return this.aberto && this.d.vencimento < hoje; }

  /** Numero atribuido pela sequencia do nucleo depois de validado (N6, sem buraco). */
  numerar(numero: string, chave: string | null = null): Documento {
    return new Documento({ ...this.paraDados(), numero, chave_idempotencia: chave });
  }

  /** Multa (uma vez) e juros simples pro rata dia sobre o saldo, se pago depois do vencimento. */
  encargos(data: string): Encargos {
    const dias = Math.max(0, diasEntre(this.d.vencimento, data));
    if (!dias || !this.aberto) return { dias_atraso: dias, multa_centavos: 0, juros_centavos: 0 };
    return {
      dias_atraso: dias,
      multa_centavos: Math.round((this.d.saldo_centavos * this.d.multa_pct) / 100),
      juros_centavos: Math.round((this.d.saldo_centavos * this.d.juros_mes_pct * dias) / 3000),
    };
  }

  private transicao(novo: EstadoDocumento): ErroDominio | null {
    return TRANSICOES[this.d.estado].includes(novo) ? null
      : erroDe('transicao_invalida', `Documento ${this.d.estado} nao pode ir para ${novo}`, 'estado', { permitidas: TRANSICOES[this.d.estado] });
  }

  /**
   * Baixa parcial ou total (M5.2). `valor_centavos` amortiza o saldo (padrao: o saldo todo);
   * juros e multa somam no caixa, desconto abate. Devolve o documento novo e o total movimentado.
   */
  baixar(e: EntradaBaixa, hoje: string = hojeIso()): Result<{ documento: Documento; baixa: { data: string; valor_centavos: number; juros_centavos: number; multa_centavos: number; desconto_centavos: number; total_centavos: number; forma: FormaBaixa; quitado: boolean } }> {
    if (!this.aberto) return fail(erroDe('transicao_invalida', `Documento ${this.d.estado} nao aceita baixa`, 'estado', { permitidas: TRANSICOES[this.d.estado] }));
    const erros: ErroDominio[] = [];
    const valor = e.valor_centavos ?? this.d.saldo_centavos;
    const rv = Centavos.tryCreate(valor, 'valor_centavos');
    if (!rv.ok) erros.push(...rv.erros);
    else if (valor > this.d.saldo_centavos) erros.push(erroDe('valor_acima_do_saldo', 'Valor da baixa maior que o saldo em aberto', 'valor_centavos', { saldo_centavos: this.d.saldo_centavos }));
    const extras = { juros_centavos: e.juros_centavos ?? 0, multa_centavos: e.multa_centavos ?? 0, desconto_centavos: e.desconto_centavos ?? 0 };
    for (const [k, v] of Object.entries(extras)) { const r = Centavos.tryCreate(v, k, false); if (!r.ok) erros.push(...r.erros); }
    const data = t(e.data) ?? hoje;
    const rd = DataIso.tryCreate(data, 'data');
    if (!rd.ok) erros.push(...rd.erros);
    else if (data < this.d.emissao) erros.push(erroDe('data_invalida', 'Data da baixa antes da emissao', 'data'));
    const forma = (t(e.forma) ?? 'transferencia') as FormaBaixa;
    if (!FORMAS_BAIXA.includes(forma)) erros.push(erroDe('forma_invalida', 'Forma deve ser pix, boleto, dinheiro, transferencia, cartao ou outro', 'forma'));
    const total = valor + extras.juros_centavos + extras.multa_centavos - extras.desconto_centavos;
    if (!erros.length && total <= 0) erros.push(erroDe('desconto_invalido', 'Desconto nao pode zerar o valor recebido', 'desconto_centavos'));
    if (erros.length) return fail(...erros);
    const saldo = this.d.saldo_centavos - valor;
    const novo: EstadoDocumento = saldo === 0 ? 'pago' : 'parcial';
    const tr = this.transicao(novo);
    if (tr) return fail(tr);
    const documento = new Documento({ ...this.paraDados(), pago_centavos: this.d.pago_centavos + valor, saldo_centavos: saldo, estado: novo, pago_em: saldo === 0 ? data : null });
    return ok({ documento, baixa: { data, valor_centavos: valor, ...extras, total_centavos: total, forma, quitado: saldo === 0 } });
  }

  cancelar(motivo?: string | null): Result<Documento> {
    const tr = this.transicao('cancelado');
    if (tr) return fail(tr);
    return ok(new Documento({ ...this.paraDados(), estado: 'cancelado', cancelado_motivo: t(motivo)?.slice(0, 500) ?? null }));
  }

  /** Marca que o aviso de vencido ja saiu (fatura.vencida publicado uma vez por vencimento). */
  marcarVencida(hoje: string = hojeIso()): Result<Documento> {
    if (!this.atrasado(hoje)) return fail(erroDe('nao_vencido', 'Documento nao esta vencido'));
    if (this.d.vencida_em) return fail(erroDe('conflito', 'Vencimento ja notificado'));
    return ok(new Documento({ ...this.paraDados(), vencida_em: hoje }));
  }

  editar(e: EdicaoDocumento): Result<Documento> {
    if (!this.aberto) return fail(erroDe('transicao_invalida', `Documento ${this.d.estado} nao pode ser editado`, 'estado'));
    const tem = (k: keyof EdicaoDocumento) => e[k] !== undefined;
    const vencimento = tem('vencimento') ? (t(e.vencimento) ?? '') : this.d.vencimento;
    const n: DocumentoDados = {
      ...this.paraDados(),
      descricao: tem('descricao') ? t(e.descricao) : this.d.descricao,
      vencimento,
      condicao_pagamento: tem('vencimento') && vencimento !== this.d.vencimento ? 'personalizada' : this.d.condicao_pagamento,
      vencida_em: vencimento !== this.d.vencimento ? null : this.d.vencida_em,
      observacoes: tem('observacoes') ? t(e.observacoes) : this.d.observacoes,
      categoria_id: tem('categoria_id') ? t(e.categoria_id) : this.d.categoria_id,
      centro_custo_id: tem('centro_custo_id') ? t(e.centro_custo_id) : this.d.centro_custo_id,
      conta_financeira_id: tem('conta_financeira_id') ? t(e.conta_financeira_id) : this.d.conta_financeira_id,
      multa_pct: tem('multa_pct') ? pct(e.multa_pct) : this.d.multa_pct,
      juros_mes_pct: tem('juros_mes_pct') ? pct(e.juros_mes_pct) : this.d.juros_mes_pct,
      extras: tem('extras') ? { ...e.extras } : { ...this.d.extras },
    };
    const erros = validar(n);
    return erros.length ? fail(...erros) : ok(new Documento(n));
  }

  paraDados(): DocumentoDados {
    return { ...this.d, itens: this.d.itens.map((i) => ({ ...i })), extras: { ...this.d.extras } };
  }
}
