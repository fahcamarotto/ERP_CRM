/** Portas do agregado Documento, segregadas por operacao. */
import type { Documento, FormaBaixa } from './documento.ts';

export interface ObterDocumento {
  obterPorId(id: string): Promise<Documento | null>;
}

export interface GravarDocumento {
  inserir(d: Documento): Promise<void>;
  atualizar(d: Documento): Promise<void>;
}

/** Idempotency-Key da emissao: a mesma chave devolve o documento ja gravado. */
export interface BuscarDocumentoPorChave {
  porChave(chave: string): Promise<Documento | null>;
}

/** N6: numero sem buraco por tipo (sequencia do nucleo). */
export interface Numeracao {
  proximoNumero(codigo: string): Promise<string>;
}

/** Referencias fora do agregado: parceiro (Cadastros) e conta, categoria e centro (Financeiro), so leitura publicada. */
export interface ConsultarReferenciasDocumento {
  parceiroAtivo(id: string): Promise<boolean>;
  contaFinanceiraAtiva(id: string): Promise<boolean>;
  categoriaAtiva(id: string): Promise<boolean>;
  centroAtivo(id: string): Promise<boolean>;
  documentoDoParceiro(id: string, parceiroId: string): Promise<boolean>;
}

export interface BaixaDados {
  id: string;
  documento_id: string;
  data: string;
  valor_centavos: number;
  juros_centavos: number;
  multa_centavos: number;
  desconto_centavos: number;
  total_centavos: number;
  forma: FormaBaixa;
  conta_financeira_id: string | null;
  origem: 'manual' | 'webhook' | 'seed';
  id_externo: string | null;
  chave_idempotencia: string | null;
}

export interface GravarBaixa {
  inserirBaixa(b: BaixaDados): Promise<void>;
  /** Baixa ja gravada com a mesma Idempotency-Key ou o mesmo id externo do provedor (webhook). */
  baixaRepetida(chave: string | null, idExterno: string | null): Promise<BaixaDados | null>;
}
