/**
 * Consultas de leitura do Documento: lista por aba com atraso calculado, ficha com baixas e cobrancas,
 * vencidos, resumo por aba e opcoes dos seletores (tabelas publicadas de Cadastros e Financeiro).
 */
import type pg from 'pg';
import { decodificarCursor, pagina } from '../../compartilhado/cursor.ts';

/** Tipos de documento de cada aba do modulo. */
export const TIPOS_DA_ABA: Record<string, string[]> = {
  'a-receber': ['fatura'],
  'a-pagar': ['conta_pagar', 'reembolso'],
  'notas-credito': ['nota_credito'],
};

const RESUMO = `d.id, d.tipo, d.numero, d.parceiro_id, coalesce(p.nome_fantasia, p.nome) AS parceiro_nome, d.descricao,
  to_char(d.emissao, 'YYYY-MM-DD') AS emissao, to_char(d.vencimento, 'YYYY-MM-DD') AS vencimento, d.condicao_pagamento, d.moeda,
  d.valor_centavos::float8 AS valor_centavos, d.desconto_centavos::float8 AS desconto_centavos, d.pago_centavos::float8 AS pago_centavos,
  d.saldo_centavos::float8 AS saldo_centavos, d.estado, to_char(d.pago_em, 'YYYY-MM-DD') AS pago_em, d.recorrencia_id,
  (d.estado IN ('em_aberto', 'parcial') AND d.vencimento < current_date) AS atrasado,
  CASE WHEN d.estado IN ('em_aberto', 'parcial') AND d.vencimento < current_date THEN current_date - d.vencimento ELSE 0 END AS dias_atraso,
  d.created_at, d.updated_at`;

const JUNCOES = `FROM contas_documentos d LEFT JOIN cadastros_parceiros p ON p.id = d.parceiro_id`;

export interface FiltroDocumentos {
  aba?: string;
  tipo?: string;
  estado?: string;
  situacao?: 'abertos' | 'atrasados' | 'pagos' | 'cancelados';
  parceiro_id?: string;
  busca?: string;
  vence_ate?: string;
  limite?: number;
  cursor?: string;
}

const SITUACAO: Record<string, string> = {
  abertos: "d.estado IN ('em_aberto', 'parcial')",
  atrasados: "d.estado IN ('em_aberto', 'parcial') AND d.vencimento < current_date",
  pagos: "d.estado = 'pago'",
  cancelados: "d.estado = 'cancelado'",
};

export async function listarDocumentos(c: pg.PoolClient, f: FiltroDocumentos) {
  const lim = Math.min(Math.max(f.limite ?? 50, 1), 200);
  const cur = decodificarCursor(f.cursor);
  const tipos = f.tipo ? [f.tipo] : f.aba ? TIPOS_DA_ABA[f.aba] ?? [] : null;
  const r = await c.query(
    `SELECT ${RESUMO} ${JUNCOES}
     WHERE d.deleted_at IS NULL AND ($1::text[] IS NULL OR d.tipo = ANY ($1)) AND ($2::text IS NULL OR d.estado = $2)
       AND ($3::uuid IS NULL OR d.parceiro_id = $3) AND ($4::date IS NULL OR d.vencimento <= $4)
       AND ($5::text IS NULL OR d.numero ILIKE '%' || $5 || '%' OR p.nome ILIKE '%' || $5 || '%' OR d.descricao ILIKE '%' || $5 || '%')
       AND ${f.situacao && SITUACAO[f.situacao] ? SITUACAO[f.situacao] : 'true'}
       AND ($6::timestamptz IS NULL OR (d.created_at, d.id) > ($6::timestamptz, $7::uuid))
     ORDER BY d.created_at, d.id LIMIT $8`,
    [tipos, f.estado ?? null, f.parceiro_id ?? null, f.vence_ate ?? null, f.busca?.trim() || null, cur?.[0] ?? null, cur?.[1] ?? null, lim + 1],
  );
  return pagina(r.rows, lim);
}

export async function obterDocumento(c: pg.PoolClient, id: string) {
  const r = await c.query(
    `SELECT ${RESUMO}, d.itens, d.multa_pct::float8 AS multa_pct, d.juros_mes_pct::float8 AS juros_mes_pct, d.categoria_id, d.centro_custo_id,
       d.conta_financeira_id, d.documento_origem_id, to_char(d.competencia, 'YYYY-MM-DD') AS competencia, d.observacoes, d.cancelado_motivo,
       to_char(d.vencida_em, 'YYYY-MM-DD') AS vencida_em, d.extras, p.email::text AS parceiro_email, p.telefone AS parceiro_telefone,
       o.numero AS documento_origem_numero, k.nome AS conta_financeira_nome, g.nome AS categoria_nome, cc.nome AS centro_custo_nome,
       CASE WHEN d.estado IN ('em_aberto', 'parcial') AND d.vencimento < current_date
            THEN round(d.saldo_centavos * d.multa_pct / 100)::float8 ELSE 0 END AS multa_sugerida_centavos,
       CASE WHEN d.estado IN ('em_aberto', 'parcial') AND d.vencimento < current_date
            THEN round(d.saldo_centavos * d.juros_mes_pct * (current_date - d.vencimento) / 3000)::float8 ELSE 0 END AS juros_sugeridos_centavos,
       coalesce((SELECT json_agg(json_build_object('id', b.id, 'data', to_char(b.data, 'YYYY-MM-DD'), 'valor_centavos', b.valor_centavos,
                  'juros_centavos', b.juros_centavos, 'multa_centavos', b.multa_centavos, 'desconto_centavos', b.desconto_centavos,
                  'total_centavos', b.total_centavos, 'forma', b.forma, 'origem', b.origem) ORDER BY b.data, b.created_at)
                 FROM contas_baixas b WHERE b.documento_id = d.id AND b.deleted_at IS NULL), '[]') AS baixas,
       coalesce((SELECT json_agg(json_build_object('id', x.id, 'canal', x.canal, 'etapa', x.etapa, 'agendada_para', x.agendada_para,
                  'estado', x.estado, 'destino', x.destino, 'erro', x.erro, 'enviada_em', x.enviada_em) ORDER BY x.agendada_para)
                 FROM contas_cobrancas x WHERE x.documento_id = d.id AND x.deleted_at IS NULL), '[]') AS cobrancas
     ${JUNCOES}
       LEFT JOIN contas_documentos o ON o.id = d.documento_origem_id
       LEFT JOIN financeiro_contas k ON k.id = d.conta_financeira_id
       LEFT JOIN financeiro_categorias g ON g.id = d.categoria_id
       LEFT JOIN financeiro_centros_custo cc ON cc.id = d.centro_custo_id
     WHERE d.id = $1 AND d.deleted_at IS NULL`, [id]);
  return r.rows[0] ?? null;
}

/** Vencidos e ainda abertos (tool faturas.vencidas), do mais atrasado ao mais recente. */
export async function listarVencidas(c: pg.PoolClient, f: { natureza?: 'receber' | 'pagar'; parceiro_id?: string; limite?: number }) {
  const lim = Math.min(Math.max(f.limite ?? 50, 1), 200);
  const tipos = f.natureza === 'pagar' ? ['conta_pagar', 'reembolso', 'nota_credito'] : f.natureza === 'receber' ? ['fatura'] : null;
  const r = await c.query(
    `SELECT ${RESUMO}, p.email::text AS parceiro_email, p.telefone AS parceiro_telefone ${JUNCOES}
     WHERE d.deleted_at IS NULL AND d.estado IN ('em_aberto', 'parcial') AND d.vencimento < current_date
       AND ($1::text[] IS NULL OR d.tipo = ANY ($1)) AND ($2::uuid IS NULL OR d.parceiro_id = $2)
     ORDER BY d.vencimento, d.id LIMIT $3`, [tipos, f.parceiro_id ?? null, lim]);
  const total = r.rows.reduce((s, x) => s + Number(x.saldo_centavos), 0);
  return { itens: r.rows, total_saldo_centavos: total };
}

/** Totais por aba: em aberto, atrasado (quantidade e saldo) e pago no mes. */
export async function resumo(c: pg.PoolClient) {
  const r = await c.query(
    `SELECT CASE WHEN tipo = 'fatura' THEN 'a-receber' WHEN tipo = 'nota_credito' THEN 'notas-credito' ELSE 'a-pagar' END AS aba, moeda,
       count(*) FILTER (WHERE estado IN ('em_aberto', 'parcial'))::int AS abertos,
       coalesce(sum(saldo_centavos) FILTER (WHERE estado IN ('em_aberto', 'parcial')), 0)::float8 AS aberto_centavos,
       count(*) FILTER (WHERE estado IN ('em_aberto', 'parcial') AND vencimento < current_date)::int AS atrasados,
       coalesce(sum(saldo_centavos) FILTER (WHERE estado IN ('em_aberto', 'parcial') AND vencimento < current_date), 0)::float8 AS atrasado_centavos,
       coalesce(sum(pago_centavos) FILTER (WHERE pago_em >= date_trunc('month', current_date)), 0)::float8 AS pago_mes_centavos
     FROM contas_documentos WHERE deleted_at IS NULL GROUP BY 1, 2 ORDER BY 1, 2`);
  return r.rows;
}

/** Opcoes dos seletores: parceiros (Cadastros), contas, categorias e centros (Financeiro), so colunas publicadas. */
export async function opcoes(c: pg.PoolClient) {
  const [parceiros, contas, categorias, centros, faturas] = await Promise.all([
    c.query(`SELECT id, coalesce(nome_fantasia, nome) AS nome, e_cliente, e_fornecedor FROM cadastros_parceiros
             WHERE estado = 'ativo' AND deleted_at IS NULL AND (e_cliente OR e_fornecedor) ORDER BY 2 LIMIT 500`),
    c.query('SELECT id, nome, moeda FROM financeiro_contas WHERE ativa AND deleted_at IS NULL ORDER BY nome'),
    c.query('SELECT id, nome, natureza FROM financeiro_categorias WHERE ativa AND deleted_at IS NULL ORDER BY natureza, nome'),
    c.query('SELECT id, codigo, nome FROM financeiro_centros_custo WHERE ativo AND deleted_at IS NULL ORDER BY codigo'),
    c.query(`SELECT id, numero, parceiro_id FROM contas_documentos WHERE tipo = 'fatura' AND estado <> 'cancelado' AND deleted_at IS NULL ORDER BY created_at DESC LIMIT 300`),
  ]);
  return { parceiros: parceiros.rows, contas: contas.rows, categorias: categorias.rows, centros: centros.rows, faturas: faturas.rows };
}
