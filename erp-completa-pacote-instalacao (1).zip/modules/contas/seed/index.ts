/**
 * Seed demo de Contas: faturas (em aberto, atrasada, parcial, paga, cancelada), contas a pagar,
 * reembolso, nota de credito, recorrencias e a regua de cobranca. Passa pelos mesmos casos de uso da API
 * (numeracao N6, eventos, auditoria, agenda de cobranca). Idempotente: documentos e baixas pela chave
 * `seed:<k>`, recorrencias por id deterministico. Parceiros e contas so por SELECT das tabelas publicadas.
 */
import { createHash } from 'node:crypto';
import type { SeedModulo } from '@erp/api/sdk/puro';
import { REGUA_PADRAO } from '../api/cobranca/model/cobranca.ts';
import { contextoPg } from '../api/compartilhado/efeitos-pg.ts';
import { hojeIso, somarDias } from '../api/compartilhado/valores.ts';
import type { DadosEmissao } from '../api/documento/model/documento.ts';
import { casosDeUso } from '../api/fabrica.ts';
import { RecorrenciaRepoPg } from '../api/recorrencia/adapter/recorrencia-repo-pg.ts';
import type { DadosRecorrencia } from '../api/recorrencia/model/recorrencia.ts';

function idDe(chave: string): string {
  const h = createHash('sha256').update(`contas-demo:${chave}`).digest('hex');
  return `${h.slice(0, 8)}-${h.slice(8, 12)}-4${h.slice(13, 16)}-a${h.slice(17, 20)}-${h.slice(20, 32)}`;
}

const semear: SeedModulo = async ({ c, usuarioId, log }) => {
  const clientes = (await c.query("SELECT id FROM cadastros_parceiros WHERE e_cliente AND estado = 'ativo' AND deleted_at IS NULL ORDER BY created_at, id LIMIT 4")).rows.map((r) => r.id as string);
  const fornecedores = (await c.query("SELECT id FROM cadastros_parceiros WHERE e_fornecedor AND estado = 'ativo' AND deleted_at IS NULL ORDER BY created_at, id LIMIT 2")).rows.map((r) => r.id as string);
  if (!clientes.length || !fornecedores.length) { log('sem clientes ou fornecedores do Cadastros: seed de contas pulado'); return; }
  const conta = ((await c.query("SELECT id FROM financeiro_contas WHERE ativa AND deleted_at IS NULL AND moeda = 'BRL' ORDER BY created_at LIMIT 1")).rows[0]?.id as string) ?? null;
  const cat = async (natureza: string) => ((await c.query('SELECT id FROM financeiro_categorias WHERE natureza = $1 AND ativa AND deleted_at IS NULL ORDER BY created_at LIMIT 1', [natureza])).rows[0]?.id as string) ?? null;
  const receita = await cat('receita');
  const despesa = await cat('despesa');
  const cl = (i: number) => clientes[i % clientes.length]!;
  const fo = (i: number) => fornecedores[i % fornecedores.length]!;
  const H = hojeIso();
  const dia = (n: number) => somarDias(H, n);

  const casos = casosDeUso(c);
  const ctx = contextoPg(c, { tipo: 'usuario', id: usuarioId });
  let novos = 0;

  const regua = await c.query('SELECT 1 FROM contas_reguas WHERE deleted_at IS NULL');
  if (!regua.rowCount) { await casos.configurarRegua.execute(ctx, { ativa: true, etapas: REGUA_PADRAO }); novos++; }

  const docs: { k: string; e: DadosEmissao; baixa?: { valor?: number; data: string; forma: 'pix' | 'boleto' | 'transferencia' }; cancelar?: boolean }[] = [
    { k: 'f1', e: { tipo: 'fatura', parceiro_id: cl(0), descricao: 'Consultoria mensal de processos', emissao: dia(-40), vencimento: dia(-10), multa_pct: 2, juros_mes_pct: 1, categoria_id: receita, conta_financeira_id: conta,
      itens: [{ descricao: 'Consultoria de processos (mês anterior)', quantidade: 1, preco_centavos: 450000 }] } },
    { k: 'f2', e: { tipo: 'fatura', parceiro_id: cl(1), descricao: 'Treinamento da equipe comercial', emissao: dia(-20), condicao_pagamento: '30_dias', categoria_id: receita, conta_financeira_id: conta,
      itens: [{ descricao: 'Turma presencial', quantidade: 2, preco_centavos: 120000 }, { descricao: 'Material didático', quantidade: 1, preco_centavos: 35000 }] } },
    { k: 'f3', e: { tipo: 'fatura', parceiro_id: cl(2), descricao: 'Implantação do sistema', emissao: dia(-35), vencimento: dia(-5), valor_centavos: 890000, multa_pct: 2, juros_mes_pct: 1, categoria_id: receita, conta_financeira_id: conta },
      baixa: { valor: 300000, data: dia(-3), forma: 'pix' } },
    { k: 'f4', e: { tipo: 'fatura', parceiro_id: cl(0), descricao: 'Suporte técnico avulso', emissao: dia(-30), vencimento: dia(-15), valor_centavos: 230000, categoria_id: receita, conta_financeira_id: conta },
      baixa: { data: dia(-16), forma: 'boleto' } },
    { k: 'f5', e: { tipo: 'fatura', parceiro_id: cl(3), descricao: 'Projeto de automação', emissao: dia(-5), condicao_pagamento: '30_dias', valor_centavos: 1500000, desconto_centavos: 50000, categoria_id: receita, conta_financeira_id: conta } },
    { k: 'f6', e: { tipo: 'fatura', parceiro_id: cl(1), descricao: 'Visita técnica (lançada em duplicidade)', emissao: dia(-8), vencimento: dia(7), valor_centavos: 99000 }, cancelar: true },
    { k: 'p1', e: { tipo: 'conta_pagar', parceiro_id: fo(0), descricao: 'Aluguel do escritório', emissao: dia(-25), vencimento: dia(-2), valor_centavos: 620000, categoria_id: despesa, conta_financeira_id: conta } },
    { k: 'p2', e: { tipo: 'conta_pagar', parceiro_id: fo(1), descricao: 'Licenças de software', emissao: dia(-3), vencimento: dia(7), valor_centavos: 185000, categoria_id: despesa, conta_financeira_id: conta } },
    { k: 'p3', e: { tipo: 'conta_pagar', parceiro_id: fo(0), descricao: 'Material de escritório', emissao: dia(-12), vencimento: dia(-6), valor_centavos: 43000, categoria_id: despesa, conta_financeira_id: conta },
      baixa: { data: dia(-6), forma: 'transferencia' } },
    { k: 'r1', e: { tipo: 'reembolso', parceiro_id: cl(0), descricao: 'Reembolso de despesa de viagem', emissao: dia(-2), vencimento: dia(3), valor_centavos: 38000, categoria_id: despesa, conta_financeira_id: conta } },
  ];

  const ids: Record<string, string> = {};
  for (const x of docs) {
    const r = await casos.emitirDocumento.execute(ctx, { ...x.e, chave_idempotencia: `seed:${x.k}` });
    if (!r.ok) throw new Error(`seed contas ${x.k}: ${r.erros.map((e) => e.mensagem).join('; ')}`);
    ids[x.k] = r.valor.id;
    if (!r.valor.repetido) novos++;
    if (x.baixa) {
      const b = await casos.baixar.execute(ctx, { documento_id: r.valor.id, valor_centavos: x.baixa.valor ?? null, data: x.baixa.data, forma: x.baixa.forma, chave_idempotencia: `seed-baixa:${x.k}`, origem: 'seed' });
      if (!b.ok) throw new Error(`seed contas baixa ${x.k}: ${b.erros.map((e) => e.mensagem).join('; ')}`);
      if (!b.valor.repetido) novos++;
    }
    if (x.cancelar && !r.valor.repetido) await casos.cancelarDocumento.execute(ctx, { id: r.valor.id, motivo: 'Lançado em duplicidade' });
  }

  const nc = await casos.emitirDocumento.execute(ctx, {
    tipo: 'nota_credito', parceiro_id: cl(0), documento_origem_id: ids.f4, descricao: 'Crédito por hora de suporte não utilizada', emissao: dia(-1), vencimento: dia(5), valor_centavos: 30000, chave_idempotencia: 'seed:n1',
  });
  if (!nc.ok) throw new Error(`seed contas n1: ${nc.erros.map((e) => e.mensagem).join('; ')}`);
  if (!nc.valor.repetido) novos++;

  const proximoMes = `${somarDias(`${H.slice(0, 7)}-01`, 32).slice(0, 7)}-01`;
  const recs: { k: string; e: DadosRecorrencia; pausar?: boolean }[] = [
    { k: 'rec1', e: { tipo: 'fatura', parceiro_id: cl(0), descricao: 'Mensalidade de suporte', valor_centavos: 150000, frequencia: 'mensal', dia_vencimento: 10, inicio: proximoMes, categoria_id: receita, conta_financeira_id: conta } },
    { k: 'rec2', e: { tipo: 'conta_pagar', parceiro_id: fo(1), descricao: 'Hospedagem em nuvem', valor_centavos: 89000, frequencia: 'mensal', dia_vencimento: 5, inicio: proximoMes, categoria_id: despesa, conta_financeira_id: conta } },
    { k: 'rec3', e: { tipo: 'fatura', parceiro_id: cl(1), descricao: 'Plano anual de manutenção', valor_centavos: 1200000, frequencia: 'anual', dia_vencimento: 15, inicio: proximoMes, antecedencia_dias: 15 }, pausar: true },
  ];
  const repoRec = new RecorrenciaRepoPg(c);
  for (const x of recs) {
    const id = idDe(x.k);
    if (await repoRec.obterPorId(id)) continue;
    const r = await casos.configurarRecorrencia.execute(ctx, x.e, id);
    if (!r.ok) throw new Error(`seed contas ${x.k}: ${r.erros.map((e) => e.mensagem).join('; ')}`);
    if (x.pausar) await casos.mudarEstadoRecorrencia.execute(ctx, { id, estado: 'pausada' });
    novos++;
  }

  log(`${novos} registro(s) demo novo(s)`);
};

export default semear;
