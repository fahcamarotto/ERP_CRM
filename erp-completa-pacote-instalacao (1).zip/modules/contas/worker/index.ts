/**
 * Handlers de worker de Contas (carregados pelo worker do nucleo na partida).
 * `c` ja esta numa transacao do papel erp_worker com o escopo do job (RLS vale).
 */
import type { HandlersModulo } from '@erp/api/sdk/puro';
import { lerPagamento } from '../api/cobranca/use-case/cobrancas.ts';
import { contextoPg } from '../api/compartilhado/efeitos-pg.ts';
import { JOBS } from '../api/compartilhado/fila.ts';
import { casosDeUso } from '../api/fabrica.ts';

const SISTEMA = { tipo: 'sistema' as const, id: null };
const falha = (r: { ok: false; erros: { mensagem: string }[] }) => new Error(r.erros.map((e) => e.mensagem).join('; '));

const handlers: HandlersModulo = {
  // M5.4 Cobranca da regua ou manual: email pela fila do nucleo; WhatsApp, Pix e boleto conforme o conector.
  [JOBS.cobrar]: async (d, c) => {
    const p = d.payload as { cobranca_id: string };
    const r = await casosDeUso(c).processarCobranca.execute(contextoPg(c, SISTEMA), p);
    if (!r.ok && r.erros[0]?.codigo !== 'nao_encontrado') throw falha(r);
  },

  // M5.8 Aviso de vencido: publica fatura.vencida uma vez por vencimento.
  [JOBS.verificarVencimento]: async (d, c) => {
    const p = d.payload as { documento_id: string };
    const r = await casosDeUso(c).verificarVencimento.execute(contextoPg(c, SISTEMA), p);
    if (!r.ok) throw falha(r);
  },

  // M5.3 Recorrencia: gera o documento da competencia e agenda a proxima (idempotente por competencia).
  [JOBS.gerarRecorrencia]: async (d, c) => {
    const p = d.payload as { recorrencia_id: string; competencia?: string };
    const r = await casosDeUso(c).gerarDocumentoRecorrente.execute(contextoPg(c, SISTEMA), p);
    if (!r.ok && r.erros[0]?.codigo !== 'nao_encontrado') throw falha(r);
  },

  // M5.5 Confirmacao do provedor Pix e boleto: POST /api/v1/webhooks/pix-boleto/<token> (assinatura validada pelo nucleo).
  'webhook.recebido.pix-boleto': async (d, c) => {
    const p = d.payload as { recebido_id: string };
    const ev = (await c.query('SELECT payload FROM integracoes_eventos_recebidos WHERE id = $1', [p.recebido_id])).rows[0];
    if (!ev) return;
    const lido = lerPagamento(ev.payload, p.recebido_id);
    const r = lido.ok ? await casosDeUso(c).confirmarPagamento.execute(contextoPg(c, SISTEMA), lido.valor) : lido;
    if (!r.ok) {
      // Dado invalido do remetente nao e reprocessado: registra o motivo e encerra.
      await c.query('UPDATE integracoes_eventos_recebidos SET erro = $2 WHERE id = $1', [p.recebido_id, r.erros.map((e) => e.mensagem).join('; ').slice(0, 500)]);
    }
  },
};

export default handlers;
