/** Testes do modulo Contas (M5) com repositorios em memoria: node --import tsx --test modules/contas/tests/*.test.ts */
import assert from 'node:assert/strict';
import { describe, it } from 'node:test';
import { Cobranca, Regua } from '../api/cobranca/model/cobranca.ts';
import { lerPagamento } from '../api/cobranca/use-case/cobrancas.ts';
import { JOBS } from '../api/compartilhado/fila.ts';
import { Centavos, DataIso, Moeda, somarMeses } from '../api/compartilhado/valores.ts';
import { Documento, type DadosEmissao } from '../api/documento/model/documento.ts';
import { Item } from '../api/documento/model/item.ts';
import { Recorrencia, primeiraData } from '../api/recorrencia/model/recorrencia.ts';
import { CONTA, FORNECEDOR, PARCEIRO, contexto, montar } from './memoria.ts';

const HOJE = '2026-10-01';
const fatura = (x: Partial<DadosEmissao> & { chave_idempotencia?: string } = {}): DadosEmissao & { chave_idempotencia?: string } => ({ tipo: 'fatura', parceiro_id: PARCEIRO, emissao: '2026-09-20', vencimento: '2026-10-20', valor_centavos: 100000, ...x });

describe('Objetos de valor', () => {
  it('Centavos: inteiro positivo; float, zero e negativo falham; create lanca', () => {
    assert.ok(Centavos.tryCreate(1, 'v').ok);
    assert.equal(Centavos.tryCreate(10.5, 'v').ok, false);
    assert.equal(Centavos.tryCreate(0, 'v').ok, false);
    assert.ok(Centavos.tryCreate(0, 'v', false).ok);
    assert.equal(Centavos.tryCreate(-1, 'v', false).ok, false);
    assert.throws(() => Centavos.create(1.2));
  });
  it('Moeda ISO e DataIso no calendario', () => {
    assert.equal(Moeda.create('brl').codigo, 'BRL');
    assert.equal(Moeda.tryCreate('real').ok, false);
    assert.ok(DataIso.tryCreate('2026-02-28').ok);
    assert.equal(DataIso.tryCreate('2026-02-30').ok, false);
    assert.throws(() => DataIso.create('31/12/2026'));
  });
  it('Item: total em centavos e erro por linha', () => {
    assert.equal(Item.create({ descricao: 'Hora', quantidade: 2.5, preco_centavos: 15000 }).totalCentavos, 37500);
    const r = Item.lista([{ descricao: 'ok', preco_centavos: 1 }, { descricao: '', quantidade: 0, preco_centavos: -1 }]);
    assert.equal(r.ok, false);
    if (!r.ok) assert.deepEqual(r.erros.map((e) => e.campo), ['itens.1.descricao', 'itens.1.quantidade', 'itens.1.preco_centavos']);
  });
  it('somarMeses mantem o dia; primeiraData respeita o dia de vencimento', () => {
    assert.equal(somarMeses('2026-11-10', 1, 10), '2026-12-10');
    assert.equal(somarMeses('2026-12-10', 3, 10), '2027-03-10');
    assert.equal(primeiraData('2026-10-05', 10), '2026-10-10');
    assert.equal(primeiraData('2026-10-15', 10), '2026-11-10');
  });
});

describe('Documento (entidade)', () => {
  it('valor pelos itens, vencimento pela condicao, saldo = valor - desconto', () => {
    const d = Documento.create({ tipo: 'fatura', parceiro_id: PARCEIRO, emissao: '2026-10-01', condicao_pagamento: '30_dias', desconto_centavos: 500,
      itens: [{ descricao: 'A', quantidade: 2, preco_centavos: 1000 }, { descricao: 'B', preco_centavos: 333 }] }).paraDados();
    assert.equal(d.valor_centavos, 2333);
    assert.equal(d.saldo_centavos, 1833);
    assert.equal(d.vencimento, '2026-10-31');
    assert.equal(d.estado, 'em_aberto');
  });
  it('tryCreate acumula todos os erros', () => {
    const r = Documento.tryCreate({ tipo: 'boleto' as never, parceiro_id: '', emissao: '2026-10-10', vencimento: '2026-10-01', moeda: 'xx', multa_pct: 50 });
    assert.equal(r.ok, false);
    if (!r.ok) {
      const cods = r.erros.map((e) => e.codigo);
      for (const c of ['valor_obrigatorio', 'tipo_invalido', 'parceiro_obrigatorio', 'vencimento_invalido', 'moeda_invalida', 'multa_invalida']) assert.ok(cods.includes(c), c);
    }
  });
  it('desconto nao pode zerar o valor; create lanca', () => {
    assert.equal(Documento.tryCreate(fatura({ desconto_centavos: 100000 })).ok, false);
    assert.throws(() => Documento.create(fatura({ valor_centavos: 0 })));
  });
  it('baixa parcial e total, sem mutar o original; encargos so em atraso', () => {
    const d = Documento.create(fatura());
    const p = d.baixar({ valor_centavos: 40000, data: '2026-10-05' }, HOJE);
    assert.ok(p.ok);
    if (!p.ok) return;
    assert.equal(d.estado, 'em_aberto');
    assert.equal(p.valor.documento.estado, 'parcial');
    assert.equal(p.valor.documento.saldoCentavos, 60000);
    const t = p.valor.documento.baixar({ data: '2026-10-06' }, HOJE);
    assert.ok(t.ok && t.valor.documento.estado === 'pago' && t.valor.baixa.quitado);
    const atrasada = Documento.create(fatura({ multa_pct: 2, juros_mes_pct: 3 }));
    assert.deepEqual(atrasada.encargos('2026-10-20'), { dias_atraso: 0, multa_centavos: 0, juros_centavos: 0 });
    assert.deepEqual(atrasada.encargos('2026-10-30'), { dias_atraso: 10, multa_centavos: 2000, juros_centavos: 1000 });
  });
  it('baixa acima do saldo, data antes da emissao e forma invalida falham', () => {
    const d = Documento.create(fatura());
    const r = d.baixar({ valor_centavos: 100001, data: '2026-01-01', forma: 'cheque' }, HOJE);
    assert.equal(r.ok, false);
    if (!r.ok) assert.deepEqual(r.erros.map((e) => e.codigo).sort(), ['data_invalida', 'forma_invalida', 'valor_acima_do_saldo']);
  });
  it('transicoes invalidas: pago nao baixa nem cancela; parcial nao cancela; cancelado nao edita', () => {
    const d = Documento.create(fatura());
    const pago = (d.baixar({}, HOJE) as { ok: true; valor: { documento: Documento } }).valor.documento;
    assert.equal(pago.baixar({}, HOJE).ok, false);
    const c1 = pago.cancelar();
    assert.ok(!c1.ok && c1.erros[0]!.codigo === 'transicao_invalida');
    const parcial = (d.baixar({ valor_centavos: 1 }, HOJE) as { ok: true; valor: { documento: Documento } }).valor.documento;
    assert.equal(parcial.cancelar().ok, false);
    const cancelado = (d.cancelar('x') as { ok: true; valor: Documento }).valor;
    assert.equal(cancelado.editar({ descricao: 'y' }).ok, false);
    assert.equal(cancelado.baixar({}, HOJE).ok, false);
  });
  it('editar vencimento vira condicao personalizada e zera o aviso de vencido', () => {
    const d = Documento.create(fatura({ vencimento: '2026-09-25' }));
    const v = (d.marcarVencida(HOJE) as { ok: true; valor: Documento }).valor;
    assert.equal(v.paraDados().vencida_em, HOJE);
    const e = v.editar({ vencimento: '2026-10-15' });
    assert.ok(e.ok);
    if (e.ok) {
      assert.equal(e.valor.paraDados().condicao_pagamento, 'personalizada');
      assert.equal(e.valor.paraDados().vencida_em, null);
    }
    assert.equal(v.paraDados().vencimento, '2026-09-25');
  });
});

describe('EmitirDocumento', () => {
  it('numera por tipo, publica fatura.emitida, agenda vencimento e regua padrao', async () => {
    const m = montar(HOJE);
    const ctx = contexto();
    const r = await m.emitir.execute(ctx, fatura({ chave_idempotencia: 'chave-0001' }));
    assert.ok(r.ok);
    if (!r.ok) return;
    const d = m.documentos.linhas.get(r.valor.id)!;
    assert.equal(d.numero, 'FATURA-000001');
    assert.deepEqual(ctx.efeitos.eventos.map((e) => e.evento), ['fatura.emitida']);
    assert.equal(ctx.efeitos.eventos[0]!.dados.natureza, 'receber');
    assert.deepEqual(ctx.efeitos.auditoria.map((a) => a.acao), ['documento.emitir']);
    const venc = m.fila.jobs.find((j) => j.tipo === JOBS.verificarVencimento)!;
    assert.equal(venc.disponivelEm, '2026-10-21T00:00:00Z');
    assert.deepEqual([...m.cobrancas.linhas.values()].map((c) => `${c.etapa}:${c.canal}`), ['D-3:email', 'D0:email', 'D0:whatsapp', 'D+3:email', 'D+7:whatsapp']);
    assert.equal(m.fila.jobs.filter((j) => j.tipo === JOBS.cobrar).length, 5);
  });
  it('mesma chave devolve o mesmo documento sem novo numero nem evento', async () => {
    const m = montar(HOJE);
    const ctx = contexto();
    const a = await m.emitir.execute(ctx, fatura({ chave_idempotencia: 'chave-0002' }));
    const b = await m.emitir.execute(ctx, fatura({ chave_idempotencia: 'chave-0002' }));
    assert.ok(a.ok && b.ok && a.valor.id === b.valor.id && b.valor.repetido);
    assert.equal(m.documentos.linhas.size, 1);
    assert.equal(ctx.efeitos.eventos.length, 1);
  });
  it('conta a pagar nao agenda regua; numeracao propria; regua inativa nao agenda', async () => {
    const m = montar(HOJE);
    const r = await m.emitir.execute(contexto(), { tipo: 'conta_pagar', parceiro_id: FORNECEDOR, vencimento: '2026-10-10', valor_centavos: 5000 });
    assert.ok(r.ok);
    if (r.ok) assert.equal(m.documentos.linhas.get(r.valor.id)!.numero, 'CONTA-PAGAR-000001');
    assert.equal(m.cobrancas.linhas.size, 0);
    await m.configurarRegua.execute(contexto(), { ativa: false, etapas: [] });
    await m.emitir.execute(contexto(), fatura());
    assert.equal(m.cobrancas.linhas.size, 0);
  });
  it('etapa da regua ja passada nao e agendada', async () => {
    const m = montar(HOJE);
    await m.emitir.execute(contexto(), fatura({ emissao: '2026-09-01', vencimento: '2026-09-30' }));
    assert.deepEqual([...m.cobrancas.linhas.values()].map((c) => c.etapa), ['D+3', 'D+7']);
  });
  it('parceiro inexistente, conta inativa e origem invalida falham', async () => {
    const m = montar(HOJE);
    const r = await m.emitir.execute(contexto(), fatura({ parceiro_id: '99999999-9999-4999-8999-999999999999', conta_financeira_id: '88888888-8888-4888-8888-888888888888' }));
    assert.ok(!r.ok && r.erros.map((e) => e.codigo).sort().join() === 'conta_invalida,parceiro_invalido');
    const nc = await m.emitir.execute(contexto(), { tipo: 'nota_credito', parceiro_id: PARCEIRO, valor_centavos: 100, documento_origem_id: '77777777-7777-4777-8777-777777777777' });
    assert.ok(!nc.ok && nc.erros[0]!.codigo === 'origem_invalida');
  });
});

describe('Baixar e CancelarDocumento', () => {
  it('baixa parcial publica fatura.paga com valor com sinal e mantem regua; total cancela cobrancas agendadas', async () => {
    const m = montar(HOJE);
    const e = await m.emitir.execute(contexto(), fatura({ conta_financeira_id: CONTA }));
    assert.ok(e.ok);
    if (!e.ok) return;
    const ctx = contexto();
    const p = await m.baixar.execute(ctx, { documento_id: e.valor.id, valor_centavos: 30000, juros_centavos: 100, data: '2026-10-02', forma: 'pix', chave_idempotencia: 'baixa-0001' });
    assert.ok(p.ok);
    const ev = ctx.efeitos.eventos[0]!;
    assert.equal(ev.evento, 'fatura.paga');
    assert.equal(ev.dados.valor_pago_centavos, 30100);
    assert.equal(ev.dados.quitado, false);
    assert.equal(ev.dados.conta_financeira_id, CONTA);
    assert.equal(ev.dados.data_pagamento, '2026-10-02');
    assert.equal(m.documentos.linhas.get(e.valor.id)!.estado, 'parcial');
    assert.ok([...m.cobrancas.linhas.values()].every((c) => c.estado === 'agendada'));
    const t = await m.baixar.execute(ctx, { documento_id: e.valor.id, chave_idempotencia: 'baixa-0002' });
    assert.ok(t.ok);
    assert.equal(m.documentos.linhas.get(e.valor.id)!.estado, 'pago');
    assert.equal(ctx.efeitos.eventos[1]!.dados.quitado, true);
    assert.ok([...m.cobrancas.linhas.values()].every((c) => c.estado === 'cancelada'));
    assert.deepEqual(ctx.efeitos.auditoria.map((a) => a.acao), ['documento.baixar', 'documento.baixar']);
  });
  it('conta a pagar publica valor negativo (saida no Financeiro)', async () => {
    const m = montar(HOJE);
    const e = await m.emitir.execute(contexto(), { tipo: 'conta_pagar', parceiro_id: FORNECEDOR, vencimento: '2026-10-10', valor_centavos: 5000 });
    const ctx = contexto();
    if (e.ok) await m.baixar.execute(ctx, { documento_id: e.valor.id });
    assert.equal(ctx.efeitos.eventos[0]!.dados.valor_pago_centavos, -5000);
  });
  it('mesma Idempotency-Key nao baixa duas vezes', async () => {
    const m = montar(HOJE);
    const e = await m.emitir.execute(contexto(), fatura());
    if (!e.ok) return assert.fail();
    const ctx = contexto();
    const a = await m.baixar.execute(ctx, { documento_id: e.valor.id, valor_centavos: 1000, chave_idempotencia: 'baixa-repetida' });
    const b = await m.baixar.execute(ctx, { documento_id: e.valor.id, valor_centavos: 1000, chave_idempotencia: 'baixa-repetida' });
    assert.ok(a.ok && b.ok && b.valor.repetido && a.valor.baixa_id === b.valor.baixa_id);
    assert.equal(m.documentos.baixas.length, 1);
    assert.equal(m.documentos.linhas.get(e.valor.id)!.saldo_centavos, 99000);
  });
  it('nao encontrado, acima do saldo e cancelar parcial', async () => {
    const m = montar(HOJE);
    const n = await m.baixar.execute(contexto(), { documento_id: '00000000-0000-4000-8000-00000000dead' });
    assert.ok(!n.ok && n.erros[0]!.codigo === 'nao_encontrado');
    const e = await m.emitir.execute(contexto(), fatura());
    if (!e.ok) return assert.fail();
    const a = await m.baixar.execute(contexto(), { documento_id: e.valor.id, valor_centavos: 200000 });
    assert.ok(!a.ok && a.erros[0]!.codigo === 'valor_acima_do_saldo');
    await m.baixar.execute(contexto(), { documento_id: e.valor.id, valor_centavos: 100 });
    const c = await m.cancelar.execute(contexto(), { id: e.valor.id });
    assert.ok(!c.ok && c.erros[0]!.codigo === 'transicao_invalida');
  });
  it('cancelar em aberto cancela as cobrancas agendadas', async () => {
    const m = montar(HOJE);
    const e = await m.emitir.execute(contexto(), fatura());
    if (!e.ok) return assert.fail();
    const ctx = contexto();
    const c = await m.cancelar.execute(ctx, { id: e.valor.id, motivo: 'duplicado' });
    assert.ok(c.ok);
    assert.equal(m.documentos.linhas.get(e.valor.id)!.estado, 'cancelado');
    assert.ok([...m.cobrancas.linhas.values()].every((x) => x.estado === 'cancelada'));
    assert.deepEqual(ctx.efeitos.auditoria.map((a) => a.acao), ['documento.cancelar']);
  });
  it('editar vencimento reagenda o aviso e grava historico', async () => {
    const m = montar(HOJE);
    const e = await m.emitir.execute(contexto(), fatura());
    if (!e.ok) return assert.fail();
    const ctx = contexto();
    const r = await m.editar.execute(ctx, { id: e.valor.id, vencimento: '2026-11-05' });
    assert.ok(r.ok);
    assert.equal(m.fila.jobs.filter((j) => j.tipo === JOBS.verificarVencimento).at(-1)!.disponivelEm, '2026-11-06T00:00:00Z');
    assert.equal(ctx.efeitos.historicos.length, 1);
  });
});

describe('VerificarVencimento (job)', () => {
  it('publica fatura.vencida uma vez; pago ou em dia nao publica', async () => {
    const m = montar(HOJE);
    const a = await m.emitir.execute(contexto(), fatura({ emissao: '2026-09-01', vencimento: '2026-09-20' }));
    const b = await m.emitir.execute(contexto(), fatura());
    if (!a.ok || !b.ok) return assert.fail();
    const ctx = contexto();
    assert.deepEqual(await m.vencimento.execute(ctx, { documento_id: a.valor.id }), { ok: true, valor: { publicado: true } });
    assert.deepEqual(await m.vencimento.execute(ctx, { documento_id: a.valor.id }), { ok: true, valor: { publicado: false } });
    assert.deepEqual(await m.vencimento.execute(ctx, { documento_id: b.valor.id }), { ok: true, valor: { publicado: false } });
    assert.deepEqual(ctx.efeitos.eventos.map((e) => e.evento), ['fatura.vencida']);
    assert.equal(ctx.efeitos.eventos[0]!.dados.dias_atraso, 11);
    assert.equal(ctx.efeitos.notas.length, 1);
  });
});

describe('Cobranca (GerarCobranca, ProcessarCobranca e regua)', () => {
  it('Regua valida etapas e ordena; repetida e canal invalido falham', () => {
    assert.deepEqual(Regua.create({ etapas: [{ dias: 3, canal: 'email' }, { dias: -1, canal: 'whatsapp' }] }).etapas.map((e) => e.dias), [-1, 3]);
    const r = Regua.tryCreate({ etapas: [{ dias: 1, canal: 'email' }, { dias: 1, canal: 'email' }, { dias: 200, canal: 'sms' as never }] });
    assert.equal(r.ok, false);
    if (!r.ok) assert.equal(r.erros.length, 3);
  });
  it('Cobranca so sai de agendada', () => {
    const c = Cobranca.create({ documento_id: PARCEIRO, canal: 'email' });
    const e = c.concluir('enviada');
    assert.ok(e.ok);
    if (e.ok) assert.equal(e.valor.concluir('erro').ok, false);
    assert.equal(Cobranca.tryCreate({ documento_id: PARCEIRO, canal: 'telegrama' }).ok, false);
  });
  it('email enviado pela fila, whatsapp aguarda conector, sem contato, documento quitado cancela', async () => {
    const m = montar(HOJE);
    const e = await m.emitir.execute(contexto(), fatura());
    if (!e.ok) return assert.fail();
    const ctx = contexto();
    const g1 = await m.gerarCobranca.execute(ctx, { documento_id: e.valor.id, canal: 'email' });
    const g2 = await m.gerarCobranca.execute(ctx, { documento_id: e.valor.id, canal: 'whatsapp' });
    const g3 = await m.gerarCobranca.execute(ctx, { documento_id: e.valor.id, canal: 'pix' });
    if (!g1.ok || !g2.ok || !g3.ok) return assert.fail();
    assert.equal((await m.processarCobranca.execute(ctx, { cobranca_id: g1.valor.cobranca_id }) as { ok: true; valor: { estado: string } }).valor.estado, 'enviada');
    assert.equal(m.cobrancas.emails[0]!.para, 'financeiro@aurora.test');
    assert.equal(m.cobrancas.emails[0]!.dados.numero, 'FATURA-000001');
    assert.equal((await m.processarCobranca.execute(ctx, { cobranca_id: g2.valor.cobranca_id }) as { ok: true; valor: { estado: string } }).valor.estado, 'aguardando_conector');
    assert.equal((await m.processarCobranca.execute(ctx, { cobranca_id: g3.valor.cobranca_id }) as { ok: true; valor: { estado: string } }).valor.estado, 'aguardando_conector');
    assert.equal(ctx.efeitos.notas.length, 1);
    // reprocessar nao reenvia
    await m.processarCobranca.execute(ctx, { cobranca_id: g1.valor.cobranca_id });
    assert.equal(m.cobrancas.emails.length, 1);
    await m.baixar.execute(ctx, { documento_id: e.valor.id });
    const g4 = Cobranca.create({ documento_id: e.valor.id, canal: 'email' });
    await m.cobrancas.inserir(g4);
    assert.equal((await m.processarCobranca.execute(ctx, { cobranca_id: g4.id }) as { ok: true; valor: { estado: string } }).valor.estado, 'cancelada');
  });
  it('gerar cobranca de conta a pagar ou documento pago falha', async () => {
    const m = montar(HOJE);
    const p = await m.emitir.execute(contexto(), { tipo: 'conta_pagar', parceiro_id: FORNECEDOR, vencimento: '2026-10-10', valor_centavos: 5000 });
    if (!p.ok) return assert.fail();
    const r = await m.gerarCobranca.execute(contexto(), { documento_id: p.valor.id, canal: 'email' });
    assert.ok(!r.ok && r.erros[0]!.codigo === 'tipo_invalido');
    const sem = montar(HOJE);
    sem.cobrancas.contatos[PARCEIRO] = { nome: 'Sem email', email: null, telefone: null };
    const f = await sem.emitir.execute(contexto(), fatura());
    if (!f.ok) return assert.fail();
    const g = await sem.gerarCobranca.execute(contexto(), { documento_id: f.valor.id, canal: 'email' });
    if (!g.ok) return assert.fail();
    assert.equal((await sem.processarCobranca.execute(contexto(), { cobranca_id: g.valor.cobranca_id }) as { ok: true; valor: { estado: string } }).valor.estado, 'sem_contato');
  });
});

describe('ConfirmarPagamento (webhook pix-boleto)', () => {
  it('le corpo de provedor e baixa uma vez so pelo id externo; excedente vira juros', async () => {
    const m = montar(HOJE);
    const e = await m.emitir.execute(contexto(), fatura());
    if (!e.ok) return assert.fail();
    const p = lerPagamento({ event: 'PAYMENT_RECEIVED', payment: { id: 'pay_123', externalReference: e.valor.id, value: '1005.50', paymentDate: '2026-10-03', billingType: 'PIX' } }, 'rec-1');
    assert.ok(p.ok);
    if (!p.ok) return;
    assert.equal(p.valor.valor_centavos, 100550);
    const ctx = contexto();
    const a = await m.confirmarPagamento.execute(ctx, p.valor);
    const b = await m.confirmarPagamento.execute(ctx, p.valor);
    assert.ok(a.ok && b.ok && !a.valor.repetido && b.valor.repetido);
    assert.equal(m.documentos.baixas.length, 1);
    assert.equal(m.documentos.baixas[0]!.juros_centavos, 550);
    assert.equal(m.documentos.baixas[0]!.origem, 'webhook');
    assert.equal(m.documentos.linhas.get(e.valor.id)!.estado, 'pago');
    assert.equal(ctx.efeitos.eventos.filter((x) => x.evento === 'fatura.paga').length, 1);
  });
  it('status nao pago e corpo sem documento sao recusados; numero localiza a fatura', async () => {
    assert.equal(lerPagamento({ status: 'PENDING', documento_id: PARCEIRO }, 'x').ok, false);
    assert.equal(lerPagamento({ status: 'paid', valor: 10 }, 'x').ok, false);
    const m = montar(HOJE);
    const e = await m.emitir.execute(contexto(), fatura());
    if (!e.ok) return assert.fail();
    const p = lerPagamento({ status: 'paid', numero: 'FATURA-000001', valor_centavos: 40000, txid: 'tx1' }, 'x');
    if (!p.ok) return assert.fail();
    const r = await m.confirmarPagamento.execute(contexto(), p.valor);
    assert.ok(r.ok);
    assert.equal(m.documentos.linhas.get(e.valor.id)!.estado, 'parcial');
  });
});

describe('Recorrencia (ConfigurarRecorrencia e job de geracao)', () => {
  const dados = { tipo: 'fatura' as const, parceiro_id: PARCEIRO, descricao: 'Mensalidade', valor_centavos: 15000, frequencia: 'mensal' as const, dia_vencimento: 10, inicio: '2026-10-05' };
  it('entidade: proxima data, validacao e transicoes', () => {
    const r = Recorrencia.create(dados);
    assert.equal(r.proximaEm, '2026-10-10');
    assert.equal(r.geracaoEm, '2026-10-05');
    const inv = Recorrencia.tryCreate({ ...dados, dia_vencimento: 31, frequencia: 'semanal' as never, valor_centavos: 0 });
    assert.ok(!inv.ok && inv.erros.length === 3);
    const enc = (r.mudarEstado('encerrada') as { ok: true; valor: Recorrencia }).valor;
    assert.equal(enc.mudarEstado('ativa').ok, false);
    assert.equal(enc.editar({ descricao: 'x y' }).ok, false);
  });
  it('configurar agenda o job; gerar emite o documento da competencia, avanca e reagenda; job repetido nao duplica', async () => {
    const m = montar(HOJE);
    const ctx = contexto();
    const c = await m.configurarRecorrencia.execute(ctx, dados);
    if (!c.ok) return assert.fail();
    const job = m.fila.jobs.find((j) => j.tipo === JOBS.gerarRecorrencia)!;
    assert.deepEqual(job.payload, { recorrencia_id: c.valor.id, competencia: '2026-10-10' });
    assert.equal(job.disponivelEm, '2026-10-05T09:00:00Z');
    const g = await m.gerarRecorrente.execute(ctx, { recorrencia_id: c.valor.id, competencia: '2026-10-10' });
    assert.ok(g.ok && g.valor.documento_id);
    const doc = m.documentos.linhas.get((g as { ok: true; valor: { documento_id: string } }).valor.documento_id)!;
    assert.equal(doc.vencimento, '2026-10-10');
    assert.equal(doc.competencia, '2026-10-10');
    assert.equal(doc.recorrencia_id, c.valor.id);
    const rec = m.recorrencias.linhas.get(c.valor.id)!;
    assert.equal(rec.proxima_em, '2026-11-10');
    assert.equal(rec.gerados, 1);
    assert.deepEqual(m.fila.jobs.filter((j) => j.tipo === JOBS.gerarRecorrencia).at(-1)!.payload, { recorrencia_id: c.valor.id, competencia: '2026-11-10' });
    const repetido = await m.gerarRecorrente.execute(ctx, { recorrencia_id: c.valor.id, competencia: '2026-10-10' });
    assert.ok(repetido.ok && repetido.valor.documento_id === null);
    assert.equal([...m.documentos.linhas.values()].filter((d) => d.recorrencia_id === c.valor.id).length, 1);
  });
  it('trimestral com fim encerra ao passar do fim; pausada nao gera', async () => {
    const m = montar(HOJE);
    const c = await m.configurarRecorrencia.execute(contexto(), { ...dados, tipo: 'conta_pagar', parceiro_id: FORNECEDOR, frequencia: 'trimestral', fim: '2026-12-31' });
    if (!c.ok) return assert.fail();
    const g = await m.gerarRecorrente.execute(contexto(), { recorrencia_id: c.valor.id });
    assert.ok(g.ok);
    assert.equal(m.recorrencias.linhas.get(c.valor.id)!.estado, 'encerrada');
    const d = await m.configurarRecorrencia.execute(contexto(), dados);
    if (!d.ok) return assert.fail();
    await m.estadoRecorrencia.execute(contexto(), { id: d.valor.id, estado: 'pausada' });
    const p = await m.gerarRecorrente.execute(contexto(), { recorrencia_id: d.valor.id });
    assert.ok(!p.ok && p.erros[0]!.codigo === 'transicao_invalida');
    const n = await m.gerarRecorrente.execute(contexto(), { recorrencia_id: '00000000-0000-4000-8000-00000000beef' });
    assert.ok(!n.ok && n.erros[0]!.codigo === 'nao_encontrado');
  });
});
