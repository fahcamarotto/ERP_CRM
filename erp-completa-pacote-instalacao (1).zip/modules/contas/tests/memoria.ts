/**
 * Repositorios em memoria das portas de Contas, fila e efeitos que gravam o que foi publicado.
 * Os casos de uso rodam aqui sem banco, sem Fastify e sem o SDK.
 */
import { Cobranca, Regua, type CobrancaDados } from '../api/cobranca/model/cobranca.ts';
import type { ContatoParceiro, GravarCobranca, GravarRegua, LerRegua, Mensageiro, ObterCobranca } from '../api/cobranca/model/portas.ts';
import { ConfigurarRegua, ConfirmarPagamento, GerarCobranca, ProcessarCobranca, type LocalizarDocumento } from '../api/cobranca/use-case/cobrancas.ts';
import type { ContextoCaso, Efeitos } from '../api/compartilhado/efeitos.ts';
import type { FilaJobs } from '../api/compartilhado/fila.ts';
import { Documento, type DocumentoDados } from '../api/documento/model/documento.ts';
import type { BaixaDados, BuscarDocumentoPorChave, ConsultarReferenciasDocumento, GravarBaixa, GravarDocumento, Numeracao, ObterDocumento } from '../api/documento/model/portas.ts';
import { Baixar, CancelarDocumento, VerificarVencimento } from '../api/documento/use-case/baixar.ts';
import { EditarDocumento, EmitirDocumento } from '../api/documento/use-case/emitir-documento.ts';
import type { GravarRecorrencia, ObterRecorrencia } from '../api/recorrencia/model/portas.ts';
import { Recorrencia, type RecorrenciaDados } from '../api/recorrencia/model/recorrencia.ts';
import { ConfigurarRecorrencia, EditarRecorrencia, GerarDocumentoRecorrente, MudarEstadoRecorrencia } from '../api/recorrencia/use-case/recorrencias.ts';

export class EfeitosMemoria implements Efeitos {
  auditoria: { acao: string; entidade: string; id: string | null }[] = [];
  eventos: { evento: string; dados: Record<string, unknown> }[] = [];
  historicos: { entidade: string; id: string; antes: unknown; depois: unknown }[] = [];
  notas: { entidade: string; id: string; corpo: string }[] = [];
  async auditar(acao: string, entidade: string, id: string | null) { this.auditoria.push({ acao, entidade, id }); }
  async publicar(evento: string, dados: Record<string, unknown>) { this.eventos.push({ evento, dados }); }
  async historico(entidade: string, id: string, antes: unknown, depois: unknown) { this.historicos.push({ entidade, id, antes, depois }); }
  async nota(entidade: string, id: string, corpo: string) { this.notas.push({ entidade, id, corpo }); }
}

export function contexto(): ContextoCaso & { efeitos: EfeitosMemoria } {
  return { ator: { tipo: 'usuario', id: '00000000-0000-4000-8000-000000000001' }, efeitos: new EfeitosMemoria() };
}

export const PARCEIRO = '11111111-1111-4111-8111-111111111111';
export const FORNECEDOR = '22222222-2222-4222-8222-222222222222';
export const CONTA = '33333333-3333-4333-8333-333333333333';

export class FilaMemoria implements FilaJobs {
  jobs: { id: string; tipo: string; payload: Record<string, unknown>; disponivelEm: string | null }[] = [];
  async enfileirar(tipo: string, payload: Record<string, unknown>, disponivelEm: string | null = null) {
    const id = `00000000-0000-4000-9000-${String(this.jobs.length + 1).padStart(12, '0')}`;
    this.jobs.push({ id, tipo, payload, disponivelEm });
    return id;
  }
}

export class DocumentosMemoria implements ObterDocumento, GravarDocumento, BuscarDocumentoPorChave, Numeracao, ConsultarReferenciasDocumento, GravarBaixa, LocalizarDocumento {
  linhas = new Map<string, DocumentoDados>();
  baixas: BaixaDados[] = [];
  seq = new Map<string, number>();
  parceiros = new Set([PARCEIRO, FORNECEDOR]);
  contas = new Set([CONTA]);
  async obterPorId(id: string) { const d = this.linhas.get(id); return d ? Documento.reidratar(d) : null; }
  async porChave(chave: string) { const d = [...this.linhas.values()].find((x) => x.chave_idempotencia === chave); return d ? Documento.reidratar(d) : null; }
  async idPorNumero(numero: string) { return [...this.linhas.values()].find((x) => x.numero === numero && x.tipo === 'fatura')?.id ?? null; }
  async inserir(d: Documento) {
    const x = d.paraDados();
    if ([...this.linhas.values()].some((y) => y.tipo === x.tipo && y.numero === x.numero)) throw Object.assign(new Error('duplicado'), { code: '23505' });
    this.linhas.set(x.id, x);
  }
  async atualizar(d: Documento) { const x = d.paraDados(); if (this.linhas.has(x.id)) this.linhas.set(x.id, x); }
  async proximoNumero(codigo: string) {
    const n = (this.seq.get(codigo) ?? 0) + 1;
    this.seq.set(codigo, n);
    return `${codigo.toUpperCase()}-${String(n).padStart(6, '0')}`;
  }
  async parceiroAtivo(id: string) { return this.parceiros.has(id); }
  async contaFinanceiraAtiva(id: string) { return this.contas.has(id); }
  async categoriaAtiva() { return true; }
  async centroAtivo() { return true; }
  async documentoDoParceiro(id: string, parceiroId: string) { const d = this.linhas.get(id); return !!d && d.parceiro_id === parceiroId && d.tipo === 'fatura'; }
  async inserirBaixa(b: BaixaDados) { this.baixas.push({ ...b }); }
  async baixaRepetida(chave: string | null, externo: string | null) {
    return this.baixas.find((b) => (chave && b.chave_idempotencia === chave) || (externo && b.id_externo === externo)) ?? null;
  }
}

export class CobrancasMemoria implements ObterCobranca, GravarCobranca, LerRegua, GravarRegua, ContatoParceiro, Mensageiro {
  linhas = new Map<string, CobrancaDados>();
  reguaSalva: Regua | null = null;
  emails: { para: string; dados: Record<string, unknown> }[] = [];
  conectores: Record<string, string> = { resend: 'ativo', whatsapp: 'aguardando_credencial', 'pix-boleto': 'desligado' };
  contatos: Record<string, { nome: string; email: string | null; telefone: string | null }> = {
    [PARCEIRO]: { nome: 'Aurora Tech', email: 'financeiro@aurora.test', telefone: '+5511987650001' },
    [FORNECEDOR]: { nome: 'Nuvem Segura', email: null, telefone: null },
  };
  async obterPorId(id: string) { const d = this.linhas.get(id); return d ? Cobranca.reidratar(d) : null; }
  async inserir(c: Cobranca) {
    const d = c.paraDados();
    if (d.etapa !== 'manual' && [...this.linhas.values()].some((x) => x.documento_id === d.documento_id && x.etapa === d.etapa && x.canal === d.canal)) return;
    this.linhas.set(d.id, d);
  }
  async atualizar(c: Cobranca) { const d = c.paraDados(); this.linhas.set(d.id, d); }
  async cancelarAgendadas(documentoId: string) {
    let n = 0;
    for (const x of this.linhas.values()) if (x.documento_id === documentoId && x.estado === 'agendada') { x.estado = 'cancelada'; n++; }
    return n;
  }
  async regua() { return this.reguaSalva; }
  async salvarRegua(r: Regua) { this.reguaSalva = r; }
  async contato(id: string) { return this.contatos[id] ?? null; }
  async email(para: string, dados: Record<string, unknown>) { this.emails.push({ para, dados }); return `email-${this.emails.length}`; }
  async estadoConector(slug: string) { return this.conectores[slug] ?? null; }
}

export class RecorrenciasMemoria implements ObterRecorrencia, GravarRecorrencia {
  linhas = new Map<string, RecorrenciaDados>();
  async obterPorId(id: string) { const d = this.linhas.get(id); return d ? Recorrencia.reidratar(d) : null; }
  async inserir(r: Recorrencia) { const d = r.paraDados(); this.linhas.set(d.id, d); }
  async atualizar(r: Recorrencia) { const d = r.paraDados(); this.linhas.set(d.id, d); }
}

/** Monta todos os casos de uso sobre a memoria, com `hoje` fixo. */
export function montar(hoje = '2026-10-01') {
  const documentos = new DocumentosMemoria();
  const cobrancas = new CobrancasMemoria();
  const recorrencias = new RecorrenciasMemoria();
  const fila = new FilaMemoria();
  const h = () => hoje;
  const emitir = new EmitirDocumento({ repo: documentos, numeracao: documentos, refs: documentos, cobrancas, fila, hoje: h });
  const baixar = new Baixar({ repo: documentos, baixas: documentos, refs: documentos, cobrancas, hoje: h });
  const depsRec = { repo: recorrencias, refs: documentos, fila, hoje: h };
  return {
    documentos, cobrancas, recorrencias, fila,
    emitir, baixar,
    editar: new EditarDocumento({ repo: documentos, refs: documentos, fila }),
    cancelar: new CancelarDocumento({ repo: documentos, cobrancas }),
    vencimento: new VerificarVencimento({ repo: documentos, hoje: h }),
    gerarCobranca: new GerarCobranca({ documentos, cobrancas, fila }),
    processarCobranca: new ProcessarCobranca({ cobrancas, documentos, contatos: cobrancas, mensageiro: cobrancas }),
    configurarRegua: new ConfigurarRegua({ reguas: cobrancas }),
    confirmarPagamento: new ConfirmarPagamento({ baixar, localizar: documentos, documentos }),
    configurarRecorrencia: new ConfigurarRecorrencia(depsRec),
    editarRecorrencia: new EditarRecorrencia(depsRec),
    estadoRecorrencia: new MudarEstadoRecorrencia(depsRec),
    gerarRecorrente: new GerarDocumentoRecorrente({ ...depsRec, emitir }),
  };
}
