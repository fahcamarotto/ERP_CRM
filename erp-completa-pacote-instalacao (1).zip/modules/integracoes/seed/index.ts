/**
 * Seed demo do Integracoes (D1): registra os tres agentes MCP do specs/modulos.json (openclaw, hermes,
 * naia-claude) sem chave, para a aba MCP abrir com os snippets prontos. Conectores ja nascem no seed do
 * nucleo em aguardando_credencial; credencial real nunca entra em seed. Idempotente por agente.
 */
import { createHash } from 'node:crypto';
import type { SeedModulo } from '@erp/api/sdk/puro';
import { AGENTES } from '../api/agente/model/agente-mcp.ts';
import { contextoPg } from '../api/compartilhado/efeitos-pg.ts';
import { casosDeUso } from '../api/fabrica.ts';

function idDe(chave: string): string {
  const h = createHash('sha256').update(`integracoes-demo:${chave}`).digest('hex');
  return `${h.slice(0, 8)}-${h.slice(8, 12)}-4${h.slice(13, 16)}-a${h.slice(17, 20)}-${h.slice(20, 32)}`;
}

const semear: SeedModulo = async ({ c, usuarioId, log }) => {
  const casos = casosDeUso(c);
  const ctx = contextoPg(c, { tipo: 'usuario', id: usuarioId });
  let novos = 0;
  for (const a of AGENTES) {
    const r = await casos.registrarAgente.execute(ctx, { agente: a }, idDe(`agente:${a}`));
    if (r.ok) novos++;
    else if (r.erros[0]?.codigo !== 'conflito') throw new Error(r.erros.map((e) => e.mensagem).join('; '));
  }
  log(`${novos} registro(s) demo novo(s)`);
};

export default semear;
