/**
 * Leitura do ambiente (credenciais de plataforma injetadas do cofre por op run e URL publica). Nunca devolve
 * segredo para resposta ou log; so o adaptador HTTP usa o token.
 */
import { createHash } from 'node:crypto';

function loopback(host: string): boolean {
  return host === 'localhost' || host === '::1' || host === '[::1]' || /^127\./.test(host) || host === '0.0.0.0';
}

/** URL publica https (producao). Local (loopback ou http) devolve null e o polling assume. */
export function urlPublica(): string | null {
  const v = (process.env.ERP_URL_PUBLICA ?? '').trim().replace(/\/$/, '');
  if (!v) return null;
  try {
    const u = new URL(v);
    return u.protocol === 'https:' && !loopback(u.hostname) ? v : null;
  } catch {
    return null;
  }
}

/** Origem dos callbacks OAuth: URL publica, senao o web local (o proxy do Vite leva /api ao servidor). */
export function baseCallback(): string {
  return ((process.env.ERP_URL_PUBLICA ?? '').trim() || process.env.ERP_WEB_URL || 'http://127.0.0.1:5173').replace(/\/$/, '');
}

function httpsPublico(v: string | undefined): string | null {
  const t = (v ?? '').trim().replace(/\/$/, '');
  if (!t) return null;
  try {
    const u = new URL(t);
    return u.protocol === 'https:' && !loopback(u.hostname) ? t : null;
  } catch {
    return null;
  }
}

/**
 * Webhook da Zernio: ERP_WEBHOOK_URL_PUBLICA (tunel local so para webhooks, os callbacks OAuth ficam no
 * 127.0.0.1) vence; em producao ERP_URL_PUBLICA cobre tudo. O nome fixo identifica o webhook do ERP na equipe
 * Zernio (o tunel muda de URL a cada partida e o registro e atualizado, nunca duplicado).
 */
export function webhookZernio(): { url: string; segredo: string; nome: string } | null {
  const tunel = httpsPublico(process.env.ERP_WEBHOOK_URL_PUBLICA);
  const u = tunel ?? urlPublica();
  const segredo = process.env.ZERNIO_WEBHOOK_SECRET ?? '';
  if (!u || !segredo) return null;
  const nome = (process.env.ERP_WEBHOOK_NOME ?? '').trim() || (tunel ? 'erp-local-tunel' : `erp-${new URL(u).hostname}`);
  return { url: `${u}/api/v1/integracoes/zernio/webhook`, segredo, nome: nome.slice(0, 50) };
}

/** Chave do state OAuth derivada do segredo de sessao (nunca o proprio segredo). */
export function chaveState(): string {
  return createHash('sha256').update(`erp-integracoes-state:${process.env.ERP_SESSION_SECRET ?? ''}`).digest('hex');
}

export const ambiente = {
  zernio: () => !!process.env.ZERNIO_API_KEY,
  zernioWebhook: () => !!process.env.ZERNIO_WEBHOOK_SECRET,
  resend: () => !!process.env.RESEND_API_KEY,
};
