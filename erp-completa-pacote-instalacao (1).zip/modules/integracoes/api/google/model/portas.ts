/**
 * Portas do Google Calendar via Maton com a chave de API da PROPRIA subconta: a conexao com o Google e feita
 * pelo dono no site do Maton; o ERP so le as conexoes e agendas e sincroniza com a Agenda.
 */
export type StatusMaton = 'ACTIVE' | 'PENDING' | 'FAILED' | string;

export interface ConexaoMaton { connection_id: string; status: StatusMaton; url: string | null }

export interface CalendarioGoogle { id: string; nome: string; primario: boolean }

/** Conta Google reconhecida na chave (conexao ACTIVE do app google-calendar) e as agendas dela. */
export interface ContaGoogle { connection_id: string; conta: string; calendarios: CalendarioGoogle[] }

export interface EventoGoogle { id: string; status: string; updated: string; extendedProperties?: { private?: Record<string, string> }; [k: string]: unknown }

export interface ApiMaton {
  /** Somente leitura: conexoes ACTIVE do app google-calendar. */
  conexoesGoogle(): Promise<ConexaoMaton[]>;
  obterConexao(id: string): Promise<ConexaoMaton | null>;
  /** Somente leitura: agendas da conta (calendarList). */
  calendarios(conexao: string): Promise<CalendarioGoogle[]>;
  eventos(conexao: string, calendario: string, desde: string): Promise<EventoGoogle[]>;
  criarEvento(conexao: string, calendario: string, ev: Record<string, unknown>): Promise<{ id: string }>;
  atualizarEvento(conexao: string, calendario: string, id: string, ev: Record<string, unknown>): Promise<void>;
  excluirEvento(conexao: string, calendario: string, id: string): Promise<void>;
}

/** Cliente do Maton montado com a chave decifrada da subconta (nunca com chave de plataforma). */
export type FabricaMaton = (chave: string) => ApiMaton;

/** Cifra do nucleo (AES-256-GCM, cifra:v1:...). */
export interface Cofre { cifrar(segredo: string): string; decifrar(ref: string): string }

export type EstadoChave = 'ok' | 'falhou';

/** Chave da subconta como fica no banco: so a cifra e os 4 ultimos caracteres. */
export interface ChaveGuardada { ref: string; sufixo: string; estado: EstadoChave; erro: string | null; testada_em: string | null; contas: ContaGoogle[] }

export type EstadoGoogle = 'pendente' | 'ativo' | 'falhou' | 'desconectado';

export interface ConexaoGoogleDados {
  id: string;
  connection_id: string;
  estado: EstadoGoogle;
  calendario: string;
  sincronizado_em: string | null;
  atualizado_min: string | null;
  importados: number;
  ultimo_erro: string | null;
  job_sync_id: string | null;
}

export interface RepoGoogle {
  conexao(): Promise<ConexaoGoogleDados | null>;
  /** Uma conexao viva por subconta: substitui a anterior (exclusao logica) ja ativa na agenda escolhida. */
  novaConexao(connectionId: string, calendario: string): Promise<string>;
  atualizar(id: string, p: Partial<Omit<ConexaoGoogleDados, 'id' | 'connection_id'>>): Promise<void>;
  mudarConector(estado: 'ativo' | 'aguardando_credencial'): Promise<void>;
  chave(): Promise<ChaveGuardada | null>;
  /** Grava ou troca a chave (uma viva por subconta). */
  salvarChave(c: Omit<ChaveGuardada, 'testada_em'>): Promise<void>;
  marcarChave(p: { estado: EstadoChave; erro: string | null; contas?: ContaGoogle[] }): Promise<void>;
  removerChave(): Promise<void>;
  eventoDoCompromisso(compromissoId: string): Promise<string | null>;
  gravarEvento(compromissoId: string, googleId: string): Promise<void>;
  removerEvento(compromissoId: string): Promise<void>;
  tituloCompromisso(compromissoId: string): Promise<string | null>;
  entregarAgenda(idExterno: string, payload: unknown): Promise<boolean>;
  enfileirar(tipo: string, payload: Record<string, unknown>, atrasoSeg?: number): Promise<string>;
}
