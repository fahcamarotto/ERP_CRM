/**
 * Maton: conexoes em https://ctrl.maton.ai/connections e Google Calendar v3 pelo gateway
 * https://gateway.maton.ai/google-calendar/calendar/v3 com `Maton-Connection` apontando a conexao escolhida.
 * A chave e a da PROPRIA subconta (colada na Agenda, guardada cifrada), nunca uma chave de plataforma.
 * O ERP nao cria nem remove conexao no Maton: so lista conexoes e agendas e le e grava eventos da agenda escolhida.
 * MATON_CTRL_BASE e MATON_GATEWAY_BASE trocam a origem (mock nos testes).
 */
import { ClienteHttp, ErroProvedor } from '../../compartilhado/http.ts';
import type { ApiMaton, CalendarioGoogle, ConexaoMaton, EventoGoogle } from '../model/portas.ts';

type Obj = Record<string, unknown>;
const s = (v: unknown) => (typeof v === 'string' ? v : '');

function conexaoDe(r: Obj): ConexaoMaton {
  const c = (r.connection && typeof r.connection === 'object' ? r.connection : r) as Obj;
  const id = s(c.connection_id) || s(c.id);
  if (!id) throw new ErroProvedor('maton: conexao sem id', 502, 'resposta_invalida');
  return { connection_id: id, status: s(c.status) || 'PENDING', url: s(c.url) || null };
}

export class ClienteMaton implements ApiMaton {
  private readonly ctrl: ClienteHttp;
  private readonly gw: string;
  private readonly token: string;
  constructor(o: { token: string; ctrl?: string; gateway?: string }) {
    this.token = o.token;
    this.ctrl = new ClienteHttp({ base: o.ctrl ?? (process.env.MATON_CTRL_BASE || 'https://ctrl.maton.ai'), token: this.token, provedor: 'maton' });
    this.gw = (o.gateway ?? (process.env.MATON_GATEWAY_BASE || 'https://gateway.maton.ai')).replace(/\/$/, '');
  }

  async conexoesGoogle() {
    const r = await this.ctrl.pedir<Obj>({ metodo: 'GET', caminho: 'connections', query: { app: 'google-calendar', status: 'ACTIVE' } });
    const lista = (Array.isArray(r.connections) ? r.connections : []) as Obj[];
    return lista.map((c) => conexaoDe(c)).filter((c) => c.status === 'ACTIVE');
  }

  async obterConexao(id: string) {
    try {
      return conexaoDe(await this.ctrl.pedir<Obj>({ metodo: 'GET', caminho: `connections/${encodeURIComponent(id)}` }));
    } catch (e) {
      if (e instanceof ErroProvedor && e.status === 404) return null;
      throw e;
    }
  }

  async calendarios(conexao: string): Promise<CalendarioGoogle[]> {
    const r = await this.cal<Obj>(conexao, 'GET', 'users/me/calendarList', { maxResults: '250' });
    return ((Array.isArray(r.items) ? r.items : []) as Obj[])
      .filter((x) => s(x.id))
      .map((x) => ({ id: s(x.id), nome: s(x.summaryOverride) || s(x.summary) || s(x.id), primario: x.primary === true }));
  }

  /** Gateway: mesmo cliente HTTP, base do Calendar e cabecalho da conexao. */
  private async cal<T>(conexao: string, metodo: 'GET' | 'POST' | 'PATCH' | 'DELETE', caminho: string, q?: Record<string, string>, corpo?: unknown): Promise<T> {
    const http = new ClienteHttp({ base: `${this.gw}/google-calendar/calendar/v3`, token: this.token, provedor: 'maton' });
    const url = http.url(caminho, q);
    if (!this.token) throw new ErroProvedor('maton: chave de API da subconta ausente', null, 'sem_credencial', true);
    let res: Response;
    try {
      res = await fetch(url, {
        method: metodo, redirect: 'manual', signal: AbortSignal.timeout(15_000),
        headers: { authorization: `Bearer ${this.token}`, 'maton-connection': conexao, accept: 'application/json', ...(corpo ? { 'content-type': 'application/json' } : {}) },
        body: corpo ? JSON.stringify(corpo) : undefined,
      });
    } catch (e) {
      throw new ErroProvedor(`maton: sem resposta (${e instanceof Error ? e.name : 'Erro'})`, null, 'indisponivel');
    }
    const texto = await res.text();
    if (!res.ok) throw new ErroProvedor(`maton ${res.status}: google calendar recusou`, res.status, null, res.status >= 400 && res.status < 500 && ![408, 409, 429].includes(res.status));
    return (texto ? JSON.parse(texto) : {}) as T;
  }

  /**
   * Incremental por `updatedMin` so quando a marca e recente: o Google responde 410 quando ela passa da
   * janela de retencao de alteracoes. Marca antiga (primeira sincronizacao) ou 410 viram leitura completa
   * por `timeMin` (da mesma data ate 1 ano a frente, para recorrencias expandidas terem fim).
   */
  async eventos(conexao: string, calendario: string, desde: string): Promise<EventoGoogle[]> {
    const recente = Date.now() - Date.parse(desde) < 20 * 86_400_000;
    if (recente) {
      try {
        return await this.listarEventos(conexao, calendario, { updatedMin: desde, showDeleted: 'true' });
      } catch (x) {
        if (!(x instanceof ErroProvedor && x.status === 410)) throw x;
      }
    }
    const ate = new Date(Date.now() + 365 * 86_400_000).toISOString();
    return this.listarEventos(conexao, calendario, { timeMin: desde, timeMax: ate });
  }

  private async listarEventos(conexao: string, calendario: string, filtro: Record<string, string>): Promise<EventoGoogle[]> {
    const itens: EventoGoogle[] = [];
    let pagina: string | undefined;
    for (let i = 0; i < 20; i++) {
      const r = await this.cal<Obj>(conexao, 'GET', `calendars/${encodeURIComponent(calendario)}/events`, {
        ...filtro, singleEvents: 'true', maxResults: '250', ...(pagina ? { pageToken: pagina } : {}),
      });
      itens.push(...((Array.isArray(r.items) ? r.items : []) as EventoGoogle[]));
      pagina = s(r.nextPageToken) || undefined;
      if (!pagina) break;
    }
    return itens;
  }

  async criarEvento(conexao: string, calendario: string, ev: Record<string, unknown>) {
    const r = await this.cal<Obj>(conexao, 'POST', `calendars/${encodeURIComponent(calendario)}/events`, undefined, ev);
    return { id: s(r.id) };
  }

  async atualizarEvento(conexao: string, calendario: string, id: string, ev: Record<string, unknown>) {
    await this.cal(conexao, 'PATCH', `calendars/${encodeURIComponent(calendario)}/events/${encodeURIComponent(id)}`, undefined, ev);
  }

  async excluirEvento(conexao: string, calendario: string, id: string) {
    await this.cal(conexao, 'DELETE', `calendars/${encodeURIComponent(calendario)}/events/${encodeURIComponent(id)}`);
  }
}
