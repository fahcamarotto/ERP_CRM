/**
 * Adaptador Postgres da conexao Google (Maton), da chave Maton da subconta (integracoes_credenciais, so a cifra
 * cifra:v1 e os 4 ultimos caracteres) e do mapa agendamento -> evento do Google.
 */
import type pg from 'pg';
import { FilaOutbox } from '../../zernio/adapter/zernio-repo-pg.ts';
import type { ChaveGuardada, ConexaoGoogleDados, ContaGoogle, EstadoChave, RepoGoogle } from '../model/portas.ts';

const COLUNAS = 'id, connection_id, estado, calendario, sincronizado_em, atualizado_min, importados, ultimo_erro, job_sync_id';
const CONECTOR = 'google-calendar';
const iso = (d: unknown) => (d instanceof Date ? d.toISOString() : d ? String(d) : null);

export class GoogleRepoPg extends FilaOutbox implements RepoGoogle {
  constructor(c: pg.PoolClient) { super(c); }

  async conexao(): Promise<ConexaoGoogleDados | null> {
    const r = await this.c.query(`SELECT ${COLUNAS} FROM integracoes_google_conexoes WHERE deleted_at IS NULL ORDER BY created_at DESC LIMIT 1`);
    const l = r.rows[0];
    return l ? { ...l, sincronizado_em: iso(l.sincronizado_em), atualizado_min: iso(l.atualizado_min) } : null;
  }
  async novaConexao(connectionId: string, calendario: string): Promise<string> {
    await this.c.query(`UPDATE integracoes_google_conexoes SET deleted_at = now() WHERE deleted_at IS NULL`);
    const r = await this.c.query(
      `INSERT INTO integracoes_google_conexoes (connection_id, calendario, estado, creator_id) VALUES ($1, $2, 'ativo', nucleo_usuario_atual()) RETURNING id`,
      [connectionId, calendario],
    );
    return r.rows[0].id as string;
  }
  async chave(): Promise<ChaveGuardada | null> {
    const r = await this.c.query(
      `SELECT segredo_ref, sufixo, teste_estado, ultimo_erro, ultimo_teste, campos FROM integracoes_credenciais WHERE conector = $1 AND deleted_at IS NULL`,
      [CONECTOR],
    );
    const l = r.rows[0];
    if (!l) return null;
    const contas = Array.isArray(l.campos?.contas) ? (l.campos.contas as ContaGoogle[]) : [];
    return { ref: l.segredo_ref, sufixo: l.sufixo, estado: l.teste_estado === 'ok' ? 'ok' : 'falhou', erro: l.ultimo_erro, testada_em: iso(l.ultimo_teste), contas };
  }
  async salvarChave(c: Omit<ChaveGuardada, 'testada_em'>): Promise<void> {
    await this.c.query(`UPDATE integracoes_credenciais SET deleted_at = now() WHERE conector = $1 AND deleted_at IS NULL`, [CONECTOR]);
    await this.c.query(
      `INSERT INTO integracoes_credenciais (conector, segredo_ref, sufixo, campos, teste_estado, ultimo_teste, ultimo_erro, creator_id)
       VALUES ($1, $2, $3, $4, $5, now(), $6, nucleo_usuario_atual())`,
      [CONECTOR, c.ref, c.sufixo, JSON.stringify({ contas: c.contas }), c.estado, c.erro],
    );
  }
  async marcarChave(p: { estado: EstadoChave; erro: string | null; contas?: ContaGoogle[] }): Promise<void> {
    await this.c.query(
      `UPDATE integracoes_credenciais SET teste_estado = $2, ultimo_erro = $3, ultimo_teste = now(),
         campos = CASE WHEN $4::jsonb IS NULL THEN campos ELSE jsonb_build_object('contas', $4::jsonb) END
       WHERE conector = $1 AND deleted_at IS NULL`,
      [CONECTOR, p.estado, p.erro, p.contas ? JSON.stringify(p.contas) : null],
    );
  }
  async removerChave(): Promise<void> {
    await this.c.query(`UPDATE integracoes_credenciais SET deleted_at = now() WHERE conector = $1 AND deleted_at IS NULL`, [CONECTOR]);
  }
  async atualizar(id: string, p: Partial<Omit<ConexaoGoogleDados, 'id' | 'connection_id'>>): Promise<void> {
    const campos = Object.entries(p).filter(([, v]) => v !== undefined);
    if (!campos.length) return;
    await this.c.query(`UPDATE integracoes_google_conexoes SET ${campos.map(([k], i) => `${k} = $${i + 2}`).join(', ')} WHERE id = $1`, [id, ...campos.map(([, v]) => v)]);
  }
  async mudarConector(estado: 'ativo' | 'aguardando_credencial'): Promise<void> {
    await this.mudarConectorSlug(CONECTOR, estado);
  }
  async eventoDoCompromisso(compromissoId: string): Promise<string | null> {
    const r = await this.c.query(`SELECT google_evento_id FROM integracoes_google_eventos WHERE compromisso_id = $1 AND deleted_at IS NULL`, [compromissoId]);
    return (r.rows[0]?.google_evento_id as string | undefined) ?? null;
  }
  async gravarEvento(compromissoId: string, googleId: string): Promise<void> {
    await this.c.query(
      `INSERT INTO integracoes_google_eventos (compromisso_id, google_evento_id) VALUES ($1, $2)
       ON CONFLICT (tenant_id, workspace_id, compromisso_id) DO UPDATE SET google_evento_id = EXCLUDED.google_evento_id, deleted_at = NULL`,
      [compromissoId, googleId],
    );
  }
  async removerEvento(compromissoId: string): Promise<void> {
    await this.c.query(`UPDATE integracoes_google_eventos SET deleted_at = now() WHERE compromisso_id = $1 AND deleted_at IS NULL`, [compromissoId]);
  }
  /** Titulo pela tabela publicada da Agenda (CONTRATOS 7.1: agenda_compromissos.titulo). */
  async tituloCompromisso(compromissoId: string): Promise<string | null> {
    const r = await this.c.query(`SELECT titulo FROM agenda_compromissos WHERE id = $1 AND deleted_at IS NULL`, [compromissoId]);
    return (r.rows[0]?.titulo as string | undefined) ?? null;
  }
  async entregarAgenda(idExterno: string, payload: unknown): Promise<boolean> {
    return this.entregarAoConversas(CONECTOR, idExterno, payload);
  }
}
