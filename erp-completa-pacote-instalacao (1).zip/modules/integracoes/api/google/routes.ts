/**
 * Rotas do Google Agenda via Maton com a chave da propria subconta: situacao, salvar ou trocar a chave (validada
 * no Maton, somente leitura), testar, escolher a agenda, parar a sincronizacao e remover a chave.
 * A chave nunca volta para o front: so os 4 ultimos caracteres.
 */
import { esquemaErro, exigirUsuario, requer, type FastifyInstance, type FastifyRequest } from '@erp/api/sdk';
import { naTransacao } from '../borda.ts';
import { exigirOk } from '../compartilhado/result.ts';
import { GoogleRepoPg } from './adapter/google-repo-pg.ts';
import { situacaoGoogle } from './use-case/google.ts';

const tags = ['integracoes'];
const erros = { 400: esquemaErro, 403: esquemaErro, 404: esquemaErro, 409: esquemaErro, 502: esquemaErro, 503: esquemaErro };
const semCorpo = { 204: { type: 'null' }, ...erros } as const;

const situacao = (req: FastifyRequest) => naTransacao(req, (_casos, _ctx, c) => situacaoGoogle(new GoogleRepoPg(c)));

export function rotasGoogle(app: FastifyInstance): void {
  app.get('/google', {
    preHandler: requer('integracoes.ver'),
    schema: { tags, summary: 'Situacao do Google Agenda (sem_chave, chave_invalida, escolher, conectado), sufixo da chave, contas e agenda sincronizada' },
  }, (req) => situacao(req));

  app.put<{ Body: { chave: string } }>('/google/chave', {
    preHandler: [exigirUsuario, requer('integracoes.editar')],
    schema: {
      tags, summary: 'Salva ou troca a chave de API do Maton da subconta (cifrada); valida listando as conexoes e agendas Google (somente leitura)',
      body: { type: 'object', additionalProperties: false, required: ['chave'], properties: { chave: { type: 'string', minLength: 1, maxLength: 512 } } }, response: erros,
    },
  }, (req) => naTransacao(req, async (casos, ctx) => exigirOk(await casos.salvarChaveMaton.execute(ctx, { chave: req.body.chave }))));

  app.post('/google/testar', {
    preHandler: [exigirUsuario, requer('integracoes.editar')],
    schema: { tags, summary: 'Testa a chave salva no Maton (somente leitura) e atualiza as contas reconhecidas', response: erros },
  }, (req) => naTransacao(req, async (casos, ctx) => exigirOk(await casos.testarChaveMaton.execute(ctx))));

  app.put<{ Body: { connection_id: string; calendario: string } }>('/google/agenda', {
    preHandler: [exigirUsuario, requer('integracoes.editar')],
    schema: {
      tags, summary: 'Escolhe a conta e a agenda do Google a sincronizar com a Agenda',
      body: {
        type: 'object', additionalProperties: false, required: ['connection_id', 'calendario'],
        properties: { connection_id: { type: 'string', pattern: '^[A-Za-z0-9_-]{4,128}$' }, calendario: { type: 'string', minLength: 1, maxLength: 300 } },
      },
      response: erros,
    },
  }, (req) => naTransacao(req, async (casos, ctx) => exigirOk(await casos.escolherAgendaGoogle.execute(ctx, req.body))));

  app.delete('/google', {
    preHandler: [exigirUsuario, requer('integracoes.excluir')],
    schema: { tags, summary: 'Para a sincronizacao com o Google (nada muda no Maton)', response: semCorpo },
  }, async (req, reply) => {
    await naTransacao(req, async (casos, ctx) => exigirOk(await casos.desconectarGoogle.execute(ctx)));
    return reply.code(204).send();
  });

  app.delete('/google/chave', {
    preHandler: [exigirUsuario, requer('integracoes.excluir')],
    schema: { tags, summary: 'Remove a chave do Maton da subconta e para a sincronizacao', response: semCorpo },
  }, async (req, reply) => {
    await naTransacao(req, async (casos, ctx) => exigirOk(await casos.removerChaveMaton.execute(ctx)));
    return reply.code(204).send();
  });
}
