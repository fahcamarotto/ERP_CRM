/**
 * Google Calendar via Maton com a chave de API da PROPRIA subconta. O dono conecta a Google Agenda dele no site
 * do Maton e cola aqui a chave; o ERP guarda so a cifra e os 4 ultimos caracteres, valida a chave lendo as
 * conexoes e agendas (somente leitura), o dono escolhe a agenda e a sincronizacao liga: eventos do Google entram
 * na Agenda pelo caminho publicado (webhook.recebido.google-calendar) e agendamentos saem para o Google
 * (reacao a agenda.marcado, agenda.confirmado e agenda.cancelado). O ERP nunca cria nem remove conexao no Maton.
 */
import { createHash } from 'node:crypto';
import type { ContextoCaso } from '../../compartilhado/efeitos.ts';
import { ErroProvedor } from '../../compartilhado/http.ts';
import { erroDe, fail, ok, type Result } from '../../compartilhado/result.ts';
import type { ApiMaton, ChaveGuardada, Cofre, ConexaoGoogleDados, ContaGoogle, FabricaMaton, RepoGoogle } from '../model/portas.ts';

export const TIPO_JOB_GOOGLE = 'integracoes.google_importar';
export const INTERVALO_GOOGLE_S = 300;
export const ERRO_CHAVE_INVALIDA = 'chave_invalida';
const TABELA = 'integracoes_google_conexoes';
const MARCA = 'erp_compromisso_id';

export interface DepsGoogle { repo: RepoGoogle; maton: FabricaMaton; cofre: Cofre; agora?: () => Date }

export type Situacao = 'sem_chave' | 'chave_invalida' | 'escolher' | 'conectado';

export interface SituacaoGoogle {
  situacao: Situacao;
  chave: { sufixo: string; testada_em: string | null; erro: string | null } | null;
  contas: ContaGoogle[];
  conexao: ConexaoGoogleDados | null;
}

/** Chave recusada pelo Maton (401 ou 403): mensagem fixa, nunca o texto do provedor (que pode ecoar a chave). */
const recusada = (e: unknown) => e instanceof ErroProvedor && (e.status === 401 || e.status === 403);

function falha(e: unknown): Result<never> {
  if (recusada(e)) return fail(erroDe(ERRO_CHAVE_INVALIDA, 'Chave de API do Maton invalida', 'chave'));
  if (e instanceof ErroProvedor) return fail(erroDe(e.codigo === 'sem_credencial' ? 'sem_credencial' : 'provedor_falhou', e.message, undefined, { status: e.status }));
  throw e;
}

/** Somente leitura: conexoes ACTIVE do google-calendar e as agendas de cada uma. */
async function lerContas(api: ApiMaton): Promise<ContaGoogle[]> {
  const contas: ContaGoogle[] = [];
  for (const con of await api.conexoesGoogle()) {
    const calendarios = await api.calendarios(con.connection_id);
    const primario = calendarios.find((c) => c.primario);
    contas.push({ connection_id: con.connection_id, conta: primario?.id ?? con.connection_id, calendarios });
  }
  return contas;
}

export async function situacaoGoogle(repo: RepoGoogle): Promise<SituacaoGoogle> {
  const [chave, c] = await Promise.all([repo.chave(), repo.conexao()]);
  const conexao = c && c.estado !== 'desconectado' ? c : null;
  const situacao: Situacao = !chave ? 'sem_chave' : chave.estado === 'falhou' ? 'chave_invalida' : conexao?.estado === 'ativo' ? 'conectado' : 'escolher';
  return { situacao, chave: chave && { sufixo: chave.sufixo, testada_em: chave.testada_em, erro: chave.erro }, contas: chave?.contas ?? [], conexao };
}

/** Para a sincronizacao (so no ERP): conexao desconectada e conector aguardando credencial. */
async function pararSync(d: DepsGoogle, ctx: ContextoCaso, atual: ConexaoGoogleDados, estado: 'desconectado' | 'falhou', motivo: string | null): Promise<void> {
  await d.repo.atualizar(atual.id, { estado, job_sync_id: null, ultimo_erro: motivo });
  await d.repo.mudarConector('aguardando_credencial');
  await ctx.efeitos.auditar('google.status', TABELA, atual.id, { estado: atual.estado }, { estado });
  await ctx.efeitos.publicar('conector.desconectado', { slug: 'google-calendar', motivo: 'credencial_removida' });
}

/** Chave recusada durante o uso: marca chave invalida e para a sincronizacao. */
async function chaveRecusada(d: DepsGoogle, ctx: ContextoCaso, c: ConexaoGoogleDados): Promise<void> {
  await d.repo.marcarChave({ estado: 'falhou', erro: ERRO_CHAVE_INVALIDA });
  if (c.estado === 'ativo') await pararSync(d, ctx, c, 'falhou', 'Chave de API do Maton invalida');
}

export class SalvarChaveMaton {
  constructor(private readonly d: DepsGoogle) {}
  async execute(ctx: ContextoCaso, e: { chave: string }): Promise<Result<SituacaoGoogle>> {
    const chave = (e.chave ?? '').trim();
    if (chave.length < 8 || chave.length > 512 || /\s/.test(chave)) return fail(erroDe('entrada_invalida', 'Cole a chave de API do Maton', 'chave'));
    let contas: ContaGoogle[];
    try {
      contas = await lerContas(this.d.maton(chave));
    } catch (x) {
      return falha(x);
    }
    const antes = await this.d.repo.chave();
    await this.d.repo.salvarChave({ ref: this.d.cofre.cifrar(chave), sufixo: chave.slice(-4), estado: 'ok', erro: null, contas });
    await ctx.efeitos.auditar(antes ? 'google.chave_trocar' : 'google.chave_salvar', 'integracoes_credenciais', null, antes ? { sufixo: antes.sufixo } : undefined, { sufixo: chave.slice(-4), contas: contas.length });
    const atual = await this.d.repo.conexao();
    if (atual?.estado === 'ativo' && !contas.some((c) => c.connection_id === atual.connection_id)) await pararSync(this.d, ctx, atual, 'desconectado', null);
    return ok(await situacaoGoogle(this.d.repo));
  }
}

/** Testa a chave guardada (somente leitura no Maton) e atualiza as contas reconhecidas. */
export class TestarChaveMaton {
  constructor(private readonly d: DepsGoogle) {}
  async execute(ctx: ContextoCaso): Promise<Result<SituacaoGoogle>> {
    const g = await this.d.repo.chave();
    if (!g) return fail(erroDe('nao_encontrado', 'Nenhuma chave do Maton salva nesta subconta', 'chave'));
    try {
      const contas = await lerContas(this.d.maton(this.d.cofre.decifrar(g.ref)));
      await this.d.repo.marcarChave({ estado: 'ok', erro: null, contas });
    } catch (x) {
      if (!recusada(x)) return falha(x);
      const c = await this.d.repo.conexao();
      if (c) await chaveRecusada(this.d, ctx, c);
      else await this.d.repo.marcarChave({ estado: 'falhou', erro: ERRO_CHAVE_INVALIDA });
    }
    return ok(await situacaoGoogle(this.d.repo));
  }
}

export async function agendarGoogle(repo: RepoGoogle, id: string, atraso: number): Promise<void> {
  const job = await repo.enfileirar(TIPO_JOB_GOOGLE, { conexao_id: id }, atraso);
  await repo.atualizar(id, { job_sync_id: job });
}

/** Escolhe a conta e a agenda reconhecidas na chave e liga a sincronizacao com a Agenda. */
export class EscolherAgendaGoogle {
  constructor(private readonly d: DepsGoogle) {}
  async execute(ctx: ContextoCaso, e: { connection_id: string; calendario: string }): Promise<Result<SituacaoGoogle>> {
    const g = await this.d.repo.chave();
    if (!g) return fail(erroDe('sem_credencial', 'Cole a chave de API do Maton antes de escolher a agenda', 'chave'));
    if (g.estado === 'falhou') return fail(erroDe(ERRO_CHAVE_INVALIDA, 'Chave de API do Maton invalida', 'chave'));
    let calendarios;
    try {
      calendarios = await this.d.maton(this.d.cofre.decifrar(g.ref)).calendarios(e.connection_id);
    } catch (x) {
      return falha(x);
    }
    if (!calendarios.some((c) => c.id === e.calendario)) return fail(erroDe('nao_encontrado', 'Agenda nao encontrada nesta conta do Maton', 'calendario'));
    const atual = await this.d.repo.conexao();
    if (atual?.estado === 'ativo' && atual.connection_id === e.connection_id && atual.calendario === e.calendario) return ok(await situacaoGoogle(this.d.repo));
    const id = await this.d.repo.novaConexao(e.connection_id, e.calendario);
    await this.d.repo.mudarConector('ativo');
    await ctx.efeitos.auditar('google.agenda_escolher', TABELA, id, atual ? { connection_id: atual.connection_id, calendario: atual.calendario } : undefined, { connection_id: e.connection_id, calendario: e.calendario });
    await ctx.efeitos.publicar('conector.conectado', { slug: 'google-calendar', provedor: 'maton', reconexao: !!atual });
    await agendarGoogle(this.d.repo, id, 0);
    return ok(await situacaoGoogle(this.d.repo));
  }
}

/** Para a sincronizacao. Nada muda no Maton (a conexao com o Google e do dono). */
export class DesconectarGoogle {
  constructor(private readonly d: DepsGoogle) {}
  async execute(ctx: ContextoCaso): Promise<Result<void>> {
    const atual = await this.d.repo.conexao();
    if (!atual || atual.estado === 'desconectado') return fail(erroDe('nao_encontrado', 'Nenhuma agenda do Google sincronizando'));
    await pararSync(this.d, ctx, atual, 'desconectado', null);
    return ok(undefined);
  }
}

/** Remove a chave da subconta e para a sincronizacao. */
export class RemoverChaveMaton {
  constructor(private readonly d: DepsGoogle) {}
  async execute(ctx: ContextoCaso): Promise<Result<void>> {
    const g = await this.d.repo.chave();
    if (!g) return fail(erroDe('nao_encontrado', 'Nenhuma chave do Maton salva nesta subconta', 'chave'));
    const atual = await this.d.repo.conexao();
    if (atual && atual.estado !== 'desconectado') await pararSync(this.d, ctx, atual, 'desconectado', null);
    await this.d.repo.removerChave();
    await ctx.efeitos.auditar('google.chave_remover', 'integracoes_credenciais', null, { sufixo: g.sufixo }, undefined);
    return ok(undefined);
  }
}

/** Cliente com a chave da subconta, ou null quando nao ha chave valida. */
function clienteDa(d: DepsGoogle, g: ChaveGuardada | null): ApiMaton | null {
  return g && g.estado === 'ok' ? d.maton(d.cofre.decifrar(g.ref)) : null;
}

/** Job periodico: traz os eventos alterados do Google e entrega a Agenda. Eventos criados pelo ERP sao pulados. */
export class ImportarEventosGoogle {
  constructor(private readonly d: DepsGoogle) {}
  async execute(ctx: ContextoCaso, e: { conexao_id: string; job_id: string | null }): Promise<Result<{ importados: number } | null>> {
    const c = await this.d.repo.conexao();
    if (!c || c.id !== e.conexao_id || c.estado !== 'ativo') return ok(null);
    if (e.job_id && c.job_sync_id && c.job_sync_id !== e.job_id) return ok(null);
    const api = clienteDa(this.d, await this.d.repo.chave());
    if (!api) { await this.d.repo.atualizar(c.id, { job_sync_id: null, ultimo_erro: 'Sem chave valida do Maton' }); return ok(null); }
    const agora = this.d.agora?.() ?? new Date();
    const desde = c.atualizado_min ?? new Date(agora.getTime() - 30 * 86_400_000).toISOString();
    let importados = 0;
    let erro: string | null = null;
    try {
      const itens = (await api.eventos(c.connection_id, c.calendario, desde)).filter((x) => !x.extendedProperties?.private?.[MARCA]);
      if (itens.length) {
        const chave = `google:${c.connection_id}:${itens.map((x) => `${x.id}@${x.updated}`).join(',')}`;
        if (await this.d.repo.entregarAgenda(createHash('sha256').update(chave).digest('hex'), { calendar_id: c.calendario, items: itens })) importados = itens.length;
      }
    } catch (x) {
      if (!(x instanceof ErroProvedor)) throw x;
      if (recusada(x)) { await chaveRecusada(this.d, ctx, c); return ok(null); }
      erro = x.message;
    }
    await this.d.repo.atualizar(c.id, { sincronizado_em: agora.toISOString(), atualizado_min: erro ? c.atualizado_min : agora.toISOString(), importados: c.importados + importados, ultimo_erro: erro, job_sync_id: null });
    await agendarGoogle(this.d.repo, c.id, INTERVALO_GOOGLE_S);
    return ok({ importados });
  }
}

export interface EventoAgenda { id: string; inicio?: string; fim?: string; estado?: string }

/** Reacao a agenda.marcado, agenda.confirmado e agenda.cancelado: cria, atualiza ou apaga o evento no Google. */
export class EnviarAgendamentoGoogle {
  constructor(private readonly d: DepsGoogle) {}
  async execute(ctx: ContextoCaso, e: EventoAgenda & { cancelado: boolean }): Promise<Result<{ situacao: 'criado' | 'atualizado' | 'removido' | 'ignorado' }>> {
    const c: ConexaoGoogleDados | null = await this.d.repo.conexao();
    if (!c || c.estado !== 'ativo' || !e.id) return ok({ situacao: 'ignorado' });
    const api = clienteDa(this.d, await this.d.repo.chave());
    if (!api) return ok({ situacao: 'ignorado' });
    const existente = await this.d.repo.eventoDoCompromisso(e.id);
    try {
      if (e.cancelado) {
        if (!existente) return ok({ situacao: 'ignorado' });
        try { await api.excluirEvento(c.connection_id, c.calendario, existente); } catch (x) { if (!(x instanceof ErroProvedor && (x.status === 404 || x.status === 410))) throw x; }
        await this.d.repo.removerEvento(e.id);
        await ctx.efeitos.auditar('google.evento_remover', TABELA, c.id, undefined, { compromisso_id: e.id });
        return ok({ situacao: 'removido' });
      }
      if (!e.inicio || !e.fim) return ok({ situacao: 'ignorado' });
      const corpo = {
        summary: (await this.d.repo.tituloCompromisso(e.id)) ?? 'Agendamento',
        start: { dateTime: e.inicio }, end: { dateTime: e.fim },
        extendedProperties: { private: { [MARCA]: e.id } },
      };
      if (existente) {
        await api.atualizarEvento(c.connection_id, c.calendario, existente, corpo);
        return ok({ situacao: 'atualizado' });
      }
      const r = await api.criarEvento(c.connection_id, c.calendario, corpo);
      await this.d.repo.gravarEvento(e.id, r.id);
      await ctx.efeitos.auditar('google.evento_criar', TABELA, c.id, undefined, { compromisso_id: e.id, google_evento_id: r.id });
      return ok({ situacao: 'criado' });
    } catch (x) {
      if (recusada(x)) { await chaveRecusada(this.d, ctx, c); return fail(erroDe('provedor_recusou', 'Chave de API do Maton invalida')); }
      if (x instanceof ErroProvedor && x.permanente) return fail(erroDe('provedor_recusou', x.message));
      throw x;
    }
  }
}
