/**
 * Composicao do modulo: liga casos de uso aos adaptadores Postgres e HTTP para um cliente de transacao.
 * Usada pelas rotas, pelas tools, pelo worker e pelo seed. Nao importa Fastify nem o pool do servidor.
 */
import type pg from 'pg';
import { cifrarSegredo, decifrarSegredo, segredoAleatorio } from '@erp/shared/servidor';
import { AgenteRepoPg } from './agente/adapter/agente-repo-pg.ts';
import { DesvincularChaveAgente, RegistrarAgente, VincularChaveAgente } from './agente/use-case/agentes.ts';
import { chaveState, webhookZernio } from './ambiente.ts';
import { RegistroPg } from './conector/adapter/registro-pg.ts';
import { MudarEstadoConector } from './conector/use-case/estado.ts';
import { FonteRepoPg } from './fonte/adapter/fonte-repo-pg.ts';
import { CriarFonteLead, EditarFonteLead, ExcluirFonteLead, MudarEstadoFonteLead, RegistrarAvisoFonte, RotacionarSegredoFonteLead } from './fonte/use-case/fontes.ts';
import { ClienteMaton } from './google/adapter/cliente-maton.ts';
import { GoogleRepoPg } from './google/adapter/google-repo-pg.ts';
import { DesconectarGoogle, EnviarAgendamentoGoogle, EscolherAgendaGoogle, ImportarEventosGoogle, RemoverChaveMaton, SalvarChaveMaton, TestarChaveMaton } from './google/use-case/google.ts';
import { ClienteZernio } from './zernio/adapter/cliente-zernio.ts';
import { ZernioRepoPg } from './zernio/adapter/zernio-repo-pg.ts';
import { ConcluirConexaoZernio, DesconectarCanalZernio, IniciarConexaoZernio, SincronizarCanaisZernio, VincularContaExistenteZernio } from './zernio/use-case/conexao.ts';
import { ImportarConversasZernio } from './zernio/use-case/importacao.ts';
import { AplicarWebhookZernio, EntregarMensagemZernio } from './zernio/use-case/mensagens.ts';

export function casosDeUso(c: pg.PoolClient) {
  const agentes = new AgenteRepoPg(c);
  const zr = new ZernioRepoPg(c);
  const zapi = new ClienteZernio();
  const dz = { repo: zr, api: zapi, chaveState: chaveState(), webhook: webhookZernio() };
  // Google Agenda: cliente Maton montado com a chave da subconta (cifra do nucleo), nunca com chave de plataforma.
  const dg = { repo: new GoogleRepoPg(c), maton: (token: string) => new ClienteMaton({ token }), cofre: { cifrar: cifrarSegredo, decifrar: decifrarSegredo } };
  // Fontes de lead: segredo de assinatura gerado aqui, guardado so cifrado (mesma cifra do nucleo).
  const fontes = new FonteRepoPg(c);
  const cofreFonte = { novoSegredo: () => { const segredo = segredoAleatorio(24); return { segredo, ref: cifrarSegredo(segredo) }; } };
  return {
    mudarEstadoConector: new MudarEstadoConector({ registro: new RegistroPg(c) }),
    registrarAgente: new RegistrarAgente({ repo: agentes }),
    vincularChaveAgente: new VincularChaveAgente({ repo: agentes }),
    desvincularChaveAgente: new DesvincularChaveAgente({ repo: agentes }),
    iniciarZernio: new IniciarConexaoZernio(dz),
    concluirZernio: new ConcluirConexaoZernio(dz),
    sincronizarZernio: new SincronizarCanaisZernio(dz),
    desconectarZernio: new DesconectarCanalZernio(dz),
    vincularExistenteZernio: new VincularContaExistenteZernio(dz),
    aplicarWebhookZernio: new AplicarWebhookZernio({ repo: zr }),
    importarZernio: new ImportarConversasZernio({ repo: zr, api: zapi, tempoReal: !!dz.webhook }),
    entregarZernio: new EntregarMensagemZernio({ repo: zr, api: zapi }),
    salvarChaveMaton: new SalvarChaveMaton(dg),
    testarChaveMaton: new TestarChaveMaton(dg),
    escolherAgendaGoogle: new EscolherAgendaGoogle(dg),
    removerChaveMaton: new RemoverChaveMaton(dg),
    desconectarGoogle: new DesconectarGoogle(dg),
    importarGoogle: new ImportarEventosGoogle(dg),
    enviarGoogle: new EnviarAgendamentoGoogle(dg),
    criarFonte: new CriarFonteLead({ repo: fontes, destino: fontes, cofre: cofreFonte }),
    editarFonte: new EditarFonteLead({ repo: fontes, destino: fontes }),
    mudarEstadoFonte: new MudarEstadoFonteLead({ repo: fontes }),
    rotacionarSegredoFonte: new RotacionarSegredoFonteLead({ repo: fontes, cofre: cofreFonte }),
    excluirFonte: new ExcluirFonteLead({ repo: fontes }),
    registrarAvisoFonte: new RegistrarAvisoFonte({ repo: fontes }),
  };
}

export type CasosDeUso = ReturnType<typeof casosDeUso>;
