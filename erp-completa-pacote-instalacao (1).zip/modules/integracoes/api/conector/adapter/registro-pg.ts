/** Registro de conectores (tabela conectores do nucleo, UPDATE de estado) e players habilitados da subconta. */
import type pg from 'pg';
import { PLAYERS, type EstadoConector, type Player } from '../model/catalogo.ts';
import { reconciliarConectores } from '../query/conectores.ts';
import type { RegistroConectores } from '../use-case/estado.ts';

export class RegistroPg implements RegistroConectores {
  constructor(private readonly c: pg.PoolClient) {}
  async estado(slug: string): Promise<EstadoConector | null> {
    const r = await this.c.query(`SELECT estado FROM conectores WHERE slug = $1 AND deleted_at IS NULL`, [slug]);
    return (r.rows[0]?.estado as EstadoConector | undefined) ?? null;
  }
  async mudar(slug: string, estado: EstadoConector): Promise<void> {
    await this.c.query(`UPDATE conectores SET estado = $2 WHERE slug = $1 AND deleted_at IS NULL`, [slug, estado]);
  }
  reconciliar(): Promise<void> {
    return reconciliarConectores(this.c);
  }
}

export interface PlayerDTO { provedor: Player; habilitado: boolean }

export async function listarPlayers(c: pg.PoolClient): Promise<PlayerDTO[]> {
  const r = await c.query(`SELECT provedor, habilitado FROM integracoes_players WHERE deleted_at IS NULL`);
  const m = new Map(r.rows.map((l) => [l.provedor as string, l.habilitado as boolean]));
  return PLAYERS.map((p) => ({ provedor: p, habilitado: m.get(p) ?? false }));
}

export async function gravarPlayer(c: pg.PoolClient, provedor: Player, habilitado: boolean): Promise<void> {
  await c.query(
    `INSERT INTO integracoes_players (provedor, habilitado, creator_id) VALUES ($1, $2, nucleo_usuario_atual())
     ON CONFLICT (tenant_id, workspace_id, provedor) DO UPDATE SET habilitado = EXCLUDED.habilitado, deleted_at = NULL`,
    [provedor, habilitado],
  );
}

export interface RecebidoDTO { id: string; id_externo: string; estado: string; erro: string | null; payload: unknown; created_at: string }

/** Ultimos envios recebidos pelo webhook de entrada da landing (integracoes_eventos_recebidos do nucleo). */
export async function listarRecebidos(c: pg.PoolClient, conector: string, limite = 50): Promise<RecebidoDTO[]> {
  const r = await c.query(
    `SELECT id, id_externo, estado, erro, payload, created_at FROM integracoes_eventos_recebidos
     WHERE conector = $1 AND deleted_at IS NULL ORDER BY created_at DESC LIMIT $2`,
    [conector, Math.min(Math.max(limite, 1), 200)],
  );
  return r.rows.map((l) => ({ ...l, created_at: (l.created_at as Date).toISOString() })) as RecebidoDTO[];
}
