/** Ligar e desligar um conector (M14.1). Ligar volta para a regra de estado; Pix e boleto nao ligam nesta versao. */
import type { ContextoCaso } from '../../compartilhado/efeitos.ts';
import { erroDe, fail, ok, type Result } from '../../compartilhado/result.ts';
import { definicaoDe, type EstadoConector } from '../model/catalogo.ts';

export interface RegistroConectores {
  estado(slug: string): Promise<EstadoConector | null>;
  mudar(slug: string, estado: EstadoConector): Promise<void>;
  reconciliar(): Promise<void>;
}

export class MudarEstadoConector {
  constructor(private readonly d: { registro: RegistroConectores }) {}

  async execute(ctx: ContextoCaso, e: { slug: string; ligado: boolean }): Promise<Result<{ estado: EstadoConector }>> {
    const def = definicaoDe(e.slug);
    if (!def.ok) return def;
    const atual = await this.d.registro.estado(e.slug);
    if (!atual) return fail(erroDe('nao_encontrado', `Conector ${e.slug} nao registrado nesta subconta`, 'slug'));
    if (def.valor.fluxo === 'desligado') return fail(erroDe('transicao_invalida', 'Pix e boleto continuam desligados nesta versao', 'estado', { permitidas: [] }));
    if (!e.ligado && atual === 'desligado') return fail(erroDe('transicao_invalida', 'Conector ja esta desligado', 'estado', { permitidas: ['ligar'] }));
    if (e.ligado && atual !== 'desligado') return fail(erroDe('transicao_invalida', 'Conector ja esta ligado', 'estado', { permitidas: ['desligar'] }));
    await this.d.registro.mudar(e.slug, e.ligado ? 'aguardando_credencial' : 'desligado');
    if (e.ligado) await this.d.registro.reconciliar();
    const novo = (await this.d.registro.estado(e.slug))!;
    await ctx.efeitos.auditar(e.ligado ? 'conector.ligar' : 'conector.desligar', 'conectores', null, { slug: e.slug, estado: atual }, { slug: e.slug, estado: novo });
    if (novo === 'ativo') await ctx.efeitos.publicar('conector.conectado', { slug: e.slug, provedor: def.valor.provedor, reconexao: true });
    if (novo === 'desligado') await ctx.efeitos.publicar('conector.desconectado', { slug: e.slug, motivo: 'desligado' });
    return ok({ estado: novo });
  }
}
