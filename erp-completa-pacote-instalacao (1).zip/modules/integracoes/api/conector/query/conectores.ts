/**
 * Aba Conectores: catalogo + registro do nucleo (tabela conectores) + vinculos da subconta. Antes de ler,
 * reconcilia o estado de cada conector pela regra unica (estadoEsperado): nenhuma subconta depende de ajuste manual.
 */
import type pg from 'pg';
import { ambiente } from '../../ambiente.ts';
import { CATALOGO, estadoEsperado, type EstadoConector, type Fluxo, type Vinculos } from '../model/catalogo.ts';

export interface ConectorDTO {
  slug: string;
  provedor: string;
  fluxo: Fluxo;
  usado_por: string[];
  estado: string;
  entrada_configurada: boolean;
  atualizado: string | null;
}

export async function vinculos(c: pg.PoolClient): Promise<Vinculos> {
  const r = await c.query(`SELECT
      EXISTS (SELECT 1 FROM integracoes_canais WHERE canal = 'whatsapp' AND estado = 'ativo' AND deleted_at IS NULL) AS whatsapp,
      EXISTS (SELECT 1 FROM integracoes_canais WHERE canal = 'instagram' AND estado = 'ativo' AND deleted_at IS NULL) AS instagram,
      (EXISTS (SELECT 1 FROM integracoes_google_conexoes WHERE estado = 'ativo' AND deleted_at IS NULL)
        AND EXISTS (SELECT 1 FROM integracoes_credenciais WHERE conector = 'google-calendar' AND teste_estado = 'ok' AND deleted_at IS NULL)) AS google,
      (EXISTS (SELECT 1 FROM conectores WHERE slug = 'webhook-landing' AND segredo_entrada_ref IS NOT NULL AND deleted_at IS NULL)
        OR EXISTS (SELECT 1 FROM integracoes_fontes_lead WHERE NOT padrao AND segredo_ref IS NOT NULL AND deleted_at IS NULL)) AS entrada,
      EXISTS (SELECT 1 FROM integracoes_players WHERE habilitado AND deleted_at IS NULL) AS players`);
  const l = r.rows[0];
  return { canais: { whatsapp: l.whatsapp, instagram: l.instagram }, google: l.google, resend: ambiente.resend(), entrada: l.entrada, players: l.players };
}

/** Aplica a regra de estado a todos os conectores da subconta (idempotente). */
export async function reconciliarConectores(c: pg.PoolClient): Promise<void> {
  const v = await vinculos(c);
  const r = await c.query(`SELECT slug, estado FROM conectores WHERE deleted_at IS NULL`);
  for (const l of r.rows) {
    const def = CATALOGO.find((d) => d.slug === l.slug);
    if (!def) continue;
    const novo = estadoEsperado(def, l.estado as EstadoConector, v);
    if (novo !== l.estado) await c.query(`UPDATE conectores SET estado = $2 WHERE slug = $1 AND deleted_at IS NULL`, [l.slug, novo]);
  }
}

export async function listarConectores(c: pg.PoolClient): Promise<ConectorDTO[]> {
  await reconciliarConectores(c);
  const r = await c.query(
    `SELECT slug, provedor, estado, segredo_entrada_ref IS NOT NULL AS entrada_configurada, updated_at FROM conectores WHERE deleted_at IS NULL`,
  );
  const porSlug = new Map(r.rows.map((l) => [l.slug as string, l]));
  return CATALOGO.filter((d) => porSlug.has(d.slug)).map((d) => {
    const l = porSlug.get(d.slug)!;
    return {
      slug: d.slug, provedor: d.provedor, fluxo: d.fluxo, usado_por: d.usadoPor, estado: l.estado as string,
      entrada_configurada: l.entrada_configurada as boolean, atualizado: l.updated_at ? (l.updated_at as Date).toISOString() : null,
    };
  });
}
