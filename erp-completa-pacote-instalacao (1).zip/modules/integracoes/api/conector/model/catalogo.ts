/**
 * Catalogo de conectores do M14.1 (specs/modulos.json). Nenhum pede chave colada: cada um tem o proprio fluxo.
 * `canal`: WhatsApp e Instagram pela Zernio (Criar canal, tela da Meta). `chave`: Google Agenda pelo Maton com a
 * chave de API da propria subconta (colada no menu Agenda, guardada cifrada).
 * `plataforma`: chave da plataforma no cofre (Resend). `entrada`: URL e segredo por subconta (landing).
 * `habilitar`: sem credencial (players). `desligado`: fora do ar nesta versao (Pix e boleto).
 */
import { erroDe, fail, ok, type Result } from '../../compartilhado/result.ts';

export const ESTADOS_CONECTOR = ['aguardando_credencial', 'ativo', 'erro', 'desligado'] as const;
export type EstadoConector = (typeof ESTADOS_CONECTOR)[number];
export type Fluxo = 'canal' | 'chave' | 'plataforma' | 'entrada' | 'habilitar' | 'desligado';

export interface DefinicaoConector {
  slug: string;
  provedor: string;
  fluxo: Fluxo;
  /** Modulos que dependem do conector (a tela mostra o que fica desativado sem ele). */
  usadoPor: string[];
}

export const CATALOGO: readonly DefinicaoConector[] = [
  { slug: 'whatsapp', provedor: 'zernio', fluxo: 'canal', usadoPor: ['conversas', 'agenda', 'contas'] },
  { slug: 'instagram', provedor: 'zernio', fluxo: 'canal', usadoPor: ['conversas'] },
  { slug: 'google-calendar', provedor: 'maton', fluxo: 'chave', usadoPor: ['agenda'] },
  { slug: 'resend', provedor: 'resend', fluxo: 'plataforma', usadoPor: ['nucleo', 'contas'] },
  { slug: 'webhook-landing', provedor: 'erp', fluxo: 'entrada', usadoPor: ['cadastros', 'pipeline'] },
  { slug: 'players', provedor: 'youtube, vimeo, panda, bunny', fluxo: 'habilitar', usadoPor: ['treinamento'] },
  { slug: 'pix-boleto', provedor: 'asaas', fluxo: 'desligado', usadoPor: ['contas', 'assinaturas'] },
];

export const PLAYERS = ['youtube', 'vimeo', 'panda', 'bunny'] as const;
export type Player = (typeof PLAYERS)[number];

export function definicaoDe(slug: string): Result<DefinicaoConector> {
  const d = CATALOGO.find((x) => x.slug === slug);
  return d ? ok(d) : fail(erroDe('nao_encontrado', `Conector ${slug} nao existe no catalogo`, 'slug'));
}

/** Situacao de cada vinculo da subconta, base da regra de estado do conector. */
export interface Vinculos {
  canais: Record<'whatsapp' | 'instagram', boolean>;
  google: boolean;
  resend: boolean;
  entrada: boolean;
  players: boolean;
}

/**
 * Estado que o conector deve ter (regra unica, aplicada a toda subconta existente e futura).
 * Desligado pelo usuario continua desligado; Pix e boleto ficam sempre desligados.
 */
export function estadoEsperado(def: DefinicaoConector, atual: EstadoConector, v: Vinculos): EstadoConector {
  if (def.fluxo === 'desligado') return 'desligado';
  if (atual === 'desligado') return 'desligado';
  const pronto = def.slug === 'whatsapp' || def.slug === 'instagram' ? v.canais[def.slug]
    : def.slug === 'google-calendar' ? v.google
      : def.slug === 'resend' ? v.resend
        : def.slug === 'webhook-landing' ? v.entrada
          : def.slug === 'players' ? v.players : false;
  return pronto ? 'ativo' : 'aguardando_credencial';
}
