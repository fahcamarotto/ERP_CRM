/** Rotas do M14.1 sem fluxo externo: ligar e desligar, players de video e recebidos do webhook da landing. */
import { esquemaErro, exigirUsuario, requer, type FastifyInstance } from '@erp/api/sdk';
import { naTransacao, naoEncontrado } from '../borda.ts';
import { exigirOk } from '../compartilhado/result.ts';
import { slugConector } from '../esquemas.ts';
import { gravarPlayer, listarPlayers, listarRecebidos } from './adapter/registro-pg.ts';
import { PLAYERS, type Player } from './model/catalogo.ts';
import { listarConectores, reconciliarConectores } from './query/conectores.ts';

const tags = ['integracoes'];
const erros = { 400: esquemaErro, 403: esquemaErro, 404: esquemaErro, 409: esquemaErro };
const params = { type: 'object', required: ['slug'], properties: { slug: slugConector } };

export function rotasConector(app: FastifyInstance): void {
  app.post<{ Params: { slug: string }; Body: { ligado: boolean } }>('/conectores/:slug/estado', {
    preHandler: [exigirUsuario, requer('integracoes.editar')],
    schema: {
      tags, summary: 'Liga ou desliga o conector (MudarEstadoConector)', params,
      body: { type: 'object', additionalProperties: false, required: ['ligado'], properties: { ligado: { type: 'boolean' } } }, response: erros,
    },
  }, (req) => naTransacao(req, async (casos, ctx, c) => {
    exigirOk(await casos.mudarEstadoConector.execute(ctx, { slug: req.params.slug, ligado: req.body.ligado }));
    return (await listarConectores(c)).find((x) => x.slug === req.params.slug) ?? Promise.reject(naoEncontrado('Conector nao encontrado'));
  }));

  app.get('/players', {
    preHandler: requer('integracoes.ver'),
    schema: { tags, summary: 'Players de video (YouTube, Vimeo, Panda Video, Bunny Stream) e se estao habilitados' },
  }, (req) => naTransacao(req, (_casos, _ctx, c) => listarPlayers(c)));

  app.put<{ Params: { provedor: Player }; Body: { habilitado: boolean } }>('/players/:provedor', {
    preHandler: [exigirUsuario, requer('integracoes.editar')],
    schema: {
      tags, summary: 'Habilita ou desabilita um player de video (sem credencial)',
      params: { type: 'object', required: ['provedor'], properties: { provedor: { type: 'string', enum: [...PLAYERS] } } },
      body: { type: 'object', additionalProperties: false, required: ['habilitado'], properties: { habilitado: { type: 'boolean' } } }, response: erros,
    },
  }, (req) => naTransacao(req, async (_casos, ctx, c) => {
    const antes = (await listarPlayers(c)).find((p) => p.provedor === req.params.provedor);
    await gravarPlayer(c, req.params.provedor, req.body.habilitado);
    await reconciliarConectores(c);
    await ctx.efeitos.auditar('player.habilitar', 'integracoes_players', null, antes, { provedor: req.params.provedor, habilitado: req.body.habilitado });
    return listarPlayers(c);
  }));

  app.get<{ Querystring: { limite?: number } }>('/landing/recebidos', {
    preHandler: requer('integracoes.ver'),
    schema: { tags, summary: 'Ultimos envios recebidos pelo webhook de entrada da landing page', querystring: { type: 'object', properties: { limite: { type: 'integer', minimum: 1, maximum: 200 } } } },
  }, (req) => naTransacao(req, (_casos, _ctx, c) => listarRecebidos(c, 'webhook-landing', req.query.limite ?? 50)));
}
