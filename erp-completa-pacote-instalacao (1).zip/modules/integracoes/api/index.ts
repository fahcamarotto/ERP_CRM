/**
 * Plugin do modulo Integracoes (M14), registrado sozinho com prefixo /api/v1/integracoes.
 * Chaves de API, webhooks, entrada assinada e /mcp ficam no nucleo (/api/v1/nucleo/*); aqui moram os fluxos
 * dos conectores (Zernio, Maton, Resend, landing, players) e os agentes MCP. Importar ./tools.ts registra as @tool.
 */
import type { FastifyPluginAsync } from '@erp/api/sdk';
import './tools.ts';
import { rotasAgente } from './agente/routes.ts';
import { rotasConector } from './conector/routes.ts';
import { rotasFonte } from './fonte/routes.ts';
import { rotasGoogle } from './google/routes.ts';
import { rotasResend } from './resend/routes.ts';
import { corrigirWebhookNaPartida, rotasZernio } from './zernio/routes.ts';

const plugin: FastifyPluginAsync = async (app) => {
  rotasConector(app);
  rotasFonte(app);
  rotasZernio(app);
  rotasGoogle(app);
  rotasResend(app);
  rotasAgente(app);
  // Tunel local muda de URL a cada partida: o webhook proprio do ERP e corrigido sem bloquear a subida.
  app.addHook('onReady', async () => { void corrigirWebhookNaPartida((m) => app.log.info(m)); });
};

export default plugin;
