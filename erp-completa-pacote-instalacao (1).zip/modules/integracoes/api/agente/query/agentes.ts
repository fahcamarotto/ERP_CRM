import type pg from 'pg';
import { AGENTES, NOMES_AGENTE, type Agente } from '../model/agente-mcp.ts';
import { snippetAgente, type SnippetAgente } from '../model/snippets.ts';

export interface AgenteDTO {
  id: string | null;
  agente: Agente;
  nome: string;
  chave_id: string | null;
  chave_prefixo: string | null;
  escopos: string[];
  estado: string;
  vinculado_em: string | null;
  snippet: SnippetAgente;
}

/** Os tres agentes sempre aparecem (registrados ou nao), cada um com o snippet pronto. */
export async function listarAgentes(c: pg.PoolClient, url: string): Promise<AgenteDTO[]> {
  const r = await c.query(`SELECT id, agente, nome, chave_id, chave_prefixo, escopos, estado, vinculado_em FROM integracoes_agentes_mcp WHERE deleted_at IS NULL`);
  const por = new Map(r.rows.map((l) => [l.agente as string, l]));
  return AGENTES.map((a) => {
    const l = por.get(a);
    return {
      id: (l?.id as string | undefined) ?? null,
      agente: a,
      nome: (l?.nome as string | undefined) ?? NOMES_AGENTE[a],
      chave_id: (l?.chave_id as string | null | undefined) ?? null,
      chave_prefixo: (l?.chave_prefixo as string | null | undefined) ?? null,
      escopos: (l?.escopos as string[] | undefined) ?? [],
      estado: (l?.estado as string | undefined) ?? 'sem_chave',
      vinculado_em: l?.vinculado_em ? (l.vinculado_em as Date).toISOString() : null,
      snippet: snippetAgente(a, url),
    };
  });
}
