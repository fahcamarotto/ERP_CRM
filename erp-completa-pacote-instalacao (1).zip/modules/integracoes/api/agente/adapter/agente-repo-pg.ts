import type pg from 'pg';
import { AgenteMcp, type AgenteMcpDados } from '../model/agente-mcp.ts';
import type { GravarAgente, ObterAgente } from '../model/portas.ts';

export class AgenteRepoPg implements ObterAgente, GravarAgente {
  constructor(private readonly c: pg.PoolClient) {}

  async obterPorAgente(agente: string): Promise<AgenteMcp | null> {
    const r = await this.c.query(
      `SELECT id, agente, nome, chave_id, chave_prefixo, escopos, estado, vinculado_em FROM integracoes_agentes_mcp WHERE agente = $1 AND deleted_at IS NULL`,
      [agente],
    );
    const l = r.rows[0];
    return l ? AgenteMcp.reidratar({ ...l, vinculado_em: l.vinculado_em ? (l.vinculado_em as Date).toISOString() : null } as AgenteMcpDados) : null;
  }

  async inserir(x: AgenteMcp): Promise<void> {
    const d = x.paraDados();
    await this.c.query(
      `INSERT INTO integracoes_agentes_mcp (id, agente, nome, chave_id, chave_prefixo, escopos, estado, vinculado_em, creator_id)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, nucleo_usuario_atual())`,
      [d.id, d.agente, d.nome, d.chave_id, d.chave_prefixo, d.escopos, d.estado, d.vinculado_em],
    );
  }

  async atualizar(x: AgenteMcp): Promise<void> {
    const d = x.paraDados();
    await this.c.query(
      `UPDATE integracoes_agentes_mcp SET nome = $2, chave_id = $3, chave_prefixo = $4, escopos = $5, estado = $6, vinculado_em = $7 WHERE id = $1 AND deleted_at IS NULL`,
      [d.id, d.nome, d.chave_id, d.chave_prefixo, d.escopos, d.estado, d.vinculado_em],
    );
  }
}
