/**
 * Casos de uso dos agentes MCP: vincular a chave recem-criada (a chave nasce em POST /api/v1/nucleo/chaves)
 * e desvincular. O registro do agente nasce sozinho no primeiro vinculo ou pelo seed.
 */
import type { ContextoCaso } from '../../compartilhado/efeitos.ts';
import { erroDe, fail, ok, type Result } from '../../compartilhado/result.ts';
import { AgenteMcp } from '../model/agente-mcp.ts';
import type { GravarAgente, ObterAgente } from '../model/portas.ts';

const TABELA = 'integracoes_agentes_mcp';
type Repo = ObterAgente & GravarAgente;

export class RegistrarAgente {
  constructor(private readonly deps: { repo: Repo }) {}
  async execute(ctx: ContextoCaso, e: { agente: string; nome?: string | null }, id?: string): Promise<Result<{ id: string }>> {
    const r = AgenteMcp.tryCreate(e, id);
    if (!r.ok) return r;
    if (await this.deps.repo.obterPorAgente(e.agente)) return fail(erroDe('conflito', `Agente ${e.agente} ja registrado`, 'agente'));
    await this.deps.repo.inserir(r.valor);
    await ctx.efeitos.auditar('agente_mcp.registrar', TABELA, r.valor.id, undefined, r.valor.paraDados());
    return ok({ id: r.valor.id });
  }
}

export interface EntradaVinculo { agente: string; chave_id: string; chave_prefixo: string; escopos: string[] }

export class VincularChaveAgente {
  constructor(private readonly deps: { repo: Repo }) {}
  async execute(ctx: ContextoCaso, e: EntradaVinculo): Promise<Result<{ id: string }>> {
    let atual = await this.deps.repo.obterPorAgente(e.agente);
    let novo = false;
    if (!atual) {
      const c = AgenteMcp.tryCreate({ agente: e.agente });
      if (!c.ok) return c;
      atual = c.valor;
      novo = true;
    }
    const r = atual.vincular(e);
    if (!r.ok) return r;
    if (novo) await this.deps.repo.inserir(r.valor);
    else await this.deps.repo.atualizar(r.valor);
    const d = r.valor.paraDados();
    await ctx.efeitos.auditar('agente_mcp.vincular', TABELA, d.id, novo ? undefined : atual.paraDados(), d);
    await ctx.efeitos.publicar('agente_mcp.conectado', { agente: d.agente, chave_prefixo: d.chave_prefixo, escopos: d.escopos });
    return ok({ id: d.id });
  }
}

export class DesvincularChaveAgente {
  constructor(private readonly deps: { repo: Repo }) {}
  async execute(ctx: ContextoCaso, e: { agente: string }): Promise<Result<{ chave_id: string | null }>> {
    const atual = await this.deps.repo.obterPorAgente(e.agente);
    if (!atual) return fail(erroDe('nao_encontrado', `Agente ${e.agente} nao registrado`, 'agente'));
    const r = atual.revogar();
    if (!r.ok) return r;
    await this.deps.repo.atualizar(r.valor);
    await ctx.efeitos.auditar('agente_mcp.desvincular', TABELA, atual.id, atual.paraDados(), r.valor.paraDados());
    await ctx.efeitos.publicar('agente_mcp.desconectado', { agente: e.agente });
    return ok({ chave_id: atual.paraDados().chave_id });
  }
}
