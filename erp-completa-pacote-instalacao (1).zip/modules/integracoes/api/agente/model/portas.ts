import type { AgenteMcp } from './agente-mcp.ts';

export interface ObterAgente { obterPorAgente(agente: string): Promise<AgenteMcp | null> }
export interface GravarAgente { inserir(x: AgenteMcp): Promise<void>; atualizar(x: AgenteMcp): Promise<void> }
