/**
 * Snippets de conexao MCP (M14.6) para OpenClaw, Hermes e Naia Claude. Formato .mcp.json, transporte
 * http e cabecalho Authorization com a variavel ${ERP_MCP_KEY}: a chave nunca entra no arquivo.
 */
import { AGENTES, NOMES_AGENTE, type Agente } from './agente-mcp.ts';

export const VARIAVEL_CHAVE = 'ERP_MCP_KEY';

export interface SnippetAgente {
  agente: Agente;
  nome: string;
  arquivo: string;
  conteudo: string;
  variavel: string;
  comando: string | null;
}

const ONDE: Record<Agente, string> = {
  openclaw: '.mcp.json (mcpServers do gateway OpenClaw)',
  hermes: '.mcp.json (servidores MCP do Hermes)',
  'naia-claude': '.mcp.json (raiz do projeto da Naia Claude)',
};

export function urlMcp(base: string): string {
  return `${base.replace(/\/+$/, '')}/mcp`;
}

export function snippetAgente(agente: Agente, url: string): SnippetAgente {
  const conteudo = JSON.stringify({ mcpServers: { erp: { type: 'http', url, headers: { Authorization: `Bearer \${${VARIAVEL_CHAVE}}` } } } }, null, 2);
  return {
    agente,
    nome: NOMES_AGENTE[agente],
    arquivo: ONDE[agente],
    conteudo,
    variavel: VARIAVEL_CHAVE,
    comando: agente === 'naia-claude' ? `claude mcp add --transport http erp ${url} --header "Authorization: Bearer \${${VARIAVEL_CHAVE}}"` : null,
  };
}

export function snippets(url: string, agente?: Agente): SnippetAgente[] {
  return (agente ? [agente] : [...AGENTES]).map((a) => snippetAgente(a, url));
}
