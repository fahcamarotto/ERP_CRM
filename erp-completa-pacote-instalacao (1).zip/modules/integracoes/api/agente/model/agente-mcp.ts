/**
 * Entidade raiz AgenteMcp (M14.5, M14.6): um agente externo (OpenClaw, Hermes, Naia Claude) ligado
 * a uma chave de API do workspace. Guarda so id e prefixo da chave, nunca o segredo.
 */
import { randomUUID } from 'node:crypto';
import { erroDe, fail, ok, type ErroDominio, type Result } from '../../compartilhado/result.ts';

export const AGENTES = ['openclaw', 'hermes', 'naia-claude'] as const;
export type Agente = (typeof AGENTES)[number];
export const NOMES_AGENTE: Record<Agente, string> = { openclaw: 'OpenClaw', hermes: 'Hermes', 'naia-claude': 'Naia Claude' };

export const ESTADOS_AGENTE = ['sem_chave', 'conectado', 'revogado'] as const;
export type EstadoAgente = (typeof ESTADOS_AGENTE)[number];
export const TRANSICOES_AGENTE: Record<EstadoAgente, EstadoAgente[]> = {
  sem_chave: ['conectado'],
  conectado: ['conectado', 'revogado'],
  revogado: ['conectado'],
};

/** Mesmo formato de escopo da chave de API do nucleo. */
export const PADRAO_ESCOPO = /^(\*|\*:(leitura|escrita)|[a-z0-9_-]+:(leitura|escrita))$/;
export const PADRAO_PREFIXO = /^erp_live_[0-9a-f]{8}$/;
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;

export interface AgenteMcpDados {
  id: string;
  agente: Agente;
  nome: string;
  chave_id: string | null;
  chave_prefixo: string | null;
  escopos: string[];
  estado: EstadoAgente;
  vinculado_em: string | null;
}

export function validarChave(e: { chave_id?: unknown; chave_prefixo?: unknown; escopos?: unknown }): ErroDominio[] {
  const erros: ErroDominio[] = [];
  if (typeof e.chave_id !== 'string' || !UUID.test(e.chave_id)) erros.push(erroDe('chave_invalida', 'Id da chave invalido', 'chave_id'));
  if (typeof e.chave_prefixo !== 'string' || !PADRAO_PREFIXO.test(e.chave_prefixo)) erros.push(erroDe('prefixo_invalido', 'Prefixo deve ser erp_live_ seguido de 8 hex', 'chave_prefixo'));
  const esc = Array.isArray(e.escopos) ? e.escopos : [];
  if (!esc.length) erros.push(erroDe('escopo_obrigatorio', 'Informe ao menos um escopo', 'escopos'));
  for (const s of esc) if (typeof s !== 'string' || !PADRAO_ESCOPO.test(s)) erros.push(erroDe('escopo_invalido', `Escopo invalido: ${String(s)}`, 'escopos'));
  return erros;
}

export class AgenteMcp {
  private constructor(private readonly p: AgenteMcpDados) {}

  static tryCreate(e: { agente: string; nome?: string | null }, id: string = randomUUID()): Result<AgenteMcp> {
    const erros: ErroDominio[] = [];
    if (!(AGENTES as readonly string[]).includes(e.agente)) erros.push(erroDe('agente_invalido', `Agente deve ser ${AGENTES.join(', ')}`, 'agente', { permitidos: AGENTES }));
    const nome = (e.nome ?? '').trim() || NOMES_AGENTE[e.agente as Agente] || '';
    if (nome.length < 2 || nome.length > 80) erros.push(erroDe('nome_invalido', 'Nome com 2 a 80 caracteres', 'nome'));
    if (erros.length) return fail(...erros);
    return ok(new AgenteMcp({ id, agente: e.agente as Agente, nome, chave_id: null, chave_prefixo: null, escopos: [], estado: 'sem_chave', vinculado_em: null }));
  }

  static create(e: { agente: string; nome?: string | null }, id?: string): AgenteMcp {
    const r = AgenteMcp.tryCreate(e, id);
    if (!r.ok) throw new Error(r.erros[0]!.mensagem);
    return r.valor;
  }

  static reidratar(d: AgenteMcpDados): AgenteMcp {
    return new AgenteMcp({ ...d, escopos: [...d.escopos] });
  }

  get id(): string { return this.p.id; }
  get agente(): Agente { return this.p.agente; }
  get estado(): EstadoAgente { return this.p.estado; }

  private transicao(novo: EstadoAgente): ErroDominio | null {
    const permitidas = TRANSICOES_AGENTE[this.p.estado];
    return permitidas.includes(novo) ? null : erroDe('transicao_invalida', `Agente em ${this.p.estado} nao vai para ${novo}`, 'estado', { permitidas });
  }

  vincular(e: { chave_id: string; chave_prefixo: string; escopos: string[] }, quando: Date = new Date()): Result<AgenteMcp> {
    const erros = validarChave(e);
    const t = this.transicao('conectado');
    if (t) erros.push(t);
    if (erros.length) return fail(...erros);
    return ok(new AgenteMcp({ ...this.p, chave_id: e.chave_id, chave_prefixo: e.chave_prefixo, escopos: [...new Set(e.escopos)], estado: 'conectado', vinculado_em: quando.toISOString() }));
  }

  revogar(): Result<AgenteMcp> {
    const t = this.transicao('revogado');
    return t ? fail(t) : ok(new AgenteMcp({ ...this.p, estado: 'revogado' }));
  }

  paraDados(): AgenteMcpDados {
    return { ...this.p, escopos: [...this.p.escopos] };
  }
}
