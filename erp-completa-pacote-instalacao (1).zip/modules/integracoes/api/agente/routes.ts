/** Rotas dos agentes MCP: vincular a chave recem-criada no nucleo e desvincular. So pessoa com sessao. */
import { esquemaErro, exigirUsuario, requer, type FastifyInstance } from '@erp/api/sdk';
import { naTransacao, naoEncontrado } from '../borda.ts';
import { exigirOk } from '../compartilhado/result.ts';
import { agente, propsVinculo, urlBase } from '../esquemas.ts';
import { urlMcp } from './model/snippets.ts';
import { listarAgentes } from './query/agentes.ts';
import type { EntradaVinculo } from './use-case/agentes.ts';

const tags = ['integracoes'];
const erros = { 400: esquemaErro, 403: esquemaErro, 404: esquemaErro, 409: esquemaErro };
const params = { type: 'object', required: ['agente'], properties: { agente } };

export function rotasAgente(app: FastifyInstance): void {
  app.post<{ Params: { agente: string }; Body: Omit<EntradaVinculo, 'agente'> }>('/mcp/agentes/:agente/chave', {
    preHandler: [exigirUsuario, requer('integracoes.criar')],
    schema: {
      tags, summary: 'Vincula ao agente a chave criada em POST /api/v1/nucleo/chaves (VincularChaveAgente)', params,
      body: { type: 'object', additionalProperties: false, required: ['chave_id', 'chave_prefixo', 'escopos'], properties: propsVinculo }, response: erros,
    },
  }, (req) => naTransacao(req, async (casos, ctx, c) => {
    exigirOk(await casos.vincularChaveAgente.execute(ctx, { agente: req.params.agente, ...req.body }));
    return (await listarAgentes(c, urlMcp(urlBase()))).find((a) => a.agente === req.params.agente) ?? Promise.reject(naoEncontrado('Agente nao encontrado'));
  }));

  app.delete<{ Params: { agente: string } }>('/mcp/agentes/:agente/chave', {
    preHandler: [exigirUsuario, requer('integracoes.editar')],
    schema: { tags, summary: 'Desvincula a chave do agente (revogue a chave em DELETE /api/v1/nucleo/chaves/:id)', params, response: erros },
  }, (req) => naTransacao(req, async (casos, ctx) => exigirOk(await casos.desvincularChaveAgente.execute(ctx, { agente: req.params.agente }))));
}
