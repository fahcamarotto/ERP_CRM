/**
 * Adaptador Postgres das fontes de lead (integracoes_fontes_lead) e da consulta de destino nas tabelas
 * publicadas do Pipeline (pipeline_funis, pipeline_etapas) e em usuarios do nucleo. RLS limita a subconta.
 */
import type pg from 'pg';
import { FonteLead, type FonteLeadDados } from '../model/fonte-lead.ts';
import type { ConsultarDestino, GravarFonte, NomeEmUso, ObterFonte } from '../model/portas.ts';

const COLUNAS = 'id, nome, padrao, funil_id, etapa_id, tags, responsavel_id, estado';

export class FonteRepoPg implements ObterFonte, GravarFonte, NomeEmUso, ConsultarDestino {
  constructor(private readonly c: pg.PoolClient) {}

  async obterPorId(id: string): Promise<FonteLead | null> {
    const r = await this.c.query(`SELECT ${COLUNAS} FROM integracoes_fontes_lead WHERE id = $1 AND deleted_at IS NULL`, [id]);
    return r.rows[0] ? FonteLead.reidratar(r.rows[0] as FonteLeadDados) : null;
  }

  async nomeEmUso(nome: string, excetoId?: string): Promise<boolean> {
    const r = await this.c.query(
      `SELECT 1 FROM integracoes_fontes_lead WHERE lower(nome) = lower($1) AND deleted_at IS NULL AND ($2::uuid IS NULL OR id <> $2)`,
      [nome, excetoId ?? null],
    );
    return (r.rowCount ?? 0) > 0;
  }

  async inserir(x: FonteLead, segredoRef: string | null): Promise<{ token: string }> {
    const d = x.paraDados();
    const r = await this.c.query(
      `INSERT INTO integracoes_fontes_lead (id, nome, padrao, funil_id, etapa_id, tags, responsavel_id, estado, segredo_ref, creator_id)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, nucleo_usuario_atual()) RETURNING token`,
      [d.id, d.nome, d.padrao, d.funil_id, d.etapa_id, d.tags, d.responsavel_id, d.estado, segredoRef],
    );
    return { token: r.rows[0].token as string };
  }

  async atualizar(x: FonteLead): Promise<void> {
    const d = x.paraDados();
    // Editar o destino limpa o aviso de destino substituido.
    await this.c.query(
      `UPDATE integracoes_fontes_lead SET nome = $2, funil_id = $3, etapa_id = $4, tags = $5, responsavel_id = $6, estado = $7,
              aviso = CASE WHEN funil_id IS DISTINCT FROM $3 OR etapa_id IS DISTINCT FROM $4 THEN NULL ELSE aviso END,
              aviso_em = CASE WHEN funil_id IS DISTINCT FROM $3 OR etapa_id IS DISTINCT FROM $4 THEN NULL ELSE aviso_em END
       WHERE id = $1 AND deleted_at IS NULL`,
      [d.id, d.nome, d.funil_id, d.etapa_id, d.tags, d.responsavel_id, d.estado],
    );
  }

  async excluir(id: string): Promise<void> {
    await this.c.query(`UPDATE integracoes_fontes_lead SET deleted_at = now(), estado = 'pausada' WHERE id = $1 AND deleted_at IS NULL AND NOT padrao`, [id]);
  }

  async trocarSegredo(x: FonteLead, segredoRef: string): Promise<{ token: string }> {
    if (x.padraoDaSubconta) {
      // URL antiga: o segredo mora no conector webhook-landing (o mesmo que a tela antiga gerava).
      await this.c.query(`UPDATE conectores SET segredo_entrada_ref = $1 WHERE slug = 'webhook-landing' AND deleted_at IS NULL`, [segredoRef]);
      const r = await this.c.query(`SELECT token FROM integracoes_fontes_lead WHERE id = $1`, [x.id]);
      return { token: r.rows[0].token as string };
    }
    const r = await this.c.query(`UPDATE integracoes_fontes_lead SET segredo_ref = $2 WHERE id = $1 AND deleted_at IS NULL RETURNING token`, [x.id, segredoRef]);
    return { token: r.rows[0].token as string };
  }

  async registrarAviso(id: string, aviso: string): Promise<boolean> {
    const r = await this.c.query(`UPDATE integracoes_fontes_lead SET aviso = $2, aviso_em = now() WHERE id = $1 AND deleted_at IS NULL`, [id, aviso.slice(0, 500)]);
    return (r.rowCount ?? 0) > 0;
  }

  async conferir(funilId: string | null, etapaId: string | null): Promise<string | null> {
    if (!funilId) return null;
    const f = await this.c.query(`SELECT arquivado FROM pipeline_funis WHERE id = $1 AND deleted_at IS NULL`, [funilId]);
    if (!f.rows[0]) return 'Pipeline nao encontrado';
    if (f.rows[0].arquivado) return 'Pipeline arquivado nao recebe leads';
    if (!etapaId) return null;
    const e = await this.c.query(`SELECT funil_id, tipo FROM pipeline_etapas WHERE id = $1 AND deleted_at IS NULL`, [etapaId]);
    if (!e.rows[0]) return 'Etapa nao encontrada';
    if (e.rows[0].funil_id !== funilId) return 'A etapa e de outro pipeline';
    if (e.rows[0].tipo !== 'aberta') return 'Escolha uma etapa aberta (nao Ganho nem Perdido)';
    return null;
  }

  async usuarioAtivo(id: string): Promise<boolean> {
    const r = await this.c.query(`SELECT 1 FROM usuarios WHERE id = $1 AND ativo AND deleted_at IS NULL`, [id]);
    return (r.rowCount ?? 0) > 0;
  }
}
