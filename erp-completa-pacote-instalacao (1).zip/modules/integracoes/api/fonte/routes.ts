/**
 * Rotas das fontes de lead (varias landing pages por subconta). Listar, obter e criar tambem sao @tool (tools.ts).
 * O segredo volta so na criacao e na rotacao. A URL publica e POST /api/v1/webhooks/webhook-landing/<token>.
 */
import { esquemaErro, exigirUsuario, requer, type FastifyInstance } from '@erp/api/sdk';
import { naTransacao, naoEncontrado } from '../borda.ts';
import { exigirOk } from '../compartilhado/result.ts';
import { propsFonte, urlBase, uuid } from '../esquemas.ts';
import type { EntradaFonte } from './model/fonte-lead.ts';
import { destinosFonte, listarFontes, recebidosDaFonte, urlDaFonte } from './query/fontes.ts';

const tags = ['integracoes'];
const erros = { 400: esquemaErro, 403: esquemaErro, 404: esquemaErro, 409: esquemaErro };
const params = { type: 'object', required: ['id'], properties: { id: uuid } };

export function rotasFonte(app: FastifyInstance): void {
  app.get('/fontes-lead/destinos', {
    preHandler: requer('integracoes.ver'),
    schema: { tags, summary: 'Opcoes de destino da fonte: pipelines ativos com etapas abertas, usuarios ativos e tags existentes' },
  }, (req) => naTransacao(req, (_casos, _ctx, c) => destinosFonte(c)));

  app.patch<{ Params: { id: string }; Body: EntradaFonte }>('/fontes-lead/:id', {
    preHandler: [exigirUsuario, requer('integracoes.editar')],
    schema: { tags, summary: 'Edita nome, pipeline e etapa de destino, tags e responsavel da fonte', params, body: { type: 'object', additionalProperties: false, properties: propsFonte }, response: erros },
  }, (req) => naTransacao(req, async (casos, ctx, c) => {
    exigirOk(await casos.editarFonte.execute(ctx, { ...req.body, id: req.params.id }));
    return (await listarFontes(c, urlBase(), req.params.id))[0];
  }));

  app.post<{ Params: { id: string }; Body: { estado: 'ativa' | 'pausada' } }>('/fontes-lead/:id/estado', {
    preHandler: [exigirUsuario, requer('integracoes.editar')],
    schema: {
      tags, summary: 'Pausa (a URL passa a recusar envios) ou reativa a fonte', params,
      body: { type: 'object', additionalProperties: false, required: ['estado'], properties: { estado: { type: 'string', enum: ['ativa', 'pausada'] } } }, response: erros,
    },
  }, (req) => naTransacao(req, async (casos, ctx, c) => {
    exigirOk(await casos.mudarEstadoFonte.execute(ctx, { id: req.params.id, estado: req.body.estado }));
    return (await listarFontes(c, urlBase(), req.params.id))[0];
  }));

  app.post<{ Params: { id: string } }>('/fontes-lead/:id/segredo', {
    preHandler: [exigirUsuario, requer('integracoes.editar')],
    schema: { tags, summary: 'Gera um segredo novo (aparece uma vez); o anterior deixa de valer na hora', params, response: erros },
  }, (req) => naTransacao(req, async (casos, ctx) => {
    const r = exigirOk(await casos.rotacionarSegredoFonte.execute(ctx, { id: req.params.id }));
    return { id: r.id, url: urlDaFonte(urlBase(), r.token), segredo: r.segredo, assinatura: 'X-Hub-Signature-256: sha256=<HMAC-SHA256 hex do corpo cru>' };
  }));

  app.delete<{ Params: { id: string } }>('/fontes-lead/:id', {
    preHandler: [exigirUsuario, requer('integracoes.excluir')],
    schema: { tags, summary: 'Exclui a fonte (a URL deixa de existir). A fonte padrao nao pode ser excluida', params, response: erros },
  }, (req) => naTransacao(req, async (casos, ctx) => exigirOk(await casos.excluirFonte.execute(ctx, { id: req.params.id }))));

  app.get<{ Params: { id: string }; Querystring: { limite?: number } }>('/fontes-lead/:id/recebidos', {
    preHandler: requer('integracoes.ver'),
    schema: { tags, summary: 'Ultimos leads recebidos pela fonte', params, querystring: { type: 'object', properties: { limite: { type: 'integer', minimum: 1, maximum: 100 } } } },
  }, (req) => naTransacao(req, async (_casos, _ctx, c) => {
    if (!(await listarFontes(c, urlBase(), req.params.id)).length) throw naoEncontrado('Fonte de lead nao encontrada');
    return recebidosDaFonte(c, req.params.id, req.query.limite ?? 20);
  }));
}
