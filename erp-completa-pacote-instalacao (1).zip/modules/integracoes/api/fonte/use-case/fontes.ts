/**
 * Casos de uso das fontes de lead: criar (URL e segredo proprios), editar destino, tags e responsavel, pausar e
 * reativar, rotacionar o segredo, excluir e registrar o aviso de destino substituido (reacao ao Pipeline).
 * O segredo aparece uma unica vez (na criacao e na rotacao); so a cifra fica gravada.
 */
import type { ContextoCaso } from '../../compartilhado/efeitos.ts';
import { erroDe, fail, ok, type Result } from '../../compartilhado/result.ts';
import { FonteLead, type EntradaFonte, type FonteLeadDados } from '../model/fonte-lead.ts';
import type { Cofre, ConsultarDestino, GravarFonte, NomeEmUso, ObterFonte } from '../model/portas.ts';

export const TABELA_FONTES = 'integracoes_fontes_lead';
type Repo = ObterFonte & GravarFonte & NomeEmUso;

async function conferirReferencias(d: ConsultarDestino, x: FonteLeadDados): Promise<Result<void>> {
  const motivo = await d.conferir(x.funil_id, x.etapa_id);
  if (motivo) return fail(erroDe('destino_invalido', motivo, x.etapa_id ? 'etapa_id' : 'funil_id'));
  if (x.responsavel_id && !(await d.usuarioAtivo(x.responsavel_id))) return fail(erroDe('responsavel_invalido', 'Responsavel nao e um usuario ativo desta subconta', 'responsavel_id'));
  return ok(undefined);
}

async function obter(repo: ObterFonte, id: string): Promise<Result<FonteLead>> {
  const f = await repo.obterPorId(id);
  return f ? ok(f) : fail(erroDe('nao_encontrado', 'Fonte de lead nao encontrada'));
}

export class CriarFonteLead {
  constructor(private readonly deps: { repo: Repo; destino: ConsultarDestino; cofre: Cofre }) {}
  async execute(ctx: ContextoCaso, e: EntradaFonte): Promise<Result<{ id: string; token: string; segredo: string }>> {
    const r = FonteLead.tryCreate(e);
    if (!r.ok) return r;
    const d = r.valor.paraDados();
    if (await this.deps.repo.nomeEmUso(d.nome)) return fail(erroDe('conflito', 'Ja existe uma fonte com este nome', 'nome'));
    const refs = await conferirReferencias(this.deps.destino, d);
    if (!refs.ok) return refs;
    const s = this.deps.cofre.novoSegredo();
    const { token } = await this.deps.repo.inserir(r.valor, s.ref);
    await ctx.efeitos.auditar('fonte_lead.criar', TABELA_FONTES, d.id, undefined, d);
    return ok({ id: d.id, token, segredo: s.segredo });
  }
}

export class EditarFonteLead {
  constructor(private readonly deps: { repo: Repo; destino: ConsultarDestino }) {}
  async execute(ctx: ContextoCaso, e: EntradaFonte & { id: string }): Promise<Result<{ id: string }>> {
    const atual = await obter(this.deps.repo, e.id);
    if (!atual.ok) return atual;
    const { id, ...mud } = e;
    const r = atual.valor.editar(mud);
    if (!r.ok) return r;
    const d = r.valor.paraDados();
    if (mud.nome !== undefined && (await this.deps.repo.nomeEmUso(d.nome, id))) return fail(erroDe('conflito', 'Ja existe uma fonte com este nome', 'nome'));
    const refs = await conferirReferencias(this.deps.destino, d);
    if (!refs.ok) return refs;
    await this.deps.repo.atualizar(r.valor);
    await ctx.efeitos.auditar('fonte_lead.editar', TABELA_FONTES, id, atual.valor.paraDados(), d);
    return ok({ id });
  }
}

export class MudarEstadoFonteLead {
  constructor(private readonly deps: { repo: Repo }) {}
  async execute(ctx: ContextoCaso, e: { id: string; estado: string }): Promise<Result<{ id: string; estado: string }>> {
    const atual = await obter(this.deps.repo, e.id);
    if (!atual.ok) return atual;
    const r = atual.valor.mudarEstado(e.estado);
    if (!r.ok) return r;
    await this.deps.repo.atualizar(r.valor);
    await ctx.efeitos.auditar(`fonte_lead.${r.valor.estado === 'pausada' ? 'pausar' : 'reativar'}`, TABELA_FONTES, e.id, { estado: atual.valor.estado }, { estado: r.valor.estado });
    return ok({ id: e.id, estado: r.valor.estado });
  }
}

export class RotacionarSegredoFonteLead {
  constructor(private readonly deps: { repo: Repo; cofre: Cofre }) {}
  async execute(ctx: ContextoCaso, e: { id: string }): Promise<Result<{ id: string; token: string; segredo: string }>> {
    const atual = await obter(this.deps.repo, e.id);
    if (!atual.ok) return atual;
    const s = this.deps.cofre.novoSegredo();
    const { token } = await this.deps.repo.trocarSegredo(atual.valor, s.ref);
    await ctx.efeitos.auditar('fonte_lead.rotacionar_segredo', TABELA_FONTES, e.id, undefined, { padrao: atual.valor.padraoDaSubconta });
    return ok({ id: e.id, token, segredo: s.segredo });
  }
}

export class ExcluirFonteLead {
  constructor(private readonly deps: { repo: Repo }) {}
  async execute(ctx: ContextoCaso, e: { id: string }): Promise<Result<{ id: string }>> {
    const atual = await obter(this.deps.repo, e.id);
    if (!atual.ok) return atual;
    const pode = atual.valor.podeExcluir();
    if (!pode.ok) return pode;
    await this.deps.repo.excluir(e.id);
    await ctx.efeitos.auditar('fonte_lead.excluir', TABELA_FONTES, e.id, atual.valor.paraDados(), undefined);
    return ok({ id: e.id });
  }
}

const MOTIVOS: Record<string, string> = {
  etapa_removida: 'a etapa escolhida foi removida',
  etapa_fechada: 'a etapa escolhida nao e uma etapa aberta',
  etapa_de_outro_pipeline: 'a etapa escolhida e de outro pipeline',
  pipeline_removido: 'o pipeline escolhido foi removido',
  pipeline_arquivado: 'o pipeline escolhido foi arquivado',
};

/** Reacao a lead.destino_substituido do Pipeline: o lead foi para a primeira etapa do pipeline padrao. */
export class RegistrarAvisoFonte {
  constructor(private readonly deps: { repo: GravarFonte }) {}
  async execute(e: { fonte_id?: string | null; motivo?: string | null }): Promise<Result<{ registrado: boolean }>> {
    if (!e.fonte_id) return ok({ registrado: false });
    const motivo = MOTIVOS[e.motivo ?? ''] ?? 'o destino escolhido nao recebe oportunidades';
    const aviso = `Lead enviado para a primeira etapa do pipeline padrao porque ${motivo}. Edite a fonte e escolha outro destino.`;
    return ok({ registrado: await this.deps.repo.registrarAviso(e.fonte_id, aviso) });
  }
}
