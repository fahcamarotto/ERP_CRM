/**
 * Entidade raiz FonteLead: uma landing page (ou formulario) com URL propria, segredo proprio e destino no Pipeline
 * (pipeline e etapa), tags aplicadas ao cliente, responsavel opcional e ativa ou pausada. A fonte padrao e a URL
 * unica antiga do conector webhook-landing: nunca e excluida e usa o segredo do conector.
 */
import { randomUUID } from 'node:crypto';
import { erroDe, fail, ok, type ErroDominio, type Result } from '../../compartilhado/result.ts';

export const ESTADOS_FONTE = ['ativa', 'pausada'] as const;
export type EstadoFonte = (typeof ESTADOS_FONTE)[number];
export const NOME_FONTE_PADRAO = 'Landing page padrão';
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;

export interface FonteLeadDados {
  id: string;
  nome: string;
  padrao: boolean;
  funil_id: string | null;
  etapa_id: string | null;
  tags: string[];
  responsavel_id: string | null;
  estado: EstadoFonte;
}

export interface EntradaFonte {
  nome?: string | null;
  funil_id?: string | null;
  etapa_id?: string | null;
  tags?: string[] | null;
  responsavel_id?: string | null;
}

/** Tags por nome: aparadas, sem repeticao (ignora caixa), 1 a 60 caracteres, no maximo 20. */
export function normalizarTags(tags: unknown): Result<string[]> {
  if (tags == null) return ok([]);
  if (!Array.isArray(tags)) return fail(erroDe('tags_invalidas', 'Tags devem ser uma lista de nomes', 'tags'));
  const vistas = new Set<string>();
  const saida: string[] = [];
  for (const t of tags) {
    if (typeof t !== 'string') return fail(erroDe('tags_invalidas', 'Cada tag e um texto', 'tags'));
    const n = t.trim();
    if (!n) continue;
    if (n.length > 60) return fail(erroDe('tags_invalidas', 'Tag com no maximo 60 caracteres', 'tags'));
    if (vistas.has(n.toLowerCase())) continue;
    vistas.add(n.toLowerCase());
    saida.push(n);
  }
  if (saida.length > 20) return fail(erroDe('tags_invalidas', 'No maximo 20 tags por fonte', 'tags'));
  return ok(saida);
}

function validar(e: Required<Pick<FonteLeadDados, 'nome'>> & EntradaFonte): Result<Pick<FonteLeadDados, 'nome' | 'funil_id' | 'etapa_id' | 'tags' | 'responsavel_id'>> {
  const erros: ErroDominio[] = [];
  const nome = (e.nome ?? '').trim();
  if (nome.length < 2 || nome.length > 80) erros.push(erroDe('nome_invalido', 'Nome com 2 a 80 caracteres', 'nome'));
  const funil = e.funil_id ?? null;
  const etapa = e.etapa_id ?? null;
  const resp = e.responsavel_id ?? null;
  if (funil && !UUID.test(funil)) erros.push(erroDe('funil_invalido', 'Pipeline invalido', 'funil_id'));
  if (etapa && !UUID.test(etapa)) erros.push(erroDe('etapa_invalida', 'Etapa invalida', 'etapa_id'));
  if (etapa && !funil) erros.push(erroDe('etapa_invalida', 'Escolha o pipeline da etapa', 'etapa_id'));
  if (resp && !UUID.test(resp)) erros.push(erroDe('responsavel_invalido', 'Responsavel invalido', 'responsavel_id'));
  const tags = normalizarTags(e.tags);
  if (!tags.ok) erros.push(...tags.erros);
  if (erros.length) return fail(...erros);
  return ok({ nome, funil_id: funil, etapa_id: etapa, tags: tags.ok ? tags.valor : [], responsavel_id: resp });
}

export class FonteLead {
  private constructor(private readonly p: FonteLeadDados) {}

  static tryCreate(e: EntradaFonte, id: string = randomUUID()): Result<FonteLead> {
    const v = validar({ ...e, nome: e.nome ?? '' });
    if (!v.ok) return v;
    return ok(new FonteLead({ id, padrao: false, estado: 'ativa', ...v.valor }));
  }

  static create(e: EntradaFonte, id?: string): FonteLead {
    const r = FonteLead.tryCreate(e, id);
    if (!r.ok) throw new Error(r.erros[0]!.mensagem);
    return r.valor;
  }

  /** A URL unica antiga: destino pipeline padrao, primeira etapa. */
  static padrao(id: string = randomUUID()): FonteLead {
    return new FonteLead({ id, nome: NOME_FONTE_PADRAO, padrao: true, funil_id: null, etapa_id: null, tags: [], responsavel_id: null, estado: 'ativa' });
  }

  static reidratar(d: FonteLeadDados): FonteLead {
    return new FonteLead({ ...d, tags: [...d.tags] });
  }

  get id(): string { return this.p.id; }
  get padraoDaSubconta(): boolean { return this.p.padrao; }
  get estado(): EstadoFonte { return this.p.estado; }

  editar(m: EntradaFonte): Result<FonteLead> {
    const v = validar({
      nome: m.nome ?? this.p.nome,
      funil_id: m.funil_id === undefined ? this.p.funil_id : m.funil_id,
      etapa_id: m.etapa_id === undefined ? (m.funil_id === undefined ? this.p.etapa_id : null) : m.etapa_id,
      tags: m.tags === undefined ? this.p.tags : m.tags,
      responsavel_id: m.responsavel_id === undefined ? this.p.responsavel_id : m.responsavel_id,
    });
    if (!v.ok) return v;
    return ok(new FonteLead({ ...this.p, ...v.valor }));
  }

  mudarEstado(estado: string): Result<FonteLead> {
    if (!(ESTADOS_FONTE as readonly string[]).includes(estado)) return fail(erroDe('estado_invalido', 'Estado deve ser ativa ou pausada', 'estado'));
    if (estado === this.p.estado) return fail(erroDe('transicao_invalida', `A fonte ja esta ${estado}`, 'estado'));
    return ok(new FonteLead({ ...this.p, estado: estado as EstadoFonte }));
  }

  podeExcluir(): Result<void> {
    if (this.p.padrao) return fail(erroDe('conflito', 'A fonte padrao (URL antiga) nao pode ser excluida; pause se quiser parar de receber'));
    return ok(undefined);
  }

  paraDados(): FonteLeadDados {
    return { ...this.p, tags: [...this.p.tags] };
  }
}
