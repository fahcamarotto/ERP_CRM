import type { FonteLead } from './fonte-lead.ts';

export interface ObterFonte { obterPorId(id: string): Promise<FonteLead | null> }
export interface GravarFonte {
  /** Insere com o segredo cifrado (null na fonte padrao) e devolve o token publico gerado pelo banco. */
  inserir(x: FonteLead, segredoRef: string | null): Promise<{ token: string }>;
  atualizar(x: FonteLead): Promise<void>;
  excluir(id: string): Promise<void>;
  /** Troca o segredo: na fonte padrao grava no conector webhook-landing (URL antiga). */
  trocarSegredo(x: FonteLead, segredoRef: string): Promise<{ token: string }>;
  registrarAviso(id: string, aviso: string): Promise<boolean>;
}
export interface NomeEmUso { nomeEmUso(nome: string, excetoId?: string): Promise<boolean> }

/** Destino no Pipeline (tabelas publicadas pipeline_funis e pipeline_etapas) e responsavel (usuarios do nucleo). */
export interface ConsultarDestino {
  /** null quando valido; senao o motivo (pipeline inexistente ou arquivado, etapa de outro pipeline ou fechada). */
  conferir(funilId: string | null, etapaId: string | null): Promise<string | null>;
  usuarioAtivo(id: string): Promise<boolean>;
}

/** Segredo de assinatura: gera o valor exibido uma vez e a cifra guardada. */
export interface Cofre { novoSegredo(): { segredo: string; ref: string } }
