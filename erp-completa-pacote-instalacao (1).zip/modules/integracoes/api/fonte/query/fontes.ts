/**
 * Leituras das fontes de lead: lista com URL, contador e ultimo recebido, aviso de destino (gravado pelo Pipeline
 * ou detectado agora nas tabelas publicadas), recebidos por fonte e opcoes de destino (pipelines ativos com etapas
 * abertas, usuarios ativos e tags existentes). A fonte padrao nasce aqui em subconta que ainda nao tem.
 */
import type pg from 'pg';
import { NOME_FONTE_PADRAO } from '../model/fonte-lead.ts';

export interface FonteDTO {
  id: string; nome: string; padrao: boolean; url: string; estado: 'ativa' | 'pausada'; segredo_configurado: boolean;
  funil_id: string | null; funil_nome: string | null; etapa_id: string | null; etapa_nome: string | null;
  tags: string[]; responsavel_id: string | null; responsavel_nome: string | null;
  recebidos: number; ultimo_em: string | null; aviso: string | null; aviso_em: string | null; created_at: string;
}
export interface RecebidoFonteDTO { id: string; estado: string; erro: string | null; nome: string | null; email: string | null; telefone: string | null; created_at: string }
export interface DestinosDTO {
  funis: { id: string; nome: string; padrao: boolean; etapas: { id: string; nome: string }[] }[];
  usuarios: { id: string; nome: string }[];
  tags: string[];
}

export function urlDaFonte(base: string, token: string): string {
  return `${base.replace(/\/$/, '')}/api/v1/webhooks/webhook-landing/${token}`;
}

/** Fonte padrao (URL antiga do conector webhook-landing) em toda subconta, sem passo manual. Idempotente. */
export async function garantirFontePadrao(c: pg.PoolClient): Promise<void> {
  await c.query(
    `INSERT INTO integracoes_fontes_lead (nome, token, padrao)
     SELECT $1, k.token_entrada, true FROM conectores k
     WHERE k.slug = 'webhook-landing' AND k.deleted_at IS NULL
       AND NOT EXISTS (SELECT 1 FROM integracoes_fontes_lead f WHERE f.padrao AND f.deleted_at IS NULL)
     ON CONFLICT DO NOTHING`,
    [NOME_FONTE_PADRAO],
  );
}

const AVISO_AGORA = `CASE
  WHEN f.funil_id IS NOT NULL AND (fu.id IS NULL OR fu.deleted_at IS NOT NULL) THEN 'O pipeline escolhido foi removido: novos leads vao para a primeira etapa do pipeline padrao.'
  WHEN fu.arquivado THEN 'O pipeline escolhido foi arquivado: novos leads vao para a primeira etapa do pipeline padrao.'
  WHEN f.etapa_id IS NOT NULL AND (e.id IS NULL OR e.deleted_at IS NOT NULL) THEN 'A etapa escolhida foi removida: novos leads vao para a primeira etapa do pipeline padrao.'
  WHEN e.id IS NOT NULL AND (e.tipo <> 'aberta' OR e.funil_id <> f.funil_id) THEN 'A etapa escolhida nao recebe leads: novos leads vao para a primeira etapa do pipeline padrao.'
  ELSE NULL END`;

export async function listarFontes(c: pg.PoolClient, base: string, id?: string): Promise<FonteDTO[]> {
  await garantirFontePadrao(c);
  const r = await c.query(
    `SELECT f.id, f.nome, f.padrao, f.token, f.estado, f.funil_id, f.etapa_id, f.tags, f.responsavel_id, f.created_at,
            fu.nome AS funil_nome, e.nome AS etapa_nome, u.nome AS responsavel_nome,
            CASE WHEN f.padrao THEN k.segredo_entrada_ref IS NOT NULL ELSE f.segredo_ref IS NOT NULL END AS segredo_configurado,
            COALESCE(${AVISO_AGORA}, f.aviso) AS aviso, f.aviso_em,
            (SELECT count(*)::int FROM integracoes_eventos_recebidos x WHERE x.fonte_id = f.id AND x.deleted_at IS NULL) AS recebidos,
            (SELECT max(x.created_at) FROM integracoes_eventos_recebidos x WHERE x.fonte_id = f.id AND x.deleted_at IS NULL) AS ultimo_em
       FROM integracoes_fontes_lead f
       LEFT JOIN pipeline_funis fu ON fu.id = f.funil_id
       LEFT JOIN pipeline_etapas e ON e.id = f.etapa_id
       LEFT JOIN usuarios u ON u.id = f.responsavel_id
       LEFT JOIN conectores k ON k.slug = 'webhook-landing' AND k.deleted_at IS NULL
      WHERE f.deleted_at IS NULL AND ($1::uuid IS NULL OR f.id = $1)
      ORDER BY f.padrao DESC, f.created_at`,
    [id ?? null],
  );
  return r.rows.map((l) => ({
    id: l.id, nome: l.nome, padrao: l.padrao, url: urlDaFonte(base, l.token), estado: l.estado, segredo_configurado: l.segredo_configurado,
    funil_id: l.funil_id, funil_nome: l.funil_nome ?? null, etapa_id: l.etapa_id, etapa_nome: l.etapa_nome ?? null,
    tags: l.tags ?? [], responsavel_id: l.responsavel_id, responsavel_nome: l.responsavel_nome ?? null,
    recebidos: l.recebidos, ultimo_em: l.ultimo_em ? (l.ultimo_em as Date).toISOString() : null,
    aviso: l.aviso ?? null, aviso_em: l.aviso_em ? (l.aviso_em as Date).toISOString() : null, created_at: (l.created_at as Date).toISOString(),
  }));
}

export async function recebidosDaFonte(c: pg.PoolClient, id: string, limite = 20): Promise<RecebidoFonteDTO[]> {
  const r = await c.query(
    `SELECT id, estado, erro, created_at,
            COALESCE(payload->>'nome', payload->>'name', payload->'data'->>'nome', payload->'data'->>'name') AS nome,
            COALESCE(payload->>'email', payload->'data'->>'email') AS email,
            COALESCE(payload->>'telefone', payload->>'phone', payload->>'whatsapp', payload->'data'->>'telefone') AS telefone
       FROM integracoes_eventos_recebidos WHERE fonte_id = $1 AND deleted_at IS NULL ORDER BY created_at DESC LIMIT $2`,
    [id, Math.min(Math.max(limite, 1), 100)],
  );
  return r.rows.map((l) => ({ ...l, created_at: (l.created_at as Date).toISOString() })) as RecebidoFonteDTO[];
}

export async function destinosFonte(c: pg.PoolClient): Promise<DestinosDTO> {
  const f = await c.query(`SELECT id, nome, padrao FROM pipeline_funis WHERE NOT arquivado AND deleted_at IS NULL ORDER BY padrao DESC, ordem, nome`);
  const e = await c.query(`SELECT id, nome, funil_id FROM pipeline_etapas WHERE tipo = 'aberta' AND deleted_at IS NULL ORDER BY ordem, nome`);
  const u = await c.query(`SELECT id, nome FROM usuarios WHERE ativo AND deleted_at IS NULL ORDER BY nome LIMIT 500`);
  const t = await c.query(`SELECT nome FROM cadastros_classificacoes WHERE tipo = 'tag' AND deleted_at IS NULL ORDER BY nome LIMIT 500`);
  return {
    funis: f.rows.map((x) => ({ id: x.id, nome: x.nome, padrao: x.padrao, etapas: e.rows.filter((y) => y.funil_id === x.id).map((y) => ({ id: y.id, nome: y.nome })) })),
    usuarios: u.rows as { id: string; nome: string }[],
    tags: t.rows.map((x) => x.nome as string),
  };
}
