/**
 * Espelhamento integral da Zernio (ImportarConversasZernio): varre todas as conversas do canal (cursor da
 * varredura em integracoes_canais.import_cursor) e, por conversa, as mensagens da mais nova para a mais antiga
 * com cursor proprio (integracoes_zernio_conversas.historico_cursor) ate o fim do historico. Entrada e saida,
 * midia com tipo e URL, status e data entram no Conversas pelo envelope `erp.mensagens`, idempotente pelo id da
 * mensagem (reexecutar nao duplica). Cada job tem um prazo: estourou, grava os cursores e agenda a continuacao.
 * Depois da primeira passada a varredura e incremental (conversa sem `updatedTime` novo nao e relida).
 */
import type { ContextoCaso } from '../../compartilhado/efeitos.ts';
import { ErroProvedor } from '../../compartilhado/http.ts';
import { ok, type Result } from '../../compartilhado/result.ts';
import { envelopeErp, itemDoHistorico } from '../model/webhook.ts';
import type { ApiZernio, CanalDados, ConversaVinculada, ConversaZernio, RepoZernio } from '../model/portas.ts';
import { agendarImportacao, INTERVALO_POLLING_S } from './conexao.ts';

export interface DepsImportacao {
  repo: RepoZernio;
  api: ApiZernio;
  /** Webhook ativo (tunel ou URL publica): sem ele a importacao incremental se reagenda a cada 20 s. */
  tempoReal: boolean;
  /** Tempo maximo de um job (ms). */
  prazoMs?: number;
  agora?: () => number;
}

class PrazoEsgotado extends Error {}

export class ImportarConversasZernio {
  constructor(private readonly d: DepsImportacao) {}

  private agora() { return this.d.agora?.() ?? Date.now(); }

  /** `job_id` e o id do job atual: so o job mais novo do canal continua a cadeia (sem cadeia duplicada). */
  async execute(_ctx: ContextoCaso, e: { canal_id: string; job_id: string | null }): Promise<Result<{ importadas: number; reagendado: boolean; continua: boolean } | null>> {
    const c = await this.d.repo.canal(e.canal_id);
    if (!c || c.estado !== 'ativo') return ok(null);
    if (e.job_id && c.job_sync_id && c.job_sync_id !== e.job_id) return ok(null);
    const prazo = this.agora() + (this.d.prazoMs ?? 45_000);
    const cont = { n: 0 };
    let erro: string | null = null;
    let cursor: string | null = c.import_cursor ?? null;
    try {
      for (;;) {
        const r = await this.d.api.conversas(c.conta_id, c.canal, cursor);
        let mudou = false;
        for (const conv of r.itens) {
          if (conv.conta_id && conv.conta_id !== c.conta_id) continue;
          if (conv.plataforma && conv.plataforma !== c.canal) continue;
          if (await this.importarConversa(c, conv, prazo, cont)) mudou = true;
        }
        if (!r.proximo || r.proximo === cursor) break;
        // Incremental: lista vem da mais atualizada para a menos; pagina sem novidade encerra a varredura.
        if (c.historico_completo && !mudou) break;
        cursor = r.proximo;
        await this.d.repo.atualizarCanal(c.id, { import_cursor: cursor });
        if (this.agora() > prazo) throw new PrazoEsgotado();
      }
    } catch (x) {
      if (x instanceof PrazoEsgotado) {
        await this.d.repo.atualizarCanal(c.id, { importadas: c.importadas + cont.n, sincronizado_em: new Date(this.agora()).toISOString(), ultimo_erro: null, job_sync_id: null });
        await agendarImportacao(this.d.repo, [c.id], 0);
        return ok({ importadas: cont.n, reagendado: true, continua: true });
      }
      if (!(x instanceof ErroProvedor)) throw x;
      erro = x.message;
    }
    await this.d.repo.atualizarCanal(c.id, {
      sincronizado_em: new Date(this.agora()).toISOString(), importadas: c.importadas + cont.n, ultimo_erro: erro, job_sync_id: null,
      ...(erro ? {} : { import_cursor: null, historico_completo: true }),
    });
    const reagendar = !this.d.tempoReal;
    if (reagendar) await agendarImportacao(this.d.repo, [c.id], INTERVALO_POLLING_S);
    return ok({ importadas: cont.n, reagendado: reagendar, continua: false });
  }

  /** Importa as mensagens novas e o que falta do historico de uma conversa. true = havia novidade. */
  private async importarConversa(c: CanalDados, conv: ConversaZernio, prazo: number, cont: { n: number }): Promise<boolean> {
    const contato = conv.participante.replace(/^\+/, '');
    const antes = await this.d.repo.conversaExterna(c.id, conv.id);
    if (antes?.historico_completo && conv.atualizada && antes.atualizada_externa === conv.atualizada) return false;
    await this.d.repo.gravarConversa({ canal_id: c.id, canal: c.canal, conversa_externa_id: conv.id, contato, nome: conv.nome, usuario: conv.usuario ?? null, foto: conv.foto ?? null });
    const v: ConversaVinculada = antes ?? { canal_id: c.id, conta_id: c.conta_id, conversa_externa_id: conv.id, ultima_mensagem_id: null, historico_cursor: null, historico_completo: false };
    const entregar = async (ms: Awaited<ReturnType<ApiZernio['mensagens']>>['itens']) => {
      // A mais antiga primeiro: a conversa termina com a ultima mensagem certa.
      const itens = ms.slice().reverse().map((m) => itemDoHistorico(contato, conv, m)).filter((x) => !!x);
      for (const it of itens) {
        if (await this.d.repo.entregarAoConversas(c.canal, `zernio:msg:${it.id_externo}`, envelopeErp([it]))) cont.n++;
      }
    };
    // 1) Topo: da mais nova ate a ultima ja importada (ou, na primeira vez, o historico inteiro).
    const primeira = !v.ultima_mensagem_id;
    let cur: string | null = null;
    let topo: string | null = null;
    for (;;) {
      const r = await this.d.api.mensagens(c.conta_id, conv.id, cur);
      const corte = v.ultima_mensagem_id ? r.itens.findIndex((m) => m.id === v.ultima_mensagem_id) : -1;
      const novas = corte >= 0 ? r.itens.slice(0, corte) : r.itens;
      topo ??= r.itens[0]?.id ?? null;
      await entregar(novas);
      if (topo && topo !== v.ultima_mensagem_id) await this.d.repo.atualizarConversa(c.id, conv.id, { ultima_mensagem_id: topo });
      if (corte >= 0 || !r.proximo) {
        if (primeira) await this.d.repo.atualizarConversa(c.id, conv.id, { historico_cursor: null, historico_completo: true, atualizada_externa: conv.atualizada ?? null });
        break;
      }
      cur = r.proximo;
      if (primeira) await this.d.repo.atualizarConversa(c.id, conv.id, { historico_cursor: cur });
      if (this.agora() > prazo) throw new PrazoEsgotado();
    }
    // 2) Historico interrompido numa execucao anterior: continua do cursor gravado ate o fim.
    if (!primeira && !v.historico_completo) {
      let h = v.historico_cursor ?? null;
      while (h) {
        const r = await this.d.api.mensagens(c.conta_id, conv.id, h);
        await entregar(r.itens);
        h = r.proximo && r.proximo !== h ? r.proximo : null;
        await this.d.repo.atualizarConversa(c.id, conv.id, { historico_cursor: h, ...(h ? {} : { historico_completo: true }) });
        if (h && this.agora() > prazo) throw new PrazoEsgotado();
      }
      if (!v.historico_cursor) await this.d.repo.atualizarConversa(c.id, conv.id, { historico_completo: true });
    }
    await this.d.repo.atualizarConversa(c.id, conv.id, { atualizada_externa: conv.atualizada ?? null });
    return true;
  }
}
