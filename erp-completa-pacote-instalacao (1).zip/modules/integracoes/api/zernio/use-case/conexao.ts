/**
 * Conexao de canal pela Zernio (replica do sistema de agentes de referencia): garante 1 profile por subconta, emite state
 * assinado de uso unico, pede o authUrl da Meta, conclui no callback confirmando a conta pela API, sincroniza
 * e desconecta. Nenhuma chave e colada: a chave de plataforma vem do ambiente (cofre) pelo adaptador.
 */
import type { ContextoCaso } from '../../compartilhado/efeitos.ts';
import { emitirState, hashState, validarState, type Escopo } from '../../compartilhado/estado-oauth.ts';
import { ErroProvedor, hostPermitido } from '../../compartilhado/http.ts';
import { erroDe, fail, ok, type Result } from '../../compartilhado/result.ts';
import { PLATAFORMAS, type ApiZernio, type CanalDados, type Plataforma, type RepoZernio } from '../model/portas.ts';

export const HOSTS_AUTORIZACAO = ['zernio.com', 'facebook.com', 'instagram.com'];
export const TIPO_JOB_IMPORTAR = 'integracoes.zernio_importar';
/** Sem webhook (tunel ou URL publica) a importacao incremental roda a cada 20 s. */
export const INTERVALO_POLLING_S = 20;
const TABELA = 'integracoes_canais';

/** `webhook` so existe com URL publica https: o ERP registra o proprio webhook na Zernio (tempo real). */
export interface DepsZernio { repo: RepoZernio; api: ApiZernio; chaveState: string; webhook?: { url: string; segredo: string; nome: string } | null; agora?: () => number }

export const EVENTOS_WEBHOOK = ['message.received', 'message.sent', 'message.delivered', 'message.read', 'message.failed', 'account.connected', 'account.disconnected', 'comment.received', 'whatsapp.template.status_updated'];

/**
 * Registra ou corrige o webhook PROPRIO do ERP na Zernio (um por equipe, nao por subconta), idempotente: acha so
 * pelo nome do ERP ou pela URL do ERP (nunca toca webhook de outro sistema), cria se faltar e atualiza URL,
 * eventos, estado ou contas divergentes. Filtrado por accountIds: so as contas ligadas a canais do ERP chegam.
 * `contas` null (partida da API) so corrige a URL do webhook ja existente, sem criar.
 */
export async function garantirWebhook(api: ApiZernio, w: DepsZernio['webhook'], contas: string[] | null): Promise<'sem_url_publica' | 'sem_contas' | 'criado' | 'atualizado' | 'ok'> {
  if (!w?.url || !w.segredo) return 'sem_url_publica';
  const hooks = await api.webhooks();
  const atual = hooks.find((x) => x.name === w.nome) ?? hooks.find((x) => x.url === w.url);
  const ids = [...new Set([...(atual?.accountIds ?? []), ...(contas ?? [])])].sort();
  if (!ids.length || (contas === null && !atual)) return 'sem_contas';
  const conf = { name: w.nome, url: w.url, events: EVENTOS_WEBHOOK, secret: w.segredo, accountIds: ids };
  if (!atual) { await api.criarWebhook(conf); return 'criado'; }
  const iguais = atual.url === w.url && atual.ativo && atual.name === w.nome && EVENTOS_WEBHOOK.every((e) => atual.events.includes(e))
    && ids.length === atual.accountIds.length && ids.every((x) => atual.accountIds.includes(x));
  if (iguais) return 'ok';
  await api.atualizarWebhook(atual.id, { ...conf, isActive: true });
  return 'atualizado';
}

export function falhaProvedor(e: unknown): Result<never> {
  if (e instanceof ErroProvedor) return fail(erroDe(e.codigo === 'sem_credencial' ? 'sem_credencial' : 'provedor_falhou', e.message, undefined, { status: e.status }));
  throw e;
}

function conflitoConta(e: unknown): boolean {
  return !!e && typeof e === 'object' && (e as { code?: string }).code === '23505';
}

/** Liga o conector do canal quando ha canal ativo e volta a aguardar quando nao ha. */
export async function reconciliarConectores(repo: RepoZernio): Promise<Record<Plataforma, boolean>> {
  const canais = await repo.canais();
  const r = {} as Record<Plataforma, boolean>;
  for (const p of PLATAFORMAS) {
    r[p] = canais.some((c) => c.canal === p && c.estado === 'ativo');
    await repo.mudarConector(p, r[p] ? 'ativo' : 'aguardando_credencial');
  }
  return r;
}

export class IniciarConexaoZernio {
  constructor(private readonly d: DepsZernio) {}

  async execute(ctx: ContextoCaso, e: { plataforma: string; escopo: Escopo; base: string; retorno?: string }): Promise<Result<{ authUrl: string; profile_id: string }>> {
    if (!PLATAFORMAS.includes(e.plataforma as Plataforma)) return fail(erroDe('plataforma_invalida', 'Escolha WhatsApp ou Instagram', 'plataforma'));
    const plataforma = e.plataforma as Plataforma;
    try {
      let profile = await this.d.repo.perfil();
      if (!profile) {
        const nome = `ERP ${e.escopo.workspace.slice(0, 8)}`;
        profile = (await this.d.api.criarPerfil(nome, `erp-zernio-profile-${e.escopo.tenant}-${e.escopo.workspace}`)).profile_id;
        await this.d.repo.gravarPerfil(profile, nome);
        await ctx.efeitos.auditar('zernio.perfil_criar', 'integracoes_zernio_perfis', null, undefined, { profile_id: profile });
      }
      const st = emitirState(this.d.chaveState, { ...e.escopo, provedor: 'zernio', plataforma, ...(e.retorno ? { retorno: e.retorno } : {}) }, this.d.agora?.());
      await this.d.repo.gravarState(st.hash, 'zernio', plataforma, st.expira);
      const redirect = `${e.base.replace(/\/$/, '')}/api/v1/integracoes/zernio/callback?crm_state=${encodeURIComponent(st.state)}`;
      const authUrl = await this.d.api.urlConexao(plataforma, profile, redirect);
      if (!hostPermitido(authUrl, HOSTS_AUTORIZACAO)) return fail(erroDe('url_autorizacao_invalida', 'A Zernio devolveu um endereco de autorizacao fora do permitido'));
      await ctx.efeitos.auditar('zernio.conexao_iniciar', TABELA, null, undefined, { plataforma, profile_id: profile });
      return ok({ authUrl, profile_id: profile });
    } catch (x) {
      return falhaProvedor(x);
    }
  }
}

export class ConcluirConexaoZernio {
  constructor(private readonly d: DepsZernio) {}

  async execute(ctx: ContextoCaso, e: { state: unknown; escopo: Escopo; erro?: string | null }): Promise<Result<{ plataforma: Plataforma; canais: string[]; retorno: string | null }>> {
    const v = validarState(this.d.chaveState, e.state, e.escopo, 'zernio', this.d.agora?.());
    if (!v.ok) return v;
    if (!(await this.d.repo.consumirState(hashState(e.state as string)))) return fail(erroDe('state_usado', 'Esta autorizacao ja foi usada ou expirou', 'state'));
    if (e.erro) return fail(erroDe('autorizacao_negada', 'A autorizacao foi cancelada na Meta'));
    const plataforma = v.valor.plataforma as Plataforma;
    const profile = await this.d.repo.perfil();
    if (!profile) return fail(erroDe('sem_perfil', 'Subconta sem profile Zernio: comece a conexao de novo'));
    try {
      const contas = (await this.d.api.contas(profile)).filter((c) => c.plataforma === plataforma && c.profile_id === profile);
      if (!contas.length) return fail(erroDe('conta_nao_encontrada', 'A Zernio ainda nao mostra a conta conectada: tente Sincronizar em instantes'));
      const ids: string[] = [];
      for (const c of contas) {
        try {
          const s = await this.d.repo.salvarCanal({ canal: plataforma, conta_id: c.id, profile_id: profile, nome: c.nome, usuario: c.usuario });
          ids.push(s.id);
          await ctx.efeitos.auditar(s.novo ? 'canal.conectar' : 'canal.reconectar', TABELA, s.id, undefined, { canal: plataforma, conta_id: c.id });
          await ctx.efeitos.publicar('conector.conectado', { slug: plataforma, provedor: 'zernio', reconexao: !s.novo });
        } catch (x) {
          if (conflitoConta(x)) return fail(erroDe('conflito', 'Esta conta ja esta ligada a outra subconta', 'conta_id'));
          throw x;
        }
      }
      await reconciliarConectores(this.d.repo);
      await ctx.efeitos.auditar('zernio.webhook', 'integracoes_canais', null, undefined, { situacao: await garantirWebhook(this.d.api, this.d.webhook, (await this.d.repo.filtroWebhook()).accountIds) });
      await agendarImportacao(this.d.repo, ids, 0);
      return ok({ plataforma, canais: ids, retorno: v.valor.retorno ?? null });
    } catch (x) {
      return falhaProvedor(x);
    }
  }
}

/** Enfileira a importacao (polling) de cada canal e guarda o id do job: so o job mais novo reagenda. */
export async function agendarImportacao(repo: RepoZernio, canalIds: string[], atrasoSeg: number): Promise<void> {
  for (const id of canalIds) {
    const job = await repo.enfileirar(TIPO_JOB_IMPORTAR, { canal_id: id }, atrasoSeg);
    await repo.atualizarCanal(id, { job_sync_id: job });
  }
}

export class SincronizarCanaisZernio {
  constructor(private readonly d: DepsZernio) {}

  async execute(ctx: ContextoCaso): Promise<Result<{ canais: CanalDados[]; removidos: number }>> {
    const profile = await this.d.repo.perfil();
    if (!profile) {
      // Sem profile proprio: so canais ligados de conta existente; reimporta e confere o webhook.
      try {
        const ids = (await this.d.repo.canais()).filter((c) => c.estado === 'ativo').map((c) => c.id);
        const webhook = await garantirWebhook(this.d.api, this.d.webhook, (await this.d.repo.filtroWebhook()).accountIds);
        await agendarImportacao(this.d.repo, ids, 0);
        await ctx.efeitos.auditar('canais.sincronizar', TABELA, null, undefined, { contas: ids.length, removidos: 0, webhook });
        return ok({ canais: await this.d.repo.canais(), removidos: 0 });
      } catch (x) {
        return falhaProvedor(x);
      }
    }
    try {
      const remotas = (await this.d.api.contas(profile)).filter((c) => PLATAFORMAS.includes(c.plataforma as Plataforma) && c.profile_id === profile);
      const vivas = new Set(remotas.map((c) => c.id));
      const ids: string[] = [];
      for (const c of remotas) {
        try {
          ids.push((await this.d.repo.salvarCanal({ canal: c.plataforma as Plataforma, conta_id: c.id, profile_id: profile, nome: c.nome, usuario: c.usuario })).id);
        } catch (x) {
          if (!conflitoConta(x)) throw x;
        }
      }
      let removidos = 0;
      for (const c of await this.d.repo.canais()) {
        if (c.estado === 'ativo' && c.origem !== 'existente' && !vivas.has(c.conta_id)) {
          await this.d.repo.atualizarCanal(c.id, { estado: 'desconectado', ultimo_erro: 'Conta removida na Zernio' });
          await ctx.efeitos.publicar('conector.desconectado', { slug: c.canal, motivo: 'credencial_removida' });
          removidos++;
        }
      }
      await reconciliarConectores(this.d.repo);
      const webhook = await garantirWebhook(this.d.api, this.d.webhook, (await this.d.repo.filtroWebhook()).accountIds);
      await agendarImportacao(this.d.repo, ids, 0);
      await ctx.efeitos.auditar('canais.sincronizar', TABELA, null, undefined, { contas: ids.length, removidos, webhook });
      return ok({ canais: await this.d.repo.canais(), removidos });
    } catch (x) {
      return falhaProvedor(x);
    }
  }
}

export class DesconectarCanalZernio {
  constructor(private readonly d: DepsZernio) {}

  async execute(ctx: ContextoCaso, e: { id: string }): Promise<Result<void>> {
    const c = await this.d.repo.canal(e.id);
    if (!c) return fail(erroDe('nao_encontrado', 'Canal nao encontrado'));
    if (c.estado !== 'ativo') return fail(erroDe('transicao_invalida', 'Canal ja esta desconectado', 'estado', { permitidas: ['conectar'] }));
    // Conta que ja existia na Zernio (outro sistema da equipe usa): o ERP so se desliga dela, nunca a remove.
    if (c.origem !== 'existente') {
      try {
        await this.d.api.removerConta(c.conta_id);
      } catch (x) {
        if (!(x instanceof ErroProvedor && x.status === 404)) return falhaProvedor(x);
      }
    }
    await this.d.repo.atualizarCanal(c.id, { estado: 'desconectado', job_sync_id: null });
    await reconciliarConectores(this.d.repo);
    await ctx.efeitos.auditar('canal.desconectar', TABELA, c.id, { estado: 'ativo' }, { estado: 'desconectado' });
    await ctx.efeitos.publicar('conector.desconectado', { slug: c.canal, motivo: 'credencial_removida' });
    return ok(undefined);
  }
}

/**
 * Liga a esta subconta uma conta WhatsApp ou Instagram que JA existe na Zernio (so super admin da plataforma):
 * le a conta (GET), grava o canal com o profileId dela e origem 'existente', sem criar profile, sem mover nem
 * alterar a conta na Zernio. Importa o historico e garante o webhook proprio do ERP filtrado pela conta.
 */
export class VincularContaExistenteZernio {
  constructor(private readonly d: DepsZernio) {}

  async execute(ctx: ContextoCaso, e: { conta_id: string }): Promise<Result<{ canal_id: string; plataforma: Plataforma; novo: boolean }>> {
    try {
      const conta = (await this.d.api.contas(null)).find((c) => c.id === e.conta_id);
      if (!conta) return fail(erroDe('nao_encontrado', 'Conta nao encontrada na Zernio', 'conta_id'));
      if (!PLATAFORMAS.includes(conta.plataforma as Plataforma)) return fail(erroDe('plataforma_invalida', 'So contas de WhatsApp ou Instagram viram canal', 'conta_id'));
      const plataforma = conta.plataforma as Plataforma;
      let s: { id: string; novo: boolean };
      try {
        s = await this.d.repo.salvarCanal({ canal: plataforma, conta_id: conta.id, profile_id: conta.profile_id, nome: conta.nome, usuario: conta.usuario, origem: 'existente' });
      } catch (x) {
        if (conflitoConta(x)) return fail(erroDe('conflito', 'Esta conta ja esta ligada a outra subconta', 'conta_id'));
        throw x;
      }
      await ctx.efeitos.auditar(s.novo ? 'canal.vincular_existente' : 'canal.reconectar', TABELA, s.id, undefined, { canal: plataforma, conta_id: conta.id, profile_id: conta.profile_id });
      await ctx.efeitos.publicar('conector.conectado', { slug: plataforma, provedor: 'zernio', reconexao: !s.novo });
      await reconciliarConectores(this.d.repo);
      await ctx.efeitos.auditar('zernio.webhook', TABELA, null, undefined, { situacao: await garantirWebhook(this.d.api, this.d.webhook, (await this.d.repo.filtroWebhook()).accountIds) });
      await agendarImportacao(this.d.repo, [s.id], 0);
      return ok({ canal_id: s.id, plataforma, novo: s.novo });
    } catch (x) {
      return falhaProvedor(x);
    }
  }
}
