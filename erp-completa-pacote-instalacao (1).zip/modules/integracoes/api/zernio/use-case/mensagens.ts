/**
 * Mensagens pela Zernio: webhook ja assinado e resolvido para a subconta (AplicarWebhookZernio) e entrega do
 * envio pedido pelo Conversas (EntregarMensagemZernio, reacao a mensagem.envio_solicitado: texto, midia e
 * template). Tudo chega ao Conversas como evento recebido no envelope `erp.mensagens` (webhook.recebido.<canal>).
 * A importacao do historico mora em importacao.ts.
 */
import type { ContextoCaso } from '../../compartilhado/efeitos.ts';
import { ErroProvedor } from '../../compartilhado/http.ts';
import { erroDe, fail, ok, type Result } from '../../compartilhado/result.ts';
import { converter, envelopeStatus } from '../model/webhook.ts';
import type { ApiZernio, MidiaEnvio, Plataforma, RepoZernio } from '../model/portas.ts';
import { reconciliarConectores } from './conexao.ts';

export interface VinculoZernio { canal_id: string; canal: Plataforma; profile_id: string }

export class AplicarWebhookZernio {
  constructor(private readonly d: { repo: RepoZernio }) {}

  async execute(ctx: ContextoCaso, e: { vinculo: VinculoZernio; evento_id: string; profile_id: string | null; payload: unknown }): Promise<Result<{ situacao: 'entregue' | 'duplicado' | 'ignorado' | 'conta' | 'publicado' }>> {
    if (e.profile_id && e.profile_id !== e.vinculo.profile_id) return fail(erroDe('conta_de_outro_tenant', 'Conta e profile do evento nao batem com o vinculo', 'account'));
    const ev = converter(e.payload, e.vinculo.canal);
    if (ev.tipo === 'ignorar') return ok({ situacao: 'ignorado' });
    if (ev.tipo === 'evento_erp') {
      // Comentario do Instagram e status de template viram eventos do ERP (Automacoes reage), uma vez por evento.
      if (!(await this.d.repo.registrarRecebido(`zernio-${ev.evento}`, `zernio:${e.evento_id}`, e.payload))) return ok({ situacao: 'duplicado' });
      await ctx.efeitos.publicar(ev.evento, ev.dados);
      return ok({ situacao: 'publicado' });
    }
    if (ev.tipo === 'conta') {
      await this.d.repo.atualizarCanal(e.vinculo.canal_id, { estado: ev.conectada ? 'ativo' : 'desconectado', ultimo_erro: ev.conectada ? null : 'Conta desconectada na Zernio' });
      await reconciliarConectores(this.d.repo);
      if (!ev.conectada) await ctx.efeitos.publicar('conector.desconectado', { slug: e.vinculo.canal, motivo: 'credencial_removida' });
      await ctx.efeitos.auditar(ev.conectada ? 'canal.reconectar' : 'canal.desconectar', 'integracoes_canais', e.vinculo.canal_id, undefined, { origem: 'webhook' });
      return ok({ situacao: 'conta' });
    }
    if (ev.tipo === 'mensagem') {
      await this.d.repo.gravarConversa({ canal_id: e.vinculo.canal_id, canal: ev.canal, conversa_externa_id: ev.conversa_id, contato: ev.contato, nome: ev.nome, usuario: ev.usuario, foto: ev.foto });
      const novo = await this.d.repo.entregarAoConversas(ev.canal, `zernio:${e.evento_id}`, ev.envelope);
      return ok({ situacao: novo ? 'entregue' : 'duplicado' });
    }
    const novo = await this.d.repo.entregarAoConversas(ev.canal, `zernio:${e.evento_id}`, ev.envelope);
    return ok({ situacao: novo ? 'entregue' : 'duplicado' });
  }
}

export interface PedidoEnvio {
  mensagem_id: string;
  conversa_id: string;
  canal: string;
  para: string;
  tipo: string;
  corpo: string;
  template: { nome: string; idioma: string; parametros?: string[] } | null;
  /** Midia (CONTRATOS 7.1.3): anexo enviado pela tela (conversas_anexos) ou URL publica. */
  midia?: { tipo: MidiaEnvio['tipo']; url: string | null; nome: string | null; anexo_id: string | null } | null;
}

export class EntregarMensagemZernio {
  constructor(private readonly d: { repo: RepoZernio; api: ApiZernio }) {}

  async execute(ctx: ContextoCaso, e: PedidoEnvio): Promise<Result<{ situacao: 'enviada' | 'falhou' | 'ignorada' }>> {
    if (e.canal !== 'whatsapp' && e.canal !== 'instagram') return ok({ situacao: 'ignorada' });
    const canal = e.canal as Plataforma;
    const c = await this.d.repo.canalAtivo(canal);
    if (!c) return ok({ situacao: 'ignorada' });
    const contato = String(e.para ?? '').replace(/^\+/, '');
    const vinc = await this.d.repo.conversaPorContato(canal, contato);
    const falhar = async (msg: string) => {
      await this.d.repo.entregarAoConversas(canal, `zernio:envio:${e.mensagem_id}`, envelopeStatus({ id_externo: null, mensagem_id: e.mensagem_id, contato, status: 'failed', erro: msg }));
      await ctx.efeitos.auditar('mensagem.entregar_falhou', 'integracoes_canais', c.id, undefined, { mensagem_id: e.mensagem_id, motivo: msg });
      return ok({ situacao: 'falhou' as const });
    };
    try {
      let r: { message_id: string; conversa_id: string | null };
      if (e.template) {
        if (canal !== 'whatsapp') return falhar('Template e recurso do WhatsApp');
        r = await this.d.api.enviarTemplate(c.conta_id, vinc?.conversa_externa_id ?? null, contato, { nome: e.template.nome, idioma: e.template.idioma, parametros: e.template.parametros ?? [] });
      } else {
        // Fora da janela de 24 h o Conversas ja exige template; sem conversa aberta na Zernio texto livre nao sai.
        if (!vinc) return falhar(canal === 'whatsapp' ? 'Sem conversa aberta com o contato: envie um template aprovado' : 'O contato precisa escrever primeiro no Instagram');
        if (e.midia) {
          const m = e.midia;
          const arq = m.anexo_id ? await this.d.repo.anexo(m.anexo_id) : null;
          if (m.anexo_id && !arq) return falhar('Anexo nao encontrado');
          if (!arq && !m.url) return falhar('Midia sem arquivo nem URL');
          const legenda = e.tipo === 'midia' && e.corpo && !/^\[[^\]]+\]/.test(e.corpo) ? e.corpo : null;
          r = { ...(await this.d.api.enviarMidia(c.conta_id, vinc.conversa_externa_id, { tipo: m.tipo, url: m.url, nome: arq?.nome ?? m.nome, mime: arq?.mime ?? null, dados: arq?.dados ?? null }, legenda)), conversa_id: vinc.conversa_externa_id };
        } else {
          r = { ...(await this.d.api.enviarTexto(c.conta_id, vinc.conversa_externa_id, e.corpo)), conversa_id: vinc.conversa_externa_id };
        }
      }
      if (r.conversa_id && !vinc) await this.d.repo.gravarConversa({ canal_id: c.id, canal, conversa_externa_id: r.conversa_id, contato, nome: null });
      await this.d.repo.entregarAoConversas(canal, `zernio:envio:${e.mensagem_id}`, envelopeStatus({ id_externo: r.message_id, mensagem_id: e.mensagem_id, contato, status: 'sent' }));
      await ctx.efeitos.auditar('mensagem.entregar', 'integracoes_canais', c.id, undefined, { mensagem_id: e.mensagem_id, canal });
      return ok({ situacao: 'enviada' });
    } catch (x) {
      if (x instanceof ErroProvedor && (x.permanente || x.codigo === 'resultado_desconhecido')) return falhar(x.message);
      throw x;
    }
  }
}
