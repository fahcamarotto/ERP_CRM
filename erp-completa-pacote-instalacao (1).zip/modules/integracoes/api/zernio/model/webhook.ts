/**
 * Webhook da Zernio (funcoes puras): assinatura HMAC-SHA256 hex do corpo cru em X-Zernio-Signature e
 * conversao do evento para o envelope `erp.mensagens` que o Conversas le (CONTRATOS 7.1.3): mensagem com
 * direcao, midia (tipo e URL), perfil do contato (nome, @usuario, foto) e status de envio.
 */
import { createHmac, timingSafeEqual } from 'node:crypto';
import type { MensagemZernio, MidiaZernio, Plataforma } from './portas.ts';

type Obj = Record<string, unknown>;
const obj = (v: unknown): Obj => (v && typeof v === 'object' && !Array.isArray(v) ? (v as Obj) : {});
const txt = (v: unknown): string | null => (typeof v === 'string' && v.trim() ? v.trim() : typeof v === 'number' ? String(v) : null);
export const idDe = (v: unknown): string | null => {
  const o = obj(v);
  return txt(o._id) ?? txt(o.id) ?? txt(v);
};

export const EVENTOS_MENSAGEM = ['message.received', 'message.sent', 'message.delivered', 'message.read', 'message.failed'] as const;
export const EVENTOS_CONTA = ['account.connected', 'account.disconnected'] as const;
/** Eventos que viram eventos do ERP para o Automacoes (CONTRATOS 7.1.15). */
export const EVENTOS_AUTOMACAO = ['comment.received', 'whatsapp.template.status_updated'] as const;

export function assinaturaValida(cru: Buffer, assinatura: unknown, segredo: string): boolean {
  if (!segredo || typeof assinatura !== 'string') return false;
  const s = assinatura.trim().toLowerCase().replace(/^sha256=/, '');
  if (!/^[0-9a-f]{64}$/.test(s)) return false;
  const esperada = Buffer.from(createHmac('sha256', segredo).update(cru).digest('hex'), 'hex');
  return timingSafeEqual(esperada, Buffer.from(s, 'hex'));
}

export interface CabecalhoEvento { id: string; evento: string; conta_id: string; profile_id: string | null; plataforma: string | null }

/** Le so o necessario para achar a subconta dona (antes de qualquer outra coisa). */
export function cabecalho(payload: unknown): CabecalhoEvento | null {
  const p = obj(payload);
  const conta = obj(p.account);
  const id = txt(p.id);
  const evento = txt(p.event);
  const contaId = txt(conta.id) ?? txt(conta.accountId) ?? txt(conta._id);
  if (!id || !evento || !contaId) return null;
  return { id, evento, conta_id: contaId, profile_id: idDe(conta.profileId), plataforma: txt(conta.platform) ?? txt(obj(p.message).platform) };
}

const segundos = (v: unknown): string => {
  const t = txt(v);
  if (!t) return String(Math.floor(Date.now() / 1000));
  if (/^\d+(\.\d+)?$/.test(t)) { const n = Number(t); return String(Math.floor(n > 1e11 ? n / 1000 : n)); }
  const d = Date.parse(t);
  return String(Math.floor((Number.isNaN(d) ? Date.now() : d) / 1000));
};
const semMais = (v: string) => v.replace(/^\+/, '');

export type StatusProvedor = 'sent' | 'delivered' | 'read' | 'failed';

/** Item do envelope `erp.mensagens` (formato publicado em CONTRATOS 7.1.3). */
export type ItemErp =
  | {
      tipo: 'mensagem'; direcao: 'entrada' | 'saida'; id_externo: string; contato: string; nome: string | null;
      usuario: string | null; foto_url: string | null; texto: string; midia: MidiaZernio | null;
      status: StatusProvedor | null; ocorrida_em: string; historico: boolean;
    }
  | { tipo: 'status'; id_externo: string | null; mensagem_id: string | null; contato: string; status: StatusProvedor; erro: string | null; ocorrida_em: string };

export const envelopeErp = (itens: ItemErp[]) => ({ object: 'erp.mensagens', itens });

const iso = (v: unknown): string => new Date(Number(segundos(v)) * 1000).toISOString();

export function envelopeStatus(e: { id_externo: string | null; mensagem_id: string | null; contato: string; status: StatusProvedor; erro?: string | null; quando?: unknown }) {
  return envelopeErp([{ tipo: 'status', id_externo: e.id_externo, mensagem_id: e.mensagem_id, contato: semMais(e.contato), status: e.status, erro: e.erro ? e.erro.slice(0, 300) : null, ocorrida_em: iso(e.quando) }]);
}

const TIPOS_MIDIA: Record<string, string> = { image: 'imagem', video: 'video', audio: 'audio', file: 'documento', document: 'documento', sticker: 'figurinha' };

/** Primeiro anexo da mensagem (formato da Zernio: attachments[] com type e url). */
export function midiaDe(m: Obj): MidiaZernio | null {
  const a = obj(Array.isArray(m.attachments) ? m.attachments[0] : null);
  const tipo = txt(a.type) ?? txt(m.attachmentType);
  if (!tipo) return null;
  const url = txt(a.url) ?? txt(obj(a.payload).url) ?? txt(m.attachmentUrl);
  return { tipo: tipo === 'document' ? 'file' : tipo, url: url && /^https?:\/\//.test(url) ? url : null, nome: txt(a.name) ?? txt(a.filename) ?? txt(a.title) };
}

/** Texto legivel: o texto da mensagem ou, sem texto, o rotulo da midia. */
export function textoLegivel(texto: string | null, midia: MidiaZernio | null): string {
  if (texto) return texto;
  if (!midia) return '';
  return `[${TIPOS_MIDIA[midia.tipo] ?? midia.tipo}]${midia.nome ? ` ${midia.nome}` : ''}`;
}

export type EventoAplicavel =
  | { tipo: 'mensagem'; canal: Plataforma; conversa_id: string; contato: string; nome: string | null; usuario: string | null; foto: string | null; envelope: unknown }
  | { tipo: 'status'; canal: Plataforma; conversa_id: string | null; contato: string; envelope: unknown }
  | { tipo: 'conta'; conectada: boolean }
  | { tipo: 'evento_erp'; evento: 'comentario.recebido' | 'whatsapp_template.status_atualizado'; dados: Record<string, unknown> }
  | { tipo: 'ignorar'; motivo: string };

/**
 * Converte o evento ja assinado e ja resolvido para a subconta. `canal` e o do vinculo gravado; plataforma do
 * payload diferente dele e tratada como conta de outro vinculo. message.sent traz o conteudo: vira mensagem de
 * saida (enviada pelo celular ou por outro sistema aparece na conversa; a enviada pelo ERP so ganha o id).
 */
export function converter(payload: unknown, canal: Plataforma): EventoAplicavel {
  const p = obj(payload);
  const evento = txt(p.event) ?? '';
  if (evento === 'account.connected') return { tipo: 'conta', conectada: true };
  if (evento === 'account.disconnected') return { tipo: 'conta', conectada: false };
  if (evento === 'comment.received') {
    const cm = obj(p.comment);
    const autor = obj(cm.author);
    const post = obj(p.post);
    if (txt(cm.platform) && cm.platform !== canal) return { tipo: 'ignorar', motivo: 'plataforma_diferente_do_vinculo' };
    if (autor.isOwnAccount === true) return { tipo: 'ignorar', motivo: 'comentario_da_propria_conta' };
    const comentario = txt(cm.id);
    const postId = txt(cm.platformPostId) ?? txt(post.platformPostId) ?? txt(cm.postId) ?? txt(post.id);
    const autorId = txt(autor.id);
    if (!comentario || !postId || !autorId) return { tipo: 'ignorar', motivo: 'comentario_incompleto' };
    return { tipo: 'evento_erp', evento: 'comentario.recebido', dados: {
      comentario_id: comentario, post_id: postId, texto: txt(cm.text) ?? '', autor_id: autorId, autor_usuario: txt(autor.username), autor_nome: txt(autor.name),
      conta_usuario: txt(obj(p.account).username), ocorrido_em: iso(cm.createdAt ?? p.timestamp),
    } };
  }
  if (evento === 'whatsapp.template.status_updated') {
    const t = obj(p.template);
    const nome = txt(t.name);
    const status = txt(t.status);
    if (!nome || !status) return { tipo: 'ignorar', motivo: 'template_incompleto' };
    const motivo = txt(t.reason);
    return { tipo: 'evento_erp', evento: 'whatsapp_template.status_atualizado', dados: { template_id: txt(t.templateId), nome, idioma: txt(t.language) ?? 'pt_BR', status, motivo: motivo && motivo !== 'NONE' ? motivo : null } };
  }
  if (!(EVENTOS_MENSAGEM as readonly string[]).includes(evento)) return { tipo: 'ignorar', motivo: 'evento_nao_tratado' };
  const m = obj(p.message);
  const conv = obj(p.conversation);
  const plataforma = txt(m.platform) ?? txt(obj(p.account).platform);
  if (plataforma && plataforma !== canal) return { tipo: 'ignorar', motivo: 'plataforma_diferente_do_vinculo' };
  const conversaId = txt(conv.id) ?? txt(m.conversationId);
  const idMsg = txt(m.platformMessageId) ?? txt(m.id);
  if (!idMsg) return { tipo: 'ignorar', motivo: 'mensagem_sem_id' };
  const quando = m.sentAt ?? m.createdAt ?? p.timestamp;
  if (evento === 'message.received' || evento === 'message.sent') {
    const entrada = evento === 'message.received';
    if (entrada && txt(m.direction) && m.direction !== 'incoming') return { tipo: 'ignorar', motivo: 'direcao_invalida' };
    const remetente = obj(m.sender);
    const contato = (entrada ? txt(remetente.id) : null) ?? txt(conv.participantId) ?? txt(obj(m.recipient).id);
    if (!contato || !conversaId) return { tipo: 'ignorar', motivo: 'sem_contato' };
    const midia = midiaDe(m);
    const texto = textoLegivel(txt(m.text) ?? txt(m.message), midia);
    if (!texto) return { tipo: 'ignorar', motivo: 'mensagem_vazia' };
    const generico = (n: string | null) => (n && /^instagram user$/i.test(n) ? null : n);
    const nomeBruto = (entrada ? txt(remetente.name) : null) ?? txt(conv.participantName);
    const usuarioBruto = (entrada ? txt(remetente.username) : null) ?? txt(conv.participantUsername);
    const nome = usuarioBruto ? generico(nomeBruto) : nomeBruto;
    const usuario = (entrada ? txt(remetente.username) : null) ?? txt(conv.participantUsername);
    const foto = (entrada ? txt(remetente.picture) ?? txt(remetente.profilePicture) : null) ?? txt(conv.participantPicture) ?? txt(conv.participantProfilePicture);
    const item: ItemErp = {
      tipo: 'mensagem', direcao: entrada ? 'entrada' : 'saida', id_externo: idMsg, contato: semMais(contato), nome, usuario, foto_url: foto,
      texto, midia, status: entrada ? null : 'sent', ocorrida_em: iso(quando), historico: false,
    };
    return { tipo: 'mensagem', canal, conversa_id: conversaId, contato: semMais(contato), nome, usuario, foto, envelope: envelopeErp([item]) };
  }
  const contato = txt(conv.participantId) ?? txt(obj(m.recipient).id) ?? '';
  const status = evento.slice('message.'.length) as StatusProvedor;
  const erro = status === 'failed' ? (txt(obj(p.error).message) ?? txt(p.error) ?? 'falha no provedor') : null;
  return { tipo: 'status', canal, conversa_id: conversaId, contato, envelope: envelopeStatus({ id_externo: idMsg, mensagem_id: null, contato, status, erro, quando: p.statusAt ?? quando }) };
}

const STATUS_VALIDOS = ['sent', 'delivered', 'read', 'failed'];

/** Mensagem do historico (importacao): entrada e saida, com midia e status, marcada como historico. */
export function itemDoHistorico(contato: string, conv: { nome: string | null; usuario?: string | null; foto?: string | null }, m: MensagemZernio): ItemErp | null {
  const texto = textoLegivel(m.texto || null, m.midia);
  if (!texto) return null;
  const st = (m.status ?? '').toLowerCase();
  return {
    tipo: 'mensagem', direcao: m.direcao, id_externo: m.id, contato: semMais(contato), nome: conv.nome, usuario: conv.usuario ?? null, foto_url: conv.foto ?? null,
    texto, midia: m.midia, status: m.direcao === 'saida' ? ((STATUS_VALIDOS.includes(st) ? st : 'sent') as StatusProvedor) : null,
    ocorrida_em: iso(m.criada_em), historico: true,
  };
}
