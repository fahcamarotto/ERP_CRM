/** Portas do fluxo Zernio (WhatsApp e Instagram): API do provedor e repositorio da subconta. */
export type Plataforma = 'whatsapp' | 'instagram';
export const PLATAFORMAS: readonly Plataforma[] = ['whatsapp', 'instagram'];

export interface ContaZernio { id: string; plataforma: string; profile_id: string; nome: string; usuario: string }
export interface ConversaZernio {
  id: string; conta_id: string; plataforma: string; participante: string; nome: string | null;
  usuario?: string | null; foto?: string | null;
  /** Marca de atualizacao da conversa na Zernio (updatedTime): igual a gravada = nada novo. */
  atualizada?: string | null;
}
export type TipoMidia = 'image' | 'video' | 'audio' | 'file' | 'sticker' | string;
export interface MidiaZernio { tipo: TipoMidia; url: string | null; nome: string | null }
export interface MensagemZernio {
  id: string; direcao: 'entrada' | 'saida'; texto: string; criada_em: string | null; midia: MidiaZernio | null;
  /** Status da mensagem enviada (sent, delivered, read, failed) quando a Zernio informa. */
  status?: string | null;
  remetente?: { id: string | null; nome: string | null; usuario: string | null; foto: string | null } | null;
}
export interface MidiaEnvio { tipo: 'image' | 'video' | 'audio' | 'file'; url?: string | null; nome?: string | null; mime?: string | null; dados?: Buffer | null }
export interface TemplateEnvio { nome: string; idioma: string; parametros: string[] }

export interface ApiZernio {
  criarPerfil(nome: string, idempotencia: string): Promise<{ profile_id: string }>;
  urlConexao(plataforma: Plataforma, profileId: string, redirect: string): Promise<string>;
  /** Contas do profile; `null` lista as da equipe inteira (so leitura, vinculo de conta existente). */
  contas(profileId: string | null): Promise<ContaZernio[]>;
  removerConta(contaId: string): Promise<void>;
  conversas(contaId: string, plataforma: Plataforma, cursor: string | null): Promise<{ itens: ConversaZernio[]; proximo: string | null }>;
  /** Pagina de mensagens da mais nova para a mais antiga; `proximo` null = fim do historico. */
  mensagens(contaId: string, conversaId: string, cursor: string | null): Promise<{ itens: MensagemZernio[]; proximo: string | null }>;
  enviarTexto(contaId: string, conversaId: string, texto: string): Promise<{ message_id: string }>;
  enviarMidia(contaId: string, conversaId: string, m: MidiaEnvio, legenda: string | null): Promise<{ message_id: string }>;
  enviarTemplate(contaId: string, conversaId: string | null, participante: string, t: TemplateEnvio): Promise<{ message_id: string; conversa_id: string | null }>;
  webhooks(): Promise<WebhookZernio[]>;
  criarWebhook(w: ConfWebhook): Promise<void>;
  atualizarWebhook(id: string, w: ConfWebhook & { isActive: boolean }): Promise<void>;
}

/** Webhook proprio do ERP: sempre filtrado pelas contas dos canais do ERP (nunca recebe conta alheia). */
export interface ConfWebhook { name: string; url: string; events: string[]; secret: string; accountIds: string[] }
export interface WebhookZernio { id: string; name: string; url: string; events: string[]; ativo: boolean; profileIds: string[]; accountIds: string[] }

export interface CanalDados {
  id: string;
  canal: Plataforma;
  conta_id: string;
  profile_id: string;
  nome: string;
  usuario: string;
  estado: 'ativo' | 'desconectado';
  conectado_em: string;
  sincronizado_em: string | null;
  importadas: number;
  ultimo_erro: string | null;
  job_sync_id: string | null;
  /** 'existente': conta que ja estava na Zernio; o ERP nunca a remove la. */
  origem?: 'erp' | 'existente';
  import_cursor?: string | null;
  historico_completo?: boolean;
}

export interface ConversaVinculada {
  canal_id: string; conta_id: string; conversa_externa_id: string; ultima_mensagem_id: string | null;
  historico_cursor?: string | null; historico_completo?: boolean; atualizada_externa?: string | null;
}
export type PatchConversa = Partial<Pick<ConversaVinculada, 'ultima_mensagem_id' | 'historico_cursor' | 'historico_completo' | 'atualizada_externa'>>;

export interface RepoZernio {
  perfil(): Promise<string | null>;
  gravarPerfil(profileId: string, nome: string): Promise<void>;
  gravarState(hash: string, provedor: 'zernio' | 'maton', plataforma: string, expira: Date): Promise<void>;
  /** Marca o state como usado se existir, nao usado e nao expirado nesta subconta. */
  consumirState(hash: string): Promise<boolean>;
  canais(): Promise<CanalDados[]>;
  canal(id: string): Promise<CanalDados | null>;
  canalAtivo(canal: Plataforma): Promise<CanalDados | null>;
  /** Insere ou reativa. Conta ligada a outra subconta lanca erro 23505 (indice unico global). */
  salvarCanal(c: { canal: Plataforma; conta_id: string; profile_id: string; nome: string; usuario: string; origem?: 'erp' | 'existente' }): Promise<{ id: string; novo: boolean }>;
  atualizarCanal(id: string, p: Partial<Pick<CanalDados, 'estado' | 'sincronizado_em' | 'importadas' | 'ultimo_erro' | 'job_sync_id' | 'import_cursor' | 'historico_completo'>>): Promise<void>;
  /** Conversa da Zernio ja vista neste canal (estado da importacao). */
  conversaExterna(canalId: string, conversaExternaId: string): Promise<ConversaVinculada | null>;
  atualizarConversa(canalId: string, conversaExternaId: string, p: PatchConversa): Promise<void>;
  conversaPorContato(canal: Plataforma, contato: string): Promise<ConversaVinculada | null>;
  gravarConversa(c: { canal_id: string; canal: Plataforma; conversa_externa_id: string; contato: string; nome: string | null; usuario?: string | null; foto?: string | null }): Promise<void>;
  /** Estado do conector (tabela conectores do nucleo). */
  mudarConector(slug: Plataforma, estado: 'ativo' | 'aguardando_credencial'): Promise<void>;
  /** Contas dos canais ativos do ERP nesta subconta (filtro do webhook proprio). */
  filtroWebhook(): Promise<{ accountIds: string[] }>;
  /** Anexo enviado pela tela (tabela publicada conversas_anexos). */
  anexo(id: string): Promise<{ mime: string; nome: string; dados: Buffer } | null>;
  /** Registra o evento recebido sem job (o modulo publica um evento do ERP); false = ja recebido antes. */
  registrarRecebido(conector: string, idExterno: string, payload: unknown): Promise<boolean>;
  /** Grava em integracoes_eventos_recebidos e enfileira webhook.recebido (Conversas trata). false = duplicado. */
  entregarAoConversas(conector: Plataforma, idExterno: string, payload: unknown): Promise<boolean>;
  enfileirar(tipo: string, payload: Record<string, unknown>, atrasoSeg?: number): Promise<string>;
}
