/**
 * Rotas do fluxo Zernio: Criar canal (connect -> authUrl da Meta), callback com state assinado de uso unico,
 * lista, sincronizar e desconectar canais (so pessoa com sessao) e o webhook publico assinado da Zernio.
 */
import { comEscopo, esquemaErro, exigirUsuario, requer, sessaoDe, type FastifyInstance, type FastifyReply, type FastifyRequest } from '@erp/api/sdk';
import { ambiente, baseCallback, urlPublica, webhookZernio } from '../ambiente.ts';
import { ClienteZernio } from './adapter/cliente-zernio.ts';
import { garantirWebhook } from './use-case/conexao.ts';
import { naTransacao } from '../borda.ts';
import { contextoPg } from '../compartilhado/efeitos-pg.ts';
import { exigirOk } from '../compartilhado/result.ts';
import { casosDeUso } from '../fabrica.ts';
import { uuid } from '../esquemas.ts';
import { assinaturaValida, cabecalho } from './model/webhook.ts';
import { PLATAFORMAS, type Plataforma } from './model/portas.ts';
import { ZernioRepoPg } from './adapter/zernio-repo-pg.ts';

const tags = ['integracoes'];
const erros = { 400: esquemaErro, 403: esquemaErro, 404: esquemaErro, 409: esquemaErro };
const TELA = '/integracoes/integracoes/conectores';
/** Telas para onde o callback volta: Integracoes > Conectores (padrao) ou o menu Conversas do canal. */
const RETORNOS = ['conectores', 'conversas'] as const;
const telaDe = (retorno: string | null | undefined, plataforma: string | null | undefined) =>
  retorno === 'conversas' ? `/comercial/conversas/${plataforma === 'instagram' ? 'instagram' : 'whatsapp'}` : TELA;
const NULO = '00000000-0000-0000-0000-000000000000';
const SISTEMA = { tipo: 'sistema' as const, id: null };
export const MAX_WEBHOOK = 2 * 1024 * 1024;

const escopoDe = (req: FastifyRequest) => {
  const s = sessaoDe(req);
  return { tenant: s.tenantId, workspace: s.workspaceId, usuario: s.usuarioId };
};

export async function situacaoCanais(req: FastifyRequest) {
  const canais = await naTransacao(req, (_casos, _ctx, c) => new ZernioRepoPg(c).canais());
  return { configurado: ambiente.zernio(), tempo_real: !!webhookZernio(), url_publica: urlPublica(), canais };
}

/** Partida da API: com webhook (tunel ou URL publica) corrige a URL do webhook proprio ja registrado. */
export async function corrigirWebhookNaPartida(log: (m: string) => void): Promise<void> {
  const w = webhookZernio();
  if (!w || !ambiente.zernio()) return;
  try { log(`zernio webhook na partida: ${await garantirWebhook(new ClienteZernio(), w, null)}`); } catch (e) { log(`zernio webhook na partida falhou: ${e instanceof Error ? e.message : String(e)}`); }
}

export function rotasZernio(app: FastifyInstance): void {
  app.post<{ Body: { plataforma: Plataforma; retorno?: string } }>('/zernio/connect', {
    preHandler: [exigirUsuario, requer('integracoes.editar')],
    schema: {
      tags, summary: 'Criar canal: garante o profile Zernio da subconta e devolve o authUrl da Meta (IniciarConexaoZernio)',
      body: { type: 'object', additionalProperties: false, required: ['plataforma'], properties: { plataforma: { type: 'string', enum: [...PLATAFORMAS] }, retorno: { type: 'string', enum: [...RETORNOS] } } }, response: erros,
    },
  }, (req) => naTransacao(req, async (casos, ctx) => exigirOk(await casos.iniciarZernio.execute(ctx, { plataforma: req.body.plataforma, escopo: escopoDe(req), base: baseCallback(), retorno: req.body.retorno }))));

  app.get<{ Querystring: { crm_state?: string; error?: string } }>('/zernio/callback', {
    preHandler: [exigirUsuario, requer('integracoes.editar')],
    schema: { tags, summary: 'Retorno da Meta via Zernio: consome o state, confirma a conta e grava o canal (303 para a tela de canais)', querystring: { type: 'object', properties: { crm_state: { type: 'string', maxLength: 2048 }, error: { type: 'string', maxLength: 200 } } } },
  }, async (req, reply) => {
    const r = await naTransacao(req, (casos, ctx) => casos.concluirZernio.execute(ctx, { state: req.query.crm_state, escopo: escopoDe(req), erro: req.query.error ?? null }));
    const motivo = r.ok ? '' : `&motivo=${encodeURIComponent(r.erros[0]?.codigo ?? 'erro')}`;
    const tela = r.ok ? telaDe(r.valor.retorno, r.valor.plataforma) : TELA;
    return reply.code(303).header('location', `${tela}?zernio=${r.ok ? 'connected' : 'error'}${motivo}`).send();
  });

  app.post('/zernio/sincronizar', {
    preHandler: [exigirUsuario, requer('integracoes.editar')],
    schema: { tags, summary: 'Sincroniza as contas do profile Zernio e enfileira a importacao das conversas', response: erros },
  }, async (req) => {
    await naTransacao(req, async (casos, ctx) => exigirOk(await casos.sincronizarZernio.execute(ctx)));
    return situacaoCanais(req);
  });

  // Super admin da plataforma liga a uma subconta uma conta que ja existe na Zernio (sem criar nem mexer nela).
  app.post<{ Body: { conta_id: string } }>('/zernio/vincular-existente', {
    preHandler: [exigirUsuario, requer('integracoes.editar')],
    schema: {
      tags, summary: 'Liga a esta subconta uma conta WhatsApp ou Instagram que ja existe na Zernio (so super admin; GET na Zernio, nada e alterado la)',
      body: { type: 'object', additionalProperties: false, required: ['conta_id'], properties: { conta_id: { type: 'string', pattern: '^[A-Za-z0-9_-]{4,128}$' } } }, response: erros,
    },
  }, async (req, reply) => {
    if (!sessaoDe(req).superAdmin) return reply.code(403).send({ erro: { codigo: 'sem_permissao', mensagem: 'Restrito ao super admin da plataforma' } });
    const r = await naTransacao(req, async (casos, ctx) => exigirOk(await casos.vincularExistenteZernio.execute(ctx, { conta_id: req.body.conta_id })));
    return reply.code(r.novo ? 201 : 200).send(r);
  });

  app.delete<{ Params: { id: string } }>('/zernio/canais/:id', {
    preHandler: [exigirUsuario, requer('integracoes.excluir')],
    schema: { tags, summary: 'Desconecta o canal (remove a conta na Zernio)', params: { type: 'object', required: ['id'], properties: { id: uuid } }, response: erros },
  }, async (req, reply) => {
    await naTransacao(req, async (casos, ctx) => exigirOk(await casos.desconectarZernio.execute(ctx, { id: req.params.id })));
    return reply.code(204).send();
  });

  // Webhook publico: corpo cru, HMAC hex em X-Zernio-Signature, vinculo resolvido por funcao SECURITY DEFINER.
  void app.register(async (pub) => {
    pub.addContentTypeParser('application/json', { parseAs: 'buffer', bodyLimit: MAX_WEBHOOK }, (_req, corpo, feito) => feito(null, corpo));
    pub.post('/zernio/webhook', {
      bodyLimit: MAX_WEBHOOK,
      config: { rateLimit: { max: 600, timeWindow: '1 minute' } },
      schema: { tags, summary: 'Webhook da Zernio (assinatura X-Zernio-Signature obrigatoria)' },
    }, (req, reply) => receberWebhook(req, reply));
  });
}

async function receberWebhook(req: FastifyRequest, reply: FastifyReply) {
  const cru = Buffer.isBuffer(req.body) ? req.body : Buffer.from('');
  const segredo = process.env.ZERNIO_WEBHOOK_SECRET ?? '';
  const sig = req.headers['x-zernio-signature'] ?? req.headers['x-late-signature'];
  if (!segredo || !assinaturaValida(cru, Array.isArray(sig) ? sig[0] : sig, segredo)) {
    return reply.code(401).send({ erro: { codigo: 'assinatura_invalida', mensagem: 'Assinatura invalida' } });
  }
  let payload: unknown;
  try { payload = JSON.parse(cru.toString('utf8')); } catch { return reply.code(400).send({ erro: { codigo: 'entrada_invalida', mensagem: 'Corpo nao e JSON' } }); }
  if ((payload as { event?: string })?.event === 'webhook.test') return { recebido: true, teste: true };
  const cab = cabecalho(payload);
  if (!cab) return reply.code(400).send({ erro: { codigo: 'entrada_invalida', mensagem: 'Evento sem id, tipo ou conta' } });
  const vinculo = (await comEscopo({ tenantId: NULO, workspaceId: NULO, usuarioId: '' }, (c) => c.query('SELECT * FROM integracoes_zernio_resolver($1)', [cab.conta_id]))).rows[0] as
    { tenant_id: string; workspace_id: string; canal_id: string; canal: Plataforma; profile_id: string } | undefined;
  if (!vinculo) return { recebido: true, ignorado: 'conta_sem_vinculo' };
  const r = await comEscopo({ tenantId: vinculo.tenant_id, workspaceId: vinculo.workspace_id, usuarioId: '' }, (c) =>
    casosDeUso(c).aplicarWebhookZernio.execute(contextoPg(c, SISTEMA, req.ip ?? null), {
      vinculo: { canal_id: vinculo.canal_id, canal: vinculo.canal, profile_id: vinculo.profile_id }, evento_id: cab.id, profile_id: cab.profile_id, payload,
    }));
  if (!r.ok) return reply.code(403).send({ erro: { codigo: r.erros[0]!.codigo, mensagem: r.erros[0]!.mensagem } });
  return { recebido: true, situacao: r.valor.situacao };
}

