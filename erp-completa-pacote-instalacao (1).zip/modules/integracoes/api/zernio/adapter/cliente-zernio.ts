/**
 * Cliente da API Zernio (fetch proprio, sem SDK @zernio/node). Base https://zernio.com/api/v1; ZERNIO_API_BASE
 * troca a origem (mock local nos testes). A chave vem de ZERNIO_API_KEY, injetada do cofre por op run.
 */
import { ClienteHttp, ErroProvedor, type OpcoesHttp } from '../../compartilhado/http.ts';
import { idDe, midiaDe } from '../model/webhook.ts';
import type { ApiZernio, ConfWebhook, ContaZernio, ConversaZernio, MensagemZernio, MidiaEnvio, Plataforma, TemplateEnvio } from '../model/portas.ts';

type Obj = Record<string, unknown>;
const s = (v: unknown) => (typeof v === 'string' ? v : typeof v === 'number' ? String(v) : '');
const lista = (v: unknown): Obj[] => (Array.isArray(v) ? (v.filter((x) => x && typeof x === 'object') as Obj[]) : []);

export const BASE_ZERNIO = 'https://zernio.com/api/v1';
/** A Meta devolve "Instagram User" quando nao libera o nome: com @usuario disponivel, ele vira o nome. */
const nomeReal = (n: string): string | null => (n && !/^instagram user$/i.test(n.trim()) ? n : null);

export function opcoesZernio(extra: Partial<OpcoesHttp> = {}): OpcoesHttp {
  return { base: process.env.ZERNIO_API_BASE || BASE_ZERNIO, token: process.env.ZERNIO_API_KEY ?? '', provedor: 'zernio', timeoutMs: 20_000, ...extra };
}

export class ClienteZernio implements ApiZernio {
  private readonly http: ClienteHttp;
  constructor(o: OpcoesHttp = opcoesZernio()) { this.http = new ClienteHttp(o); }

  async perfis(): Promise<{ id: string; nome: string }[]> {
    const r = await this.http.pedir<Obj>({ metodo: 'GET', caminho: 'profiles' });
    return lista(r.profiles).map((p) => ({ id: idDe(p) ?? '', nome: s(p.name) }));
  }

  async criarPerfil(nome: string, idempotencia: string) {
    const r = await this.http.pedir<Obj>({ metodo: 'POST', caminho: 'profiles', corpo: { name: nome, description: 'Canais do ERP' }, idempotencia });
    const id = idDe(r.profile) ?? idDe(r);
    if (!id) throw new ErroProvedor('zernio: profile criado sem id', 502, 'resposta_invalida');
    return { profile_id: id };
  }

  async urlConexao(plataforma: Plataforma, profileId: string, redirect: string) {
    const r = await this.http.pedir<Obj>({ metodo: 'GET', caminho: `connect/${plataforma}`, query: { profileId, redirect_url: redirect } });
    return s(r.authUrl ?? r.auth_url);
  }

  /** Contas do profile (ou de toda a equipe com `null`, so leitura). */
  async contas(profileId: string | null): Promise<ContaZernio[]> {
    const r = await this.http.pedir<Obj>({ metodo: 'GET', caminho: 'accounts', query: { profileId } });
    return lista(r.accounts).map((a) => {
      const meta = (a.metadata && typeof a.metadata === 'object' ? a.metadata : {}) as Obj;
      return {
        id: idDe(a) ?? s(a.accountId), plataforma: s(a.platform), profile_id: idDe(a.profileId) ?? '',
        nome: s(a.displayName || a.username || meta.displayPhoneNumber).slice(0, 200),
        usuario: s(meta.displayPhoneNumber || a.username).slice(0, 200),
      };
    }).filter((a) => a.id);
  }

  async removerConta(contaId: string) {
    await this.http.pedir({ metodo: 'DELETE', caminho: `accounts/${encodeURIComponent(contaId)}` });
  }

  async conversas(contaId: string, plataforma: Plataforma, cursor: string | null) {
    const r = await this.http.pedir<Obj>({ metodo: 'GET', caminho: 'inbox/conversations', query: { accountId: contaId, platform: plataforma, limit: 50, sortOrder: 'desc', cursor } });
    const pag = (r.pagination && typeof r.pagination === 'object' ? r.pagination : {}) as Obj;
    const itens: ConversaZernio[] = lista(r.data).map((c) => ({
      id: s(c.id), conta_id: s(c.accountId), plataforma: s(c.platform), participante: s(c.participantId), nome: nomeReal(s(c.participantName)) ?? (s(c.participantUsername) ? null : s(c.participantName) || null),
      usuario: s(c.participantUsername || c.whatsappUsername || (c.instagramProfile && typeof c.instagramProfile === 'object' ? (c.instagramProfile as Obj).username : '')) || null, foto: s(c.participantPicture || c.participantProfilePicture || c.participantAvatar) || null,
      atualizada: s(c.updatedTime || c.updatedAt || c.lastMessageAt) || null,
    })).filter((c) => c.id && c.participante);
    return { itens, proximo: pag.hasMore ? s(pag.nextCursor) || null : null };
  }

  async mensagens(contaId: string, conversaId: string, cursor: string | null) {
    const r = await this.http.pedir<Obj>({ metodo: 'GET', caminho: `inbox/conversations/${encodeURIComponent(conversaId)}/messages`, query: { accountId: contaId, limit: 100, sortOrder: 'desc', cursor } });
    const pag = (r.pagination && typeof r.pagination === 'object' ? r.pagination : {}) as Obj;
    const itens: MensagemZernio[] = lista(r.messages ?? r.data).map((m) => {
      const rem = (m.sender && typeof m.sender === 'object' ? m.sender : {}) as Obj;
      return {
        id: s(m.platformMessageId || m.id), direcao: m.direction === 'incoming' ? 'entrada' as const : 'saida' as const,
        texto: s(m.message ?? m.text), criada_em: s(m.createdAt || m.sentAt) || null, midia: midiaDe(m), status: s(m.deliveryStatus || m.status) || null,
        remetente: { id: s(rem.id || m.senderId) || null, nome: s(rem.name || m.senderName) || null, usuario: s(rem.username) || null, foto: s(rem.picture || rem.profilePicture) || null },
      };
    }).filter((m) => m.id);
    // A Zernio pode aplicar outra ordem por plataforma: garante a mais nova primeiro.
    if (r.sortOrderApplied === 'asc') itens.reverse();
    return { itens, proximo: pag.hasMore === false ? null : s(pag.nextCursor) || null };
  }

  async enviarMidia(contaId: string, conversaId: string, m: MidiaEnvio, legenda: string | null) {
    const caminho = `inbox/conversations/${encodeURIComponent(conversaId)}/messages`;
    if (m.dados) {
      const f = new FormData();
      f.set('accountId', contaId);
      if (legenda) f.set('message', legenda);
      f.set('attachmentType', m.tipo);
      if (m.nome) f.set('attachmentName', m.nome);
      f.set('attachment', new Blob([new Uint8Array(m.dados)], { type: m.mime || 'application/octet-stream' }), m.nome || 'arquivo');
      return { message_id: recibo(await this.http.pedir<Obj>({ metodo: 'POST', caminho, formulario: f })).message_id };
    }
    const corpo = { accountId: contaId, attachmentUrl: m.url, attachmentType: m.tipo, ...(m.nome && m.tipo === 'file' ? { attachmentName: m.nome } : {}), ...(legenda ? { message: legenda } : {}) };
    return { message_id: recibo(await this.http.pedir<Obj>({ metodo: 'POST', caminho, corpo })).message_id };
  }

  async enviarTexto(contaId: string, conversaId: string, texto: string) {
    const r = await this.http.pedir<Obj>({ metodo: 'POST', caminho: `inbox/conversations/${encodeURIComponent(conversaId)}/messages`, corpo: { accountId: contaId, message: texto } });
    return { message_id: recibo(r).message_id };
  }

  async webhooks() {
    const r = await this.http.pedir<Obj>({ metodo: 'GET', caminho: 'webhooks/settings' });
    return lista(r.webhooks ?? r.data).map((w) => ({
      id: idDe(w) ?? s(w.webhookId), name: s(w.name), url: s(w.url),
      events: Array.isArray(w.events) ? w.events.map(String) : [], ativo: w.isActive !== false,
      profileIds: Array.isArray(w.profileIds) ? w.profileIds.map((x) => idDe(x) ?? '').filter(Boolean) : [],
      accountIds: Array.isArray(w.accountIds) ? w.accountIds.map((x) => idDe(x) ?? '').filter(Boolean) : [],
    }));
  }

  async criarWebhook(w: ConfWebhook) {
    await this.http.pedir({ metodo: 'POST', caminho: 'webhooks/settings', corpo: w, idempotencia: `erp-webhook-${w.url}`.slice(0, 200) });
  }

  async atualizarWebhook(id: string, w: ConfWebhook & { isActive: boolean }) {
    await this.http.pedir({ metodo: 'PUT', caminho: 'webhooks/settings', corpo: { webhookId: id, ...w } });
  }

  async enviarTemplate(contaId: string, conversaId: string | null, participante: string, t: TemplateEnvio) {
    const componentes = t.parametros.length ? [{ type: 'body', parameters: t.parametros.map((x) => ({ type: 'text', text: x })) }] : [];
    const r = conversaId
      ? await this.http.pedir<Obj>({ metodo: 'POST', caminho: `inbox/conversations/${encodeURIComponent(conversaId)}/messages`, corpo: { accountId: contaId, template: { elements: [{ name: t.nome, language: t.idioma, components: componentes }] } } })
      : await this.http.pedir<Obj>({ metodo: 'POST', caminho: 'inbox/conversations', corpo: { accountId: contaId, participantId: participante, templateName: t.nome, templateLanguage: t.idioma, templateParams: t.parametros } });
    const rec = recibo(r);
    return { message_id: rec.message_id, conversa_id: rec.conversa_id ?? conversaId };
  }
}

function recibo(r: Obj): { message_id: string; conversa_id: string | null } {
  const d = (r.data && typeof r.data === 'object' ? r.data : r) as Obj;
  const id = s(d.messageId || d.platformMessageId || d.id);
  if (!id) throw new ErroProvedor('zernio: envio aceito sem id da mensagem', 502, 'resultado_desconhecido');
  return { message_id: id, conversa_id: s(d.conversationId) || null };
}
