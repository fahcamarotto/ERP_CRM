/** Adaptador Postgres do fluxo Zernio. Roda no cliente da transacao (RLS da subconta da sessao ou do job). */
import type pg from 'pg';
import type { CanalDados, ConversaVinculada, PatchConversa, Plataforma, RepoZernio } from '../model/portas.ts';

const COLUNAS = `id, canal, conta_id, profile_id, nome, usuario, estado, conectado_em, sincronizado_em, importadas, ultimo_erro, job_sync_id, origem, import_cursor, historico_completo`;
const COLUNAS_CONV = `z.canal_id, c.conta_id, z.conversa_externa_id, z.ultima_mensagem_id, z.historico_cursor, z.historico_completo, z.atualizada_externa`;
const iso = (d: unknown) => (d instanceof Date ? d.toISOString() : d ? String(d) : null);
const linha = (l: Record<string, unknown>): CanalDados => ({ ...(l as unknown as CanalDados), conectado_em: iso(l.conectado_em)!, sincronizado_em: iso(l.sincronizado_em) });

export class FilaOutbox {
  constructor(protected readonly c: pg.PoolClient) {}
  async enfileirar(tipo: string, payload: Record<string, unknown>, atrasoSeg = 0): Promise<string> {
    const r = await this.c.query(
      `INSERT INTO outbox (tipo, payload, disponivel_em) VALUES ($1, $2, now() + make_interval(secs => $3::int)) RETURNING id`,
      [tipo, JSON.stringify(payload), Math.max(0, Math.floor(atrasoSeg))],
    );
    return r.rows[0].id as string;
  }
  async gravarState(hash: string, provedor: 'zernio' | 'maton', plataforma: string, expira: Date): Promise<void> {
    await this.c.query(
      `INSERT INTO integracoes_oauth_estados (hash, provedor, plataforma, usuario_id, expira_em, creator_id)
       VALUES ($1, $2, $3, nucleo_usuario_atual(), $4, nucleo_usuario_atual())`,
      [hash, provedor, plataforma, expira],
    );
  }
  async consumirState(hash: string): Promise<boolean> {
    const r = await this.c.query(
      `UPDATE integracoes_oauth_estados SET usado_em = now() WHERE hash = $1 AND usado_em IS NULL AND expira_em > now() AND deleted_at IS NULL RETURNING id`,
      [hash],
    );
    return !!r.rowCount;
  }
  async registrarRecebido(conector: string, idExterno: string, payload: unknown): Promise<boolean> {
    const ins = await this.c.query(
      `INSERT INTO integracoes_eventos_recebidos (conector, id_externo, payload, estado, processado_em) VALUES ($1, $2, $3, 'processado', now())
       ON CONFLICT (tenant_id, workspace_id, conector, id_externo) DO NOTHING RETURNING id`,
      [conector, idExterno.slice(0, 200), JSON.stringify(payload)],
    );
    return !!ins.rowCount;
  }
  /** Evento para o modulo dono do canal (Conversas, Agenda): mesmo caminho do webhook de entrada do nucleo. */
  async entregarAoConversas(conector: string, idExterno: string, payload: unknown): Promise<boolean> {
    const ins = await this.c.query(
      `INSERT INTO integracoes_eventos_recebidos (conector, id_externo, payload) VALUES ($1, $2, $3)
       ON CONFLICT (tenant_id, workspace_id, conector, id_externo) DO NOTHING RETURNING id`,
      [conector, idExterno.slice(0, 200), JSON.stringify(payload)],
    );
    if (!ins.rowCount) return false;
    await this.c.query(`INSERT INTO outbox (tipo, payload) VALUES ('webhook.recebido', $1)`, [JSON.stringify({ recebido_id: ins.rows[0].id, conector })]);
    return true;
  }
  async mudarConectorSlug(slug: string, estado: string): Promise<void> {
    await this.c.query(`UPDATE conectores SET estado = $2 WHERE slug = $1 AND deleted_at IS NULL AND estado <> 'desligado' AND estado <> $2`, [slug, estado]);
  }
}

export class ZernioRepoPg extends FilaOutbox implements RepoZernio {
  async perfil(): Promise<string | null> {
    const r = await this.c.query(`SELECT profile_id FROM integracoes_zernio_perfis WHERE deleted_at IS NULL LIMIT 1`);
    return (r.rows[0]?.profile_id as string | undefined) ?? null;
  }
  async gravarPerfil(profileId: string, nome: string): Promise<void> {
    await this.c.query(
      `INSERT INTO integracoes_zernio_perfis (profile_id, nome, creator_id) VALUES ($1, $2, nucleo_usuario_atual())
       ON CONFLICT (tenant_id, workspace_id) WHERE deleted_at IS NULL DO NOTHING`,
      [profileId, nome],
    );
  }
  async canais(): Promise<CanalDados[]> {
    return (await this.c.query(`SELECT ${COLUNAS} FROM integracoes_canais WHERE deleted_at IS NULL ORDER BY conectado_em`)).rows.map(linha);
  }
  async canal(id: string): Promise<CanalDados | null> {
    const r = await this.c.query(`SELECT ${COLUNAS} FROM integracoes_canais WHERE id = $1 AND deleted_at IS NULL`, [id]);
    return r.rows[0] ? linha(r.rows[0]) : null;
  }
  async canalAtivo(canal: Plataforma): Promise<CanalDados | null> {
    const r = await this.c.query(`SELECT ${COLUNAS} FROM integracoes_canais WHERE canal = $1 AND estado = 'ativo' AND deleted_at IS NULL ORDER BY conectado_em LIMIT 1`, [canal]);
    return r.rows[0] ? linha(r.rows[0]) : null;
  }
  async salvarCanal(c: { canal: Plataforma; conta_id: string; profile_id: string; nome: string; usuario: string; origem?: 'erp' | 'existente' }): Promise<{ id: string; novo: boolean }> {
    const atual = await this.c.query(`SELECT id FROM integracoes_canais WHERE conta_id = $1 AND deleted_at IS NULL`, [c.conta_id]);
    if (atual.rows[0]) {
      await this.c.query(
        `UPDATE integracoes_canais SET estado = 'ativo', nome = $2, usuario = $3, profile_id = $4, canal = $5, ultimo_erro = NULL WHERE id = $1`,
        [atual.rows[0].id, c.nome, c.usuario, c.profile_id, c.canal],
      );
      return { id: atual.rows[0].id as string, novo: false };
    }
    // Conta ligada a outra subconta: o indice unico global devolve 23505 (a RLS esconde a linha alheia).
    const r = await this.c.query(
      `INSERT INTO integracoes_canais (canal, conta_id, profile_id, nome, usuario, origem, creator_id) VALUES ($1, $2, $3, $4, $5, $6, nucleo_usuario_atual()) RETURNING id`,
      [c.canal, c.conta_id, c.profile_id, c.nome, c.usuario, c.origem ?? 'erp'],
    );
    return { id: r.rows[0].id as string, novo: true };
  }
  async atualizarCanal(id: string, p: Partial<Pick<CanalDados, 'estado' | 'sincronizado_em' | 'importadas' | 'ultimo_erro' | 'job_sync_id' | 'import_cursor' | 'historico_completo'>>): Promise<void> {
    const campos = Object.entries(p).filter(([, v]) => v !== undefined);
    if (!campos.length) return;
    const sets = campos.map(([k], i) => `${k} = $${i + 2}`).join(', ');
    await this.c.query(`UPDATE integracoes_canais SET ${sets} WHERE id = $1 AND deleted_at IS NULL`, [id, ...campos.map(([, v]) => v)]);
  }
  async conversaPorContato(canal: Plataforma, contato: string): Promise<ConversaVinculada | null> {
    const r = await this.c.query(
      `SELECT ${COLUNAS_CONV} FROM integracoes_zernio_conversas z
       JOIN integracoes_canais c ON c.id = z.canal_id AND c.estado = 'ativo' AND c.deleted_at IS NULL
       WHERE z.canal = $1 AND z.contato = $2 AND z.deleted_at IS NULL ORDER BY z.updated_at DESC LIMIT 1`,
      [canal, contato.replace(/^\+/, '')],
    );
    return (r.rows[0] as ConversaVinculada | undefined) ?? null;
  }
  async gravarConversa(c: { canal_id: string; canal: Plataforma; conversa_externa_id: string; contato: string; nome: string | null; usuario?: string | null; foto?: string | null }): Promise<void> {
    await this.c.query(
      `INSERT INTO integracoes_zernio_conversas (canal_id, canal, conversa_externa_id, contato, nome, usuario, foto_url) VALUES ($1, $2, $3, $4, $5, $6, $7)
       ON CONFLICT (tenant_id, workspace_id, canal_id, conversa_externa_id) DO UPDATE SET contato = EXCLUDED.contato,
         nome = coalesce(EXCLUDED.nome, integracoes_zernio_conversas.nome), usuario = coalesce(EXCLUDED.usuario, integracoes_zernio_conversas.usuario),
         foto_url = coalesce(EXCLUDED.foto_url, integracoes_zernio_conversas.foto_url), deleted_at = NULL`,
      [c.canal_id, c.canal, c.conversa_externa_id, c.contato.replace(/^\+/, ''), c.nome, c.usuario ?? null, c.foto ?? null],
    );
  }
  async conversaExterna(canalId: string, conversaExternaId: string): Promise<ConversaVinculada | null> {
    const r = await this.c.query(
      `SELECT ${COLUNAS_CONV} FROM integracoes_zernio_conversas z JOIN integracoes_canais c ON c.id = z.canal_id
       WHERE z.canal_id = $1 AND z.conversa_externa_id = $2 AND z.deleted_at IS NULL`, [canalId, conversaExternaId]);
    return (r.rows[0] as ConversaVinculada | undefined) ?? null;
  }
  async atualizarConversa(canalId: string, conversaExternaId: string, p: PatchConversa): Promise<void> {
    const campos = Object.entries(p).filter(([, v]) => v !== undefined);
    if (!campos.length) return;
    const sets = campos.map(([k], i) => `${k} = $${i + 3}`).join(', ');
    await this.c.query(`UPDATE integracoes_zernio_conversas SET ${sets} WHERE canal_id = $1 AND conversa_externa_id = $2`, [canalId, conversaExternaId, ...campos.map(([, v]) => v)]);
  }
  async filtroWebhook(): Promise<{ accountIds: string[] }> {
    const r = await this.c.query(`SELECT conta_id FROM integracoes_canais WHERE estado = 'ativo' AND deleted_at IS NULL ORDER BY conta_id`);
    return { accountIds: r.rows.map((l) => l.conta_id as string) };
  }
  async anexo(id: string): Promise<{ mime: string; nome: string; dados: Buffer } | null> {
    const r = await this.c.query(`SELECT mime, nome, dados FROM conversas_anexos WHERE id = $1 AND deleted_at IS NULL`, [id]);
    return (r.rows[0] as { mime: string; nome: string; dados: Buffer } | undefined) ?? null;
  }
  async mudarConector(slug: Plataforma, estado: 'ativo' | 'aguardando_credencial'): Promise<void> {
    await this.mudarConectorSlug(slug, estado);
  }
}
