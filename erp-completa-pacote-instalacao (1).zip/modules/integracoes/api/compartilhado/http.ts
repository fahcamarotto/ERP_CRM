/**
 * Cliente HTTP dos provedores (Zernio, Maton, Resend): fetch proprio com timeout, sem seguir redirect e com
 * nova tentativa so quando e seguro (leitura, ou escrita com Idempotency-Key) em falha de rede, 429 e 5xx.
 * Nunca registra o token; mensagens de erro passam por `ocultar` antes de sair.
 */
export class ErroProvedor extends Error {
  constructor(
    mensagem: string,
    readonly status: number | null,
    readonly codigo: string | null = null,
    /** Erro do remetente (4xx exceto 408, 409, 429): repetir nao resolve. */
    readonly permanente = false,
  ) {
    super(mensagem);
    this.name = 'ErroProvedor';
  }
}

export interface OpcoesHttp {
  base: string;
  token: string;
  provedor: string;
  timeoutMs?: number;
  tentativas?: number;
  /** Espera entre tentativas (ms); o teste usa 0. */
  espera?: number;
}

export interface Pedido {
  metodo: 'GET' | 'POST' | 'PATCH' | 'PUT' | 'DELETE';
  caminho: string;
  query?: Record<string, string | number | undefined | null>;
  corpo?: unknown;
  /** multipart/form-data (envio de arquivo); exclui `corpo`. */
  formulario?: FormData;
  idempotencia?: string;
}

const pausa = (ms: number) => new Promise((r) => setTimeout(r, ms));

export class ClienteHttp {
  constructor(private readonly o: OpcoesHttp) {}

  private ocultar(texto: string): string {
    return texto.split(this.o.token || '\u0000').join('[oculto]').slice(0, 500);
  }

  url(caminho: string, query?: Pedido['query']): string {
    const u = new URL(this.o.base.replace(/\/$/, '') + '/' + caminho.replace(/^\//, ''));
    for (const [k, v] of Object.entries(query ?? {})) if (v !== undefined && v !== null && v !== '') u.searchParams.set(k, String(v));
    return u.toString();
  }

  async pedir<T = Record<string, unknown>>(p: Pedido): Promise<T> {
    if (!this.o.token) throw new ErroProvedor(`${this.o.provedor}: credencial de plataforma ausente no ambiente (cofre)`, null, 'sem_credencial', true);
    const seguro = p.metodo === 'GET' || !!p.idempotencia;
    const max = seguro ? Math.max(1, this.o.tentativas ?? 3) : 1;
    let ultimo: ErroProvedor | null = null;
    for (let i = 0; i < max; i++) {
      if (i > 0) await pausa((this.o.espera ?? 400) * i);
      const headers: Record<string, string> = { authorization: `Bearer ${this.o.token}`, accept: 'application/json' };
      if (p.corpo !== undefined && !p.formulario) headers['content-type'] = 'application/json';
      if (p.idempotencia) headers['idempotency-key'] = p.idempotencia;
      let res: Response;
      try {
        res = await fetch(this.url(p.caminho, p.query), {
          method: p.metodo, headers, redirect: 'manual',
          body: p.formulario ?? (p.corpo === undefined ? undefined : JSON.stringify(p.corpo)),
          signal: AbortSignal.timeout(this.o.timeoutMs ?? 15_000),
        });
      } catch (e) {
        const nome = e instanceof Error ? e.name : 'Erro';
        ultimo = new ErroProvedor(`${this.o.provedor}: sem resposta (${nome})`, null, seguro ? 'indisponivel' : 'resultado_desconhecido');
        continue;
      }
      const texto = await res.text();
      let dados: unknown = null;
      try { dados = texto ? JSON.parse(texto) : {}; } catch { dados = null; }
      const obj = (dados && typeof dados === 'object' ? dados : {}) as Record<string, unknown>;
      if (res.status >= 200 && res.status < 300 && obj.success !== false) {
        if (dados === null) throw new ErroProvedor(`${this.o.provedor}: resposta sem JSON`, res.status, 'resposta_invalida');
        return dados as T;
      }
      const err = (obj.error && typeof obj.error === 'object' ? obj.error : {}) as Record<string, unknown>;
      const msg = [err.message, obj.message, typeof obj.error === 'string' ? obj.error : null].find((x) => typeof x === 'string') as string | undefined;
      const codigo = (err.code ?? obj.code ?? null) as string | null;
      const permanente = res.status >= 400 && res.status < 500 && ![408, 409, 429].includes(res.status);
      ultimo = new ErroProvedor(this.ocultar(`${this.o.provedor} ${res.status}: ${msg ?? 'requisicao recusada'}`), res.status, codigo ? String(codigo) : null, permanente);
      if (permanente || (res.status < 500 && res.status !== 429)) break;
    }
    throw ultimo ?? new ErroProvedor(`${this.o.provedor}: falha`, null);
  }
}

/** Host permitido para URL de autorizacao devolvida pelo provedor (https, sem credencial, porta padrao). */
export function hostPermitido(url: unknown, hosts: string[]): boolean {
  if (typeof url !== 'string') return false;
  let u: URL;
  try { u = new URL(url); } catch { return false; }
  if (u.protocol !== 'https:' || u.username || u.password || (u.port && u.port !== '443')) return false;
  const h = u.hostname.toLowerCase();
  return hosts.some((x) => h === x || h.endsWith(`.${x}`));
}
