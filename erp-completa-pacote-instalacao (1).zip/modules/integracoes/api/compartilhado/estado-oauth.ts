/**
 * State OAuth assinado de uso unico (padrao zernio_linkedin_* do sistema de agentes de referencia): carrega subconta, usuario,
 * provedor, plataforma, nonce e expiracao, assinado com HMAC-SHA256. So o hash fica no banco; consumir marca
 * usado_em. Validar confere assinatura, expiracao e que a sessao de quem volta e a mesma de quem iniciou.
 */
import { createHash, createHmac, randomBytes, timingSafeEqual } from 'node:crypto';
import { erroDe, fail, ok, type Result } from './result.ts';

export const VALIDADE_STATE_MS = 15 * 60 * 1000;

export interface DadosState {
  tenant: string;
  workspace: string;
  usuario: string;
  provedor: 'zernio' | 'maton';
  plataforma: string;
  nonce: string;
  expira: number;
  /** Tela para onde o callback volta (`conectores` ou `conversas`). */
  retorno?: string;
}

export interface Escopo { tenant: string; workspace: string; usuario: string }

const b64 = (s: string) => Buffer.from(s, 'utf8').toString('base64url');
const assinar = (chave: string, corpo: string) => createHmac('sha256', chave).update(`erp-oauth-state:${corpo}`).digest('hex');

export function hashState(state: string): string {
  return createHash('sha256').update(state).digest('hex');
}

export function emitirState(chave: string, e: Escopo & { provedor: DadosState['provedor']; plataforma: string; retorno?: string }, agora = Date.now()): { state: string; hash: string; expira: Date } {
  if (!chave || chave.length < 16) throw new Error('segredo de assinatura do state ausente');
  const d: DadosState = { tenant: e.tenant, workspace: e.workspace, usuario: e.usuario, provedor: e.provedor, plataforma: e.plataforma, nonce: randomBytes(16).toString('hex'), expira: agora + VALIDADE_STATE_MS, ...(e.retorno ? { retorno: e.retorno } : {}) };
  const corpo = b64(JSON.stringify(d));
  const state = `${corpo}.${assinar(chave, corpo)}`;
  return { state, hash: hashState(state), expira: new Date(d.expira) };
}

/** Confere assinatura, validade e dono. Nao consome: o consumo e atomico no repositorio (hash + usado_em). */
export function validarState(chave: string, state: unknown, sessao: Escopo, provedor: DadosState['provedor'], agora = Date.now()): Result<DadosState> {
  const invalido = fail<DadosState>(erroDe('state_invalido', 'Retorno de autorizacao invalido ou adulterado', 'state'));
  if (typeof state !== 'string' || state.length > 2048 || !/^[A-Za-z0-9_-]+\.[0-9a-f]{64}$/.test(state)) return invalido;
  const [corpo, sig] = state.split('.') as [string, string];
  const esperado = Buffer.from(assinar(chave, corpo), 'hex');
  const recebido = Buffer.from(sig, 'hex');
  if (esperado.length !== recebido.length || !timingSafeEqual(esperado, recebido)) return invalido;
  let d: DadosState;
  try { d = JSON.parse(Buffer.from(corpo, 'base64url').toString('utf8')) as DadosState; } catch { return invalido; }
  if (d.provedor !== provedor) return invalido;
  if (typeof d.expira !== 'number' || d.expira < agora) return fail(erroDe('state_expirado', 'A autorizacao expirou: comece de novo', 'state'));
  if (d.tenant !== sessao.tenant || d.workspace !== sessao.workspace || d.usuario !== sessao.usuario) {
    return fail(erroDe('state_de_outra_sessao', 'Esta autorizacao foi iniciada por outra subconta ou usuario', 'state'));
  }
  return ok(d);
}
