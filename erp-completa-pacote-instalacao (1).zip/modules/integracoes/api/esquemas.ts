/** JSON Schemas dos DTOs de entrada (validacao Fastify, OpenAPI em /docs e schema das tools MCP). */
import { AGENTES } from './agente/model/agente-mcp.ts';
import { CATALOGO } from './conector/model/catalogo.ts';

export const uuid = { type: 'string', format: 'uuid' } as const;
export const slugConector = { type: 'string', enum: CATALOGO.map((d) => d.slug), description: 'Slug do conector (whatsapp, instagram, google-calendar, webhook-landing, players, resend, pix-boleto)' };
export const agente = { type: 'string', enum: [...AGENTES], description: 'openclaw, hermes ou naia-claude' };

export const propsVinculo = {
  chave_id: uuid,
  chave_prefixo: { type: 'string', pattern: '^erp_live_[0-9a-f]{8}$' },
  escopos: { type: 'array', minItems: 1, maxItems: 64, items: { type: 'string', pattern: '^(\\*|\\*:(leitura|escrita)|[a-z0-9_-]+:(leitura|escrita))$' } },
};

/** URL publica da API (mesma regra do nucleo): ERP_URL_PUBLICA ou host e porta locais. */
export function urlBase(): string {
  return process.env.ERP_URL_PUBLICA ?? `http://${process.env.API_HOST ?? '127.0.0.1'}:${process.env.API_PORT ?? '4100'}`;
}

/** Fonte de lead: nome, pipeline e etapa de destino (null = pipeline padrao, primeira etapa), tags e responsavel. */
export const propsFonte = {
  nome: { type: 'string', minLength: 2, maxLength: 80, description: 'Nome da fonte (ex.: LP Imersao IA); vira a origem do lead' },
  funil_id: { anyOf: [uuid, { type: 'null' }], description: 'Pipeline de destino (null = pipeline padrao)' },
  etapa_id: { anyOf: [uuid, { type: 'null' }], description: 'Etapa (coluna) de destino, aberta e do pipeline escolhido (null = primeira etapa)' },
  tags: { type: 'array', maxItems: 20, items: { type: 'string', minLength: 1, maxLength: 60 }, description: 'Tags aplicadas ao cliente no Cadastros' },
  responsavel_id: { anyOf: [uuid, { type: 'null' }], description: 'Responsavel da oportunidade (usuario ativo)' },
};
