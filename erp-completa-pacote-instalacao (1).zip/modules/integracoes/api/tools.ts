/**
 * @tool do modulo Integracoes (N15): conectores.listar, canais.listar, agentes_mcp.listar, mcp.snippets e as fontes
 * de lead (fontes_lead.listar, fonte_lead.obter, fonte_lead.criar).
 * Conectar canal, Google e vincular chave de agente ficam so na API com sessao de usuario (routes.ts).
 */
import { tool } from '@erp/api/sdk';
import { listarAgentes } from './agente/query/agentes.ts';
import { snippets, urlMcp } from './agente/model/snippets.ts';
import type { Agente } from './agente/model/agente-mcp.ts';
import { ambiente, urlPublica, webhookZernio } from './ambiente.ts';
import { listarConectores } from './conector/query/conectores.ts';
import { naoEncontrado } from './borda.ts';
import { contextoPg } from './compartilhado/efeitos-pg.ts';
import { exigirOk } from './compartilhado/result.ts';
import { agente, propsFonte, urlBase, uuid } from './esquemas.ts';
import { casosDeUso } from './fabrica.ts';
import type { EntradaFonte } from './fonte/model/fonte-lead.ts';
import { listarFontes, recebidosDaFonte, urlDaFonte } from './fonte/query/fontes.ts';
import { ZernioRepoPg } from './zernio/adapter/zernio-repo-pg.ts';

tool<Record<string, never>>({
  nome: 'conectores.listar', modulo: 'integracoes', titulo: 'Listar conectores', tipo: 'leitura', permissao: 'integracoes.ver',
  descricao: 'Lista os conectores da subconta (WhatsApp, Instagram, Google Calendar, landing page, players, Resend, Pix e boleto) com fluxo de conexao e estado. Nenhum conector guarda chave colada.',
  entrada: { type: 'object', properties: {} },
  rota: { metodo: 'GET', caminho: '/api/v1/integracoes/catalogo' },
  executar: ({ c }) => listarConectores(c),
});

tool<Record<string, never>>({
  nome: 'canais.listar', modulo: 'integracoes', titulo: 'Listar canais de mensagem', tipo: 'leitura', permissao: 'integracoes.ver',
  descricao: 'Lista os canais WhatsApp e Instagram conectados pela Zernio nesta subconta, com status, ultima sincronizacao e se o recebimento e em tempo real (webhook) ou por sincronizacao periodica.',
  entrada: { type: 'object', properties: {} },
  rota: { metodo: 'GET', caminho: '/api/v1/integracoes/zernio/canais' },
  executar: async ({ c }) => ({ configurado: ambiente.zernio(), tempo_real: !!webhookZernio(), url_publica: urlPublica(), canais: await new ZernioRepoPg(c).canais() }),
});

tool<Record<string, never>>({
  nome: 'agentes_mcp.listar', modulo: 'integracoes', titulo: 'Listar agentes MCP', tipo: 'leitura', permissao: 'integracoes.ver',
  descricao: 'Lista os agentes MCP da subconta (OpenClaw, Hermes, Naia Claude) com o prefixo e os escopos da chave vinculada e o snippet .mcp.json de cada um.',
  entrada: { type: 'object', properties: {} },
  rota: { metodo: 'GET', caminho: '/api/v1/integracoes/mcp/agentes' },
  executar: ({ c }) => listarAgentes(c, urlMcp(urlBase())),
});

tool<{ agente?: Agente }>({
  nome: 'mcp.snippets', modulo: 'integracoes', titulo: 'Snippets de conexao MCP', tipo: 'leitura', permissao: 'integracoes.ver',
  descricao: 'Devolve o .mcp.json (transporte http, Authorization Bearer ${ERP_MCP_KEY}) para conectar OpenClaw, Hermes ou Naia Claude ao servidor MCP desta subconta.',
  entrada: { type: 'object', properties: { agente } },
  rota: { metodo: 'GET', caminho: '/api/v1/integracoes/mcp/snippets' },
  executar: async (_ctx, a) => ({ url: urlMcp(urlBase()), snippets: snippets(urlMcp(urlBase()), a.agente) }),
});

tool<Record<string, never>>({
  nome: 'fontes_lead.listar', modulo: 'integracoes', titulo: 'Listar fontes de lead', tipo: 'leitura', permissao: 'integracoes.ver',
  descricao: 'Lista as fontes de lead (landing pages) da subconta: nome, URL propria, pipeline e etapa de destino, tags, responsavel, ativa ou pausada, leads recebidos e aviso de destino. Nunca devolve o segredo.',
  entrada: { type: 'object', properties: {} },
  rota: { metodo: 'GET', caminho: '/api/v1/integracoes/fontes-lead' },
  executar: ({ c }) => listarFontes(c, urlBase()),
});

tool<{ id: string }>({
  nome: 'fonte_lead.obter', modulo: 'integracoes', titulo: 'Obter fonte de lead', tipo: 'leitura', permissao: 'integracoes.ver',
  descricao: 'Ficha de uma fonte de lead com URL, destino, contador e os ultimos leads recebidos.',
  entrada: { type: 'object', required: ['id'], properties: { id: uuid } },
  rota: { metodo: 'GET', caminho: '/api/v1/integracoes/fontes-lead/:id' },
  executar: async ({ c }, a) => {
    const f = (await listarFontes(c, urlBase(), a.id))[0];
    if (!f) throw naoEncontrado('Fonte de lead nao encontrada');
    return { ...f, ultimos: await recebidosDaFonte(c, a.id, 10) };
  },
});

tool<EntradaFonte & { nome: string }>({
  nome: 'fonte_lead.criar', modulo: 'integracoes', titulo: 'Criar fonte de lead', tipo: 'escrita', permissao: 'integracoes.criar',
  descricao: 'Cria uma fonte de lead (landing page) com URL e segredo proprios. O lead que chega nela vira cliente no Cadastros (sem duplicar por e-mail ou telefone) e oportunidade no pipeline e na etapa escolhidos, com origem igual ao nome da fonte. Sem funil_id vai para o pipeline padrao; sem etapa_id, para a primeira etapa. O segredo aparece so nesta resposta.',
  entrada: { type: 'object', required: ['nome'], additionalProperties: false, properties: propsFonte },
  rota: { metodo: 'POST', caminho: '/api/v1/integracoes/fontes-lead' },
  executar: async ({ c, ator, ip }, a) => {
    const r = exigirOk(await casosDeUso(c).criarFonte.execute(contextoPg(c, ator, ip), a));
    const f = (await listarFontes(c, urlBase(), r.id))[0]!;
    return { ...f, url: urlDaFonte(urlBase(), r.token), segredo: r.segredo, assinatura: 'X-Hub-Signature-256: sha256=<HMAC-SHA256 hex do corpo cru>' };
  },
});
