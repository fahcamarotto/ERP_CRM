/**
 * Resend com chave de plataforma (cofre, RESEND_API_KEY): status do dominio remetente e e-mail de teste para o
 * proprio usuario logado. O envio passa pela fila do nucleo (enviarEmail -> worker -> Resend).
 */
import { enviarEmail, exigirUsuario, requer, type FastifyInstance } from '@erp/api/sdk';
import { ambiente } from '../ambiente.ts';
import { naTransacao } from '../borda.ts';
import { ClienteHttp, ErroProvedor } from '../compartilhado/http.ts';
import { reconciliarConectores } from '../conector/query/conectores.ts';

const tags = ['integracoes'];

export interface ResendDTO { configurado: boolean; dominio: string | null; dominio_status: string | null; remetente: string | null; erro: string | null }

export function remetente(): string | null {
  const d = process.env.RESEND_DOMINIO;
  return process.env.ERP_EMAIL_REMETENTE ?? (d ? `ERP <nao-responda@${d}>` : null);
}

async function statusResend(): Promise<ResendDTO> {
  const base = { configurado: ambiente.resend(), dominio: process.env.RESEND_DOMINIO ?? null, dominio_status: null, remetente: remetente(), erro: null };
  if (!base.configurado) return base;
  try {
    const http = new ClienteHttp({ base: process.env.RESEND_API_BASE || 'https://api.resend.com', token: process.env.RESEND_API_KEY ?? '', provedor: 'resend', timeoutMs: 8000, tentativas: 1 });
    const r = await http.pedir<{ data?: { name?: string; status?: string }[] }>({ metodo: 'GET', caminho: 'domains' });
    const lista = r.data ?? [];
    const d = lista.find((x) => x.name === base.dominio) ?? lista[0];
    return { ...base, dominio: d?.name ?? base.dominio, dominio_status: d?.status ?? null };
  } catch (e) {
    return { ...base, erro: e instanceof ErroProvedor ? e.message : 'falha ao consultar o Resend' };
  }
}

export function rotasResend(app: FastifyInstance): void {
  app.get('/resend', {
    preHandler: requer('integracoes.ver'),
    schema: { tags, summary: 'Status do Resend (chave de plataforma, dominio remetente e verificacao)' },
  }, async (req) => {
    await naTransacao(req, (_casos, _ctx, c) => reconciliarConectores(c));
    return statusResend();
  });

  app.post('/resend/teste', {
    preHandler: [exigirUsuario, requer('integracoes.editar')],
    schema: { tags, summary: 'Envia um e-mail de teste para o e-mail do usuario logado (pela fila)' },
  }, async (req, reply) => {
    if (!ambiente.resend()) return reply.code(409).send({ erro: { codigo: 'sem_credencial', mensagem: 'Resend sem chave de plataforma no ambiente' } });
    const r = await naTransacao(req, async (_casos, ctx, c) => {
      const u = (await c.query('SELECT email FROM usuarios WHERE id = nucleo_usuario_atual() AND deleted_at IS NULL')).rows[0] as { email: string } | undefined;
      if (!u) return null;
      const id = await enviarEmail(c, 'aviso', u.email, { titulo: 'Teste do ERP', mensagem: 'E-mail de teste enviado pela tela Integracoes > Conectores. A entrega pelo Resend esta funcionando.' });
      await ctx.efeitos.auditar('resend.teste', 'emails', id, undefined, { para: u.email });
      return { email_id: id, para: u.email };
    });
    if (!r) return reply.code(404).send({ erro: { codigo: 'nao_encontrado', mensagem: 'Usuario da sessao nao encontrado' } });
    return reply.code(202).send(r);
  });
}
