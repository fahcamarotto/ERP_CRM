/**
 * Handlers de worker do Integracoes (carregados pelo worker do nucleo na partida).
 * `c` ja esta numa transacao do papel erp_worker com o escopo do job (RLS vale). Nunca imprime segredo.
 */
import type { HandlersModulo } from '@erp/api/sdk/puro';
import { contextoPg } from '../api/compartilhado/efeitos-pg.ts';
import { casosDeUso } from '../api/fabrica.ts';
import { TIPO_JOB_GOOGLE } from '../api/google/use-case/google.ts';
import { TIPO_JOB_IMPORTAR } from '../api/zernio/use-case/conexao.ts';
import type { PedidoEnvio } from '../api/zernio/use-case/mensagens.ts';

const SISTEMA = { tipo: 'sistema' as const, id: null };
const falhar = (r: { ok: false; erros: { mensagem: string }[] }) => { throw new Error(r.erros.map((e) => e.mensagem).join('; ')); };

/** Agenda publicou marcado, confirmado ou cancelado: sai para o Google quando a conexao Maton esta ativa. */
function paraGoogle(cancelado: boolean) {
  return async (d: { payload: unknown }, c: Parameters<HandlersModulo[string]>[1]) => {
    const dados = (d.payload as { dados?: { id?: string; inicio?: string; fim?: string; estado?: string } }).dados ?? {};
    if (!dados.id) return;
    const r = await casosDeUso(c).enviarGoogle.execute(contextoPg(c, SISTEMA), { id: dados.id, inicio: dados.inicio, fim: dados.fim, estado: dados.estado, cancelado });
    if (!r.ok && r.erros[0]?.codigo !== 'provedor_recusou') falhar(r);
  };
}

const handlers: HandlersModulo = {
  // Pipeline mandou o lead para o pipeline padrao porque o destino da fonte nao recebe mais: aviso na fonte.
  'integracoes:ao:lead.destino_substituido': async (d, c) => {
    const dados = (d.payload as { dados?: { fonte_id?: string | null; motivo?: string | null } }).dados;
    if (!dados?.fonte_id) return;
    const r = await casosDeUso(c).registrarAvisoFonte.execute(dados);
    if (!r.ok) falhar(r);
  },

  // Importacao periodica das conversas da Zernio (fallback sem URL publica; com URL publica roda so na conexao).
  [TIPO_JOB_IMPORTAR]: async (d, c) => {
    const r = await casosDeUso(c).importarZernio.execute(contextoPg(c, SISTEMA), { canal_id: (d.payload as { canal_id: string }).canal_id, job_id: d.outboxId });
    if (!r.ok) falhar(r);
  },

  // Conversas pediu o envio (CONTRATOS 7.1.3): entrega na Zernio e devolve o status pelo leitor de webhook do Conversas.
  'integracoes:ao:mensagem.envio_solicitado': async (d, c) => {
    const dados = (d.payload as { dados?: PedidoEnvio }).dados;
    if (!dados?.mensagem_id) return;
    const r = await casosDeUso(c).entregarZernio.execute(contextoPg(c, SISTEMA), dados);
    if (!r.ok) falhar(r);
  },

  // Google Agenda via Maton: eventos do Google entram na Agenda; agendamentos saem para o Google.
  [TIPO_JOB_GOOGLE]: async (d, c) => {
    const r = await casosDeUso(c).importarGoogle.execute(contextoPg(c, SISTEMA), { conexao_id: (d.payload as { conexao_id: string }).conexao_id, job_id: d.outboxId });
    if (!r.ok) falhar(r);
  },
  'integracoes:ao:agenda.marcado': paraGoogle(false),
  'integracoes:ao:agenda.confirmado': paraGoogle(false),
  'integracoes:ao:agenda.cancelado': paraGoogle(true),
};

export default handlers;
