/**
 * Teste ponta a ponta das fontes de lead contra a API e o worker rodando (npm run start:bg). So roda com
 * ERP_TESTE_API=1; sem isso fica pulado. Usa o admin do .env (senha nunca impressa), cria duas fontes com destinos
 * diferentes, envia leads assinados e confere no banco: oportunidade no pipeline e na etapa da fonte, cliente sem
 * duplicar por e-mail, assinatura invalida 401, fonte pausada recusada e URL antiga indo para o pipeline padrao.
 * Apaga tudo o que criou no fim.
 * Rodar: ERP_TESTE_API=1 node --import tsx --test modules/integracoes/tests/fontes-lead.api.test.ts
 */
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { after, before, describe, it } from 'node:test';
import pg from 'pg';
import { decifrarSegredo } from '@erp/shared/servidor';

const RAIZ = path.resolve(import.meta.dirname, '../../..');
const env = Object.fromEntries(fs.readFileSync(path.join(RAIZ, '.env'), 'utf8').split('\n').filter((l) => /^[A-Z_]+=/.test(l)).map((l) => [l.slice(0, l.indexOf('=')), l.slice(l.indexOf('=') + 1)]));
process.env.ERP_SESSION_SECRET ??= env.ERP_SESSION_SECRET;
const API = `http://${env.API_HOST || '127.0.0.1'}:${env.API_PORT || '4100'}`;
const ATIVO = process.env.ERP_TESTE_API === '1';
const marca = `prova${Date.now().toString(36)}`;

let cookie = '';
let db: pg.Client;
const criadas = { fontes: [] as string[], funis: [] as string[], emails: [] as string[] };

async function api<T = any>(metodo: string, rota: string, corpo?: unknown): Promise<{ status: number; corpo: T }> {
  const r = await fetch(`${API}${rota}`, { method: metodo, headers: { cookie, ...(corpo === undefined ? {} : { 'content-type': 'application/json' }) }, body: corpo === undefined ? undefined : JSON.stringify(corpo) });
  return { status: r.status, corpo: (await r.json().catch(() => null)) as T };
}

async function enviarLead(url: string, segredo: string, lead: Record<string, unknown>, assinaturaErrada = false): Promise<number> {
  const corpo = JSON.stringify(lead);
  const ass = crypto.createHmac('sha256', assinaturaErrada ? 'segredo-errado' : segredo).update(corpo).digest('hex');
  const r = await fetch(url.replace(/^https?:\/\/[^/]+/, API), { method: 'POST', headers: { 'content-type': 'application/json', 'x-hub-signature-256': `sha256=${ass}` }, body: corpo });
  return r.status;
}

/** Espera o worker abrir a oportunidade do cliente com este e-mail (lead.recebido e pipeline:ao:lead.recebido). */
async function oportunidadesDe(email: string, minimo = 1): Promise<{ parceiro_id: string; funil_id: string; etapa_id: string; origem: string; canal: string }[]> {
  for (let i = 0; i < 60; i++) {
    const r = await db.query(
      `SELECT o.parceiro_id, o.funil_id, o.etapa_id, o.origem, o.canal FROM pipeline_oportunidades o JOIN cadastros_parceiros p ON p.id = o.parceiro_id
        WHERE lower(p.email) = lower($1) AND o.deleted_at IS NULL ORDER BY o.created_at`, [email]);
    if (r.rows.length >= minimo) return r.rows;
    await new Promise((ok) => setTimeout(ok, 500));
  }
  return [];
}

describe('Fontes de lead pela API (ponta a ponta)', { skip: !ATIVO && 'defina ERP_TESTE_API=1 com a API e o worker rodando' }, () => {
  let destinos: { funis: { id: string; nome: string; padrao: boolean; etapas: { id: string; nome: string }[] }[] };
  let f1: { id: string; url: string; segredo: string };
  let f2: { id: string; url: string; segredo: string };
  let funilB: string;

  before(async () => {
    db = new pg.Client({ host: env.PGHOST || '127.0.0.1', port: Number(env.PGPORT || 5432), database: env.ERP_DB_NAME || 'erp_local' });
    await db.connect();
    await db.query(`SET statement_timeout = '10s'`);
    const r = await fetch(`${API}/api/v1/auth/login`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ email: env.ERP_ADMIN_EMAIL, senha: env.ERP_ADMIN_PASSWORD }) });
    assert.equal(r.status, 200, 'login do admin');
    cookie = (r.headers.getSetCookie?.() ?? []).map((c) => c.split(';')[0]).join('; ');
    const b = await api<{ id: string }>('POST', '/api/v1/pipeline/funis', { nome: `Prova ${marca}`, etapas: ['Entrada B', 'Qualificado B'] });
    assert.equal(b.status, 200, JSON.stringify(b.corpo));
    funilB = b.corpo.id;
    criadas.funis.push(funilB);
    destinos = (await api('GET', '/api/v1/integracoes/fontes-lead/destinos')).corpo;
  });

  after(async () => {
    if (!db) return;
    // Limpeza do que o teste criou (banco local, dados de prova).
    try {
    await db.query(`DELETE FROM pipeline_movimentos WHERE oportunidade_id IN (SELECT o.id FROM pipeline_oportunidades o JOIN cadastros_parceiros p ON p.id = o.parceiro_id WHERE p.email = ANY($1))`, [criadas.emails]);
    await db.query(`DELETE FROM pipeline_oportunidades WHERE parceiro_id IN (SELECT id FROM cadastros_parceiros WHERE email = ANY($1))`, [criadas.emails]);
    await db.query(`DELETE FROM cadastros_parceiro_tags WHERE parceiro_id IN (SELECT id FROM cadastros_parceiros WHERE email = ANY($1))`, [criadas.emails]);
    await db.query(`DELETE FROM cadastros_parceiros WHERE email = ANY($1)`, [criadas.emails]);
    await db.query(`DELETE FROM cadastros_classificacoes WHERE tipo = 'tag' AND nome = $1`, [marca]);
    await db.query(`DELETE FROM integracoes_eventos_recebidos WHERE fonte_id = ANY($1) OR payload->>'email' = ANY($2)`, [criadas.fontes, criadas.emails]);
    await db.query(`DELETE FROM integracoes_fontes_lead WHERE id = ANY($1)`, [criadas.fontes]);
    await db.query(`DELETE FROM pipeline_etapas WHERE funil_id = ANY($1)`, [criadas.funis]);
    await db.query(`DELETE FROM pipeline_funis WHERE id = ANY($1)`, [criadas.funis]);
    } finally {
      await db.end();
    }
  });

  it('cria duas fontes com destinos diferentes e devolve URL e segredo uma vez', async () => {
    const padrao = destinos.funis.find((f) => f.padrao)!;
    const b = destinos.funis.find((f) => f.id === funilB)!;
    const r1 = await api('POST', '/api/v1/integracoes/fontes-lead', { nome: `LP A ${marca}`, funil_id: padrao.id, etapa_id: padrao.etapas[1]!.id, tags: [marca] });
    const r2 = await api('POST', '/api/v1/integracoes/fontes-lead', { nome: `LP B ${marca}`, funil_id: b.id, etapa_id: b.etapas[1]!.id });
    assert.equal(r1.status, 200, JSON.stringify(r1.corpo));
    assert.equal(r2.status, 200, JSON.stringify(r2.corpo));
    f1 = r1.corpo; f2 = r2.corpo;
    criadas.fontes.push(f1.id, f2.id);
    assert.match(f1.url, /\/api\/v1\/webhooks\/webhook-landing\/[a-f0-9]{36}$/);
    assert.notEqual(f1.url, f2.url);
    assert.ok(f1.segredo && f2.segredo && f1.segredo !== f2.segredo);
    const lista = (await api<{ id: string }[]>('GET', '/api/v1/integracoes/fontes-lead')).corpo;
    assert.ok(lista.some((x) => x.id === f1.id) && !JSON.stringify(lista).includes(f1.segredo), 'lista sem segredo');
  });

  it('cada fonte abre o lead no proprio pipeline e etapa, origem = nome da fonte, tags no cliente', async () => {
    const padrao = destinos.funis.find((f) => f.padrao)!;
    const b = destinos.funis.find((f) => f.id === funilB)!;
    const e1 = `a.${marca}@exemplo.com`; const e2 = `b.${marca}@exemplo.com`;
    criadas.emails.push(e1, e2);
    assert.equal(await enviarLead(f1.url, f1.segredo, { id: `${marca}-1`, nome: 'Lead A', email: e1, utm_source: 'google' }), 202);
    assert.equal(await enviarLead(f2.url, f2.segredo, { id: `${marca}-2`, nome: 'Lead B', email: e2 }), 202);
    const [oa] = await oportunidadesDe(e1); const [ob] = await oportunidadesDe(e2);
    assert.deepEqual([oa?.funil_id, oa?.etapa_id, oa?.origem, oa?.canal], [padrao.id, padrao.etapas[1]!.id, `LP A ${marca}`, 'site']);
    assert.deepEqual([ob?.funil_id, ob?.etapa_id, ob?.origem], [b.id, b.etapas[1]!.id, `LP B ${marca}`]);
    const tags = await db.query(`SELECT c.nome FROM cadastros_parceiros p JOIN cadastros_parceiro_tags t ON t.parceiro_id = p.id JOIN cadastros_classificacoes c ON c.id = t.tag_id WHERE p.email = $1`, [e1]);
    assert.deepEqual(tags.rows.map((x) => x.nome), [marca]);
  });

  it('mesmo e-mail de novo nao duplica o cliente', async () => {
    const e1 = `a.${marca}@exemplo.com`;
    assert.equal(await enviarLead(f1.url, f1.segredo, { id: `${marca}-3`, nome: 'Lead A de novo', email: e1.toUpperCase() }), 202);
    const ops = await oportunidadesDe(e1, 2);
    assert.equal(ops.length, 2);
    const p = await db.query(`SELECT count(*)::int AS n FROM cadastros_parceiros WHERE lower(email) = lower($1) AND deleted_at IS NULL`, [e1]);
    assert.equal(p.rows[0].n, 1);
  });

  it('assinatura invalida 401 e fonte pausada recusada', async () => {
    assert.equal(await enviarLead(f2.url, f2.segredo, { id: `${marca}-x`, email: `x.${marca}@exemplo.com` }, true), 401);
    assert.equal((await api('POST', `/api/v1/integracoes/fontes-lead/${f2.id}/estado`, { estado: 'pausada' })).status, 200);
    assert.equal(await enviarLead(f2.url, f2.segredo, { id: `${marca}-p`, email: `p.${marca}@exemplo.com` }), 403);
  });

  it('URL antiga (fonte padrao) continua indo para o pipeline padrao, primeira etapa', async () => {
    const lista = (await api<{ id: string; padrao: boolean; url: string }[]>('GET', '/api/v1/integracoes/fontes-lead')).corpo;
    const antiga = lista.find((x) => x.padrao)!;
    const conector = await db.query(`SELECT k.token_entrada, k.segredo_entrada_ref FROM conectores k JOIN integracoes_fontes_lead f ON f.tenant_id = k.tenant_id AND f.workspace_id = k.workspace_id WHERE f.id = $1 AND k.slug = 'webhook-landing'`, [antiga.id]);
    assert.ok(antiga.url.endsWith(conector.rows[0].token_entrada), 'fonte padrao usa o token antigo do conector');
    assert.ok(conector.rows[0].segredo_entrada_ref, 'subconta de prova precisa do segredo antigo gerado');
    const e3 = `c.${marca}@exemplo.com`;
    criadas.emails.push(e3);
    assert.equal(await enviarLead(antiga.url, decifrarSegredo(conector.rows[0].segredo_entrada_ref), { id: `${marca}-4`, nome: 'Lead URL antiga', email: e3 }), 202);
    const [oc] = await oportunidadesDe(e3);
    const padrao = destinos.funis.find((f) => f.padrao)!;
    assert.deepEqual([oc?.funil_id, oc?.etapa_id, oc?.origem], [padrao.id, padrao.etapas[0]!.id, 'Landing page padrão']);
  });
});
