/**
 * Mock HTTP local da API Zernio (/api/v1) e do Maton (ctrl e gateway) para os testes e para a prova de ponta a
 * ponta sem tocar no provedor real. Nunca cria profile, conta ou mensagem de verdade.
 * Uso avulso: node --import tsx modules/integracoes/tests/mock-zernio.ts 4999
 */
import { createServer, type IncomingMessage, type Server } from 'node:http';
import type { AddressInfo } from 'node:net';
import { pathToFileURL } from 'node:url';

export interface Pedido { metodo: string; caminho: string; query: Record<string, string>; corpo: unknown; auth: string | undefined; idem: string | undefined; conexao: string | undefined }

export class MockProvedores {
  pedidos: Pedido[] = [];
  perfis = new Map<string, string>();
  contas: { _id: string; platform: string; profileId: string; username: string; displayName: string }[] = [];
  conversas: { id: string; accountId: string; platform: string; participantId: string; participantName: string; participantUsername?: string; participantPicture?: string; updatedTime?: string }[] = [];
  /** Mensagens por conversa, da mais nova para a mais antiga (como sortOrder=desc). */
  mensagens = new Map<string, { id: string; direction: string; message: string; createdAt: string; deliveryStatus?: string; attachments?: { type: string; url: string; filename?: string }[] }[]>();
  /** Tamanho da pagina de mensagens (a API real usa ate 100). */
  paginaMensagens = 100;
  webhooks: { _id: string; name: string; url: string; events: string[]; isActive: boolean; accountIds?: string[] }[] = [];
  /** Partes do ultimo multipart recebido (envio de arquivo). */
  ultimoMultipart: string | null = null;
  authHost = 'https://www.facebook.com/v21.0/dialog/oauth';
  falharProximoGet = 0;
  maton = new Map<string, { connection_id: string; status: string; url: string; app?: string }>();
  /** Chaves do Maton aceitas pelo mock (vazio: qualquer Bearer). Outra chave recebe 401 como o Maton real. */
  chavesMaton = new Set<string>();
  calendariosGoogle: { id: string; summary: string; primary?: boolean }[] = [{ id: 'dono@exemplo.com', summary: 'dono@exemplo.com', primary: true }, { id: 'equipe@group.calendar.google.com', summary: 'Equipe' }];
  eventosGoogle: Record<string, unknown>[] = [];
  private srv: Server | null = null;
  private n = 0;

  get base() { return `http://127.0.0.1:${(this.srv!.address() as AddressInfo).port}`; }

  async iniciar(porta = 0): Promise<this> {
    this.srv = createServer((req, res) => void this.tratar(req).then(([s, b]) => { res.writeHead(s, { 'content-type': 'application/json' }); res.end(JSON.stringify(b)); }));
    await new Promise<void>((ok) => this.srv!.listen(porta, '127.0.0.1', ok));
    return this;
  }
  async parar() { await new Promise((ok) => this.srv?.close(ok)); }
  feitos(metodo: string, prefixo: string) { return this.pedidos.filter((p) => p.metodo === metodo && p.caminho.startsWith(prefixo)); }

  private async tratar(req: IncomingMessage): Promise<[number, unknown]> {
    const u = new URL(req.url ?? '/', 'http://x');
    let bruto = '';
    for await (const c of req) bruto += c;
    const multipart = String(req.headers['content-type'] ?? '').startsWith('multipart/form-data');
    if (multipart) this.ultimoMultipart = bruto;
    const corpo = bruto && !multipart ? JSON.parse(bruto) : undefined;
    const p: Pedido = { metodo: req.method ?? 'GET', caminho: u.pathname, query: Object.fromEntries(u.searchParams), corpo, auth: req.headers.authorization, idem: req.headers['idempotency-key'] as string | undefined, conexao: req.headers['maton-connection'] as string | undefined };
    this.pedidos.push(p);
    if (!p.auth?.startsWith('Bearer ')) return [401, { error: 'sem token' }];
    if (p.metodo === 'GET' && this.falharProximoGet > 0) { this.falharProximoGet--; return [503, { error: 'indisponivel' }]; }
    const c = p.caminho.replace(/^\/api\/v1/, '');
    const q = p.query;
    if (c === '/profiles' && p.metodo === 'GET') return [200, { profiles: [...this.perfis.values()].map((id) => ({ _id: id, name: id })) }];
    if (c === '/profiles' && p.metodo === 'POST') {
      const k = p.idem ?? `sem-${++this.n}`;
      if (!this.perfis.has(k)) this.perfis.set(k, `prof_${++this.n}`);
      return [200, { profile: { _id: this.perfis.get(k), name: (corpo as { name: string }).name } }];
    }
    const conn = /^\/connect\/(whatsapp|instagram)$/.exec(c);
    if (conn) return [200, { authUrl: `${this.authHost}?client_id=mock&state=zernio-${q.profileId}`, state: 'x' }];
    if (c === '/accounts' && p.metodo === 'GET') return [200, { accounts: this.contas.filter((a) => !q.profileId || a.profileId === q.profileId) }];
    const del = /^\/accounts\/([^/]+)$/.exec(c);
    if (del && p.metodo === 'DELETE') { this.contas = this.contas.filter((a) => a._id !== del[1]); return [200, { success: true }]; }
    if (c === '/inbox/conversations' && p.metodo === 'GET') return [200, { data: this.conversas.filter((x) => x.accountId === q.accountId && x.platform === q.platform), pagination: { hasMore: false } }];
    if (c === '/inbox/conversations' && p.metodo === 'POST') return [200, { success: true, data: { messageId: `wamid.T${++this.n}`, conversationId: `conv_novo_${this.n}` } }];
    const msgs = /^\/inbox\/conversations\/([^/]+)\/messages$/.exec(c);
    if (msgs && p.metodo === 'GET') {
      const todas = this.mensagens.get(msgs[1]!) ?? [];
      const ini = q.cursor ? Number(q.cursor.replace('c', '')) : 0;
      const pag = todas.slice(ini, ini + this.paginaMensagens);
      const fim = ini + pag.length >= todas.length;
      return [200, { messages: pag, sortOrderApplied: 'desc', pagination: { hasMore: !fim, nextCursor: fim ? null : `c${ini + pag.length}` } }];
    }
    if (msgs && p.metodo === 'POST') return [200, { success: true, data: { messageId: `wamid.S${++this.n}`, conversationId: msgs[1], ...(multipart ? { attachments: [{ type: 'image', url: 'https://cdn.exemplo/x.png' }] } : {}) } }];
    if (c === '/webhooks/settings' && p.metodo === 'GET') return [200, { webhooks: this.webhooks }];
    if (c === '/webhooks/settings' && p.metodo === 'POST') { const w = corpo as { name: string; url: string; events: string[]; accountIds?: string[] }; this.webhooks.push({ _id: `wh_${++this.n}`, name: w.name, url: w.url, events: w.events, accountIds: w.accountIds ?? [], isActive: true }); return [200, { success: true }]; }
    if (c === '/webhooks/settings' && p.metodo === 'PUT') { const w = corpo as { webhookId: string; name: string; url: string; events: string[]; isActive: boolean; accountIds?: string[] }; const x = this.webhooks.find((y) => y._id === w.webhookId); if (x) Object.assign(x, { name: w.name, url: w.url, events: w.events, isActive: w.isActive, accountIds: w.accountIds ?? [] }); return [200, { success: true }]; }
    // Maton (ctrl e gateway)
    const ehMaton = c.startsWith('/connections') || c.startsWith('/google-calendar/');
    if (ehMaton && this.chavesMaton.size && !this.chavesMaton.has(p.auth.slice(7))) return [401, { error: { message: `invalid API key, received as ${p.auth.slice(7)}` } }];
    if (c === '/connections' && p.metodo === 'GET') return [200, { connections: [...this.maton.values()].filter((x) => (!q.app || (x.app ?? 'google-calendar') === q.app) && (!q.status || x.status === q.status)) }];
    if (c === '/google-calendar/calendar/v3/users/me/calendarList' && p.metodo === 'GET') return [200, { items: this.calendariosGoogle }];
    if (c === '/connections' && p.metodo === 'POST') { const id = `mconn_${++this.n}`; this.maton.set(id, { connection_id: id, status: 'PENDING', url: `https://connect.maton.ai/?session_token=t${this.n}` }); return [200, { connection_id: id }]; }
    const mc = /^\/connections\/([^/]+)$/.exec(c);
    if (mc && p.metodo === 'GET') { const x = this.maton.get(mc[1]!); return x ? [200, { connection: x }] : [404, { error: 'not found' }]; }
    if (mc && p.metodo === 'DELETE') { this.maton.delete(mc[1]!); return [200, {}]; }
    if (/^\/google-calendar\/calendar\/v3\/calendars\/[^/]+\/events$/.test(c)) {
      if (p.metodo === 'GET') return [200, { items: this.eventosGoogle }];
      return [200, { id: `gev_${++this.n}` }];
    }
    if (/^\/google-calendar\/calendar\/v3\/calendars\/[^/]+\/events\/[^/]+$/.test(c)) return [200, {}];
    return [404, { error: `rota do mock inexistente: ${p.metodo} ${c}` }];
  }
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  const m = await new MockProvedores().iniciar(Number(process.argv[2] ?? 4999));
  m.contas.push({ _id: 'acc_mock_wa', platform: 'whatsapp', profileId: 'prof_1', username: '+5511999990000', displayName: 'WhatsApp mock' });
  console.log(`mock zernio/maton em ${m.base}`);
}
