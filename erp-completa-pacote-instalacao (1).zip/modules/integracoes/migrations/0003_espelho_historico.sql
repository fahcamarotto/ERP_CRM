-- Espelhamento integral e vinculo de conta ja existente na Zernio (idempotente).
-- origem 'existente': conta que ja estava na Zernio (outro sistema da equipe usa a mesma conta); o ERP so le e
-- responde por ela, nunca remove a conta na Zernio. import_cursor guarda onde a varredura de conversas parou;
-- historico_cursor guarda onde o historico de mensagens de cada conversa parou (retomada sem duplicar).
ALTER TABLE integracoes_canais ADD COLUMN IF NOT EXISTS origem text NOT NULL DEFAULT 'erp' CHECK (origem IN ('erp', 'existente'));
ALTER TABLE integracoes_canais ADD COLUMN IF NOT EXISTS import_cursor text;
ALTER TABLE integracoes_canais ADD COLUMN IF NOT EXISTS historico_completo boolean NOT NULL DEFAULT false;
ALTER TABLE integracoes_zernio_conversas ADD COLUMN IF NOT EXISTS historico_cursor text;
ALTER TABLE integracoes_zernio_conversas ADD COLUMN IF NOT EXISTS historico_completo boolean NOT NULL DEFAULT false;
ALTER TABLE integracoes_zernio_conversas ADD COLUMN IF NOT EXISTS atualizada_externa text;
ALTER TABLE integracoes_zernio_conversas ADD COLUMN IF NOT EXISTS usuario text;
ALTER TABLE integracoes_zernio_conversas ADD COLUMN IF NOT EXISTS foto_url text;
