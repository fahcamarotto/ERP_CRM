-- M14 Integracoes: credencial cifrada de cada conector (M14.1) e agentes MCP com chave vinculada (M14.5, M14.6).
-- Toda tabela: tenant_id e workspace_id do contexto da sessao, PK composta, FK composta, RLS
-- por nucleo_aplicar_padrao, exclusao logica (sem DELETE). Idempotente.
-- Segredo nunca em claro: segredo_ref guarda so a cifra AES-256-GCM (cifra:v1:...) e sufixo os 4 ultimos caracteres.

-- M14.1 Credencial do conector ---------------------------------------------------------------
CREATE TABLE IF NOT EXISTS integracoes_credenciais (
  id            uuid NOT NULL DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL DEFAULT nucleo_tenant_atual(),
  workspace_id  uuid NOT NULL DEFAULT nucleo_workspace_atual(),
  creator_id    uuid,
  conector      text NOT NULL CHECK (conector ~ '^[a-z0-9-]{2,40}$'),
  segredo_ref   text NOT NULL CHECK (segredo_ref LIKE 'cifra:v1:%'),
  sufixo        text NOT NULL CHECK (length(sufixo) BETWEEN 1 AND 4),
  campos        jsonb NOT NULL DEFAULT '{}'::jsonb,
  teste_estado  text NOT NULL DEFAULT 'nunca' CHECK (teste_estado IN ('nunca', 'testando', 'ok', 'falhou')),
  ultimo_teste  timestamptz,
  ultimo_erro   text,
  job_id        uuid,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now(),
  deleted_at    timestamptz,
  PRIMARY KEY (id, tenant_id, workspace_id),
  FOREIGN KEY (workspace_id, tenant_id) REFERENCES workspaces (id, tenant_id),
  FOREIGN KEY (creator_id, tenant_id, workspace_id) REFERENCES usuarios (id, tenant_id, workspace_id)
);
CREATE UNIQUE INDEX IF NOT EXISTS integracoes_credenciais_conector_uq
  ON integracoes_credenciais (tenant_id, workspace_id, conector) WHERE deleted_at IS NULL;
SELECT nucleo_aplicar_padrao('integracoes_credenciais');

-- M14.5 e M14.6 Agentes MCP (openclaw, hermes, naia-claude) ---------------------------------
CREATE TABLE IF NOT EXISTS integracoes_agentes_mcp (
  id             uuid NOT NULL DEFAULT gen_random_uuid(),
  tenant_id      uuid NOT NULL DEFAULT nucleo_tenant_atual(),
  workspace_id   uuid NOT NULL DEFAULT nucleo_workspace_atual(),
  creator_id     uuid,
  agente         text NOT NULL CHECK (agente IN ('openclaw', 'hermes', 'naia-claude')),
  nome           text NOT NULL CHECK (length(btrim(nome)) BETWEEN 2 AND 80),
  chave_id       uuid,
  chave_prefixo  text CHECK (chave_prefixo IS NULL OR chave_prefixo ~ '^erp_live_[0-9a-f]{8}$'),
  escopos        text[] NOT NULL DEFAULT '{}',
  estado         text NOT NULL DEFAULT 'sem_chave' CHECK (estado IN ('sem_chave', 'conectado', 'revogado')),
  vinculado_em   timestamptz,
  created_at     timestamptz NOT NULL DEFAULT now(),
  updated_at     timestamptz NOT NULL DEFAULT now(),
  deleted_at     timestamptz,
  PRIMARY KEY (id, tenant_id, workspace_id),
  FOREIGN KEY (workspace_id, tenant_id) REFERENCES workspaces (id, tenant_id),
  FOREIGN KEY (creator_id, tenant_id, workspace_id) REFERENCES usuarios (id, tenant_id, workspace_id),
  CHECK (estado <> 'conectado' OR (chave_id IS NOT NULL AND chave_prefixo IS NOT NULL))
);
CREATE UNIQUE INDEX IF NOT EXISTS integracoes_agentes_mcp_agente_uq
  ON integracoes_agentes_mcp (tenant_id, workspace_id, agente) WHERE deleted_at IS NULL;
SELECT nucleo_aplicar_padrao('integracoes_agentes_mcp');

GRANT SELECT, INSERT, UPDATE ON integracoes_credenciais, integracoes_agentes_mcp TO erp_app;
-- O worker processa o teste de conexao (job integracoes.testar_conector) e grava o resultado.
GRANT SELECT, UPDATE ON integracoes_credenciais TO erp_worker;
