-- M14.1 refeito: nenhum conector pede chave colada. Credencial de plataforma vem do cofre (env injetado por op run);
-- cada subconta guarda so os vinculos do proprio fluxo: profile e canais Zernio, conexao Maton, players habilitados.
-- Toda tabela: tenant_id e workspace_id do contexto, PK composta, RLS por nucleo_aplicar_padrao, exclusao logica. Idempotente.

-- State OAuth de uso unico (Zernio e Maton): so o hash fica gravado; expira em 15 min.
CREATE TABLE IF NOT EXISTS integracoes_oauth_estados (
  id            uuid NOT NULL DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL DEFAULT nucleo_tenant_atual(),
  workspace_id  uuid NOT NULL DEFAULT nucleo_workspace_atual(),
  creator_id    uuid,
  hash          text NOT NULL CHECK (hash ~ '^[0-9a-f]{64}$'),
  provedor      text NOT NULL CHECK (provedor IN ('zernio', 'maton')),
  plataforma    text NOT NULL CHECK (plataforma ~ '^[a-z0-9-]{2,40}$'),
  usuario_id    uuid,
  expira_em     timestamptz NOT NULL,
  usado_em      timestamptz,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now(),
  deleted_at    timestamptz,
  PRIMARY KEY (id, tenant_id, workspace_id),
  FOREIGN KEY (workspace_id, tenant_id) REFERENCES workspaces (id, tenant_id),
  FOREIGN KEY (creator_id, tenant_id, workspace_id) REFERENCES usuarios (id, tenant_id, workspace_id)
);
CREATE UNIQUE INDEX IF NOT EXISTS integracoes_oauth_estados_hash_uq ON integracoes_oauth_estados (hash);
SELECT nucleo_aplicar_padrao('integracoes_oauth_estados');

-- Um profile Zernio por subconta (Idempotency-Key estavel). profile_id unico no sistema.
CREATE TABLE IF NOT EXISTS integracoes_zernio_perfis (
  id            uuid NOT NULL DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL DEFAULT nucleo_tenant_atual(),
  workspace_id  uuid NOT NULL DEFAULT nucleo_workspace_atual(),
  creator_id    uuid,
  profile_id    text NOT NULL CHECK (profile_id ~ '^[A-Za-z0-9_-]{4,128}$'),
  nome          text NOT NULL CHECK (length(nome) BETWEEN 1 AND 200),
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now(),
  deleted_at    timestamptz,
  PRIMARY KEY (id, tenant_id, workspace_id),
  FOREIGN KEY (workspace_id, tenant_id) REFERENCES workspaces (id, tenant_id),
  FOREIGN KEY (creator_id, tenant_id, workspace_id) REFERENCES usuarios (id, tenant_id, workspace_id)
);
CREATE UNIQUE INDEX IF NOT EXISTS integracoes_zernio_perfis_escopo_uq ON integracoes_zernio_perfis (tenant_id, workspace_id) WHERE deleted_at IS NULL;
CREATE UNIQUE INDEX IF NOT EXISTS integracoes_zernio_perfis_profile_uq ON integracoes_zernio_perfis (profile_id) WHERE deleted_at IS NULL;
SELECT nucleo_aplicar_padrao('integracoes_zernio_perfis');

-- Canal conectado (conta WhatsApp ou Instagram na Zernio). conta_id e unico no sistema: a mesma conta
-- nunca fica ligada a duas subcontas (o indice vale acima da RLS).
CREATE TABLE IF NOT EXISTS integracoes_canais (
  id              uuid NOT NULL DEFAULT gen_random_uuid(),
  tenant_id       uuid NOT NULL DEFAULT nucleo_tenant_atual(),
  workspace_id    uuid NOT NULL DEFAULT nucleo_workspace_atual(),
  creator_id      uuid,
  canal           text NOT NULL CHECK (canal IN ('whatsapp', 'instagram')),
  provedor        text NOT NULL DEFAULT 'zernio' CHECK (provedor = 'zernio'),
  conta_id        text NOT NULL CHECK (conta_id ~ '^[A-Za-z0-9_-]{4,128}$'),
  profile_id      text NOT NULL,
  nome            text NOT NULL DEFAULT '',
  usuario         text NOT NULL DEFAULT '',
  estado          text NOT NULL DEFAULT 'ativo' CHECK (estado IN ('ativo', 'desconectado')),
  conectado_em    timestamptz NOT NULL DEFAULT now(),
  sincronizado_em timestamptz,
  importadas      integer NOT NULL DEFAULT 0,
  ultimo_erro     text,
  job_sync_id     uuid,
  created_at      timestamptz NOT NULL DEFAULT now(),
  updated_at      timestamptz NOT NULL DEFAULT now(),
  deleted_at      timestamptz,
  PRIMARY KEY (id, tenant_id, workspace_id),
  FOREIGN KEY (workspace_id, tenant_id) REFERENCES workspaces (id, tenant_id),
  FOREIGN KEY (creator_id, tenant_id, workspace_id) REFERENCES usuarios (id, tenant_id, workspace_id)
);
CREATE UNIQUE INDEX IF NOT EXISTS integracoes_canais_conta_uq ON integracoes_canais (conta_id) WHERE deleted_at IS NULL;
SELECT nucleo_aplicar_padrao('integracoes_canais');

-- Conversa da Zernio por contato: o envio de Conversas acha aqui o conversationId.
CREATE TABLE IF NOT EXISTS integracoes_zernio_conversas (
  id                  uuid NOT NULL DEFAULT gen_random_uuid(),
  tenant_id           uuid NOT NULL DEFAULT nucleo_tenant_atual(),
  workspace_id        uuid NOT NULL DEFAULT nucleo_workspace_atual(),
  creator_id          uuid,
  canal_id            uuid NOT NULL,
  canal               text NOT NULL CHECK (canal IN ('whatsapp', 'instagram')),
  conversa_externa_id text NOT NULL,
  contato             text NOT NULL,
  nome                text,
  ultima_mensagem_id  text,
  created_at          timestamptz NOT NULL DEFAULT now(),
  updated_at          timestamptz NOT NULL DEFAULT now(),
  deleted_at          timestamptz,
  PRIMARY KEY (id, tenant_id, workspace_id),
  FOREIGN KEY (workspace_id, tenant_id) REFERENCES workspaces (id, tenant_id),
  FOREIGN KEY (canal_id, tenant_id, workspace_id) REFERENCES integracoes_canais (id, tenant_id, workspace_id)
);
CREATE UNIQUE INDEX IF NOT EXISTS integracoes_zernio_conversas_uq ON integracoes_zernio_conversas (tenant_id, workspace_id, canal_id, conversa_externa_id);
CREATE INDEX IF NOT EXISTS integracoes_zernio_conversas_contato_idx ON integracoes_zernio_conversas (tenant_id, workspace_id, canal, contato);
SELECT nucleo_aplicar_padrao('integracoes_zernio_conversas');

-- Conexao Google Calendar via Maton (uma por subconta).
CREATE TABLE IF NOT EXISTS integracoes_google_conexoes (
  id              uuid NOT NULL DEFAULT gen_random_uuid(),
  tenant_id       uuid NOT NULL DEFAULT nucleo_tenant_atual(),
  workspace_id    uuid NOT NULL DEFAULT nucleo_workspace_atual(),
  creator_id      uuid,
  connection_id   text NOT NULL CHECK (connection_id ~ '^[A-Za-z0-9_-]{4,128}$'),
  estado          text NOT NULL DEFAULT 'pendente' CHECK (estado IN ('pendente', 'ativo', 'falhou', 'desconectado')),
  calendario      text NOT NULL DEFAULT 'primary',
  sincronizado_em timestamptz,
  atualizado_min  timestamptz,
  importados      integer NOT NULL DEFAULT 0,
  ultimo_erro     text,
  job_sync_id     uuid,
  created_at      timestamptz NOT NULL DEFAULT now(),
  updated_at      timestamptz NOT NULL DEFAULT now(),
  deleted_at      timestamptz,
  PRIMARY KEY (id, tenant_id, workspace_id),
  FOREIGN KEY (workspace_id, tenant_id) REFERENCES workspaces (id, tenant_id),
  FOREIGN KEY (creator_id, tenant_id, workspace_id) REFERENCES usuarios (id, tenant_id, workspace_id)
);
CREATE UNIQUE INDEX IF NOT EXISTS integracoes_google_conexoes_escopo_uq ON integracoes_google_conexoes (tenant_id, workspace_id) WHERE deleted_at IS NULL;
CREATE UNIQUE INDEX IF NOT EXISTS integracoes_google_conexoes_conn_uq ON integracoes_google_conexoes (connection_id) WHERE deleted_at IS NULL;
SELECT nucleo_aplicar_padrao('integracoes_google_conexoes');

-- Evento do Google criado a partir de um agendamento (saida): evita reimportar como bloqueio.
CREATE TABLE IF NOT EXISTS integracoes_google_eventos (
  id               uuid NOT NULL DEFAULT gen_random_uuid(),
  tenant_id        uuid NOT NULL DEFAULT nucleo_tenant_atual(),
  workspace_id     uuid NOT NULL DEFAULT nucleo_workspace_atual(),
  creator_id       uuid,
  compromisso_id   uuid NOT NULL,
  google_evento_id text NOT NULL,
  created_at       timestamptz NOT NULL DEFAULT now(),
  updated_at       timestamptz NOT NULL DEFAULT now(),
  deleted_at       timestamptz,
  PRIMARY KEY (id, tenant_id, workspace_id),
  FOREIGN KEY (workspace_id, tenant_id) REFERENCES workspaces (id, tenant_id)
);
CREATE UNIQUE INDEX IF NOT EXISTS integracoes_google_eventos_uq ON integracoes_google_eventos (tenant_id, workspace_id, compromisso_id);
CREATE INDEX IF NOT EXISTS integracoes_google_eventos_ext_idx ON integracoes_google_eventos (tenant_id, workspace_id, google_evento_id);
SELECT nucleo_aplicar_padrao('integracoes_google_eventos');

-- Players de video habilitados (sem credencial).
CREATE TABLE IF NOT EXISTS integracoes_players (
  id            uuid NOT NULL DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL DEFAULT nucleo_tenant_atual(),
  workspace_id  uuid NOT NULL DEFAULT nucleo_workspace_atual(),
  creator_id    uuid,
  provedor      text NOT NULL CHECK (provedor IN ('youtube', 'vimeo', 'panda', 'bunny')),
  habilitado    boolean NOT NULL DEFAULT false,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now(),
  deleted_at    timestamptz,
  PRIMARY KEY (id, tenant_id, workspace_id),
  FOREIGN KEY (workspace_id, tenant_id) REFERENCES workspaces (id, tenant_id),
  FOREIGN KEY (creator_id, tenant_id, workspace_id) REFERENCES usuarios (id, tenant_id, workspace_id)
);
CREATE UNIQUE INDEX IF NOT EXISTS integracoes_players_uq ON integracoes_players (tenant_id, workspace_id, provedor);
SELECT nucleo_aplicar_padrao('integracoes_players');

-- Webhook da Zernio (sem sessao): resolve a conta para a subconta dona. Revisado pelo integrador;
-- devolve so o necessario e so canal ativo de tenant ativo.
CREATE OR REPLACE FUNCTION integracoes_zernio_resolver(p_conta text)
RETURNS TABLE (tenant_id uuid, workspace_id uuid, canal_id uuid, canal text, profile_id text)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public, pg_temp AS $$
  SELECT c.tenant_id, c.workspace_id, c.id, c.canal, c.profile_id
  FROM integracoes_canais c JOIN tenants t ON t.id = c.tenant_id
  WHERE c.conta_id = p_conta AND c.estado = 'ativo' AND c.deleted_at IS NULL
    AND t.estado = 'ativo' AND t.deleted_at IS NULL
$$;
REVOKE ALL ON FUNCTION integracoes_zernio_resolver(text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION integracoes_zernio_resolver(text) TO erp_app;

GRANT SELECT, INSERT, UPDATE ON integracoes_oauth_estados, integracoes_zernio_perfis, integracoes_canais,
  integracoes_zernio_conversas, integracoes_google_conexoes, integracoes_google_eventos, integracoes_players TO erp_app;
GRANT SELECT, INSERT, UPDATE ON integracoes_canais, integracoes_zernio_conversas, integracoes_google_conexoes,
  integracoes_google_eventos TO erp_worker;
GRANT SELECT ON integracoes_zernio_perfis, integracoes_players TO erp_worker;
-- O worker liga e desliga o conector conforme os vinculos (CONTRATOS 2.2: UPDATE de estado).
GRANT UPDATE (estado, updated_at) ON conectores TO erp_worker;
