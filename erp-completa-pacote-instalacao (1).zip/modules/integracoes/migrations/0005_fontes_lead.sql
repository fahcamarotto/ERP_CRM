-- Fontes de lead (varias landing pages por subconta): cada fonte tem nome, URL propria (token), segredo proprio
-- (cifra do nucleo), pipeline e etapa de destino, tags aplicadas ao cliente, responsavel e ativa/pausada.
-- A URL unica antiga vira a fonte "Landing page padrao" (mesmo token e mesmo segredo do conector webhook-landing),
-- destino pipeline padrao na primeira etapa. Toda tabela com tenant_id e workspace_id do contexto, PK composta e RLS.
-- Idempotente.

CREATE TABLE IF NOT EXISTS integracoes_fontes_lead (
  id              uuid NOT NULL DEFAULT gen_random_uuid(),
  tenant_id       uuid NOT NULL DEFAULT nucleo_tenant_atual(),
  workspace_id    uuid NOT NULL DEFAULT nucleo_workspace_atual(),
  creator_id      uuid,
  nome            text NOT NULL CHECK (length(btrim(nome)) BETWEEN 2 AND 80),
  token           text NOT NULL DEFAULT encode(gen_random_bytes(18), 'hex') CHECK (token ~ '^[a-f0-9]{36}$'),
  -- Fonte padrao usa o segredo do conector webhook-landing (segredo_ref nulo); as demais guardam a propria cifra.
  segredo_ref     text,
  padrao          boolean NOT NULL DEFAULT false,
  funil_id        uuid,
  etapa_id        uuid,
  tags            text[] NOT NULL DEFAULT '{}' CHECK (cardinality(tags) <= 20),
  responsavel_id  uuid,
  estado          text NOT NULL DEFAULT 'ativa' CHECK (estado IN ('ativa', 'pausada')),
  aviso           text,
  aviso_em        timestamptz,
  created_at      timestamptz NOT NULL DEFAULT now(),
  updated_at      timestamptz NOT NULL DEFAULT now(),
  deleted_at      timestamptz,
  PRIMARY KEY (id, tenant_id, workspace_id),
  CHECK (etapa_id IS NULL OR funil_id IS NOT NULL),
  FOREIGN KEY (workspace_id, tenant_id) REFERENCES workspaces (id, tenant_id),
  FOREIGN KEY (creator_id, tenant_id, workspace_id) REFERENCES usuarios (id, tenant_id, workspace_id),
  FOREIGN KEY (responsavel_id, tenant_id, workspace_id) REFERENCES usuarios (id, tenant_id, workspace_id)
);
-- O token e a URL publica: unico no sistema inteiro (o resolver nao tem sessao).
CREATE UNIQUE INDEX IF NOT EXISTS integracoes_fontes_lead_token_uq ON integracoes_fontes_lead (token);
CREATE UNIQUE INDEX IF NOT EXISTS integracoes_fontes_lead_nome_uq ON integracoes_fontes_lead (tenant_id, workspace_id, lower(nome)) WHERE deleted_at IS NULL;
CREATE UNIQUE INDEX IF NOT EXISTS integracoes_fontes_lead_padrao_uq ON integracoes_fontes_lead (tenant_id, workspace_id) WHERE padrao AND deleted_at IS NULL;
SELECT nucleo_aplicar_padrao('integracoes_fontes_lead');

-- Cada envio recebido sabe de qual fonte veio (contador e ultimos recebidos por fonte).
ALTER TABLE integracoes_eventos_recebidos ADD COLUMN IF NOT EXISTS fonte_id uuid;
CREATE INDEX IF NOT EXISTS integracoes_eventos_recebidos_fonte_idx ON integracoes_eventos_recebidos (tenant_id, workspace_id, fonte_id, created_at DESC) WHERE fonte_id IS NOT NULL;

-- Fonte padrao em toda subconta que ja tem o conector webhook-landing (a URL antiga continua valendo).
-- Subconta futura: a fonte padrao nasce na primeira leitura das fontes ou no primeiro lead pela URL antiga.
INSERT INTO integracoes_fontes_lead (tenant_id, workspace_id, nome, token, padrao)
SELECT c.tenant_id, c.workspace_id, 'Landing page padrão', c.token_entrada, true
FROM conectores c
WHERE c.slug = 'webhook-landing' AND c.deleted_at IS NULL
  AND NOT EXISTS (SELECT 1 FROM integracoes_fontes_lead f WHERE f.tenant_id = c.tenant_id AND f.workspace_id = c.workspace_id AND f.padrao AND f.deleted_at IS NULL)
  AND NOT EXISTS (SELECT 1 FROM integracoes_fontes_lead f WHERE f.token = c.token_entrada);

-- Envios antigos da URL unica passam a contar na fonte padrao.
UPDATE integracoes_eventos_recebidos e SET fonte_id = f.id
FROM integracoes_fontes_lead f
WHERE e.fonte_id IS NULL AND e.conector = 'webhook-landing' AND f.padrao AND f.deleted_at IS NULL
  AND f.tenant_id = e.tenant_id AND f.workspace_id = e.workspace_id;

-- Resolve o token publico de uma fonte (sem sessao). Fonte padrao herda segredo e desligamento do conector.
CREATE OR REPLACE FUNCTION integracoes_fonte_lead_resolver(p_token text)
RETURNS TABLE (tenant_id uuid, workspace_id uuid, fonte_id uuid, padrao boolean, segredo_ref text, estado text)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public, pg_temp AS $$
  SELECT f.tenant_id, f.workspace_id, f.id, f.padrao,
         CASE WHEN f.padrao THEN c.segredo_entrada_ref ELSE f.segredo_ref END,
         CASE WHEN f.estado = 'pausada' THEN 'pausada' WHEN f.padrao AND c.estado = 'desligado' THEN 'desligado' ELSE 'ativa' END
  FROM integracoes_fontes_lead f
  JOIN tenants t ON t.id = f.tenant_id
  LEFT JOIN conectores c ON c.tenant_id = f.tenant_id AND c.workspace_id = f.workspace_id AND c.slug = 'webhook-landing' AND c.deleted_at IS NULL
  WHERE f.token = p_token AND f.deleted_at IS NULL AND t.estado = 'ativo' AND t.deleted_at IS NULL
$$;
REVOKE ALL ON FUNCTION integracoes_fonte_lead_resolver(text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION integracoes_fonte_lead_resolver(text) TO erp_app;

GRANT SELECT, INSERT, UPDATE ON integracoes_fontes_lead TO erp_app;
-- Worker: Cadastros le a fonte do lead (interface publicada) e Integracoes grava o aviso de destino substituido.
GRANT SELECT ON integracoes_fontes_lead TO erp_worker;
GRANT UPDATE (aviso, aviso_em, updated_at) ON integracoes_fontes_lead TO erp_worker;
