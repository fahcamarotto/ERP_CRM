-- Google Agenda via Maton com a chave de API da PROPRIA subconta (integracoes_credenciais, conector google-calendar,
-- so a cifra cifra:v1 e os 4 ultimos caracteres). Idempotente.

-- Duas subcontas do mesmo dono podem usar a mesma conta do Maton: o connection_id deixa de ser unico global
-- e passa a ser unico dentro da subconta.
DROP INDEX IF EXISTS integracoes_google_conexoes_conn_uq;
CREATE UNIQUE INDEX IF NOT EXISTS integracoes_google_conexoes_conn_escopo_uq
  ON integracoes_google_conexoes (tenant_id, workspace_id, connection_id) WHERE deleted_at IS NULL;

-- Regra unica para toda subconta: conexao viva sem chave do Maton da propria subconta (criada pela chave de
-- plataforma antiga) para de sincronizar; o dono cola a chave dele no menu Agenda e escolhe a agenda.
UPDATE integracoes_google_conexoes g SET estado = 'desconectado', job_sync_id = NULL,
       ultimo_erro = 'Cole a chave de API do Maton da subconta no menu Agenda'
 WHERE g.deleted_at IS NULL AND g.estado <> 'desconectado'
   AND NOT EXISTS (SELECT 1 FROM integracoes_credenciais k
                    WHERE k.tenant_id = g.tenant_id AND k.workspace_id = g.workspace_id
                      AND k.conector = 'google-calendar' AND k.deleted_at IS NULL);

-- O worker marca a chave como invalida quando o Maton recusa durante a sincronizacao (UPDATE ja concedido em 0001).
GRANT SELECT, UPDATE ON integracoes_credenciais TO erp_worker;
