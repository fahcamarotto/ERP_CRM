/** Rotas REST das Equipes de venda (M2.4). */
import { esquemaErro, requer, type FastifyInstance } from '@erp/api/sdk';
import { naTransacao } from '../borda.ts';
import { exigirOk } from '../compartilhado/result.ts';
import { propsEquipe, uuid } from '../esquemas.ts';
import type { DadosEquipe } from './model/equipe.ts';
import { listarEquipes } from './query/equipes.ts';

const tags = ['pipeline'];
const erros = { 400: esquemaErro, 404: esquemaErro, 409: esquemaErro };
const paramId = { type: 'object', required: ['id'], properties: { id: uuid } } as const;

export function rotasEquipe(app: FastifyInstance): void {
  app.get('/equipes', {
    preHandler: requer('pipeline.ver'),
    schema: { tags, summary: 'Equipes com lider, membros e desempenho' },
  }, (req) => naTransacao(req, (_, __, c) => listarEquipes(c)));

  app.post<{ Body: DadosEquipe }>('/equipes', {
    preHandler: requer('pipeline.criar'),
    schema: { tags, summary: 'Cria equipe de vendas (CriarEquipe)', body: { type: 'object', additionalProperties: false, required: ['nome'], properties: propsEquipe }, response: erros },
  }, async (req, reply) => reply.code(201).send(await naTransacao(req, async (casos, ctx) => exigirOk(await casos.criarEquipe.execute(ctx, req.body)))));

  app.patch<{ Params: { id: string }; Body: Partial<DadosEquipe> }>('/equipes/:id', {
    preHandler: requer('pipeline.editar'),
    schema: { tags, summary: 'Edita equipe e membros (EditarEquipe)', params: paramId, body: { type: 'object', additionalProperties: false, properties: propsEquipe }, response: erros },
  }, async (req, reply) => {
    await naTransacao(req, async (casos, ctx) => exigirOk(await casos.editarEquipe.execute(ctx, { ...req.body, id: req.params.id })));
    return reply.code(204).send();
  });

  app.delete<{ Params: { id: string } }>('/equipes/:id', {
    preHandler: requer('pipeline.excluir'),
    schema: { tags, summary: 'Exclui equipe sem oportunidade aberta nem meta (ExcluirEquipe)', params: paramId, response: erros },
  }, async (req, reply) => {
    await naTransacao(req, async (casos, ctx) => exigirOk(await casos.excluirEquipe.execute(ctx, { id: req.params.id })));
    return reply.code(204).send();
  });
}
