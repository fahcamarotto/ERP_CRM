/** Adaptador Postgres das portas de Equipe; membros sincronizados na tabela de ligacao. */
import type pg from 'pg';
import { Equipe, type EquipeDados } from '../model/equipe.ts';
import type { ConsultarReferenciasEquipe, GravarEquipe, ObterEquipe } from '../model/portas.ts';

const SELECAO = `SELECT e.id, e.nome, e.lider_id, e.cor,
  coalesce((SELECT array_agg(m.usuario_id) FROM pipeline_equipe_membros m WHERE m.equipe_id = e.id AND m.deleted_at IS NULL), '{}') AS membro_ids
  FROM pipeline_equipes e`;

export class EquipeRepoPg implements ObterEquipe, GravarEquipe, ConsultarReferenciasEquipe {
  constructor(private readonly c: pg.PoolClient) {}

  async obterPorId(id: string) {
    const r = await this.c.query(`${SELECAO} WHERE e.id = $1 AND e.deleted_at IS NULL`, [id]);
    return r.rows[0] ? Equipe.reidratar(r.rows[0] as EquipeDados) : null;
  }

  async buscarPorNome(nome: string) {
    const r = await this.c.query(`${SELECAO} WHERE lower(e.nome) = lower($1) AND e.deleted_at IS NULL`, [nome]);
    return r.rows[0] ? Equipe.reidratar(r.rows[0] as EquipeDados) : null;
  }

  async inserir(e: Equipe) {
    const d = e.paraDados();
    await this.c.query('INSERT INTO pipeline_equipes (id, nome, lider_id, cor, creator_id) VALUES ($1, $2, $3, $4, nucleo_usuario_atual())', [d.id, d.nome, d.lider_id, d.cor]);
    await this.sincronizarMembros(d.id, d.membro_ids);
  }

  async atualizar(e: Equipe) {
    const d = e.paraDados();
    await this.c.query('UPDATE pipeline_equipes SET nome = $2, lider_id = $3, cor = $4 WHERE id = $1 AND deleted_at IS NULL', [d.id, d.nome, d.lider_id, d.cor]);
    await this.sincronizarMembros(d.id, d.membro_ids);
  }

  async excluir(id: string) {
    await this.c.query('UPDATE pipeline_equipe_membros SET deleted_at = now() WHERE equipe_id = $1 AND deleted_at IS NULL', [id]);
    await this.c.query('UPDATE pipeline_equipes SET deleted_at = now() WHERE id = $1 AND deleted_at IS NULL', [id]);
  }

  private async sincronizarMembros(equipeId: string, ids: string[]) {
    await this.c.query(
      'UPDATE pipeline_equipe_membros SET deleted_at = now() WHERE equipe_id = $1 AND deleted_at IS NULL AND NOT (usuario_id = ANY ($2::uuid[]))',
      [equipeId, ids],
    );
    if (!ids.length) return;
    await this.c.query(
      `INSERT INTO pipeline_equipe_membros (equipe_id, usuario_id, creator_id) SELECT $1, u, nucleo_usuario_atual() FROM unnest($2::uuid[]) u
       ON CONFLICT (tenant_id, workspace_id, equipe_id, usuario_id) DO UPDATE SET deleted_at = NULL`,
      [equipeId, ids],
    );
  }

  async usuariosExistentes(ids: string[]) {
    const r = await this.c.query('SELECT id FROM usuarios WHERE id = ANY ($1::uuid[]) AND deleted_at IS NULL', [ids]);
    return r.rows.map((x) => x.id as string);
  }

  async emUso(id: string) {
    const r = await this.c.query(
      `SELECT (SELECT count(*) FROM pipeline_oportunidades WHERE equipe_id = $1 AND estado = 'aberta' AND deleted_at IS NULL)
            + (SELECT count(*) FROM pipeline_metas WHERE equipe_id = $1 AND deleted_at IS NULL) AS n`,
      [id],
    );
    return Number(r.rows[0].n);
  }
}
