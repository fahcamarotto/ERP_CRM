/** Consulta das Equipes com lider, membros e desempenho (abertas, ganhas no mes, valor em negociacao). */
import type pg from 'pg';

export async function listarEquipes(c: pg.PoolClient) {
  const r = await c.query(
    `SELECT e.id, e.nome, e.lider_id, l.nome AS lider_nome, e.cor, e.created_at, e.updated_at,
       coalesce((SELECT json_agg(json_build_object('id', u.id, 'nome', u.nome) ORDER BY u.nome) FROM pipeline_equipe_membros m
                 JOIN usuarios u ON u.id = m.usuario_id WHERE m.equipe_id = e.id AND m.deleted_at IS NULL), '[]') AS membros,
       (SELECT count(*)::int FROM pipeline_oportunidades o WHERE o.equipe_id = e.id AND o.estado = 'aberta' AND o.deleted_at IS NULL) AS abertas,
       (SELECT coalesce(sum(o.valor), 0)::float8 FROM pipeline_oportunidades o WHERE o.equipe_id = e.id AND o.estado = 'aberta' AND o.deleted_at IS NULL) AS valor_em_negociacao,
       (SELECT coalesce(sum(o.valor), 0)::float8 FROM pipeline_oportunidades o WHERE o.equipe_id = e.id AND o.estado = 'ganha' AND o.deleted_at IS NULL
          AND o.fechada_em >= date_trunc('month', now())) AS ganho_no_mes
     FROM pipeline_equipes e LEFT JOIN usuarios l ON l.id = e.lider_id
     WHERE e.deleted_at IS NULL ORDER BY lower(e.nome)`,
  );
  return r.rows;
}
