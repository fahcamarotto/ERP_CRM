/** Entidade Equipe de vendas (M2.4): nome, lider, cor por token e membros (usuarios do workspace). Imutavel. */
import { randomUUID } from 'node:crypto';
import { erroDe, fail, ok, type ErroDominio, type Result } from '../../compartilhado/result.ts';
import { CORES, type Cor } from '../../etapa/model/etapa.ts';

export interface DadosEquipe {
  nome: string;
  lider_id?: string | null;
  cor?: Cor;
  membro_ids?: string[];
}

export interface EquipeDados {
  id: string;
  nome: string;
  lider_id: string | null;
  cor: Cor;
  membro_ids: string[];
}

function validar(d: EquipeDados): ErroDominio[] {
  const e: ErroDominio[] = [];
  if (d.nome.length < 2 || d.nome.length > 80) e.push(erroDe('nome_invalido', 'Nome deve ter de 2 a 80 caracteres', 'nome'));
  if (!CORES.includes(d.cor)) e.push(erroDe('cor_invalida', `Cor deve ser um token: ${CORES.join(', ')}`, 'cor'));
  if (d.membro_ids.length > 200) e.push(erroDe('membros_invalidos', 'No maximo 200 membros', 'membro_ids'));
  return e;
}

/** O lider sempre entra como membro. */
const membros = (lider: string | null, ids: string[]) => [...new Set([...(lider ? [lider] : []), ...ids])];

export class Equipe {
  private constructor(private readonly d: EquipeDados) {}

  static tryCreate(e: DadosEquipe, id: string = randomUUID()): Result<Equipe> {
    const lider = (e.lider_id ?? '').trim() || null;
    const d: EquipeDados = { id, nome: (e.nome ?? '').trim(), lider_id: lider, cor: e.cor ?? 'azul', membro_ids: membros(lider, e.membro_ids ?? []) };
    const erros = validar(d);
    return erros.length ? fail(...erros) : ok(new Equipe(d));
  }

  static create(e: DadosEquipe, id?: string): Equipe {
    const r = Equipe.tryCreate(e, id);
    if (!r.ok) throw new Error(r.erros.map((x) => x.mensagem).join('; '));
    return r.valor;
  }

  static reidratar(d: EquipeDados): Equipe {
    return new Equipe({ ...d, membro_ids: [...d.membro_ids] });
  }

  get id(): string { return this.d.id; }

  editar(e: Partial<DadosEquipe>): Result<Equipe> {
    const lider = e.lider_id !== undefined ? (e.lider_id ?? '').trim() || null : this.d.lider_id;
    const n: EquipeDados = {
      ...this.d,
      nome: e.nome !== undefined ? e.nome.trim() : this.d.nome,
      lider_id: lider,
      cor: e.cor ?? this.d.cor,
      membro_ids: membros(lider, e.membro_ids ?? this.d.membro_ids),
    };
    const erros = validar(n);
    return erros.length ? fail(...erros) : ok(new Equipe(n));
  }

  paraDados(): EquipeDados {
    return { ...this.d, membro_ids: [...this.d.membro_ids] };
  }
}
