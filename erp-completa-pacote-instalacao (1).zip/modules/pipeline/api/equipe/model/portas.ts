/** Portas do repositorio de Equipes. */
import type { Equipe } from './equipe.ts';

export interface ObterEquipe {
  obterPorId(id: string): Promise<Equipe | null>;
  buscarPorNome(nome: string): Promise<Equipe | null>;
}

export interface GravarEquipe {
  inserir(e: Equipe): Promise<void>;
  atualizar(e: Equipe): Promise<void>;
  excluir(id: string): Promise<void>;
}

export interface ConsultarReferenciasEquipe {
  usuariosExistentes(ids: string[]): Promise<string[]>;
  /** Oportunidades abertas e metas vivas ligadas a equipe. */
  emUso(id: string): Promise<number>;
}
