/** Casos de uso de Equipes (M2.4): criar, editar e excluir (bloqueado com oportunidade aberta ou meta). */
import { erroDe, fail, ok, okVazio, type ErroDominio, type Result } from '../../compartilhado/result.ts';
import type { ContextoCaso } from '../../compartilhado/efeitos.ts';
import { Equipe, type DadosEquipe } from '../model/equipe.ts';
import type { ConsultarReferenciasEquipe, GravarEquipe, ObterEquipe } from '../model/portas.ts';

const TABELA = 'pipeline_equipes';
type Deps = { repo: ObterEquipe & GravarEquipe; refs: ConsultarReferenciasEquipe };

async function conferir(deps: Deps, e: Equipe): Promise<ErroDominio[]> {
  const d = e.paraDados();
  const erros: ErroDominio[] = [];
  const mesmo = await deps.repo.buscarPorNome(d.nome);
  if (mesmo && mesmo.id !== d.id) erros.push(erroDe('conflito', 'Ja existe equipe com este nome', 'nome'));
  if (d.membro_ids.length) {
    const vivos = new Set(await deps.refs.usuariosExistentes(d.membro_ids));
    const faltam = d.membro_ids.filter((u) => !vivos.has(u));
    if (faltam.length) erros.push(erroDe('usuario_invalido', 'Lider ou membro nao encontrado', 'membro_ids', { faltam }));
  }
  return erros;
}

export class CriarEquipe {
  constructor(private readonly deps: Deps) {}
  async execute(ctx: ContextoCaso, e: DadosEquipe): Promise<Result<{ id: string }>> {
    const r = Equipe.tryCreate(e);
    if (!r.ok) return r;
    const erros = await conferir(this.deps, r.valor);
    if (erros.length) return fail(...erros);
    await this.deps.repo.inserir(r.valor);
    const d = r.valor.paraDados();
    await ctx.efeitos.auditar('equipe.criar', TABELA, d.id, undefined, d);
    return ok({ id: d.id });
  }
}

export class EditarEquipe {
  constructor(private readonly deps: Deps) {}
  async execute(ctx: ContextoCaso, e: { id: string } & Partial<DadosEquipe>): Promise<Result<void>> {
    const atual = await this.deps.repo.obterPorId(e.id);
    if (!atual) return fail(erroDe('nao_encontrado', 'Equipe nao encontrada'));
    const r = atual.editar(e);
    if (!r.ok) return r;
    const erros = await conferir(this.deps, r.valor);
    if (erros.length) return fail(...erros);
    await this.deps.repo.atualizar(r.valor);
    const antes = atual.paraDados() as unknown as Record<string, unknown>;
    const depois = r.valor.paraDados() as unknown as Record<string, unknown>;
    await ctx.efeitos.historico(TABELA, e.id, antes, depois);
    await ctx.efeitos.auditar('equipe.editar', TABELA, e.id, antes, depois);
    return okVazio();
  }
}

export class ExcluirEquipe {
  constructor(private readonly deps: Deps) {}
  async execute(ctx: ContextoCaso, e: { id: string }): Promise<Result<void>> {
    const atual = await this.deps.repo.obterPorId(e.id);
    if (!atual) return fail(erroDe('nao_encontrado', 'Equipe nao encontrada'));
    const uso = await this.deps.refs.emUso(e.id);
    if (uso > 0) return fail(erroDe('conflito', `Equipe com ${uso} oportunidade(s) aberta(s) ou meta(s): remova antes de excluir`, undefined, { em_uso: uso }));
    await this.deps.repo.excluir(e.id);
    await ctx.efeitos.auditar('equipe.excluir', TABELA, e.id, atual.paraDados());
    return okVazio();
  }
}
