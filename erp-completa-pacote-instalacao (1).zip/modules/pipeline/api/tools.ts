/**
 * @tool do modulo (N15): cada chamada vira tool MCP em /mcp e rota REST com o mesmo schema no OpenAPI.
 * Tools de M2.7: oportunidades.listar, oportunidade.criar, oportunidade.mover; mais oportunidade.obter,
 * oportunidade.ganhar, oportunidade.perder, pipeline.metricas, etapas.listar, atividades.listar,
 * atividade.agendar e atividade.concluir; varios pipelines: funis.listar, funil.criar, funil.renomear, funil.arquivar
 * e etapas.reordenar. Sem funil_id, toda tool usa o pipeline padrao do workspace.
 */
import { tool } from '@erp/api/sdk';
import { naoEncontrado } from './borda.ts';
import { contextoPg } from './compartilhado/efeitos-pg.ts';
import { exigirOk } from './compartilhado/result.ts';
import type { DadosAtividade } from './atividade/model/atividade.ts';
import { listarAtividades, obterAtividade, type FiltroAtividades } from './atividade/query/atividades.ts';
import { estadosAtividade, estadosOportunidade, paginacao, propsAtividade, propsFunil, propsOportunidade, uuid } from './esquemas.ts';
import { listarEtapas } from './etapa/query/etapas.ts';
import { casosDeUso } from './fabrica.ts';
import { listarFunis, obterFunil } from './funil/query/funis.ts';
import type { EntradaCriarOportunidade } from './oportunidade/use-case/criar-oportunidade.ts';
import { listarOportunidades, metricasPipeline, obterOportunidade, type FiltroOportunidades } from './oportunidade/query/oportunidades.ts';

const M = 'pipeline';
const ficha = async (c: Parameters<typeof obterOportunidade>[0], id: string) => (await obterOportunidade(c, id)) ?? Promise.reject(naoEncontrado('Oportunidade nao encontrada'));

tool<FiltroOportunidades>({
  nome: 'oportunidades.listar', modulo: M, titulo: 'Listar oportunidades', tipo: 'leitura', permissao: 'pipeline.ver',
  descricao: 'Lista oportunidades com cliente, valor, pipeline, etapa, probabilidade, responsavel e equipe; filtra por pipeline (funil_id), estado (aberta, ganha, perdida), etapa, cliente, responsavel, equipe ou busca no titulo.',
  entrada: { type: 'object', properties: { ...paginacao, funil_id: uuid, estado: { type: 'string', enum: [...estadosOportunidade] }, etapa_id: uuid, parceiro_id: uuid, responsavel_id: uuid, equipe_id: uuid } },
  rota: { metodo: 'GET', caminho: '/api/v1/pipeline/oportunidades' },
  executar: ({ c }, a) => listarOportunidades(c, a),
});

tool<{ id: string }>({
  nome: 'oportunidade.obter', modulo: M, titulo: 'Obter oportunidade', tipo: 'leitura', permissao: 'pipeline.ver',
  descricao: 'Ficha da oportunidade pelo id: dados, UTM, motivo de perda, projeto ligado e historico de movimentos entre etapas.',
  entrada: { type: 'object', required: ['id'], properties: { id: uuid } },
  rota: { metodo: 'GET', caminho: '/api/v1/pipeline/oportunidades/:id' },
  executar: ({ c }, a) => ficha(c, a.id),
});

tool<EntradaCriarOportunidade>({
  nome: 'oportunidade.criar', modulo: M, titulo: 'Criar oportunidade', tipo: 'escrita', permissao: 'pipeline.criar',
  descricao: 'Abre oportunidade aberta na etapa informada ou na primeira etapa do pipeline informado (funil_id; padrao: o pipeline padrao), com cliente, valor, responsavel, origem, canal e UTM. Publica oportunidade.criada.',
  entrada: { type: 'object', required: ['titulo'], properties: { ...propsOportunidade, funil_id: uuid, etapa_id: uuid } },
  rota: { metodo: 'POST', caminho: '/api/v1/pipeline/oportunidades' },
  executar: async ({ c, ator, ip }, a) => {
    const { id } = exigirOk(await casosDeUso(c).criarOportunidade.execute(contextoPg(c, ator, ip), a));
    return ficha(c, id);
  },
});

tool<{ id: string; etapa_id: string }>({
  nome: 'oportunidade.mover', modulo: M, titulo: 'Mover oportunidade de etapa', tipo: 'escrita', permissao: 'pipeline.editar',
  descricao: 'Move oportunidade aberta para outra etapa aberta (a probabilidade passa a ser a da etapa). Etapa de outro pipeline ativo leva a oportunidade para aquele pipeline. Para ganho ou perda use oportunidade.ganhar ou oportunidade.perder. Publica oportunidade.movida.',
  entrada: { type: 'object', required: ['id', 'etapa_id'], properties: { id: uuid, etapa_id: uuid } },
  rota: { metodo: 'POST', caminho: '/api/v1/pipeline/oportunidades/:id/mover' },
  executar: async ({ c, ator, ip }, a) => {
    exigirOk(await casosDeUso(c).moverEtapa.execute(contextoPg(c, ator, ip), a));
    return ficha(c, a.id);
  },
});

tool<{ id: string; converter_em_projeto?: boolean }>({
  nome: 'oportunidade.ganhar', modulo: M, titulo: 'Marcar oportunidade como ganha', tipo: 'escrita', permissao: 'pipeline.editar',
  descricao: 'Fecha a oportunidade como ganha (etapa de ganho, probabilidade 100). Publica oportunidade.ganha com converter_em_projeto; o projeto e criado por projetos.criar do Cadastros e ligado em /oportunidades/:id/projeto.',
  entrada: { type: 'object', required: ['id'], properties: { id: uuid, converter_em_projeto: { type: 'boolean' } } },
  rota: { metodo: 'POST', caminho: '/api/v1/pipeline/oportunidades/:id/ganhar' },
  executar: async ({ c, ator, ip }, a) => {
    exigirOk(await casosDeUso(c).marcarGanha.execute(contextoPg(c, ator, ip), a));
    return ficha(c, a.id);
  },
});

tool<{ id: string; motivo_perda_id: string; motivo_perda_detalhe?: string | null }>({
  nome: 'oportunidade.perder', modulo: M, titulo: 'Marcar oportunidade como perdida', tipo: 'escrita', permissao: 'pipeline.editar',
  descricao: 'Fecha a oportunidade como perdida. Motivo de perda obrigatorio (id de um motivo ativo, ver aba Motivos de perda). Publica oportunidade.perdida.',
  entrada: { type: 'object', required: ['id', 'motivo_perda_id'], properties: { id: uuid, motivo_perda_id: uuid, motivo_perda_detalhe: { type: ['string', 'null'], maxLength: 2000 } } },
  rota: { metodo: 'POST', caminho: '/api/v1/pipeline/oportunidades/:id/perder' },
  executar: async ({ c, ator, ip }, a) => {
    exigirOk(await casosDeUso(c).marcarPerdida.execute(contextoPg(c, ator, ip), a));
    return ficha(c, a.id);
  },
});

tool<{ responsavel_id?: string; equipe_id?: string; funil_id?: string }>({
  nome: 'pipeline.metricas', modulo: M, titulo: 'Metricas do pipeline', tipo: 'leitura', permissao: 'pipeline.ver',
  descricao: 'Valor em negociacao, valor ponderado, abertas, ganhas, perdidas, taxa de ganho, ciclo medio em dias e conversao por etapa; filtra por pipeline (funil_id; sem ele os totais somam todos os pipelines e a conversao e do padrao), responsavel ou equipe.',
  entrada: { type: 'object', properties: { responsavel_id: uuid, equipe_id: uuid, funil_id: uuid } },
  rota: { metodo: 'GET', caminho: '/api/v1/pipeline/metricas' },
  executar: ({ c }, a) => metricasPipeline(c, a),
});

tool<{ funil_id?: string }>({
  nome: 'etapas.listar', modulo: M, titulo: 'Listar etapas do pipeline', tipo: 'leitura', permissao: 'pipeline.ver',
  descricao: 'Etapas de um pipeline (funil_id; padrao: o pipeline padrao) na ordem, com tipo (aberta, ganho, perdido), probabilidade, quantidade e valor das oportunidades em cada uma. Workspace sem pipeline recebe o padrao (novo, contato, proposta, negociacao, ganho, perdido).',
  entrada: { type: 'object', properties: { funil_id: uuid } },
  rota: { metodo: 'GET', caminho: '/api/v1/pipeline/etapas' },
  executar: async ({ c, ator, ip }, a) => {
    const f = exigirOk(await casosDeUso(c).resolverFunil.execute(contextoPg(c, ator, ip), a.funil_id ?? null));
    return listarEtapas(c, f.id);
  },
});

tool<{ funil_id?: string; etapa_ids: string[] }>({
  nome: 'etapas.reordenar', modulo: M, titulo: 'Reordenar etapas do pipeline', tipo: 'escrita', permissao: 'pipeline.editar',
  descricao: 'Grava a nova ordem das colunas de um pipeline (funil_id; padrao: o pipeline padrao). etapa_ids traz TODAS as etapas do pipeline na ordem desejada; lista incompleta ou com etapa de outro pipeline e recusada. Transacional e auditado; vale para todos os usuarios da subconta.',
  entrada: { type: 'object', required: ['etapa_ids'], properties: { funil_id: uuid, etapa_ids: { type: 'array', items: uuid, minItems: 1, maxItems: 99 } } },
  rota: { metodo: 'POST', caminho: '/api/v1/pipeline/etapas/reordenar' },
  executar: async ({ c, ator, ip }, a) => {
    const ctx = contextoPg(c, ator, ip);
    const casos = casosDeUso(c);
    const f = exigirOk(await casos.resolverFunil.execute(ctx, a.funil_id ?? null));
    exigirOk(await casos.reordenarEtapas.execute(ctx, { funil_id: f.id, etapa_ids: a.etapa_ids }));
    return listarEtapas(c, f.id);
  },
});

const fichaFunil = async (c: Parameters<typeof obterFunil>[0], id: string) => (await obterFunil(c, id)) ?? Promise.reject(naoEncontrado('Pipeline nao encontrado'));

tool<{ incluir_arquivados?: boolean }>({
  nome: 'funis.listar', modulo: M, titulo: 'Listar pipelines', tipo: 'leitura', permissao: 'pipeline.ver',
  descricao: 'Pipelines (funis) do workspace na ordem, com padrao, arquivado, quantidade de etapas, oportunidades abertas e valor em negociacao. Workspace sem pipeline recebe o Pipeline padrao.',
  entrada: { type: 'object', properties: { incluir_arquivados: { type: 'boolean' } } },
  rota: { metodo: 'GET', caminho: '/api/v1/pipeline/funis' },
  executar: async ({ c, ator, ip }, a) => {
    exigirOk(await casosDeUso(c).garantirFunil.execute(contextoPg(c, ator, ip)));
    return listarFunis(c, a);
  },
});

tool<{ nome: string; etapas?: string[] }>({
  nome: 'funil.criar', modulo: M, titulo: 'Criar pipeline', tipo: 'escrita', permissao: 'pipeline.editar',
  descricao: 'Cria um pipeline (funil) com nome e etapas abertas iniciais (padrao: Novo, Contato, Proposta, Negociacao); as etapas Ganho e Perdido entram sempre no fim.',
  entrada: { type: 'object', required: ['nome'], properties: { ...propsFunil, etapas: { type: 'array', items: { type: 'string', minLength: 1, maxLength: 60 }, minItems: 1, maxItems: 20 } } },
  rota: { metodo: 'POST', caminho: '/api/v1/pipeline/funis' },
  executar: async ({ c, ator, ip }, a) => {
    const { id } = exigirOk(await casosDeUso(c).criarFunil.execute(contextoPg(c, ator, ip), a));
    return fichaFunil(c, id);
  },
});

tool<{ id: string; nome: string }>({
  nome: 'funil.renomear', modulo: M, titulo: 'Renomear pipeline', tipo: 'escrita', permissao: 'pipeline.editar',
  descricao: 'Renomeia um pipeline ativo (nome unico entre os ativos).',
  entrada: { type: 'object', required: ['id', 'nome'], properties: { id: uuid, ...propsFunil } },
  rota: { metodo: 'PATCH', caminho: '/api/v1/pipeline/funis/:id' },
  executar: async ({ c, ator, ip }, a) => {
    exigirOk(await casosDeUso(c).renomearFunil.execute(contextoPg(c, ator, ip), a));
    return fichaFunil(c, a.id);
  },
});

tool<{ id: string; mover_para_funil_id?: string | null }>({
  nome: 'funil.arquivar', modulo: M, titulo: 'Arquivar pipeline', tipo: 'escrita', permissao: 'pipeline.excluir',
  descricao: 'Arquiva um pipeline. O ultimo pipeline ativo nao pode ser arquivado. Com oportunidades abertas, exige mover_para_funil_id (outro pipeline ativo): as abertas vao para a primeira etapa aberta dele. Arquivar o padrao torna padrao o proximo ativo.',
  entrada: { type: 'object', required: ['id'], properties: { id: uuid, mover_para_funil_id: { type: ['string', 'null'], format: 'uuid' } } },
  rota: { metodo: 'POST', caminho: '/api/v1/pipeline/funis/:id/arquivar' },
  executar: async ({ c, ator, ip }, a) => {
    const r = exigirOk(await casosDeUso(c).arquivarFunil.execute(contextoPg(c, ator, ip), a));
    return { ...(await fichaFunil(c, a.id)), movidas: r.movidas, novo_padrao_id: r.novo_padrao_id };
  },
});

tool<FiltroAtividades>({
  nome: 'atividades.listar', modulo: M, titulo: 'Listar atividades', tipo: 'leitura', permissao: 'pipeline.ver',
  descricao: 'Lista tarefas, ligacoes, reunioes e follow-ups com data, responsavel, oportunidade e estado; filtra por estado, periodo (de, ate em AAAA-MM-DD), oportunidade ou responsavel.',
  entrada: { type: 'object', properties: { limite: paginacao.limite, cursor: paginacao.cursor, estado: { type: 'string', enum: [...estadosAtividade] }, oportunidade_id: uuid, responsavel_id: uuid, de: { type: 'string', format: 'date' }, ate: { type: 'string', format: 'date' } } },
  rota: { metodo: 'GET', caminho: '/api/v1/pipeline/atividades' },
  executar: ({ c }, a) => listarAtividades(c, a),
});

tool<DadosAtividade>({
  nome: 'atividade.agendar', modulo: M, titulo: 'Agendar atividade', tipo: 'escrita', permissao: 'pipeline.criar',
  descricao: 'Agenda tarefa, ligacao, reuniao ou follow-up com data e hora, ligada a uma oportunidade. Responsavel padrao: quem chamou. Publica atividade.agendada (a Agenda reage quando instalada).',
  entrada: { type: 'object', required: ['tipo', 'titulo', 'data'], properties: propsAtividade },
  rota: { metodo: 'POST', caminho: '/api/v1/pipeline/atividades' },
  executar: async ({ c, ator, ip }, a) => {
    const { id } = exigirOk(await casosDeUso(c).agendarAtividade.execute(contextoPg(c, ator, ip), a));
    return obterAtividade(c, id);
  },
});

tool<{ id: string; resultado?: string | null }>({
  nome: 'atividade.concluir', modulo: M, titulo: 'Concluir atividade', tipo: 'escrita', permissao: 'pipeline.editar',
  descricao: 'Conclui atividade pendente com o resultado opcional; anota na oportunidade e publica atividade.concluida.',
  entrada: { type: 'object', required: ['id'], properties: { id: uuid, resultado: { type: ['string', 'null'], maxLength: 2000 } } },
  rota: { metodo: 'POST', caminho: '/api/v1/pipeline/atividades/:id/concluir' },
  executar: async ({ c, ator, ip }, a) => {
    exigirOk(await casosDeUso(c).concluirAtividade.execute(contextoPg(c, ator, ip), a));
    return (await obterAtividade(c, a.id)) ?? Promise.reject(naoEncontrado('Atividade nao encontrada'));
  },
});
