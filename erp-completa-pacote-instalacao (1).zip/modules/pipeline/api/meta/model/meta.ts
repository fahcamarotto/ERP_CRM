/** Entidade Meta (M2.4): valor alvo mensal por equipe OU por vendedor, numa competencia AAAA-MM. Imutavel. */
import { randomUUID } from 'node:crypto';
import { erroDe, fail, ok, type ErroDominio, type Result } from '../../compartilhado/result.ts';
import { Dinheiro } from '../../oportunidade/model/dinheiro.ts';

export interface DadosMeta {
  competencia: string;
  equipe_id?: string | null;
  vendedor_id?: string | null;
  valor_alvo: number;
  moeda?: string;
}

export interface MetaDados {
  id: string;
  /** AAAA-MM */
  competencia: string;
  equipe_id: string | null;
  vendedor_id: string | null;
  valor_alvo: number;
  moeda: string;
}

const t = (v?: string | null) => (v ?? '').trim() || null;

/** Aceita AAAA-MM ou AAAA-MM-DD e guarda AAAA-MM. */
export function competenciaDe(v: unknown): string | null {
  const m = typeof v === 'string' ? /^(\d{4})-(0[1-9]|1[0-2])(-\d{2})?$/.exec(v.trim()) : null;
  return m ? `${m[1]}-${m[2]}` : null;
}

function montar(id: string, e: DadosMeta): Result<MetaDados> {
  const erros: ErroDominio[] = [];
  const competencia = competenciaDe(e.competencia);
  if (!competencia) erros.push(erroDe('competencia_invalida', 'Competencia deve ser AAAA-MM', 'competencia'));
  const equipe = t(e.equipe_id);
  const vendedor = t(e.vendedor_id);
  if (!equipe === !vendedor) erros.push(erroDe('alvo_invalido', 'Informe a equipe ou o vendedor (um dos dois)', 'equipe_id'));
  const dinheiro = Dinheiro.tryCreate(e.valor_alvo, e.moeda ?? 'BRL');
  if (!dinheiro.ok) erros.push(...dinheiro.erros.map((x) => (x.campo === 'valor' ? { ...x, campo: 'valor_alvo' } : x)));
  else if (dinheiro.valor.valor <= 0) erros.push(erroDe('valor_invalido', 'Valor alvo deve ser maior que zero', 'valor_alvo'));
  if (erros.length || !dinheiro.ok) return fail(...erros);
  return ok({ id, competencia: competencia!, equipe_id: equipe, vendedor_id: vendedor, valor_alvo: dinheiro.valor.valor, moeda: dinheiro.valor.moeda });
}

export class Meta {
  private constructor(private readonly d: MetaDados) {}

  static tryCreate(e: DadosMeta, id: string = randomUUID()): Result<Meta> {
    const r = montar(id, e);
    return r.ok ? ok(new Meta(r.valor)) : r;
  }

  static create(e: DadosMeta, id?: string): Meta {
    const r = Meta.tryCreate(e, id);
    if (!r.ok) throw new Error(r.erros.map((x) => x.mensagem).join('; '));
    return r.valor;
  }

  static reidratar(d: MetaDados): Meta {
    return new Meta({ ...d });
  }

  get id(): string { return this.d.id; }

  /** Competencia e alvo (equipe ou vendedor) sao a identidade da meta: so valor e moeda mudam. */
  editar(e: { valor_alvo?: number; moeda?: string }): Result<Meta> {
    const r = montar(this.d.id, { ...this.d, valor_alvo: e.valor_alvo ?? this.d.valor_alvo, moeda: e.moeda ?? this.d.moeda });
    return r.ok ? ok(new Meta(r.valor)) : r;
  }

  paraDados(): MetaDados {
    return { ...this.d };
  }
}
