/** Portas do repositorio de Metas. */
import type { Meta } from './meta.ts';

export interface ObterMeta {
  obterPorId(id: string): Promise<Meta | null>;
  /** Meta viva da mesma competencia e do mesmo alvo (unicidade). */
  buscarMesmoAlvo(competencia: string, equipeId: string | null, vendedorId: string | null): Promise<Meta | null>;
}

export interface GravarMeta {
  inserir(m: Meta): Promise<void>;
  atualizar(m: Meta): Promise<void>;
  excluir(id: string): Promise<void>;
}

export interface ConsultarReferenciasMeta {
  equipeExiste(id: string): Promise<boolean>;
  usuarioExiste(id: string): Promise<boolean>;
}
