/** Adaptador Postgres das portas de Meta (competencia gravada como o primeiro dia do mes). */
import type pg from 'pg';
import { Meta, type MetaDados } from '../model/meta.ts';
import type { ConsultarReferenciasMeta, GravarMeta, ObterMeta } from '../model/portas.ts';

const COLUNAS = "id, to_char(competencia, 'YYYY-MM') AS competencia, equipe_id, vendedor_id, valor_alvo::float8 AS valor_alvo, moeda";
const dia1 = (competencia: string) => `${competencia}-01`;

export class MetaRepoPg implements ObterMeta, GravarMeta, ConsultarReferenciasMeta {
  constructor(private readonly c: pg.PoolClient) {}

  async obterPorId(id: string) {
    const r = await this.c.query(`SELECT ${COLUNAS} FROM pipeline_metas WHERE id = $1 AND deleted_at IS NULL`, [id]);
    return r.rows[0] ? Meta.reidratar(r.rows[0] as MetaDados) : null;
  }

  async buscarMesmoAlvo(competencia: string, equipeId: string | null, vendedorId: string | null) {
    const r = await this.c.query(
      `SELECT ${COLUNAS} FROM pipeline_metas WHERE competencia = $1::date AND deleted_at IS NULL
         AND equipe_id IS NOT DISTINCT FROM $2::uuid AND vendedor_id IS NOT DISTINCT FROM $3::uuid`,
      [dia1(competencia), equipeId, vendedorId],
    );
    return r.rows[0] ? Meta.reidratar(r.rows[0] as MetaDados) : null;
  }

  async inserir(m: Meta) {
    const d = m.paraDados();
    await this.c.query(
      'INSERT INTO pipeline_metas (id, competencia, equipe_id, vendedor_id, valor_alvo, moeda, creator_id) VALUES ($1, $2::date, $3, $4, $5, $6, nucleo_usuario_atual())',
      [d.id, dia1(d.competencia), d.equipe_id, d.vendedor_id, d.valor_alvo, d.moeda],
    );
  }

  async atualizar(m: Meta) {
    const d = m.paraDados();
    await this.c.query('UPDATE pipeline_metas SET valor_alvo = $2, moeda = $3 WHERE id = $1 AND deleted_at IS NULL', [d.id, d.valor_alvo, d.moeda]);
  }

  async excluir(id: string) {
    await this.c.query('UPDATE pipeline_metas SET deleted_at = now() WHERE id = $1 AND deleted_at IS NULL', [id]);
  }

  async equipeExiste(id: string) {
    return ((await this.c.query('SELECT 1 FROM pipeline_equipes WHERE id = $1 AND deleted_at IS NULL', [id])).rowCount ?? 0) > 0;
  }

  async usuarioExiste(id: string) {
    return ((await this.c.query('SELECT 1 FROM usuarios WHERE id = $1 AND deleted_at IS NULL', [id])).rowCount ?? 0) > 0;
  }
}
