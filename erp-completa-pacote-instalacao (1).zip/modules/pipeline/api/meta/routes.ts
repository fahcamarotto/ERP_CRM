/** Rotas REST das Metas mensais (M2.4). */
import { esquemaErro, requer, type FastifyInstance } from '@erp/api/sdk';
import { naTransacao } from '../borda.ts';
import { exigirOk } from '../compartilhado/result.ts';
import { propsMeta, uuid } from '../esquemas.ts';
import type { DadosMeta } from './model/meta.ts';
import { listarMetas } from './query/metas.ts';

const tags = ['pipeline'];
const erros = { 400: esquemaErro, 404: esquemaErro, 409: esquemaErro };
const paramId = { type: 'object', required: ['id'], properties: { id: uuid } } as const;

export function rotasMeta(app: FastifyInstance): void {
  app.get<{ Querystring: { competencia?: string } }>('/metas', {
    preHandler: requer('pipeline.ver'),
    schema: { tags, summary: 'Metas com realizado e percentual', querystring: { type: 'object', additionalProperties: false, properties: { competencia: propsMeta.competencia } } },
  }, (req) => naTransacao(req, (_, __, c) => listarMetas(c, req.query)));

  app.post<{ Body: DadosMeta }>('/metas', {
    preHandler: requer('pipeline.criar'),
    schema: { tags, summary: 'Cria meta mensal por equipe ou vendedor (CriarMeta)', body: { type: 'object', additionalProperties: false, required: ['competencia', 'valor_alvo'], properties: propsMeta }, response: erros },
  }, async (req, reply) => reply.code(201).send(await naTransacao(req, async (casos, ctx) => exigirOk(await casos.criarMeta.execute(ctx, req.body)))));

  app.patch<{ Params: { id: string }; Body: { valor_alvo?: number; moeda?: string } }>('/metas/:id', {
    preHandler: requer('pipeline.editar'),
    schema: { tags, summary: 'Edita valor alvo (EditarMeta)', params: paramId, body: { type: 'object', additionalProperties: false, properties: { valor_alvo: propsMeta.valor_alvo, moeda: propsMeta.moeda } }, response: erros },
  }, async (req, reply) => {
    await naTransacao(req, async (casos, ctx) => exigirOk(await casos.editarMeta.execute(ctx, { ...req.body, id: req.params.id })));
    return reply.code(204).send();
  });

  app.delete<{ Params: { id: string } }>('/metas/:id', {
    preHandler: requer('pipeline.excluir'),
    schema: { tags, summary: 'Exclui meta (ExcluirMeta)', params: paramId, response: erros },
  }, async (req, reply) => {
    await naTransacao(req, async (casos, ctx) => exigirOk(await casos.excluirMeta.execute(ctx, { id: req.params.id })));
    return reply.code(204).send();
  });
}
