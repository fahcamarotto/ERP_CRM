/** Consulta das Metas com o realizado (soma das oportunidades ganhas no mes pelo alvo) e o percentual atingido. */
import type pg from 'pg';

export async function listarMetas(c: pg.PoolClient, f: { competencia?: string } = {}) {
  const r = await c.query(
    `SELECT m.id, to_char(m.competencia, 'YYYY-MM') AS competencia, m.equipe_id, e.nome AS equipe_nome, m.vendedor_id, u.nome AS vendedor_nome,
       m.valor_alvo::float8 AS valor_alvo, m.moeda, m.created_at, m.updated_at,
       coalesce((SELECT sum(o.valor) FROM pipeline_oportunidades o
                 WHERE o.estado = 'ganha' AND o.deleted_at IS NULL AND o.moeda = m.moeda
                   AND o.fechada_em >= m.competencia AND o.fechada_em < m.competencia + interval '1 month'
                   AND (o.equipe_id = m.equipe_id OR o.responsavel_id = m.vendedor_id)), 0)::float8 AS realizado
     FROM pipeline_metas m
     LEFT JOIN pipeline_equipes e ON e.id = m.equipe_id
     LEFT JOIN usuarios u ON u.id = m.vendedor_id
     WHERE m.deleted_at IS NULL AND ($1::text IS NULL OR m.competencia = ($1 || '-01')::date)
     ORDER BY m.competencia DESC, coalesce(e.nome, u.nome)`,
    [f.competencia ?? null],
  );
  return r.rows.map((l) => ({ ...l, percentual: l.valor_alvo > 0 ? Math.round((l.realizado / l.valor_alvo) * 1000) / 10 : 0 }));
}
