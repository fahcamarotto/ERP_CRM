/** Casos de uso de Metas (M2.4): criar (uma por competencia e alvo), editar valor e excluir. */
import { erroDe, fail, ok, okVazio, type Result } from '../../compartilhado/result.ts';
import type { ContextoCaso } from '../../compartilhado/efeitos.ts';
import { Meta, type DadosMeta } from '../model/meta.ts';
import type { ConsultarReferenciasMeta, GravarMeta, ObterMeta } from '../model/portas.ts';

const TABELA = 'pipeline_metas';

export class CriarMeta {
  constructor(private readonly deps: { repo: ObterMeta & GravarMeta; refs: ConsultarReferenciasMeta }) {}
  async execute(ctx: ContextoCaso, e: DadosMeta): Promise<Result<{ id: string }>> {
    const r = Meta.tryCreate(e);
    if (!r.ok) return r;
    const d = r.valor.paraDados();
    if (d.equipe_id && !(await this.deps.refs.equipeExiste(d.equipe_id))) return fail(erroDe('equipe_invalida', 'Equipe nao encontrada', 'equipe_id'));
    if (d.vendedor_id && !(await this.deps.refs.usuarioExiste(d.vendedor_id))) return fail(erroDe('usuario_invalido', 'Vendedor nao encontrado', 'vendedor_id'));
    const ja = await this.deps.repo.buscarMesmoAlvo(d.competencia, d.equipe_id, d.vendedor_id);
    if (ja) return fail(erroDe('conflito', 'Ja existe meta para este alvo nesta competencia', 'competencia', { meta_id: ja.id }));
    await this.deps.repo.inserir(r.valor);
    await ctx.efeitos.auditar('meta.criar', TABELA, d.id, undefined, d);
    return ok({ id: d.id });
  }
}

export class EditarMeta {
  constructor(private readonly deps: { repo: ObterMeta & GravarMeta }) {}
  async execute(ctx: ContextoCaso, e: { id: string; valor_alvo?: number; moeda?: string }): Promise<Result<void>> {
    const atual = await this.deps.repo.obterPorId(e.id);
    if (!atual) return fail(erroDe('nao_encontrado', 'Meta nao encontrada'));
    const r = atual.editar(e);
    if (!r.ok) return r;
    await this.deps.repo.atualizar(r.valor);
    await ctx.efeitos.auditar('meta.editar', TABELA, e.id, atual.paraDados(), r.valor.paraDados());
    return okVazio();
  }
}

export class ExcluirMeta {
  constructor(private readonly deps: { repo: ObterMeta & GravarMeta }) {}
  async execute(ctx: ContextoCaso, e: { id: string }): Promise<Result<void>> {
    const atual = await this.deps.repo.obterPorId(e.id);
    if (!atual) return fail(erroDe('nao_encontrado', 'Meta nao encontrada'));
    await this.deps.repo.excluir(e.id);
    await ctx.efeitos.auditar('meta.excluir', TABELA, e.id, atual.paraDados());
    return okVazio();
  }
}
