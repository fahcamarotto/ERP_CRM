/** JSON Schemas dos DTOs de entrada (validacao Fastify, OpenAPI em /docs e schema das tools MCP). */
import { CANAIS, ESTADOS_OPORTUNIDADE } from './oportunidade/model/oportunidade.ts';
import { TIPOS_ATIVIDADE, ESTADOS_ATIVIDADE } from './atividade/model/atividade.ts';
import { CORES } from './etapa/model/etapa.ts';

export const uuid = { type: 'string', format: 'uuid' } as const;
const uuidNulo = { type: ['string', 'null'], format: 'uuid' } as const;
const texto = (max: number) => ({ type: ['string', 'null'], maxLength: max });

export const propsOportunidade = {
  titulo: { type: 'string', minLength: 2, maxLength: 200 },
  parceiro_id: { ...uuidNulo, description: 'Cliente (cadastros_parceiros)' },
  valor: { type: ['number', 'null'], minimum: 0 },
  moeda: { type: 'string', pattern: '^[A-Z]{3}$' },
  responsavel_id: uuidNulo,
  equipe_id: uuidNulo,
  probabilidade: { type: ['integer', 'null'], minimum: 0, maximum: 100, description: 'Padrao: probabilidade da etapa' },
  origem: texto(60),
  canal: { type: ['string', 'null'], enum: [...CANAIS, null] },
  utm_source: texto(120),
  utm_medium: texto(120),
  utm_campaign: texto(120),
  previsao_fechamento: { type: ['string', 'null'], format: 'date' },
  extras: { type: 'object', description: 'Campos personalizados (modulo pipeline, entidade oportunidade)' },
} as const;

export const estadosOportunidade = ESTADOS_OPORTUNIDADE;

export const propsFunil = {
  nome: { type: 'string', minLength: 1, maxLength: 60 },
} as const;

export const propsEtapa = {
  funil_id: { ...uuid, description: 'Pipeline (funil) da etapa. Padrao: o pipeline padrao do workspace' },
  nome: { type: 'string', minLength: 1, maxLength: 60 },
  ordem: { type: 'integer', minimum: 0, maximum: 999 },
  tipo: { type: 'string', enum: ['aberta', 'ganho', 'perdido'] },
  probabilidade: { type: 'integer', minimum: 0, maximum: 100 },
  cor: { type: 'string', enum: [...CORES] },
} as const;

export const propsAtividade = {
  tipo: { type: 'string', enum: [...TIPOS_ATIVIDADE] },
  titulo: { type: 'string', minLength: 2, maxLength: 200 },
  descricao: texto(4000),
  data: { type: 'string', maxLength: 40, description: 'Data e hora ISO 8601, ex.: 2026-10-05T14:30:00-03:00' },
  duracao_min: { type: 'integer', minimum: 5, maximum: 1440 },
  responsavel_id: { ...uuidNulo, description: 'Padrao: usuario da sessao' },
  oportunidade_id: uuidNulo,
} as const;

export const estadosAtividade = ESTADOS_ATIVIDADE;

export const propsEquipe = {
  nome: { type: 'string', minLength: 2, maxLength: 80 },
  lider_id: uuidNulo,
  cor: { type: 'string', enum: [...CORES] },
  membro_ids: { type: 'array', items: uuid, maxItems: 200 },
} as const;

export const propsMeta = {
  competencia: { type: 'string', pattern: '^\\d{4}-(0[1-9]|1[0-2])$', description: 'AAAA-MM' },
  equipe_id: uuidNulo,
  vendedor_id: uuidNulo,
  valor_alvo: { type: 'number', exclusiveMinimum: 0 },
  moeda: { type: 'string', pattern: '^[A-Z]{3}$' },
} as const;

export const propsMotivo = {
  nome: { type: 'string', minLength: 2, maxLength: 80 },
  descricao: texto(300),
  ativo: { type: 'boolean' },
} as const;

export const paginacao = {
  busca: { type: 'string', maxLength: 120 },
  limite: { type: 'integer', minimum: 1, maximum: 500, default: 50 },
  cursor: { type: 'string', maxLength: 200 },
} as const;
