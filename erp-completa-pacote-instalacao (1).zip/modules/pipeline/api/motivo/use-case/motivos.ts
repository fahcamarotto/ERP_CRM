/** Casos de uso de Motivos de perda: criar, editar (inclusive desativar) e excluir (so sem uso). */
import { erroDe, fail, ok, okVazio, type Result } from '../../compartilhado/result.ts';
import type { ContextoCaso } from '../../compartilhado/efeitos.ts';
import { MotivoPerda, type DadosMotivo } from '../model/motivo.ts';
import type { ContarUsoMotivo, GravarMotivo, ObterMotivo } from '../model/portas.ts';

const TABELA = 'pipeline_motivos_perda';
type Repo = ObterMotivo & GravarMotivo & ContarUsoMotivo;

export class CriarMotivo {
  constructor(private readonly deps: { repo: Repo }) {}
  async execute(ctx: ContextoCaso, e: DadosMotivo): Promise<Result<{ id: string }>> {
    const r = MotivoPerda.tryCreate(e);
    if (!r.ok) return r;
    const d = r.valor.paraDados();
    if (await this.deps.repo.buscarPorNome(d.nome)) return fail(erroDe('conflito', 'Ja existe motivo com este nome', 'nome'));
    await this.deps.repo.inserir(r.valor);
    await ctx.efeitos.auditar('motivo_perda.criar', TABELA, d.id, undefined, d);
    return ok({ id: d.id });
  }
}

export class EditarMotivo {
  constructor(private readonly deps: { repo: Repo }) {}
  async execute(ctx: ContextoCaso, e: { id: string } & Partial<DadosMotivo>): Promise<Result<void>> {
    const atual = await this.deps.repo.obterPorId(e.id);
    if (!atual) return fail(erroDe('nao_encontrado', 'Motivo nao encontrado'));
    const r = atual.editar(e);
    if (!r.ok) return r;
    const d = r.valor.paraDados();
    const mesmo = await this.deps.repo.buscarPorNome(d.nome);
    if (mesmo && mesmo.id !== d.id) return fail(erroDe('conflito', 'Ja existe motivo com este nome', 'nome'));
    await this.deps.repo.atualizar(r.valor);
    await ctx.efeitos.auditar('motivo_perda.editar', TABELA, d.id, atual.paraDados(), d);
    return okVazio();
  }
}

export class ExcluirMotivo {
  constructor(private readonly deps: { repo: Repo }) {}
  async execute(ctx: ContextoCaso, e: { id: string }): Promise<Result<void>> {
    const atual = await this.deps.repo.obterPorId(e.id);
    if (!atual) return fail(erroDe('nao_encontrado', 'Motivo nao encontrado'));
    const uso = await this.deps.repo.emUso(e.id);
    if (uso > 0) return fail(erroDe('conflito', `Usado em ${uso} oportunidade(s) perdida(s): desative em vez de excluir`, undefined, { em_uso: uso }));
    await this.deps.repo.excluir(e.id);
    await ctx.efeitos.auditar('motivo_perda.excluir', TABELA, e.id, atual.paraDados());
    return okVazio();
  }
}
