/** Consulta dos Motivos de perda com uso e valor perdido por motivo (analise de perdas). */
import type pg from 'pg';

export async function listarMotivos(c: pg.PoolClient, f: { ativos?: boolean } = {}) {
  const r = await c.query(
    `SELECT m.id, m.nome, m.descricao, m.ativo, m.created_at, m.updated_at,
       count(o.id)::int AS em_uso, coalesce(sum(o.valor), 0)::float8 AS valor_perdido
     FROM pipeline_motivos_perda m
     LEFT JOIN pipeline_oportunidades o ON o.motivo_perda_id = m.id AND o.estado = 'perdida' AND o.deleted_at IS NULL
     WHERE m.deleted_at IS NULL AND ($1::boolean IS NULL OR m.ativo = $1)
     GROUP BY m.id, m.nome, m.descricao, m.ativo, m.created_at, m.updated_at ORDER BY lower(m.nome)`,
    [f.ativos ?? null],
  );
  return r.rows;
}
