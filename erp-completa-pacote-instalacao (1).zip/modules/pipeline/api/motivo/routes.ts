/** Rotas REST dos Motivos de perda. */
import { esquemaErro, requer, type FastifyInstance } from '@erp/api/sdk';
import { naTransacao } from '../borda.ts';
import { exigirOk } from '../compartilhado/result.ts';
import { propsMotivo, uuid } from '../esquemas.ts';
import type { DadosMotivo } from './model/motivo.ts';
import { listarMotivos } from './query/motivos.ts';

const tags = ['pipeline'];
const erros = { 400: esquemaErro, 404: esquemaErro, 409: esquemaErro };
const paramId = { type: 'object', required: ['id'], properties: { id: uuid } } as const;

export function rotasMotivo(app: FastifyInstance): void {
  app.get<{ Querystring: { ativos?: boolean } }>('/motivos-perda', {
    preHandler: requer('pipeline.ver'),
    schema: { tags, summary: 'Motivos de perda com uso e valor perdido', querystring: { type: 'object', additionalProperties: false, properties: { ativos: { type: 'boolean' } } } },
  }, (req) => naTransacao(req, (_, __, c) => listarMotivos(c, req.query)));

  app.post<{ Body: DadosMotivo }>('/motivos-perda', {
    preHandler: requer('pipeline.criar'),
    schema: { tags, summary: 'Cria motivo de perda (CriarMotivo)', body: { type: 'object', additionalProperties: false, required: ['nome'], properties: propsMotivo }, response: erros },
  }, async (req, reply) => reply.code(201).send(await naTransacao(req, async (casos, ctx) => exigirOk(await casos.criarMotivo.execute(ctx, req.body)))));

  app.patch<{ Params: { id: string }; Body: Partial<DadosMotivo> }>('/motivos-perda/:id', {
    preHandler: requer('pipeline.editar'),
    schema: { tags, summary: 'Edita ou desativa motivo (EditarMotivo)', params: paramId, body: { type: 'object', additionalProperties: false, properties: propsMotivo }, response: erros },
  }, async (req, reply) => {
    await naTransacao(req, async (casos, ctx) => exigirOk(await casos.editarMotivo.execute(ctx, { ...req.body, id: req.params.id })));
    return reply.code(204).send();
  });

  app.delete<{ Params: { id: string } }>('/motivos-perda/:id', {
    preHandler: requer('pipeline.excluir'),
    schema: { tags, summary: 'Exclui motivo sem uso (ExcluirMotivo)', params: paramId, response: erros },
  }, async (req, reply) => {
    await naTransacao(req, async (casos, ctx) => exigirOk(await casos.excluirMotivo.execute(ctx, { id: req.params.id })));
    return reply.code(204).send();
  });
}
