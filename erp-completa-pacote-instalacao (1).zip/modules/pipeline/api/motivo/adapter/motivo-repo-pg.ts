/** Adaptador Postgres das portas de Motivo de perda. */
import type pg from 'pg';
import { MotivoPerda, type MotivoDados } from '../model/motivo.ts';
import type { ContarUsoMotivo, GravarMotivo, ObterMotivo } from '../model/portas.ts';

const COLUNAS = 'id, nome, descricao, ativo';

export class MotivoRepoPg implements ObterMotivo, GravarMotivo, ContarUsoMotivo {
  constructor(private readonly c: pg.PoolClient) {}

  async obterPorId(id: string) {
    const r = await this.c.query(`SELECT ${COLUNAS} FROM pipeline_motivos_perda WHERE id = $1 AND deleted_at IS NULL`, [id]);
    return r.rows[0] ? MotivoPerda.reidratar(r.rows[0] as MotivoDados) : null;
  }

  async buscarPorNome(nome: string) {
    const r = await this.c.query(`SELECT ${COLUNAS} FROM pipeline_motivos_perda WHERE lower(nome) = lower($1) AND deleted_at IS NULL`, [nome]);
    return r.rows[0] ? MotivoPerda.reidratar(r.rows[0] as MotivoDados) : null;
  }

  async inserir(m: MotivoPerda) {
    const d = m.paraDados();
    await this.c.query('INSERT INTO pipeline_motivos_perda (id, nome, descricao, ativo, creator_id) VALUES ($1, $2, $3, $4, nucleo_usuario_atual())', [d.id, d.nome, d.descricao, d.ativo]);
  }

  async atualizar(m: MotivoPerda) {
    const d = m.paraDados();
    await this.c.query('UPDATE pipeline_motivos_perda SET nome = $2, descricao = $3, ativo = $4 WHERE id = $1 AND deleted_at IS NULL', [d.id, d.nome, d.descricao, d.ativo]);
  }

  async excluir(id: string) {
    await this.c.query('UPDATE pipeline_motivos_perda SET deleted_at = now() WHERE id = $1 AND deleted_at IS NULL', [id]);
  }

  async emUso(id: string) {
    return (await this.c.query('SELECT count(*)::int AS n FROM pipeline_oportunidades WHERE motivo_perda_id = $1 AND deleted_at IS NULL', [id])).rows[0].n as number;
  }
}
