/** Entidade MotivoPerda: lista configuravel usada no MarcarPerdida (motivo obrigatorio). Imutavel. */
import { randomUUID } from 'node:crypto';
import { erroDe, fail, ok, type ErroDominio, type Result } from '../../compartilhado/result.ts';

export interface DadosMotivo {
  nome: string;
  descricao?: string | null;
  ativo?: boolean;
}

export interface MotivoDados {
  id: string;
  nome: string;
  descricao: string | null;
  ativo: boolean;
}

function validar(d: MotivoDados): ErroDominio[] {
  const e: ErroDominio[] = [];
  if (d.nome.length < 2 || d.nome.length > 80) e.push(erroDe('nome_invalido', 'Nome deve ter de 2 a 80 caracteres', 'nome'));
  if ((d.descricao?.length ?? 0) > 300) e.push(erroDe('descricao_invalida', 'Descricao com no maximo 300 caracteres', 'descricao'));
  return e;
}

export class MotivoPerda {
  private constructor(private readonly d: MotivoDados) {}

  static tryCreate(e: DadosMotivo, id: string = randomUUID()): Result<MotivoPerda> {
    const d: MotivoDados = { id, nome: (e.nome ?? '').trim(), descricao: (e.descricao ?? '').trim() || null, ativo: e.ativo ?? true };
    const erros = validar(d);
    return erros.length ? fail(...erros) : ok(new MotivoPerda(d));
  }

  static create(e: DadosMotivo, id?: string): MotivoPerda {
    const r = MotivoPerda.tryCreate(e, id);
    if (!r.ok) throw new Error(r.erros.map((x) => x.mensagem).join('; '));
    return r.valor;
  }

  static reidratar(d: MotivoDados): MotivoPerda {
    return new MotivoPerda({ ...d });
  }

  get id(): string { return this.d.id; }

  editar(e: Partial<DadosMotivo>): Result<MotivoPerda> {
    const n: MotivoDados = {
      ...this.d,
      nome: e.nome !== undefined ? e.nome.trim() : this.d.nome,
      descricao: e.descricao !== undefined ? (e.descricao ?? '').trim() || null : this.d.descricao,
      ativo: e.ativo ?? this.d.ativo,
    };
    const erros = validar(n);
    return erros.length ? fail(...erros) : ok(new MotivoPerda(n));
  }

  paraDados(): MotivoDados {
    return { ...this.d };
  }
}
