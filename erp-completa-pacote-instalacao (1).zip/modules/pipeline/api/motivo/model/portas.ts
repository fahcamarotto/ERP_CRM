/** Portas do repositorio de Motivos de perda. */
import type { MotivoPerda } from './motivo.ts';

export interface ObterMotivo {
  obterPorId(id: string): Promise<MotivoPerda | null>;
  buscarPorNome(nome: string): Promise<MotivoPerda | null>;
}

export interface GravarMotivo {
  inserir(m: MotivoPerda): Promise<void>;
  atualizar(m: MotivoPerda): Promise<void>;
  excluir(id: string): Promise<void>;
}

export interface ContarUsoMotivo {
  emUso(id: string): Promise<number>;
}
