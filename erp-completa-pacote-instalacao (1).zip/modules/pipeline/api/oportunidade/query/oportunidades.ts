/** Consultas de leitura da Oportunidade: lista com nomes de exibicao, ficha com movimentos e atividades, metricas do topo. */
import type pg from 'pg';
import { decodificarCursor, pagina } from '../../compartilhado/cursor.ts';

const RESUMO = `o.id, o.titulo, o.parceiro_id, c.nome AS cliente_nome, o.valor::float8 AS valor, o.moeda, o.responsavel_id, u.nome AS responsavel_nome,
  o.equipe_id, eq.nome AS equipe_nome, o.funil_id, fu.nome AS funil_nome, o.etapa_id, e.nome AS etapa_nome, e.tipo AS etapa_tipo, o.probabilidade, o.estado, o.origem, o.canal,
  o.utm_source, o.utm_medium, o.utm_campaign, to_char(o.previsao_fechamento, 'YYYY-MM-DD') AS previsao_fechamento,
  o.motivo_perda_id, mp.nome AS motivo_perda_nome, o.motivo_perda_detalhe, o.projeto_id, o.etapa_desde, o.fechada_em, o.created_at, o.updated_at,
  (SELECT count(*)::int FROM pipeline_atividades a WHERE a.oportunidade_id = o.id AND a.estado = 'pendente' AND a.deleted_at IS NULL) AS atividades_pendentes`;

const JUNCOES = `FROM pipeline_oportunidades o
  JOIN pipeline_etapas e ON e.id = o.etapa_id
  JOIN pipeline_funis fu ON fu.id = o.funil_id
  LEFT JOIN cadastros_parceiros c ON c.id = o.parceiro_id AND c.deleted_at IS NULL
  LEFT JOIN usuarios u ON u.id = o.responsavel_id
  LEFT JOIN pipeline_equipes eq ON eq.id = o.equipe_id
  LEFT JOIN pipeline_motivos_perda mp ON mp.id = o.motivo_perda_id`;

export interface FiltroOportunidades {
  estado?: 'aberta' | 'ganha' | 'perdida';
  funil_id?: string;
  etapa_id?: string;
  parceiro_id?: string;
  responsavel_id?: string;
  equipe_id?: string;
  busca?: string;
  limite?: number;
  cursor?: string;
}

export async function listarOportunidades(c: pg.PoolClient, f: FiltroOportunidades) {
  const lim = Math.min(Math.max(f.limite ?? 50, 1), 500);
  const cur = decodificarCursor(f.cursor);
  const r = await c.query(
    `SELECT ${RESUMO} ${JUNCOES}
     WHERE o.deleted_at IS NULL AND ($1::text IS NULL OR o.estado = $1) AND ($2::uuid IS NULL OR o.etapa_id = $2)
       AND ($3::uuid IS NULL OR o.parceiro_id = $3) AND ($4::uuid IS NULL OR o.responsavel_id = $4) AND ($5::uuid IS NULL OR o.equipe_id = $5)
       AND ($6::text IS NULL OR o.titulo ILIKE '%' || $6 || '%' OR c.nome ILIKE '%' || $6 || '%')
       AND ($7::timestamptz IS NULL OR (o.created_at, o.id) > ($7::timestamptz, $8::uuid))
       AND ($10::uuid IS NULL OR o.funil_id = $10)
     ORDER BY o.created_at, o.id LIMIT $9`,
    [f.estado ?? null, f.etapa_id ?? null, f.parceiro_id ?? null, f.responsavel_id ?? null, f.equipe_id ?? null, f.busca?.trim() || null,
      cur?.[0] ?? null, cur?.[1] ?? null, lim + 1, f.funil_id ?? null],
  );
  return pagina(r.rows, lim);
}

export async function obterOportunidade(c: pg.PoolClient, id: string) {
  const r = await c.query(
    `SELECT ${RESUMO}, o.extras, o.lead_evento_id,
       coalesce((SELECT json_agg(json_build_object('id', m.id, 'de', de.nome, 'para', pa.nome, 'em', m.created_at) ORDER BY m.created_at)
                 FROM pipeline_movimentos m LEFT JOIN pipeline_etapas de ON de.id = m.de_etapa_id JOIN pipeline_etapas pa ON pa.id = m.para_etapa_id
                 WHERE m.oportunidade_id = o.id AND m.deleted_at IS NULL), '[]') AS movimentos
     ${JUNCOES} WHERE o.id = $1 AND o.deleted_at IS NULL`,
    [id],
  );
  return r.rows[0] ?? null;
}

/**
 * Metricas do topo (M2.6): valor em negociacao (abertas), valor ponderado pela probabilidade, conversao por etapa
 * (das oportunidades que passaram pela etapa, quantas foram ganhas) e ciclo medio em dias (criacao ate o ganho).
 * Com funil_id os totais sao daquele funil; sem ele, de todos (Inicio). A conversao por etapa e sempre de um funil:
 * o informado ou o padrao do workspace.
 */
export async function metricasPipeline(c: pg.PoolClient, f: { responsavel_id?: string; equipe_id?: string; funil_id?: string } = {}) {
  const filtro = `o.deleted_at IS NULL AND ($1::uuid IS NULL OR o.responsavel_id = $1) AND ($2::uuid IS NULL OR o.equipe_id = $2) AND ($3::uuid IS NULL OR o.funil_id = $3)`;
  const p = [f.responsavel_id ?? null, f.equipe_id ?? null, f.funil_id ?? null];
  const topo = (await c.query(
    `SELECT coalesce(sum(o.valor) FILTER (WHERE o.estado = 'aberta'), 0)::float8 AS valor_em_negociacao,
       coalesce(sum(o.valor * o.probabilidade / 100.0) FILTER (WHERE o.estado = 'aberta'), 0)::float8 AS valor_ponderado,
       count(*) FILTER (WHERE o.estado = 'aberta')::int AS abertas,
       count(*) FILTER (WHERE o.estado = 'ganha')::int AS ganhas,
       count(*) FILTER (WHERE o.estado = 'perdida')::int AS perdidas,
       coalesce(sum(o.valor) FILTER (WHERE o.estado = 'ganha'), 0)::float8 AS valor_ganho,
       round(avg(extract(epoch FROM o.fechada_em - o.created_at) / 86400.0) FILTER (WHERE o.estado = 'ganha')::numeric, 1)::float8 AS ciclo_medio_dias,
       CASE WHEN count(*) FILTER (WHERE o.estado <> 'aberta') = 0 THEN NULL
         ELSE round(100.0 * count(*) FILTER (WHERE o.estado = 'ganha') / count(*) FILTER (WHERE o.estado <> 'aberta'), 1)::float8 END AS taxa_ganho,
       (SELECT moeda FROM pipeline_oportunidades WHERE deleted_at IS NULL GROUP BY moeda ORDER BY count(*) DESC LIMIT 1) AS moeda
     FROM pipeline_oportunidades o WHERE ${filtro}`,
    p,
  )).rows[0];
  const etapas = (await c.query(
    `SELECT e.id, e.nome, e.tipo, e.ordem,
       count(DISTINCT x.oportunidade_id)::int AS passaram,
       count(DISTINCT x.oportunidade_id) FILTER (WHERE x.estado = 'ganha')::int AS ganhas,
       CASE WHEN count(DISTINCT x.oportunidade_id) = 0 THEN NULL
         ELSE round(100.0 * count(DISTINCT x.oportunidade_id) FILTER (WHERE x.estado = 'ganha') / count(DISTINCT x.oportunidade_id), 1)::float8 END AS conversao
     FROM pipeline_etapas e
     LEFT JOIN (SELECT m.para_etapa_id, m.oportunidade_id, o.estado FROM pipeline_movimentos m
                JOIN pipeline_oportunidades o ON o.id = m.oportunidade_id WHERE m.deleted_at IS NULL AND ${filtro}) x ON x.para_etapa_id = e.id
     WHERE e.deleted_at IS NULL AND e.tipo = 'aberta'
       AND e.funil_id = coalesce($3::uuid, (SELECT id FROM pipeline_funis WHERE padrao AND deleted_at IS NULL LIMIT 1))
     GROUP BY e.id, e.nome, e.tipo, e.ordem ORDER BY e.ordem, e.nome`,
    p,
  )).rows;
  return { ...topo, moeda: topo.moeda ?? 'BRL', conversao_por_etapa: etapas };
}
