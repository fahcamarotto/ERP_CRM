/** Adaptador Postgres das portas do agregado Oportunidade (RLS restringe ao workspace da sessao). */
import type pg from 'pg';
import type { TipoEtapa } from '../../etapa/model/etapa.ts';
import { Oportunidade, type EtapaRef, type OportunidadeDados } from '../model/oportunidade.ts';
import type { BuscarAbertaDoParceiro, BuscarPorLead, ConsultarEtapas, ConsultarReferenciasOportunidade, GravarOportunidade, ObterOportunidade } from '../model/portas.ts';

const COLUNAS = `id, titulo, parceiro_id, valor::float8 AS valor, moeda, responsavel_id, equipe_id, funil_id, etapa_id, probabilidade, estado,
  origem, canal, utm_source, utm_medium, utm_campaign, to_char(previsao_fechamento, 'YYYY-MM-DD') AS previsao_fechamento,
  motivo_perda_id, motivo_perda_detalhe, projeto_id, lead_evento_id, etapa_desde, fechada_em, extras`;

function reidratar(l: Record<string, unknown>): Oportunidade {
  const iso = (v: unknown) => (v instanceof Date ? v.toISOString() : v === null || v === undefined ? null : String(v));
  return Oportunidade.reidratar({ ...(l as unknown as OportunidadeDados), etapa_desde: iso(l.etapa_desde)!, fechada_em: iso(l.fechada_em) });
}

const ref = (l: { id: string; tipo: TipoEtapa; probabilidade: number; funil_id: string } | undefined): EtapaRef | null =>
  l ? { id: l.id, tipo: l.tipo, probabilidade: Number(l.probabilidade), funil_id: l.funil_id } : null;
const REF = 'id, tipo, probabilidade, funil_id';

export class OportunidadeRepoPg implements ObterOportunidade, GravarOportunidade, BuscarPorLead, BuscarAbertaDoParceiro, ConsultarEtapas, ConsultarReferenciasOportunidade {
  constructor(private readonly c: pg.PoolClient) {}

  async obterPorId(id: string) {
    const r = await this.c.query(`SELECT ${COLUNAS} FROM pipeline_oportunidades WHERE id = $1 AND deleted_at IS NULL`, [id]);
    return r.rows[0] ? reidratar(r.rows[0]) : null;
  }

  async abertaDoParceiro(parceiroId: string, funilId: string) {
    const r = await this.c.query(
      `SELECT ${COLUNAS} FROM pipeline_oportunidades WHERE parceiro_id = $1 AND funil_id = $2 AND estado = 'aberta' AND deleted_at IS NULL ORDER BY created_at DESC LIMIT 1`,
      [parceiroId, funilId],
    );
    return r.rows[0] ? reidratar(r.rows[0]) : null;
  }

  async porLeadEvento(eventoId: string) {
    const r = await this.c.query(`SELECT ${COLUNAS} FROM pipeline_oportunidades WHERE lead_evento_id = $1`, [eventoId]);
    return r.rows[0] ? reidratar(r.rows[0]) : null;
  }

  async inserir(o: Oportunidade) {
    const d = o.paraDados();
    await this.c.query(
      `INSERT INTO pipeline_oportunidades (id, titulo, parceiro_id, valor, moeda, responsavel_id, equipe_id, etapa_id, probabilidade, estado,
         origem, canal, utm_source, utm_medium, utm_campaign, previsao_fechamento, motivo_perda_id, motivo_perda_detalhe, projeto_id,
         lead_evento_id, etapa_desde, fechada_em, extras, funil_id, creator_id)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22, $23, $24, nucleo_usuario_atual())`,
      [d.id, d.titulo, d.parceiro_id, d.valor, d.moeda, d.responsavel_id, d.equipe_id, d.etapa_id, d.probabilidade, d.estado, d.origem, d.canal,
        d.utm_source, d.utm_medium, d.utm_campaign, d.previsao_fechamento, d.motivo_perda_id, d.motivo_perda_detalhe, d.projeto_id, d.lead_evento_id,
        d.etapa_desde, d.fechada_em, JSON.stringify(d.extras), d.funil_id],
    );
  }

  async atualizar(o: Oportunidade) {
    const d = o.paraDados();
    await this.c.query(
      `UPDATE pipeline_oportunidades SET titulo = $2, parceiro_id = $3, valor = $4, moeda = $5, responsavel_id = $6, equipe_id = $7, etapa_id = $8,
         probabilidade = $9, estado = $10, origem = $11, canal = $12, utm_source = $13, utm_medium = $14, utm_campaign = $15,
         previsao_fechamento = $16, motivo_perda_id = $17, motivo_perda_detalhe = $18, projeto_id = $19, etapa_desde = $20, fechada_em = $21, extras = $22,
         funil_id = $23
       WHERE id = $1 AND deleted_at IS NULL`,
      [d.id, d.titulo, d.parceiro_id, d.valor, d.moeda, d.responsavel_id, d.equipe_id, d.etapa_id, d.probabilidade, d.estado, d.origem, d.canal,
        d.utm_source, d.utm_medium, d.utm_campaign, d.previsao_fechamento, d.motivo_perda_id, d.motivo_perda_detalhe, d.projeto_id, d.etapa_desde,
        d.fechada_em, JSON.stringify(d.extras), d.funil_id],
    );
  }

  async excluir(id: string) {
    await this.c.query('UPDATE pipeline_oportunidades SET deleted_at = now() WHERE id = $1 AND deleted_at IS NULL', [id]);
  }

  async registrarMovimento(oportunidadeId: string, de: string | null, para: string) {
    await this.c.query('INSERT INTO pipeline_movimentos (oportunidade_id, de_etapa_id, para_etapa_id, creator_id) VALUES ($1, $2, $3, nucleo_usuario_atual())', [oportunidadeId, de, para]);
  }

  async etapa(id: string) {
    return ref((await this.c.query(`SELECT ${REF} FROM pipeline_etapas WHERE id = $1 AND deleted_at IS NULL`, [id])).rows[0]);
  }

  async primeiraAberta(funilId: string) {
    return ref((await this.c.query(`SELECT ${REF} FROM pipeline_etapas WHERE funil_id = $1 AND tipo = 'aberta' AND deleted_at IS NULL ORDER BY ordem, nome LIMIT 1`, [funilId])).rows[0]);
  }

  async etapaFinal(funilId: string, tipo: 'ganho' | 'perdido') {
    return ref((await this.c.query(`SELECT ${REF} FROM pipeline_etapas WHERE funil_id = $1 AND tipo = $2 AND deleted_at IS NULL LIMIT 1`, [funilId, tipo])).rows[0]);
  }

  async funil(id: string) {
    const r = await this.c.query('SELECT id, arquivado FROM pipeline_funis WHERE id = $1 AND deleted_at IS NULL', [id]);
    return (r.rows[0] as { id: string; arquivado: boolean } | undefined) ?? null;
  }

  private async existe(sql: string, id: string): Promise<boolean> {
    return ((await this.c.query(sql, [id])).rowCount ?? 0) > 0;
  }

  /** Leitura da tabela publicada cadastros_parceiros (docs/CONTRATOS.md 7.1.1). */
  parceiroAtivo(id: string) { return this.existe("SELECT 1 FROM cadastros_parceiros WHERE id = $1 AND deleted_at IS NULL AND estado = 'ativo'", id); }
  usuarioExiste(id: string) { return this.existe('SELECT 1 FROM usuarios WHERE id = $1 AND deleted_at IS NULL', id); }
  equipeExiste(id: string) { return this.existe('SELECT 1 FROM pipeline_equipes WHERE id = $1 AND deleted_at IS NULL', id); }
  motivoAtivo(id: string) { return this.existe('SELECT 1 FROM pipeline_motivos_perda WHERE id = $1 AND ativo AND deleted_at IS NULL', id); }
  /** Leitura da tabela publicada cadastros_projetos. */
  projetoExiste(id: string) { return this.existe('SELECT 1 FROM cadastros_projetos WHERE id = $1 AND deleted_at IS NULL', id); }
}
