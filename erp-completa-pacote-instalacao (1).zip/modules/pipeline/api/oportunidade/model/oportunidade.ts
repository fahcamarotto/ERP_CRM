/**
 * Entidade Oportunidade (M2.1): titulo, parceiro, valor e moeda, responsavel, equipe, etapa, probabilidade,
 * origem, canal, UTM, previsao de fechamento e motivo de perda. Maquina de estados aberta, ganha e perdida.
 * Imutavel: toda alteracao devolve um clone novo.
 */
import { randomUUID } from 'node:crypto';
import { combinar, erroDe, fail, ok, type ErroDominio, type Result } from '../../compartilhado/result.ts';
import type { TipoEtapa } from '../../etapa/model/etapa.ts';
import { Dinheiro } from './dinheiro.ts';
import { Utm } from './utm.ts';

export const ESTADOS_OPORTUNIDADE = ['aberta', 'ganha', 'perdida'] as const;
export type EstadoOportunidade = (typeof ESTADOS_OPORTUNIDADE)[number];
export const CANAIS = ['site', 'whatsapp', 'instagram', 'indicacao', 'telefone', 'email', 'evento', 'outro'] as const;
export type Canal = (typeof CANAIS)[number];

/** Maquina de estados: fechada (ganha ou perdida) so volta para aberta pelo Reabrir. */
export const TRANSICOES: Record<EstadoOportunidade, EstadoOportunidade[]> = {
  aberta: ['ganha', 'perdida'],
  ganha: ['aberta'],
  perdida: ['aberta'],
};

/** Forma minima da etapa que a entidade precisa conhecer. */
export interface EtapaRef { id: string; tipo: TipoEtapa; probabilidade: number; funil_id: string }

export interface DadosOportunidade {
  titulo: string;
  parceiro_id?: string | null;
  valor?: number | null;
  moeda?: string;
  responsavel_id?: string | null;
  equipe_id?: string | null;
  probabilidade?: number | null;
  origem?: string | null;
  canal?: Canal | null;
  utm_source?: string | null;
  utm_medium?: string | null;
  utm_campaign?: string | null;
  previsao_fechamento?: string | null;
  extras?: Record<string, unknown>;
}

export interface OportunidadeDados {
  id: string;
  titulo: string;
  parceiro_id: string | null;
  valor: number;
  moeda: string;
  responsavel_id: string | null;
  equipe_id: string | null;
  funil_id: string;
  etapa_id: string;
  probabilidade: number;
  estado: EstadoOportunidade;
  origem: string | null;
  canal: Canal | null;
  utm_source: string | null;
  utm_medium: string | null;
  utm_campaign: string | null;
  previsao_fechamento: string | null;
  motivo_perda_id: string | null;
  motivo_perda_detalhe: string | null;
  projeto_id: string | null;
  lead_evento_id: string | null;
  etapa_desde: string;
  fechada_em: string | null;
  extras: Record<string, unknown>;
}

const t = (v?: string | null) => (v ?? '').trim() || null;
const dataValida = (v: string | null) => v === null || (/^\d{4}-\d{2}-\d{2}$/.test(v) && !Number.isNaN(Date.parse(v)));
const agoraIso = () => new Date().toISOString();

function validar(d: OportunidadeDados): ErroDominio[] {
  const e: ErroDominio[] = [];
  if (d.titulo.length < 2 || d.titulo.length > 200) e.push(erroDe('titulo_invalido', 'Titulo deve ter de 2 a 200 caracteres', 'titulo'));
  if (!Number.isInteger(d.probabilidade) || d.probabilidade < 0 || d.probabilidade > 100) e.push(erroDe('probabilidade_invalida', 'Probabilidade de 0 a 100', 'probabilidade'));
  if (d.canal !== null && !CANAIS.includes(d.canal)) e.push(erroDe('canal_invalido', `Canal deve ser: ${CANAIS.join(', ')}`, 'canal'));
  if (!dataValida(d.previsao_fechamento)) e.push(erroDe('data_invalida', 'Previsao de fechamento deve ser AAAA-MM-DD', 'previsao_fechamento'));
  if ((d.origem?.length ?? 0) > 60) e.push(erroDe('origem_invalida', 'Origem com no maximo 60 caracteres', 'origem'));
  return e;
}

/** Monta valor, moeda e UTM pelos objetos de valor e devolve todos os erros de uma vez. */
function montar(base: OportunidadeDados, e: Partial<DadosOportunidade>): Result<OportunidadeDados> {
  const tem = (k: keyof DadosOportunidade) => e[k] !== undefined;
  const r = combinar(
    Dinheiro.tryCreate(tem('valor') ? e.valor : base.valor, tem('moeda') ? e.moeda : base.moeda),
    Utm.tryCreate({
      utm_source: tem('utm_source') ? e.utm_source : base.utm_source,
      utm_medium: tem('utm_medium') ? e.utm_medium : base.utm_medium,
      utm_campaign: tem('utm_campaign') ? e.utm_campaign : base.utm_campaign,
    }),
  );
  const n: OportunidadeDados = {
    ...base,
    titulo: tem('titulo') ? (e.titulo ?? '').trim() : base.titulo,
    parceiro_id: tem('parceiro_id') ? t(e.parceiro_id) : base.parceiro_id,
    responsavel_id: tem('responsavel_id') ? t(e.responsavel_id) : base.responsavel_id,
    equipe_id: tem('equipe_id') ? t(e.equipe_id) : base.equipe_id,
    probabilidade: e.probabilidade !== undefined && e.probabilidade !== null ? Number(e.probabilidade) : base.probabilidade,
    origem: tem('origem') ? t(e.origem) : base.origem,
    canal: tem('canal') ? (t(e.canal) as Canal | null) : base.canal,
    previsao_fechamento: tem('previsao_fechamento') ? t(e.previsao_fechamento) : base.previsao_fechamento,
    extras: tem('extras') ? { ...e.extras } : { ...base.extras },
  };
  if (r.ok) { n.valor = r.valor[0].valor; n.moeda = r.valor[0].moeda; Object.assign(n, r.valor[1].dados); }
  const erros = [...(r.ok ? [] : r.erros), ...validar(n)];
  return erros.length ? fail(...erros) : ok(n);
}

export class Oportunidade {
  private constructor(private readonly d: OportunidadeDados) {}

  /** Nasce aberta numa etapa aberta; probabilidade padrao vem da etapa. */
  static tryCreate(e: DadosOportunidade & { lead_evento_id?: string | null }, etapa: EtapaRef, id: string = randomUUID()): Result<Oportunidade> {
    if (etapa.tipo !== 'aberta') return fail(erroDe('etapa_invalida', 'Oportunidade nova entra numa etapa aberta', 'etapa_id'));
    const base: OportunidadeDados = {
      id, titulo: '', parceiro_id: null, valor: 0, moeda: 'BRL', responsavel_id: null, equipe_id: null, funil_id: etapa.funil_id, etapa_id: etapa.id,
      probabilidade: etapa.probabilidade, estado: 'aberta', origem: null, canal: null, utm_source: null, utm_medium: null, utm_campaign: null,
      previsao_fechamento: null, motivo_perda_id: null, motivo_perda_detalhe: null, projeto_id: null, lead_evento_id: e.lead_evento_id ?? null,
      etapa_desde: agoraIso(), fechada_em: null, extras: {},
    };
    const r = montar(base, { ...e, titulo: e.titulo ?? '' });
    return r.ok ? ok(new Oportunidade(r.valor)) : r;
  }

  static create(e: DadosOportunidade & { lead_evento_id?: string | null }, etapa: EtapaRef, id?: string): Oportunidade {
    const r = Oportunidade.tryCreate(e, etapa, id);
    if (!r.ok) throw new Error(r.erros.map((x) => x.mensagem).join('; '));
    return r.valor;
  }

  static reidratar(d: OportunidadeDados): Oportunidade {
    return new Oportunidade({ ...d, extras: { ...d.extras } });
  }

  get id(): string { return this.d.id; }
  get estado(): EstadoOportunidade { return this.d.estado; }
  get etapaId(): string { return this.d.etapa_id; }
  get funilId(): string { return this.d.funil_id; }

  private exigirAberta(acao: string): ErroDominio | null {
    return this.d.estado === 'aberta' ? null
      : erroDe('transicao_invalida', `Oportunidade ${this.d.estado} nao pode ${acao}`, 'estado', { permitidas: TRANSICOES[this.d.estado] });
  }

  editar(e: Partial<DadosOportunidade>): Result<Oportunidade> {
    const bloq = this.exigirAberta('ser editada');
    if (bloq) return fail(bloq);
    const r = montar(this.d, e);
    return r.ok ? ok(new Oportunidade(r.valor)) : r;
  }

  /**
   * MoverEtapa: so entre etapas abertas; ganho e perda tem caso de uso proprio (motivo obrigatorio na perda).
   * Etapa de outro funil leva a oportunidade para aquele funil (arquivar pipeline movendo as abertas).
   */
  mover(etapa: EtapaRef, agora: string = agoraIso()): Result<Oportunidade> {
    const bloq = this.exigirAberta('mudar de etapa');
    if (bloq) return fail(bloq);
    if (etapa.tipo !== 'aberta') return fail(erroDe('etapa_final', 'Use marcar ganha ou marcar perdida para fechar a oportunidade', 'etapa_id', { tipo: etapa.tipo }));
    if (etapa.id === this.d.etapa_id) return fail(erroDe('mesma_etapa', 'A oportunidade ja esta nesta etapa', 'etapa_id'));
    return ok(new Oportunidade({ ...this.d, funil_id: etapa.funil_id, etapa_id: etapa.id, probabilidade: etapa.probabilidade, etapa_desde: agora }));
  }

  marcarGanha(etapaGanho: EtapaRef, agora: string = agoraIso()): Result<Oportunidade> {
    const bloq = this.exigirAberta('ser marcada como ganha');
    if (bloq) return fail(bloq);
    if (etapaGanho.tipo !== 'ganho' || etapaGanho.funil_id !== this.d.funil_id) return fail(erroDe('etapa_invalida', 'Etapa de ganho invalida', 'etapa_id'));
    return ok(new Oportunidade({ ...this.d, estado: 'ganha', etapa_id: etapaGanho.id, probabilidade: 100, etapa_desde: agora, fechada_em: agora, motivo_perda_id: null, motivo_perda_detalhe: null }));
  }

  marcarPerdida(etapaPerda: EtapaRef, motivoId: string | null | undefined, detalhe?: string | null, agora: string = agoraIso()): Result<Oportunidade> {
    const bloq = this.exigirAberta('ser marcada como perdida');
    if (bloq) return fail(bloq);
    if (!t(motivoId)) return fail(erroDe('motivo_obrigatorio', 'Informe o motivo da perda', 'motivo_perda_id'));
    if (etapaPerda.tipo !== 'perdido' || etapaPerda.funil_id !== this.d.funil_id) return fail(erroDe('etapa_invalida', 'Etapa de perda invalida', 'etapa_id'));
    const det = t(detalhe);
    if ((det?.length ?? 0) > 2000) return fail(erroDe('detalhe_invalido', 'Detalhe com no maximo 2000 caracteres', 'motivo_perda_detalhe'));
    return ok(new Oportunidade({ ...this.d, estado: 'perdida', etapa_id: etapaPerda.id, probabilidade: 0, etapa_desde: agora, fechada_em: agora, motivo_perda_id: t(motivoId), motivo_perda_detalhe: det }));
  }

  /** Volta uma oportunidade fechada para uma etapa aberta (erro de digitacao ou negociacao retomada). */
  reabrir(etapa: EtapaRef, agora: string = agoraIso()): Result<Oportunidade> {
    if (this.d.estado === 'aberta') return fail(erroDe('transicao_invalida', 'Oportunidade ja esta aberta', 'estado', { permitidas: TRANSICOES.aberta }));
    if (etapa.tipo !== 'aberta') return fail(erroDe('etapa_invalida', 'Reabrir exige uma etapa aberta', 'etapa_id'));
    return ok(new Oportunidade({ ...this.d, estado: 'aberta', funil_id: etapa.funil_id, etapa_id: etapa.id, probabilidade: etapa.probabilidade, etapa_desde: agora, fechada_em: null, motivo_perda_id: null, motivo_perda_detalhe: null }));
  }

  /** Liga o projeto do Cadastros criado a partir da oportunidade ganha (converter em projeto). */
  vincularProjeto(projetoId: string): Result<Oportunidade> {
    if (this.d.estado !== 'ganha') return fail(erroDe('transicao_invalida', 'So oportunidade ganha vira projeto', 'estado'));
    if (this.d.projeto_id) return fail(erroDe('conflito', 'Oportunidade ja convertida em projeto', 'projeto_id', { projeto_id: this.d.projeto_id }));
    return ok(new Oportunidade({ ...this.d, projeto_id: projetoId }));
  }

  paraDados(): OportunidadeDados {
    return { ...this.d, extras: { ...this.d.extras } };
  }
}
