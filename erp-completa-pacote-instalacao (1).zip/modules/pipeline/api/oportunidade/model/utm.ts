/** Objeto de valor Utm (M2.1): fonte, midia e campanha de origem, aparadas e com ate 120 caracteres cada. */
import { erroDe, fail, ok, type Result } from '../../compartilhado/result.ts';

export interface UtmDados {
  utm_source: string | null;
  utm_medium: string | null;
  utm_campaign: string | null;
}

const limpar = (v: unknown) => (typeof v === 'string' ? v.trim() : v === null || v === undefined ? '' : String(v).trim()) || null;

export class Utm {
  private constructor(readonly dados: UtmDados) {}

  static tryCreate(e: Partial<Record<keyof UtmDados, unknown>>): Result<Utm> {
    const d: UtmDados = { utm_source: limpar(e.utm_source), utm_medium: limpar(e.utm_medium), utm_campaign: limpar(e.utm_campaign) };
    const longo = (Object.keys(d) as (keyof UtmDados)[]).filter((k) => (d[k]?.length ?? 0) > 120);
    if (longo.length) return fail(...longo.map((k) => erroDe('utm_invalida', 'UTM com no maximo 120 caracteres', k)));
    return ok(new Utm(d));
  }

  static create(e: Partial<Record<keyof UtmDados, unknown>>): Utm {
    const r = Utm.tryCreate(e);
    if (!r.ok) throw new Error(r.erros[0]!.mensagem);
    return r.valor;
  }
}
