/** Portas do repositorio do agregado Oportunidade, segregadas por operacao. */
import type { EtapaRef, Oportunidade } from './oportunidade.ts';

export interface ObterOportunidade {
  obterPorId(id: string): Promise<Oportunidade | null>;
}

export interface GravarOportunidade {
  inserir(o: Oportunidade): Promise<void>;
  atualizar(o: Oportunidade): Promise<void>;
  excluir(id: string): Promise<void>;
  /** Linha em pipeline_movimentos (base da conversao por etapa). */
  registrarMovimento(oportunidadeId: string, de: string | null, para: string): Promise<void>;
}

/** Idempotencia do lead: um evento lead.recebido abre no maximo uma oportunidade. */
export interface BuscarPorLead {
  porLeadEvento(eventoId: string): Promise<Oportunidade | null>;
}

/** Oportunidade aberta de um cliente num funil (reacao a automacao: mover em vez de duplicar). */
export interface BuscarAbertaDoParceiro {
  abertaDoParceiro(parceiroId: string, funilId: string): Promise<Oportunidade | null>;
}

/** Etapas e funis vistos pela oportunidade. Primeira aberta e etapas finais sao sempre de um funil. */
export interface ConsultarEtapas {
  etapa(id: string): Promise<EtapaRef | null>;
  primeiraAberta(funilId: string): Promise<EtapaRef | null>;
  etapaFinal(funilId: string, tipo: 'ganho' | 'perdido'): Promise<EtapaRef | null>;
  /** Funil vivo (null quando nao existe). */
  funil(id: string): Promise<{ id: string; arquivado: boolean } | null>;
}

/** Referencias fora do agregado: parceiro e projeto do Cadastros (tabelas publicadas), usuarios, equipe e motivo. */
export interface ConsultarReferenciasOportunidade {
  parceiroAtivo(id: string): Promise<boolean>;
  usuarioExiste(id: string): Promise<boolean>;
  equipeExiste(id: string): Promise<boolean>;
  motivoAtivo(id: string): Promise<boolean>;
  projetoExiste(id: string): Promise<boolean>;
}
