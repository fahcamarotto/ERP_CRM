/** Objeto de valor Dinheiro: valor zero ou positivo com 2 casas e moeda ISO 4217. */
import { combinar, erroDe, fail, ok, type Result } from '../../compartilhado/result.ts';

export class Dinheiro {
  private constructor(readonly valor: number, readonly moeda: string) {}

  static tryCreate(valor: unknown, moeda: unknown = 'BRL'): Result<Dinheiro> {
    const n = valor === null || valor === undefined || valor === '' ? 0 : Number(valor);
    const m = String(moeda ?? 'BRL').trim().toUpperCase() || 'BRL';
    const rv: Result<number> = Number.isFinite(n) && n >= 0 && n < 1e12 ? ok(Math.round(n * 100) / 100) : fail(erroDe('valor_invalido', 'Valor deve ser zero ou positivo', 'valor'));
    const rm: Result<string> = /^[A-Z]{3}$/.test(m) ? ok(m) : fail(erroDe('moeda_invalida', 'Moeda em ISO 4217 (BRL, USD, EUR)', 'moeda'));
    const r = combinar(rv, rm);
    return r.ok ? ok(new Dinheiro(r.valor[0], r.valor[1])) : r;
  }

  static create(valor: unknown, moeda?: unknown): Dinheiro {
    const r = Dinheiro.tryCreate(valor, moeda);
    if (!r.ok) throw new Error(r.erros[0]!.mensagem);
    return r.valor;
  }
}
