/** Casos de uso EditarOportunidade e ExcluirOportunidade (exclusao logica). */
import { erroDe, fail, okVazio, type Result } from '../../compartilhado/result.ts';
import type { ContextoCaso } from '../../compartilhado/efeitos.ts';
import type { DadosOportunidade } from '../model/oportunidade.ts';
import type { ConsultarReferenciasOportunidade, GravarOportunidade, ObterOportunidade } from '../model/portas.ts';
import { conferirReferencias, TABELA } from './regras.ts';

export class EditarOportunidade {
  constructor(private readonly deps: { repo: ObterOportunidade & GravarOportunidade; refs: ConsultarReferenciasOportunidade }) {}
  async execute(ctx: ContextoCaso, e: { id: string } & Partial<DadosOportunidade>): Promise<Result<void>> {
    const { id, ...mud } = e;
    const atual = await this.deps.repo.obterPorId(id);
    if (!atual) return fail(erroDe('nao_encontrado', 'Oportunidade nao encontrada'));
    const r = atual.editar(mud);
    if (!r.ok) return r;
    const erros = await conferirReferencias(this.deps.refs, r.valor, atual);
    if (erros.length) return fail(...erros);
    await this.deps.repo.atualizar(r.valor);
    const antes = atual.paraDados() as unknown as Record<string, unknown>;
    const depois = r.valor.paraDados() as unknown as Record<string, unknown>;
    await ctx.efeitos.historico(TABELA, id, antes, depois);
    await ctx.efeitos.auditar('oportunidade.editar', TABELA, id, antes, depois);
    return okVazio();
  }
}

export class ExcluirOportunidade {
  constructor(private readonly deps: { repo: ObterOportunidade & GravarOportunidade }) {}
  async execute(ctx: ContextoCaso, e: { id: string }): Promise<Result<void>> {
    const atual = await this.deps.repo.obterPorId(e.id);
    if (!atual) return fail(erroDe('nao_encontrado', 'Oportunidade nao encontrada'));
    await this.deps.repo.excluir(e.id);
    await ctx.efeitos.auditar('oportunidade.excluir', TABELA, e.id, atual.paraDados());
    return okVazio();
  }
}
