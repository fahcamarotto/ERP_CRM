/** Regras compartilhadas pelos casos de uso da Oportunidade: conferir referencias e montar o payload dos eventos. */
import { erroDe, type ErroDominio } from '../../compartilhado/result.ts';
import type { Oportunidade } from '../model/oportunidade.ts';
import type { ConsultarReferenciasOportunidade } from '../model/portas.ts';

export const TABELA = 'pipeline_oportunidades';

/** Confere so o que mudou (na criacao, tudo que veio preenchido). */
export async function conferirReferencias(refs: ConsultarReferenciasOportunidade, o: Oportunidade, anterior?: Oportunidade): Promise<ErroDominio[]> {
  const d = o.paraDados();
  const a = anterior?.paraDados();
  const erros: ErroDominio[] = [];
  if (d.parceiro_id && d.parceiro_id !== a?.parceiro_id && !(await refs.parceiroAtivo(d.parceiro_id))) {
    erros.push(erroDe('cliente_invalido', 'Cliente nao encontrado ou arquivado', 'parceiro_id'));
  }
  if (d.responsavel_id && d.responsavel_id !== a?.responsavel_id && !(await refs.usuarioExiste(d.responsavel_id))) {
    erros.push(erroDe('usuario_invalido', 'Responsavel nao encontrado', 'responsavel_id'));
  }
  if (d.equipe_id && d.equipe_id !== a?.equipe_id && !(await refs.equipeExiste(d.equipe_id))) {
    erros.push(erroDe('equipe_invalida', 'Equipe nao encontrada', 'equipe_id'));
  }
  return erros;
}

/** Payload de oportunidade.criada (contrato em docs/CONTRATOS.md 7.1.2). */
export function dadosCriada(o: Oportunidade) {
  const d = o.paraDados();
  return {
    id: d.id, titulo: d.titulo, parceiro_id: d.parceiro_id, valor: d.valor, moeda: d.moeda, funil_id: d.funil_id, etapa_id: d.etapa_id,
    responsavel_id: d.responsavel_id, equipe_id: d.equipe_id, origem: d.origem, canal: d.canal,
    utm: { source: d.utm_source, medium: d.utm_medium, campaign: d.utm_campaign }, lead_evento_id: d.lead_evento_id,
  };
}
