/**
 * Caso de uso AplicarOportunidadeDeAutomacao: reacao a automacao.oportunidade_solicitada do modulo Automacoes
 * (handler pipeline:ao:automacao.oportunidade_solicitada). Move a oportunidade aberta do cliente no funil da etapa
 * pedida; sem oportunidade aberta, cria uma ja nessa etapa. Idempotente pelo id do evento (lead_evento_id).
 */
import { ok, type Result } from '../../compartilhado/result.ts';
import type { ContextoCaso } from '../../compartilhado/efeitos.ts';
import type { BuscarAbertaDoParceiro, BuscarPorLead, ConsultarEtapas } from '../model/portas.ts';
import type { CriarOportunidade } from './criar-oportunidade.ts';
import type { MoverEtapa } from './mover-etapa.ts';

/** Payload do evento (docs/CONTRATOS.md, eventos do Automacoes). */
export interface EventoAutomacao {
  id: string;
  dados: { parceiro_id: string; etapa_id: string; funil_id?: string | null; titulo?: string | null; canal?: string | null; fluxo_id?: string | null };
}

export class AplicarOportunidadeDeAutomacao {
  constructor(private readonly d: { repo: BuscarPorLead & BuscarAbertaDoParceiro; etapas: ConsultarEtapas; criar: Pick<CriarOportunidade, 'execute'>; mover: Pick<MoverEtapa, 'execute'> }) {}

  async execute(ctx: ContextoCaso, ev: EventoAutomacao): Promise<Result<{ id: string | null; acao: 'criada' | 'movida' | 'mantida' | 'ignorada' }>> {
    const ja = await this.d.repo.porLeadEvento(ev.id);
    if (ja) return ok({ id: ja.id, acao: 'mantida' });
    const etapa = await this.d.etapas.etapa(ev.dados.etapa_id);
    if (!etapa) return ok({ id: null, acao: 'ignorada' });
    const aberta = await this.d.repo.abertaDoParceiro(ev.dados.parceiro_id, etapa.funil_id);
    if (aberta) {
      if (aberta.etapaId === etapa.id) return ok({ id: aberta.id, acao: 'mantida' });
      const r = await this.d.mover.execute(ctx, { id: aberta.id, etapa_id: etapa.id });
      if (!r.ok) return r;
      await ctx.efeitos.nota('pipeline_oportunidades', aberta.id, 'Etapa alterada por uma automacao de atendimento.');
      return ok({ id: aberta.id, acao: 'movida' });
    }
    const canal = ev.dados.canal === 'whatsapp' || ev.dados.canal === 'instagram' ? ev.dados.canal : 'outro';
    const r = await this.d.criar.execute(ctx, {
      titulo: (ev.dados.titulo || 'Automacao').slice(0, 200), parceiro_id: ev.dados.parceiro_id, etapa_id: etapa.id, origem: `automacao_${canal}`, canal, lead_evento_id: ev.id,
    });
    if (!r.ok) return r;
    return ok({ id: r.valor.id, acao: 'criada' });
  }
}
