/**
 * Casos de uso MarcarGanha e MarcarPerdida (M2.5) e VincularProjeto.
 * Converter em projeto: a tela cria o projeto pela interface publicada do Cadastros (POST /api/v1/cadastros/projetos,
 * tool projetos.criar) e liga o id aqui; o Pipeline nunca escreve em tabela do Cadastros.
 */
import { erroDe, fail, okVazio, type Result } from '../../compartilhado/result.ts';
import type { ContextoCaso } from '../../compartilhado/efeitos.ts';
import type { ConsultarEtapas, ConsultarReferenciasOportunidade, GravarOportunidade, ObterOportunidade } from '../model/portas.ts';
import { TABELA } from './regras.ts';

type Deps = { repo: ObterOportunidade & GravarOportunidade; etapas: ConsultarEtapas; refs: ConsultarReferenciasOportunidade };

export class MarcarGanha {
  constructor(private readonly deps: Deps) {}
  async execute(ctx: ContextoCaso, e: { id: string; converter_em_projeto?: boolean }): Promise<Result<void>> {
    const atual = await this.deps.repo.obterPorId(e.id);
    if (!atual) return fail(erroDe('nao_encontrado', 'Oportunidade nao encontrada'));
    const etapa = await this.deps.etapas.etapaFinal(atual.funilId, 'ganho');
    if (!etapa) return fail(erroDe('etapa_invalida', 'O funil nao tem etapa de ganho', 'etapa_id'));
    const r = atual.marcarGanha(etapa);
    if (!r.ok) return r;
    await this.deps.repo.atualizar(r.valor);
    await this.deps.repo.registrarMovimento(e.id, atual.etapaId, etapa.id);
    const d = r.valor.paraDados();
    await ctx.efeitos.historico(TABELA, e.id, { estado: atual.estado, etapa_id: atual.etapaId }, { estado: d.estado, etapa_id: d.etapa_id });
    await ctx.efeitos.auditar('oportunidade.ganhar', TABELA, e.id, { estado: atual.estado }, { estado: d.estado });
    await ctx.efeitos.publicar('oportunidade.ganha', {
      id: d.id, titulo: d.titulo, parceiro_id: d.parceiro_id, valor: d.valor, moeda: d.moeda, responsavel_id: d.responsavel_id,
      equipe_id: d.equipe_id, fechada_em: d.fechada_em, converter_em_projeto: !!e.converter_em_projeto,
    });
    return okVazio();
  }
}

export class MarcarPerdida {
  constructor(private readonly deps: Deps) {}
  async execute(ctx: ContextoCaso, e: { id: string; motivo_perda_id: string; motivo_perda_detalhe?: string | null }): Promise<Result<void>> {
    const atual = await this.deps.repo.obterPorId(e.id);
    if (!atual) return fail(erroDe('nao_encontrado', 'Oportunidade nao encontrada'));
    const etapa = await this.deps.etapas.etapaFinal(atual.funilId, 'perdido');
    if (!etapa) return fail(erroDe('etapa_invalida', 'O funil nao tem etapa de perda', 'etapa_id'));
    const r = atual.marcarPerdida(etapa, e.motivo_perda_id, e.motivo_perda_detalhe);
    if (!r.ok) return r;
    if (!(await this.deps.refs.motivoAtivo(e.motivo_perda_id))) return fail(erroDe('motivo_invalido', 'Motivo de perda nao encontrado ou inativo', 'motivo_perda_id'));
    await this.deps.repo.atualizar(r.valor);
    await this.deps.repo.registrarMovimento(e.id, atual.etapaId, etapa.id);
    const d = r.valor.paraDados();
    await ctx.efeitos.historico(TABELA, e.id, { estado: atual.estado, etapa_id: atual.etapaId }, { estado: d.estado, etapa_id: d.etapa_id, motivo_perda_id: d.motivo_perda_id });
    await ctx.efeitos.auditar('oportunidade.perder', TABELA, e.id, { estado: atual.estado }, { estado: d.estado, motivo_perda_id: d.motivo_perda_id });
    await ctx.efeitos.publicar('oportunidade.perdida', {
      id: d.id, titulo: d.titulo, parceiro_id: d.parceiro_id, valor: d.valor, moeda: d.moeda, motivo_perda_id: d.motivo_perda_id, fechada_em: d.fechada_em,
    });
    return okVazio();
  }
}

export class VincularProjeto {
  constructor(private readonly deps: { repo: ObterOportunidade & GravarOportunidade; refs: ConsultarReferenciasOportunidade }) {}
  async execute(ctx: ContextoCaso, e: { id: string; projeto_id: string }): Promise<Result<void>> {
    const atual = await this.deps.repo.obterPorId(e.id);
    if (!atual) return fail(erroDe('nao_encontrado', 'Oportunidade nao encontrada'));
    const r = atual.vincularProjeto(e.projeto_id);
    if (!r.ok) return r;
    if (!(await this.deps.refs.projetoExiste(e.projeto_id))) return fail(erroDe('projeto_invalido', 'Projeto nao encontrado no Cadastros', 'projeto_id'));
    await this.deps.repo.atualizar(r.valor);
    await ctx.efeitos.historico(TABELA, e.id, { projeto_id: null }, { projeto_id: e.projeto_id });
    await ctx.efeitos.auditar('oportunidade.converter_projeto', TABELA, e.id, undefined, { projeto_id: e.projeto_id });
    return okVazio();
  }
}
