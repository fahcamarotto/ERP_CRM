/** Casos de uso MoverEtapa (M2.5) e Reabrir: mudam a etapa aberta e gravam o movimento para a conversao por etapa. */
import { erroDe, fail, okVazio, type Result } from '../../compartilhado/result.ts';
import type { ContextoCaso } from '../../compartilhado/efeitos.ts';
import type { ConsultarEtapas, GravarOportunidade, ObterOportunidade } from '../model/portas.ts';
import { TABELA } from './regras.ts';

type Deps = { repo: ObterOportunidade & GravarOportunidade; etapas: ConsultarEtapas };

export class MoverEtapa {
  constructor(private readonly deps: Deps) {}
  async execute(ctx: ContextoCaso, e: { id: string; etapa_id: string }): Promise<Result<void>> {
    const atual = await this.deps.repo.obterPorId(e.id);
    if (!atual) return fail(erroDe('nao_encontrado', 'Oportunidade nao encontrada'));
    const etapa = await this.deps.etapas.etapa(e.etapa_id);
    if (!etapa) return fail(erroDe('etapa_invalida', 'Etapa nao encontrada', 'etapa_id'));
    if (etapa.funil_id !== atual.funilId && (await this.deps.etapas.funil(etapa.funil_id))?.arquivado) {
      return fail(erroDe('funil_arquivado', 'Pipeline arquivado nao recebe oportunidades', 'etapa_id'));
    }
    const r = atual.mover(etapa);
    if (!r.ok) return r;
    await this.deps.repo.atualizar(r.valor);
    await this.deps.repo.registrarMovimento(e.id, atual.etapaId, etapa.id);
    const de = { funil_id: atual.funilId, etapa_id: atual.etapaId, probabilidade: atual.paraDados().probabilidade };
    const para = { funil_id: etapa.funil_id, etapa_id: etapa.id, probabilidade: r.valor.paraDados().probabilidade };
    await ctx.efeitos.historico(TABELA, e.id, de, para);
    await ctx.efeitos.auditar('oportunidade.mover', TABELA, e.id, de, para);
    await ctx.efeitos.publicar('oportunidade.movida', {
      id: e.id, de_etapa_id: atual.etapaId, para_etapa_id: etapa.id, probabilidade: para.probabilidade, reaberta: false, de_funil_id: atual.funilId, para_funil_id: etapa.funil_id,
    });
    return okVazio();
  }
}

export class ReabrirOportunidade {
  constructor(private readonly deps: Deps) {}
  async execute(ctx: ContextoCaso, e: { id: string; etapa_id?: string | null }): Promise<Result<void>> {
    const atual = await this.deps.repo.obterPorId(e.id);
    if (!atual) return fail(erroDe('nao_encontrado', 'Oportunidade nao encontrada'));
    const etapa = e.etapa_id ? await this.deps.etapas.etapa(e.etapa_id) : await this.deps.etapas.primeiraAberta(atual.funilId);
    if (!etapa) return fail(erroDe('etapa_invalida', 'Etapa nao encontrada', 'etapa_id'));
    const r = atual.reabrir(etapa);
    if (!r.ok) return r;
    await this.deps.repo.atualizar(r.valor);
    await this.deps.repo.registrarMovimento(e.id, atual.etapaId, etapa.id);
    await ctx.efeitos.historico(TABELA, e.id, { estado: atual.estado, etapa_id: atual.etapaId }, { estado: 'aberta', etapa_id: etapa.id });
    await ctx.efeitos.auditar('oportunidade.reabrir', TABELA, e.id, { estado: atual.estado }, { estado: 'aberta' });
    await ctx.efeitos.publicar('oportunidade.movida', {
      id: e.id, de_etapa_id: atual.etapaId, para_etapa_id: etapa.id, probabilidade: etapa.probabilidade, reaberta: true, de_funil_id: atual.funilId, para_funil_id: etapa.funil_id,
    });
    return okVazio();
  }
}
