/**
 * Caso de uso AbrirOportunidadeDeLead: reacao a lead.recebido do Cadastros (handler pipeline:ao:lead.recebido).
 * Idempotente pelo id do evento: o mesmo lead entregue duas vezes abre uma unica oportunidade.
 */
import { ok, type Result } from '../../compartilhado/result.ts';
import type { ContextoCaso } from '../../compartilhado/efeitos.ts';
import type { BuscarPorLead, ConsultarEtapas } from '../model/portas.ts';
import type { CriarOportunidade } from './criar-oportunidade.ts';

/** Payload do evento (docs/CONTRATOS.md 7.1.1, lead.recebido). */
export interface EventoLead {
  id: string;
  dados: {
    parceiro_id: string;
    nome?: string | null;
    empresa?: string | null;
    mensagem?: string | null;
    origem?: string | null;
    utm?: { source?: string | null; medium?: string | null; campaign?: string | null } | null;
    /** Fonte de lead (landing page) e o destino escolhido nela; sem destino vale o pipeline padrao, primeira etapa. */
    canal?: string | null;
    fonte_id?: string | null;
    funil_id?: string | null;
    etapa_id?: string | null;
    responsavel_id?: string | null;
  };
}

type MotivoDestino = 'etapa_removida' | 'etapa_fechada' | 'etapa_de_outro_pipeline' | 'pipeline_removido' | 'pipeline_arquivado';
const CANAIS = new Set(['site', 'whatsapp', 'instagram', 'indicacao', 'email']);

/** Destino pedido pela fonte, ou o motivo para cair no pipeline padrao (etapa ou pipeline removido ou arquivado). */
async function destinoDoLead(etapas: ConsultarEtapas, d: EventoLead['dados']): Promise<{ funil_id?: string; etapa_id?: string } | { motivo: MotivoDestino }> {
  if (d.etapa_id) {
    const e = await etapas.etapa(d.etapa_id);
    if (!e) return { motivo: 'etapa_removida' };
    if (e.tipo !== 'aberta') return { motivo: 'etapa_fechada' };
    if (d.funil_id && d.funil_id !== e.funil_id) return { motivo: 'etapa_de_outro_pipeline' };
    const f = await etapas.funil(e.funil_id);
    if (!f) return { motivo: 'pipeline_removido' };
    if (f.arquivado) return { motivo: 'pipeline_arquivado' };
    return { etapa_id: e.id };
  }
  if (d.funil_id) {
    const f = await etapas.funil(d.funil_id);
    if (!f) return { motivo: 'pipeline_removido' };
    if (f.arquivado) return { motivo: 'pipeline_arquivado' };
    return { funil_id: f.id };
  }
  return {};
}

const CANAL_POR_ORIGEM: Record<string, 'site' | 'whatsapp' | 'instagram' | 'indicacao' | 'email'> = {
  landing: 'site', site: 'site', whatsapp: 'whatsapp', instagram: 'instagram', indicacao: 'indicacao', email: 'email',
};

export class AbrirOportunidadeDeLead {
  constructor(private readonly deps: { repo: BuscarPorLead; etapas: ConsultarEtapas; criar: Pick<CriarOportunidade, 'execute'> }) {}

  async execute(ctx: ContextoCaso, ev: EventoLead): Promise<Result<{ id: string; nova: boolean; substituido: MotivoDestino | null }>> {
    const ja = await this.deps.repo.porLeadEvento(ev.id);
    if (ja) return ok({ id: ja.id, nova: false, substituido: null });
    const d = ev.dados;
    const quem = (d.empresa || d.nome || 'Lead').toString().trim();
    const origem = (d.origem ?? 'landing').slice(0, 60);
    const canal: 'site' | 'whatsapp' | 'instagram' | 'indicacao' | 'email' | 'outro' = d.canal && CANAIS.has(d.canal) ? d.canal as 'site' : CANAL_POR_ORIGEM[origem.toLowerCase()] ?? 'outro';
    const destino = await destinoDoLead(this.deps.etapas, d);
    const motivo = 'motivo' in destino ? destino.motivo : null;
    const base = {
      titulo: `Lead: ${quem}`.slice(0, 200), parceiro_id: d.parceiro_id, origem, canal,
      utm_source: d.utm?.source ?? null, utm_medium: d.utm?.medium ?? null, utm_campaign: d.utm?.campaign ?? null, lead_evento_id: ev.id,
      ...(motivo ? {} : destino as { funil_id?: string; etapa_id?: string }),
    };
    let r = await this.deps.criar.execute(ctx, { ...base, responsavel_id: d.responsavel_id ?? null });
    // Responsavel que deixou de existir nao trava o lead: abre sem responsavel.
    if (!r.ok && d.responsavel_id && r.erros.some((e) => e.campo === 'responsavel_id')) r = await this.deps.criar.execute(ctx, base);
    if (!r.ok) return r;
    if (d.mensagem) await ctx.efeitos.nota('pipeline_oportunidades', r.valor.id, `Mensagem do lead: ${d.mensagem.slice(0, 2000)}`);
    if (motivo) {
      await ctx.efeitos.nota('pipeline_oportunidades', r.valor.id, `Destino da fonte "${origem}" indisponivel (${motivo}): aberta na primeira etapa do pipeline padrao.`);
      await ctx.efeitos.publicar('lead.destino_substituido', {
        fonte_id: d.fonte_id ?? null, oportunidade_id: r.valor.id, motivo, funil_id: d.funil_id ?? null, etapa_id: d.etapa_id ?? null, origem,
      });
    }
    return ok({ id: r.valor.id, nova: true, substituido: motivo });
  }
}

/** Payload de conversa.oportunidade_solicitada (docs/CONTRATOS.md, eventos do Conversas). */
export interface EventoConversa {
  id: string;
  dados: {
    conversa_id: string;
    parceiro_id: string;
    titulo: string;
    valor?: number | null;
    moeda?: string | null;
    canal?: string | null;
    atendente_id?: string | null;
    origem?: string | null;
  };
}

/**
 * Caso de uso AbrirOportunidadeDeConversa: reacao a conversa.oportunidade_solicitada (handler
 * pipeline:ao:conversa.oportunidade_solicitada). Abre no funil padrao, primeira etapa. Idempotente pelo id do evento
 * (gravado em lead_evento_id, a mesma chave de origem do lead).
 */
export class AbrirOportunidadeDeConversa {
  constructor(private readonly deps: { repo: BuscarPorLead; criar: Pick<CriarOportunidade, 'execute'> }) {}

  async execute(ctx: ContextoCaso, ev: EventoConversa): Promise<Result<{ id: string; nova: boolean }>> {
    const ja = await this.deps.repo.porLeadEvento(ev.id);
    if (ja) return ok({ id: ja.id, nova: false });
    const d = ev.dados;
    const canal = d.canal === 'whatsapp' || d.canal === 'instagram' ? d.canal : 'outro';
    const r = await this.deps.criar.execute(ctx, {
      titulo: d.titulo, parceiro_id: d.parceiro_id, valor: d.valor ?? null, moeda: d.moeda ?? 'BRL', responsavel_id: d.atendente_id ?? null,
      origem: (d.origem ?? `conversa_${canal}`).slice(0, 60), canal, lead_evento_id: ev.id,
    });
    if (!r.ok) return r;
    await ctx.efeitos.nota('pipeline_oportunidades', r.valor.id, 'Oportunidade aberta a partir de uma conversa do atendimento.');
    return ok({ id: r.valor.id, nova: true });
  }
}
