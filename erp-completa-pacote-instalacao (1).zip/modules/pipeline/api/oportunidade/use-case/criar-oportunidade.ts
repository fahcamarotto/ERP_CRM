/**
 * Caso de uso CriarOportunidade (M2.5): nasce aberta na etapa informada ou na primeira etapa aberta do funil
 * informado; sem funil nem etapa, no funil padrao do workspace (o que outros modulos e o lead usam).
 */
import { erroDe, fail, ok, type Result } from '../../compartilhado/result.ts';
import type { ContextoCaso } from '../../compartilhado/efeitos.ts';
import { Oportunidade, type DadosOportunidade, type EtapaRef } from '../model/oportunidade.ts';
import type { ConsultarEtapas, ConsultarReferenciasOportunidade, GravarOportunidade, ObterOportunidade } from '../model/portas.ts';
import { conferirReferencias, dadosCriada, TABELA } from './regras.ts';

export type EntradaCriarOportunidade = DadosOportunidade & { funil_id?: string | null; etapa_id?: string | null; lead_evento_id?: string | null };

export interface DepsCriarOportunidade {
  repo: ObterOportunidade & GravarOportunidade;
  etapas: ConsultarEtapas;
  refs: ConsultarReferenciasOportunidade;
  /** ResolverFunil: o funil informado ou o padrao (workspace sem funil recebe o padrao com etapas antes da primeira oportunidade). */
  funil: { execute(ctx: ContextoCaso | null, funilId?: string | null): Promise<Result<{ id: string; arquivado: boolean }>> };
}

export class CriarOportunidade {
  constructor(private readonly deps: DepsCriarOportunidade) {}

  async execute(ctx: ContextoCaso, e: EntradaCriarOportunidade): Promise<Result<{ id: string }>> {
    let etapa: EtapaRef | null;
    if (e.etapa_id) {
      etapa = await this.deps.etapas.etapa(e.etapa_id);
      if (!etapa) return fail(erroDe('etapa_invalida', 'Etapa nao encontrada', 'etapa_id'));
      if (e.funil_id && e.funil_id !== etapa.funil_id) return fail(erroDe('etapa_invalida', 'A etapa e de outro pipeline', 'etapa_id'));
      const f = await this.deps.etapas.funil(etapa.funil_id);
      if (f?.arquivado) return fail(erroDe('funil_arquivado', 'Pipeline arquivado nao recebe oportunidades', 'funil_id'));
    } else {
      const f = await this.deps.funil.execute(ctx, e.funil_id ?? null);
      if (!f.ok) return f;
      if (f.valor.arquivado) return fail(erroDe('funil_arquivado', 'Pipeline arquivado nao recebe oportunidades', 'funil_id'));
      etapa = await this.deps.etapas.primeiraAberta(f.valor.id);
      if (!etapa) return fail(erroDe('etapa_invalida', 'O pipeline nao tem etapa aberta', 'etapa_id'));
    }
    const { etapa_id: _ignorada, funil_id: _funil, ...dados } = e;
    const r = Oportunidade.tryCreate(dados, etapa);
    if (!r.ok) return r;
    const erros = await conferirReferencias(this.deps.refs, r.valor);
    if (erros.length) return fail(...erros);
    await this.deps.repo.inserir(r.valor);
    await this.deps.repo.registrarMovimento(r.valor.id, null, etapa.id);
    const d = r.valor.paraDados();
    await ctx.efeitos.auditar('oportunidade.criar', TABELA, d.id, undefined, d);
    await ctx.efeitos.publicar('oportunidade.criada', dadosCriada(r.valor));
    return ok({ id: d.id });
  }
}
