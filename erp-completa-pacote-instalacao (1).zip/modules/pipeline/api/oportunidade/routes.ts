/** Rotas REST da Oportunidade fora das tools: editar, excluir, reabrir, ligar projeto e opcoes dos seletores. */
import { esquemaErro, requer, type FastifyInstance } from '@erp/api/sdk';
import { naTransacao, naoEncontrado } from '../borda.ts';
import { exigirOk } from '../compartilhado/result.ts';
import { propsOportunidade, uuid } from '../esquemas.ts';
import type { DadosOportunidade } from './model/oportunidade.ts';
import { obterOportunidade } from './query/oportunidades.ts';

const tags = ['pipeline'];
const erros = { 400: esquemaErro, 404: esquemaErro, 409: esquemaErro };
const paramId = { type: 'object', required: ['id'], properties: { id: uuid } } as const;

export function rotasOportunidade(app: FastifyInstance): void {
  // Leitura da tabela publicada do nucleo `usuarios`: opcoes de responsavel, lider, membro e vendedor.
  app.get('/responsaveis', {
    preHandler: requer('pipeline.ver'),
    schema: { tags, summary: 'Usuarios ativos do workspace (responsavel, lider, membro e vendedor)' },
  }, (req) => naTransacao(req, async (_, __, c) => (await c.query('SELECT id, nome FROM usuarios WHERE ativo AND deleted_at IS NULL ORDER BY nome')).rows));

  // Leitura da tabela publicada cadastros_parceiros (docs/CONTRATOS.md 7.1.1): seletor de clientes.
  app.get('/clientes', {
    preHandler: requer('pipeline.ver'),
    schema: { tags, summary: 'Clientes ativos do Cadastros (seletor da oportunidade)' },
  }, (req) => naTransacao(req, async (_, __, c) => (await c.query(
    "SELECT id, coalesce(nome_fantasia, nome) AS nome FROM cadastros_parceiros WHERE e_cliente AND estado = 'ativo' AND deleted_at IS NULL ORDER BY nome LIMIT 500",
  )).rows));

  app.patch<{ Params: { id: string }; Body: Partial<DadosOportunidade> }>('/oportunidades/:id', {
    preHandler: requer('pipeline.editar'),
    schema: { tags, summary: 'Edita oportunidade aberta (EditarOportunidade)', params: paramId, body: { type: 'object', additionalProperties: false, properties: propsOportunidade }, response: erros },
  }, (req) => naTransacao(req, async (casos, ctx, c) => {
    exigirOk(await casos.editarOportunidade.execute(ctx, { ...req.body, id: req.params.id }));
    return obterOportunidade(c, req.params.id);
  }));

  app.delete<{ Params: { id: string } }>('/oportunidades/:id', {
    preHandler: requer('pipeline.excluir'),
    schema: { tags, summary: 'Exclui oportunidade (exclusao logica)', params: paramId, response: erros },
  }, async (req, reply) => {
    await naTransacao(req, async (casos, ctx) => exigirOk(await casos.excluirOportunidade.execute(ctx, { id: req.params.id })));
    return reply.code(204).send();
  });

  app.post<{ Params: { id: string }; Body: { etapa_id?: string | null } }>('/oportunidades/:id/reabrir', {
    preHandler: requer('pipeline.editar'),
    schema: { tags, summary: 'Reabre oportunidade ganha ou perdida (ReabrirOportunidade)', params: paramId, body: { type: 'object', additionalProperties: false, properties: { etapa_id: { type: ['string', 'null'], format: 'uuid' } } }, response: erros },
  }, (req) => naTransacao(req, async (casos, ctx, c) => {
    exigirOk(await casos.reabrirOportunidade.execute(ctx, { id: req.params.id, etapa_id: req.body?.etapa_id ?? null }));
    return obterOportunidade(c, req.params.id);
  }));

  app.post<{ Params: { id: string }; Body: { projeto_id: string } }>('/oportunidades/:id/projeto', {
    preHandler: requer('pipeline.editar'),
    schema: { tags, summary: 'Liga o projeto do Cadastros criado a partir da oportunidade ganha (VincularProjeto)', params: paramId, body: { type: 'object', additionalProperties: false, required: ['projeto_id'], properties: { projeto_id: uuid } }, response: erros },
  }, (req) => naTransacao(req, async (casos, ctx, c) => {
    exigirOk(await casos.vincularProjeto.execute(ctx, { id: req.params.id, projeto_id: req.body.projeto_id }));
    return (await obterOportunidade(c, req.params.id)) ?? Promise.reject(naoEncontrado('Oportunidade nao encontrada'));
  }));
}
