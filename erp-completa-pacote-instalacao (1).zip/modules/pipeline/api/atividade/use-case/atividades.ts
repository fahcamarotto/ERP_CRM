/** Casos de uso das Atividades (M2.5): AgendarAtividade, EditarAtividade, ConcluirAtividade e CancelarAtividade. */
import { erroDe, fail, ok, okVazio, type ErroDominio, type Result } from '../../compartilhado/result.ts';
import type { ContextoCaso } from '../../compartilhado/efeitos.ts';
import { Atividade, type DadosAtividade } from '../model/atividade.ts';
import type { ConsultarReferenciasAtividade, GravarAtividade, ObterAtividade } from '../model/portas.ts';

const TABELA = 'pipeline_atividades';
type Deps = { repo: ObterAtividade & GravarAtividade; refs: ConsultarReferenciasAtividade };

async function conferir(refs: ConsultarReferenciasAtividade, a: Atividade, anterior?: Atividade): Promise<ErroDominio[]> {
  const d = a.paraDados();
  const x = anterior?.paraDados();
  const erros: ErroDominio[] = [];
  if (d.oportunidade_id && d.oportunidade_id !== x?.oportunidade_id && !(await refs.oportunidadeExiste(d.oportunidade_id))) {
    erros.push(erroDe('oportunidade_invalida', 'Oportunidade nao encontrada', 'oportunidade_id'));
  }
  if (d.responsavel_id && d.responsavel_id !== x?.responsavel_id && !(await refs.usuarioExiste(d.responsavel_id))) {
    erros.push(erroDe('usuario_invalido', 'Responsavel nao encontrado', 'responsavel_id'));
  }
  return erros;
}

/** Payload de atividade.agendada e atividade.concluida (a Agenda cria o compromisso quando instalada). */
const dadosEvento = (a: Atividade) => {
  const d = a.paraDados();
  return { id: d.id, tipo: d.tipo, titulo: d.titulo, data: d.data, duracao_min: d.duracao_min, responsavel_id: d.responsavel_id, oportunidade_id: d.oportunidade_id, estado: d.estado };
};

export class AgendarAtividade {
  constructor(private readonly deps: Deps) {}
  async execute(ctx: ContextoCaso, e: DadosAtividade): Promise<Result<{ id: string }>> {
    const r = Atividade.tryCreate({ ...e, responsavel_id: e.responsavel_id === undefined ? (ctx.ator.tipo === 'usuario' ? ctx.ator.id : null) : e.responsavel_id });
    if (!r.ok) return r;
    const erros = await conferir(this.deps.refs, r.valor);
    if (erros.length) return fail(...erros);
    await this.deps.repo.inserir(r.valor);
    const d = r.valor.paraDados();
    await ctx.efeitos.auditar('atividade.agendar', TABELA, d.id, undefined, d);
    if (d.oportunidade_id) await ctx.efeitos.nota('pipeline_oportunidades', d.oportunidade_id, `Atividade agendada (${d.tipo}): ${d.titulo}`);
    await ctx.efeitos.publicar('atividade.agendada', dadosEvento(r.valor));
    return ok({ id: d.id });
  }
}

export class EditarAtividade {
  constructor(private readonly deps: Deps) {}
  async execute(ctx: ContextoCaso, e: { id: string } & Partial<DadosAtividade>): Promise<Result<void>> {
    const { id, ...mud } = e;
    const atual = await this.deps.repo.obterPorId(id);
    if (!atual) return fail(erroDe('nao_encontrado', 'Atividade nao encontrada'));
    const r = atual.editar(mud);
    if (!r.ok) return r;
    const erros = await conferir(this.deps.refs, r.valor, atual);
    if (erros.length) return fail(...erros);
    await this.deps.repo.atualizar(r.valor);
    const antes = atual.paraDados() as unknown as Record<string, unknown>;
    const depois = r.valor.paraDados() as unknown as Record<string, unknown>;
    await ctx.efeitos.historico(TABELA, id, antes, depois);
    await ctx.efeitos.auditar('atividade.editar', TABELA, id, antes, depois);
    return okVazio();
  }
}

export class ConcluirAtividade {
  constructor(private readonly deps: { repo: ObterAtividade & GravarAtividade }) {}
  async execute(ctx: ContextoCaso, e: { id: string; resultado?: string | null }): Promise<Result<void>> {
    const atual = await this.deps.repo.obterPorId(e.id);
    if (!atual) return fail(erroDe('nao_encontrado', 'Atividade nao encontrada'));
    const r = atual.concluir(e.resultado);
    if (!r.ok) return r;
    await this.deps.repo.atualizar(r.valor);
    const d = r.valor.paraDados();
    await ctx.efeitos.historico(TABELA, e.id, { estado: atual.estado }, { estado: d.estado, resultado: d.resultado });
    await ctx.efeitos.auditar('atividade.concluir', TABELA, e.id, { estado: atual.estado }, { estado: d.estado });
    if (d.oportunidade_id) await ctx.efeitos.nota('pipeline_oportunidades', d.oportunidade_id, `Atividade concluida: ${d.titulo}${d.resultado ? `. Resultado: ${d.resultado}` : ''}`);
    await ctx.efeitos.publicar('atividade.concluida', { ...dadosEvento(r.valor), resultado: d.resultado, concluida_em: d.concluida_em });
    return okVazio();
  }
}

export class CancelarAtividade {
  constructor(private readonly deps: { repo: ObterAtividade & GravarAtividade }) {}
  async execute(ctx: ContextoCaso, e: { id: string }): Promise<Result<void>> {
    const atual = await this.deps.repo.obterPorId(e.id);
    if (!atual) return fail(erroDe('nao_encontrado', 'Atividade nao encontrada'));
    const r = atual.cancelar();
    if (!r.ok) return r;
    await this.deps.repo.atualizar(r.valor);
    await ctx.efeitos.historico(TABELA, e.id, { estado: atual.estado }, { estado: 'cancelada' });
    await ctx.efeitos.auditar('atividade.cancelar', TABELA, e.id, { estado: atual.estado }, { estado: 'cancelada' });
    return okVazio();
  }
}
