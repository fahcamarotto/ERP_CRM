/** Adaptador Postgres das portas de Atividade. */
import type pg from 'pg';
import { Atividade, type AtividadeDados } from '../model/atividade.ts';
import type { ConsultarReferenciasAtividade, GravarAtividade, ObterAtividade } from '../model/portas.ts';

const COLUNAS = 'id, tipo, titulo, descricao, data, duracao_min, responsavel_id, oportunidade_id, estado, resultado, concluida_em';
const iso = (v: unknown) => (v instanceof Date ? v.toISOString() : v === null || v === undefined ? null : String(v));

export class AtividadeRepoPg implements ObterAtividade, GravarAtividade, ConsultarReferenciasAtividade {
  constructor(private readonly c: pg.PoolClient) {}

  async obterPorId(id: string) {
    const l = (await this.c.query(`SELECT ${COLUNAS} FROM pipeline_atividades WHERE id = $1 AND deleted_at IS NULL`, [id])).rows[0];
    return l ? Atividade.reidratar({ ...(l as AtividadeDados), data: iso(l.data)!, concluida_em: iso(l.concluida_em) }) : null;
  }

  async inserir(a: Atividade) {
    const d = a.paraDados();
    await this.c.query(
      `INSERT INTO pipeline_atividades (id, tipo, titulo, descricao, data, duracao_min, responsavel_id, oportunidade_id, estado, resultado, concluida_em, creator_id)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, nucleo_usuario_atual())`,
      [d.id, d.tipo, d.titulo, d.descricao, d.data, d.duracao_min, d.responsavel_id, d.oportunidade_id, d.estado, d.resultado, d.concluida_em],
    );
  }

  async atualizar(a: Atividade) {
    const d = a.paraDados();
    await this.c.query(
      `UPDATE pipeline_atividades SET tipo = $2, titulo = $3, descricao = $4, data = $5, duracao_min = $6, responsavel_id = $7, oportunidade_id = $8,
         estado = $9, resultado = $10, concluida_em = $11 WHERE id = $1 AND deleted_at IS NULL`,
      [d.id, d.tipo, d.titulo, d.descricao, d.data, d.duracao_min, d.responsavel_id, d.oportunidade_id, d.estado, d.resultado, d.concluida_em],
    );
  }

  async oportunidadeExiste(id: string) {
    return ((await this.c.query('SELECT 1 FROM pipeline_oportunidades WHERE id = $1 AND deleted_at IS NULL', [id])).rowCount ?? 0) > 0;
  }

  async usuarioExiste(id: string) {
    return ((await this.c.query('SELECT 1 FROM usuarios WHERE id = $1 AND deleted_at IS NULL', [id])).rowCount ?? 0) > 0;
  }
}
