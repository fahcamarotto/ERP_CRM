/** Rotas REST das Atividades fora das tools: ficha, edicao e cancelamento. */
import { esquemaErro, requer, type FastifyInstance } from '@erp/api/sdk';
import { naTransacao, naoEncontrado } from '../borda.ts';
import { exigirOk } from '../compartilhado/result.ts';
import { propsAtividade, uuid } from '../esquemas.ts';
import type { DadosAtividade } from './model/atividade.ts';
import { obterAtividade } from './query/atividades.ts';

const tags = ['pipeline'];
const erros = { 400: esquemaErro, 404: esquemaErro, 409: esquemaErro };
const paramId = { type: 'object', required: ['id'], properties: { id: uuid } } as const;

export function rotasAtividade(app: FastifyInstance): void {
  app.get<{ Params: { id: string } }>('/atividades/:id', {
    preHandler: requer('pipeline.ver'),
    schema: { tags, summary: 'Ficha da atividade', params: paramId, response: { 404: esquemaErro } },
  }, (req) => naTransacao(req, async (_, __, c) => (await obterAtividade(c, req.params.id)) ?? Promise.reject(naoEncontrado('Atividade nao encontrada'))));

  app.patch<{ Params: { id: string }; Body: Partial<DadosAtividade> }>('/atividades/:id', {
    preHandler: requer('pipeline.editar'),
    schema: { tags, summary: 'Edita atividade pendente (EditarAtividade)', params: paramId, body: { type: 'object', additionalProperties: false, properties: propsAtividade }, response: erros },
  }, (req) => naTransacao(req, async (casos, ctx, c) => {
    exigirOk(await casos.editarAtividade.execute(ctx, { ...req.body, id: req.params.id }));
    return obterAtividade(c, req.params.id);
  }));

  app.post<{ Params: { id: string } }>('/atividades/:id/cancelar', {
    preHandler: requer('pipeline.editar'),
    schema: { tags, summary: 'Cancela atividade pendente (CancelarAtividade)', params: paramId, response: erros },
  }, (req) => naTransacao(req, async (casos, ctx, c) => {
    exigirOk(await casos.cancelarAtividade.execute(ctx, { id: req.params.id }));
    return obterAtividade(c, req.params.id);
  }));
}
