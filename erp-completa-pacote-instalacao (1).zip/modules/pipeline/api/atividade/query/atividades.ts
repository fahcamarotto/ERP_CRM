/** Consulta das Atividades com oportunidade, cliente e responsavel; filtro por estado, periodo, oportunidade e responsavel. */
import type pg from 'pg';
import { decodificarCursor, pagina } from '../../compartilhado/cursor.ts';

const RESUMO = `a.id, a.tipo, a.titulo, a.descricao, a.data, a.duracao_min, a.responsavel_id, u.nome AS responsavel_nome,
  a.oportunidade_id, o.titulo AS oportunidade_titulo, c.nome AS cliente_nome, a.estado, a.resultado, a.concluida_em, a.created_at, a.updated_at,
  (a.estado = 'pendente' AND a.data < now()) AS atrasada`;
const JUNCOES = `FROM pipeline_atividades a
  LEFT JOIN usuarios u ON u.id = a.responsavel_id
  LEFT JOIN pipeline_oportunidades o ON o.id = a.oportunidade_id AND o.deleted_at IS NULL
  LEFT JOIN cadastros_parceiros c ON c.id = o.parceiro_id AND c.deleted_at IS NULL`;

export interface FiltroAtividades {
  estado?: 'pendente' | 'concluida' | 'cancelada';
  oportunidade_id?: string;
  responsavel_id?: string;
  de?: string;
  ate?: string;
  limite?: number;
  cursor?: string;
}

export async function listarAtividades(c: pg.PoolClient, f: FiltroAtividades) {
  const lim = Math.min(Math.max(f.limite ?? 50, 1), 500);
  const cur = decodificarCursor(f.cursor);
  const r = await c.query(
    `SELECT ${RESUMO} ${JUNCOES}
     WHERE a.deleted_at IS NULL AND ($1::text IS NULL OR a.estado = $1) AND ($2::uuid IS NULL OR a.oportunidade_id = $2)
       AND ($3::uuid IS NULL OR a.responsavel_id = $3) AND ($4::date IS NULL OR a.data >= $4::date) AND ($5::date IS NULL OR a.data < $5::date + 1)
       AND ($6::timestamptz IS NULL OR (a.created_at, a.id) > ($6::timestamptz, $7::uuid))
     ORDER BY a.created_at, a.id LIMIT $8`,
    [f.estado ?? null, f.oportunidade_id ?? null, f.responsavel_id ?? null, f.de ?? null, f.ate ?? null, cur?.[0] ?? null, cur?.[1] ?? null, lim + 1],
  );
  return pagina(r.rows, lim);
}

export async function obterAtividade(c: pg.PoolClient, id: string) {
  return (await c.query(`SELECT ${RESUMO} ${JUNCOES} WHERE a.id = $1 AND a.deleted_at IS NULL`, [id])).rows[0] ?? null;
}
