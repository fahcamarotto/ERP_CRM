/** Portas do repositorio de Atividades. */
import type { Atividade } from './atividade.ts';

export interface ObterAtividade {
  obterPorId(id: string): Promise<Atividade | null>;
}

export interface GravarAtividade {
  inserir(a: Atividade): Promise<void>;
  atualizar(a: Atividade): Promise<void>;
}

export interface ConsultarReferenciasAtividade {
  oportunidadeExiste(id: string): Promise<boolean>;
  usuarioExiste(id: string): Promise<boolean>;
}
