/**
 * Entidade Atividade (M2.3): tarefa, ligacao, reuniao ou follow-up com data, responsavel e estado,
 * ligada a uma oportunidade. A Agenda, quando instalada, reage a atividade.agendada. Imutavel.
 */
import { randomUUID } from 'node:crypto';
import { erroDe, fail, ok, type ErroDominio, type Result } from '../../compartilhado/result.ts';

export const TIPOS_ATIVIDADE = ['tarefa', 'ligacao', 'reuniao', 'follow_up'] as const;
export type TipoAtividade = (typeof TIPOS_ATIVIDADE)[number];
export const ESTADOS_ATIVIDADE = ['pendente', 'concluida', 'cancelada'] as const;
export type EstadoAtividade = (typeof ESTADOS_ATIVIDADE)[number];

/** Concluida e cancelada sao finais. */
export const TRANSICOES_ATIVIDADE: Record<EstadoAtividade, EstadoAtividade[]> = { pendente: ['concluida', 'cancelada'], concluida: [], cancelada: [] };

export interface DadosAtividade {
  tipo: TipoAtividade;
  titulo: string;
  descricao?: string | null;
  data: string;
  duracao_min?: number;
  responsavel_id?: string | null;
  oportunidade_id?: string | null;
}

export interface AtividadeDados {
  id: string;
  tipo: TipoAtividade;
  titulo: string;
  descricao: string | null;
  data: string;
  duracao_min: number;
  responsavel_id: string | null;
  oportunidade_id: string | null;
  estado: EstadoAtividade;
  resultado: string | null;
  concluida_em: string | null;
}

const t = (v?: string | null) => (v ?? '').trim() || null;

/** Data e hora ISO 8601 (AAAA-MM-DD ou AAAA-MM-DDTHH:MM com fuso opcional), normalizada para UTC. */
function normalizarData(v: unknown): string | null {
  if (typeof v !== 'string' || !/^\d{4}-\d{2}-\d{2}([T ]\d{2}:\d{2}(:\d{2}(\.\d+)?)?(Z|[+-]\d{2}:?\d{2})?)?$/.test(v.trim())) return null;
  const ms = Date.parse(v.trim().replace(' ', 'T'));
  return Number.isNaN(ms) ? null : new Date(ms).toISOString();
}

function validar(d: AtividadeDados): ErroDominio[] {
  const e: ErroDominio[] = [];
  if (!TIPOS_ATIVIDADE.includes(d.tipo)) e.push(erroDe('tipo_invalido', `Tipo deve ser: ${TIPOS_ATIVIDADE.join(', ')}`, 'tipo'));
  if (d.titulo.length < 2 || d.titulo.length > 200) e.push(erroDe('titulo_invalido', 'Titulo deve ter de 2 a 200 caracteres', 'titulo'));
  if (!d.data) e.push(erroDe('data_invalida', 'Data e hora em ISO 8601 (AAAA-MM-DDTHH:MM)', 'data'));
  if (!Number.isInteger(d.duracao_min) || d.duracao_min < 5 || d.duracao_min > 1440) e.push(erroDe('duracao_invalida', 'Duracao de 5 a 1440 minutos', 'duracao_min'));
  return e;
}

export class Atividade {
  private constructor(private readonly d: AtividadeDados) {}

  static tryCreate(e: DadosAtividade, id: string = randomUUID()): Result<Atividade> {
    const d: AtividadeDados = {
      id, tipo: e.tipo, titulo: (e.titulo ?? '').trim(), descricao: t(e.descricao), data: normalizarData(e.data) ?? '',
      duracao_min: e.duracao_min ?? 30, responsavel_id: t(e.responsavel_id), oportunidade_id: t(e.oportunidade_id),
      estado: 'pendente', resultado: null, concluida_em: null,
    };
    const erros = validar(d);
    return erros.length ? fail(...erros) : ok(new Atividade(d));
  }

  static create(e: DadosAtividade, id?: string): Atividade {
    const r = Atividade.tryCreate(e, id);
    if (!r.ok) throw new Error(r.erros.map((x) => x.mensagem).join('; '));
    return r.valor;
  }

  static reidratar(d: AtividadeDados): Atividade {
    return new Atividade({ ...d });
  }

  get id(): string { return this.d.id; }
  get estado(): EstadoAtividade { return this.d.estado; }

  editar(e: Partial<DadosAtividade>): Result<Atividade> {
    if (this.d.estado !== 'pendente') return fail(erroDe('transicao_invalida', `Atividade ${this.d.estado} nao pode ser editada`, 'estado'));
    const tem = (k: keyof DadosAtividade) => e[k] !== undefined;
    const n: AtividadeDados = {
      ...this.d,
      tipo: e.tipo ?? this.d.tipo,
      titulo: tem('titulo') ? (e.titulo ?? '').trim() : this.d.titulo,
      descricao: tem('descricao') ? t(e.descricao) : this.d.descricao,
      data: tem('data') ? normalizarData(e.data) ?? '' : this.d.data,
      duracao_min: e.duracao_min ?? this.d.duracao_min,
      responsavel_id: tem('responsavel_id') ? t(e.responsavel_id) : this.d.responsavel_id,
      oportunidade_id: tem('oportunidade_id') ? t(e.oportunidade_id) : this.d.oportunidade_id,
    };
    const erros = validar(n);
    return erros.length ? fail(...erros) : ok(new Atividade(n));
  }

  private mudar(novo: EstadoAtividade, extra: Partial<AtividadeDados>): Result<Atividade> {
    if (!TRANSICOES_ATIVIDADE[this.d.estado].includes(novo)) {
      return fail(erroDe('transicao_invalida', `Transicao de ${this.d.estado} para ${novo} nao permitida`, 'estado', { permitidas: TRANSICOES_ATIVIDADE[this.d.estado] }));
    }
    return ok(new Atividade({ ...this.d, ...extra, estado: novo }));
  }

  concluir(resultado?: string | null, agora: string = new Date().toISOString()): Result<Atividade> {
    const r = t(resultado);
    if ((r?.length ?? 0) > 2000) return fail(erroDe('resultado_invalido', 'Resultado com no maximo 2000 caracteres', 'resultado'));
    return this.mudar('concluida', { resultado: r, concluida_em: agora });
  }

  cancelar(): Result<Atividade> {
    return this.mudar('cancelada', {});
  }

  paraDados(): AtividadeDados {
    return { ...this.d };
  }
}
