/**
 * Plugin do modulo Pipeline (M2), registrado sozinho com prefixo /api/v1/pipeline.
 * Importar ./tools.ts registra as @tool (MCP e REST) no carregamento.
 */
import type { FastifyPluginAsync } from '@erp/api/sdk';
import './tools.ts';
import { rotasAtividade } from './atividade/routes.ts';
import { rotasEquipe } from './equipe/routes.ts';
import { rotasEtapa } from './etapa/routes.ts';
import { rotasMeta } from './meta/routes.ts';
import { rotasMotivo } from './motivo/routes.ts';
import { rotasOportunidade } from './oportunidade/routes.ts';

const plugin: FastifyPluginAsync = async (app) => {
  rotasOportunidade(app);
  rotasEtapa(app);
  rotasAtividade(app);
  rotasEquipe(app);
  rotasMeta(app);
  rotasMotivo(app);
};

export default plugin;
