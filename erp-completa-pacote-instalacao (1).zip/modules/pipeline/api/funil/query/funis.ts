/** Consulta dos Funis (pipelines) com etapas, oportunidades abertas e valor em negociacao de cada um. */
import type pg from 'pg';

export async function listarFunis(c: pg.PoolClient, f: { incluir_arquivados?: boolean } = {}) {
  const r = await c.query(
    `SELECT p.id, p.nome, p.ordem, p.padrao, p.arquivado, p.arquivado_em, p.created_at, p.updated_at,
       (SELECT count(*)::int FROM pipeline_etapas e WHERE e.funil_id = p.id AND e.deleted_at IS NULL) AS etapas,
       count(o.id) FILTER (WHERE o.estado = 'aberta')::int AS abertas,
       coalesce(sum(o.valor) FILTER (WHERE o.estado = 'aberta'), 0)::float8 AS valor_em_negociacao
     FROM pipeline_funis p
     LEFT JOIN pipeline_oportunidades o ON o.funil_id = p.id AND o.deleted_at IS NULL
     WHERE p.deleted_at IS NULL AND ($1::boolean OR NOT p.arquivado)
     GROUP BY p.id, p.nome, p.ordem, p.padrao, p.arquivado, p.arquivado_em, p.created_at, p.updated_at ORDER BY p.arquivado, p.ordem, p.nome`,
    [!!f.incluir_arquivados],
  );
  return r.rows;
}

export async function obterFunil(c: pg.PoolClient, id: string) {
  return (await listarFunis(c, { incluir_arquivados: true })).find((x) => x.id === id) ?? null;
}
