/** Portas do repositorio de Funis (pipelines), segregadas por operacao. */
import type { Funil } from './funil.ts';

export interface ObterFunil {
  obterPorId(id: string): Promise<Funil | null>;
  padrao(): Promise<Funil | null>;
}

export interface ListarFunis {
  /** Funis ativos (nao arquivados) na ordem. */
  ativos(): Promise<Funil[]>;
  buscarAtivoPorNome(nome: string): Promise<Funil | null>;
  proximaOrdem(): Promise<number>;
}

export interface GravarFunil {
  inserir(f: Funil): Promise<void>;
  /** Grava nome, ordem, padrao e arquivado (arquivado_em acompanha). */
  atualizar(f: Funil): Promise<void>;
}

/** Oportunidades abertas do funil (arquivar so sem abertas ou movendo para outro funil). */
export interface ContarAbertasFunil {
  abertas(funilId: string): Promise<string[]>;
}

/** Serializa criacao do funil padrao e mudancas de ordem no workspace. */
export interface TravarFunis {
  travarFunis(): Promise<void>;
}
