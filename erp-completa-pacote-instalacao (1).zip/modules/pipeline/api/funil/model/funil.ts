/**
 * Entidade Funil (pipeline): agrupa etapas e oportunidades. Um funil padrao por workspace (usado quando
 * ninguem informa o funil). Arquivar tira o funil da navegacao; o padrao nunca fica arquivado. Imutavel.
 */
import { randomUUID } from 'node:crypto';
import { erroDe, fail, ok, type ErroDominio, type Result } from '../../compartilhado/result.ts';

export const NOME_FUNIL_PADRAO = 'Pipeline padrão';

export interface DadosFunil {
  nome: string;
  ordem?: number;
  padrao?: boolean;
}

export interface FunilDados {
  id: string;
  nome: string;
  ordem: number;
  padrao: boolean;
  arquivado: boolean;
}

function validar(d: FunilDados): ErroDominio[] {
  const e: ErroDominio[] = [];
  if (d.nome.length < 1 || d.nome.length > 60) e.push(erroDe('nome_invalido', 'Nome deve ter de 1 a 60 caracteres', 'nome'));
  if (!Number.isInteger(d.ordem) || d.ordem < 0 || d.ordem > 9999) e.push(erroDe('ordem_invalida', 'Ordem deve ser inteiro de 0 a 9999', 'ordem'));
  if (d.padrao && d.arquivado) e.push(erroDe('conflito', 'O pipeline padrao nao pode ficar arquivado', 'arquivado'));
  return e;
}

export class Funil {
  private constructor(private readonly d: FunilDados) {}

  static tryCreate(e: DadosFunil, id: string = randomUUID()): Result<Funil> {
    const d: FunilDados = { id, nome: (e.nome ?? '').trim(), ordem: e.ordem ?? 10, padrao: !!e.padrao, arquivado: false };
    const erros = validar(d);
    return erros.length ? fail(...erros) : ok(new Funil(d));
  }

  static create(e: DadosFunil, id?: string): Funil {
    const r = Funil.tryCreate(e, id);
    if (!r.ok) throw new Error(r.erros.map((x) => x.mensagem).join('; '));
    return r.valor;
  }

  static reidratar(d: FunilDados): Funil {
    return new Funil({ ...d });
  }

  get id(): string { return this.d.id; }
  get nome(): string { return this.d.nome; }
  get padrao(): boolean { return this.d.padrao; }
  get arquivado(): boolean { return this.d.arquivado; }

  renomear(nome: string): Result<Funil> {
    const n = { ...this.d, nome: (nome ?? '').trim() };
    const erros = validar(n);
    return erros.length ? fail(...erros) : ok(new Funil(n));
  }

  arquivar(): Result<Funil> {
    if (this.d.arquivado) return fail(erroDe('transicao_invalida', 'Pipeline ja esta arquivado', 'arquivado'));
    return ok(new Funil({ ...this.d, arquivado: true, padrao: false }));
  }

  tornarPadrao(): Result<Funil> {
    if (this.d.arquivado) return fail(erroDe('transicao_invalida', 'Pipeline arquivado nao pode ser o padrao', 'padrao'));
    return ok(new Funil({ ...this.d, padrao: true }));
  }

  paraDados(): FunilDados {
    return { ...this.d };
  }
}
