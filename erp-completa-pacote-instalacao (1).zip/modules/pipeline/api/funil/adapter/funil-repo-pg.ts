/** Adaptador Postgres das portas de Funil (RLS restringe ao workspace da sessao). */
import type pg from 'pg';
import { Funil, type FunilDados } from '../model/funil.ts';
import type { ContarAbertasFunil, GravarFunil, ListarFunis, ObterFunil, TravarFunis } from '../model/portas.ts';

const COLUNAS = 'id, nome, ordem, padrao, arquivado';
const de = (l: unknown) => Funil.reidratar(l as FunilDados);

export class FunilRepoPg implements ObterFunil, ListarFunis, GravarFunil, ContarAbertasFunil, TravarFunis {
  constructor(private readonly c: pg.PoolClient) {}

  async obterPorId(id: string) {
    const r = await this.c.query(`SELECT ${COLUNAS} FROM pipeline_funis WHERE id = $1 AND deleted_at IS NULL`, [id]);
    return r.rows[0] ? de(r.rows[0]) : null;
  }

  async padrao() {
    const r = await this.c.query(`SELECT ${COLUNAS} FROM pipeline_funis WHERE padrao AND deleted_at IS NULL LIMIT 1`);
    return r.rows[0] ? de(r.rows[0]) : null;
  }

  async ativos() {
    const r = await this.c.query(`SELECT ${COLUNAS} FROM pipeline_funis WHERE NOT arquivado AND deleted_at IS NULL ORDER BY padrao DESC, ordem, nome`);
    return r.rows.map(de);
  }

  async buscarAtivoPorNome(nome: string) {
    const r = await this.c.query(`SELECT ${COLUNAS} FROM pipeline_funis WHERE lower(nome) = lower($1) AND NOT arquivado AND deleted_at IS NULL`, [nome]);
    return r.rows[0] ? de(r.rows[0]) : null;
  }

  async proximaOrdem() {
    const r = await this.c.query('SELECT coalesce(max(ordem), 0)::int + 10 AS n FROM pipeline_funis WHERE deleted_at IS NULL');
    return Math.min(r.rows[0].n as number, 9999);
  }

  async inserir(f: Funil) {
    const d = f.paraDados();
    await this.c.query(
      'INSERT INTO pipeline_funis (id, nome, ordem, padrao, creator_id) VALUES ($1, $2, $3, $4, nucleo_usuario_atual())',
      [d.id, d.nome, d.ordem, d.padrao],
    );
  }

  async atualizar(f: Funil) {
    const d = f.paraDados();
    await this.c.query(
      `UPDATE pipeline_funis SET nome = $2, ordem = $3, padrao = $4, arquivado = $5,
         arquivado_em = CASE WHEN $5 THEN coalesce(arquivado_em, now()) ELSE NULL END
       WHERE id = $1 AND deleted_at IS NULL`,
      [d.id, d.nome, d.ordem, d.padrao, d.arquivado],
    );
  }

  async abertas(funilId: string) {
    const r = await this.c.query("SELECT id FROM pipeline_oportunidades WHERE funil_id = $1 AND estado = 'aberta' AND deleted_at IS NULL ORDER BY created_at, id", [funilId]);
    return r.rows.map((x) => x.id as string);
  }

  async travarFunis() {
    await this.c.query("SELECT pg_advisory_xact_lock(hashtext('pipeline_funis:' || nucleo_workspace_atual()::text))");
  }
}
