/**
 * Casos de uso dos Funis (varios pipelines): garantir o padrao, resolver o funil de uma chamada, criar com etapas
 * iniciais, renomear e arquivar (nunca o ultimo ativo; com oportunidades abertas so movendo para outro funil).
 */
import { erroDe, fail, ok, okVazio, type ErroDominio, type Result } from '../../compartilhado/result.ts';
import type { ContextoCaso } from '../../compartilhado/efeitos.ts';
import { Etapa, type Cor } from '../../etapa/model/etapa.ts';
import type { GravarEtapa } from '../../etapa/model/portas.ts';
import { Funil, NOME_FUNIL_PADRAO, type FunilDados } from '../model/funil.ts';
import type { ContarAbertasFunil, GravarFunil, ListarFunis, ObterFunil, TravarFunis } from '../model/portas.ts';

type Repo = ObterFunil & ListarFunis & GravarFunil & TravarFunis;
const TABELA = 'pipeline_funis';

/** Garante as etapas iniciais de um funil (GarantirEtapasPadrao). */
export interface GarantirEtapasDoFunil {
  execute(ctx: ContextoCaso | null, funilId: string): Promise<Result<{ criadas: number }>>;
}

/**
 * Convergencia automatica: todo workspace tem um funil padrao com etapas. Criado na primeira leitura ou na primeira
 * oportunidade (subcontas existentes e futuras, sem seed manual). Idempotente e serializado por workspace.
 */
export class GarantirFunilPadrao {
  constructor(private readonly deps: { repo: Repo; etapas: GarantirEtapasDoFunil; novoId?: () => string }) {}
  async execute(ctx: ContextoCaso | null): Promise<Result<{ id: string; criado: boolean }>> {
    let f = await this.deps.repo.padrao();
    let criado = false;
    if (!f) {
      await this.deps.repo.travarFunis();
      f = await this.deps.repo.padrao();
      if (!f) {
        const ativo = (await this.deps.repo.ativos())[0];
        if (ativo) {
          const r = ativo.tornarPadrao();
          if (!r.ok) return r;
          await this.deps.repo.atualizar(r.valor);
          f = r.valor;
        } else {
          f = Funil.create({ nome: NOME_FUNIL_PADRAO, ordem: 10, padrao: true }, this.deps.novoId?.());
          await this.deps.repo.inserir(f);
          criado = true;
          if (ctx) await ctx.efeitos.auditar('funil.criar', TABELA, f.id, undefined, f.paraDados());
        }
      }
    }
    const e = await this.deps.etapas.execute(ctx, f.id);
    if (!e.ok) return e;
    return ok({ id: f.id, criado });
  }
}

/** Funil da chamada: o informado (precisa existir) ou o padrao do workspace. */
export class ResolverFunil {
  constructor(private readonly deps: { repo: ObterFunil; padrao: Pick<GarantirFunilPadrao, 'execute'> }) {}
  async execute(ctx: ContextoCaso | null, funilId?: string | null): Promise<Result<FunilDados>> {
    if (funilId) {
      const f = await this.deps.repo.obterPorId(funilId);
      return f ? ok(f.paraDados()) : fail(erroDe('funil_invalido', 'Pipeline nao encontrado', 'funil_id'));
    }
    const p = await this.deps.padrao.execute(ctx);
    if (!p.ok) return p;
    const f = await this.deps.repo.obterPorId(p.valor.id);
    return f ? ok(f.paraDados()) : fail(erroDe('funil_invalido', 'Pipeline padrao nao encontrado', 'funil_id'));
  }
}

/** Etapas abertas iniciais de um funil novo quando a tela nao manda nenhuma. */
export const ETAPAS_INICIAIS = ['Novo', 'Contato', 'Proposta', 'Negociação'];
const CORES_ABERTAS: Cor[] = ['azul', 'ciano', 'roxo', 'laranja', 'dourado', 'acento'];
const NOMES_FINAIS = { ganho: 'Ganho', perdido: 'Perdido' } as const;

/** Probabilidade crescente de 10 a 75 entre a primeira e a ultima etapa aberta. */
function probabilidadeDe(i: number, n: number): number {
  return n <= 1 ? 10 : Math.round(10 + (i * (75 - 10)) / (n - 1));
}

export class CriarFunil {
  constructor(private readonly deps: { repo: Repo; etapas: GravarEtapa }) {}
  async execute(ctx: ContextoCaso, e: { nome: string; etapas?: string[] | null }): Promise<Result<{ id: string }>> {
    const r = Funil.tryCreate({ nome: e.nome, ordem: await this.deps.repo.proximaOrdem() });
    if (!r.ok) return r;
    const nomes = (e.etapas ?? ETAPAS_INICIAIS).map((n) => (n ?? '').trim());
    const erros: ErroDominio[] = [];
    if (nomes.length < 1 || nomes.length > 20) erros.push(erroDe('etapas_invalidas', 'Informe de 1 a 20 etapas abertas', 'etapas'));
    const vistos = new Set<string>([NOMES_FINAIS.ganho.toLowerCase(), NOMES_FINAIS.perdido.toLowerCase()]);
    for (const n of nomes) {
      if (n.length < 1 || n.length > 60) { erros.push(erroDe('etapas_invalidas', 'Nome de etapa deve ter de 1 a 60 caracteres', 'etapas')); break; }
      if (vistos.has(n.toLowerCase())) { erros.push(erroDe('etapas_invalidas', `Etapa repetida ou reservada: ${n}`, 'etapas')); break; }
      vistos.add(n.toLowerCase());
    }
    if (erros.length) return fail(...erros);
    if (await this.deps.repo.buscarAtivoPorNome(r.valor.nome)) return fail(erroDe('conflito', 'Ja existe pipeline ativo com este nome', 'nome'));
    const f = r.valor;
    await this.deps.repo.inserir(f);
    const etapas = [
      ...nomes.map((nome, i) => Etapa.create({ funil_id: f.id, nome, ordem: (i + 1) * 10, tipo: 'aberta', probabilidade: probabilidadeDe(i, nomes.length), cor: CORES_ABERTAS[i % CORES_ABERTAS.length] })),
      Etapa.create({ funil_id: f.id, nome: NOMES_FINAIS.ganho, ordem: (nomes.length + 1) * 10, tipo: 'ganho', probabilidade: 100, cor: 'sucesso' }),
      Etapa.create({ funil_id: f.id, nome: NOMES_FINAIS.perdido, ordem: (nomes.length + 2) * 10, tipo: 'perdido', probabilidade: 0, cor: 'perigo' }),
    ];
    for (const et of etapas) await this.deps.etapas.inserir(et);
    await ctx.efeitos.auditar('funil.criar', TABELA, f.id, undefined, { ...f.paraDados(), etapas: etapas.map((x) => x.nome) });
    return ok({ id: f.id });
  }
}

export class RenomearFunil {
  constructor(private readonly deps: { repo: Repo }) {}
  async execute(ctx: ContextoCaso, e: { id: string; nome: string }): Promise<Result<void>> {
    const atual = await this.deps.repo.obterPorId(e.id);
    if (!atual) return fail(erroDe('nao_encontrado', 'Pipeline nao encontrado'));
    if (atual.arquivado) return fail(erroDe('funil_arquivado', 'Pipeline arquivado nao pode ser renomeado', 'id'));
    const r = atual.renomear(e.nome);
    if (!r.ok) return r;
    const mesmo = await this.deps.repo.buscarAtivoPorNome(r.valor.nome);
    if (mesmo && mesmo.id !== e.id) return fail(erroDe('conflito', 'Ja existe pipeline ativo com este nome', 'nome'));
    await this.deps.repo.atualizar(r.valor);
    await ctx.efeitos.auditar('funil.renomear', TABELA, e.id, { nome: atual.nome }, { nome: r.valor.nome });
    return okVazio();
  }
}

/** Mover uma oportunidade para uma etapa (MoverEtapa) e achar a primeira etapa aberta do destino. */
export interface DepsMoverParaFunil {
  mover: { execute(ctx: ContextoCaso, e: { id: string; etapa_id: string }): Promise<Result<void>> };
  primeiraAberta(funilId: string): Promise<{ id: string } | null>;
}

export class ArquivarFunil {
  constructor(private readonly deps: { repo: Repo & ContarAbertasFunil; ops: DepsMoverParaFunil }) {}
  async execute(ctx: ContextoCaso, e: { id: string; mover_para_funil_id?: string | null }): Promise<Result<{ movidas: number; novo_padrao_id: string | null }>> {
    await this.deps.repo.travarFunis();
    const atual = await this.deps.repo.obterPorId(e.id);
    if (!atual) return fail(erroDe('nao_encontrado', 'Pipeline nao encontrado'));
    if (atual.arquivado) return fail(erroDe('transicao_invalida', 'Pipeline ja esta arquivado', 'arquivado'));
    const ativos = await this.deps.repo.ativos();
    const outros = ativos.filter((f) => f.id !== e.id);
    if (!outros.length) return fail(erroDe('conflito', 'Nao e possivel arquivar o ultimo pipeline ativo', 'id'));
    const abertas = await this.deps.repo.abertas(e.id);
    let movidas = 0;
    if (abertas.length) {
      if (!e.mover_para_funil_id) {
        return fail(erroDe('conflito', `Este pipeline tem ${abertas.length} oportunidade(s) aberta(s): escolha outro pipeline para move-las antes de arquivar`, 'mover_para_funil_id', { abertas: abertas.length }));
      }
      const destino = outros.find((f) => f.id === e.mover_para_funil_id);
      if (!destino) return fail(erroDe('funil_invalido', 'Pipeline de destino precisa ser outro pipeline ativo', 'mover_para_funil_id'));
      const etapa = await this.deps.ops.primeiraAberta(destino.id);
      if (!etapa) return fail(erroDe('etapa_invalida', 'O pipeline de destino nao tem etapa aberta', 'mover_para_funil_id'));
      for (const id of abertas) {
        const r = await this.deps.ops.mover.execute(ctx, { id, etapa_id: etapa.id });
        if (!r.ok) return r;
        movidas++;
      }
    }
    const r = atual.arquivar();
    if (!r.ok) return r;
    await this.deps.repo.atualizar(r.valor);
    let novoPadrao: string | null = null;
    if (atual.padrao) {
      const p = outros[0]!.tornarPadrao();
      if (!p.ok) return p;
      await this.deps.repo.atualizar(p.valor);
      novoPadrao = p.valor.id;
    }
    await ctx.efeitos.auditar('funil.arquivar', TABELA, e.id, atual.paraDados(), { ...r.valor.paraDados(), movidas, mover_para_funil_id: e.mover_para_funil_id ?? null, novo_padrao_id: novoPadrao });
    return ok({ movidas, novo_padrao_id: novoPadrao });
  }
}
