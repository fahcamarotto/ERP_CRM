/**
 * Casos de uso das Etapas (M2.2): garantir as etapas iniciais de um funil, criar, editar, reordenar em lote e
 * excluir (bloqueado enquanto em uso). Toda etapa pertence a um funil.
 */
import { erroDe, fail, ok, okVazio, type Result } from '../../compartilhado/result.ts';
import type { ContextoCaso } from '../../compartilhado/efeitos.ts';
import { Etapa, ETAPAS_PADRAO, type DadosEtapa } from '../model/etapa.ts';
import type { ContarUsoEtapa, GravarEtapa, ListarEtapas, ObterEtapa, TravarFunil } from '../model/portas.ts';

type Repo = ObterEtapa & ListarEtapas & GravarEtapa;

/** Funil vivo visto pelas etapas (existencia e arquivado). */
export interface ConsultarFunilDaEtapa {
  funilVivo(id: string): Promise<{ id: string; arquivado: boolean } | null>;
}

/**
 * Convergencia automatica: funil sem nenhuma etapa recebe as etapas iniciais na primeira leitura ou na primeira
 * oportunidade (existentes e futuros, sem seed manual). Funil que ja configurou nao muda.
 */
export class GarantirEtapasPadrao {
  constructor(private readonly deps: { repo: Repo & TravarFunil; novoId?: (chave: string) => string }) {}
  async execute(ctx: ContextoCaso | null, funilId: string): Promise<Result<{ criadas: number }>> {
    if ((await this.deps.repo.listar(funilId)).length) return ok({ criadas: 0 });
    await this.deps.repo.travarFunil(funilId);
    if ((await this.deps.repo.listar(funilId)).length) return ok({ criadas: 0 });
    for (const p of ETAPAS_PADRAO) {
      const { chave, ...dados } = p;
      const e = Etapa.create({ ...dados, funil_id: funilId }, this.deps.novoId?.(chave));
      await this.deps.repo.inserir(e);
      if (ctx) await ctx.efeitos.auditar('etapa.criar', 'pipeline_etapas', e.id, undefined, e.paraDados());
    }
    return ok({ criadas: ETAPAS_PADRAO.length });
  }
}

export class CriarEtapa {
  constructor(private readonly deps: { repo: Repo; funis: ConsultarFunilDaEtapa }) {}
  async execute(ctx: ContextoCaso, e: DadosEtapa & { funil_id: string }): Promise<Result<{ id: string }>> {
    const f = await this.deps.funis.funilVivo(e.funil_id);
    if (!f) return fail(erroDe('funil_invalido', 'Pipeline nao encontrado', 'funil_id'));
    if (f.arquivado) return fail(erroDe('funil_arquivado', 'Pipeline arquivado nao recebe etapas', 'funil_id'));
    const r = Etapa.tryCreate(e);
    if (!r.ok) return r;
    const d = r.valor.paraDados();
    if (await this.deps.repo.buscarPorNome(d.funil_id, d.nome)) return fail(erroDe('conflito', 'Ja existe etapa com este nome neste pipeline', 'nome'));
    if (d.tipo !== 'aberta' && (await this.deps.repo.porTipo(d.funil_id, d.tipo))) {
      return fail(erroDe('conflito', `O pipeline ja tem uma etapa de ${d.tipo}`, 'tipo'));
    }
    await this.deps.repo.inserir(r.valor);
    await ctx.efeitos.auditar('etapa.criar', 'pipeline_etapas', d.id, undefined, d);
    return ok({ id: d.id });
  }
}

export class EditarEtapa {
  constructor(private readonly deps: { repo: Repo }) {}
  async execute(ctx: ContextoCaso, e: { id: string } & Partial<Omit<DadosEtapa, 'tipo' | 'funil_id'>>): Promise<Result<void>> {
    const atual = await this.deps.repo.obterPorId(e.id);
    if (!atual) return fail(erroDe('nao_encontrado', 'Etapa nao encontrada'));
    const { id: _id, ...mud } = e;
    const r = atual.editar(mud);
    if (!r.ok) return r;
    const d = r.valor.paraDados();
    const mesmo = await this.deps.repo.buscarPorNome(d.funil_id, d.nome);
    if (mesmo && mesmo.id !== d.id) return fail(erroDe('conflito', 'Ja existe etapa com este nome neste pipeline', 'nome'));
    await this.deps.repo.atualizar(r.valor);
    await ctx.efeitos.auditar('etapa.editar', 'pipeline_etapas', d.id, atual.paraDados(), d);
    return okVazio();
  }
}

/** Passo entre ordens na reordenacao em lote (10, 20, 30...): deixa espaco para inserir no meio pela edicao. */
const PASSO_ORDEM = 10;

/**
 * ReordenarEtapas: recebe a lista completa das etapas vivas do funil na nova ordem e regrava `ordem` de todas
 * numa transacao so. Lista incompleta, com repeticao ou com etapa de outro funil e recusada (protege contra tela velha).
 */
export class ReordenarEtapas {
  constructor(private readonly deps: { repo: Repo & TravarFunil; funis: ConsultarFunilDaEtapa }) {}
  async execute(ctx: ContextoCaso, e: { funil_id: string; etapa_ids: string[] }): Promise<Result<{ ordem: { id: string; ordem: number }[] }>> {
    const f = await this.deps.funis.funilVivo(e.funil_id);
    if (!f) return fail(erroDe('funil_invalido', 'Pipeline nao encontrado', 'funil_id'));
    await this.deps.repo.travarFunil(e.funil_id);
    const atuais = await this.deps.repo.listar(e.funil_id);
    const ids = e.etapa_ids ?? [];
    if (new Set(ids).size !== ids.length) return fail(erroDe('lista_invalida', 'Etapa repetida na nova ordem', 'etapa_ids'));
    const vivas = new Set(atuais.map((x) => x.id));
    const fora = ids.filter((id) => !vivas.has(id));
    if (fora.length) return fail(erroDe('lista_invalida', 'Etapa que nao pertence a este pipeline', 'etapa_ids', { ids: fora }));
    if (ids.length !== atuais.length) {
      return fail(erroDe('conflito', 'A lista precisa ter todas as etapas do pipeline: recarregue e tente de novo', 'etapa_ids', { esperado: atuais.length, recebido: ids.length }));
    }
    if (ids.length * PASSO_ORDEM > 999) return fail(erroDe('lista_invalida', 'Pipeline com etapas demais para reordenar', 'etapa_ids'));
    const porId = new Map(atuais.map((x) => [x.id, x]));
    const antes = atuais.map((x) => ({ id: x.id, ordem: x.ordem }));
    const depois: { id: string; ordem: number }[] = [];
    for (const [i, id] of ids.entries()) {
      const etapa = porId.get(id)!;
      const ordem = (i + 1) * PASSO_ORDEM;
      depois.push({ id, ordem });
      if (etapa.ordem === ordem) continue;
      const r = etapa.editar({ ordem });
      if (!r.ok) return r;
      await this.deps.repo.atualizar(r.valor);
    }
    await ctx.efeitos.auditar('etapa.reordenar', 'pipeline_etapas', null, { funil_id: e.funil_id, ordem: antes }, { funil_id: e.funil_id, ordem: depois });
    return ok({ ordem: depois });
  }
}

export class ExcluirEtapa {
  constructor(private readonly deps: { repo: Repo & ContarUsoEtapa }) {}
  async execute(ctx: ContextoCaso, e: { id: string }): Promise<Result<void>> {
    const atual = await this.deps.repo.obterPorId(e.id);
    if (!atual) return fail(erroDe('nao_encontrado', 'Etapa nao encontrada'));
    if (atual.tipo !== 'aberta') return fail(erroDe('conflito', 'As etapas de ganho e de perda nao podem ser excluidas', 'tipo'));
    const abertas = (await this.deps.repo.listar(atual.funilId)).filter((x) => x.tipo === 'aberta');
    if (abertas.length <= 1) return fail(erroDe('conflito', 'O pipeline precisa de pelo menos uma etapa aberta'));
    const uso = await this.deps.repo.emUso(e.id);
    if (uso > 0) return fail(erroDe('conflito', `Em uso por ${uso} oportunidade(s): mova antes de excluir`, undefined, { em_uso: uso }));
    await this.deps.repo.excluir(e.id);
    await ctx.efeitos.auditar('etapa.excluir', 'pipeline_etapas', e.id, atual.paraDados());
    return okVazio();
  }
}
