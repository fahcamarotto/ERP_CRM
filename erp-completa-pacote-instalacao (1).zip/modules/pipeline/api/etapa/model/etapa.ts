/**
 * Entidade Etapa (M2.2): coluna do funil configuravel por workspace. Tipo `aberta` para etapas de trabalho,
 * `ganho` e `perdido` para as duas etapas finais (uma de cada por funil). Pertence a um funil. Imutavel.
 */
import { randomUUID } from 'node:crypto';
import { erroDe, fail, ok, type ErroDominio, type Result } from '../../compartilhado/result.ts';

export const TIPOS_ETAPA = ['aberta', 'ganho', 'perdido'] as const;
export type TipoEtapa = (typeof TIPOS_ETAPA)[number];
/** Cores permitidas: nomes de token de apps/web/src/estilos/tokens.css (nunca hex). */
export const CORES = ['acento', 'roxo', 'azul', 'ciano', 'laranja', 'dourado', 'sucesso', 'perigo'] as const;
export type Cor = (typeof CORES)[number];

export interface DadosEtapa {
  /** Funil dono (obrigatorio na criacao; nao muda depois). */
  funil_id?: string;
  nome: string;
  ordem?: number;
  tipo?: TipoEtapa;
  probabilidade?: number;
  cor?: Cor;
}

export interface EtapaDados {
  id: string;
  funil_id: string;
  nome: string;
  ordem: number;
  tipo: TipoEtapa;
  probabilidade: number;
  cor: Cor;
}

/** Etapas iniciais de todo funil novo (M2.2): novo, contato, proposta, negociacao, ganho, perdido. */
export const ETAPAS_PADRAO: (DadosEtapa & { chave: string })[] = [
  { chave: 'novo', nome: 'Novo', ordem: 10, tipo: 'aberta', probabilidade: 10, cor: 'azul' },
  { chave: 'contato', nome: 'Contato', ordem: 20, tipo: 'aberta', probabilidade: 25, cor: 'ciano' },
  { chave: 'proposta', nome: 'Proposta', ordem: 30, tipo: 'aberta', probabilidade: 50, cor: 'roxo' },
  { chave: 'negociacao', nome: 'Negociação', ordem: 40, tipo: 'aberta', probabilidade: 75, cor: 'laranja' },
  { chave: 'ganho', nome: 'Ganho', ordem: 90, tipo: 'ganho', probabilidade: 100, cor: 'sucesso' },
  { chave: 'perdido', nome: 'Perdido', ordem: 99, tipo: 'perdido', probabilidade: 0, cor: 'perigo' },
];

function validar(d: EtapaDados): ErroDominio[] {
  const e: ErroDominio[] = [];
  if (!d.funil_id) e.push(erroDe('funil_obrigatorio', 'Informe o pipeline da etapa', 'funil_id'));
  if (d.nome.length < 1 || d.nome.length > 60) e.push(erroDe('nome_invalido', 'Nome deve ter de 1 a 60 caracteres', 'nome'));
  if (!Number.isInteger(d.ordem) || d.ordem < 0 || d.ordem > 999) e.push(erroDe('ordem_invalida', 'Ordem deve ser inteiro de 0 a 999', 'ordem'));
  if (!TIPOS_ETAPA.includes(d.tipo)) e.push(erroDe('tipo_invalido', 'Tipo deve ser aberta, ganho ou perdido', 'tipo'));
  if (!Number.isInteger(d.probabilidade) || d.probabilidade < 0 || d.probabilidade > 100) e.push(erroDe('probabilidade_invalida', 'Probabilidade de 0 a 100', 'probabilidade'));
  if (d.tipo === 'ganho' && d.probabilidade !== 100) e.push(erroDe('probabilidade_invalida', 'Etapa de ganho tem probabilidade 100', 'probabilidade'));
  if (d.tipo === 'perdido' && d.probabilidade !== 0) e.push(erroDe('probabilidade_invalida', 'Etapa de perda tem probabilidade 0', 'probabilidade'));
  if (!CORES.includes(d.cor)) e.push(erroDe('cor_invalida', `Cor deve ser um token: ${CORES.join(', ')}`, 'cor'));
  return e;
}

export class Etapa {
  private constructor(private readonly d: EtapaDados) {}

  static tryCreate(e: DadosEtapa, id: string = randomUUID()): Result<Etapa> {
    const tipo = e.tipo ?? 'aberta';
    const d: EtapaDados = {
      id, funil_id: e.funil_id ?? '', nome: (e.nome ?? '').trim(), ordem: e.ordem ?? 50, tipo,
      probabilidade: e.probabilidade ?? (tipo === 'ganho' ? 100 : tipo === 'perdido' ? 0 : 10), cor: e.cor ?? 'acento',
    };
    const erros = validar(d);
    return erros.length ? fail(...erros) : ok(new Etapa(d));
  }

  static create(e: DadosEtapa, id?: string): Etapa {
    const r = Etapa.tryCreate(e, id);
    if (!r.ok) throw new Error(r.erros.map((x) => x.mensagem).join('; '));
    return r.valor;
  }

  static reidratar(d: EtapaDados): Etapa {
    return new Etapa({ ...d });
  }

  get id(): string { return this.d.id; }
  get funilId(): string { return this.d.funil_id; }
  get ordem(): number { return this.d.ordem; }
  get tipo(): TipoEtapa { return this.d.tipo; }
  get probabilidade(): number { return this.d.probabilidade; }
  get nome(): string { return this.d.nome; }

  /** O tipo nao muda depois de criada: trocar uma etapa final quebraria o historico de ganhos e perdas. */
  editar(e: Partial<Omit<DadosEtapa, 'tipo' | 'funil_id'>>): Result<Etapa> {
    const n: EtapaDados = {
      ...this.d,
      nome: e.nome !== undefined ? e.nome.trim() : this.d.nome,
      ordem: e.ordem ?? this.d.ordem,
      probabilidade: e.probabilidade ?? this.d.probabilidade,
      cor: e.cor ?? this.d.cor,
    };
    const erros = validar(n);
    return erros.length ? fail(...erros) : ok(new Etapa(n));
  }

  paraDados(): EtapaDados {
    return { ...this.d };
  }
}
