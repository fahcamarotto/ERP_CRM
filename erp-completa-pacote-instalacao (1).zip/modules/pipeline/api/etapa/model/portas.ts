/** Portas do repositorio de Etapas, segregadas por operacao. Toda listagem e por funil. */
import type { Etapa, TipoEtapa } from './etapa.ts';

export interface ObterEtapa {
  obterPorId(id: string): Promise<Etapa | null>;
}

export interface ListarEtapas {
  listar(funilId: string): Promise<Etapa[]>;
  porTipo(funilId: string, tipo: TipoEtapa): Promise<Etapa | null>;
  buscarPorNome(funilId: string, nome: string): Promise<Etapa | null>;
}

export interface GravarEtapa {
  inserir(e: Etapa): Promise<void>;
  atualizar(e: Etapa): Promise<void>;
  excluir(id: string): Promise<void>;
}

/** Quantas oportunidades vivas estao na etapa (exclusao so sem uso). */
export interface ContarUsoEtapa {
  emUso(id: string): Promise<number>;
}

/** Serializa a criacao das etapas iniciais e a reordenacao por funil (duas requisicoes simultaneas nao duplicam). */
export interface TravarFunil {
  travarFunil(funilId: string): Promise<void>;
}
