/** Rotas REST das Etapas (M2.2). Listar e reordenar sao @tool em ../tools.ts (etapas.listar, etapas.reordenar). */
import { esquemaErro, requer, type FastifyInstance } from '@erp/api/sdk';
import { naTransacao } from '../borda.ts';
import { exigirOk } from '../compartilhado/result.ts';
import { propsEtapa, uuid } from '../esquemas.ts';
import type { DadosEtapa } from './model/etapa.ts';

const tags = ['pipeline'];
const erros = { 400: esquemaErro, 404: esquemaErro, 409: esquemaErro };
const paramId = { type: 'object', required: ['id'], properties: { id: uuid } } as const;
const { tipo: _tipo, funil_id: _funil, ...propsEdicao } = propsEtapa;

export function rotasEtapa(app: FastifyInstance): void {
  app.post<{ Body: DadosEtapa }>('/etapas', {
    preHandler: requer('pipeline.editar'),
    schema: { tags, summary: 'Cria etapa num pipeline; sem funil_id, no pipeline padrao (CriarEtapa)', body: { type: 'object', additionalProperties: false, required: ['nome'], properties: propsEtapa }, response: erros },
  }, async (req, reply) => reply.code(201).send(await naTransacao(req, async (casos, ctx) => {
    const funil = exigirOk(await casos.resolverFunil.execute(ctx, req.body.funil_id ?? null));
    return exigirOk(await casos.criarEtapa.execute(ctx, { ...req.body, funil_id: funil.id }));
  })));

  app.patch<{ Params: { id: string }; Body: Partial<Omit<DadosEtapa, 'tipo' | 'funil_id'>> }>('/etapas/:id', {
    preHandler: requer('pipeline.editar'),
    schema: { tags, summary: 'Edita nome, ordem, probabilidade e cor da etapa (EditarEtapa)', params: paramId, body: { type: 'object', additionalProperties: false, properties: propsEdicao }, response: erros },
  }, async (req, reply) => {
    await naTransacao(req, async (casos, ctx) => exigirOk(await casos.editarEtapa.execute(ctx, { ...req.body, id: req.params.id })));
    return reply.code(204).send();
  });

  app.delete<{ Params: { id: string } }>('/etapas/:id', {
    preHandler: requer('pipeline.excluir'),
    schema: { tags, summary: 'Exclui etapa aberta sem oportunidades (ExcluirEtapa)', params: paramId, response: erros },
  }, async (req, reply) => {
    await naTransacao(req, async (casos, ctx) => exigirOk(await casos.excluirEtapa.execute(ctx, { id: req.params.id })));
    return reply.code(204).send();
  });
}
