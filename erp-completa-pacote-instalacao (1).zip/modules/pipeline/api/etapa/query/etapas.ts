/** Consulta das Etapas de um funil com contagem e valor das oportunidades vivas em cada uma. */
import type pg from 'pg';

export async function listarEtapas(c: pg.PoolClient, funilId: string) {
  const r = await c.query(
    `SELECT e.id, e.funil_id, e.nome, e.ordem, e.tipo, e.probabilidade, e.cor, e.created_at, e.updated_at,
       count(o.id)::int AS quantidade, coalesce(sum(o.valor), 0)::float8 AS valor_total
     FROM pipeline_etapas e
     LEFT JOIN pipeline_oportunidades o ON o.etapa_id = e.id AND o.deleted_at IS NULL
     WHERE e.deleted_at IS NULL AND e.funil_id = $1
     GROUP BY e.id, e.funil_id, e.nome, e.ordem, e.tipo, e.probabilidade, e.cor, e.created_at, e.updated_at ORDER BY e.ordem, e.nome`,
    [funilId],
  );
  return r.rows;
}
