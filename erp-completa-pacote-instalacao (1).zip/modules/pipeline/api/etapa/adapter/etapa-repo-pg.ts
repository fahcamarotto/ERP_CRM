/** Adaptador Postgres das portas de Etapa (RLS restringe ao workspace da sessao). */
import type pg from 'pg';
import { Etapa, type EtapaDados, type TipoEtapa } from '../model/etapa.ts';
import type { ContarUsoEtapa, GravarEtapa, ListarEtapas, ObterEtapa, TravarFunil } from '../model/portas.ts';
import type { ConsultarFunilDaEtapa } from '../use-case/etapas.ts';

const COLUNAS = 'id, funil_id, nome, ordem, tipo, probabilidade, cor';

export class EtapaRepoPg implements ObterEtapa, ListarEtapas, GravarEtapa, ContarUsoEtapa, TravarFunil, ConsultarFunilDaEtapa {
  constructor(private readonly c: pg.PoolClient) {}

  async obterPorId(id: string) {
    const r = await this.c.query(`SELECT ${COLUNAS} FROM pipeline_etapas WHERE id = $1 AND deleted_at IS NULL`, [id]);
    return r.rows[0] ? Etapa.reidratar(r.rows[0] as EtapaDados) : null;
  }

  async listar(funilId: string) {
    const r = await this.c.query(`SELECT ${COLUNAS} FROM pipeline_etapas WHERE funil_id = $1 AND deleted_at IS NULL ORDER BY ordem, nome`, [funilId]);
    return r.rows.map((x) => Etapa.reidratar(x as EtapaDados));
  }

  async porTipo(funilId: string, tipo: TipoEtapa) {
    const r = await this.c.query(`SELECT ${COLUNAS} FROM pipeline_etapas WHERE funil_id = $1 AND tipo = $2 AND deleted_at IS NULL ORDER BY ordem LIMIT 1`, [funilId, tipo]);
    return r.rows[0] ? Etapa.reidratar(r.rows[0] as EtapaDados) : null;
  }

  async buscarPorNome(funilId: string, nome: string) {
    const r = await this.c.query(`SELECT ${COLUNAS} FROM pipeline_etapas WHERE funil_id = $1 AND lower(nome) = lower($2) AND deleted_at IS NULL`, [funilId, nome]);
    return r.rows[0] ? Etapa.reidratar(r.rows[0] as EtapaDados) : null;
  }

  async inserir(e: Etapa) {
    const d = e.paraDados();
    await this.c.query(
      'INSERT INTO pipeline_etapas (id, funil_id, nome, ordem, tipo, probabilidade, cor, creator_id) VALUES ($1, $2, $3, $4, $5, $6, $7, nucleo_usuario_atual())',
      [d.id, d.funil_id, d.nome, d.ordem, d.tipo, d.probabilidade, d.cor],
    );
  }

  async atualizar(e: Etapa) {
    const d = e.paraDados();
    await this.c.query('UPDATE pipeline_etapas SET nome = $2, ordem = $3, probabilidade = $4, cor = $5 WHERE id = $1 AND deleted_at IS NULL', [d.id, d.nome, d.ordem, d.probabilidade, d.cor]);
  }

  async excluir(id: string) {
    await this.c.query('UPDATE pipeline_etapas SET deleted_at = now() WHERE id = $1 AND deleted_at IS NULL', [id]);
  }

  async travarFunil(funilId: string) {
    await this.c.query("SELECT pg_advisory_xact_lock(hashtext('pipeline_etapas:' || nucleo_workspace_atual()::text || ':' || $1::text))", [funilId]);
  }

  async emUso(id: string) {
    const r = await this.c.query('SELECT count(*)::int AS n FROM pipeline_oportunidades WHERE etapa_id = $1 AND deleted_at IS NULL', [id]);
    return r.rows[0].n as number;
  }

  async funilVivo(id: string) {
    const r = await this.c.query('SELECT id, arquivado FROM pipeline_funis WHERE id = $1 AND deleted_at IS NULL', [id]);
    return (r.rows[0] as { id: string; arquivado: boolean } | undefined) ?? null;
  }
}
