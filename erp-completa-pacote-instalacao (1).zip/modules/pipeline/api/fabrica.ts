/**
 * Composicao do modulo: liga casos de uso aos adaptadores Postgres para um cliente de transacao.
 * Usada pelas rotas, pelas tools, pelo worker e pelo seed. Nao importa Fastify nem o pool do servidor.
 */
import type pg from 'pg';
import { AtividadeRepoPg } from './atividade/adapter/atividade-repo-pg.ts';
import { AgendarAtividade, CancelarAtividade, ConcluirAtividade, EditarAtividade } from './atividade/use-case/atividades.ts';
import { EquipeRepoPg } from './equipe/adapter/equipe-repo-pg.ts';
import { CriarEquipe, EditarEquipe, ExcluirEquipe } from './equipe/use-case/equipes.ts';
import { EtapaRepoPg } from './etapa/adapter/etapa-repo-pg.ts';
import { CriarEtapa, EditarEtapa, ExcluirEtapa, GarantirEtapasPadrao, ReordenarEtapas } from './etapa/use-case/etapas.ts';
import { FunilRepoPg } from './funil/adapter/funil-repo-pg.ts';
import { ArquivarFunil, CriarFunil, GarantirFunilPadrao, RenomearFunil, ResolverFunil } from './funil/use-case/funis.ts';
import { MetaRepoPg } from './meta/adapter/meta-repo-pg.ts';
import { CriarMeta, EditarMeta, ExcluirMeta } from './meta/use-case/metas.ts';
import { MotivoRepoPg } from './motivo/adapter/motivo-repo-pg.ts';
import { CriarMotivo, EditarMotivo, ExcluirMotivo } from './motivo/use-case/motivos.ts';
import { OportunidadeRepoPg } from './oportunidade/adapter/oportunidade-repo-pg.ts';
import { AbrirOportunidadeDeConversa, AbrirOportunidadeDeLead } from './oportunidade/use-case/abrir-de-lead.ts';
import { CriarOportunidade } from './oportunidade/use-case/criar-oportunidade.ts';
import { EditarOportunidade, ExcluirOportunidade } from './oportunidade/use-case/editar-oportunidade.ts';
import { MarcarGanha, MarcarPerdida, VincularProjeto } from './oportunidade/use-case/fechar-oportunidade.ts';
import { MoverEtapa, ReabrirOportunidade } from './oportunidade/use-case/mover-etapa.ts';

import { AplicarOportunidadeDeAutomacao } from './oportunidade/use-case/abrir-de-automacao.ts';
export function casosDeUso(c: pg.PoolClient) {
  const etapas = new EtapaRepoPg(c);
  const ops = new OportunidadeRepoPg(c);
  const atividades = new AtividadeRepoPg(c);
  const equipes = new EquipeRepoPg(c);
  const metas = new MetaRepoPg(c);
  const motivos = new MotivoRepoPg(c);
  const funis = new FunilRepoPg(c);
  const garantirEtapas = new GarantirEtapasPadrao({ repo: etapas });
  const garantirFunil = new GarantirFunilPadrao({ repo: funis, etapas: garantirEtapas });
  const resolverFunil = new ResolverFunil({ repo: funis, padrao: garantirFunil });
  const criarOportunidade = new CriarOportunidade({ repo: ops, etapas: ops, refs: ops, funil: resolverFunil });
  const depsFechar = { repo: ops, etapas: ops, refs: ops };
  const moverEtapa = new MoverEtapa({ repo: ops, etapas: ops });
  return {
    garantirEtapas,
    garantirFunil,
    resolverFunil,
    criarFunil: new CriarFunil({ repo: funis, etapas }),
    renomearFunil: new RenomearFunil({ repo: funis }),
    arquivarFunil: new ArquivarFunil({ repo: funis, ops: { mover: moverEtapa, primeiraAberta: (id) => ops.primeiraAberta(id) } }),
    criarEtapa: new CriarEtapa({ repo: etapas, funis: etapas }),
    editarEtapa: new EditarEtapa({ repo: etapas }),
    reordenarEtapas: new ReordenarEtapas({ repo: etapas, funis: etapas }),
    excluirEtapa: new ExcluirEtapa({ repo: etapas }),
    criarOportunidade,
    editarOportunidade: new EditarOportunidade({ repo: ops, refs: ops }),
    excluirOportunidade: new ExcluirOportunidade({ repo: ops }),
    moverEtapa,
    reabrirOportunidade: new ReabrirOportunidade({ repo: ops, etapas: ops }),
    marcarGanha: new MarcarGanha(depsFechar),
    marcarPerdida: new MarcarPerdida(depsFechar),
    vincularProjeto: new VincularProjeto({ repo: ops, refs: ops }),
    abrirDeLead: new AbrirOportunidadeDeLead({ repo: ops, etapas: ops, criar: criarOportunidade }),
    abrirDeConversa: new AbrirOportunidadeDeConversa({ repo: ops, criar: criarOportunidade }),
    aplicarDeAutomacao: new AplicarOportunidadeDeAutomacao({ repo: ops, etapas: ops, criar: criarOportunidade, mover: moverEtapa }),
    agendarAtividade: new AgendarAtividade({ repo: atividades, refs: atividades }),
    editarAtividade: new EditarAtividade({ repo: atividades, refs: atividades }),
    concluirAtividade: new ConcluirAtividade({ repo: atividades }),
    cancelarAtividade: new CancelarAtividade({ repo: atividades }),
    criarEquipe: new CriarEquipe({ repo: equipes, refs: equipes }),
    editarEquipe: new EditarEquipe({ repo: equipes, refs: equipes }),
    excluirEquipe: new ExcluirEquipe({ repo: equipes, refs: equipes }),
    criarMeta: new CriarMeta({ repo: metas, refs: metas }),
    editarMeta: new EditarMeta({ repo: metas }),
    excluirMeta: new ExcluirMeta({ repo: metas }),
    criarMotivo: new CriarMotivo({ repo: motivos }),
    editarMotivo: new EditarMotivo({ repo: motivos }),
    excluirMotivo: new ExcluirMotivo({ repo: motivos }),
  };
}

export type CasosDeUso = ReturnType<typeof casosDeUso>;
