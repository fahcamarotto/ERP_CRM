/**
 * Handlers de worker do Pipeline (carregados pelo worker do nucleo na partida).
 * `c` ja esta numa transacao do papel erp_worker com o escopo do job (RLS vale).
 */
import type { HandlersModulo } from '@erp/api/sdk/puro';
import { contextoPg } from '../api/compartilhado/efeitos-pg.ts';
import { casosDeUso } from '../api/fabrica.ts';
import type { EventoConversa, EventoLead } from '../api/oportunidade/use-case/abrir-de-lead.ts';
import type { EventoAutomacao } from '../api/oportunidade/use-case/abrir-de-automacao.ts';

const SISTEMA = { tipo: 'sistema' as const, id: null };

const handlers: HandlersModulo = {
  // Reacao a lead.recebido do Cadastros (CONTRATOS 7.1.1): abre a oportunidade no pipeline e na etapa da fonte de lead
  // (sem destino ou com destino arquivado, na primeira etapa do pipeline padrao), com origem, UTM e responsavel.
  'pipeline:ao:lead.recebido': async (d, c) => {
    const ev = d.payload as EventoLead;
    if (!ev?.id || !ev.dados?.parceiro_id) return; // payload fora do contrato: nada a reprocessar
    const r = await casosDeUso(c).abrirDeLead.execute(contextoPg(c, SISTEMA), ev);
    if (!r.ok) throw new Error(r.erros.map((e) => e.mensagem).join('; '));
  },
  // Reacao a conversa.oportunidade_solicitada do Conversas: abre a oportunidade no pipeline padrao (idempotente pelo id do evento).
  'pipeline:ao:conversa.oportunidade_solicitada': async (d, c) => {
    const ev = d.payload as EventoConversa;
    if (!ev?.id || !ev.dados?.parceiro_id || !ev.dados?.titulo) return; // payload fora do contrato: nada a reprocessar
    const r = await casosDeUso(c).abrirDeConversa.execute(contextoPg(c, SISTEMA), ev);
    if (!r.ok) throw new Error(r.erros.map((e) => e.mensagem).join('; '));
  },
  // Reacao a automacao.oportunidade_solicitada do Automacoes: move a oportunidade aberta do cliente ou cria na etapa pedida.
  'pipeline:ao:automacao.oportunidade_solicitada': async (d, c) => {
    const ev = d.payload as EventoAutomacao;
    if (!ev?.id || !ev.dados?.parceiro_id || !ev.dados?.etapa_id) return; // payload fora do contrato: nada a reprocessar
    const r = await casosDeUso(c).aplicarDeAutomacao.execute(contextoPg(c, SISTEMA), ev);
    if (!r.ok) throw new Error(r.erros.map((e) => e.mensagem).join('; '));
  },
};

export default handlers;
