/**
 * Seed demo do Pipeline: funil padrao, motivos de perda, equipes, metas do mes, oportunidades em todas as etapas
 * (abertas, ganhas e perdidas, com origem, canal e UTM) e atividades. Idempotente: ids deterministicos por chave,
 * insercao so do que falta, no workspace do contexto. Grava pelos adaptadores e entidades do modulo.
 * Clientes: so ids lidos da tabela publicada cadastros_parceiros (o seed do Cadastros roda antes).
 */
import { createHash } from 'node:crypto';
import type { SeedModulo } from '@erp/api/sdk/puro';
import { AtividadeRepoPg } from '../api/atividade/adapter/atividade-repo-pg.ts';
import { Atividade, type TipoAtividade } from '../api/atividade/model/atividade.ts';
import { EquipeRepoPg } from '../api/equipe/adapter/equipe-repo-pg.ts';
import { Equipe } from '../api/equipe/model/equipe.ts';
import { EtapaRepoPg } from '../api/etapa/adapter/etapa-repo-pg.ts';
import { GarantirEtapasPadrao } from '../api/etapa/use-case/etapas.ts';
import { FunilRepoPg } from '../api/funil/adapter/funil-repo-pg.ts';
import { GarantirFunilPadrao } from '../api/funil/use-case/funis.ts';
import { MetaRepoPg } from '../api/meta/adapter/meta-repo-pg.ts';
import { Meta } from '../api/meta/model/meta.ts';
import { MotivoRepoPg } from '../api/motivo/adapter/motivo-repo-pg.ts';
import { MotivoPerda } from '../api/motivo/model/motivo.ts';
import { OportunidadeRepoPg } from '../api/oportunidade/adapter/oportunidade-repo-pg.ts';
import { Oportunidade, type Canal, type EtapaRef } from '../api/oportunidade/model/oportunidade.ts';

/** uuid deterministico a partir de uma chave (mesmo id em toda execucao). */
function idDe(chave: string): string {
  const h = createHash('sha256').update(`pipeline-demo:${chave}`).digest('hex');
  return `${h.slice(0, 8)}-${h.slice(8, 12)}-4${h.slice(13, 16)}-a${h.slice(17, 20)}-${h.slice(20, 32)}`;
}

const MOTIVOS = [
  ['preco', 'Preço acima do orçamento', 'Cliente achou o investimento alto para o momento.'],
  ['concorrente', 'Fechou com concorrente', null],
  ['sem-orcamento', 'Sem orçamento aprovado', null],
  ['sem-resposta', 'Sem resposta do contato', 'Mais de 3 tentativas sem retorno.'],
  ['timing', 'Momento inadequado', 'Pediu para retomar no próximo semestre.'],
] as const;

type Destino = 'novo' | 'contato' | 'proposta' | 'negociacao' | 'ganho' | 'perdido';
const OPORTUNIDADES: { k: string; titulo: string; cli: number; valor: number; destino: Destino; dias: number; equipe: 'inside' | 'contas'; canal: Canal; origem: string; utm?: [string, string, string]; motivo?: string; previsao: number }[] = [
  { k: 'o1', titulo: 'Portal do cliente: fase 2', cli: 0, valor: 48000, destino: 'negociacao', dias: 34, equipe: 'contas', canal: 'indicacao', origem: 'indicacao', previsao: 12 },
  { k: 'o2', titulo: 'Contrato anual de suporte', cli: 1, valor: 18000, destino: 'proposta', dias: 21, equipe: 'inside', canal: 'site', origem: 'landing', utm: ['google', 'cpc', 'suporte-anual'], previsao: 20 },
  { k: 'o3', titulo: 'Implantação do ERP em 3 lojas', cli: 1, valor: 96000, destino: 'contato', dias: 9, equipe: 'contas', canal: 'evento', origem: 'feira-varejo', previsao: 45 },
  { k: 'o4', titulo: 'Agenda online com lembretes', cli: 2, valor: 12500, destino: 'novo', dias: 2, equipe: 'inside', canal: 'instagram', origem: 'instagram', utm: ['instagram', 'social', 'agenda-clinicas'], previsao: 30 },
  { k: 'o5', titulo: 'Treinamento da equipe comercial', cli: 3, valor: 7800, destino: 'novo', dias: 1, equipe: 'inside', canal: 'whatsapp', origem: 'whatsapp', previsao: 25 },
  { k: 'o6', titulo: 'Consultoria de processos fiscais', cli: 4, valor: 32000, destino: 'ganho', dias: 40, equipe: 'contas', canal: 'telefone', origem: 'outbound', previsao: -3 },
  { k: 'o7', titulo: 'Mentoria individual premium', cli: 5, valor: 6000, destino: 'ganho', dias: 18, equipe: 'inside', canal: 'site', origem: 'landing', utm: ['facebook', 'paid-social', 'mentoria'], previsao: -8 },
  { k: 'o8', titulo: 'Renovação de licenças', cli: 0, valor: 22000, destino: 'perdido', dias: 27, equipe: 'contas', canal: 'email', origem: 'base', motivo: 'concorrente', previsao: -5 },
  { k: 'o9', titulo: 'Pacote de horas de desenvolvimento', cli: 6, valor: 15000, destino: 'perdido', dias: 15, equipe: 'inside', canal: 'site', origem: 'landing', utm: ['google', 'organic', 'blog'], motivo: 'preco', previsao: -1 },
  { k: 'o10', titulo: 'Integração com WhatsApp oficial', cli: 7, valor: 9800, destino: 'proposta', dias: 11, equipe: 'inside', canal: 'whatsapp', origem: 'whatsapp', previsao: 15 },
];

const ATIVIDADES: { k: string; op: string; tipo: TipoAtividade; titulo: string; horas: number; concluida?: string }[] = [
  { k: 'a1', op: 'o1', tipo: 'reuniao', titulo: 'Reunião de negociação com diretoria', horas: 26 },
  { k: 'a2', op: 'o2', tipo: 'follow_up', titulo: 'Retornar sobre a proposta enviada', horas: 4 },
  { k: 'a3', op: 'o3', tipo: 'ligacao', titulo: 'Ligar para entender o escopo das lojas', horas: -20 },
  { k: 'a4', op: 'o4', tipo: 'tarefa', titulo: 'Montar demonstração da agenda', horas: 50 },
  { k: 'a5', op: 'o6', tipo: 'reuniao', titulo: 'Kickoff do projeto fiscal', horas: -72, concluida: 'Escopo validado e cronograma aprovado.' },
  { k: 'a6', op: 'o10', tipo: 'ligacao', titulo: 'Confirmar volume de mensagens', horas: 3 },
];

const semear: SeedModulo = async ({ c, usuarioId, log }) => {
  const etapasRepo = new EtapaRepoPg(c);
  const ops = new OportunidadeRepoPg(c);
  const motivos = new MotivoRepoPg(c);
  const equipes = new EquipeRepoPg(c);
  const metas = new MetaRepoPg(c);
  const atividades = new AtividadeRepoPg(c);
  let novos = 0;

  // Funil: Pipeline padrao e suas etapas com ids deterministicos quando o workspace ainda nao tem.
  const garantirEtapas = new GarantirEtapasPadrao({ repo: etapasRepo, novoId: (k) => idDe(`etapa:${k}`) });
  const g = await new GarantirFunilPadrao({ repo: new FunilRepoPg(c), etapas: garantirEtapas, novoId: () => idDe('funil:padrao') }).execute(null);
  if (!g.ok) throw new Error(g.erros[0]!.mensagem);
  if (g.valor.criado) novos++;
  const lista = await etapasRepo.listar(g.valor.id);
  const abertas = lista.filter((e) => e.tipo === 'aberta');
  const porNome = new Map(lista.map((e) => [e.nome.toLowerCase(), e]));
  const ref = (e: { id: string; tipo: EtapaRef['tipo']; probabilidade: number; funilId: string }): EtapaRef => ({ id: e.id, tipo: e.tipo, probabilidade: e.probabilidade, funil_id: e.funilId });
  const etapa = (d: Destino): EtapaRef => {
    if (d === 'ganho' || d === 'perdido') return ref(lista.find((e) => e.tipo === d)!);
    const nome = { novo: 'novo', contato: 'contato', proposta: 'proposta', negociacao: 'negociação' }[d];
    const idx = { novo: 0, contato: 1, proposta: 2, negociacao: 3 }[d];
    return ref(porNome.get(nome) ?? abertas[Math.min(idx, abertas.length - 1)]!);
  };

  const motivoIds = new Map<string, string>();
  for (const [k, nome, descricao] of MOTIVOS) {
    const id = idDe(`motivo:${k}`);
    const existente = (await motivos.obterPorId(id)) ?? (await motivos.buscarPorNome(nome));
    if (!existente) { await motivos.inserir(MotivoPerda.create({ nome, descricao }, id)); novos++; }
    motivoIds.set(k, existente?.id ?? id);
  }

  const equipeIds = new Map<string, string>();
  for (const [k, nome, cor] of [['inside', 'Inside Sales', 'azul'], ['contas', 'Contas Estratégicas', 'roxo']] as const) {
    const id = idDe(`equipe:${k}`);
    const existente = (await equipes.obterPorId(id)) ?? (await equipes.buscarPorNome(nome));
    if (!existente) { await equipes.inserir(Equipe.create({ nome, cor, lider_id: usuarioId, membro_ids: [usuarioId] }, id)); novos++; }
    equipeIds.set(k, existente?.id ?? id);
  }

  // Metas do mes corrente e do anterior (o anterior ja tem ganhos demo realizados).
  const hoje = new Date();
  const competencias = [hoje.toISOString().slice(0, 7), new Date(Date.UTC(hoje.getUTCFullYear(), hoje.getUTCMonth() - 1, 1)).toISOString().slice(0, 7)];
  const alvos: [string, string | null, string | null, number][] = [
    ['inside', equipeIds.get('inside')!, null, 60000], ['contas', equipeIds.get('contas')!, null, 150000], ['vendedor', null, usuarioId, 80000],
  ];
  for (const competencia of competencias) {
    for (const [k, equipe, vendedor, valor] of alvos) {
      const id = idDe(`meta:${k}:${competencia}`);
      if ((await metas.obterPorId(id)) || (await metas.buscarMesmoAlvo(competencia, equipe, vendedor))) continue;
      await metas.inserir(Meta.create({ competencia, equipe_id: equipe, vendedor_id: vendedor, valor_alvo: valor }, id));
      novos++;
    }
  }

  const clientes = (await c.query("SELECT id FROM cadastros_parceiros WHERE e_cliente AND estado = 'ativo' AND deleted_at IS NULL ORDER BY created_at, id LIMIT 8")).rows.map((r) => r.id as string);
  const dia = 86400000;
  const opIds = new Map<string, string>();
  for (const o of OPORTUNIDADES) {
    const id = idDe(`oportunidade:${o.k}`);
    opIds.set(o.k, id);
    if (await ops.obterPorId(id)) continue;
    const inicio = new Date(Date.now() - o.dias * dia).toISOString();
    const primeira = etapa('novo');
    let atual = Oportunidade.create({
      titulo: o.titulo, parceiro_id: clientes.length ? clientes[o.cli % clientes.length]! : null, valor: o.valor, responsavel_id: usuarioId,
      equipe_id: equipeIds.get(o.equipe)!, canal: o.canal, origem: o.origem, utm_source: o.utm?.[0] ?? null, utm_medium: o.utm?.[1] ?? null,
      utm_campaign: o.utm?.[2] ?? null, previsao_fechamento: new Date(Date.now() + o.previsao * dia).toISOString().slice(0, 10),
    }, primeira, id);
    const caminho: Destino[] = ['contato', 'proposta', 'negociacao'];
    const ate = { novo: 0, contato: 1, proposta: 2, negociacao: 3, ganho: 3, perdido: Math.min(2, o.dias % 3 + 1) }[o.destino];
    const movimentos: [string, string][] = [];
    for (const passo of caminho.slice(0, ate)) {
      const e = etapa(passo);
      if (e.id === atual.etapaId) continue;
      const r = atual.mover(e, new Date(Date.parse(inicio) + (movimentos.length + 1) * 2 * dia).toISOString());
      if (!r.ok) throw new Error(r.erros[0]!.mensagem);
      movimentos.push([atual.etapaId, e.id]);
      atual = r.valor;
    }
    const fechamento = new Date(Date.now() - Math.max(1, Math.floor(o.dias / 6)) * dia).toISOString();
    if (o.destino === 'ganho' || o.destino === 'perdido') {
      const final = etapa(o.destino);
      const r = o.destino === 'ganho' ? atual.marcarGanha(final, fechamento) : atual.marcarPerdida(final, motivoIds.get(o.motivo!), null, fechamento);
      if (!r.ok) throw new Error(r.erros[0]!.mensagem);
      movimentos.push([atual.etapaId, final.id]);
      atual = r.valor;
    }
    await ops.inserir(atual);
    // Datas demo no passado para o ciclo medio e a conversao terem historico plausivel (tabelas do proprio modulo).
    await c.query('UPDATE pipeline_oportunidades SET created_at = $2 WHERE id = $1', [id, inicio]);
    const passos: [string | null, string][] = [[null, primeira.id], ...movimentos];
    for (const [i, [de, para]] of passos.entries()) {
      await ops.registrarMovimento(id, de, para);
      const quando = i === passos.length - 1 && atual.estado !== 'aberta' ? fechamento : new Date(Date.parse(inicio) + i * 2 * dia).toISOString();
      await c.query('UPDATE pipeline_movimentos SET created_at = $2 WHERE oportunidade_id = $1 AND created_at = now()', [id, quando]);
    }
    novos++;
  }

  for (const a of ATIVIDADES) {
    const id = idDe(`atividade:${a.k}`);
    if (await atividades.obterPorId(id)) continue;
    let at = Atividade.create({ tipo: a.tipo, titulo: a.titulo, data: new Date(Date.now() + a.horas * 3600000).toISOString(), duracao_min: a.tipo === 'reuniao' ? 60 : 30, responsavel_id: usuarioId, oportunidade_id: opIds.get(a.op)! }, id);
    if (a.concluida) { const r = at.concluir(a.concluida); if (!r.ok) throw new Error(r.erros[0]!.mensagem); at = r.valor; }
    await atividades.inserir(at);
    novos++;
  }

  log(`${novos} registro(s) demo novo(s) (${lista.length} etapas, ${MOTIVOS.length} motivos, 2 equipes, ${alvos.length * competencias.length} metas, ${OPORTUNIDADES.length} oportunidades, ${ATIVIDADES.length} atividades)`);
};

export default semear;
