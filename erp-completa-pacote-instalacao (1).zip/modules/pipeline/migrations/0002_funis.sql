-- M2 Varios pipelines (funis): cada workspace tem um ou mais funis; etapas e oportunidades pertencem a um funil.
-- Migracao de dados: todo workspace com etapas ou oportunidades ganha o funil "Pipeline padrão" e tudo que existe
-- vai para ele. Workspace sem nada recebe o funil padrao na primeira leitura (GarantirFunilPadrao, sem seed manual).
-- Toda tabela: tenant_id e workspace_id do contexto, PK composta, FK composta, RLS por nucleo_aplicar_padrao. Idempotente.

CREATE TABLE IF NOT EXISTS pipeline_funis (
  id            uuid NOT NULL DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL DEFAULT nucleo_tenant_atual(),
  workspace_id  uuid NOT NULL DEFAULT nucleo_workspace_atual(),
  creator_id    uuid,
  nome          text NOT NULL CHECK (length(btrim(nome)) BETWEEN 1 AND 60),
  ordem         integer NOT NULL DEFAULT 0 CHECK (ordem BETWEEN 0 AND 9999),
  padrao        boolean NOT NULL DEFAULT false,
  arquivado     boolean NOT NULL DEFAULT false,
  arquivado_em  timestamptz,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now(),
  deleted_at    timestamptz,
  PRIMARY KEY (id, tenant_id, workspace_id),
  FOREIGN KEY (workspace_id, tenant_id) REFERENCES workspaces (id, tenant_id),
  FOREIGN KEY (creator_id, tenant_id, workspace_id) REFERENCES usuarios (id, tenant_id, workspace_id),
  CHECK (arquivado = (arquivado_em IS NOT NULL)),
  CHECK (NOT (padrao AND arquivado))
);
CREATE UNIQUE INDEX IF NOT EXISTS pipeline_funis_nome_uq ON pipeline_funis (tenant_id, workspace_id, lower(nome)) WHERE deleted_at IS NULL AND NOT arquivado;
-- um unico funil padrao por workspace (o que outros modulos usam quando nao informam funil)
CREATE UNIQUE INDEX IF NOT EXISTS pipeline_funis_padrao_uq ON pipeline_funis (tenant_id, workspace_id) WHERE padrao AND deleted_at IS NULL;
SELECT nucleo_aplicar_padrao('pipeline_funis');

ALTER TABLE pipeline_etapas ADD COLUMN IF NOT EXISTS funil_id uuid;
ALTER TABLE pipeline_oportunidades ADD COLUMN IF NOT EXISTS funil_id uuid;

-- Funil padrao em todo workspace que ja tem dado do Pipeline.
INSERT INTO pipeline_funis (tenant_id, workspace_id, nome, ordem, padrao)
SELECT x.tenant_id, x.workspace_id, 'Pipeline padrão', 10, true
FROM (SELECT tenant_id, workspace_id FROM pipeline_etapas UNION SELECT tenant_id, workspace_id FROM pipeline_oportunidades) x
WHERE NOT EXISTS (SELECT 1 FROM pipeline_funis f WHERE f.tenant_id = x.tenant_id AND f.workspace_id = x.workspace_id AND f.padrao AND f.deleted_at IS NULL);

UPDATE pipeline_etapas e SET funil_id = f.id
FROM pipeline_funis f
WHERE e.funil_id IS NULL AND f.tenant_id = e.tenant_id AND f.workspace_id = e.workspace_id AND f.padrao AND f.deleted_at IS NULL;

UPDATE pipeline_oportunidades o SET funil_id = e.funil_id
FROM pipeline_etapas e
WHERE o.funil_id IS NULL AND e.id = o.etapa_id AND e.tenant_id = o.tenant_id AND e.workspace_id = o.workspace_id;

ALTER TABLE pipeline_etapas ALTER COLUMN funil_id SET NOT NULL;
ALTER TABLE pipeline_oportunidades ALTER COLUMN funil_id SET NOT NULL;

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'pipeline_etapas_funil_fk') THEN
    ALTER TABLE pipeline_etapas ADD CONSTRAINT pipeline_etapas_funil_fk
      FOREIGN KEY (funil_id, tenant_id, workspace_id) REFERENCES pipeline_funis (id, tenant_id, workspace_id);
  END IF;
  -- a etapa da oportunidade e sempre do mesmo funil da oportunidade
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'pipeline_etapas_funil_uq') THEN
    ALTER TABLE pipeline_etapas ADD CONSTRAINT pipeline_etapas_funil_uq UNIQUE (id, funil_id, tenant_id, workspace_id);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'pipeline_oportunidades_funil_fk') THEN
    ALTER TABLE pipeline_oportunidades ADD CONSTRAINT pipeline_oportunidades_funil_fk
      FOREIGN KEY (funil_id, tenant_id, workspace_id) REFERENCES pipeline_funis (id, tenant_id, workspace_id);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'pipeline_oportunidades_etapa_funil_fk') THEN
    ALTER TABLE pipeline_oportunidades ADD CONSTRAINT pipeline_oportunidades_etapa_funil_fk
      FOREIGN KEY (etapa_id, funil_id, tenant_id, workspace_id) REFERENCES pipeline_etapas (id, funil_id, tenant_id, workspace_id);
  END IF;
END $$;

-- Nome e etapas finais passam a ser unicos por funil (antes: por workspace).
DROP INDEX IF EXISTS pipeline_etapas_nome_uq;
DROP INDEX IF EXISTS pipeline_etapas_tipo_final_uq;
CREATE UNIQUE INDEX IF NOT EXISTS pipeline_etapas_funil_nome_uq ON pipeline_etapas (tenant_id, workspace_id, funil_id, lower(nome)) WHERE deleted_at IS NULL;
CREATE UNIQUE INDEX IF NOT EXISTS pipeline_etapas_funil_tipo_final_uq ON pipeline_etapas (tenant_id, workspace_id, funil_id, tipo) WHERE tipo <> 'aberta' AND deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS pipeline_etapas_funil_idx ON pipeline_etapas (tenant_id, workspace_id, funil_id, ordem) WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS pipeline_oportunidades_funil_idx ON pipeline_oportunidades (tenant_id, workspace_id, funil_id) WHERE deleted_at IS NULL;

GRANT SELECT, INSERT, UPDATE ON pipeline_funis TO erp_app;
GRANT SELECT, INSERT, UPDATE ON pipeline_funis TO erp_worker;
