-- M2 Pipeline de oportunidades: etapas configuraveis, motivos de perda, equipes de venda com membros,
-- metas mensais, oportunidades, movimentos entre etapas (base da conversao e do ciclo) e atividades.
-- Toda tabela: tenant_id e workspace_id do contexto da sessao, PK composta, FK composta, RLS
-- por nucleo_aplicar_padrao, exclusao logica (sem DELETE). Idempotente.

-- M2.2 Etapas configuraveis por workspace --------------------------------------------------
CREATE TABLE IF NOT EXISTS pipeline_etapas (
  id             uuid NOT NULL DEFAULT gen_random_uuid(),
  tenant_id      uuid NOT NULL DEFAULT nucleo_tenant_atual(),
  workspace_id   uuid NOT NULL DEFAULT nucleo_workspace_atual(),
  creator_id     uuid,
  nome           text NOT NULL CHECK (length(btrim(nome)) BETWEEN 1 AND 60),
  ordem          integer NOT NULL DEFAULT 0 CHECK (ordem BETWEEN 0 AND 999),
  tipo           text NOT NULL DEFAULT 'aberta' CHECK (tipo IN ('aberta', 'ganho', 'perdido')),
  probabilidade  smallint NOT NULL DEFAULT 10 CHECK (probabilidade BETWEEN 0 AND 100),
  cor            text NOT NULL DEFAULT 'acento' CHECK (cor IN ('acento', 'roxo', 'azul', 'ciano', 'laranja', 'dourado', 'sucesso', 'perigo')),
  created_at     timestamptz NOT NULL DEFAULT now(),
  updated_at     timestamptz NOT NULL DEFAULT now(),
  deleted_at     timestamptz,
  PRIMARY KEY (id, tenant_id, workspace_id),
  FOREIGN KEY (workspace_id, tenant_id) REFERENCES workspaces (id, tenant_id),
  FOREIGN KEY (creator_id, tenant_id, workspace_id) REFERENCES usuarios (id, tenant_id, workspace_id)
);
CREATE UNIQUE INDEX IF NOT EXISTS pipeline_etapas_nome_uq ON pipeline_etapas (tenant_id, workspace_id, lower(nome)) WHERE deleted_at IS NULL;
-- uma unica etapa de ganho e uma unica de perda por workspace
CREATE UNIQUE INDEX IF NOT EXISTS pipeline_etapas_tipo_final_uq ON pipeline_etapas (tenant_id, workspace_id, tipo) WHERE tipo <> 'aberta' AND deleted_at IS NULL;
SELECT nucleo_aplicar_padrao('pipeline_etapas');

-- Motivos de perda --------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS pipeline_motivos_perda (
  id            uuid NOT NULL DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL DEFAULT nucleo_tenant_atual(),
  workspace_id  uuid NOT NULL DEFAULT nucleo_workspace_atual(),
  creator_id    uuid,
  nome          text NOT NULL CHECK (length(btrim(nome)) BETWEEN 2 AND 80),
  descricao     text,
  ativo         boolean NOT NULL DEFAULT true,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now(),
  deleted_at    timestamptz,
  PRIMARY KEY (id, tenant_id, workspace_id),
  FOREIGN KEY (workspace_id, tenant_id) REFERENCES workspaces (id, tenant_id),
  FOREIGN KEY (creator_id, tenant_id, workspace_id) REFERENCES usuarios (id, tenant_id, workspace_id)
);
CREATE UNIQUE INDEX IF NOT EXISTS pipeline_motivos_perda_nome_uq ON pipeline_motivos_perda (tenant_id, workspace_id, lower(nome)) WHERE deleted_at IS NULL;
SELECT nucleo_aplicar_padrao('pipeline_motivos_perda');

-- M2.4 Equipes de venda e membros -----------------------------------------------------------
CREATE TABLE IF NOT EXISTS pipeline_equipes (
  id            uuid NOT NULL DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL DEFAULT nucleo_tenant_atual(),
  workspace_id  uuid NOT NULL DEFAULT nucleo_workspace_atual(),
  creator_id    uuid,
  nome          text NOT NULL CHECK (length(btrim(nome)) BETWEEN 2 AND 80),
  lider_id      uuid,
  cor           text NOT NULL DEFAULT 'azul' CHECK (cor IN ('acento', 'roxo', 'azul', 'ciano', 'laranja', 'dourado', 'sucesso', 'perigo')),
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now(),
  deleted_at    timestamptz,
  PRIMARY KEY (id, tenant_id, workspace_id),
  FOREIGN KEY (workspace_id, tenant_id) REFERENCES workspaces (id, tenant_id),
  FOREIGN KEY (creator_id, tenant_id, workspace_id) REFERENCES usuarios (id, tenant_id, workspace_id),
  FOREIGN KEY (lider_id, tenant_id, workspace_id) REFERENCES usuarios (id, tenant_id, workspace_id)
);
CREATE UNIQUE INDEX IF NOT EXISTS pipeline_equipes_nome_uq ON pipeline_equipes (tenant_id, workspace_id, lower(nome)) WHERE deleted_at IS NULL;
SELECT nucleo_aplicar_padrao('pipeline_equipes');

CREATE TABLE IF NOT EXISTS pipeline_equipe_membros (
  id            uuid NOT NULL DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL DEFAULT nucleo_tenant_atual(),
  workspace_id  uuid NOT NULL DEFAULT nucleo_workspace_atual(),
  creator_id    uuid,
  equipe_id     uuid NOT NULL,
  usuario_id    uuid NOT NULL,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now(),
  deleted_at    timestamptz,
  PRIMARY KEY (id, tenant_id, workspace_id),
  FOREIGN KEY (workspace_id, tenant_id) REFERENCES workspaces (id, tenant_id),
  FOREIGN KEY (creator_id, tenant_id, workspace_id) REFERENCES usuarios (id, tenant_id, workspace_id),
  FOREIGN KEY (equipe_id, tenant_id, workspace_id) REFERENCES pipeline_equipes (id, tenant_id, workspace_id),
  FOREIGN KEY (usuario_id, tenant_id, workspace_id) REFERENCES usuarios (id, tenant_id, workspace_id)
);
CREATE UNIQUE INDEX IF NOT EXISTS pipeline_equipe_membros_uq ON pipeline_equipe_membros (tenant_id, workspace_id, equipe_id, usuario_id);
SELECT nucleo_aplicar_padrao('pipeline_equipe_membros');

-- M2.4 Metas mensais por equipe ou por vendedor ---------------------------------------------
CREATE TABLE IF NOT EXISTS pipeline_metas (
  id            uuid NOT NULL DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL DEFAULT nucleo_tenant_atual(),
  workspace_id  uuid NOT NULL DEFAULT nucleo_workspace_atual(),
  creator_id    uuid,
  competencia   date NOT NULL CHECK (extract(day FROM competencia) = 1),
  equipe_id     uuid,
  vendedor_id   uuid,
  valor_alvo    numeric(14, 2) NOT NULL CHECK (valor_alvo > 0),
  moeda         text NOT NULL DEFAULT 'BRL' CHECK (moeda ~ '^[A-Z]{3}$'),
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now(),
  deleted_at    timestamptz,
  PRIMARY KEY (id, tenant_id, workspace_id),
  FOREIGN KEY (workspace_id, tenant_id) REFERENCES workspaces (id, tenant_id),
  FOREIGN KEY (creator_id, tenant_id, workspace_id) REFERENCES usuarios (id, tenant_id, workspace_id),
  FOREIGN KEY (equipe_id, tenant_id, workspace_id) REFERENCES pipeline_equipes (id, tenant_id, workspace_id),
  FOREIGN KEY (vendedor_id, tenant_id, workspace_id) REFERENCES usuarios (id, tenant_id, workspace_id),
  CHECK ((equipe_id IS NULL) <> (vendedor_id IS NULL))
);
CREATE UNIQUE INDEX IF NOT EXISTS pipeline_metas_equipe_uq ON pipeline_metas (tenant_id, workspace_id, competencia, equipe_id) WHERE equipe_id IS NOT NULL AND deleted_at IS NULL;
CREATE UNIQUE INDEX IF NOT EXISTS pipeline_metas_vendedor_uq ON pipeline_metas (tenant_id, workspace_id, competencia, vendedor_id) WHERE vendedor_id IS NOT NULL AND deleted_at IS NULL;
SELECT nucleo_aplicar_padrao('pipeline_metas');

-- M2.1 Agregado Oportunidade ----------------------------------------------------------------
CREATE TABLE IF NOT EXISTS pipeline_oportunidades (
  id                    uuid NOT NULL DEFAULT gen_random_uuid(),
  tenant_id             uuid NOT NULL DEFAULT nucleo_tenant_atual(),
  workspace_id          uuid NOT NULL DEFAULT nucleo_workspace_atual(),
  creator_id            uuid,
  titulo                text NOT NULL CHECK (length(btrim(titulo)) BETWEEN 2 AND 200),
  parceiro_id           uuid,
  valor                 numeric(14, 2) NOT NULL DEFAULT 0 CHECK (valor >= 0),
  moeda                 text NOT NULL DEFAULT 'BRL' CHECK (moeda ~ '^[A-Z]{3}$'),
  responsavel_id        uuid,
  equipe_id             uuid,
  etapa_id              uuid NOT NULL,
  probabilidade         smallint NOT NULL DEFAULT 10 CHECK (probabilidade BETWEEN 0 AND 100),
  estado                text NOT NULL DEFAULT 'aberta' CHECK (estado IN ('aberta', 'ganha', 'perdida')),
  origem                text,
  canal                 text CHECK (canal IS NULL OR canal IN ('site', 'whatsapp', 'instagram', 'indicacao', 'telefone', 'email', 'evento', 'outro')),
  utm_source            text,
  utm_medium            text,
  utm_campaign          text,
  previsao_fechamento   date,
  motivo_perda_id       uuid,
  motivo_perda_detalhe  text,
  projeto_id            uuid,
  lead_evento_id        uuid,
  etapa_desde           timestamptz NOT NULL DEFAULT now(),
  fechada_em            timestamptz,
  extras                jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at            timestamptz NOT NULL DEFAULT now(),
  updated_at            timestamptz NOT NULL DEFAULT now(),
  deleted_at            timestamptz,
  PRIMARY KEY (id, tenant_id, workspace_id),
  FOREIGN KEY (workspace_id, tenant_id) REFERENCES workspaces (id, tenant_id),
  FOREIGN KEY (creator_id, tenant_id, workspace_id) REFERENCES usuarios (id, tenant_id, workspace_id),
  FOREIGN KEY (responsavel_id, tenant_id, workspace_id) REFERENCES usuarios (id, tenant_id, workspace_id),
  FOREIGN KEY (parceiro_id, tenant_id, workspace_id) REFERENCES cadastros_parceiros (id, tenant_id, workspace_id),
  FOREIGN KEY (projeto_id, tenant_id, workspace_id) REFERENCES cadastros_projetos (id, tenant_id, workspace_id),
  FOREIGN KEY (equipe_id, tenant_id, workspace_id) REFERENCES pipeline_equipes (id, tenant_id, workspace_id),
  FOREIGN KEY (etapa_id, tenant_id, workspace_id) REFERENCES pipeline_etapas (id, tenant_id, workspace_id),
  FOREIGN KEY (motivo_perda_id, tenant_id, workspace_id) REFERENCES pipeline_motivos_perda (id, tenant_id, workspace_id),
  CHECK (estado <> 'perdida' OR motivo_perda_id IS NOT NULL),
  CHECK ((estado = 'aberta') = (fechada_em IS NULL))
);
CREATE UNIQUE INDEX IF NOT EXISTS pipeline_oportunidades_lead_uq ON pipeline_oportunidades (tenant_id, workspace_id, lead_evento_id) WHERE lead_evento_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS pipeline_oportunidades_etapa_idx ON pipeline_oportunidades (tenant_id, workspace_id, etapa_id) WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS pipeline_oportunidades_parceiro_idx ON pipeline_oportunidades (tenant_id, workspace_id, parceiro_id) WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS pipeline_oportunidades_lista_idx ON pipeline_oportunidades (tenant_id, workspace_id, created_at, id) WHERE deleted_at IS NULL;
SELECT nucleo_aplicar_padrao('pipeline_oportunidades');
DROP TRIGGER IF EXISTS pipeline_oportunidades_extras ON pipeline_oportunidades;
CREATE TRIGGER pipeline_oportunidades_extras BEFORE INSERT OR UPDATE OF extras ON pipeline_oportunidades
  FOR EACH ROW EXECUTE FUNCTION nucleo_trigger_extras('pipeline', 'oportunidade');

-- Movimentos entre etapas: base da conversao por etapa e do tempo em cada etapa -------------
CREATE TABLE IF NOT EXISTS pipeline_movimentos (
  id               uuid NOT NULL DEFAULT gen_random_uuid(),
  tenant_id        uuid NOT NULL DEFAULT nucleo_tenant_atual(),
  workspace_id     uuid NOT NULL DEFAULT nucleo_workspace_atual(),
  creator_id       uuid,
  oportunidade_id  uuid NOT NULL,
  de_etapa_id      uuid,
  para_etapa_id    uuid NOT NULL,
  created_at       timestamptz NOT NULL DEFAULT now(),
  updated_at       timestamptz NOT NULL DEFAULT now(),
  deleted_at       timestamptz,
  PRIMARY KEY (id, tenant_id, workspace_id),
  FOREIGN KEY (workspace_id, tenant_id) REFERENCES workspaces (id, tenant_id),
  FOREIGN KEY (creator_id, tenant_id, workspace_id) REFERENCES usuarios (id, tenant_id, workspace_id),
  FOREIGN KEY (oportunidade_id, tenant_id, workspace_id) REFERENCES pipeline_oportunidades (id, tenant_id, workspace_id),
  FOREIGN KEY (de_etapa_id, tenant_id, workspace_id) REFERENCES pipeline_etapas (id, tenant_id, workspace_id),
  FOREIGN KEY (para_etapa_id, tenant_id, workspace_id) REFERENCES pipeline_etapas (id, tenant_id, workspace_id)
);
CREATE INDEX IF NOT EXISTS pipeline_movimentos_op_idx ON pipeline_movimentos (tenant_id, workspace_id, oportunidade_id, created_at);
SELECT nucleo_aplicar_padrao('pipeline_movimentos');

-- M2.3 Atividades ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS pipeline_atividades (
  id               uuid NOT NULL DEFAULT gen_random_uuid(),
  tenant_id        uuid NOT NULL DEFAULT nucleo_tenant_atual(),
  workspace_id     uuid NOT NULL DEFAULT nucleo_workspace_atual(),
  creator_id       uuid,
  oportunidade_id  uuid,
  tipo             text NOT NULL CHECK (tipo IN ('tarefa', 'ligacao', 'reuniao', 'follow_up')),
  titulo           text NOT NULL CHECK (length(btrim(titulo)) BETWEEN 2 AND 200),
  descricao        text,
  data             timestamptz NOT NULL,
  duracao_min      integer NOT NULL DEFAULT 30 CHECK (duracao_min BETWEEN 5 AND 1440),
  responsavel_id   uuid,
  estado           text NOT NULL DEFAULT 'pendente' CHECK (estado IN ('pendente', 'concluida', 'cancelada')),
  resultado        text,
  concluida_em     timestamptz,
  created_at       timestamptz NOT NULL DEFAULT now(),
  updated_at       timestamptz NOT NULL DEFAULT now(),
  deleted_at       timestamptz,
  PRIMARY KEY (id, tenant_id, workspace_id),
  FOREIGN KEY (workspace_id, tenant_id) REFERENCES workspaces (id, tenant_id),
  FOREIGN KEY (creator_id, tenant_id, workspace_id) REFERENCES usuarios (id, tenant_id, workspace_id),
  FOREIGN KEY (responsavel_id, tenant_id, workspace_id) REFERENCES usuarios (id, tenant_id, workspace_id),
  FOREIGN KEY (oportunidade_id, tenant_id, workspace_id) REFERENCES pipeline_oportunidades (id, tenant_id, workspace_id),
  CHECK ((estado = 'concluida') = (concluida_em IS NOT NULL))
);
CREATE INDEX IF NOT EXISTS pipeline_atividades_data_idx ON pipeline_atividades (tenant_id, workspace_id, data) WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS pipeline_atividades_op_idx ON pipeline_atividades (tenant_id, workspace_id, oportunidade_id) WHERE deleted_at IS NULL;
SELECT nucleo_aplicar_padrao('pipeline_atividades');

-- Papeis de banco: API (erp_app) e worker (erp_worker: abre oportunidade a partir de lead.recebido).
GRANT SELECT, INSERT, UPDATE ON pipeline_etapas, pipeline_motivos_perda, pipeline_equipes, pipeline_equipe_membros,
  pipeline_metas, pipeline_oportunidades, pipeline_movimentos, pipeline_atividades TO erp_app;
GRANT SELECT, INSERT, UPDATE ON pipeline_etapas, pipeline_oportunidades, pipeline_movimentos TO erp_worker;
GRANT SELECT ON pipeline_motivos_perda, pipeline_equipes, pipeline_equipe_membros, pipeline_metas, pipeline_atividades TO erp_worker;
