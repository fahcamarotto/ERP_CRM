/**
 * Repositorios em memoria das portas do Pipeline e porta Efeitos que grava o que foi publicado.
 * Os casos de uso rodam aqui sem banco, sem Fastify e sem o SDK.
 */
import { Atividade, type AtividadeDados } from '../api/atividade/model/atividade.ts';
import type { ConsultarReferenciasAtividade, GravarAtividade, ObterAtividade } from '../api/atividade/model/portas.ts';
import type { ContextoCaso, Efeitos } from '../api/compartilhado/efeitos.ts';
import { Equipe, type EquipeDados } from '../api/equipe/model/equipe.ts';
import type { ConsultarReferenciasEquipe, GravarEquipe, ObterEquipe } from '../api/equipe/model/portas.ts';
import { Etapa, type EtapaDados, type TipoEtapa } from '../api/etapa/model/etapa.ts';
import type { ContarUsoEtapa, GravarEtapa, ListarEtapas, ObterEtapa, TravarFunil } from '../api/etapa/model/portas.ts';
import type { ConsultarFunilDaEtapa } from '../api/etapa/use-case/etapas.ts';
import { Funil, type FunilDados } from '../api/funil/model/funil.ts';
import type { ContarAbertasFunil, GravarFunil, ListarFunis, ObterFunil, TravarFunis } from '../api/funil/model/portas.ts';
import { Meta, type MetaDados } from '../api/meta/model/meta.ts';
import type { ConsultarReferenciasMeta, GravarMeta, ObterMeta } from '../api/meta/model/portas.ts';
import { MotivoPerda, type MotivoDados } from '../api/motivo/model/motivo.ts';
import type { ContarUsoMotivo, GravarMotivo, ObterMotivo } from '../api/motivo/model/portas.ts';
import { Oportunidade, type EtapaRef, type OportunidadeDados } from '../api/oportunidade/model/oportunidade.ts';
import type { BuscarPorLead, ConsultarEtapas, ConsultarReferenciasOportunidade, GravarOportunidade, ObterOportunidade } from '../api/oportunidade/model/portas.ts';

export const USUARIO = '00000000-0000-4000-8000-000000000001';

export class EfeitosMemoria implements Efeitos {
  auditoria: { acao: string; entidade: string; id: string | null }[] = [];
  eventos: { evento: string; dados: Record<string, unknown> }[] = [];
  historicos: { entidade: string; id: string; antes: unknown; depois: unknown }[] = [];
  notas: { entidade: string; id: string; corpo: string }[] = [];
  async auditar(acao: string, entidade: string, id: string | null) { this.auditoria.push({ acao, entidade, id }); }
  async publicar(evento: string, dados: Record<string, unknown>) { this.eventos.push({ evento, dados }); }
  async historico(entidade: string, id: string, antes: unknown, depois: unknown) { this.historicos.push({ entidade, id, antes, depois }); }
  async nota(entidade: string, id: string, corpo: string) { this.notas.push({ entidade, id, corpo }); }
}

export function contexto(): ContextoCaso & { efeitos: EfeitosMemoria } {
  return { ator: { tipo: 'usuario', id: USUARIO }, efeitos: new EfeitosMemoria() };
}

export class FunisMemoria implements ObterFunil, ListarFunis, GravarFunil, ContarAbertasFunil, TravarFunis {
  linhas = new Map<string, FunilDados>();
  abertasPorFunil = new Map<string, string[]>();
  travas = 0;
  private vivos() { return [...this.linhas.values()].sort((a, b) => Number(b.padrao) - Number(a.padrao) || a.ordem - b.ordem); }
  async obterPorId(id: string) { const d = this.linhas.get(id); return d ? Funil.reidratar(d) : null; }
  async padrao() { const d = this.vivos().find((x) => x.padrao); return d ? Funil.reidratar(d) : null; }
  async ativos() { return this.vivos().filter((x) => !x.arquivado).map((d) => Funil.reidratar(d)); }
  async buscarAtivoPorNome(nome: string) { const d = this.vivos().find((x) => !x.arquivado && x.nome.toLowerCase() === nome.toLowerCase()); return d ? Funil.reidratar(d) : null; }
  async proximaOrdem() { return Math.max(0, ...this.vivos().map((x) => x.ordem)) + 10; }
  async inserir(f: Funil) { this.linhas.set(f.id, f.paraDados()); }
  async atualizar(f: Funil) {
    const d = f.paraDados();
    if (d.padrao && this.vivos().some((x) => x.padrao && x.id !== d.id)) throw Object.assign(new Error('dois padroes'), { code: '23505' });
    this.linhas.set(f.id, d);
  }
  async abertas(funilId: string) { return this.abertasPorFunil.get(funilId) ?? []; }
  async travarFunis() { this.travas++; }
}

export class EtapasMemoria implements ObterEtapa, ListarEtapas, GravarEtapa, ContarUsoEtapa, TravarFunil, ConsultarFunilDaEtapa {
  linhas = new Map<string, EtapaDados & { deleted: boolean }>();
  uso = new Map<string, number>();
  travas = 0;
  constructor(readonly funis: FunisMemoria = new FunisMemoria()) {}
  private vivas(funilId?: string) { return [...this.linhas.values()].filter((x) => !x.deleted && (!funilId || x.funil_id === funilId)).sort((a, b) => a.ordem - b.ordem); }
  async obterPorId(id: string) { const d = this.linhas.get(id); return d && !d.deleted ? Etapa.reidratar(d) : null; }
  async listar(funilId: string) { return this.vivas(funilId).map((d) => Etapa.reidratar(d)); }
  async porTipo(funilId: string, tipo: TipoEtapa) { const d = this.vivas(funilId).find((x) => x.tipo === tipo); return d ? Etapa.reidratar(d) : null; }
  async buscarPorNome(funilId: string, nome: string) { const d = this.vivas(funilId).find((x) => x.nome.toLowerCase() === nome.toLowerCase()); return d ? Etapa.reidratar(d) : null; }
  async funilVivo(id: string) { const f = this.funis.linhas.get(id); return f ? { id: f.id, arquivado: f.arquivado } : null; }
  async inserir(e: Etapa) { this.linhas.set(e.id, { ...e.paraDados(), deleted: false }); }
  async atualizar(e: Etapa) { this.linhas.set(e.id, { ...e.paraDados(), deleted: false }); }
  async excluir(id: string) { const d = this.linhas.get(id); if (d) d.deleted = true; }
  async emUso(id: string) { return this.uso.get(id) ?? 0; }
  async travarFunil() { this.travas++; }
}

/** Oportunidades em memoria; etapas e referencias vem das outras memorias (como o adaptador faz com SELECT). */
export class OportunidadesMemoria implements ObterOportunidade, GravarOportunidade, BuscarPorLead, ConsultarEtapas, ConsultarReferenciasOportunidade {
  linhas = new Map<string, OportunidadeDados & { deleted: boolean }>();
  movimentos: { oportunidade_id: string; de: string | null; para: string }[] = [];
  parceiros = new Set<string>();
  usuarios = new Set<string>([USUARIO]);
  equipes = new Set<string>();
  motivos = new Set<string>();
  projetos = new Set<string>();
  constructor(readonly etapas: EtapasMemoria) {}
  async obterPorId(id: string) { const d = this.linhas.get(id); return d && !d.deleted ? Oportunidade.reidratar(d) : null; }
  async abertaDoParceiro(p: string, f: string) { const d = [...this.linhas.values()].find((x) => !x.deleted && x.parceiro_id === p && x.funil_id === f && x.estado === 'aberta'); return d ? Oportunidade.reidratar(d) : null; }
  async porLeadEvento(ev: string) { const d = [...this.linhas.values()].find((x) => x.lead_evento_id === ev); return d ? Oportunidade.reidratar(d) : null; }
  async inserir(o: Oportunidade) {
    const d = o.paraDados();
    if (d.lead_evento_id && [...this.linhas.values()].some((x) => x.lead_evento_id === d.lead_evento_id)) throw Object.assign(new Error('duplicado'), { code: '23505' });
    this.linhas.set(d.id, { ...d, deleted: false });
  }
  async atualizar(o: Oportunidade) { this.linhas.set(o.id, { ...o.paraDados(), deleted: false }); }
  async excluir(id: string) { const d = this.linhas.get(id); if (d) d.deleted = true; }
  async registrarMovimento(oportunidade_id: string, de: string | null, para: string) { this.movimentos.push({ oportunidade_id, de, para }); }
  private ref(e: Etapa | null): EtapaRef | null { return e ? { id: e.id, tipo: e.tipo, probabilidade: e.probabilidade, funil_id: e.funilId } : null; }
  async etapa(id: string) { return this.ref(await this.etapas.obterPorId(id)); }
  async primeiraAberta(funilId: string) { return this.ref((await this.etapas.listar(funilId)).find((e) => e.tipo === 'aberta') ?? null); }
  async etapaFinal(funilId: string, tipo: 'ganho' | 'perdido') { return this.ref(await this.etapas.porTipo(funilId, tipo)); }
  async funil(id: string) { return this.etapas.funilVivo(id); }
  async parceiroAtivo(id: string) { return this.parceiros.has(id); }
  async usuarioExiste(id: string) { return this.usuarios.has(id); }
  async equipeExiste(id: string) { return this.equipes.has(id); }
  async motivoAtivo(id: string) { return this.motivos.has(id); }
  async projetoExiste(id: string) { return this.projetos.has(id); }
}

export class AtividadesMemoria implements ObterAtividade, GravarAtividade, ConsultarReferenciasAtividade {
  linhas = new Map<string, AtividadeDados>();
  oportunidades = new Set<string>();
  usuarios = new Set<string>([USUARIO]);
  async obterPorId(id: string) { const d = this.linhas.get(id); return d ? Atividade.reidratar(d) : null; }
  async inserir(a: Atividade) { this.linhas.set(a.id, a.paraDados()); }
  async atualizar(a: Atividade) { this.linhas.set(a.id, a.paraDados()); }
  async oportunidadeExiste(id: string) { return this.oportunidades.has(id); }
  async usuarioExiste(id: string) { return this.usuarios.has(id); }
}

export class EquipesMemoria implements ObterEquipe, GravarEquipe, ConsultarReferenciasEquipe {
  linhas = new Map<string, EquipeDados & { deleted: boolean }>();
  usuarios = new Set<string>([USUARIO]);
  uso = new Map<string, number>();
  async obterPorId(id: string) { const d = this.linhas.get(id); return d && !d.deleted ? Equipe.reidratar(d) : null; }
  async buscarPorNome(nome: string) { const d = [...this.linhas.values()].find((x) => !x.deleted && x.nome.toLowerCase() === nome.toLowerCase()); return d ? Equipe.reidratar(d) : null; }
  async inserir(e: Equipe) { this.linhas.set(e.id, { ...e.paraDados(), deleted: false }); }
  async atualizar(e: Equipe) { this.linhas.set(e.id, { ...e.paraDados(), deleted: false }); }
  async excluir(id: string) { const d = this.linhas.get(id); if (d) d.deleted = true; }
  async usuariosExistentes(ids: string[]) { return ids.filter((i) => this.usuarios.has(i)); }
  async emUso(id: string) { return this.uso.get(id) ?? 0; }
}

export class MetasMemoria implements ObterMeta, GravarMeta, ConsultarReferenciasMeta {
  linhas = new Map<string, MetaDados & { deleted: boolean }>();
  equipes = new Set<string>();
  usuarios = new Set<string>([USUARIO]);
  async obterPorId(id: string) { const d = this.linhas.get(id); return d && !d.deleted ? Meta.reidratar(d) : null; }
  async buscarMesmoAlvo(comp: string, eq: string | null, vend: string | null) {
    const d = [...this.linhas.values()].find((x) => !x.deleted && x.competencia === comp && x.equipe_id === eq && x.vendedor_id === vend);
    return d ? Meta.reidratar(d) : null;
  }
  async inserir(m: Meta) { this.linhas.set(m.id, { ...m.paraDados(), deleted: false }); }
  async atualizar(m: Meta) { this.linhas.set(m.id, { ...m.paraDados(), deleted: false }); }
  async excluir(id: string) { const d = this.linhas.get(id); if (d) d.deleted = true; }
  async equipeExiste(id: string) { return this.equipes.has(id); }
  async usuarioExiste(id: string) { return this.usuarios.has(id); }
}

export class MotivosMemoria implements ObterMotivo, GravarMotivo, ContarUsoMotivo {
  linhas = new Map<string, MotivoDados & { deleted: boolean }>();
  uso = new Map<string, number>();
  async obterPorId(id: string) { const d = this.linhas.get(id); return d && !d.deleted ? MotivoPerda.reidratar(d) : null; }
  async buscarPorNome(nome: string) { const d = [...this.linhas.values()].find((x) => !x.deleted && x.nome.toLowerCase() === nome.toLowerCase()); return d ? MotivoPerda.reidratar(d) : null; }
  async inserir(m: MotivoPerda) { this.linhas.set(m.id, { ...m.paraDados(), deleted: false }); }
  async atualizar(m: MotivoPerda) { this.linhas.set(m.id, { ...m.paraDados(), deleted: false }); }
  async excluir(id: string) { const d = this.linhas.get(id); if (d) d.deleted = true; }
  async emUso(id: string) { return this.uso.get(id) ?? 0; }
}
