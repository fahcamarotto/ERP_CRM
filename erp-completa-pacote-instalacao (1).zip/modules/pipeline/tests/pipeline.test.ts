/** Testes do Pipeline (M2) com repositorios em memoria: objetos de valor, entidades, maquinas de estado e casos de uso. */
import assert from 'node:assert/strict';
import { describe, it } from 'node:test';
import { Atividade } from '../api/atividade/model/atividade.ts';
import { AgendarAtividade, CancelarAtividade, ConcluirAtividade, EditarAtividade } from '../api/atividade/use-case/atividades.ts';
import { Equipe } from '../api/equipe/model/equipe.ts';
import { CriarEquipe, ExcluirEquipe } from '../api/equipe/use-case/equipes.ts';
import { Etapa, ETAPAS_PADRAO } from '../api/etapa/model/etapa.ts';
import { CriarEtapa, EditarEtapa, ExcluirEtapa, GarantirEtapasPadrao, ReordenarEtapas } from '../api/etapa/use-case/etapas.ts';
import { NOME_FUNIL_PADRAO } from '../api/funil/model/funil.ts';
import { ArquivarFunil, CriarFunil, GarantirFunilPadrao, RenomearFunil, ResolverFunil } from '../api/funil/use-case/funis.ts';
import { competenciaDe, Meta } from '../api/meta/model/meta.ts';
import { CriarMeta, EditarMeta } from '../api/meta/use-case/metas.ts';
import { MotivoPerda } from '../api/motivo/model/motivo.ts';
import { CriarMotivo, EditarMotivo, ExcluirMotivo } from '../api/motivo/use-case/motivos.ts';
import { Dinheiro } from '../api/oportunidade/model/dinheiro.ts';
import { Oportunidade, TRANSICOES } from '../api/oportunidade/model/oportunidade.ts';
import { Utm } from '../api/oportunidade/model/utm.ts';
import { AbrirOportunidadeDeConversa, AbrirOportunidadeDeLead } from '../api/oportunidade/use-case/abrir-de-lead.ts';
import { AplicarOportunidadeDeAutomacao } from '../api/oportunidade/use-case/abrir-de-automacao.ts';
import { CriarOportunidade } from '../api/oportunidade/use-case/criar-oportunidade.ts';
import { EditarOportunidade, ExcluirOportunidade } from '../api/oportunidade/use-case/editar-oportunidade.ts';
import { MarcarGanha, MarcarPerdida, VincularProjeto } from '../api/oportunidade/use-case/fechar-oportunidade.ts';
import { MoverEtapa, ReabrirOportunidade } from '../api/oportunidade/use-case/mover-etapa.ts';
import { AtividadesMemoria, contexto, EquipesMemoria, EtapasMemoria, FunisMemoria, MetasMemoria, MotivosMemoria, OportunidadesMemoria, USUARIO } from './memoria.ts';

const PARCEIRO = '11111111-1111-4111-8111-111111111111';
const MOTIVO = '22222222-2222-4222-8222-222222222222';
const PROJETO = '33333333-3333-4333-8333-333333333333';
const F = 'f-1';
const ABERTA = { id: 'e-aberta', tipo: 'aberta' as const, probabilidade: 25, funil_id: F };

function codigos(r: { ok: boolean; erros?: { codigo: string }[] }): string[] {
  return r.ok ? [] : (r as { erros: { codigo: string }[] }).erros.map((e) => e.codigo);
}

/** Monta o mundo em memoria (o funil padrao nasce na primeira chamada que precisa dele). */
async function mundo() {
  const funis = new FunisMemoria();
  const etapas = new EtapasMemoria(funis);
  const ops = new OportunidadesMemoria(etapas);
  ops.parceiros.add(PARCEIRO);
  ops.motivos.add(MOTIVO);
  ops.projetos.add(PROJETO);
  const garantirEtapas = new GarantirEtapasPadrao({ repo: etapas });
  const funil = new GarantirFunilPadrao({ repo: funis, etapas: garantirEtapas });
  const resolver = new ResolverFunil({ repo: funis, padrao: funil });
  const criar = new CriarOportunidade({ repo: ops, etapas: ops, refs: ops, funil: resolver });
  const deps = { repo: ops, etapas: ops, refs: ops };
  const padrao = async () => (await funil.execute(null) as { ok: true; valor: { id: string } }).valor.id;
  return {
    funis, etapas, ops, funil, resolver, criar, padrao,
    mover: new MoverEtapa(deps), ganhar: new MarcarGanha(deps), perder: new MarcarPerdida(deps), reabrir: new ReabrirOportunidade(deps),
    vincular: new VincularProjeto(deps), editar: new EditarOportunidade(deps), excluir: new ExcluirOportunidade(deps),
  };
}

describe('objetos de valor', () => {
  it('Dinheiro arredonda em 2 casas, normaliza moeda e recusa negativo ou moeda invalida', () => {
    const d = Dinheiro.create(1234.567, 'brl');
    assert.equal(d.valor, 1234.57);
    assert.equal(d.moeda, 'BRL');
    assert.deepEqual(codigos(Dinheiro.tryCreate(-1, 'BR')), ['valor_invalido', 'moeda_invalida']);
    assert.throws(() => Dinheiro.create('abc'));
  });

  it('Utm apara espacos, vazio vira null e recusa acima de 120', () => {
    assert.deepEqual(Utm.create({ utm_source: ' google ', utm_medium: '', utm_campaign: null }).dados, { utm_source: 'google', utm_medium: null, utm_campaign: null });
    assert.deepEqual(codigos(Utm.tryCreate({ utm_campaign: 'x'.repeat(121) })), ['utm_invalida']);
    assert.throws(() => Utm.create({ utm_source: 'x'.repeat(200) }));
  });

  it('competencia aceita AAAA-MM e AAAA-MM-DD e recusa mes invalido', () => {
    assert.equal(competenciaDe('2026-10'), '2026-10');
    assert.equal(competenciaDe('2026-10-15'), '2026-10');
    assert.equal(competenciaDe('2026-13'), null);
  });
});

describe('Oportunidade (entidade)', () => {
  it('tryCreate acumula todos os erros de uma vez', () => {
    const r = Oportunidade.tryCreate({ titulo: 'x', valor: -5, moeda: 'R$', probabilidade: 150, previsao_fechamento: '31/12/2026' }, ABERTA);
    assert.deepEqual(codigos(r).sort(), ['data_invalida', 'moeda_invalida', 'probabilidade_invalida', 'titulo_invalido', 'valor_invalido']);
    assert.throws(() => Oportunidade.create({ titulo: '' }, ABERTA));
  });

  it('nasce aberta com a probabilidade da etapa e nao entra direto em etapa final', () => {
    const o = Oportunidade.create({ titulo: 'Contrato anual', valor: 1000 }, ABERTA);
    assert.equal(o.estado, 'aberta');
    assert.equal(o.paraDados().probabilidade, 25);
    assert.deepEqual(codigos(Oportunidade.tryCreate({ titulo: 'Contrato' }, { id: 'g', tipo: 'ganho', probabilidade: 100, funil_id: F })), ['etapa_invalida']);
  });

  it('editar devolve clone e nao muta o original', () => {
    const o = Oportunidade.create({ titulo: 'Original', valor: 10 }, ABERTA);
    const r = o.editar({ titulo: 'Novo titulo', valor: 20 });
    assert.ok(r.ok);
    assert.equal(o.paraDados().titulo, 'Original');
    assert.equal(r.valor.paraDados().valor, 20);
  });

  it('maquina de estados: fechada nao edita nem move; reabrir so de fechada', () => {
    assert.deepEqual(TRANSICOES.aberta, ['ganha', 'perdida']);
    const o = Oportunidade.create({ titulo: 'Fechar' }, ABERTA);
    assert.deepEqual(codigos(o.reabrir(ABERTA)), ['transicao_invalida']);
    const g = o.marcarGanha({ id: 'g', tipo: 'ganho', probabilidade: 100, funil_id: F });
    assert.ok(g.ok);
    assert.deepEqual(codigos(g.valor.editar({ titulo: 'outro' })), ['transicao_invalida']);
    assert.deepEqual(codigos(g.valor.mover({ id: 'x', tipo: 'aberta', probabilidade: 50, funil_id: F })), ['transicao_invalida']);
    assert.deepEqual(codigos(g.valor.marcarPerdida({ id: 'p', tipo: 'perdido', probabilidade: 0, funil_id: F }, MOTIVO)), ['transicao_invalida']);
    assert.deepEqual(codigos(o.mover({ id: 'g', tipo: 'ganho', probabilidade: 100, funil_id: F })), ['etapa_final']);
    assert.deepEqual(codigos(o.mover(ABERTA)), ['mesma_etapa']);
  });
});

describe('Etapas (M2.2)', () => {
  it('GarantirEtapasPadrao cria as etapas iniciais do funil uma unica vez', async () => {
    const etapas = new EtapasMemoria();
    const g = new GarantirEtapasPadrao({ repo: etapas });
    const ctx = contexto();
    assert.deepEqual(await g.execute(ctx, F), { ok: true, valor: { criadas: 6 } });
    assert.deepEqual(await g.execute(ctx, F), { ok: true, valor: { criadas: 0 } });
    assert.deepEqual((await etapas.listar(F)).map((e) => e.nome), ETAPAS_PADRAO.map((e) => e.nome));
    assert.equal(etapas.travas, 1);
    assert.equal(ctx.efeitos.auditoria.length, 6);
  });

  it('etapa valida tipo e probabilidade das finais e nao muda o tipo na edicao', () => {
    assert.deepEqual(codigos(Etapa.tryCreate({ funil_id: F, nome: 'Ganho 2', tipo: 'ganho', probabilidade: 80 })), ['probabilidade_invalida']);
    assert.deepEqual(codigos(Etapa.tryCreate({ nome: 'Sem funil' })), ['funil_obrigatorio']);
    assert.throws(() => Etapa.create({ funil_id: F, nome: '' }));
    const e = Etapa.create({ funil_id: F, nome: 'Qualificacao', probabilidade: 30 });
    const r = e.editar({ probabilidade: 40 });
    assert.ok(r.ok);
    assert.equal(e.probabilidade, 30);
    assert.equal(r.valor.tipo, 'aberta');
  });

  it('criar etapa recusa nome repetido e segunda etapa de ganho; excluir protege finais, ultima aberta e etapa em uso', async () => {
    const m = await mundo();
    const funil_id = await m.padrao();
    const ctx = contexto();
    const criarEtapa = new CriarEtapa({ repo: m.etapas, funis: m.etapas });
    assert.deepEqual(codigos(await criarEtapa.execute(ctx, { funil_id, nome: 'proposta' })), ['conflito']);
    assert.deepEqual(codigos(await criarEtapa.execute(ctx, { funil_id, nome: 'Fechado', tipo: 'ganho', probabilidade: 100 })), ['conflito']);
    assert.deepEqual(codigos(await criarEtapa.execute(ctx, { funil_id: 'nao-existe', nome: 'X' })), ['funil_invalido']);
    const nova = await criarEtapa.execute(ctx, { funil_id, nome: 'Qualificacao', ordem: 15, probabilidade: 15 });
    assert.ok(nova.ok);
    assert.ok((await new EditarEtapa({ repo: m.etapas }).execute(ctx, { id: nova.valor.id, nome: 'Qualificação', ordem: 12 })).ok);
    const excluir = new ExcluirEtapa({ repo: m.etapas });
    const ganho = (await m.etapas.porTipo(funil_id, 'ganho'))!;
    assert.deepEqual(codigos(await excluir.execute(ctx, { id: ganho.id })), ['conflito']);
    m.etapas.uso.set(nova.valor.id, 2);
    assert.deepEqual(codigos(await excluir.execute(ctx, { id: nova.valor.id })), ['conflito']);
    m.etapas.uso.set(nova.valor.id, 0);
    assert.ok((await excluir.execute(ctx, { id: nova.valor.id })).ok);
    assert.deepEqual(codigos(await excluir.execute(ctx, { id: 'nao-existe' })), ['nao_encontrado']);
  });
});

describe('Oportunidade (casos de uso M2.5)', () => {
  it('CriarOportunidade garante o funil, entra na primeira etapa, grava movimento, auditoria e evento', async () => {
    const m = await mundo();
    const ctx = contexto();
    const r = await m.criar.execute(ctx, { titulo: 'Portal do cliente', parceiro_id: PARCEIRO, valor: 5000, responsavel_id: USUARIO, canal: 'site', utm_source: 'google', utm_campaign: 'portal' });
    assert.ok(r.ok);
    const o = (await m.ops.obterPorId(r.valor.id))!.paraDados();
    const novo = (await m.etapas.listar(await m.padrao()))[0]!;
    assert.equal(o.funil_id, novo.funilId);
    assert.equal(o.etapa_id, novo.id);
    assert.equal(o.probabilidade, 10);
    assert.deepEqual(m.ops.movimentos, [{ oportunidade_id: r.valor.id, de: null, para: novo.id }]);
    assert.ok(ctx.efeitos.auditoria.some((a) => a.acao === 'oportunidade.criar'));
    const ev = ctx.efeitos.eventos.find((e) => e.evento === 'oportunidade.criada')!;
    assert.deepEqual(ev.dados.utm, { source: 'google', medium: null, campaign: 'portal' });
  });

  it('CriarOportunidade recusa cliente, responsavel, equipe e etapa invalidos', async () => {
    const m = await mundo();
    const r = await m.criar.execute(contexto(), { titulo: 'Teste', parceiro_id: '99999999-9999-4999-8999-999999999999', responsavel_id: 'x', equipe_id: 'y' });
    assert.deepEqual(codigos(r).sort(), ['cliente_invalido', 'equipe_invalida', 'usuario_invalido']);
    assert.deepEqual(codigos(await m.criar.execute(contexto(), { titulo: 'Teste', etapa_id: 'nao-existe' })), ['etapa_invalida']);
  });

  it('MoverEtapa muda etapa e probabilidade, publica oportunidade.movida e recusa etapa final', async () => {
    const m = await mundo();
    const { valor } = (await m.criar.execute(contexto(), { titulo: 'Mover' })) as { ok: true; valor: { id: string } };
    const proposta = (await m.etapas.buscarPorNome(await m.padrao(), 'Proposta'))!;
    const ctx = contexto();
    assert.ok((await m.mover.execute(ctx, { id: valor.id, etapa_id: proposta.id })).ok);
    const d = (await m.ops.obterPorId(valor.id))!.paraDados();
    assert.equal(d.etapa_id, proposta.id);
    assert.equal(d.probabilidade, 50);
    assert.equal(ctx.efeitos.eventos[0]!.evento, 'oportunidade.movida');
    assert.equal(ctx.efeitos.historicos.length, 1);
    const ganho = (await m.etapas.porTipo(await m.padrao(), 'ganho'))!;
    assert.deepEqual(codigos(await m.mover.execute(ctx, { id: valor.id, etapa_id: ganho.id })), ['etapa_final']);
    assert.deepEqual(codigos(await m.mover.execute(ctx, { id: 'nao-existe', etapa_id: proposta.id })), ['nao_encontrado']);
  });

  it('MarcarGanha fecha com probabilidade 100, publica oportunidade.ganha e permite ligar o projeto uma vez', async () => {
    const m = await mundo();
    const { valor } = (await m.criar.execute(contexto(), { titulo: 'Ganhar', parceiro_id: PARCEIRO, valor: 900 })) as { ok: true; valor: { id: string } };
    const ctx = contexto();
    assert.deepEqual(codigos(await m.vincular.execute(ctx, { id: valor.id, projeto_id: PROJETO })), ['transicao_invalida']);
    assert.ok((await m.ganhar.execute(ctx, { id: valor.id, converter_em_projeto: true })).ok);
    const d = (await m.ops.obterPorId(valor.id))!.paraDados();
    assert.equal(d.estado, 'ganha');
    assert.equal(d.probabilidade, 100);
    assert.ok(d.fechada_em);
    const ev = ctx.efeitos.eventos.find((e) => e.evento === 'oportunidade.ganha')!;
    assert.equal(ev.dados.converter_em_projeto, true);
    assert.deepEqual(codigos(await m.ganhar.execute(ctx, { id: valor.id })), ['transicao_invalida']);
    assert.deepEqual(codigos(await m.vincular.execute(ctx, { id: valor.id, projeto_id: '44444444-4444-4444-8444-444444444444' })), ['projeto_invalido']);
    assert.ok((await m.vincular.execute(ctx, { id: valor.id, projeto_id: PROJETO })).ok);
    assert.deepEqual(codigos(await m.vincular.execute(ctx, { id: valor.id, projeto_id: PROJETO })), ['conflito']);
  });

  it('MarcarPerdida exige motivo ativo e publica oportunidade.perdida; Reabrir volta para etapa aberta', async () => {
    const m = await mundo();
    const { valor } = (await m.criar.execute(contexto(), { titulo: 'Perder', valor: 300 })) as { ok: true; valor: { id: string } };
    const ctx = contexto();
    assert.deepEqual(codigos(await m.perder.execute(ctx, { id: valor.id, motivo_perda_id: '' })), ['motivo_obrigatorio']);
    assert.deepEqual(codigos(await m.perder.execute(ctx, { id: valor.id, motivo_perda_id: '55555555-5555-4555-8555-555555555555' })), ['motivo_invalido']);
    assert.ok((await m.perder.execute(ctx, { id: valor.id, motivo_perda_id: MOTIVO, motivo_perda_detalhe: 'Concorrente 20% mais barato' })).ok);
    const d = (await m.ops.obterPorId(valor.id))!.paraDados();
    assert.equal(d.estado, 'perdida');
    assert.equal(d.probabilidade, 0);
    assert.equal(d.motivo_perda_id, MOTIVO);
    assert.ok(ctx.efeitos.eventos.some((e) => e.evento === 'oportunidade.perdida'));
    assert.ok((await m.reabrir.execute(ctx, { id: valor.id })).ok);
    const r = (await m.ops.obterPorId(valor.id))!.paraDados();
    assert.equal(r.estado, 'aberta');
    assert.equal(r.motivo_perda_id, null);
    assert.equal(r.fechada_em, null);
  });

  it('EditarOportunidade grava historico e recusa fechada; ExcluirOportunidade e logica', async () => {
    const m = await mundo();
    const { valor } = (await m.criar.execute(contexto(), { titulo: 'Editar' })) as { ok: true; valor: { id: string } };
    const ctx = contexto();
    assert.ok((await m.editar.execute(ctx, { id: valor.id, valor: 1500, previsao_fechamento: '2026-12-01' })).ok);
    assert.equal(ctx.efeitos.historicos.length, 1);
    assert.deepEqual(codigos(await m.editar.execute(ctx, { id: valor.id, parceiro_id: 'nao-existe' })), ['cliente_invalido']);
    assert.ok((await m.excluir.execute(ctx, { id: valor.id })).ok);
    assert.equal(await m.ops.obterPorId(valor.id), null);
    assert.deepEqual(codigos(await m.editar.execute(ctx, { id: valor.id, titulo: 'x' })), ['nao_encontrado']);
  });

  it('AplicarOportunidadeDeAutomacao cria na etapa pedida, depois move a aberta e e idempotente pelo evento', async () => {
    const m = await mundo();
    const f = await m.padrao();
    const [e1, e2] = (await m.etapas.listar(f)).filter((e) => e.paraDados().tipo === 'aberta');
    const aplicar = new AplicarOportunidadeDeAutomacao({ repo: m.ops, etapas: m.ops, criar: m.criar, mover: m.mover });
    const ctx = contexto();
    const r1 = await aplicar.execute(ctx, { id: 'ev-1', dados: { parceiro_id: PARCEIRO, etapa_id: e2!.id, titulo: 'Lead do Instagram', canal: 'instagram' } });
    assert.ok(r1.ok && r1.valor.acao === 'criada');
    assert.equal((await m.ops.obterPorId(r1.valor.id!))!.etapaId, e2!.id);
    const r2 = await aplicar.execute(ctx, { id: 'ev-2', dados: { parceiro_id: PARCEIRO, etapa_id: e1!.id } });
    assert.ok(r2.ok && r2.valor.acao === 'movida' && r2.valor.id === r1.valor.id);
    assert.equal((await m.ops.obterPorId(r1.valor.id!))!.etapaId, e1!.id);
    const r3 = await aplicar.execute(ctx, { id: 'ev-1', dados: { parceiro_id: PARCEIRO, etapa_id: e2!.id } });
    assert.ok(r3.ok && r3.valor.acao === 'mantida');
    assert.equal([...m.ops.linhas.values()].length, 1);
  });

  it('AbrirOportunidadeDeLead e idempotente pelo id do evento e leva origem, canal e UTM', async () => {
    const m = await mundo();
    const abrir = new AbrirOportunidadeDeLead({ repo: m.ops, etapas: m.ops, criar: m.criar });
    const ev = { id: '66666666-6666-4666-8666-666666666666', dados: { parceiro_id: PARCEIRO, nome: 'Ana', empresa: 'Aurora', mensagem: 'Quero orcamento', origem: 'landing', utm: { source: 'google', medium: 'cpc', campaign: 'erp' } } };
    const ctx = contexto();
    const r1 = await abrir.execute(ctx, ev);
    const r2 = await abrir.execute(ctx, ev);
    assert.ok(r1.ok && r2.ok);
    assert.equal(r1.valor.nova, true);
    assert.equal(r2.valor.nova, false);
    assert.equal(r1.valor.id, r2.valor.id);
    const d = (await m.ops.obterPorId(r1.valor.id))!.paraDados();
    assert.equal(d.titulo, 'Lead: Aurora');
    assert.equal(d.canal, 'site');
    assert.equal(d.utm_campaign, 'erp');
    assert.equal(ctx.efeitos.notas.length, 1);
    assert.equal(ctx.efeitos.eventos.filter((e) => e.evento === 'oportunidade.criada').length, 1);
  });
});

describe('Varios pipelines (funis)', () => {
  it('GarantirFunilPadrao cria o Pipeline padrao com etapas uma unica vez e ResolverFunil usa ele sem funil_id', async () => {
    const m = await mundo();
    const ctx = contexto();
    const r1 = await m.funil.execute(ctx);
    const r2 = await m.funil.execute(ctx);
    assert.ok(r1.ok && r2.ok);
    assert.equal(r1.valor.criado, true);
    assert.equal(r2.valor.criado, false);
    assert.equal(r1.valor.id, r2.valor.id);
    assert.equal((await m.funis.padrao())!.nome, NOME_FUNIL_PADRAO);
    assert.equal((await m.etapas.listar(r1.valor.id)).length, 6);
    const res = await m.resolver.execute(ctx, null);
    assert.ok(res.ok && res.valor.id === r1.valor.id);
    assert.deepEqual(codigos(await m.resolver.execute(ctx, 'nao-existe')), ['funil_invalido']);
  });

  it('CriarFunil cria etapas abertas editaveis mais ganho e perdido; recusa nome repetido e etapa reservada', async () => {
    const m = await mundo();
    await m.padrao();
    const criarFunil = new CriarFunil({ repo: m.funis, etapas: m.etapas });
    const ctx = contexto();
    const r = await criarFunil.execute(ctx, { nome: 'Pos-venda', etapas: ['Onboarding', 'Expansao'] });
    assert.ok(r.ok);
    const lista = await m.etapas.listar(r.valor.id);
    assert.deepEqual(lista.map((e) => e.nome), ['Onboarding', 'Expansao', 'Ganho', 'Perdido']);
    assert.deepEqual(lista.map((e) => e.probabilidade), [10, 75, 100, 0]);
    const padrao = await criarFunil.execute(ctx, { nome: 'Varejo' });
    assert.ok(padrao.ok);
    assert.equal((await m.etapas.listar(padrao.valor.id)).length, 6);
    assert.deepEqual(codigos(await criarFunil.execute(ctx, { nome: 'pos-venda' })), ['conflito']);
    assert.deepEqual(codigos(await criarFunil.execute(ctx, { nome: 'Outro', etapas: ['A', 'a'] })), ['etapas_invalidas']);
    assert.deepEqual(codigos(await criarFunil.execute(ctx, { nome: 'Outro', etapas: ['Ganho'] })), ['etapas_invalidas']);
    assert.ok((await new RenomearFunil({ repo: m.funis }).execute(ctx, { id: r.valor.id, nome: 'Pós-venda' })).ok);
    assert.deepEqual(codigos(await new RenomearFunil({ repo: m.funis }).execute(ctx, { id: r.valor.id, nome: 'varejo' })), ['conflito']);
  });

  it('Nova oportunidade entra no funil informado; etapa de outro funil e funil arquivado sao recusados', async () => {
    const m = await mundo();
    const padrao = await m.padrao();
    const novo = (await new CriarFunil({ repo: m.funis, etapas: m.etapas }).execute(contexto(), { nome: 'Parcerias', etapas: ['Triagem'] })) as { ok: true; valor: { id: string } };
    const r = await m.criar.execute(contexto(), { titulo: 'No funil novo', funil_id: novo.valor.id });
    assert.ok(r.ok);
    const d = (await m.ops.obterPorId(r.valor.id))!.paraDados();
    assert.equal(d.funil_id, novo.valor.id);
    assert.equal(d.etapa_id, (await m.etapas.listar(novo.valor.id))[0]!.id);
    const etapaPadrao = (await m.etapas.listar(padrao))[0]!;
    assert.deepEqual(codigos(await m.criar.execute(contexto(), { titulo: 'Misturado', funil_id: novo.valor.id, etapa_id: etapaPadrao.id })), ['etapa_invalida']);
    const ganhoPadrao = (await m.etapas.porTipo(padrao, 'ganho'))!;
    const o = (await m.ops.obterPorId(r.valor.id))!;
    assert.deepEqual(codigos(o.marcarGanha({ id: ganhoPadrao.id, tipo: 'ganho', probabilidade: 100, funil_id: padrao })), ['etapa_invalida']);
    assert.ok((await m.ganhar.execute(contexto(), { id: r.valor.id })).ok);
    assert.equal((await m.ops.obterPorId(r.valor.id))!.etapaId, (await m.etapas.porTipo(novo.valor.id, 'ganho'))!.id);
  });

  it('ReordenarEtapas grava a ordem nova em lote, audita e recusa lista incompleta, repetida ou de outro funil', async () => {
    const m = await mundo();
    const funil_id = await m.padrao();
    const reordenar = new ReordenarEtapas({ repo: m.etapas, funis: m.etapas });
    const ids = (await m.etapas.listar(funil_id)).map((e) => e.id);
    const nova = [ids[2]!, ids[0]!, ids[1]!, ...ids.slice(3)];
    const ctx = contexto();
    const r = await reordenar.execute(ctx, { funil_id, etapa_ids: nova });
    assert.ok(r.ok);
    assert.deepEqual((await m.etapas.listar(funil_id)).map((e) => e.id), nova);
    assert.deepEqual(r.valor.ordem.map((x) => x.ordem), [10, 20, 30, 40, 50, 60]);
    assert.equal(ctx.efeitos.auditoria.filter((a) => a.acao === 'etapa.reordenar').length, 1);
    assert.deepEqual(codigos(await reordenar.execute(ctx, { funil_id, etapa_ids: nova.slice(1) })), ['conflito']);
    assert.deepEqual(codigos(await reordenar.execute(ctx, { funil_id, etapa_ids: [nova[0]!, ...nova.slice(0, -1)] })), ['lista_invalida']);
    assert.deepEqual(codigos(await reordenar.execute(ctx, { funil_id, etapa_ids: [...nova.slice(1), 'de-outro-funil'] })), ['lista_invalida']);
    assert.deepEqual(codigos(await reordenar.execute(ctx, { funil_id: 'nao-existe', etapa_ids: nova })), ['funil_invalido']);
  });

  it('ArquivarFunil: nunca o ultimo ativo; com abertas exige destino e move; arquivar o padrao passa o padrao adiante', async () => {
    const m = await mundo();
    const padrao = await m.padrao();
    const arquivar = new ArquivarFunil({ repo: m.funis, ops: { mover: m.mover, primeiraAberta: (id) => m.ops.primeiraAberta(id) } });
    const ctx = contexto();
    assert.deepEqual(codigos(await arquivar.execute(ctx, { id: padrao })), ['conflito']);
    const outro = (await new CriarFunil({ repo: m.funis, etapas: m.etapas }).execute(ctx, { nome: 'Licitacoes' })) as { ok: true; valor: { id: string } };
    const op = (await m.criar.execute(ctx, { titulo: 'Aberta no padrao' })) as { ok: true; valor: { id: string } };
    m.funis.abertasPorFunil.set(padrao, [op.valor.id]);
    const bloqueado = await arquivar.execute(ctx, { id: padrao });
    assert.deepEqual(codigos(bloqueado), ['conflito']);
    assert.equal((bloqueado as { erros: { meta?: Record<string, unknown> }[] }).erros[0]!.meta?.abertas, 1);
    assert.deepEqual(codigos(await arquivar.execute(ctx, { id: padrao, mover_para_funil_id: padrao })), ['funil_invalido']);
    const r = await arquivar.execute(ctx, { id: padrao, mover_para_funil_id: outro.valor.id });
    assert.ok(r.ok);
    assert.equal(r.valor.movidas, 1);
    assert.equal(r.valor.novo_padrao_id, outro.valor.id);
    assert.equal((await m.ops.obterPorId(op.valor.id))!.funilId, outro.valor.id);
    assert.equal((await m.funis.obterPorId(padrao))!.arquivado, true);
    assert.equal((await m.funis.padrao())!.id, outro.valor.id);
    assert.deepEqual(codigos(await m.criar.execute(ctx, { titulo: 'No arquivado', funil_id: padrao })), ['funil_arquivado']);
    assert.deepEqual(codigos(await arquivar.execute(ctx, { id: padrao })), ['transicao_invalida']);
  });

  it('AbrirOportunidadeDeConversa abre no funil padrao e e idempotente pelo id do evento', async () => {
    const m = await mundo();
    const abrir = new AbrirOportunidadeDeConversa({ repo: m.ops, criar: m.criar });
    const ev = { id: '88888888-8888-4888-8888-888888888888', dados: { conversa_id: 'c1', parceiro_id: PARCEIRO, titulo: 'Conversa WhatsApp com Ana', valor: 1200, moeda: 'BRL', canal: 'whatsapp', atendente_id: USUARIO, origem: 'conversa_whatsapp' } };
    const ctx = contexto();
    const r1 = await abrir.execute(ctx, ev);
    const r2 = await abrir.execute(ctx, ev);
    assert.ok(r1.ok && r2.ok);
    assert.equal(r2.valor.nova, false);
    const d = (await m.ops.obterPorId(r1.valor.id))!.paraDados();
    assert.equal(d.funil_id, await m.padrao());
    assert.equal(d.canal, 'whatsapp');
    assert.equal(d.responsavel_id, USUARIO);
  });
});

describe('Atividades (M2.3)', () => {
  const OP = '77777777-7777-4777-8777-777777777777';

  it('Atividade valida tipo, titulo, data ISO e duracao de uma vez', () => {
    const r = Atividade.tryCreate({ tipo: 'visita' as never, titulo: 'x', data: '05/10/2026', duracao_min: 1 });
    assert.deepEqual(codigos(r).sort(), ['data_invalida', 'duracao_invalida', 'tipo_invalido', 'titulo_invalido']);
    assert.equal(Atividade.create({ tipo: 'ligacao', titulo: 'Ligar', data: '2026-10-05T14:30:00-03:00' }).paraDados().data, '2026-10-05T17:30:00.000Z');
  });

  it('Agendar, editar, concluir e cancelar com eventos, nota na oportunidade e transicoes validas', async () => {
    const repo = new AtividadesMemoria();
    repo.oportunidades.add(OP);
    const ctx = contexto();
    const ag = await new AgendarAtividade({ repo, refs: repo }).execute(ctx, { tipo: 'reuniao', titulo: 'Reuniao de proposta', data: '2026-10-06T10:00', oportunidade_id: OP });
    assert.ok(ag.ok);
    assert.equal((await repo.obterPorId(ag.valor.id))!.paraDados().responsavel_id, USUARIO);
    assert.equal(ctx.efeitos.eventos[0]!.evento, 'atividade.agendada');
    assert.equal(ctx.efeitos.notas[0]!.entidade, 'pipeline_oportunidades');
    assert.ok((await new EditarAtividade({ repo, refs: repo }).execute(ctx, { id: ag.valor.id, duracao_min: 90 })).ok);
    assert.ok((await new ConcluirAtividade({ repo }).execute(ctx, { id: ag.valor.id, resultado: 'Cliente pediu desconto' })).ok);
    assert.equal((await repo.obterPorId(ag.valor.id))!.estado, 'concluida');
    assert.ok(ctx.efeitos.eventos.some((e) => e.evento === 'atividade.concluida'));
    assert.deepEqual(codigos(await new CancelarAtividade({ repo }).execute(ctx, { id: ag.valor.id })), ['transicao_invalida']);
    assert.deepEqual(codigos(await new EditarAtividade({ repo, refs: repo }).execute(ctx, { id: ag.valor.id, titulo: 'Outro' })), ['transicao_invalida']);
    assert.deepEqual(codigos(await new ConcluirAtividade({ repo }).execute(ctx, { id: 'nao-existe' })), ['nao_encontrado']);
    assert.deepEqual(codigos(await new AgendarAtividade({ repo, refs: repo }).execute(ctx, { tipo: 'tarefa', titulo: 'Sem dono', data: '2026-10-06', oportunidade_id: 'x', responsavel_id: 'y' })).sort(), ['oportunidade_invalida', 'usuario_invalido']);
  });
});

describe('Equipes, metas e motivos (M2.4)', () => {
  it('Equipe inclui o lider nos membros, recusa nome repetido e membro inexistente; exclusao bloqueada em uso', async () => {
    assert.deepEqual(Equipe.create({ nome: 'Inside', lider_id: USUARIO, membro_ids: [] }).paraDados().membro_ids, [USUARIO]);
    const repo = new EquipesMemoria();
    const ctx = contexto();
    const r = await new CriarEquipe({ repo, refs: repo }).execute(ctx, { nome: 'Inside Sales', lider_id: USUARIO });
    assert.ok(r.ok);
    assert.deepEqual(codigos(await new CriarEquipe({ repo, refs: repo }).execute(ctx, { nome: 'inside sales' })), ['conflito']);
    assert.deepEqual(codigos(await new CriarEquipe({ repo, refs: repo }).execute(ctx, { nome: 'Outra', membro_ids: ['fantasma'] })), ['usuario_invalido']);
    repo.uso.set(r.valor.id, 1);
    assert.deepEqual(codigos(await new ExcluirEquipe({ repo, refs: repo }).execute(ctx, { id: r.valor.id })), ['conflito']);
  });

  it('Meta exige equipe OU vendedor, valor positivo e e unica por competencia e alvo', async () => {
    assert.deepEqual(codigos(Meta.tryCreate({ competencia: '2026-13', valor_alvo: 0, equipe_id: 'a', vendedor_id: 'b' })).sort(), ['alvo_invalido', 'competencia_invalida', 'valor_invalido']);
    const repo = new MetasMemoria();
    const ctx = contexto();
    const c1 = await new CriarMeta({ repo, refs: repo }).execute(ctx, { competencia: '2026-10', vendedor_id: USUARIO, valor_alvo: 50000 });
    assert.ok(c1.ok);
    assert.deepEqual(codigos(await new CriarMeta({ repo, refs: repo }).execute(ctx, { competencia: '2026-10-01', vendedor_id: USUARIO, valor_alvo: 1 })), ['conflito']);
    assert.deepEqual(codigos(await new CriarMeta({ repo, refs: repo }).execute(ctx, { competencia: '2026-10', equipe_id: 'nao-existe', valor_alvo: 1 })), ['equipe_invalida']);
    assert.ok((await new EditarMeta({ repo }).execute(ctx, { id: c1.valor.id, valor_alvo: 60000 })).ok);
    assert.equal((await repo.obterPorId(c1.valor.id))!.paraDados().valor_alvo, 60000);
  });

  it('Motivo: criar, desativar, conflito de nome e exclusao bloqueada em uso', async () => {
    assert.throws(() => MotivoPerda.create({ nome: 'x' }));
    const repo = new MotivosMemoria();
    const ctx = contexto();
    const r = await new CriarMotivo({ repo }).execute(ctx, { nome: 'Preco alto' });
    assert.ok(r.ok);
    assert.deepEqual(codigos(await new CriarMotivo({ repo }).execute(ctx, { nome: 'PRECO ALTO' })), ['conflito']);
    assert.ok((await new EditarMotivo({ repo }).execute(ctx, { id: r.valor.id, ativo: false })).ok);
    assert.equal((await repo.obterPorId(r.valor.id))!.paraDados().ativo, false);
    repo.uso.set(r.valor.id, 3);
    assert.deepEqual(codigos(await new ExcluirMotivo({ repo }).execute(ctx, { id: r.valor.id })), ['conflito']);
  });
});

describe('Fontes de lead (varias landing pages)', () => {
  async function cenario() {
    const m = await mundo();
    const padrao = await m.padrao();
    const novo = (await new CriarFunil({ repo: m.funis, etapas: m.etapas }).execute(contexto(), { nome: 'Imersao IA', etapas: ['Inscrito', 'Qualificado'] })) as { ok: true; valor: { id: string } };
    const etapasNovo = await m.etapas.listar(novo.valor.id);
    const etapasPadrao = await m.etapas.listar(padrao);
    const abrir = new AbrirOportunidadeDeLead({ repo: m.ops, etapas: m.ops, criar: m.criar });
    return { m, padrao, novo: novo.valor.id, etapasNovo, etapasPadrao, abrir };
  }
  const ev = (id: string, dados: Record<string, unknown>) => ({ id, dados: { parceiro_id: PARCEIRO, nome: 'Ana', origem: 'LP Imersao IA', canal: 'site', ...dados } });

  it('lead da fonte abre no pipeline e na etapa escolhidos, com origem = nome da fonte e canal site', async () => {
    const { m, novo, etapasNovo, abrir } = await cenario();
    const qualificado = etapasNovo.find((e) => e.nome === 'Qualificado')!;
    const r = await abrir.execute(contexto(), ev('77777777-7777-4777-8777-000000000001', { fonte_id: 'f-1', funil_id: novo, etapa_id: qualificado.id }));
    assert.ok(r.ok && r.valor.nova && r.valor.substituido === null);
    const d = (await m.ops.obterPorId(r.valor.id))!.paraDados();
    assert.equal(d.funil_id, novo);
    assert.equal(d.etapa_id, qualificado.id);
    assert.equal(d.origem, 'LP Imersao IA');
    assert.equal(d.canal, 'site');
  });

  it('duas fontes com destinos diferentes abrem cada lead no proprio destino', async () => {
    const { m, padrao, novo, etapasNovo, etapasPadrao, abrir } = await cenario();
    const a = await abrir.execute(contexto(), ev('77777777-7777-4777-8777-000000000002', { origem: 'LP A', fonte_id: 'f-a', funil_id: novo, etapa_id: etapasNovo[0]!.id }));
    const segunda = etapasPadrao.filter((e) => e.tipo === 'aberta')[1]!;
    const b = await abrir.execute(contexto(), ev('77777777-7777-4777-8777-000000000003', { origem: 'LP B', fonte_id: 'f-b', funil_id: padrao, etapa_id: segunda.id }));
    assert.ok(a.ok && b.ok);
    const da = (await m.ops.obterPorId(a.valor.id))!.paraDados();
    const db = (await m.ops.obterPorId(b.valor.id))!.paraDados();
    assert.deepEqual([da.funil_id, da.etapa_id, da.origem], [novo, etapasNovo[0]!.id, 'LP A']);
    assert.deepEqual([db.funil_id, db.etapa_id, db.origem], [padrao, segunda.id, 'LP B']);
  });

  it('pipeline arquivado ou etapa removida: primeira etapa do pipeline padrao e aviso para a fonte', async () => {
    const { m, padrao, novo, etapasNovo, etapasPadrao, abrir } = await cenario();
    const f = m.funis.linhas.get(novo)!;
    m.funis.linhas.set(novo, { ...f, arquivado: true, arquivado_em: new Date().toISOString() } as typeof f);
    const ctx = contexto();
    const r = await abrir.execute(ctx, ev('77777777-7777-4777-8777-000000000004', { fonte_id: 'f-1', funil_id: novo, etapa_id: etapasNovo[0]!.id }));
    assert.ok(r.ok && r.valor.substituido === 'pipeline_arquivado');
    const d = (await m.ops.obterPorId(r.valor.id))!.paraDados();
    assert.equal(d.funil_id, padrao);
    assert.equal(d.etapa_id, etapasPadrao.find((e) => e.tipo === 'aberta')!.id);
    const aviso = ctx.efeitos.eventos.find((e) => e.evento === 'lead.destino_substituido');
    assert.equal(aviso?.dados.fonte_id, 'f-1');
    assert.equal(aviso?.dados.motivo, 'pipeline_arquivado');
    await m.etapas.excluir(etapasPadrao[1]!.id);
    const r2 = await abrir.execute(contexto(), ev('77777777-7777-4777-8777-000000000005', { fonte_id: 'f-2', funil_id: padrao, etapa_id: etapasPadrao[1]!.id }));
    assert.ok(r2.ok && r2.valor.substituido === 'etapa_removida');
    assert.equal((await m.ops.obterPorId(r2.valor.id))!.paraDados().etapa_id, etapasPadrao[0]!.id);
  });

  it('sem destino (URL antiga, fonte padrao) abre no pipeline padrao sem aviso', async () => {
    const { m, padrao, abrir } = await cenario();
    const ctx = contexto();
    const r = await abrir.execute(ctx, ev('77777777-7777-4777-8777-000000000006', { origem: 'Landing page padrão' }));
    assert.ok(r.ok && r.valor.substituido === null);
    assert.equal((await m.ops.obterPorId(r.valor.id))!.paraDados().funil_id, padrao);
    assert.equal(ctx.efeitos.eventos.filter((e) => e.evento === 'lead.destino_substituido').length, 0);
  });
});
