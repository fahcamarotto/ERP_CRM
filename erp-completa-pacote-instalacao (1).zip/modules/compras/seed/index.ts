/**
 * Seed demo do Compras: fornecedores (parceiros do Cadastros com e_fornecedor), requisicoes, cotacoes,
 * pedidos em todos os estados, um recebimento parcial, um total e o historico de preco.
 * Idempotente: ids deterministicos por chave e insercao so do que falta, no workspace do contexto.
 * Grava pelas entidades e adaptadores do modulo (mesmas regras); nao publica evento (dado demo nao
 * movimenta Estoque nem Contas). Outros modulos so por SELECT nas tabelas publicadas.
 */
import { createHash } from 'node:crypto';
import type { SeedModulo } from '@erp/api/sdk/puro';
import { hojeIso, somarDias } from '../api/compartilhado/datas.ts';
import { DocumentoRepoPg, NumeracaoPg } from '../api/documento/adapter/documento-repo-pg.ts';
import { DocumentoCompra, type EntradaItem, type EstadoDocumento, type TipoDocumento } from '../api/documento/model/documento.ts';
import { SEQUENCIA } from '../api/documento/use-case/documentos.ts';
import { FornecedorRepoPg } from '../api/fornecedor/adapter/fornecedor-repo-pg.ts';
import { Fornecedor, type CondicaoPagamento } from '../api/fornecedor/model/fornecedor.ts';
import { PrecosRepoPg } from '../api/preco/precos-repo-pg.ts';
import { RecebimentoRepoPg } from '../api/recebimento/adapter/recebimento-repo-pg.ts';
import { Recebimento } from '../api/recebimento/model/recebimento.ts';
import { SEQUENCIA_RECEBIMENTO } from '../api/recebimento/use-case/registrar-recebimento.ts';

/** uuid deterministico a partir de uma chave (mesmo id em toda execucao). */
function idDe(chave: string): string {
  const h = createHash('sha256').update(`compras-demo:${chave}`).digest('hex');
  return `${h.slice(0, 8)}-${h.slice(8, 12)}-4${h.slice(13, 16)}-a${h.slice(17, 20)}-${h.slice(20, 32)}`;
}

const CONDICOES: [CondicaoPagamento, number, number][] = [['30_dias', 7, 50000], ['15_dias', 3, 20000], ['45_dias', 10, 100000], ['a_vista', 2, 0]];

const CAMINHO: Record<EstadoDocumento, EstadoDocumento[]> = {
  rascunho: [], enviado: ['enviado'], confirmado: ['enviado', 'confirmado'], recebido: ['enviado', 'confirmado'], cancelado: ['cancelado'],
};

const semear: SeedModulo = async ({ c, log }) => {
  const fornecedores = new FornecedorRepoPg(c);
  const documentos = new DocumentoRepoPg(c);
  const recebimentos = new RecebimentoRepoPg(c);
  const precos = new PrecosRepoPg(c);
  const numeracao = new NumeracaoPg(c);
  let novos = 0;

  // Tabelas publicadas: cadastros_parceiros (7.1.1), estoque_produtos e estoque_depositos (7.1.9).
  const parceiros = (await c.query(
    "SELECT id FROM cadastros_parceiros WHERE e_fornecedor AND estado = 'ativo' AND deleted_at IS NULL ORDER BY created_at, id LIMIT 4")).rows as { id: string }[];
  const produtos = (await c.query(
    `SELECT id, nome, unidade, greatest(round(coalesce(nullif(custo, 0), preco * 0.6, 10) * 100), 100)::bigint AS custo_centavos
     FROM estoque_produtos WHERE estado = 'ativo' AND deleted_at IS NULL ORDER BY created_at, id LIMIT 6`)).rows as { id: string; nome: string; unidade: string; custo_centavos: string }[];
  const deposito = (await c.query("SELECT id FROM estoque_depositos WHERE estado = 'ativo' AND deleted_at IS NULL ORDER BY created_at, id LIMIT 1")).rows[0] as { id: string } | undefined;
  if (!parceiros.length || !produtos.length) {
    log('sem fornecedores no Cadastros ou produtos no Estoque: rode os seeds de cadastros e estoque antes');
    return;
  }

  const forn: string[] = [];
  for (const [i, p] of parceiros.entries()) {
    const id = idDe(`fornecedor:${i}`);
    const existente = (await fornecedores.obterPorId(id)) ?? (await fornecedores.buscarPorParceiro(p.id));
    const [condicao, prazo, minimo] = CONDICOES[i % CONDICOES.length]!;
    if (!existente) {
      await fornecedores.inserir(Fornecedor.create({ parceiro_id: p.id, condicao_pagamento: condicao, prazo_entrega_dias: prazo, pedido_minimo_centavos: minimo,
        observacoes: i === 0 ? 'Entrega em horário comercial; exige pedido por e-mail.' : null }, id));
      novos++;
    }
    forn.push(existente?.id ?? id);
  }
  const fornDe = (i: number) => forn[i % forn.length]!;
  const prod = (i: number) => produtos[i % produtos.length]!;
  const item = (i: number, quantidade: number, fator = 1): EntradaItem => ({
    produto_id: prod(i).id, descricao: prod(i).nome, unidade: prod(i).unidade, quantidade,
    preco_unitario_centavos: Math.round(Number(prod(i).custo_centavos) * fator),
  });

  const hoje = hojeIso();
  const garantir = async (k: string, tipo: TipoDocumento, estado: EstadoDocumento, e: {
    fornecedor?: number; itens: EntradaItem[]; origem_id?: string; observacoes?: string; condicao?: CondicaoPagamento; dias?: number;
  }): Promise<DocumentoCompra> => {
    const id = idDe(`documento:${k}`);
    const ja = await documentos.obterPorId(id);
    if (ja) return ja;
    const base = DocumentoCompra.create({
      tipo, fornecedor_id: e.fornecedor === undefined ? null : fornDe(e.fornecedor), itens: e.itens, observacoes: e.observacoes ?? null,
      origem: e.origem_id ? (tipo === 'cotacao' ? 'requisicao' : 'cotacao') : 'manual', origem_id: e.origem_id ?? null,
      condicao_pagamento: e.condicao ?? (tipo === 'requisicao' ? null : '30_dias'), previsao_entrega: somarDias(hoje, e.dias ?? 7),
    }, id).numerar(await numeracao.proximoNumero(SEQUENCIA[tipo]));
    await documentos.inserir(base);
    const final = CAMINHO[estado].reduce((d, s) => { const r = d.mudarEstado(s); if (!r.ok) throw new Error(r.erros[0]!.mensagem); return r.valor; }, base);
    if (final !== base) await documentos.atualizar(final);
    if (tipo !== 'requisicao' && (estado === 'confirmado' || estado === 'recebido')) {
      await precos.registrarPrecos(final.precosDoDocumento().map((p) => ({
        ...p, fornecedor_id: final.fornecedorId!, moeda: 'BRL', origem: tipo === 'cotacao' ? 'cotacao' as const : 'pedido' as const, documento_id: id, data: hoje,
      })));
    }
    novos++;
    return final;
  };

  const receber = async (k: string, pedido: DocumentoCompra, fracao: number, nota: string) => {
    const id = idDe(`recebimento:${k}`);
    const ja = (await c.query('SELECT 1 FROM compras_recebimentos WHERE id = $1', [id])).rowCount;
    if (ja) return;
    const linhas = pedido.paraDados().itens.map((i) => ({ item_id: i.id, quantidade: Math.max(Math.round((i.quantidade - i.quantidade_recebida) * fracao), 1) }));
    const r = pedido.receber(linhas);
    if (!r.ok) throw new Error(r.erros[0]!.mensagem);
    const rec = Recebimento.create({
      pedido_id: pedido.id, data: hoje, deposito_id: deposito?.id ?? null, nota_fiscal: nota, moeda: 'BRL', total: r.valor.total,
      linhas: deposito ? r.valor.recebidas : r.valor.recebidas.map((l) => ({ ...l, produto_id: null })),
    }, id).numerar(await numeracao.proximoNumero(SEQUENCIA_RECEBIMENTO));
    await recebimentos.inserir(rec);
    await documentos.atualizar(r.valor.pedido);
    const d = rec.paraDados();
    await precos.registrarPrecos(d.itens.filter((i) => i.produto_id).map((i) => ({
      produto_id: i.produto_id!, fornecedor_id: pedido.fornecedorId!, preco_unitario_centavos: i.preco_unitario_centavos, moeda: 'BRL',
      origem: 'recebimento' as const, documento_id: id, data: hoje,
    })));
    novos++;
  };

  // Fluxo completo: requisicao aprovada, duas cotacoes (uma escolhida), pedido confirmado com recebimento parcial.
  const req1 = await garantir('req1', 'requisicao', 'confirmado', { itens: [item(0, 40), item(1, 25)], observacoes: 'Reposição mensal do centro de distribuição.' });
  await garantir('cot1b', 'cotacao', 'cancelado', { fornecedor: 1, origem_id: req1.id, itens: [item(0, 40, 1.12), item(1, 25, 1.08)], condicao: '15_dias', dias: 3 });
  const cot1 = await garantir('cot1', 'cotacao', 'confirmado', { fornecedor: 0, origem_id: req1.id, itens: [item(0, 40, 0.97), item(1, 25, 1.02)] });
  const ped1 = await garantir('ped1', 'pedido', 'confirmado', { fornecedor: 0, origem_id: cot1.id, itens: [item(0, 40, 0.97), item(1, 25, 1.02)], observacoes: 'Entregar no CD01.' });
  if (ped1.estado === 'confirmado') await receber('rec1', ped1, 0.5, '000123');

  // Pedido direto recebido por inteiro.
  const ped2 = await garantir('ped2', 'pedido', 'recebido', { fornecedor: 2, itens: [item(2, 12), item(3, 30, 0.95)], condicao: '45_dias', dias: 10 });
  if (ped2.estado === 'confirmado') await receber('rec2', ped2, 1, '004567');

  // Demais estados para cada aba ter conteudo.
  await garantir('req2', 'requisicao', 'rascunho', { itens: [item(4, 10)], observacoes: 'Material de escritório do segundo semestre.' });
  await garantir('req3', 'requisicao', 'enviado', { itens: [item(5, 6), item(2, 4)] });
  await garantir('cot3', 'cotacao', 'enviado', { fornecedor: 3, itens: [item(3, 50, 1.05)], condicao: 'a_vista', dias: 2 });
  await garantir('ped3', 'pedido', 'rascunho', { fornecedor: 1, itens: [item(1, 15, 1.04)], condicao: '15_dias', dias: 3 });
  await garantir('ped4', 'pedido', 'enviado', { fornecedor: 3, itens: [item(5, 8, 0.99), item(4, 20)], condicao: 'a_vista', dias: 2 });
  await garantir('ped5', 'pedido', 'cancelado', { fornecedor: 2, itens: [item(0, 5, 1.2)], observacoes: 'Cancelado: fornecedor sem estoque.' });

  log(`${novos} registro(s) demo novo(s) (${forn.length} fornecedores, 3 requisições, 3 cotações, 5 pedidos, 2 recebimentos)`);
};

export default semear;
