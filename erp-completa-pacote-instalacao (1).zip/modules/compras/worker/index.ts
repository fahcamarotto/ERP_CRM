/**
 * Handlers de worker do Compras (carregados pelo worker do nucleo na partida).
 * `c` ja esta numa transacao do papel erp_worker com o escopo do job (RLS vale).
 */
import type { HandlersModulo } from '@erp/api/sdk/puro';
import { contextoPg } from '../api/compartilhado/efeitos-pg.ts';
import type { AlertaReposicao } from '../api/documento/use-case/documentos.ts';
import { casosDeUso } from '../api/fabrica.ts';

const SISTEMA = { tipo: 'sistema' as const, id: null };
type Evento<T> = { id: string; evento: string; ocorrido_em: string; dados: T };

const handlers: HandlersModulo = {
  // CONTRATOS 7.1.9: estoque.abaixo_minimo abre requisicao de reposicao em rascunho (idempotente pelo alerta).
  'compras:ao:estoque.abaixo_minimo': async (d, c) => {
    const ev = d.payload as Evento<AlertaReposicao>;
    if (!ev?.dados?.produto_id || !ev.dados.alerta_id) return;
    const r = await casosDeUso(c, { worker: true }).abrirRequisicaoReposicao.execute(contextoPg(c, SISTEMA), ev.dados);
    if (!r.ok) throw new Error(r.erros.map((e) => e.mensagem).join('; '));
  },

  // CONTRATOS 7.1.1: parceiro.mesclado reaponta o fornecedor de Compras para o parceiro mantido.
  'compras:ao:parceiro.mesclado': async (d, c) => {
    const ev = d.payload as Evento<{ mantido_id: string; removidos_ids: string[] }>;
    if (!ev?.dados?.mantido_id || !Array.isArray(ev.dados.removidos_ids)) return;
    const r = await casosDeUso(c, { worker: true }).reapontarParceiro.execute(contextoPg(c, SISTEMA), ev.dados);
    if (!r.ok) throw new Error(r.erros.map((e) => e.mensagem).join('; '));
  },
};

export default handlers;
