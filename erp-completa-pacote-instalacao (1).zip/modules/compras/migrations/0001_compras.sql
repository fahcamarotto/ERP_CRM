-- M10 Compras: fornecedores (condicao de pagamento e prazo), documentos de compra (requisicao,
-- cotacao e pedido num fluxo de estados), itens, recebimentos parciais e totais e historico de preco.
-- Toda tabela: tenant_id e workspace_id do contexto da sessao, PK composta, FK composta, RLS
-- por nucleo_aplicar_padrao, exclusao logica (sem DELETE). Idempotente.
-- Outros modulos so por tabela publicada: cadastros_parceiros, estoque_produtos, estoque_depositos.

-- M10.2 Fornecedor ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS compras_fornecedores (
  id                      uuid NOT NULL DEFAULT gen_random_uuid(),
  tenant_id               uuid NOT NULL DEFAULT nucleo_tenant_atual(),
  workspace_id            uuid NOT NULL DEFAULT nucleo_workspace_atual(),
  creator_id              uuid,
  parceiro_id             uuid NOT NULL,
  condicao_pagamento      text NOT NULL DEFAULT '30_dias'
                          CHECK (condicao_pagamento IN ('a_vista', '7_dias', '15_dias', '30_dias', '45_dias', '60_dias', '90_dias')),
  prazo_entrega_dias      integer NOT NULL DEFAULT 7 CHECK (prazo_entrega_dias BETWEEN 0 AND 365),
  pedido_minimo_centavos  bigint NOT NULL DEFAULT 0 CHECK (pedido_minimo_centavos >= 0),
  observacoes             text,
  estado                  text NOT NULL DEFAULT 'ativo' CHECK (estado IN ('ativo', 'arquivado')),
  extras                  jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at              timestamptz NOT NULL DEFAULT now(),
  updated_at              timestamptz NOT NULL DEFAULT now(),
  deleted_at              timestamptz,
  PRIMARY KEY (id, tenant_id, workspace_id),
  FOREIGN KEY (workspace_id, tenant_id) REFERENCES workspaces (id, tenant_id),
  FOREIGN KEY (creator_id, tenant_id, workspace_id) REFERENCES usuarios (id, tenant_id, workspace_id),
  FOREIGN KEY (parceiro_id, tenant_id, workspace_id) REFERENCES cadastros_parceiros (id, tenant_id, workspace_id)
);
CREATE UNIQUE INDEX IF NOT EXISTS compras_fornecedores_parceiro_uq
  ON compras_fornecedores (tenant_id, workspace_id, parceiro_id) WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS compras_fornecedores_lista_idx ON compras_fornecedores (tenant_id, workspace_id, created_at, id) WHERE deleted_at IS NULL;
SELECT nucleo_aplicar_padrao('compras_fornecedores');
DROP TRIGGER IF EXISTS compras_fornecedores_extras ON compras_fornecedores;
CREATE TRIGGER compras_fornecedores_extras BEFORE INSERT OR UPDATE OF extras ON compras_fornecedores
  FOR EACH ROW EXECUTE FUNCTION nucleo_trigger_extras('compras', 'fornecedor');

-- M10.1 Requisicao, cotacao e pedido (agregado DocumentoCompra) ---------------------------------
CREATE TABLE IF NOT EXISTS compras_documentos (
  id                  uuid NOT NULL DEFAULT gen_random_uuid(),
  tenant_id           uuid NOT NULL DEFAULT nucleo_tenant_atual(),
  workspace_id        uuid NOT NULL DEFAULT nucleo_workspace_atual(),
  creator_id          uuid,
  tipo                text NOT NULL CHECK (tipo IN ('requisicao', 'cotacao', 'pedido')),
  numero              text NOT NULL CHECK (length(btrim(numero)) BETWEEN 1 AND 40),
  fornecedor_id       uuid,
  origem_id           uuid,
  origem              text NOT NULL DEFAULT 'manual' CHECK (origem IN ('manual', 'reposicao', 'requisicao', 'cotacao')),
  origem_ref          text,
  moeda               text NOT NULL DEFAULT 'BRL' CHECK (moeda ~ '^[A-Z]{3}$'),
  previsao_entrega    date,
  condicao_pagamento  text CHECK (condicao_pagamento IS NULL OR condicao_pagamento IN ('a_vista', '7_dias', '15_dias', '30_dias', '45_dias', '60_dias', '90_dias')),
  observacoes         text,
  estado              text NOT NULL DEFAULT 'rascunho' CHECK (estado IN ('rascunho', 'enviado', 'confirmado', 'recebido', 'cancelado')),
  total_centavos      bigint NOT NULL DEFAULT 0 CHECK (total_centavos >= 0),
  enviado_em          timestamptz,
  confirmado_em       timestamptz,
  recebido_em         timestamptz,
  cancelado_em        timestamptz,
  extras              jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at          timestamptz NOT NULL DEFAULT now(),
  updated_at          timestamptz NOT NULL DEFAULT now(),
  deleted_at          timestamptz,
  PRIMARY KEY (id, tenant_id, workspace_id),
  FOREIGN KEY (workspace_id, tenant_id) REFERENCES workspaces (id, tenant_id),
  FOREIGN KEY (creator_id, tenant_id, workspace_id) REFERENCES usuarios (id, tenant_id, workspace_id),
  FOREIGN KEY (fornecedor_id, tenant_id, workspace_id) REFERENCES compras_fornecedores (id, tenant_id, workspace_id),
  FOREIGN KEY (origem_id, tenant_id, workspace_id) REFERENCES compras_documentos (id, tenant_id, workspace_id),
  CHECK (tipo = 'requisicao' OR fornecedor_id IS NOT NULL),
  CHECK (estado <> 'recebido' OR tipo = 'pedido'),
  CHECK (origem_id IS NULL OR origem_id <> id)
);
CREATE UNIQUE INDEX IF NOT EXISTS compras_documentos_numero_uq
  ON compras_documentos (tenant_id, workspace_id, tipo, numero) WHERE deleted_at IS NULL;
CREATE UNIQUE INDEX IF NOT EXISTS compras_documentos_origem_ref_uq
  ON compras_documentos (tenant_id, workspace_id, origem_ref) WHERE origem_ref IS NOT NULL AND deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS compras_documentos_lista_idx ON compras_documentos (tenant_id, workspace_id, tipo, created_at, id) WHERE deleted_at IS NULL;
SELECT nucleo_aplicar_padrao('compras_documentos');
DROP TRIGGER IF EXISTS compras_documentos_extras ON compras_documentos;
CREATE TRIGGER compras_documentos_extras BEFORE INSERT OR UPDATE OF extras ON compras_documentos
  FOR EACH ROW EXECUTE FUNCTION nucleo_trigger_extras('compras', 'documento');

CREATE TABLE IF NOT EXISTS compras_itens (
  id                       uuid NOT NULL DEFAULT gen_random_uuid(),
  tenant_id                uuid NOT NULL DEFAULT nucleo_tenant_atual(),
  workspace_id             uuid NOT NULL DEFAULT nucleo_workspace_atual(),
  creator_id               uuid,
  documento_id             uuid NOT NULL,
  ordem                    integer NOT NULL DEFAULT 0,
  produto_id               uuid,
  descricao                text NOT NULL CHECK (length(btrim(descricao)) BETWEEN 1 AND 200),
  unidade                  text NOT NULL DEFAULT 'UN',
  quantidade               numeric(14,3) NOT NULL CHECK (quantidade > 0),
  preco_unitario_centavos  bigint NOT NULL DEFAULT 0 CHECK (preco_unitario_centavos >= 0),
  total_centavos           bigint NOT NULL DEFAULT 0 CHECK (total_centavos >= 0),
  quantidade_recebida      numeric(14,3) NOT NULL DEFAULT 0 CHECK (quantidade_recebida >= 0 AND quantidade_recebida <= quantidade),
  created_at               timestamptz NOT NULL DEFAULT now(),
  updated_at               timestamptz NOT NULL DEFAULT now(),
  deleted_at               timestamptz,
  PRIMARY KEY (id, tenant_id, workspace_id),
  FOREIGN KEY (workspace_id, tenant_id) REFERENCES workspaces (id, tenant_id),
  FOREIGN KEY (creator_id, tenant_id, workspace_id) REFERENCES usuarios (id, tenant_id, workspace_id),
  FOREIGN KEY (documento_id, tenant_id, workspace_id) REFERENCES compras_documentos (id, tenant_id, workspace_id),
  FOREIGN KEY (produto_id, tenant_id, workspace_id) REFERENCES estoque_produtos (id, tenant_id, workspace_id)
);
CREATE INDEX IF NOT EXISTS compras_itens_documento_idx ON compras_itens (tenant_id, workspace_id, documento_id, ordem) WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS compras_itens_produto_idx ON compras_itens (tenant_id, workspace_id, produto_id) WHERE deleted_at IS NULL;
SELECT nucleo_aplicar_padrao('compras_itens');

-- M10.3 Recebimento parcial e total ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS compras_recebimentos (
  id              uuid NOT NULL DEFAULT gen_random_uuid(),
  tenant_id       uuid NOT NULL DEFAULT nucleo_tenant_atual(),
  workspace_id    uuid NOT NULL DEFAULT nucleo_workspace_atual(),
  creator_id      uuid,
  numero          text NOT NULL CHECK (length(btrim(numero)) BETWEEN 1 AND 40),
  pedido_id       uuid NOT NULL,
  data            date NOT NULL DEFAULT current_date,
  deposito_id     uuid,
  nota_fiscal     text,
  observacoes     text,
  tipo            text NOT NULL CHECK (tipo IN ('parcial', 'total')),
  moeda           text NOT NULL DEFAULT 'BRL' CHECK (moeda ~ '^[A-Z]{3}$'),
  total_centavos  bigint NOT NULL DEFAULT 0 CHECK (total_centavos >= 0),
  created_at      timestamptz NOT NULL DEFAULT now(),
  updated_at      timestamptz NOT NULL DEFAULT now(),
  deleted_at      timestamptz,
  PRIMARY KEY (id, tenant_id, workspace_id),
  FOREIGN KEY (workspace_id, tenant_id) REFERENCES workspaces (id, tenant_id),
  FOREIGN KEY (creator_id, tenant_id, workspace_id) REFERENCES usuarios (id, tenant_id, workspace_id),
  FOREIGN KEY (pedido_id, tenant_id, workspace_id) REFERENCES compras_documentos (id, tenant_id, workspace_id),
  FOREIGN KEY (deposito_id, tenant_id, workspace_id) REFERENCES estoque_depositos (id, tenant_id, workspace_id)
);
CREATE UNIQUE INDEX IF NOT EXISTS compras_recebimentos_numero_uq ON compras_recebimentos (tenant_id, workspace_id, numero) WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS compras_recebimentos_lista_idx ON compras_recebimentos (tenant_id, workspace_id, created_at, id) WHERE deleted_at IS NULL;
SELECT nucleo_aplicar_padrao('compras_recebimentos');

CREATE TABLE IF NOT EXISTS compras_recebimento_itens (
  id                       uuid NOT NULL DEFAULT gen_random_uuid(),
  tenant_id                uuid NOT NULL DEFAULT nucleo_tenant_atual(),
  workspace_id             uuid NOT NULL DEFAULT nucleo_workspace_atual(),
  creator_id               uuid,
  recebimento_id           uuid NOT NULL,
  item_id                  uuid NOT NULL,
  produto_id               uuid,
  descricao                text NOT NULL,
  quantidade               numeric(14,3) NOT NULL CHECK (quantidade > 0),
  preco_unitario_centavos  bigint NOT NULL DEFAULT 0 CHECK (preco_unitario_centavos >= 0),
  total_centavos           bigint NOT NULL DEFAULT 0 CHECK (total_centavos >= 0),
  lote_codigo              text,
  validade                 date,
  created_at               timestamptz NOT NULL DEFAULT now(),
  updated_at               timestamptz NOT NULL DEFAULT now(),
  deleted_at               timestamptz,
  PRIMARY KEY (id, tenant_id, workspace_id),
  FOREIGN KEY (workspace_id, tenant_id) REFERENCES workspaces (id, tenant_id),
  FOREIGN KEY (creator_id, tenant_id, workspace_id) REFERENCES usuarios (id, tenant_id, workspace_id),
  FOREIGN KEY (recebimento_id, tenant_id, workspace_id) REFERENCES compras_recebimentos (id, tenant_id, workspace_id),
  FOREIGN KEY (item_id, tenant_id, workspace_id) REFERENCES compras_itens (id, tenant_id, workspace_id),
  FOREIGN KEY (produto_id, tenant_id, workspace_id) REFERENCES estoque_produtos (id, tenant_id, workspace_id)
);
CREATE INDEX IF NOT EXISTS compras_recebimento_itens_rec_idx ON compras_recebimento_itens (tenant_id, workspace_id, recebimento_id) WHERE deleted_at IS NULL;
SELECT nucleo_aplicar_padrao('compras_recebimento_itens');

-- M10.4 Historico de preco por produto e fornecedor ---------------------------------------------
CREATE TABLE IF NOT EXISTS compras_precos (
  id                       uuid NOT NULL DEFAULT gen_random_uuid(),
  tenant_id                uuid NOT NULL DEFAULT nucleo_tenant_atual(),
  workspace_id             uuid NOT NULL DEFAULT nucleo_workspace_atual(),
  creator_id               uuid,
  produto_id               uuid NOT NULL,
  fornecedor_id            uuid NOT NULL,
  preco_unitario_centavos  bigint NOT NULL CHECK (preco_unitario_centavos > 0),
  moeda                    text NOT NULL DEFAULT 'BRL' CHECK (moeda ~ '^[A-Z]{3}$'),
  origem                   text NOT NULL CHECK (origem IN ('cotacao', 'pedido', 'recebimento')),
  documento_id             uuid NOT NULL,
  data                     date NOT NULL DEFAULT current_date,
  created_at               timestamptz NOT NULL DEFAULT now(),
  updated_at               timestamptz NOT NULL DEFAULT now(),
  deleted_at               timestamptz,
  PRIMARY KEY (id, tenant_id, workspace_id),
  FOREIGN KEY (workspace_id, tenant_id) REFERENCES workspaces (id, tenant_id),
  FOREIGN KEY (creator_id, tenant_id, workspace_id) REFERENCES usuarios (id, tenant_id, workspace_id),
  FOREIGN KEY (produto_id, tenant_id, workspace_id) REFERENCES estoque_produtos (id, tenant_id, workspace_id),
  FOREIGN KEY (fornecedor_id, tenant_id, workspace_id) REFERENCES compras_fornecedores (id, tenant_id, workspace_id)
);
CREATE UNIQUE INDEX IF NOT EXISTS compras_precos_origem_uq
  ON compras_precos (tenant_id, workspace_id, documento_id, produto_id, origem) WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS compras_precos_produto_idx ON compras_precos (tenant_id, workspace_id, produto_id, fornecedor_id, data DESC) WHERE deleted_at IS NULL;
SELECT nucleo_aplicar_padrao('compras_precos');

-- Papeis de banco: API (erp_app) e worker (erp_worker: requisicao de reposicao e parceiro mesclado).
GRANT SELECT, INSERT, UPDATE ON compras_fornecedores, compras_documentos, compras_itens, compras_recebimentos,
  compras_recebimento_itens, compras_precos TO erp_app;
GRANT SELECT, INSERT, UPDATE ON compras_fornecedores, compras_documentos, compras_itens TO erp_worker;
GRANT SELECT ON compras_recebimentos, compras_recebimento_itens, compras_precos TO erp_worker;
