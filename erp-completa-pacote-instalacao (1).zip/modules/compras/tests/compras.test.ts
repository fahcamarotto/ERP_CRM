/**
 * P3 do modulo Compras: cada caso de uso com repositorio em memoria.
 * Rodar: node --import tsx --test modules/compras/tests/*.test.ts
 */
import assert from 'node:assert/strict';
import { describe, it } from 'node:test';
import { Centavos } from '../api/documento/model/centavos.ts';
import { DocumentoCompra, transicoesManuais } from '../api/documento/model/documento.ts';
import { Quantidade } from '../api/documento/model/quantidade.ts';
import {
  AbrirRequisicaoReposicao, CriarDocumento, EditarDocumento, ExcluirDocumentoCompra, GerarCotacoes, GerarPedido, MudarEstadoDocumento,
} from '../api/documento/use-case/documentos.ts';
import { Fornecedor } from '../api/fornecedor/model/fornecedor.ts';
import { CriarFornecedor, EditarFornecedor, MudarEstadoFornecedor, ReapontarParceiro } from '../api/fornecedor/use-case/fornecedores.ts';
import { RegistrarRecebimento } from '../api/recebimento/use-case/registrar-recebimento.ts';
import {
  contexto, DEPOSITO, DocumentosMemoria, FornecedoresMemoria, PARCEIRO, PARCEIRO_2, PrecosMemoria, PRODUTO_A, PRODUTO_B, RecebimentosMemoria,
} from './memoria.ts';

const F1 = '40000000-0000-4000-8000-000000000001';
const F2 = '40000000-0000-4000-8000-000000000002';

function montar() {
  const docs = new DocumentosMemoria();
  docs.fornecedores.set(F1, { id: F1, parceiro_id: PARCEIRO, condicao_pagamento: '30_dias', prazo_entrega_dias: 5 });
  docs.fornecedores.set(F2, { id: F2, parceiro_id: PARCEIRO_2, condicao_pagamento: '15_dias', prazo_entrega_dias: 2 });
  const precos = new PrecosMemoria();
  const recs = new RecebimentosMemoria(docs);
  const deps = { repo: docs, refs: docs, numeracao: docs };
  return {
    docs, precos, recs,
    criar: new CriarDocumento(deps),
    editar: new EditarDocumento({ repo: docs, refs: docs }),
    mudar: new MudarEstadoDocumento({ repo: docs, refs: docs, precos }),
    excluir: new ExcluirDocumentoCompra({ repo: docs }),
    gerarCotacoes: new GerarCotacoes({ ...deps, precos }),
    gerarPedido: new GerarPedido(deps),
    reposicao: new AbrirRequisicaoReposicao({ ...deps, busca: docs }),
    receber: new RegistrarRecebimento({ pedidos: docs, recebimentos: recs, refs: recs, numeracao: docs, precos }),
  };
}

const itensPadrao = () => [
  { produto_id: PRODUTO_A, quantidade: 10, preco_unitario_centavos: 2590 },
  { produto_id: PRODUTO_B, quantidade: 4, preco_unitario_centavos: 18900 },
];

async function pedidoConfirmado(m: ReturnType<typeof montar>) {
  const ctx = contexto();
  const r = await m.criar.execute(ctx, { tipo: 'pedido', fornecedor_id: F1, itens: itensPadrao() });
  assert.ok(r.ok);
  assert.ok((await m.mudar.execute(ctx, { id: r.valor.id, estado: 'enviado' })).ok);
  assert.ok((await m.mudar.execute(ctx, { id: r.valor.id, estado: 'confirmado' })).ok);
  return r.valor.id;
}

describe('objetos de valor', () => {
  it('Quantidade aceita positiva com 3 casas e recusa zero, negativa e texto', () => {
    const r = Quantidade.tryCreate('2,5');
    assert.ok(r.ok);
    assert.equal(r.valor.valor, 2.5);
    assert.equal(Quantidade.create(1.23456).valor, 1.235);
    for (const ruim of [0, -1, 'abc', Number.NaN]) {
      const x = Quantidade.tryCreate(ruim);
      assert.ok(!x.ok);
      assert.equal(x.erros[0]!.codigo, 'quantidade_invalida');
    }
    assert.throws(() => Quantidade.create(0));
  });

  it('Centavos aceita inteiro zero ou positivo e calcula o total da linha', () => {
    assert.ok(Centavos.tryCreate(0).ok);
    assert.ok(!Centavos.tryCreate(10.5).ok);
    assert.ok(!Centavos.tryCreate(-1).ok);
    assert.throws(() => Centavos.create(-5));
    assert.equal(Centavos.total(2.5, 333), 833);
  });
});

describe('Fornecedor (M10.2)', () => {
  it('tryCreate acumula todos os erros de uma vez', () => {
    const r = Fornecedor.tryCreate({ parceiro_id: 'x', condicao_pagamento: '99_dias' as never, prazo_entrega_dias: 400, pedido_minimo_centavos: -1 });
    assert.ok(!r.ok);
    assert.deepEqual(r.erros.map((e) => e.codigo).sort(), ['condicao_invalida', 'parceiro_invalido', 'prazo_invalido', 'valor_invalido']);
  });

  it('editar devolve clone e nao muda o original', () => {
    const f = Fornecedor.create({ parceiro_id: PARCEIRO });
    const r = f.editar({ prazo_entrega_dias: 12, condicao_pagamento: 'a_vista' });
    assert.ok(r.ok);
    assert.equal(r.valor.prazoEntregaDias, 12);
    assert.equal(f.prazoEntregaDias, 7);
    assert.equal(f.condicao, '30_dias');
  });

  it('CriarFornecedor: caminho feliz, parceiro invalido e conflito no mesmo parceiro', async () => {
    const repo = new FornecedoresMemoria();
    const uc = new CriarFornecedor({ repo, parceiros: repo });
    const ctx = contexto();
    const r = await uc.execute(ctx, { parceiro_id: PARCEIRO, condicao_pagamento: '45_dias', prazo_entrega_dias: 10 });
    assert.ok(r.ok);
    assert.deepEqual(ctx.efeitos.auditoria.map((a) => a.acao), ['fornecedor.criar']);
    const dup = await uc.execute(ctx, { parceiro_id: PARCEIRO });
    assert.ok(!dup.ok);
    assert.equal(dup.erros[0]!.codigo, 'conflito');
    assert.equal(dup.erros[0]!.meta?.fornecedor_id, r.valor.id);
    const sem = await uc.execute(ctx, { parceiro_id: '10000000-0000-4000-8000-0000000000ff' });
    assert.ok(!sem.ok);
    assert.equal(sem.erros[0]!.codigo, 'parceiro_invalido');
  });

  it('EditarFornecedor grava historico; arquivar com pedido aberto da conflito; nao encontrado', async () => {
    const repo = new FornecedoresMemoria();
    const ctx = contexto();
    const { id } = (await new CriarFornecedor({ repo, parceiros: repo }).execute(ctx, { parceiro_id: PARCEIRO }) as { ok: true; valor: { id: string } }).valor;
    assert.ok((await new EditarFornecedor({ repo }).execute(ctx, { id, pedido_minimo_centavos: 50000 })).ok);
    assert.equal(ctx.efeitos.historicos.length, 1);
    const mudar = new MudarEstadoFornecedor({ repo, abertos: repo });
    repo.abertos.set(id, 2);
    const c = await mudar.execute(ctx, { id, estado: 'arquivado' });
    assert.ok(!c.ok);
    assert.equal(c.erros[0]!.codigo, 'conflito');
    repo.abertos.set(id, 0);
    assert.ok((await mudar.execute(ctx, { id, estado: 'arquivado' })).ok);
    const de_novo = await mudar.execute(ctx, { id, estado: 'arquivado' });
    assert.equal(!de_novo.ok && de_novo.erros[0]!.codigo, 'transicao_invalida');
    const nf = await mudar.execute(ctx, { id: F2, estado: 'ativo' });
    assert.equal(!nf.ok && nf.erros[0]!.codigo, 'nao_encontrado');
  });

  it('ReapontarParceiro reaponta para o mantido ou arquiva quando o mantido ja e fornecedor', async () => {
    const repo = new FornecedoresMemoria();
    const a = Fornecedor.create({ parceiro_id: PARCEIRO });
    await repo.inserir(a);
    const uc = new ReapontarParceiro({ repo });
    const r = await uc.execute(contexto(), { mantido_id: PARCEIRO_2, removidos_ids: [PARCEIRO] });
    assert.ok(r.ok);
    assert.deepEqual(r.valor, { reapontados: 1, arquivados: 0 });
    assert.equal((await repo.obterPorId(a.id))!.parceiroId, PARCEIRO_2);
    const b = Fornecedor.create({ parceiro_id: PARCEIRO });
    await repo.inserir(b);
    const r2 = await uc.execute(contexto(), { mantido_id: PARCEIRO_2, removidos_ids: [PARCEIRO] });
    assert.ok(r2.ok);
    assert.deepEqual(r2.valor, { reapontados: 0, arquivados: 1 });
    assert.equal((await repo.obterPorId(b.id))!.estado, 'arquivado');
  });
});

describe('DocumentoCompra (M10.1)', () => {
  it('tryCreate acumula erros: sem itens, cotacao sem fornecedor, moeda e data invalidas', () => {
    const r = DocumentoCompra.tryCreate({ tipo: 'cotacao', moeda: 'reais', previsao_entrega: '31/12/2026', itens: [] });
    assert.ok(!r.ok);
    assert.deepEqual(r.erros.map((e) => e.codigo).sort(), ['data_invalida', 'fornecedor_obrigatorio', 'itens_obrigatorios', 'moeda_invalida']);
    const itensRuins = DocumentoCompra.tryCreate({ tipo: 'requisicao', itens: [{ quantidade: 0, descricao: '' }, { quantidade: 2, preco_unitario_centavos: 1.5, descricao: 'x' }] });
    assert.ok(!itensRuins.ok);
    assert.deepEqual(itensRuins.erros.map((e) => e.campo), ['itens.0.quantidade', 'itens.0.descricao', 'itens.1.preco_unitario_centavos']);
  });

  it('editar so em rascunho e devolve clone sem mudar o original', () => {
    const d = DocumentoCompra.create({ tipo: 'requisicao', itens: [{ descricao: 'Cadeira', quantidade: 2 }] });
    const r = d.editar({ itens: [{ descricao: 'Cadeira', quantidade: 5, preco_unitario_centavos: 30000 }] });
    assert.ok(r.ok);
    assert.equal(r.valor.paraDados().total_centavos, 150000);
    assert.equal(d.paraDados().itens[0]!.quantidade, 2);
    const enviado = d.mudarEstado('enviado');
    assert.ok(enviado.ok);
    const e = enviado.valor.editar({ observacoes: 'x' });
    assert.equal(!e.ok && e.erros[0]!.codigo, 'transicao_invalida');
  });

  it('maquina de estados: transicoes invalidas, recebido nunca a mao e preco obrigatorio no pedido', () => {
    const p = DocumentoCompra.create({ tipo: 'pedido', fornecedor_id: F1, itens: [{ descricao: 'Sem preco', quantidade: 1 }] });
    for (const [de, para] of [['rascunho', 'confirmado'], ['rascunho', 'recebido'], ['rascunho', 'rascunho']] as const) {
      assert.equal(p.estado, de);
      const r = p.mudarEstado(para);
      assert.ok(!r.ok);
      assert.equal(r.erros[0]!.codigo, 'transicao_invalida');
    }
    const semPreco = p.mudarEstado('enviado');
    assert.equal(!semPreco.ok && semPreco.erros[0]!.codigo, 'preco_obrigatorio');
    const cancelado = p.mudarEstado('cancelado');
    assert.ok(cancelado.ok);
    assert.deepEqual(transicoesManuais(cancelado.valor.estado), []);
    assert.deepEqual(transicoesManuais('confirmado'), ['cancelado']);
    assert.ok(!cancelado.valor.mudarEstado('rascunho').ok);
  });

  it('CriarDocumento (pedido_compra.criar): descricao do produto, condicao e prazo do fornecedor, numero, auditoria e evento', async () => {
    const m = montar();
    const ctx = contexto();
    const r = await m.criar.execute(ctx, { tipo: 'pedido', fornecedor_id: F1, itens: [{ produto_id: PRODUTO_A, quantidade: 3, preco_unitario_centavos: 2590 }] });
    assert.ok(r.ok);
    assert.equal(r.valor.numero, 'PC-0001');
    const d = (await m.docs.obterPorId(r.valor.id))!.paraDados();
    assert.equal(d.itens[0]!.descricao, 'Papel A4 500 folhas');
    assert.equal(d.itens[0]!.unidade, 'CX');
    assert.equal(d.condicao_pagamento, '30_dias');
    assert.ok(d.previsao_entrega);
    assert.equal(d.total_centavos, 7770);
    assert.deepEqual(ctx.efeitos.auditoria.map((a) => a.acao), ['pedido.criar']);
    assert.equal(ctx.efeitos.eventos[0]!.evento, 'pedido_compra.criado');
    assert.equal(ctx.efeitos.eventos[0]!.dados.parceiro_id, PARCEIRO);
  });

  it('CriarDocumento recusa fornecedor e produto inexistentes', async () => {
    const m = montar();
    const f = await m.criar.execute(contexto(), { tipo: 'pedido', fornecedor_id: '40000000-0000-4000-8000-0000000000ff', itens: itensPadrao() });
    assert.equal(!f.ok && f.erros[0]!.codigo, 'fornecedor_invalido');
    const p = await m.criar.execute(contexto(), { tipo: 'requisicao', itens: [{ produto_id: '20000000-0000-4000-8000-0000000000ff', quantidade: 1 }] });
    assert.equal(!p.ok && p.erros[0]!.codigo, 'produto_invalido');
  });

  it('EditarDocumento grava historico; nao encontrado; excluir so rascunho ou cancelado', async () => {
    const m = montar();
    const ctx = contexto();
    const r = await m.criar.execute(ctx, { tipo: 'requisicao', itens: [{ produto_id: PRODUTO_B, quantidade: 1 }] });
    assert.ok(r.ok);
    assert.ok((await m.editar.execute(ctx, { id: r.valor.id, observacoes: 'Urgente' })).ok);
    assert.equal(ctx.efeitos.historicos.length, 1);
    const nf = await m.editar.execute(ctx, { id: F1, observacoes: 'x' });
    assert.equal(!nf.ok && nf.erros[0]!.codigo, 'nao_encontrado');
    assert.ok((await m.mudar.execute(ctx, { id: r.valor.id, estado: 'enviado' })).ok);
    const ex = await m.excluir.execute(ctx, { id: r.valor.id });
    assert.equal(!ex.ok && ex.erros[0]!.codigo, 'transicao_invalida');
    assert.ok((await m.mudar.execute(ctx, { id: r.valor.id, estado: 'cancelado', motivo: 'Duplicada' })).ok);
    assert.ok(ctx.efeitos.notas.some((n) => n.corpo.includes('Duplicada')));
    assert.ok((await m.excluir.execute(ctx, { id: r.valor.id })).ok);
    assert.equal(await m.docs.obterPorId(r.valor.id), null);
  });
});

describe('fluxo requisicao, cotacao e pedido', () => {
  it('requisicao aprovada gera cotacoes com preco do historico; escolher uma cancela a outra e grava preco; gera pedido', async () => {
    const m = montar();
    const ctx = contexto();
    await m.precos.registrarPrecos([{ produto_id: PRODUTO_A, fornecedor_id: F1, preco_unitario_centavos: 2400, moeda: 'BRL', origem: 'pedido', documento_id: F1, data: '2026-09-01' }]);
    const req = await m.criar.execute(ctx, { tipo: 'requisicao', itens: [{ produto_id: PRODUTO_A, quantidade: 10 }, { produto_id: PRODUTO_B, quantidade: 2 }] });
    assert.ok(req.ok);
    assert.equal(ctx.efeitos.eventos[0]!.evento, 'requisicao_compra.criada');
    const antes = await m.gerarCotacoes.execute(ctx, { requisicao_id: req.valor.id, fornecedor_ids: [F1] });
    assert.equal(!antes.ok && antes.erros[0]!.codigo, 'transicao_invalida');
    await m.mudar.execute(ctx, { id: req.valor.id, estado: 'enviado' });
    await m.mudar.execute(ctx, { id: req.valor.id, estado: 'confirmado' });
    const cots = await m.gerarCotacoes.execute(ctx, { requisicao_id: req.valor.id, fornecedor_ids: [F1, F2] });
    assert.ok(cots.ok);
    const [c1, c2] = cots.valor.ids as [string, string];
    const d1 = (await m.docs.obterPorId(c1))!.paraDados();
    assert.equal(d1.origem, 'requisicao');
    assert.equal(d1.origem_id, req.valor.id);
    assert.equal(d1.itens[0]!.preco_unitario_centavos, 2400);
    assert.equal(d1.itens[1]!.preco_unitario_centavos, 0);
    assert.equal((await m.docs.obterPorId(c2))!.paraDados().condicao_pagamento, '15_dias');
    const semPreco = await m.mudar.execute(ctx, { id: c1, estado: 'enviado' });
    assert.equal(!semPreco.ok && semPreco.erros[0]!.codigo, 'preco_obrigatorio');
    assert.ok((await m.editar.execute(ctx, { id: c1, itens: d1.itens.map((i) => ({ id: i.id, produto_id: i.produto_id, quantidade: i.quantidade, preco_unitario_centavos: i.preco_unitario_centavos || 17500 })) })).ok);
    await m.mudar.execute(ctx, { id: c1, estado: 'enviado' });
    const escolha = await m.mudar.execute(ctx, { id: c1, estado: 'confirmado' });
    assert.ok(escolha.ok);
    assert.deepEqual(escolha.valor.canceladas, [c2]);
    assert.equal((await m.docs.obterPorId(c2))!.estado, 'cancelado');
    assert.ok(ctx.efeitos.eventos.some((e) => e.evento === 'cotacao_compra.escolhida'));
    assert.equal(m.precos.linhas.filter((l) => l.origem === 'cotacao').length, 2);
    const ped = await m.gerarPedido.execute(ctx, { cotacao_id: c1 });
    assert.ok(ped.ok);
    const pd = (await m.docs.obterPorId(ped.valor.id))!.paraDados();
    assert.equal(pd.tipo, 'pedido');
    assert.equal(pd.origem_id, c1);
    assert.equal(pd.total_centavos, 10 * 2400 + 2 * 17500);
    const deNovo = await m.gerarPedido.execute(ctx, { cotacao_id: c2 });
    assert.equal(!deNovo.ok && deNovo.erros[0]!.codigo, 'transicao_invalida');
  });
});

describe('Recebimento (M10.3)', () => {
  it('parcial e depois total: confere com o pedido, publica entrada de estoque e conta a pagar, pedido vira recebido', async () => {
    const m = montar();
    const id = await pedidoConfirmado(m);
    const itens = (await m.docs.obterPorId(id))!.paraDados().itens;
    const ctx = contexto();
    const r1 = await m.receber.execute(ctx, {
      pedido_id: id, data: '2026-10-01', deposito_id: DEPOSITO, nota_fiscal: '123',
      itens: [{ item_id: itens[0]!.id, quantidade: 6, lote_codigo: 'L-01', validade: '2027-10-01' }],
    });
    assert.ok(r1.ok);
    assert.equal(r1.valor.tipo, 'parcial');
    assert.equal((await m.docs.obterPorId(id))!.estado, 'confirmado');
    const ev = ctx.efeitos.eventos.find((e) => e.evento === 'recebimento_compra.registrado')!;
    const mov = ev.dados.movimentacao as { tipo: string; deposito_id: string; parceiro_id: string; itens: { produto_id: string; quantidade: number; custo_unitario: number; lote_codigo: string }[] };
    assert.equal(mov.tipo, 'entrada');
    assert.equal(mov.deposito_id, DEPOSITO);
    assert.equal(mov.parceiro_id, PARCEIRO);
    assert.deepEqual(mov.itens[0], { produto_id: PRODUTO_A, quantidade: 6, custo_unitario: 25.9, lote_codigo: 'L-01', validade: '2027-10-01' });
    const conta = ev.dados.conta_pagar as { tipo: string; parceiro_id: string; condicao_pagamento: string; chave_idempotencia: string; itens: { preco_centavos: number; quantidade: number }[] };
    assert.equal(conta.tipo, 'conta_pagar');
    assert.equal(conta.condicao_pagamento, '30_dias');
    assert.equal(conta.chave_idempotencia, `compras-recebimento-${r1.valor.id}`);
    assert.equal(ev.dados.total_centavos, 6 * 2590);
    assert.equal(m.precos.linhas.filter((l) => l.origem === 'recebimento').length, 1);

    const excedida = await m.receber.execute(ctx, { pedido_id: id, deposito_id: DEPOSITO, itens: [{ item_id: itens[0]!.id, quantidade: 5 }] });
    assert.ok(!excedida.ok);
    assert.equal(excedida.erros[0]!.codigo, 'quantidade_excedida');
    assert.equal(excedida.erros[0]!.meta?.pendente, 4);

    const r2 = await m.receber.execute(ctx, { pedido_id: id, deposito_id: DEPOSITO });
    assert.ok(r2.ok);
    assert.equal(r2.valor.tipo, 'total');
    const final = (await m.docs.obterPorId(id))!;
    assert.equal(final.estado, 'recebido');
    assert.deepEqual(final.paraDados().itens.map((i) => i.quantidade_recebida), [10, 4]);
    assert.equal(m.recs.linhas[1]!.itens.length, 2);
    const cancelar = await m.mudar.execute(ctx, { id, estado: 'cancelado' });
    assert.equal(!cancelar.ok && cancelar.erros[0]!.codigo, 'transicao_invalida');
    const fechado = await m.receber.execute(ctx, { pedido_id: id, deposito_id: DEPOSITO });
    assert.equal(!fechado.ok && fechado.erros[0]!.codigo, 'transicao_invalida');
  });

  it('pedido nao confirmado, item estranho, deposito obrigatorio e invalido, pedido inexistente', async () => {
    const m = montar();
    const ctx = contexto();
    const rasc = await m.criar.execute(ctx, { tipo: 'pedido', fornecedor_id: F1, itens: itensPadrao() });
    assert.ok(rasc.ok);
    const naoConf = await m.receber.execute(ctx, { pedido_id: rasc.valor.id, deposito_id: DEPOSITO });
    assert.equal(!naoConf.ok && naoConf.erros[0]!.codigo, 'transicao_invalida');
    const id = await pedidoConfirmado(m);
    const estranho = await m.receber.execute(ctx, { pedido_id: id, deposito_id: DEPOSITO, itens: [{ item_id: F1, quantidade: 1 }] });
    assert.equal(!estranho.ok && estranho.erros[0]!.codigo, 'item_invalido');
    const semDeposito = await m.receber.execute(ctx, { pedido_id: id });
    assert.equal(!semDeposito.ok && semDeposito.erros[0]!.codigo, 'deposito_obrigatorio');
    const depositoRuim = await m.receber.execute(ctx, { pedido_id: id, deposito_id: F2 });
    assert.equal(!depositoRuim.ok && depositoRuim.erros[0]!.codigo, 'deposito_invalido');
    const nf = await m.receber.execute(ctx, { pedido_id: F2 });
    assert.equal(!nf.ok && nf.erros[0]!.codigo, 'nao_encontrado');
    assert.equal(m.recs.linhas.length, 0);
  });
});

describe('reacao estoque.abaixo_minimo', () => {
  it('abre requisicao de reposicao uma vez por alerta e nao duplica a do mesmo produto', async () => {
    const m = montar();
    const ctx = contexto();
    const alerta = { alerta_id: '50000000-0000-4000-8000-000000000001', produto_id: PRODUTO_A, sku: 'PAP-A4', saldo: 2, estoque_minimo: 10, sugestao_compra: 18 };
    const r = await m.reposicao.execute(ctx, alerta);
    assert.ok(r.ok);
    assert.equal(r.valor.criada, true);
    const d = (await m.docs.obterPorId(r.valor.id!))!.paraDados();
    assert.equal(d.origem, 'reposicao');
    assert.equal(d.itens[0]!.quantidade, 18);
    assert.equal(d.itens[0]!.descricao, 'Papel A4 500 folhas');
    const repetido = await m.reposicao.execute(ctx, alerta);
    assert.ok(repetido.ok);
    assert.deepEqual(repetido.valor, { id: r.valor.id, criada: false });
    const outroAlerta = await m.reposicao.execute(ctx, { ...alerta, alerta_id: '50000000-0000-4000-8000-000000000002' });
    assert.ok(outroAlerta.ok);
    assert.equal(outroAlerta.valor.criada, false);
    assert.equal([...m.docs.linhas.values()].length, 1);
  });

  it('produto arquivado depois do alerta encerra sem erro e sem requisicao', async () => {
    const m = montar();
    const alerta = { alerta_id: '50000000-0000-4000-8000-000000000009', produto_id: '50000000-0000-4000-8000-0000000000ff', saldo: 0, estoque_minimo: 5 };
    const r = await m.reposicao.execute(contexto(), alerta);
    assert.ok(r.ok);
    assert.deepEqual(r.valor, { id: null, criada: false });
    assert.equal([...m.docs.linhas.values()].length, 0);
  });
});
