/**
 * Repositorios em memoria das portas do Compras e porta Efeitos que grava o que foi publicado.
 * Os casos de uso rodam aqui sem banco, sem Fastify e sem o SDK (P3).
 */
import type { ContextoCaso, Efeitos } from '../api/compartilhado/efeitos.ts';
import { DocumentoCompra, type DocumentoDados } from '../api/documento/model/documento.ts';
import type {
  BuscarDocumentoPorOrigem, ConsultarReferenciasDocumento, ExcluirDocumento, FornecedorCompra, GravarDocumento, HistoricoPrecos,
  ListarCotacoesIrmas, Numeracao, ObterDocumento, RegistroPreco,
} from '../api/documento/model/portas.ts';
import { Fornecedor, type FornecedorDados } from '../api/fornecedor/model/fornecedor.ts';
import type { BuscarFornecedorPorParceiro, ConsultarParceiros, ContarDocumentosAbertos, GravarFornecedor, ObterFornecedor } from '../api/fornecedor/model/portas.ts';
import type { ConsultarReferenciasRecebimento, GravarRecebimento } from '../api/recebimento/model/portas.ts';
import type { Recebimento, RecebimentoDados } from '../api/recebimento/model/recebimento.ts';

export class EfeitosMemoria implements Efeitos {
  auditoria: { acao: string; entidade: string; id: string | null }[] = [];
  eventos: { evento: string; dados: Record<string, unknown> }[] = [];
  historicos: { entidade: string; id: string; antes: unknown; depois: unknown }[] = [];
  notas: { entidade: string; id: string; corpo: string }[] = [];
  async auditar(acao: string, entidade: string, id: string | null) { this.auditoria.push({ acao, entidade, id }); }
  async publicar(evento: string, dados: Record<string, unknown>) { this.eventos.push({ evento, dados }); }
  async historico(entidade: string, id: string, antes: unknown, depois: unknown) { this.historicos.push({ entidade, id, antes, depois }); }
  async nota(entidade: string, id: string, corpo: string) { this.notas.push({ entidade, id, corpo }); }
}

export function contexto(): ContextoCaso & { efeitos: EfeitosMemoria } {
  return { ator: { tipo: 'usuario', id: '00000000-0000-4000-8000-000000000001' }, efeitos: new EfeitosMemoria() };
}

export const PARCEIRO = '10000000-0000-4000-8000-000000000001';
export const PARCEIRO_2 = '10000000-0000-4000-8000-000000000002';
export const PRODUTO_A = '20000000-0000-4000-8000-00000000000a';
export const PRODUTO_B = '20000000-0000-4000-8000-00000000000b';
export const DEPOSITO = '30000000-0000-4000-8000-000000000001';

export class FornecedoresMemoria implements ObterFornecedor, BuscarFornecedorPorParceiro, GravarFornecedor, ConsultarParceiros, ContarDocumentosAbertos {
  linhas = new Map<string, FornecedorDados>();
  parceiros = new Map<string, { id: string; nome: string; e_fornecedor: boolean }>([
    [PARCEIRO, { id: PARCEIRO, nome: 'Papelaria Central', e_fornecedor: true }],
    [PARCEIRO_2, { id: PARCEIRO_2, nome: 'Nuvem Segura', e_fornecedor: true }],
  ]);
  abertos = new Map<string, number>();
  async obterPorId(id: string) { const d = this.linhas.get(id); return d ? Fornecedor.reidratar(d) : null; }
  async buscarPorParceiro(p: string) { const d = [...this.linhas.values()].find((x) => x.parceiro_id === p); return d ? Fornecedor.reidratar(d) : null; }
  async inserir(f: Fornecedor) { this.linhas.set(f.id, f.paraDados()); }
  async atualizar(f: Fornecedor) { this.linhas.set(f.id, f.paraDados()); }
  async parceiroAtivo(id: string) { return this.parceiros.get(id) ?? null; }
  async documentosAbertos(id: string) { return this.abertos.get(id) ?? 0; }
}

export class DocumentosMemoria implements ObterDocumento, GravarDocumento, ExcluirDocumento, BuscarDocumentoPorOrigem, ListarCotacoesIrmas,
  ConsultarReferenciasDocumento, Numeracao {
  linhas = new Map<string, DocumentoDados & { deleted: boolean }>();
  fornecedores = new Map<string, FornecedorCompra>();
  produtos = new Map<string, { id: string; nome: string; unidade: string }>([
    [PRODUTO_A, { id: PRODUTO_A, nome: 'Papel A4 500 folhas', unidade: 'CX' }],
    [PRODUTO_B, { id: PRODUTO_B, nome: 'Toner preto', unidade: 'UN' }],
  ]);
  seq = new Map<string, number>();

  private vivo(fn: (d: DocumentoDados) => boolean) {
    const l = [...this.linhas.values()].find((x) => !x.deleted && fn(x));
    return l ? DocumentoCompra.reidratar(l) : null;
  }
  async obterPorId(id: string) { return this.vivo((d) => d.id === id); }
  async buscarPorOrigemRef(ref: string) { return this.vivo((d) => d.origem_ref === ref); }
  async requisicaoReposicaoAberta(produtoId: string) {
    return [...this.linhas.values()].some((d) => !d.deleted && d.tipo === 'requisicao' && d.origem === 'reposicao'
      && ['rascunho', 'enviado'].includes(d.estado) && d.itens.some((i) => i.produto_id === produtoId));
  }
  async cotacoesAbertas(req: string, exceto: string) {
    return [...this.linhas.values()].filter((d) => !d.deleted && d.tipo === 'cotacao' && d.origem_id === req && d.id !== exceto
      && ['rascunho', 'enviado'].includes(d.estado)).map((d) => DocumentoCompra.reidratar(d));
  }
  async inserir(d: DocumentoCompra) {
    const x = d.paraDados();
    if ([...this.linhas.values()].some((l) => !l.deleted && l.tipo === x.tipo && l.numero === x.numero)) throw Object.assign(new Error('duplicado'), { code: '23505' });
    this.linhas.set(x.id, { ...x, deleted: false });
  }
  async atualizar(d: DocumentoCompra) { this.linhas.set(d.id, { ...d.paraDados(), deleted: false }); }
  async excluir(id: string) { const l = this.linhas.get(id); if (l) l.deleted = true; }
  async fornecedorAtivo(id: string) { return this.fornecedores.get(id) ?? null; }
  async produtosAtivos(ids: string[]) { return ids.map((i) => this.produtos.get(i)).filter((x): x is { id: string; nome: string; unidade: string } => !!x); }
  async proximoNumero(codigo: string) {
    const n = (this.seq.get(codigo) ?? 0) + 1;
    this.seq.set(codigo, n);
    return `${codigo.toUpperCase()}-${String(n).padStart(4, '0')}`;
  }
}

export class PrecosMemoria implements HistoricoPrecos {
  linhas: RegistroPreco[] = [];
  async registrarPrecos(l: RegistroPreco[]) { this.linhas.push(...l); }
  async ultimosPrecos(fornecedorId: string, ids: string[]) {
    const m = new Map<string, number>();
    for (const l of this.linhas) if (l.fornecedor_id === fornecedorId && ids.includes(l.produto_id)) m.set(l.produto_id, l.preco_unitario_centavos);
    return m;
  }
}

export class RecebimentosMemoria implements GravarRecebimento, ConsultarReferenciasRecebimento {
  linhas: RecebimentoDados[] = [];
  depositos = new Set([DEPOSITO]);
  constructor(private readonly docs: DocumentosMemoria) {}
  async inserir(r: Recebimento) { this.linhas.push(r.paraDados()); }
  async depositoAtivo(id: string) { return this.depositos.has(id); }
  async fornecedorDoPedido(id: string) { return this.docs.fornecedores.get(id) ?? null; }
}
