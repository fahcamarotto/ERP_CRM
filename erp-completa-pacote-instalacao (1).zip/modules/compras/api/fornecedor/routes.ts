/** Rotas REST do Fornecedor fora das tools: ficha, edicao, arquivar ou reativar e parceiros disponiveis. */
import { esquemaErro, requer, type FastifyInstance } from '@erp/api/sdk';
import { naTransacao, naoEncontrado } from '../borda.ts';
import { exigirOk } from '../compartilhado/result.ts';
import { propsFornecedor, uuid } from '../esquemas.ts';
import type { DadosFornecedor, EstadoFornecedor } from './model/fornecedor.ts';
import { obterFornecedor, parceirosDisponiveis } from './query/fornecedores.ts';

const tags = ['compras'];
const paramId = { type: 'object', required: ['id'], properties: { id: uuid } } as const;
const { parceiro_id: _parceiro, ...propsEdicao } = propsFornecedor;

export function rotasFornecedor(app: FastifyInstance): void {
  app.get('/parceiros-disponiveis', {
    preHandler: requer('compras.ver'),
    schema: { tags, summary: 'Parceiros do Cadastros marcados como fornecedor e ainda fora de Compras' },
  }, (req) => naTransacao(req, (_, __, c) => parceirosDisponiveis(c)));

  app.get<{ Params: { id: string } }>('/fornecedores/:id', {
    preHandler: requer('compras.ver'),
    schema: { tags, summary: 'Ficha do fornecedor com historico de preco por produto e ultimos documentos', params: paramId, response: { 404: esquemaErro } },
  }, (req) => naTransacao(req, async (_, __, c) => (await obterFornecedor(c, req.params.id)) ?? Promise.reject(naoEncontrado('Fornecedor nao encontrado'))));

  app.patch<{ Params: { id: string }; Body: Partial<Omit<DadosFornecedor, 'parceiro_id'>> }>('/fornecedores/:id', {
    preHandler: requer('compras.editar'),
    schema: {
      tags, summary: 'Edita condicao de pagamento, prazo e pedido minimo (EditarFornecedor)', params: paramId,
      body: { type: 'object', additionalProperties: false, properties: propsEdicao },
      response: { 400: esquemaErro, 404: esquemaErro, 409: esquemaErro },
    },
  }, (req) => naTransacao(req, async (casos, ctx, c) => {
    exigirOk(await casos.editarFornecedor.execute(ctx, { ...req.body, id: req.params.id }));
    return obterFornecedor(c, req.params.id);
  }));

  app.post<{ Params: { id: string }; Body: { estado: EstadoFornecedor } }>('/fornecedores/:id/estado', {
    preHandler: requer('compras.editar'),
    schema: {
      tags, summary: 'Arquiva ou reativa o fornecedor (MudarEstadoFornecedor)', params: paramId,
      body: { type: 'object', additionalProperties: false, required: ['estado'], properties: { estado: { type: 'string', enum: ['ativo', 'arquivado'] } } },
      response: { 400: esquemaErro, 404: esquemaErro, 409: esquemaErro },
    },
  }, (req) => naTransacao(req, async (casos, ctx, c) => {
    exigirOk(await casos.mudarEstadoFornecedor.execute(ctx, { id: req.params.id, estado: req.body.estado }));
    return obterFornecedor(c, req.params.id);
  }));
}
