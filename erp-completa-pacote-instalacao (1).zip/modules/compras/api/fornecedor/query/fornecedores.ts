/** Consultas de leitura do Fornecedor: lista com nome do parceiro e ficha com historico de preco e pedidos. */
import type pg from 'pg';
import { decodificarCursor, pagina } from '../../compartilhado/cursor.ts';

const RESUMO = `f.id, f.parceiro_id, p.nome AS nome, p.nome_fantasia, p.documento, p.email, p.telefone,
  f.condicao_pagamento, f.prazo_entrega_dias, f.pedido_minimo_centavos::float8 AS pedido_minimo_centavos, f.observacoes, f.estado,
  f.created_at, f.updated_at,
  (SELECT count(*)::int FROM compras_documentos d WHERE d.fornecedor_id = f.id AND d.tipo = 'pedido' AND d.deleted_at IS NULL) AS qtd_pedidos,
  (SELECT coalesce(sum(d.total_centavos), 0)::float8 FROM compras_documentos d WHERE d.fornecedor_id = f.id AND d.tipo = 'pedido'
     AND d.estado IN ('confirmado', 'recebido') AND d.deleted_at IS NULL) AS total_comprado_centavos`;

const JUNCOES = `FROM compras_fornecedores f LEFT JOIN cadastros_parceiros p ON p.id = f.parceiro_id`;

export interface FiltroFornecedores {
  estado?: 'ativo' | 'arquivado' | 'todos';
  busca?: string;
  limite?: number;
  cursor?: string;
}

export async function listarFornecedores(c: pg.PoolClient, f: FiltroFornecedores) {
  const lim = Math.min(Math.max(f.limite ?? 50, 1), 200);
  const cur = decodificarCursor(f.cursor);
  const estado = f.estado === 'todos' ? null : (f.estado ?? 'ativo');
  const r = await c.query(
    `SELECT ${RESUMO} ${JUNCOES}
     WHERE f.deleted_at IS NULL AND ($1::text IS NULL OR f.estado = $1)
       AND ($2::text IS NULL OR p.nome ILIKE '%' || $2 || '%' OR p.nome_fantasia ILIKE '%' || $2 || '%' OR p.documento LIKE '%' || $2 || '%')
       AND ($3::timestamptz IS NULL OR (f.created_at, f.id) > ($3::timestamptz, $4::uuid))
     ORDER BY f.created_at, f.id LIMIT $5`,
    [estado, f.busca?.trim() || null, cur?.[0] ?? null, cur?.[1] ?? null, lim + 1],
  );
  return pagina(r.rows, lim);
}

export async function obterFornecedor(c: pg.PoolClient, id: string) {
  const r = await c.query(`SELECT ${RESUMO}, f.extras ${JUNCOES} WHERE f.id = $1 AND f.deleted_at IS NULL`, [id]);
  const f = r.rows[0];
  if (!f) return null;
  const docs = await c.query(
    `SELECT id, tipo, numero, estado, total_centavos::float8 AS total_centavos, moeda, to_char(previsao_entrega, 'YYYY-MM-DD') AS previsao_entrega, created_at
     FROM compras_documentos WHERE fornecedor_id = $1 AND tipo <> 'requisicao' AND deleted_at IS NULL ORDER BY created_at DESC LIMIT 20`, [id]);
  const precos = await c.query(
    `SELECT pr.produto_id, ep.sku, ep.nome AS produto_nome, ep.unidade,
       (array_agg(pr.preco_unitario_centavos ORDER BY pr.data DESC, pr.created_at DESC))[1]::float8 AS ultimo_centavos,
       min(pr.preco_unitario_centavos)::float8 AS minimo_centavos, max(pr.preco_unitario_centavos)::float8 AS maximo_centavos,
       round(avg(pr.preco_unitario_centavos))::float8 AS medio_centavos, count(*)::int AS registros,
       to_char(max(pr.data), 'YYYY-MM-DD') AS ultima_data
     FROM compras_precos pr LEFT JOIN estoque_produtos ep ON ep.id = pr.produto_id
     WHERE pr.fornecedor_id = $1 AND pr.deleted_at IS NULL GROUP BY pr.produto_id, ep.sku, ep.nome, ep.unidade ORDER BY ep.nome`, [id]);
  return { ...f, documentos: docs.rows, precos: precos.rows };
}

/** Parceiros do Cadastros marcados como fornecedor e ainda sem cadastro em Compras (seletor do formulario). */
export async function parceirosDisponiveis(c: pg.PoolClient) {
  return (await c.query(
    `SELECT p.id, coalesce(p.nome_fantasia, p.nome) AS nome, p.documento FROM cadastros_parceiros p
     WHERE p.e_fornecedor AND p.estado = 'ativo' AND p.deleted_at IS NULL
       AND NOT EXISTS (SELECT 1 FROM compras_fornecedores f WHERE f.parceiro_id = p.id AND f.deleted_at IS NULL)
     ORDER BY p.nome LIMIT 200`)).rows;
}
