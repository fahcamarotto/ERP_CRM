/**
 * Entidade Fornecedor (M10.2): parceiro do Cadastros com condicao de pagamento, prazo de entrega
 * e pedido minimo. Imutavel: toda alteracao devolve um clone novo.
 */
import { randomUUID } from 'node:crypto';
import { erroDe, fail, ok, type ErroDominio, type Result } from '../../compartilhado/result.ts';

/** Condicoes aceitas (as mesmas chaves de `condicao_pagamento` de Contas, CONTRATOS 7.1.5). */
export const CONDICOES_PAGAMENTO = ['a_vista', '7_dias', '15_dias', '30_dias', '45_dias', '60_dias', '90_dias'] as const;
export type CondicaoPagamento = (typeof CONDICOES_PAGAMENTO)[number];
export const DIAS_CONDICAO: Record<CondicaoPagamento, number> = {
  a_vista: 0, '7_dias': 7, '15_dias': 15, '30_dias': 30, '45_dias': 45, '60_dias': 60, '90_dias': 90,
};

export const ESTADOS_FORNECEDOR = ['ativo', 'arquivado'] as const;
export type EstadoFornecedor = (typeof ESTADOS_FORNECEDOR)[number];

export interface DadosFornecedor {
  parceiro_id: string;
  condicao_pagamento?: CondicaoPagamento;
  prazo_entrega_dias?: number;
  pedido_minimo_centavos?: number;
  observacoes?: string | null;
  extras?: Record<string, unknown>;
}

export interface FornecedorDados {
  id: string;
  parceiro_id: string;
  condicao_pagamento: CondicaoPagamento;
  prazo_entrega_dias: number;
  pedido_minimo_centavos: number;
  observacoes: string | null;
  estado: EstadoFornecedor;
  extras: Record<string, unknown>;
}

const t = (v?: string | null) => (v ?? '').trim() || null;

function validar(d: FornecedorDados): ErroDominio[] {
  const e: ErroDominio[] = [];
  if (!/^[0-9a-f-]{36}$/i.test(d.parceiro_id)) e.push(erroDe('parceiro_invalido', 'Parceiro obrigatorio', 'parceiro_id'));
  if (!CONDICOES_PAGAMENTO.includes(d.condicao_pagamento)) {
    e.push(erroDe('condicao_invalida', 'Condicao de pagamento invalida', 'condicao_pagamento', { aceitas: CONDICOES_PAGAMENTO }));
  }
  if (!Number.isInteger(d.prazo_entrega_dias) || d.prazo_entrega_dias < 0 || d.prazo_entrega_dias > 365) {
    e.push(erroDe('prazo_invalido', 'Prazo de entrega em dias inteiros de 0 a 365', 'prazo_entrega_dias'));
  }
  if (!Number.isInteger(d.pedido_minimo_centavos) || d.pedido_minimo_centavos < 0) {
    e.push(erroDe('valor_invalido', 'Pedido minimo em centavos inteiros, zero ou positivo', 'pedido_minimo_centavos'));
  }
  if (d.observacoes && d.observacoes.length > 2000) e.push(erroDe('texto_longo', 'Observacoes com ate 2000 caracteres', 'observacoes'));
  return e;
}

export class Fornecedor {
  private constructor(private readonly d: FornecedorDados) {}

  static tryCreate(e: DadosFornecedor, id: string = randomUUID()): Result<Fornecedor> {
    const d: FornecedorDados = {
      id, parceiro_id: (e.parceiro_id ?? '').trim(), condicao_pagamento: e.condicao_pagamento ?? '30_dias',
      prazo_entrega_dias: e.prazo_entrega_dias ?? 7, pedido_minimo_centavos: e.pedido_minimo_centavos ?? 0,
      observacoes: t(e.observacoes), estado: 'ativo', extras: e.extras ?? {},
    };
    const erros = validar(d);
    return erros.length ? fail(...erros) : ok(new Fornecedor(d));
  }

  static create(e: DadosFornecedor, id?: string): Fornecedor {
    const r = Fornecedor.tryCreate(e, id);
    if (!r.ok) throw new Error(r.erros.map((x) => x.mensagem).join('; '));
    return r.valor;
  }

  static reidratar(d: FornecedorDados): Fornecedor {
    return new Fornecedor({ ...d, extras: { ...d.extras } });
  }

  get id(): string { return this.d.id; }
  get parceiroId(): string { return this.d.parceiro_id; }
  get estado(): EstadoFornecedor { return this.d.estado; }
  get condicao(): CondicaoPagamento { return this.d.condicao_pagamento; }
  get prazoEntregaDias(): number { return this.d.prazo_entrega_dias; }

  editar(e: Partial<Omit<DadosFornecedor, 'parceiro_id'>>): Result<Fornecedor> {
    if (this.d.estado === 'arquivado') return fail(erroDe('transicao_invalida', 'Fornecedor arquivado nao pode ser editado; reative antes'));
    const tem = (k: keyof typeof e) => e[k] !== undefined;
    const n: FornecedorDados = {
      ...this.d,
      condicao_pagamento: tem('condicao_pagamento') ? e.condicao_pagamento! : this.d.condicao_pagamento,
      prazo_entrega_dias: tem('prazo_entrega_dias') ? e.prazo_entrega_dias! : this.d.prazo_entrega_dias,
      pedido_minimo_centavos: tem('pedido_minimo_centavos') ? e.pedido_minimo_centavos! : this.d.pedido_minimo_centavos,
      observacoes: tem('observacoes') ? t(e.observacoes) : this.d.observacoes,
      extras: tem('extras') ? { ...e.extras } : { ...this.d.extras },
    };
    const erros = validar(n);
    return erros.length ? fail(...erros) : ok(new Fornecedor(n));
  }

  mudarEstado(novo: EstadoFornecedor): Result<Fornecedor> {
    if (!ESTADOS_FORNECEDOR.includes(novo)) return fail(erroDe('estado_invalido', 'Estado invalido', 'estado'));
    if (novo === this.d.estado) return fail(erroDe('transicao_invalida', `Fornecedor ja esta ${novo}`, 'estado'));
    return ok(new Fornecedor({ ...this.d, estado: novo }));
  }

  /** Reaponta o parceiro (parceiro.mesclado no Cadastros). */
  reapontar(parceiroId: string): Fornecedor {
    return new Fornecedor({ ...this.d, parceiro_id: parceiroId });
  }

  paraDados(): FornecedorDados {
    return { ...this.d, extras: { ...this.d.extras } };
  }
}
