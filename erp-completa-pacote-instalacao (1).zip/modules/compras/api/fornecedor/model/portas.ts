/** Portas do repositorio do agregado Fornecedor, segregadas por operacao. */
import type { Fornecedor } from './fornecedor.ts';

export interface ObterFornecedor {
  obterPorId(id: string): Promise<Fornecedor | null>;
}

export interface BuscarFornecedorPorParceiro {
  buscarPorParceiro(parceiroId: string): Promise<Fornecedor | null>;
}

export interface GravarFornecedor {
  inserir(f: Fornecedor): Promise<void>;
  atualizar(f: Fornecedor): Promise<void>;
}

/** Referencia fora do agregado: parceiro ativo do Cadastros (tabela publicada cadastros_parceiros). */
export interface ConsultarParceiros {
  parceiroAtivo(id: string): Promise<{ id: string; nome: string; e_fornecedor: boolean } | null>;
}

/** Documentos em aberto do fornecedor (impede arquivar com pedido em andamento). */
export interface ContarDocumentosAbertos {
  documentosAbertos(fornecedorId: string): Promise<number>;
}
