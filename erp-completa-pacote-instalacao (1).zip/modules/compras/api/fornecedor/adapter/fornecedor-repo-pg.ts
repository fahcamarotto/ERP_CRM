/** Adaptador Postgres das portas do Fornecedor (RLS restringe ao workspace da sessao). */
import type pg from 'pg';
import { Fornecedor, type FornecedorDados } from '../model/fornecedor.ts';
import type { BuscarFornecedorPorParceiro, ConsultarParceiros, ContarDocumentosAbertos, GravarFornecedor, ObterFornecedor } from '../model/portas.ts';

const COLUNAS = `id, parceiro_id, condicao_pagamento, prazo_entrega_dias, pedido_minimo_centavos::float8 AS pedido_minimo_centavos,
  observacoes, estado, extras`;

export class FornecedorRepoPg implements ObterFornecedor, BuscarFornecedorPorParceiro, GravarFornecedor, ConsultarParceiros, ContarDocumentosAbertos {
  constructor(private readonly c: pg.PoolClient) {}

  async obterPorId(id: string): Promise<Fornecedor | null> {
    const r = await this.c.query(`SELECT ${COLUNAS} FROM compras_fornecedores WHERE id = $1 AND deleted_at IS NULL`, [id]);
    return r.rows[0] ? Fornecedor.reidratar(r.rows[0] as FornecedorDados) : null;
  }

  async buscarPorParceiro(parceiroId: string): Promise<Fornecedor | null> {
    const r = await this.c.query(`SELECT ${COLUNAS} FROM compras_fornecedores WHERE parceiro_id = $1 AND deleted_at IS NULL`, [parceiroId]);
    return r.rows[0] ? Fornecedor.reidratar(r.rows[0] as FornecedorDados) : null;
  }

  async inserir(f: Fornecedor): Promise<void> {
    const d = f.paraDados();
    await this.c.query(
      `INSERT INTO compras_fornecedores (id, parceiro_id, condicao_pagamento, prazo_entrega_dias, pedido_minimo_centavos, observacoes, estado, extras, creator_id)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, nucleo_usuario_atual())`,
      [d.id, d.parceiro_id, d.condicao_pagamento, d.prazo_entrega_dias, d.pedido_minimo_centavos, d.observacoes, d.estado, JSON.stringify(d.extras)],
    );
  }

  async atualizar(f: Fornecedor): Promise<void> {
    const d = f.paraDados();
    await this.c.query(
      `UPDATE compras_fornecedores SET parceiro_id = $2, condicao_pagamento = $3, prazo_entrega_dias = $4, pedido_minimo_centavos = $5,
         observacoes = $6, estado = $7, extras = $8 WHERE id = $1 AND deleted_at IS NULL`,
      [d.id, d.parceiro_id, d.condicao_pagamento, d.prazo_entrega_dias, d.pedido_minimo_centavos, d.observacoes, d.estado, JSON.stringify(d.extras)],
    );
  }

  /** Leitura da tabela publicada cadastros_parceiros (CONTRATOS 7.1.1). */
  async parceiroAtivo(id: string) {
    const r = await this.c.query(
      "SELECT id, nome, e_fornecedor FROM cadastros_parceiros WHERE id = $1 AND estado = 'ativo' AND deleted_at IS NULL", [id]);
    return r.rows[0] ?? null;
  }

  async documentosAbertos(fornecedorId: string): Promise<number> {
    const r = await this.c.query(
      `SELECT count(*)::int AS n FROM compras_documentos WHERE fornecedor_id = $1 AND estado IN ('rascunho', 'enviado', 'confirmado')
         AND tipo <> 'requisicao' AND deleted_at IS NULL`, [fornecedorId]);
    return r.rows[0].n as number;
  }
}
