/** Casos de uso do Fornecedor (M10.2): CriarFornecedor, EditarFornecedor, MudarEstadoFornecedor e ReapontarParceiro. */
import { erroDe, fail, ok, okVazio, type Result } from '../../compartilhado/result.ts';
import type { ContextoCaso } from '../../compartilhado/efeitos.ts';
import { Fornecedor, type DadosFornecedor, type EstadoFornecedor } from '../model/fornecedor.ts';
import type { BuscarFornecedorPorParceiro, ConsultarParceiros, ContarDocumentosAbertos, GravarFornecedor, ObterFornecedor } from '../model/portas.ts';

const TABELA = 'compras_fornecedores';

export class CriarFornecedor {
  constructor(private readonly deps: { repo: ObterFornecedor & BuscarFornecedorPorParceiro & GravarFornecedor; parceiros: ConsultarParceiros }) {}

  async execute(ctx: ContextoCaso, e: DadosFornecedor): Promise<Result<{ id: string }>> {
    const r = Fornecedor.tryCreate(e);
    if (!r.ok) return r;
    const parceiro = await this.deps.parceiros.parceiroAtivo(r.valor.parceiroId);
    if (!parceiro) return fail(erroDe('parceiro_invalido', 'Parceiro nao encontrado ou arquivado no Cadastros', 'parceiro_id'));
    const existente = await this.deps.repo.buscarPorParceiro(r.valor.parceiroId);
    if (existente) return fail(erroDe('conflito', 'Este parceiro ja e fornecedor em Compras', 'parceiro_id', { fornecedor_id: existente.id }));
    await this.deps.repo.inserir(r.valor);
    const d = r.valor.paraDados();
    await ctx.efeitos.auditar('fornecedor.criar', TABELA, d.id, undefined, d);
    return ok({ id: d.id });
  }
}

export class EditarFornecedor {
  constructor(private readonly deps: { repo: ObterFornecedor & GravarFornecedor }) {}

  async execute(ctx: ContextoCaso, e: { id: string } & Partial<Omit<DadosFornecedor, 'parceiro_id'>>): Promise<Result<void>> {
    const { id, ...mud } = e;
    const atual = await this.deps.repo.obterPorId(id);
    if (!atual) return fail(erroDe('nao_encontrado', 'Fornecedor nao encontrado'));
    const r = atual.editar(mud);
    if (!r.ok) return r;
    await this.deps.repo.atualizar(r.valor);
    const antes = atual.paraDados() as unknown as Record<string, unknown>;
    const depois = r.valor.paraDados() as unknown as Record<string, unknown>;
    await ctx.efeitos.historico(TABELA, id, antes, depois);
    await ctx.efeitos.auditar('fornecedor.editar', TABELA, id, antes, depois);
    return okVazio();
  }
}

export class MudarEstadoFornecedor {
  constructor(private readonly deps: { repo: ObterFornecedor & GravarFornecedor; abertos: ContarDocumentosAbertos }) {}

  async execute(ctx: ContextoCaso, e: { id: string; estado: EstadoFornecedor }): Promise<Result<void>> {
    const atual = await this.deps.repo.obterPorId(e.id);
    if (!atual) return fail(erroDe('nao_encontrado', 'Fornecedor nao encontrado'));
    const r = atual.mudarEstado(e.estado);
    if (!r.ok) return r;
    if (e.estado === 'arquivado') {
      const n = await this.deps.abertos.documentosAbertos(e.id);
      if (n > 0) return fail(erroDe('conflito', `Fornecedor com ${n} cotacao(oes) ou pedido(s) em aberto`, 'estado', { abertos: n }));
    }
    await this.deps.repo.atualizar(r.valor);
    await ctx.efeitos.historico(TABELA, e.id, { estado: atual.estado }, { estado: r.valor.estado });
    await ctx.efeitos.auditar('fornecedor.mudar_estado', TABELA, e.id, { estado: atual.estado }, { estado: r.valor.estado });
    return okVazio();
  }
}

/** Reacao a parceiro.mesclado (Cadastros): reaponta para o mantido; se o mantido ja e fornecedor, arquiva o removido. */
export class ReapontarParceiro {
  constructor(private readonly deps: { repo: BuscarFornecedorPorParceiro & GravarFornecedor }) {}

  async execute(ctx: ContextoCaso, e: { mantido_id: string; removidos_ids: string[] }): Promise<Result<{ reapontados: number; arquivados: number }>> {
    let reapontados = 0;
    let arquivados = 0;
    for (const removido of e.removidos_ids) {
      const f = await this.deps.repo.buscarPorParceiro(removido);
      if (!f) continue;
      const jaExiste = await this.deps.repo.buscarPorParceiro(e.mantido_id);
      if (jaExiste) {
        const r = f.estado === 'arquivado' ? null : f.mudarEstado('arquivado');
        if (r?.ok) { await this.deps.repo.atualizar(r.valor); arquivados++; }
      } else {
        await this.deps.repo.atualizar(f.reapontar(e.mantido_id));
        reapontados++;
      }
      await ctx.efeitos.auditar('fornecedor.reapontar', TABELA, f.id, { parceiro_id: removido }, { parceiro_id: e.mantido_id });
    }
    return ok({ reapontados, arquivados });
  }
}
