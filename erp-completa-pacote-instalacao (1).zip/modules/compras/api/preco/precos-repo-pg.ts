/** Historico de preco por produto e fornecedor (M10.4): adaptador da porta HistoricoPrecos e consultas. */
import type pg from 'pg';
import { decodificarCursor, pagina } from '../compartilhado/cursor.ts';
import type { HistoricoPrecos, RegistroPreco } from '../documento/model/portas.ts';

export class PrecosRepoPg implements HistoricoPrecos {
  constructor(private readonly c: pg.PoolClient) {}

  async registrarPrecos(lista: RegistroPreco[]): Promise<void> {
    if (!lista.length) return;
    await this.c.query(
      `INSERT INTO compras_precos (produto_id, fornecedor_id, preco_unitario_centavos, moeda, origem, documento_id, data, creator_id)
       SELECT x.produto_id, x.fornecedor_id, x.preco_unitario_centavos, x.moeda, x.origem, x.documento_id, x.data, nucleo_usuario_atual()
       FROM jsonb_to_recordset($1::jsonb) AS x(produto_id uuid, fornecedor_id uuid, preco_unitario_centavos bigint, moeda text, origem text, documento_id uuid, data date)
       ON CONFLICT (tenant_id, workspace_id, documento_id, produto_id, origem) WHERE deleted_at IS NULL
       DO UPDATE SET preco_unitario_centavos = EXCLUDED.preco_unitario_centavos, data = EXCLUDED.data`,
      [JSON.stringify(lista)],
    );
  }

  async ultimosPrecos(fornecedorId: string, produtoIds: string[]): Promise<Map<string, number>> {
    const r = await this.c.query(
      `SELECT DISTINCT ON (produto_id) produto_id, preco_unitario_centavos::float8 AS preco FROM compras_precos
       WHERE fornecedor_id = $1 AND produto_id = ANY ($2::uuid[]) AND deleted_at IS NULL ORDER BY produto_id, data DESC, created_at DESC`,
      [fornecedorId, produtoIds]);
    return new Map(r.rows.map((x) => [x.produto_id as string, x.preco as number]));
  }
}

export interface FiltroPrecos {
  produto_id?: string;
  fornecedor_id?: string;
  limite?: number;
  cursor?: string;
}

/** Linhas do historico com produto e fornecedor, mais o resumo (ultimo, minimo, medio, maximo) do filtro. */
export async function historicoPrecos(c: pg.PoolClient, f: FiltroPrecos) {
  const lim = Math.min(Math.max(f.limite ?? 50, 1), 200);
  const cur = decodificarCursor(f.cursor);
  const args = [f.produto_id ?? null, f.fornecedor_id ?? null];
  const filtro = `pr.deleted_at IS NULL AND ($1::uuid IS NULL OR pr.produto_id = $1) AND ($2::uuid IS NULL OR pr.fornecedor_id = $2)`;
  const r = await c.query(
    `SELECT pr.id, pr.produto_id, ep.sku, ep.nome AS produto_nome, pr.fornecedor_id, coalesce(p.nome_fantasia, p.nome) AS fornecedor_nome,
       pr.preco_unitario_centavos::float8 AS preco_unitario_centavos, pr.moeda, pr.origem, pr.documento_id,
       coalesce(d.numero, rc.numero) AS documento_numero, to_char(pr.data, 'YYYY-MM-DD') AS data, pr.created_at
     FROM compras_precos pr
     LEFT JOIN estoque_produtos ep ON ep.id = pr.produto_id
     LEFT JOIN compras_fornecedores f ON f.id = pr.fornecedor_id
     LEFT JOIN cadastros_parceiros p ON p.id = f.parceiro_id
     LEFT JOIN compras_documentos d ON d.id = pr.documento_id
     LEFT JOIN compras_recebimentos rc ON rc.id = pr.documento_id
     WHERE ${filtro} AND ($3::timestamptz IS NULL OR (pr.created_at, pr.id) < ($3::timestamptz, $4::uuid))
     ORDER BY pr.created_at DESC, pr.id DESC LIMIT $5`,
    [...args, cur?.[0] ?? null, cur?.[1] ?? null, lim + 1],
  );
  const s = await c.query(
    `SELECT count(*)::int AS registros, min(preco_unitario_centavos)::float8 AS minimo_centavos, max(preco_unitario_centavos)::float8 AS maximo_centavos,
       round(avg(preco_unitario_centavos))::float8 AS medio_centavos,
       (array_agg(preco_unitario_centavos ORDER BY data DESC, created_at DESC))[1]::float8 AS ultimo_centavos
     FROM compras_precos pr WHERE ${filtro}`, args);
  return { ...pagina(r.rows, lim), resumo: s.rows[0] };
}
