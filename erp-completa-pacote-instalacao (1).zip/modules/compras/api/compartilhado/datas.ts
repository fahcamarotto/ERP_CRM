/** Datas de calendario em AAAA-MM-DD (UTC), sem dependencia externa. */
export function hojeIso(): string {
  return new Date().toISOString().slice(0, 10);
}

export function somarDias(data: string, dias: number): string {
  const d = new Date(`${data}T00:00:00Z`);
  d.setUTCDate(d.getUTCDate() + dias);
  return d.toISOString().slice(0, 10);
}
