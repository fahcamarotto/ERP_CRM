/**
 * @tool do modulo (N15): cada chamada vira tool MCP em /mcp e rota REST com o mesmo schema no OpenAPI.
 * Tool de M10.6: pedido_compra.criar; mais as leituras e os comandos principais do fluxo de compras.
 */
import { tool } from '@erp/api/sdk';
import { naoEncontrado } from './borda.ts';
import { contextoPg } from './compartilhado/efeitos-pg.ts';
import { exigirOk } from './compartilhado/result.ts';
import type { DadosDocumento, EstadoDocumento } from './documento/model/documento.ts';
import { listarDocumentos, obterDocumento, type FiltroDocumentos } from './documento/query/documentos.ts';
import { estadoDocumento, paginacao, propsDocumento, propsFornecedor, propsRecebimento, uuid } from './esquemas.ts';
import { casosDeUso } from './fabrica.ts';
import type { DadosFornecedor } from './fornecedor/model/fornecedor.ts';
import { listarFornecedores, obterFornecedor, type FiltroFornecedores } from './fornecedor/query/fornecedores.ts';
import { historicoPrecos, type FiltroPrecos } from './preco/precos-repo-pg.ts';
import { listarRecebimentos, obterRecebimento, type FiltroRecebimentos } from './recebimento/query/recebimentos.ts';
import type { EntradaRecebimento } from './recebimento/use-case/registrar-recebimento.ts';

const M = 'compras';
const filtroDoc = { ...paginacao, estado: estadoDocumento, fornecedor_id: uuid, origem_id: uuid } as const;
type Documento = Omit<DadosDocumento, 'tipo' | 'origem' | 'origem_id' | 'origem_ref'>;

// M10.6 ------------------------------------------------------------------------------------------
tool<Documento>({
  nome: 'pedido_compra.criar', modulo: M, titulo: 'Criar pedido de compra', tipo: 'escrita', permissao: 'compras.criar',
  descricao: 'Cria pedido de compra em rascunho para um fornecedor de Compras, com itens (produto do Estoque, quantidade e preco unitario em centavos). Condicao de pagamento e previsao de entrega vem do fornecedor quando omitidas. Numero da sequencia PC-. Publica pedido_compra.criado.',
  entrada: { type: 'object', required: ['fornecedor_id', 'itens'], properties: propsDocumento },
  rota: { metodo: 'POST', caminho: '/api/v1/compras/pedidos' },
  executar: async ({ c, ator, ip }, a) => {
    const { id } = exigirOk(await casosDeUso(c).criarDocumento.execute(contextoPg(c, ator, ip), { ...a, tipo: 'pedido' }));
    return obterDocumento(c, id);
  },
});

tool<FiltroDocumentos>({
  nome: 'pedidos_compra.listar', modulo: M, titulo: 'Listar pedidos de compra', tipo: 'leitura', permissao: 'compras.ver',
  descricao: 'Lista pedidos de compra com fornecedor, total em centavos, estado (rascunho, enviado, confirmado, recebido, cancelado) e percentual recebido. Filtra por estado, fornecedor ou busca.',
  entrada: { type: 'object', properties: filtroDoc },
  rota: { metodo: 'GET', caminho: '/api/v1/compras/pedidos' },
  executar: ({ c }, a) => listarDocumentos(c, { ...a, tipo: 'pedido' }),
});

tool<Documento>({
  nome: 'requisicao_compra.criar', modulo: M, titulo: 'Criar requisicao de compra', tipo: 'escrita', permissao: 'compras.criar',
  descricao: 'Abre requisicao de compra (pedido interno) em rascunho com os itens necessarios. Depois de aprovada gera cotacoes por fornecedor. Publica requisicao_compra.criada.',
  entrada: { type: 'object', required: ['itens'], properties: propsDocumento },
  rota: { metodo: 'POST', caminho: '/api/v1/compras/requisicoes' },
  executar: async ({ c, ator, ip }, a) => {
    const { id } = exigirOk(await casosDeUso(c).criarDocumento.execute(contextoPg(c, ator, ip), { ...a, tipo: 'requisicao' }));
    return obterDocumento(c, id);
  },
});

tool<FiltroDocumentos>({
  nome: 'requisicoes_compra.listar', modulo: M, titulo: 'Listar requisicoes de compra', tipo: 'leitura', permissao: 'compras.ver',
  descricao: 'Lista requisicoes de compra com estado, origem (manual ou reposicao do Estoque) e quantidade de itens.',
  entrada: { type: 'object', properties: filtroDoc },
  rota: { metodo: 'GET', caminho: '/api/v1/compras/requisicoes' },
  executar: ({ c }, a) => listarDocumentos(c, { ...a, tipo: 'requisicao' }),
});

tool<FiltroDocumentos>({
  nome: 'cotacoes_compra.listar', modulo: M, titulo: 'Listar cotacoes de compra', tipo: 'leitura', permissao: 'compras.ver',
  descricao: 'Lista cotacoes por fornecedor com total em centavos e a requisicao de origem. Filtre por origem_id para comparar as cotacoes de uma requisicao.',
  entrada: { type: 'object', properties: filtroDoc },
  rota: { metodo: 'GET', caminho: '/api/v1/compras/cotacoes' },
  executar: ({ c }, a) => listarDocumentos(c, { ...a, tipo: 'cotacao' }),
});

tool<{ id: string }>({
  nome: 'compras_documento.obter', modulo: M, titulo: 'Obter requisicao, cotacao ou pedido', tipo: 'leitura', permissao: 'compras.ver',
  descricao: 'Ficha de um documento de compra pelo id: itens com quantidade pendente, origem, documentos gerados e recebimentos.',
  entrada: { type: 'object', required: ['id'], properties: { id: uuid } },
  rota: { metodo: 'GET', caminho: '/api/v1/compras/documentos/:id' },
  executar: async ({ c }, a) => (await obterDocumento(c, a.id)) ?? Promise.reject(naoEncontrado('Documento de compra nao encontrado')),
});

tool<{ id: string; estado: EstadoDocumento; motivo?: string | null }>({
  nome: 'compras_documento.mudar_estado', modulo: M, titulo: 'Mudar estado do documento de compra', tipo: 'escrita', permissao: 'compras.editar',
  descricao: 'Move requisicao, cotacao ou pedido na maquina de estados (rascunho, enviado, confirmado, cancelado; recebido so pelo recebimento). Confirmar a cotacao escolhe o fornecedor e cancela as outras da mesma requisicao. Confirmar cotacao ou pedido grava o historico de preco.',
  entrada: { type: 'object', required: ['id', 'estado'], properties: { id: uuid, estado: estadoDocumento, motivo: { type: ['string', 'null'], maxLength: 500 } } },
  rota: { metodo: 'POST', caminho: '/api/v1/compras/documentos/:id/estado' },
  executar: async ({ c, ator, ip }, a) => {
    exigirOk(await casosDeUso(c).mudarEstadoDocumento.execute(contextoPg(c, ator, ip), a));
    return obterDocumento(c, a.id);
  },
});

tool<{ id: string; fornecedor_ids: string[] }>({
  nome: 'cotacoes_compra.gerar', modulo: M, titulo: 'Gerar cotacoes da requisicao', tipo: 'escrita', permissao: 'compras.criar',
  descricao: 'A partir de uma requisicao confirmada, cria uma cotacao em rascunho por fornecedor, com os mesmos itens e o ultimo preco pago a cada fornecedor como sugestao.',
  entrada: { type: 'object', required: ['id', 'fornecedor_ids'], properties: { id: uuid, fornecedor_ids: { type: 'array', minItems: 1, maxItems: 20, items: uuid } } },
  rota: { metodo: 'POST', caminho: '/api/v1/compras/documentos/:id/cotacoes' },
  executar: async ({ c, ator, ip }, a) => {
    const { ids } = exigirOk(await casosDeUso(c).gerarCotacoes.execute(contextoPg(c, ator, ip), { requisicao_id: a.id, fornecedor_ids: a.fornecedor_ids }));
    return { ids, cotacoes: await Promise.all(ids.map((id) => obterDocumento(c, id))) };
  },
});

tool<{ id: string }>({
  nome: 'pedido_compra.gerar', modulo: M, titulo: 'Gerar pedido da cotacao', tipo: 'escrita', permissao: 'compras.criar',
  descricao: 'Transforma a cotacao confirmada (escolhida) em pedido de compra em rascunho com os mesmos itens e precos. Publica pedido_compra.criado.',
  entrada: { type: 'object', required: ['id'], properties: { id: uuid } },
  rota: { metodo: 'POST', caminho: '/api/v1/compras/documentos/:id/pedido' },
  executar: async ({ c, ator, ip }, a) => {
    const { id } = exigirOk(await casosDeUso(c).gerarPedido.execute(contextoPg(c, ator, ip), { cotacao_id: a.id }));
    return obterDocumento(c, id);
  },
});

// M10.3 ------------------------------------------------------------------------------------------
tool<EntradaRecebimento>({
  nome: 'recebimento_compra.registrar', modulo: M, titulo: 'Registrar recebimento de compra', tipo: 'escrita', permissao: 'compras.receber',
  descricao: 'Registra recebimento parcial ou total de um pedido confirmado, conferindo cada quantidade com o saldo pendente (sem itens recebe tudo). Publica recebimento_compra.registrado com a entrada no Estoque e a conta a pagar em Contas.',
  entrada: { type: 'object', required: ['pedido_id'], properties: propsRecebimento },
  rota: { metodo: 'POST', caminho: '/api/v1/compras/recebimentos' },
  executar: async ({ c, ator, ip }, a) => {
    const { id } = exigirOk(await casosDeUso(c).registrarRecebimento.execute(contextoPg(c, ator, ip), a));
    return obterRecebimento(c, id);
  },
});

tool<FiltroRecebimentos>({
  nome: 'recebimentos_compra.listar', modulo: M, titulo: 'Listar recebimentos de compra', tipo: 'leitura', permissao: 'compras.ver',
  descricao: 'Lista recebimentos (parciais e totais) com pedido, fornecedor, deposito, nota fiscal e total em centavos.',
  entrada: { type: 'object', properties: { ...paginacao, pedido_id: uuid } },
  rota: { metodo: 'GET', caminho: '/api/v1/compras/recebimentos' },
  executar: ({ c }, a) => listarRecebimentos(c, a),
});

// M10.2 e M10.4 ----------------------------------------------------------------------------------
tool<FiltroFornecedores>({
  nome: 'fornecedores_compra.listar', modulo: M, titulo: 'Listar fornecedores de compras', tipo: 'leitura', permissao: 'compras.ver',
  descricao: 'Lista fornecedores de Compras com condicao de pagamento, prazo de entrega, pedido minimo e total comprado.',
  entrada: { type: 'object', properties: { ...paginacao, estado: { type: 'string', enum: ['ativo', 'arquivado', 'todos'], default: 'ativo' } } },
  rota: { metodo: 'GET', caminho: '/api/v1/compras/fornecedores' },
  executar: ({ c }, a) => listarFornecedores(c, a),
});

tool<DadosFornecedor>({
  nome: 'fornecedor_compra.criar', modulo: M, titulo: 'Cadastrar fornecedor de compras', tipo: 'escrita', permissao: 'compras.criar',
  descricao: 'Liga um parceiro do Cadastros a Compras com condicao de pagamento, prazo de entrega e pedido minimo. Um cadastro por parceiro.',
  entrada: { type: 'object', required: ['parceiro_id'], properties: propsFornecedor },
  rota: { metodo: 'POST', caminho: '/api/v1/compras/fornecedores' },
  executar: async ({ c, ator, ip }, a) => {
    const { id } = exigirOk(await casosDeUso(c).criarFornecedor.execute(contextoPg(c, ator, ip), a));
    return obterFornecedor(c, id);
  },
});

tool<FiltroPrecos>({
  nome: 'precos_compra.historico', modulo: M, titulo: 'Historico de preco de compra', tipo: 'leitura', permissao: 'compras.ver',
  descricao: 'Historico de preco pago por produto e fornecedor (cotacao escolhida, pedido confirmado e recebimento), com resumo de ultimo, minimo, medio e maximo em centavos.',
  entrada: { type: 'object', properties: { produto_id: uuid, fornecedor_id: uuid, limite: paginacao.limite, cursor: paginacao.cursor } },
  rota: { metodo: 'GET', caminho: '/api/v1/compras/precos' },
  executar: ({ c }, a) => historicoPrecos(c, a),
});
