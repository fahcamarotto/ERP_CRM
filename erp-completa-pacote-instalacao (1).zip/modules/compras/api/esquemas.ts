/** JSON Schemas dos DTOs de entrada (viram validacao Fastify, OpenAPI em /docs e schema das tools MCP). */
import { ESTADOS_DOCUMENTO, LIMITE_ITENS, TIPOS_DOCUMENTO } from './documento/model/documento.ts';
import { CONDICOES_PAGAMENTO } from './fornecedor/model/fornecedor.ts';

export const uuid = { type: 'string', format: 'uuid' } as const;
const uuidNulo = { type: ['string', 'null'], format: 'uuid' } as const;
const texto = (max: number) => ({ type: ['string', 'null'], maxLength: max });
const data = { type: ['string', 'null'], format: 'date' } as const;
const centavos = (descricao: string) => ({ type: 'integer', minimum: 0, maximum: 900_000_000_000_000, description: descricao });

export const condicao = { type: 'string', enum: [...CONDICOES_PAGAMENTO], description: 'Mesmas chaves de Contas: a_vista, 7_dias ... 90_dias' } as const;

export const propsFornecedor = {
  parceiro_id: { ...uuid, description: 'Parceiro do Cadastros (cadastros_parceiros) que vende para a empresa' },
  condicao_pagamento: condicao,
  prazo_entrega_dias: { type: 'integer', minimum: 0, maximum: 365, description: 'Prazo medio de entrega em dias' },
  pedido_minimo_centavos: centavos('Pedido minimo do fornecedor em centavos'),
  observacoes: texto(2000),
  extras: { type: 'object', description: 'Campos personalizados (modulo compras, entidade fornecedor)' },
} as const;

export const propsItem = {
  type: 'object', additionalProperties: false, required: ['quantidade'],
  properties: {
    id: { ...uuid, description: 'Na edicao: id do item que continua' },
    produto_id: { ...uuidNulo, description: 'Produto do Estoque (estoque_produtos); sem produto o item nao entra no estoque' },
    descricao: { ...texto(200), description: 'Padrao: nome do produto' },
    unidade: texto(10),
    quantidade: { type: 'number', exclusiveMinimum: 0, maximum: 99_999_999_999 },
    preco_unitario_centavos: centavos('Preco unitario em centavos (obrigatorio para enviar cotacao ou pedido)'),
  },
} as const;

export const propsDocumento = {
  fornecedor_id: { ...uuidNulo, description: 'Fornecedor de Compras (obrigatorio em cotacao e pedido)' },
  moeda: { type: 'string', pattern: '^[A-Z]{3}$' },
  previsao_entrega: data,
  condicao_pagamento: { type: ['string', 'null'], enum: [...CONDICOES_PAGAMENTO, null] },
  observacoes: texto(4000),
  itens: { type: 'array', minItems: 1, maxItems: LIMITE_ITENS, items: propsItem },
  extras: { type: 'object', description: 'Campos personalizados (modulo compras, entidade documento)' },
} as const;

export const tipoDocumento = { type: 'string', enum: [...TIPOS_DOCUMENTO] } as const;
export const estadoDocumento = { type: 'string', enum: [...ESTADOS_DOCUMENTO] } as const;

export const propsRecebimento = {
  pedido_id: uuid,
  data: { ...data, description: 'Data do recebimento (padrao: hoje)' },
  deposito_id: { ...uuidNulo, description: 'Deposito do Estoque que recebe (obrigatorio com produto de estoque)' },
  nota_fiscal: texto(60),
  observacoes: texto(2000),
  itens: {
    type: 'array', minItems: 1, maxItems: LIMITE_ITENS, description: 'Sem itens: recebe todo o saldo pendente (recebimento total)',
    items: {
      type: 'object', additionalProperties: false, required: ['item_id', 'quantidade'],
      properties: {
        item_id: { ...uuid, description: 'Item do pedido' },
        quantidade: { type: 'number', exclusiveMinimum: 0 },
        lote_codigo: texto(60),
        validade: data,
      },
    },
  },
} as const;

export const paginacao = {
  busca: { type: 'string', maxLength: 120 },
  limite: { type: 'integer', minimum: 1, maximum: 200, default: 50 },
  cursor: { type: 'string', maxLength: 200 },
} as const;
