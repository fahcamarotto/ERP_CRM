/**
 * Composicao do modulo: liga casos de uso aos adaptadores Postgres para um cliente de transacao.
 * Usada pelas rotas, pelas tools, pelo worker e pelo seed. Nao importa Fastify nem o pool do servidor.
 */
import { randomUUID } from 'node:crypto';
import type pg from 'pg';
import { DocumentoRepoPg, NumeracaoAutomatica, NumeracaoPg } from './documento/adapter/documento-repo-pg.ts';
import type { Numeracao } from './documento/model/portas.ts';
import {
  AbrirRequisicaoReposicao, CriarDocumento, EditarDocumento, ExcluirDocumentoCompra, GerarCotacoes, GerarPedido, MudarEstadoDocumento,
} from './documento/use-case/documentos.ts';
import { FornecedorRepoPg } from './fornecedor/adapter/fornecedor-repo-pg.ts';
import { CriarFornecedor, EditarFornecedor, MudarEstadoFornecedor, ReapontarParceiro } from './fornecedor/use-case/fornecedores.ts';
import { PrecosRepoPg } from './preco/precos-repo-pg.ts';
import { RecebimentoRepoPg } from './recebimento/adapter/recebimento-repo-pg.ts';
import { RegistrarRecebimento } from './recebimento/use-case/registrar-recebimento.ts';

/** `worker: true` troca a sequencia do nucleo (sem GRANT para erp_worker) pela numeracao automatica. */
export function casosDeUso(c: pg.PoolClient, opcoes: { worker?: boolean } = {}) {
  const fornecedores = new FornecedorRepoPg(c);
  const documentos = new DocumentoRepoPg(c);
  const recebimentos = new RecebimentoRepoPg(c);
  const precos = new PrecosRepoPg(c);
  const numeracao: Numeracao = opcoes.worker ? new NumeracaoAutomatica(randomUUID) : new NumeracaoPg(c);
  const depsDoc = { repo: documentos, refs: documentos, numeracao };
  return {
    criarFornecedor: new CriarFornecedor({ repo: fornecedores, parceiros: fornecedores }),
    editarFornecedor: new EditarFornecedor({ repo: fornecedores }),
    mudarEstadoFornecedor: new MudarEstadoFornecedor({ repo: fornecedores, abertos: fornecedores }),
    reapontarParceiro: new ReapontarParceiro({ repo: fornecedores }),
    criarDocumento: new CriarDocumento(depsDoc),
    editarDocumento: new EditarDocumento({ repo: documentos, refs: documentos }),
    mudarEstadoDocumento: new MudarEstadoDocumento({ repo: documentos, refs: documentos, precos }),
    excluirDocumento: new ExcluirDocumentoCompra({ repo: documentos }),
    gerarCotacoes: new GerarCotacoes({ ...depsDoc, precos }),
    gerarPedido: new GerarPedido(depsDoc),
    abrirRequisicaoReposicao: new AbrirRequisicaoReposicao({ ...depsDoc, busca: documentos }),
    registrarRecebimento: new RegistrarRecebimento({ pedidos: documentos, recebimentos, refs: recebimentos, numeracao, precos }),
  };
}

export type CasosDeUso = ReturnType<typeof casosDeUso>;
