/** Consultas de leitura do Recebimento: lista com pedido e fornecedor, ficha com itens. */
import type pg from 'pg';
import { decodificarCursor, pagina } from '../../compartilhado/cursor.ts';

const RESUMO = `r.id, r.numero, r.pedido_id, d.numero AS pedido_numero, d.estado AS pedido_estado, d.fornecedor_id,
  coalesce(p.nome_fantasia, p.nome) AS fornecedor_nome, to_char(r.data, 'YYYY-MM-DD') AS data, r.deposito_id, dp.nome AS deposito_nome,
  r.nota_fiscal, r.observacoes, r.tipo, r.moeda, r.total_centavos::float8 AS total_centavos, r.created_at,
  (SELECT count(*)::int FROM compras_recebimento_itens i WHERE i.recebimento_id = r.id AND i.deleted_at IS NULL) AS qtd_itens`;

const JUNCOES = `FROM compras_recebimentos r
  JOIN compras_documentos d ON d.id = r.pedido_id
  LEFT JOIN compras_fornecedores f ON f.id = d.fornecedor_id
  LEFT JOIN cadastros_parceiros p ON p.id = f.parceiro_id
  LEFT JOIN estoque_depositos dp ON dp.id = r.deposito_id`;

export interface FiltroRecebimentos {
  pedido_id?: string;
  busca?: string;
  limite?: number;
  cursor?: string;
}

export async function listarRecebimentos(c: pg.PoolClient, f: FiltroRecebimentos) {
  const lim = Math.min(Math.max(f.limite ?? 50, 1), 200);
  const cur = decodificarCursor(f.cursor);
  const r = await c.query(
    `SELECT ${RESUMO} ${JUNCOES}
     WHERE r.deleted_at IS NULL AND ($1::uuid IS NULL OR r.pedido_id = $1)
       AND ($2::text IS NULL OR r.numero ILIKE '%' || $2 || '%' OR d.numero ILIKE '%' || $2 || '%' OR p.nome ILIKE '%' || $2 || '%' OR r.nota_fiscal ILIKE '%' || $2 || '%')
       AND ($3::timestamptz IS NULL OR (r.created_at, r.id) > ($3::timestamptz, $4::uuid))
     ORDER BY r.created_at, r.id LIMIT $5`,
    [f.pedido_id ?? null, f.busca?.trim() || null, cur?.[0] ?? null, cur?.[1] ?? null, lim + 1],
  );
  return pagina(r.rows, lim);
}

export async function obterRecebimento(c: pg.PoolClient, id: string) {
  const r = await c.query(
    `SELECT ${RESUMO},
       coalesce((SELECT json_agg(json_build_object('id', i.id, 'item_id', i.item_id, 'produto_id', i.produto_id, 'sku', ep.sku,
          'descricao', i.descricao, 'quantidade', i.quantidade::float8, 'preco_unitario_centavos', i.preco_unitario_centavos::float8,
          'total_centavos', i.total_centavos::float8, 'lote_codigo', i.lote_codigo, 'validade', to_char(i.validade, 'YYYY-MM-DD')) ORDER BY i.created_at)
        FROM compras_recebimento_itens i LEFT JOIN estoque_produtos ep ON ep.id = i.produto_id
        WHERE i.recebimento_id = r.id AND i.deleted_at IS NULL), '[]') AS itens
     ${JUNCOES} WHERE r.id = $1 AND r.deleted_at IS NULL`, [id]);
  return r.rows[0] ?? null;
}
