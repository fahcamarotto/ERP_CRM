/** Adaptador Postgres do Recebimento e das referencias (deposito do Estoque e fornecedor do pedido). */
import type pg from 'pg';
import type { FornecedorCompra } from '../../documento/model/portas.ts';
import type { ConsultarReferenciasRecebimento, GravarRecebimento } from '../model/portas.ts';
import type { Recebimento } from '../model/recebimento.ts';

export class RecebimentoRepoPg implements GravarRecebimento, ConsultarReferenciasRecebimento {
  constructor(private readonly c: pg.PoolClient) {}

  async inserir(r: Recebimento): Promise<void> {
    const d = r.paraDados();
    await this.c.query(
      `INSERT INTO compras_recebimentos (id, numero, pedido_id, data, deposito_id, nota_fiscal, observacoes, tipo, moeda, total_centavos, creator_id)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, nucleo_usuario_atual())`,
      [d.id, d.numero, d.pedido_id, d.data, d.deposito_id, d.nota_fiscal, d.observacoes, d.tipo, d.moeda, d.total_centavos],
    );
    await this.c.query(
      `INSERT INTO compras_recebimento_itens (id, recebimento_id, item_id, produto_id, descricao, quantidade, preco_unitario_centavos, total_centavos, lote_codigo, validade, creator_id)
       SELECT x.id, $1, x.item_id, x.produto_id, x.descricao, x.quantidade, x.preco_unitario_centavos, x.total_centavos, x.lote_codigo, x.validade, nucleo_usuario_atual()
       FROM jsonb_to_recordset($2::jsonb) AS x(id uuid, item_id uuid, produto_id uuid, descricao text, quantidade numeric,
         preco_unitario_centavos bigint, total_centavos bigint, lote_codigo text, validade date)`,
      [d.id, JSON.stringify(d.itens)],
    );
  }

  /** Leitura da tabela publicada estoque_depositos (CONTRATOS 7.1.9). */
  async depositoAtivo(id: string): Promise<boolean> {
    const r = await this.c.query("SELECT 1 FROM estoque_depositos WHERE id = $1 AND estado = 'ativo' AND deleted_at IS NULL", [id]);
    return (r.rowCount ?? 0) > 0;
  }

  async fornecedorDoPedido(id: string): Promise<FornecedorCompra | null> {
    const r = await this.c.query(
      'SELECT id, parceiro_id, condicao_pagamento, prazo_entrega_dias FROM compras_fornecedores WHERE id = $1 AND deleted_at IS NULL', [id]);
    return r.rows[0] ?? null;
  }
}
