/**
 * Entidade Recebimento (M10.3): conferencia de mercadoria contra o pedido, parcial ou total.
 * Registrado uma vez e nao editado (correcao por novo documento); itens apontam o item do pedido.
 */
import { randomUUID } from 'node:crypto';
import { erroDe, fail, ok, type ErroDominio, type Result } from '../../compartilhado/result.ts';
import { Centavos } from '../../documento/model/centavos.ts';
import type { LinhaRecebida } from '../../documento/model/documento.ts';

export type TipoRecebimento = 'parcial' | 'total';

export interface LoteItem {
  lote_codigo?: string | null;
  validade?: string | null;
}

export interface ItemRecebimentoDados {
  id: string;
  item_id: string;
  produto_id: string | null;
  descricao: string;
  quantidade: number;
  preco_unitario_centavos: number;
  total_centavos: number;
  lote_codigo: string | null;
  validade: string | null;
}

export interface RecebimentoDados {
  id: string;
  numero: string;
  pedido_id: string;
  data: string;
  deposito_id: string | null;
  nota_fiscal: string | null;
  observacoes: string | null;
  tipo: TipoRecebimento;
  moeda: string;
  total_centavos: number;
  itens: ItemRecebimentoDados[];
}

export interface DadosRecebimento {
  pedido_id: string;
  data: string;
  deposito_id?: string | null;
  nota_fiscal?: string | null;
  observacoes?: string | null;
  moeda: string;
  total: boolean;
  linhas: LinhaRecebida[];
  lotes?: Map<string, LoteItem>;
}

const t = (v?: string | null) => (v ?? '').trim() || null;
const dataValida = (v: string | null) => v === null || (/^\d{4}-\d{2}-\d{2}$/.test(v) && !Number.isNaN(Date.parse(v)));

export class Recebimento {
  private constructor(private readonly d: RecebimentoDados) {}

  static tryCreate(e: DadosRecebimento, id: string = randomUUID()): Result<Recebimento> {
    const erros: ErroDominio[] = [];
    const itens: ItemRecebimentoDados[] = e.linhas.map((l, i) => {
      const lote = e.lotes?.get(l.id) ?? {};
      const lote_codigo = t(lote.lote_codigo);
      const validade = t(lote.validade);
      if (lote_codigo && lote_codigo.length > 60) erros.push(erroDe('lote_invalido', 'Codigo do lote com ate 60 caracteres', `itens.${i}.lote_codigo`));
      if (!dataValida(validade)) erros.push(erroDe('data_invalida', 'Validade deve ser AAAA-MM-DD', `itens.${i}.validade`));
      return {
        id: randomUUID(), item_id: l.id, produto_id: l.produto_id, descricao: l.descricao, quantidade: l.quantidade_agora,
        preco_unitario_centavos: l.preco_unitario_centavos, total_centavos: Centavos.total(l.quantidade_agora, l.preco_unitario_centavos),
        lote_codigo, validade,
      };
    });
    const d: RecebimentoDados = {
      id, numero: '', pedido_id: e.pedido_id, data: (t(e.data) ?? ''), deposito_id: t(e.deposito_id), nota_fiscal: t(e.nota_fiscal),
      observacoes: t(e.observacoes), tipo: e.total ? 'total' : 'parcial', moeda: e.moeda, itens,
      total_centavos: itens.reduce((s, i) => s + i.total_centavos, 0),
    };
    if (!d.data || !dataValida(d.data)) erros.push(erroDe('data_invalida', 'Data do recebimento deve ser AAAA-MM-DD', 'data'));
    if (!itens.length) erros.push(erroDe('itens_obrigatorios', 'Informe ao menos um item recebido', 'itens'));
    if (itens.some((i) => i.produto_id) && !d.deposito_id) {
      erros.push(erroDe('deposito_obrigatorio', 'Informe o deposito que recebe os produtos de estoque', 'deposito_id'));
    }
    if (d.nota_fiscal && d.nota_fiscal.length > 60) erros.push(erroDe('nota_invalida', 'Nota fiscal com ate 60 caracteres', 'nota_fiscal'));
    if (d.observacoes && d.observacoes.length > 2000) erros.push(erroDe('texto_longo', 'Observacoes com ate 2000 caracteres', 'observacoes'));
    return erros.length ? fail(...erros) : ok(new Recebimento(d));
  }

  static create(e: DadosRecebimento, id?: string): Recebimento {
    const r = Recebimento.tryCreate(e, id);
    if (!r.ok) throw new Error(r.erros.map((x) => x.mensagem).join('; '));
    return r.valor;
  }

  static reidratar(d: RecebimentoDados): Recebimento {
    return new Recebimento({ ...d, itens: d.itens.map((i) => ({ ...i })) });
  }

  get id(): string { return this.d.id; }

  numerar(numero: string): Recebimento {
    return new Recebimento({ ...this.d, itens: this.d.itens.map((i) => ({ ...i })), numero });
  }

  paraDados(): RecebimentoDados {
    return { ...this.d, itens: this.d.itens.map((i) => ({ ...i })) };
  }
}
