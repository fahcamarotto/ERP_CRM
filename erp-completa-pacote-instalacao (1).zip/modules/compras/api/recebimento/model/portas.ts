/** Portas do Recebimento. */
import type { FornecedorCompra } from '../../documento/model/portas.ts';
import type { Recebimento } from './recebimento.ts';

export interface GravarRecebimento {
  inserir(r: Recebimento): Promise<void>;
}

/** Referencias: deposito ativo do Estoque (tabela publicada) e fornecedor do pedido (mesmo arquivado). */
export interface ConsultarReferenciasRecebimento {
  depositoAtivo(id: string): Promise<boolean>;
  fornecedorDoPedido(id: string): Promise<FornecedorCompra | null>;
}
