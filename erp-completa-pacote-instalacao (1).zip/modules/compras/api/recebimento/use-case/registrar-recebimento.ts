/**
 * RegistrarRecebimento (M10.3): confere as quantidades com o pedido, grava o recebimento, atualiza o
 * saldo recebido do pedido (recebido quando total), registra o preco pago (M10.4) e publica
 * recebimento_compra.registrado com a entrada de Estoque (`movimentacao`, corpo de movimentacoes.registrar)
 * e a conta a pagar (`conta_pagar`, corpo de fatura.criar com chave_idempotencia), que os donos executam.
 */
import { hojeIso } from '../../compartilhado/datas.ts';
import { erroDe, fail, ok, type Result } from '../../compartilhado/result.ts';
import type { ContextoCaso } from '../../compartilhado/efeitos.ts';
import { subtrairQtd } from '../../documento/model/quantidade.ts';
import type { GravarDocumento, HistoricoPrecos, Numeracao, ObterDocumento } from '../../documento/model/portas.ts';
import { TABELA_DOCUMENTOS } from '../../documento/use-case/documentos.ts';
import type { ConsultarReferenciasRecebimento, GravarRecebimento } from '../model/portas.ts';
import { Recebimento, type LoteItem, type RecebimentoDados } from '../model/recebimento.ts';

export const TABELA_RECEBIMENTOS = 'compras_recebimentos';
export const SEQUENCIA_RECEBIMENTO = 'rcb';

export interface EntradaRecebimento {
  pedido_id: string;
  data?: string | null;
  deposito_id?: string | null;
  nota_fiscal?: string | null;
  observacoes?: string | null;
  /** Sem itens: recebe todo o saldo pendente do pedido (recebimento total). */
  itens?: { item_id: string; quantidade: number | string; lote_codigo?: string | null; validade?: string | null }[];
}

/** Corpo da entrada no Estoque (CONTRATOS 7.1.9, movimentacoes.registrar) ou null sem produto de estoque. */
export function movimentacaoDe(d: RecebimentoDados, pedidoNumero: string, parceiroId: string) {
  const itens = d.itens.filter((i) => i.produto_id).map((i) => ({
    produto_id: i.produto_id!, quantidade: i.quantidade, custo_unitario: i.preco_unitario_centavos / 100,
    ...(i.lote_codigo ? { lote_codigo: i.lote_codigo } : {}), ...(i.validade ? { validade: i.validade } : {}),
  }));
  if (!itens.length || !d.deposito_id) return null;
  return {
    tipo: 'entrada' as const, motivo: `Recebimento ${d.numero} do pedido de compra ${pedidoNumero}`, data: d.data,
    documento: d.nota_fiscal ?? d.numero, parceiro_id: parceiroId, deposito_id: d.deposito_id, itens,
  };
}

/** Corpo da conta a pagar (CONTRATOS 7.1.5, fatura.criar com tipo conta_pagar) ou null quando o valor e zero. */
export function contaPagarDe(d: RecebimentoDados, pedidoNumero: string, parceiroId: string, condicao: string | null) {
  if (d.total_centavos <= 0) return null;
  return {
    tipo: 'conta_pagar' as const, parceiro_id: parceiroId, descricao: `Compra ${pedidoNumero} · recebimento ${d.numero}${d.nota_fiscal ? ` · NF ${d.nota_fiscal}` : ''}`.slice(0, 200),
    emissao: d.data, condicao_pagamento: condicao ?? 'a_vista', moeda: d.moeda,
    itens: d.itens.filter((i) => i.total_centavos > 0).map((i) => ({ descricao: i.descricao, quantidade: i.quantidade, preco_centavos: i.preco_unitario_centavos })),
    chave_idempotencia: `compras-recebimento-${d.id}`,
  };
}

export class RegistrarRecebimento {
  constructor(private readonly deps: {
    pedidos: ObterDocumento & GravarDocumento;
    recebimentos: GravarRecebimento;
    refs: ConsultarReferenciasRecebimento;
    numeracao: Numeracao;
    precos: HistoricoPrecos;
  }) {}

  async execute(ctx: ContextoCaso, e: EntradaRecebimento): Promise<Result<{ id: string; numero: string; tipo: 'parcial' | 'total' }>> {
    const pedido = await this.deps.pedidos.obterPorId(e.pedido_id);
    if (!pedido || pedido.tipo !== 'pedido') return fail(erroDe('nao_encontrado', 'Pedido de compra nao encontrado'));
    const p = pedido.paraDados();
    const linhas = e.itens?.length
      ? e.itens.map((i) => ({ item_id: i.item_id, quantidade: i.quantidade }))
      : p.itens.map((i) => ({ item_id: i.id, quantidade: subtrairQtd(i.quantidade, i.quantidade_recebida) })).filter((l) => l.quantidade > 0);
    const r = pedido.receber(linhas);
    if (!r.ok) return r;
    if (e.deposito_id && !(await this.deps.refs.depositoAtivo(e.deposito_id))) {
      return fail(erroDe('deposito_invalido', 'Deposito nao encontrado ou inativo no Estoque', 'deposito_id'));
    }
    const fornecedor = await this.deps.refs.fornecedorDoPedido(p.fornecedor_id ?? '');
    if (!fornecedor) return fail(erroDe('fornecedor_invalido', 'Fornecedor do pedido nao encontrado', 'fornecedor_id'));
    const lotes = new Map<string, LoteItem>((e.itens ?? []).map((i) => [i.item_id, { lote_codigo: i.lote_codigo, validade: i.validade }]));
    const rec = Recebimento.tryCreate({
      pedido_id: p.id, data: e.data ?? hojeIso(), deposito_id: e.deposito_id, nota_fiscal: e.nota_fiscal, observacoes: e.observacoes,
      moeda: p.moeda, total: r.valor.total, linhas: r.valor.recebidas, lotes,
    });
    if (!rec.ok) return rec;
    const recebimento = rec.valor.numerar(await this.deps.numeracao.proximoNumero(SEQUENCIA_RECEBIMENTO));
    await this.deps.recebimentos.inserir(recebimento);
    await this.deps.pedidos.atualizar(r.valor.pedido);
    const d = recebimento.paraDados();
    await this.deps.precos.registrarPrecos(d.itens.filter((i) => i.produto_id && i.preco_unitario_centavos > 0).map((i) => ({
      produto_id: i.produto_id!, fornecedor_id: fornecedor.id, preco_unitario_centavos: i.preco_unitario_centavos, moeda: d.moeda,
      origem: 'recebimento' as const, documento_id: d.id, data: d.data,
    })));
    await ctx.efeitos.auditar('recebimento.registrar', TABELA_RECEBIMENTOS, d.id, undefined, d);
    if (r.valor.total) {
      await ctx.efeitos.historico(TABELA_DOCUMENTOS, p.id, { estado: p.estado }, { estado: 'recebido' });
    }
    await ctx.efeitos.nota(TABELA_DOCUMENTOS, p.id,
      `Recebimento ${d.numero} (${d.tipo}) registrado: ${d.itens.map((i) => `${i.quantidade} ${i.descricao}`).join(', ')}`);
    await ctx.efeitos.publicar('recebimento_compra.registrado', {
      id: d.id, numero: d.numero, pedido_id: p.id, pedido_numero: p.numero, fornecedor_id: fornecedor.id, parceiro_id: fornecedor.parceiro_id,
      data: d.data, tipo: d.tipo, pedido_recebido: r.valor.total, total_centavos: d.total_centavos, moeda: d.moeda, nota_fiscal: d.nota_fiscal,
      deposito_id: d.deposito_id,
      itens: d.itens.map((i) => ({ item_id: i.item_id, produto_id: i.produto_id, descricao: i.descricao, quantidade: i.quantidade, preco_unitario_centavos: i.preco_unitario_centavos, total_centavos: i.total_centavos, lote_codigo: i.lote_codigo, validade: i.validade })),
      movimentacao: movimentacaoDe(d, p.numero, fornecedor.parceiro_id),
      conta_pagar: contaPagarDe(d, p.numero, fornecedor.parceiro_id, p.condicao_pagamento ?? fornecedor.condicao_pagamento),
    });
    return ok({ id: d.id, numero: d.numero, tipo: d.tipo });
  }
}
