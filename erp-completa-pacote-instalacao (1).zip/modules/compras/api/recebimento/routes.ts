/** Rotas REST do Recebimento fora das tools: ficha com itens. Registrar e listar sao @tool em ../tools.ts. */
import { esquemaErro, requer, type FastifyInstance } from '@erp/api/sdk';
import { naTransacao, naoEncontrado } from '../borda.ts';
import { uuid } from '../esquemas.ts';
import { obterRecebimento } from './query/recebimentos.ts';

const tags = ['compras'];

export function rotasRecebimento(app: FastifyInstance): void {
  app.get<{ Params: { id: string } }>('/recebimentos/:id', {
    preHandler: requer('compras.ver'),
    schema: { tags, summary: 'Ficha do recebimento com itens, lotes e pedido', params: { type: 'object', required: ['id'], properties: { id: uuid } }, response: { 404: esquemaErro } },
  }, (req) => naTransacao(req, async (_, __, c) => (await obterRecebimento(c, req.params.id)) ?? Promise.reject(naoEncontrado('Recebimento nao encontrado'))));
}
