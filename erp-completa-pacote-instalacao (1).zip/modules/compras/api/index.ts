/**
 * Plugin do modulo Compras (M10), registrado sozinho com prefixo /api/v1/compras.
 * Importar ./tools.ts registra as @tool (MCP e REST) no carregamento.
 */
import type { FastifyPluginAsync } from '@erp/api/sdk';
import './tools.ts';
import { rotasDocumento } from './documento/routes.ts';
import { rotasFornecedor } from './fornecedor/routes.ts';
import { rotasRecebimento } from './recebimento/routes.ts';

const plugin: FastifyPluginAsync = async (app) => {
  rotasDocumento(app);
  rotasFornecedor(app);
  rotasRecebimento(app);
};

export default plugin;
