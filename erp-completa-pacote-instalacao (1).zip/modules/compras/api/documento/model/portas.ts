/** Portas do agregado DocumentoCompra, segregadas por operacao. */
import type { CondicaoPagamento } from '../../fornecedor/model/fornecedor.ts';
import type { DocumentoCompra } from './documento.ts';

export interface ObterDocumento {
  obterPorId(id: string): Promise<DocumentoCompra | null>;
}

export interface GravarDocumento {
  inserir(d: DocumentoCompra): Promise<void>;
  atualizar(d: DocumentoCompra): Promise<void>;
}

export interface ExcluirDocumento {
  excluir(id: string): Promise<void>;
}

/** Idempotencia da requisicao aberta por evento (origem_ref = id do alerta de reposicao). */
export interface BuscarDocumentoPorOrigem {
  buscarPorOrigemRef(ref: string): Promise<DocumentoCompra | null>;
  requisicaoReposicaoAberta(produtoId: string): Promise<boolean>;
}

/** Cotacoes da mesma requisicao ainda abertas (a escolhida cancela as outras). */
export interface ListarCotacoesIrmas {
  cotacoesAbertas(requisicaoId: string, excetoId: string): Promise<DocumentoCompra[]>;
}

/** N6: numero da sequencia do workspace. */
export interface Numeracao {
  proximoNumero(codigo: string): Promise<string>;
}

export interface FornecedorCompra {
  id: string;
  parceiro_id: string;
  condicao_pagamento: CondicaoPagamento;
  prazo_entrega_dias: number;
}

/** Referencias externas ao agregado: fornecedor ativo de Compras e produtos ativos do Estoque (tabela publicada). */
export interface ConsultarReferenciasDocumento {
  fornecedorAtivo(id: string): Promise<FornecedorCompra | null>;
  produtosAtivos(ids: string[]): Promise<{ id: string; nome: string; unidade: string }[]>;
}

export interface RegistroPreco {
  produto_id: string;
  fornecedor_id: string;
  preco_unitario_centavos: number;
  moeda: string;
  origem: 'cotacao' | 'pedido' | 'recebimento';
  documento_id: string;
  data: string;
}

/** M10.4: historico de preco por produto e fornecedor. */
export interface HistoricoPrecos {
  registrarPrecos(lista: RegistroPreco[]): Promise<void>;
  ultimosPrecos(fornecedorId: string, produtoIds: string[]): Promise<Map<string, number>>;
}
