/** Objeto de valor Centavos: dinheiro em centavos inteiros (bigint no banco), zero ou positivo. */
import { erroDe, fail, ok, type Result } from '../../compartilhado/result.ts';

export const LIMITE_CENTAVOS = 900_000_000_000_000;

export class Centavos {
  private constructor(readonly valor: number) {}

  static tryCreate(bruto: unknown, campo = 'preco_unitario_centavos'): Result<Centavos> {
    const n = Number(bruto ?? 0);
    if (!Number.isInteger(n) || n < 0 || n > LIMITE_CENTAVOS) {
      return fail(erroDe('valor_invalido', 'Valor em centavos inteiros, zero ou positivo', campo));
    }
    return ok(new Centavos(n));
  }

  static create(bruto: unknown): Centavos {
    const r = Centavos.tryCreate(bruto);
    if (!r.ok) throw new Error(r.erros[0]!.mensagem);
    return r.valor;
  }

  /** Total da linha: quantidade x preco, arredondado ao centavo. */
  static total(quantidade: number, precoCentavos: number): number {
    return Math.round(quantidade * precoCentavos);
  }
}
