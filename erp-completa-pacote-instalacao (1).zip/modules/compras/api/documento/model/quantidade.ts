/** Objeto de valor Quantidade: positiva, ate 3 casas decimais (mesma escala de numeric(14,3) no banco). */
import { erroDe, fail, ok, type Result } from '../../compartilhado/result.ts';

export class Quantidade {
  private constructor(readonly valor: number) {}

  static tryCreate(bruto: unknown, campo = 'quantidade'): Result<Quantidade> {
    const n = typeof bruto === 'string' ? Number(bruto.replace(',', '.')) : Number(bruto);
    if (!Number.isFinite(n) || n <= 0) return fail(erroDe('quantidade_invalida', 'Quantidade deve ser maior que zero', campo));
    const v = Math.round(n * 1000) / 1000;
    if (v <= 0 || v > 99_999_999_999) return fail(erroDe('quantidade_invalida', 'Quantidade fora do limite', campo));
    return ok(new Quantidade(v));
  }

  static create(bruto: unknown): Quantidade {
    const r = Quantidade.tryCreate(bruto);
    if (!r.ok) throw new Error(r.erros[0]!.mensagem);
    return r.valor;
  }
}

/** Soma e subtracao sem erro de ponto flutuante na escala de 3 casas. */
export const somarQtd = (a: number, b: number) => Math.round((a + b) * 1000) / 1000;
export const subtrairQtd = (a: number, b: number) => Math.round((a - b) * 1000) / 1000;
