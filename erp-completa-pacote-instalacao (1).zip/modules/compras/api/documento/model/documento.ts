/**
 * Agregado DocumentoCompra (M10.1): requisicao, cotacao e pedido num mesmo fluxo de estados
 * (rascunho, enviado, confirmado, recebido, cancelado), com itens filhos. A requisicao aprovada
 * gera cotacoes (uma por fornecedor), a cotacao escolhida gera o pedido e o pedido confirmado
 * recebe mercadoria em parcelas (M10.3) ate ficar recebido. Imutavel: toda alteracao devolve clone.
 */
import { randomUUID } from 'node:crypto';
import { erroDe, fail, ok, type ErroDominio, type Result } from '../../compartilhado/result.ts';
import { CONDICOES_PAGAMENTO, type CondicaoPagamento } from '../../fornecedor/model/fornecedor.ts';
import { Centavos } from './centavos.ts';
import { Quantidade, somarQtd, subtrairQtd } from './quantidade.ts';

export const TIPOS_DOCUMENTO = ['requisicao', 'cotacao', 'pedido'] as const;
export type TipoDocumento = (typeof TIPOS_DOCUMENTO)[number];
export const ESTADOS_DOCUMENTO = ['rascunho', 'enviado', 'confirmado', 'recebido', 'cancelado'] as const;
export type EstadoDocumento = (typeof ESTADOS_DOCUMENTO)[number];
export const ORIGENS_DOCUMENTO = ['manual', 'reposicao', 'requisicao', 'cotacao'] as const;
export type OrigemDocumento = (typeof ORIGENS_DOCUMENTO)[number];

/** Maquina de estados. `recebido` so e alcancado pelo recebimento total do pedido (nunca a mao). */
export const TRANSICOES: Record<EstadoDocumento, EstadoDocumento[]> = {
  rascunho: ['enviado', 'cancelado'],
  enviado: ['rascunho', 'confirmado', 'cancelado'],
  confirmado: ['recebido', 'cancelado'],
  recebido: [],
  cancelado: [],
};

/** Transicoes que o usuario pode pedir pela API e pela tela. */
export function transicoesManuais(estado: EstadoDocumento): EstadoDocumento[] {
  return TRANSICOES[estado].filter((e) => e !== 'recebido');
}

export const LIMITE_ITENS = 200;

export interface EntradaItem {
  id?: string;
  produto_id?: string | null;
  descricao?: string | null;
  unidade?: string | null;
  quantidade: number | string;
  preco_unitario_centavos?: number | null;
}

export interface DadosDocumento {
  tipo: TipoDocumento;
  fornecedor_id?: string | null;
  moeda?: string;
  previsao_entrega?: string | null;
  condicao_pagamento?: CondicaoPagamento | null;
  observacoes?: string | null;
  itens: EntradaItem[];
  extras?: Record<string, unknown>;
  origem?: OrigemDocumento;
  origem_id?: string | null;
  origem_ref?: string | null;
}

export interface ItemDados {
  id: string;
  ordem: number;
  produto_id: string | null;
  descricao: string;
  unidade: string;
  quantidade: number;
  preco_unitario_centavos: number;
  total_centavos: number;
  quantidade_recebida: number;
}

export interface DocumentoDados {
  id: string;
  tipo: TipoDocumento;
  numero: string;
  fornecedor_id: string | null;
  origem: OrigemDocumento;
  origem_id: string | null;
  origem_ref: string | null;
  moeda: string;
  previsao_entrega: string | null;
  condicao_pagamento: CondicaoPagamento | null;
  observacoes: string | null;
  estado: EstadoDocumento;
  total_centavos: number;
  itens: ItemDados[];
  extras: Record<string, unknown>;
}

/** Linha recebida agora num recebimento (M10.3). */
export interface LinhaRecebida extends ItemDados {
  quantidade_agora: number;
}

const t = (v?: string | null) => (v ?? '').trim() || null;
const dataValida = (v: string | null) => v === null || (/^\d{4}-\d{2}-\d{2}$/.test(v) && !Number.isNaN(Date.parse(v)));
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/** Monta e valida os itens (objetos de valor Quantidade e Centavos); acumula os erros com o indice. */
function montarItens(entrada: EntradaItem[], anteriores: ItemDados[] = []): Result<ItemDados[]> {
  const erros: ErroDominio[] = [];
  if (!Array.isArray(entrada) || entrada.length === 0) return fail(erroDe('itens_obrigatorios', 'Informe ao menos um item', 'itens'));
  if (entrada.length > LIMITE_ITENS) return fail(erroDe('itens_demais', `Maximo de ${LIMITE_ITENS} itens`, 'itens'));
  const porId = new Map(anteriores.map((i) => [i.id, i]));
  const itens: ItemDados[] = [];
  entrada.forEach((e, i) => {
    const q = Quantidade.tryCreate(e.quantidade, `itens.${i}.quantidade`);
    const p = Centavos.tryCreate(e.preco_unitario_centavos ?? 0, `itens.${i}.preco_unitario_centavos`);
    const descricao = t(e.descricao);
    const produto = t(e.produto_id);
    if (!q.ok) erros.push(...q.erros);
    if (!p.ok) erros.push(...p.erros);
    if (!descricao || descricao.length > 200) erros.push(erroDe('descricao_invalida', 'Descricao do item com 1 a 200 caracteres', `itens.${i}.descricao`));
    if (produto && !UUID.test(produto)) erros.push(erroDe('produto_invalido', 'Produto invalido', `itens.${i}.produto_id`));
    const unidade = (t(e.unidade) ?? 'UN').toUpperCase();
    if (unidade.length > 10) erros.push(erroDe('unidade_invalida', 'Unidade com ate 10 caracteres', `itens.${i}.unidade`));
    if (!q.ok || !p.ok) return;
    const id = e.id && porId.has(e.id) ? e.id : randomUUID();
    itens.push({
      id, ordem: i, produto_id: produto, descricao: descricao ?? '', unidade, quantidade: q.valor.valor,
      preco_unitario_centavos: p.valor.valor, total_centavos: Centavos.total(q.valor.valor, p.valor.valor), quantidade_recebida: 0,
    });
  });
  return erros.length ? fail(...erros) : ok(itens);
}

function validar(d: DocumentoDados): ErroDominio[] {
  const e: ErroDominio[] = [];
  if (!TIPOS_DOCUMENTO.includes(d.tipo)) e.push(erroDe('tipo_invalido', 'Tipo deve ser requisicao, cotacao ou pedido', 'tipo'));
  if (d.tipo !== 'requisicao' && !d.fornecedor_id) e.push(erroDe('fornecedor_obrigatorio', 'Cotacao e pedido exigem fornecedor', 'fornecedor_id'));
  if (d.fornecedor_id && !UUID.test(d.fornecedor_id)) e.push(erroDe('fornecedor_invalido', 'Fornecedor invalido', 'fornecedor_id'));
  if (!/^[A-Z]{3}$/.test(d.moeda)) e.push(erroDe('moeda_invalida', 'Moeda em ISO 4217 (BRL, USD, EUR)', 'moeda'));
  if (!dataValida(d.previsao_entrega)) e.push(erroDe('data_invalida', 'Previsao de entrega deve ser AAAA-MM-DD', 'previsao_entrega'));
  if (d.condicao_pagamento !== null && !CONDICOES_PAGAMENTO.includes(d.condicao_pagamento)) {
    e.push(erroDe('condicao_invalida', 'Condicao de pagamento invalida', 'condicao_pagamento', { aceitas: CONDICOES_PAGAMENTO }));
  }
  if (d.observacoes && d.observacoes.length > 4000) e.push(erroDe('texto_longo', 'Observacoes com ate 4000 caracteres', 'observacoes'));
  if (!ORIGENS_DOCUMENTO.includes(d.origem)) e.push(erroDe('origem_invalida', 'Origem invalida', 'origem'));
  return e;
}

const totalDe = (itens: ItemDados[]) => itens.reduce((s, i) => s + i.total_centavos, 0);

export class DocumentoCompra {
  private constructor(private readonly d: DocumentoDados) {}

  static tryCreate(e: DadosDocumento, id: string = randomUUID()): Result<DocumentoCompra> {
    const itens = montarItens(e.itens ?? []);
    const d: DocumentoDados = {
      id, tipo: e.tipo, numero: '', fornecedor_id: t(e.fornecedor_id), origem: e.origem ?? 'manual', origem_id: t(e.origem_id),
      origem_ref: t(e.origem_ref), moeda: (t(e.moeda) ?? 'BRL').toUpperCase(), previsao_entrega: t(e.previsao_entrega),
      condicao_pagamento: e.condicao_pagamento ?? null, observacoes: t(e.observacoes), estado: 'rascunho',
      itens: itens.ok ? itens.valor : [], total_centavos: itens.ok ? totalDe(itens.valor) : 0, extras: e.extras ?? {},
    };
    const erros = [...validar(d), ...(itens.ok ? [] : itens.erros)];
    return erros.length ? fail(...erros) : ok(new DocumentoCompra(d));
  }

  static create(e: DadosDocumento, id?: string): DocumentoCompra {
    const r = DocumentoCompra.tryCreate(e, id);
    if (!r.ok) throw new Error(r.erros.map((x) => x.mensagem).join('; '));
    return r.valor;
  }

  static reidratar(d: DocumentoDados): DocumentoCompra {
    return new DocumentoCompra({ ...d, itens: d.itens.map((i) => ({ ...i })), extras: { ...d.extras } });
  }

  get id(): string { return this.d.id; }
  get tipo(): TipoDocumento { return this.d.tipo; }
  get estado(): EstadoDocumento { return this.d.estado; }
  get numero(): string { return this.d.numero; }
  get fornecedorId(): string | null { return this.d.fornecedor_id; }
  get origemId(): string | null { return this.d.origem_id; }

  /** Numero da sequencia (N6) atribuido pelo caso de uso depois de validar. */
  numerar(numero: string): DocumentoCompra {
    return new DocumentoCompra({ ...this.d, itens: this.d.itens.map((i) => ({ ...i })), numero });
  }

  editar(e: Partial<Omit<DadosDocumento, 'tipo' | 'origem' | 'origem_id' | 'origem_ref'>>): Result<DocumentoCompra> {
    if (this.d.estado !== 'rascunho') {
      return fail(erroDe('transicao_invalida', `Documento ${this.d.estado} nao pode ser editado; volte para rascunho antes`, 'estado'));
    }
    const tem = (k: keyof typeof e) => e[k] !== undefined;
    let itens = this.d.itens.map((i) => ({ ...i }));
    if (tem('itens')) {
      const r = montarItens(e.itens!, this.d.itens);
      if (!r.ok) return r;
      itens = r.valor;
    }
    const n: DocumentoDados = {
      ...this.d,
      fornecedor_id: tem('fornecedor_id') ? t(e.fornecedor_id) : this.d.fornecedor_id,
      moeda: tem('moeda') ? (t(e.moeda) ?? 'BRL').toUpperCase() : this.d.moeda,
      previsao_entrega: tem('previsao_entrega') ? t(e.previsao_entrega) : this.d.previsao_entrega,
      condicao_pagamento: tem('condicao_pagamento') ? (e.condicao_pagamento ?? null) : this.d.condicao_pagamento,
      observacoes: tem('observacoes') ? t(e.observacoes) : this.d.observacoes,
      extras: tem('extras') ? { ...e.extras } : { ...this.d.extras },
      itens, total_centavos: totalDe(itens),
    };
    const erros = validar(n);
    return erros.length ? fail(...erros) : ok(new DocumentoCompra(n));
  }

  mudarEstado(novo: EstadoDocumento): Result<DocumentoCompra> {
    if (!ESTADOS_DOCUMENTO.includes(novo)) return fail(erroDe('estado_invalido', 'Estado invalido', 'estado'));
    const permitidas = transicoesManuais(this.d.estado);
    if (!permitidas.includes(novo)) {
      return fail(erroDe('transicao_invalida', `Transicao de ${this.d.estado} para ${novo} nao permitida`, 'estado', { permitidas }));
    }
    if (this.d.tipo !== 'requisicao' && (novo === 'enviado' || novo === 'confirmado')) {
      const semPreco = this.d.itens.filter((i) => i.preco_unitario_centavos <= 0).map((i) => i.descricao);
      if (semPreco.length) return fail(erroDe('preco_obrigatorio', 'Informe o preco de todos os itens antes de enviar ou confirmar', 'itens', { itens: semPreco }));
    }
    if (novo === 'cancelado' && this.d.itens.some((i) => i.quantidade_recebida > 0)) {
      return fail(erroDe('transicao_invalida', 'Pedido com recebimento registrado nao pode ser cancelado', 'estado', { permitidas: [] }));
    }
    return ok(new DocumentoCompra({ ...this.d, itens: this.d.itens.map((i) => ({ ...i })), estado: novo }));
  }

  /**
   * Recebimento parcial ou total conferido com o pedido (M10.3): cada linha nao passa do saldo
   * pendente do item. Quando tudo foi recebido o pedido vai para `recebido`.
   */
  receber(linhas: { item_id: string; quantidade: number | string }[]): Result<{ pedido: DocumentoCompra; recebidas: LinhaRecebida[]; total: boolean }> {
    if (this.d.tipo !== 'pedido') return fail(erroDe('tipo_invalido', 'So pedido de compra recebe mercadoria', 'pedido_id'));
    if (this.d.estado !== 'confirmado') {
      return fail(erroDe('transicao_invalida', `Pedido ${this.d.estado} nao pode receber; confirme o pedido antes`, 'estado'));
    }
    if (!Array.isArray(linhas) || linhas.length === 0) return fail(erroDe('itens_obrigatorios', 'Informe ao menos um item recebido', 'itens'));
    const itens = this.d.itens.map((i) => ({ ...i }));
    const porId = new Map(itens.map((i) => [i.id, i]));
    const erros: ErroDominio[] = [];
    const recebidas: LinhaRecebida[] = [];
    const vistos = new Set<string>();
    linhas.forEach((l, i) => {
      const item = porId.get(l.item_id);
      if (!item) { erros.push(erroDe('item_invalido', 'Item nao pertence ao pedido', `itens.${i}.item_id`)); return; }
      if (vistos.has(l.item_id)) { erros.push(erroDe('item_repetido', 'Item repetido no recebimento', `itens.${i}.item_id`)); return; }
      vistos.add(l.item_id);
      const q = Quantidade.tryCreate(l.quantidade, `itens.${i}.quantidade`);
      if (!q.ok) { erros.push(...q.erros); return; }
      const pendente = subtrairQtd(item.quantidade, item.quantidade_recebida);
      if (q.valor.valor > pendente) {
        erros.push(erroDe('quantidade_excedida', `Recebendo ${q.valor.valor} de ${item.descricao}, mas so faltam ${pendente}`, `itens.${i}.quantidade`, { pendente }));
        return;
      }
      item.quantidade_recebida = somarQtd(item.quantidade_recebida, q.valor.valor);
      recebidas.push({ ...item, quantidade_agora: q.valor.valor });
    });
    if (erros.length) return fail(...erros);
    const total = itens.every((i) => i.quantidade_recebida >= i.quantidade);
    const pedido = new DocumentoCompra({ ...this.d, itens, estado: total ? 'recebido' : 'confirmado' });
    return ok({ pedido, recebidas, total });
  }

  /**
   * Gera o proximo documento do fluxo: requisicao confirmada vira cotacao (por fornecedor) e
   * cotacao confirmada vira pedido. Precos sugeridos (historico M10.4) preenchem itens sem preco.
   */
  derivar(fornecedor: { id: string; condicao_pagamento: CondicaoPagamento; previsao_entrega: string | null },
    precosSugeridos: Map<string, number> = new Map(), id: string = randomUUID()): Result<DocumentoCompra> {
    const destino: TipoDocumento | null = this.d.tipo === 'requisicao' ? 'cotacao' : this.d.tipo === 'cotacao' ? 'pedido' : null;
    if (!destino) return fail(erroDe('transicao_invalida', 'Pedido nao gera outro documento', 'tipo'));
    if (this.d.estado !== 'confirmado') {
      return fail(erroDe('transicao_invalida', `So ${this.d.tipo} confirmada gera ${destino}`, 'estado', { estado: this.d.estado }));
    }
    return DocumentoCompra.tryCreate({
      tipo: destino, fornecedor_id: fornecedor.id, moeda: this.d.moeda, origem: this.d.tipo as 'requisicao' | 'cotacao', origem_id: this.d.id,
      previsao_entrega: destino === 'pedido' ? (this.d.previsao_entrega ?? fornecedor.previsao_entrega) : fornecedor.previsao_entrega,
      condicao_pagamento: destino === 'pedido' ? (this.d.condicao_pagamento ?? fornecedor.condicao_pagamento) : fornecedor.condicao_pagamento,
      observacoes: this.d.observacoes,
      itens: this.d.itens.map((i) => ({
        produto_id: i.produto_id, descricao: i.descricao, unidade: i.unidade, quantidade: i.quantidade,
        preco_unitario_centavos: destino === 'pedido' ? i.preco_unitario_centavos : (i.produto_id ? precosSugeridos.get(i.produto_id) ?? 0 : 0),
      })),
    }, id);
  }

  /** Itens com produto e preco, para o historico de preco (M10.4). */
  precosDoDocumento(): { produto_id: string; preco_unitario_centavos: number }[] {
    return this.d.itens.filter((i) => i.produto_id && i.preco_unitario_centavos > 0)
      .map((i) => ({ produto_id: i.produto_id!, preco_unitario_centavos: i.preco_unitario_centavos }));
  }

  paraDados(): DocumentoDados {
    return { ...this.d, itens: this.d.itens.map((i) => ({ ...i })), extras: { ...this.d.extras } };
  }
}
