/** Rotas REST do DocumentoCompra fora das tools: criar cotacao avulsa, editar, excluir e opcoes dos formularios. */
import { esquemaErro, requer, type FastifyInstance } from '@erp/api/sdk';
import { naTransacao } from '../borda.ts';
import { exigirOk } from '../compartilhado/result.ts';
import { propsDocumento, uuid } from '../esquemas.ts';
import type { DadosDocumento } from './model/documento.ts';
import { obterDocumento, opcoesCompras } from './query/documentos.ts';

const tags = ['compras'];
const paramId = { type: 'object', required: ['id'], properties: { id: uuid } } as const;
type Documento = Omit<DadosDocumento, 'tipo' | 'origem' | 'origem_id' | 'origem_ref'>;

export function rotasDocumento(app: FastifyInstance): void {
  app.get('/opcoes', {
    preHandler: requer('compras.ver'),
    schema: { tags, summary: 'Fornecedores ativos, produtos e depositos do Estoque para os formularios' },
  }, (req) => naTransacao(req, (_, __, c) => opcoesCompras(c)));

  app.post<{ Body: Documento }>('/cotacoes', {
    preHandler: requer('compras.criar'),
    schema: {
      tags, summary: 'Cria cotacao avulsa em rascunho (CriarDocumento tipo cotacao)',
      body: { type: 'object', additionalProperties: false, required: ['fornecedor_id', 'itens'], properties: propsDocumento },
      response: { 400: esquemaErro, 403: esquemaErro, 409: esquemaErro },
    },
  }, async (req, reply) => reply.code(201).send(await naTransacao(req, async (casos, ctx, c) => {
    const { id } = exigirOk(await casos.criarDocumento.execute(ctx, { ...req.body, tipo: 'cotacao' }));
    return obterDocumento(c, id);
  })));

  app.patch<{ Params: { id: string }; Body: Documento }>('/documentos/:id', {
    preHandler: requer('compras.editar'),
    schema: {
      tags, summary: 'Edita documento em rascunho (EditarDocumento)', params: paramId,
      body: { type: 'object', additionalProperties: false, properties: propsDocumento },
      response: { 400: esquemaErro, 404: esquemaErro, 409: esquemaErro },
    },
  }, (req) => naTransacao(req, async (casos, ctx, c) => {
    exigirOk(await casos.editarDocumento.execute(ctx, { ...req.body, id: req.params.id }));
    return obterDocumento(c, req.params.id);
  }));

  app.delete<{ Params: { id: string } }>('/documentos/:id', {
    preHandler: requer('compras.excluir'),
    schema: { tags, summary: 'Exclui documento em rascunho ou cancelado (exclusao logica)', params: paramId, response: { 404: esquemaErro, 409: esquemaErro } },
  }, async (req, reply) => {
    await naTransacao(req, async (casos, ctx) => exigirOk(await casos.excluirDocumento.execute(ctx, { id: req.params.id })));
    return reply.code(204).send();
  });
}
