/** Adaptador Postgres do DocumentoCompra e dos itens (RLS restringe ao workspace da sessao). */
import type pg from 'pg';
import { proximoNumero } from '@erp/api/sdk/puro';
import { DocumentoCompra, type DocumentoDados } from '../model/documento.ts';
import type {
  BuscarDocumentoPorOrigem, ConsultarReferenciasDocumento, ExcluirDocumento, FornecedorCompra, GravarDocumento, ListarCotacoesIrmas,
  Numeracao, ObterDocumento,
} from '../model/portas.ts';

const COLUNAS = `d.id, d.tipo, d.numero, d.fornecedor_id, d.origem, d.origem_id, d.origem_ref, d.moeda,
  to_char(d.previsao_entrega, 'YYYY-MM-DD') AS previsao_entrega, d.condicao_pagamento, d.observacoes, d.estado,
  d.total_centavos::float8 AS total_centavos, d.extras,
  coalesce((SELECT json_agg(json_build_object('id', i.id, 'ordem', i.ordem, 'produto_id', i.produto_id, 'descricao', i.descricao,
     'unidade', i.unidade, 'quantidade', i.quantidade::float8, 'preco_unitario_centavos', i.preco_unitario_centavos::float8,
     'total_centavos', i.total_centavos::float8, 'quantidade_recebida', i.quantidade_recebida::float8) ORDER BY i.ordem)
   FROM compras_itens i WHERE i.documento_id = d.id AND i.deleted_at IS NULL), '[]') AS itens`;

export class DocumentoRepoPg implements ObterDocumento, GravarDocumento, ExcluirDocumento, BuscarDocumentoPorOrigem, ListarCotacoesIrmas, ConsultarReferenciasDocumento {
  constructor(private readonly c: pg.PoolClient) {}

  private async um(sql: string, args: unknown[]): Promise<DocumentoCompra | null> {
    const r = await this.c.query(`SELECT ${COLUNAS} FROM compras_documentos d WHERE ${sql} AND d.deleted_at IS NULL`, args);
    return r.rows[0] ? DocumentoCompra.reidratar(r.rows[0] as DocumentoDados) : null;
  }

  obterPorId(id: string) { return this.um('d.id = $1', [id]); }
  buscarPorOrigemRef(ref: string) { return this.um('d.origem_ref = $1', [ref]); }

  async requisicaoReposicaoAberta(produtoId: string): Promise<boolean> {
    const r = await this.c.query(
      `SELECT 1 FROM compras_documentos d JOIN compras_itens i ON i.documento_id = d.id AND i.deleted_at IS NULL
       WHERE d.tipo = 'requisicao' AND d.origem = 'reposicao' AND d.estado IN ('rascunho', 'enviado') AND d.deleted_at IS NULL
         AND i.produto_id = $1 LIMIT 1`, [produtoId]);
    return (r.rowCount ?? 0) > 0;
  }

  async cotacoesAbertas(requisicaoId: string, excetoId: string): Promise<DocumentoCompra[]> {
    const r = await this.c.query(
      `SELECT ${COLUNAS} FROM compras_documentos d WHERE d.origem_id = $1 AND d.id <> $2 AND d.tipo = 'cotacao'
         AND d.estado IN ('rascunho', 'enviado') AND d.deleted_at IS NULL`, [requisicaoId, excetoId]);
    return r.rows.map((x) => DocumentoCompra.reidratar(x as DocumentoDados));
  }

  async inserir(doc: DocumentoCompra): Promise<void> {
    const d = doc.paraDados();
    await this.c.query(
      `INSERT INTO compras_documentos (id, tipo, numero, fornecedor_id, origem, origem_id, origem_ref, moeda, previsao_entrega,
         condicao_pagamento, observacoes, estado, total_centavos, extras, creator_id)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, nucleo_usuario_atual())`,
      [d.id, d.tipo, d.numero, d.fornecedor_id, d.origem, d.origem_id, d.origem_ref, d.moeda, d.previsao_entrega,
        d.condicao_pagamento, d.observacoes, d.estado, d.total_centavos, JSON.stringify(d.extras)],
    );
    await this.sincronizarItens(d);
  }

  async atualizar(doc: DocumentoCompra): Promise<void> {
    const d = doc.paraDados();
    await this.c.query(
      `UPDATE compras_documentos SET fornecedor_id = $2, moeda = $3, previsao_entrega = $4, condicao_pagamento = $5, observacoes = $6,
         total_centavos = $8, extras = $9,
         enviado_em = CASE WHEN $7 = 'enviado' AND estado <> 'enviado' THEN now() ELSE enviado_em END,
         confirmado_em = CASE WHEN $7 = 'confirmado' AND estado <> 'confirmado' THEN now() ELSE confirmado_em END,
         recebido_em = CASE WHEN $7 = 'recebido' AND estado <> 'recebido' THEN now() ELSE recebido_em END,
         cancelado_em = CASE WHEN $7 = 'cancelado' AND estado <> 'cancelado' THEN now() ELSE cancelado_em END,
         estado = $7
       WHERE id = $1 AND deleted_at IS NULL`,
      [d.id, d.fornecedor_id, d.moeda, d.previsao_entrega, d.condicao_pagamento, d.observacoes, d.estado, d.total_centavos, JSON.stringify(d.extras)],
    );
    await this.sincronizarItens(d);
  }

  /** Upsert dos itens pelo id; os que sairam recebem exclusao logica. */
  private async sincronizarItens(d: DocumentoDados): Promise<void> {
    await this.c.query(
      'UPDATE compras_itens SET deleted_at = now() WHERE documento_id = $1 AND deleted_at IS NULL AND NOT (id = ANY ($2::uuid[]))',
      [d.id, d.itens.map((i) => i.id)],
    );
    if (!d.itens.length) return;
    await this.c.query(
      `INSERT INTO compras_itens (id, documento_id, ordem, produto_id, descricao, unidade, quantidade, preco_unitario_centavos, total_centavos, quantidade_recebida, creator_id)
       SELECT x.id, $1, x.ordem, x.produto_id, x.descricao, x.unidade, x.quantidade, x.preco_unitario_centavos, x.total_centavos, x.quantidade_recebida, nucleo_usuario_atual()
       FROM jsonb_to_recordset($2::jsonb) AS x(id uuid, ordem int, produto_id uuid, descricao text, unidade text, quantidade numeric,
         preco_unitario_centavos bigint, total_centavos bigint, quantidade_recebida numeric)
       ON CONFLICT (id, tenant_id, workspace_id) DO UPDATE SET ordem = EXCLUDED.ordem, produto_id = EXCLUDED.produto_id,
         descricao = EXCLUDED.descricao, unidade = EXCLUDED.unidade, quantidade = EXCLUDED.quantidade,
         preco_unitario_centavos = EXCLUDED.preco_unitario_centavos, total_centavos = EXCLUDED.total_centavos,
         quantidade_recebida = EXCLUDED.quantidade_recebida, deleted_at = NULL`,
      [d.id, JSON.stringify(d.itens)],
    );
  }

  async excluir(id: string): Promise<void> {
    await this.c.query('UPDATE compras_itens SET deleted_at = now() WHERE documento_id = $1 AND deleted_at IS NULL', [id]);
    await this.c.query('UPDATE compras_documentos SET deleted_at = now() WHERE id = $1 AND deleted_at IS NULL', [id]);
  }

  async fornecedorAtivo(id: string): Promise<FornecedorCompra | null> {
    const r = await this.c.query(
      `SELECT id, parceiro_id, condicao_pagamento, prazo_entrega_dias FROM compras_fornecedores
       WHERE id = $1 AND estado = 'ativo' AND deleted_at IS NULL`, [id]);
    return r.rows[0] ?? null;
  }

  /** Leitura da tabela publicada estoque_produtos (CONTRATOS 7.1.9). */
  async produtosAtivos(ids: string[]) {
    const r = await this.c.query(
      "SELECT id, nome, unidade FROM estoque_produtos WHERE id = ANY ($1::uuid[]) AND estado = 'ativo' AND deleted_at IS NULL", [ids]);
    return r.rows as { id: string; nome: string; unidade: string }[];
  }
}

/** N6 pela sequencia do nucleo (API e seed). */
export class NumeracaoPg implements Numeracao {
  constructor(private readonly c: pg.PoolClient) {}
  proximoNumero(codigo: string): Promise<string> { return proximoNumero(this.c, codigo); }
}

/**
 * Numeracao do worker: o papel erp_worker nao tem acesso a tabela `sequencias` do nucleo, entao o
 * documento aberto por evento recebe numero derivado do id (`RC-AUTO-XXXXXXXX`), unico no workspace.
 */
export class NumeracaoAutomatica implements Numeracao {
  private n = 0;
  constructor(private readonly semente: () => string) {}
  async proximoNumero(codigo: string): Promise<string> {
    this.n++;
    return `${codigo.toUpperCase()}-AUTO-${this.semente().replace(/-/g, '').slice(0, 8).toUpperCase()}${this.n > 1 ? `-${this.n}` : ''}`;
  }
}
