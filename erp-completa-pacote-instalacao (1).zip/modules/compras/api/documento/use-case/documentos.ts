/**
 * Casos de uso do DocumentoCompra (M10.1): CriarDocumento (inclui pedido_compra.criar), EditarDocumento,
 * MudarEstadoDocumento, ExcluirDocumento, GerarCotacoes, GerarPedido e AbrirRequisicaoReposicao.
 */
import { hojeIso, somarDias } from '../../compartilhado/datas.ts';
import { erroDe, fail, ok, okVazio, type ErroDominio, type Result } from '../../compartilhado/result.ts';
import type { ContextoCaso } from '../../compartilhado/efeitos.ts';
import { DocumentoCompra, type DadosDocumento, type DocumentoDados, type EntradaItem, type EstadoDocumento, type TipoDocumento } from '../model/documento.ts';
import type {
  BuscarDocumentoPorOrigem, ConsultarReferenciasDocumento, ExcluirDocumento, FornecedorCompra, GravarDocumento, HistoricoPrecos,
  ListarCotacoesIrmas, Numeracao, ObterDocumento,
} from '../model/portas.ts';

export const TABELA_DOCUMENTOS = 'compras_documentos';
/** Codigos de sequencia (N6) por tipo: prefixos RC-, COT- e PC-. */
export const SEQUENCIA: Record<TipoDocumento, string> = { requisicao: 'rc', cotacao: 'cot', pedido: 'pc' };
const NOME: Record<TipoDocumento, string> = { requisicao: 'Requisicao', cotacao: 'Cotacao', pedido: 'Pedido' };

export interface DepsDocumento {
  repo: ObterDocumento & GravarDocumento;
  refs: ConsultarReferenciasDocumento;
  numeracao: Numeracao;
}

/** Resumo publicado nos eventos (sem itens internos). */
function resumo(d: DocumentoDados, fornecedor?: FornecedorCompra | null) {
  return {
    id: d.id, tipo: d.tipo, numero: d.numero, fornecedor_id: d.fornecedor_id, parceiro_id: fornecedor?.parceiro_id ?? null,
    estado: d.estado, total_centavos: d.total_centavos, moeda: d.moeda, previsao_entrega: d.previsao_entrega,
    condicao_pagamento: d.condicao_pagamento, origem: d.origem, origem_id: d.origem_id,
    itens: d.itens.map((i) => ({ produto_id: i.produto_id, descricao: i.descricao, quantidade: i.quantidade, preco_unitario_centavos: i.preco_unitario_centavos })),
  };
}

/** Completa descricao e unidade pelo produto do Estoque e confere se os produtos estao ativos. */
async function completarItens(refs: ConsultarReferenciasDocumento, itens: EntradaItem[] | undefined): Promise<Result<EntradaItem[] | undefined>> {
  if (!itens) return ok(undefined);
  const ids = [...new Set(itens.map((i) => i.produto_id).filter((x): x is string => !!x))];
  if (!ids.length) return ok(itens);
  const produtos = new Map((await refs.produtosAtivos(ids)).map((p) => [p.id, p]));
  const faltam = ids.filter((id) => !produtos.has(id));
  if (faltam.length) return fail(erroDe('produto_invalido', 'Produto nao encontrado ou arquivado no Estoque', 'itens', { faltam }));
  return ok(itens.map((i) => {
    const p = i.produto_id ? produtos.get(i.produto_id) : undefined;
    return p ? { ...i, descricao: i.descricao?.trim() ? i.descricao : p.nome, unidade: i.unidade?.trim() ? i.unidade : p.unidade } : i;
  }));
}

async function conferirFornecedor(refs: ConsultarReferenciasDocumento, id: string | null | undefined): Promise<Result<FornecedorCompra | null>> {
  if (!id) return ok(null);
  const f = await refs.fornecedorAtivo(id);
  return f ? ok(f) : fail(erroDe('fornecedor_invalido', 'Fornecedor nao encontrado ou arquivado em Compras', 'fornecedor_id'));
}

async function auditarCriacao(ctx: ContextoCaso, d: DocumentoDados, f: FornecedorCompra | null) {
  await ctx.efeitos.auditar(`${d.tipo}.criar`, TABELA_DOCUMENTOS, d.id, undefined, d);
  if (d.tipo === 'requisicao') await ctx.efeitos.publicar('requisicao_compra.criada', resumo(d));
  if (d.tipo === 'pedido') await ctx.efeitos.publicar('pedido_compra.criado', resumo(d, f));
}

export class CriarDocumento {
  constructor(private readonly deps: DepsDocumento) {}

  async execute(ctx: ContextoCaso, e: DadosDocumento): Promise<Result<{ id: string; numero: string }>> {
    const itens = await completarItens(this.deps.refs, e.itens);
    if (!itens.ok) return itens;
    const f = await conferirFornecedor(this.deps.refs, e.fornecedor_id);
    if (!f.ok) return f;
    const forn = f.valor;
    const r = DocumentoCompra.tryCreate({
      ...e, itens: itens.valor ?? [],
      condicao_pagamento: e.condicao_pagamento ?? (e.tipo !== 'requisicao' ? forn?.condicao_pagamento ?? null : null),
      previsao_entrega: e.previsao_entrega ?? (forn && e.tipo === 'pedido' ? somarDias(hojeIso(), forn.prazo_entrega_dias) : null),
    });
    if (!r.ok) return r;
    const doc = r.valor.numerar(await this.deps.numeracao.proximoNumero(SEQUENCIA[e.tipo]));
    await this.deps.repo.inserir(doc);
    const d = doc.paraDados();
    await auditarCriacao(ctx, d, forn);
    return ok({ id: d.id, numero: d.numero });
  }
}

export class EditarDocumento {
  constructor(private readonly deps: { repo: ObterDocumento & GravarDocumento; refs: ConsultarReferenciasDocumento }) {}

  async execute(ctx: ContextoCaso, e: { id: string } & Partial<Omit<DadosDocumento, 'tipo' | 'origem' | 'origem_id' | 'origem_ref'>>): Promise<Result<void>> {
    const { id, ...mud } = e;
    const atual = await this.deps.repo.obterPorId(id);
    if (!atual) return fail(erroDe('nao_encontrado', 'Documento de compra nao encontrado'));
    const itens = await completarItens(this.deps.refs, mud.itens);
    if (!itens.ok) return itens;
    if (mud.fornecedor_id !== undefined && mud.fornecedor_id !== atual.fornecedorId) {
      const f = await conferirFornecedor(this.deps.refs, mud.fornecedor_id);
      if (!f.ok) return f;
    }
    const r = atual.editar({ ...mud, ...(itens.valor ? { itens: itens.valor } : {}) });
    if (!r.ok) return r;
    await this.deps.repo.atualizar(r.valor);
    const antes = atual.paraDados() as unknown as Record<string, unknown>;
    const depois = r.valor.paraDados() as unknown as Record<string, unknown>;
    await ctx.efeitos.historico(TABELA_DOCUMENTOS, id, antes, depois);
    await ctx.efeitos.auditar(`${atual.tipo}.editar`, TABELA_DOCUMENTOS, id, antes, depois);
    return okVazio();
  }
}

export class MudarEstadoDocumento {
  constructor(private readonly deps: { repo: ObterDocumento & GravarDocumento & ListarCotacoesIrmas; refs: ConsultarReferenciasDocumento; precos: HistoricoPrecos }) {}

  async execute(ctx: ContextoCaso, e: { id: string; estado: EstadoDocumento; motivo?: string | null }): Promise<Result<{ canceladas: string[] }>> {
    const atual = await this.deps.repo.obterPorId(e.id);
    if (!atual) return fail(erroDe('nao_encontrado', 'Documento de compra nao encontrado'));
    const r = atual.mudarEstado(e.estado);
    if (!r.ok) return r;
    const doc = r.valor;
    const d = doc.paraDados();
    if (d.fornecedor_id && (e.estado === 'enviado' || e.estado === 'confirmado')) {
      const f = await conferirFornecedor(this.deps.refs, d.fornecedor_id);
      if (!f.ok) return f;
    }
    await this.deps.repo.atualizar(doc);
    await ctx.efeitos.historico(TABELA_DOCUMENTOS, e.id, { estado: atual.estado }, { estado: doc.estado });
    await ctx.efeitos.auditar(`${d.tipo}.mudar_estado`, TABELA_DOCUMENTOS, e.id, { estado: atual.estado }, { estado: doc.estado, motivo: e.motivo ?? null });
    if (e.motivo?.trim()) await ctx.efeitos.nota(TABELA_DOCUMENTOS, e.id, `${NOME[d.tipo]} ${d.numero}: ${e.estado}. Motivo: ${e.motivo.trim()}`);

    const canceladas: string[] = [];
    if (e.estado === 'confirmado' && d.tipo !== 'requisicao' && d.fornecedor_id) {
      await this.deps.precos.registrarPrecos(doc.precosDoDocumento().map((p) => ({
        ...p, fornecedor_id: d.fornecedor_id!, moeda: d.moeda, origem: d.tipo === 'cotacao' ? 'cotacao' as const : 'pedido' as const, documento_id: d.id, data: hojeIso(),
      })));
    }
    if (d.tipo === 'cotacao' && e.estado === 'confirmado') {
      if (d.origem_id) {
        for (const irma of await this.deps.repo.cotacoesAbertas(d.origem_id, d.id)) {
          const c = irma.mudarEstado('cancelado');
          if (!c.ok) continue;
          await this.deps.repo.atualizar(c.valor);
          await ctx.efeitos.historico(TABELA_DOCUMENTOS, irma.id, { estado: irma.estado }, { estado: 'cancelado' });
          await ctx.efeitos.nota(TABELA_DOCUMENTOS, irma.id, `Cotacao ${irma.numero} cancelada: escolhida a cotacao ${d.numero}`);
          canceladas.push(irma.id);
        }
      }
      await ctx.efeitos.publicar('cotacao_compra.escolhida', { ...resumo(d), canceladas });
    }
    if (d.tipo === 'pedido' && (e.estado === 'confirmado' || e.estado === 'cancelado')) {
      const f = d.fornecedor_id ? await this.deps.refs.fornecedorAtivo(d.fornecedor_id) : null;
      await ctx.efeitos.publicar(e.estado === 'confirmado' ? 'pedido_compra.confirmado' : 'pedido_compra.cancelado', resumo(d, f));
    }
    return ok({ canceladas });
  }
}

export class ExcluirDocumentoCompra {
  constructor(private readonly deps: { repo: ObterDocumento & ExcluirDocumento }) {}

  async execute(ctx: ContextoCaso, e: { id: string }): Promise<Result<void>> {
    const atual = await this.deps.repo.obterPorId(e.id);
    if (!atual) return fail(erroDe('nao_encontrado', 'Documento de compra nao encontrado'));
    if (atual.estado !== 'rascunho' && atual.estado !== 'cancelado') {
      return fail(erroDe('transicao_invalida', 'So rascunho ou cancelado pode ser excluido', 'estado', { estado: atual.estado }));
    }
    await this.deps.repo.excluir(e.id);
    await ctx.efeitos.auditar(`${atual.tipo}.excluir`, TABELA_DOCUMENTOS, e.id, atual.paraDados(), undefined);
    return okVazio();
  }
}

/** Requisicao aprovada gera uma cotacao por fornecedor, com preco sugerido pelo historico (M10.4). */
export class GerarCotacoes {
  constructor(private readonly deps: DepsDocumento & { precos: HistoricoPrecos }) {}

  async execute(ctx: ContextoCaso, e: { requisicao_id: string; fornecedor_ids: string[] }): Promise<Result<{ ids: string[] }>> {
    const req = await this.deps.repo.obterPorId(e.requisicao_id);
    if (!req || req.tipo !== 'requisicao') return fail(erroDe('nao_encontrado', 'Requisicao nao encontrada'));
    const fornecedores = [...new Set(e.fornecedor_ids ?? [])];
    if (!fornecedores.length) return fail(erroDe('fornecedor_obrigatorio', 'Escolha ao menos um fornecedor', 'fornecedor_ids'));
    const erros: ErroDominio[] = [];
    const novos: DocumentoCompra[] = [];
    const produtos = req.paraDados().itens.map((i) => i.produto_id).filter((x): x is string => !!x);
    for (const fid of fornecedores) {
      const f = await this.deps.refs.fornecedorAtivo(fid);
      if (!f) { erros.push(erroDe('fornecedor_invalido', 'Fornecedor nao encontrado ou arquivado', 'fornecedor_ids', { fornecedor_id: fid })); continue; }
      const sugeridos = produtos.length ? await this.deps.precos.ultimosPrecos(fid, produtos) : new Map<string, number>();
      const r = req.derivar({ id: fid, condicao_pagamento: f.condicao_pagamento, previsao_entrega: somarDias(hojeIso(), f.prazo_entrega_dias) }, sugeridos);
      if (!r.ok) return r;
      novos.push(r.valor);
    }
    if (erros.length) return fail(...erros);
    const ids: string[] = [];
    for (const n of novos) {
      const doc = n.numerar(await this.deps.numeracao.proximoNumero(SEQUENCIA.cotacao));
      await this.deps.repo.inserir(doc);
      await ctx.efeitos.auditar('cotacao.criar', TABELA_DOCUMENTOS, doc.id, undefined, doc.paraDados());
      ids.push(doc.id);
    }
    await ctx.efeitos.nota(TABELA_DOCUMENTOS, req.id, `${ids.length} cotacao(oes) gerada(s) a partir da requisicao ${req.numero}`);
    return ok({ ids });
  }
}

/** Cotacao escolhida (confirmada) vira pedido em rascunho com os mesmos itens e precos. */
export class GerarPedido {
  constructor(private readonly deps: DepsDocumento) {}

  async execute(ctx: ContextoCaso, e: { cotacao_id: string }): Promise<Result<{ id: string; numero: string }>> {
    const cot = await this.deps.repo.obterPorId(e.cotacao_id);
    if (!cot || cot.tipo !== 'cotacao') return fail(erroDe('nao_encontrado', 'Cotacao nao encontrada'));
    const f = await this.deps.refs.fornecedorAtivo(cot.fornecedorId ?? '');
    if (!f) return fail(erroDe('fornecedor_invalido', 'Fornecedor da cotacao nao encontrado ou arquivado', 'fornecedor_id'));
    const r = cot.derivar({ id: f.id, condicao_pagamento: f.condicao_pagamento, previsao_entrega: somarDias(hojeIso(), f.prazo_entrega_dias) });
    if (!r.ok) return r;
    const doc = r.valor.numerar(await this.deps.numeracao.proximoNumero(SEQUENCIA.pedido));
    await this.deps.repo.inserir(doc);
    const d = doc.paraDados();
    await auditarCriacao(ctx, d, f);
    await ctx.efeitos.nota(TABELA_DOCUMENTOS, cot.id, `Pedido ${d.numero} gerado a partir da cotacao ${cot.numero}`);
    return ok({ id: d.id, numero: d.numero });
  }
}

export interface AlertaReposicao {
  alerta_id: string;
  produto_id: string;
  sku?: string;
  nome?: string;
  saldo?: number;
  estoque_minimo?: number;
  sugestao_compra?: number;
}

/**
 * Reacao a estoque.abaixo_minimo (CONTRATOS 7.1.9): abre requisicao em rascunho com a sugestao de compra.
 * Idempotente pelo id do alerta e nao duplica requisicao de reposicao aberta para o mesmo produto.
 */
export class AbrirRequisicaoReposicao {
  constructor(private readonly deps: DepsDocumento & { busca: BuscarDocumentoPorOrigem }) {}

  async execute(ctx: ContextoCaso, a: AlertaReposicao): Promise<Result<{ id: string | null; criada: boolean }>> {
    const ref = `reposicao:${a.alerta_id}`;
    const ja = await this.deps.busca.buscarPorOrigemRef(ref);
    if (ja) return ok({ id: ja.id, criada: false });
    if (await this.deps.busca.requisicaoReposicaoAberta(a.produto_id)) return ok({ id: null, criada: false });
    // Produto arquivado ou removido depois do alerta: nao ha o que repor e o evento encerra sem erro.
    if (!(await this.deps.refs.produtosAtivos([a.produto_id])).length) return ok({ id: null, criada: false });
    const sugestao = Number(a.sugestao_compra);
    const minimo = Number(a.estoque_minimo ?? 0);
    const saldo = Number(a.saldo ?? 0);
    const quantidade = Number.isFinite(sugestao) && sugestao > 0 ? sugestao : Math.max(minimo - saldo, 1);
    const r = await new CriarDocumento(this.deps).execute(ctx, {
      tipo: 'requisicao', origem: 'reposicao', origem_ref: ref,
      observacoes: `Aberta pela reposicao do Estoque: saldo ${saldo} abaixo do minimo ${minimo}${a.sku ? ` (SKU ${a.sku})` : ''}.`,
      itens: [{ produto_id: a.produto_id, quantidade }],
    });
    return r.ok ? ok({ id: r.valor.id, criada: true }) : r;
  }
}
