/** Consultas de leitura do DocumentoCompra: lista por tipo e ficha com itens, origem, derivados e recebimentos. */
import type pg from 'pg';
import { decodificarCursor, pagina } from '../../compartilhado/cursor.ts';

const RESUMO = `d.id, d.tipo, d.numero, d.fornecedor_id, coalesce(p.nome_fantasia, p.nome) AS fornecedor_nome, d.origem, d.origem_id,
  o.numero AS origem_numero, d.moeda, to_char(d.previsao_entrega, 'YYYY-MM-DD') AS previsao_entrega, d.condicao_pagamento,
  d.observacoes, d.estado, d.total_centavos::float8 AS total_centavos, d.creator_id, u.nome AS criado_por,
  d.enviado_em, d.confirmado_em, d.recebido_em, d.cancelado_em, d.created_at, d.updated_at,
  (SELECT count(*)::int FROM compras_itens i WHERE i.documento_id = d.id AND i.deleted_at IS NULL) AS qtd_itens,
  (SELECT CASE WHEN sum(i.quantidade) > 0 THEN round(100 * sum(i.quantidade_recebida) / sum(i.quantidade))::int ELSE 0 END
     FROM compras_itens i WHERE i.documento_id = d.id AND i.deleted_at IS NULL) AS percentual_recebido`;

const JUNCOES = `FROM compras_documentos d
  LEFT JOIN compras_fornecedores f ON f.id = d.fornecedor_id
  LEFT JOIN cadastros_parceiros p ON p.id = f.parceiro_id
  LEFT JOIN compras_documentos o ON o.id = d.origem_id
  LEFT JOIN usuarios u ON u.id = d.creator_id`;

export interface FiltroDocumentos {
  tipo?: 'requisicao' | 'cotacao' | 'pedido';
  estado?: string;
  fornecedor_id?: string;
  origem_id?: string;
  busca?: string;
  limite?: number;
  cursor?: string;
}

export async function listarDocumentos(c: pg.PoolClient, f: FiltroDocumentos) {
  const lim = Math.min(Math.max(f.limite ?? 50, 1), 200);
  const cur = decodificarCursor(f.cursor);
  const r = await c.query(
    `SELECT ${RESUMO} ${JUNCOES}
     WHERE d.deleted_at IS NULL AND ($1::text IS NULL OR d.tipo = $1) AND ($2::text IS NULL OR d.estado = $2)
       AND ($3::uuid IS NULL OR d.fornecedor_id = $3) AND ($4::uuid IS NULL OR d.origem_id = $4)
       AND ($5::text IS NULL OR d.numero ILIKE '%' || $5 || '%' OR p.nome ILIKE '%' || $5 || '%' OR p.nome_fantasia ILIKE '%' || $5 || '%'
            OR EXISTS (SELECT 1 FROM compras_itens i WHERE i.documento_id = d.id AND i.deleted_at IS NULL AND i.descricao ILIKE '%' || $5 || '%'))
       AND ($6::timestamptz IS NULL OR (d.created_at, d.id) > ($6::timestamptz, $7::uuid))
     ORDER BY d.created_at, d.id LIMIT $8`,
    [f.tipo ?? null, f.estado ?? null, f.fornecedor_id ?? null, f.origem_id ?? null, f.busca?.trim() || null, cur?.[0] ?? null, cur?.[1] ?? null, lim + 1],
  );
  return pagina(r.rows, lim);
}

export async function obterDocumento(c: pg.PoolClient, id: string) {
  const r = await c.query(
    `SELECT ${RESUMO}, d.extras,
       coalesce((SELECT json_agg(json_build_object('id', i.id, 'ordem', i.ordem, 'produto_id', i.produto_id, 'sku', ep.sku,
          'descricao', i.descricao, 'unidade', i.unidade, 'quantidade', i.quantidade::float8,
          'preco_unitario_centavos', i.preco_unitario_centavos::float8, 'total_centavos', i.total_centavos::float8,
          'quantidade_recebida', i.quantidade_recebida::float8, 'pendente', (i.quantidade - i.quantidade_recebida)::float8) ORDER BY i.ordem)
        FROM compras_itens i LEFT JOIN estoque_produtos ep ON ep.id = i.produto_id
        WHERE i.documento_id = d.id AND i.deleted_at IS NULL), '[]') AS itens,
       coalesce((SELECT json_agg(json_build_object('id', x.id, 'tipo', x.tipo, 'numero', x.numero, 'estado', x.estado,
          'total_centavos', x.total_centavos::float8, 'fornecedor_id', x.fornecedor_id) ORDER BY x.created_at)
        FROM compras_documentos x WHERE x.origem_id = d.id AND x.deleted_at IS NULL), '[]') AS derivados,
       coalesce((SELECT json_agg(json_build_object('id', rc.id, 'numero', rc.numero, 'data', to_char(rc.data, 'YYYY-MM-DD'), 'tipo', rc.tipo,
          'total_centavos', rc.total_centavos::float8, 'nota_fiscal', rc.nota_fiscal) ORDER BY rc.created_at)
        FROM compras_recebimentos rc WHERE rc.pedido_id = d.id AND rc.deleted_at IS NULL), '[]') AS recebimentos
     ${JUNCOES} WHERE d.id = $1 AND d.deleted_at IS NULL`, [id]);
  return r.rows[0] ?? null;
}

/** Opcoes dos formularios: fornecedores ativos de Compras, produtos ativos e depositos ativos do Estoque (tabelas publicadas). */
export async function opcoesCompras(c: pg.PoolClient) {
  const [fornecedores, produtos, depositos] = await Promise.all([
    c.query(`SELECT f.id, coalesce(p.nome_fantasia, p.nome) AS nome, f.condicao_pagamento, f.prazo_entrega_dias
             FROM compras_fornecedores f JOIN cadastros_parceiros p ON p.id = f.parceiro_id
             WHERE f.estado = 'ativo' AND f.deleted_at IS NULL ORDER BY 2 LIMIT 500`),
    c.query(`SELECT id, sku, nome, unidade, round(custo * 100)::float8 AS custo_centavos FROM estoque_produtos
             WHERE estado = 'ativo' AND deleted_at IS NULL ORDER BY nome LIMIT 500`),
    c.query(`SELECT id, codigo, nome FROM estoque_depositos WHERE estado = 'ativo' AND deleted_at IS NULL ORDER BY nome LIMIT 100`),
  ]);
  return { fornecedores: fornecedores.rows, produtos: produtos.rows, depositos: depositos.rows };
}
