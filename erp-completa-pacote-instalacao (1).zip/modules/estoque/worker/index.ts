/**
 * Handlers de worker do Estoque (carregados pelo worker do nucleo na partida).
 * `c` ja esta numa transacao do papel erp_worker com o escopo do job (RLS vale).
 */
import type { HandlersModulo } from '@erp/api/sdk/puro';
import { contextoPg } from '../api/compartilhado/efeitos-pg.ts';
import { casosDeUso } from '../api/fabrica.ts';
import { TIPO_JOB_REPOSICAO } from '../api/movimentacao/use-case/movimentacoes.ts';

const SISTEMA = { tipo: 'sistema' as const, id: null };

const handlers: HandlersModulo = {
  // M9.4 Reposicao: abre alerta e publica estoque.abaixo_minimo; resolve quando o saldo volta ao minimo.
  [TIPO_JOB_REPOSICAO]: async (d, c) => {
    const p = (d.payload ?? {}) as { produto_ids?: string[]; todos?: boolean };
    const r = await casosDeUso(c).verificarReposicao.execute(contextoPg(c, SISTEMA), { produto_ids: p.todos ? undefined : p.produto_ids });
    if (!r.ok) throw new Error(r.erros.map((e) => e.mensagem).join('; '));
  },

  // CONTRATOS 7.1.1: quem guarda parceiro_id reaponta os removidos para o mantido.
  'estoque:ao:parceiro.mesclado': async (d, c) => {
    const ev = (d.payload ?? {}) as { dados?: { mantido_id?: string; removidos_ids?: string[] } };
    const dados = ev.dados ?? {};
    if (!dados.mantido_id) return;
    const r = await casosDeUso(c).reapontarParceiro.execute(contextoPg(c, SISTEMA), { mantido_id: dados.mantido_id, removidos_ids: dados.removidos_ids ?? [] });
    if (!r.ok) throw new Error(r.erros.map((e) => e.mensagem).join('; '));
  },
};

export default handlers;
