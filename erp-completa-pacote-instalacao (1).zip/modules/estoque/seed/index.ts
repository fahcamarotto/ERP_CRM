/**
 * Seed demo do Estoque: unidades, depositos com locais, produtos (com grade de atributos, variacoes e
 * controle de lote), entradas com lote e validade, saida, transferencia, ajuste, verificacao de reposicao
 * e um inventario aberto. Idempotente: ids deterministicos por chave e movimentacoes marcadas por documento.
 * Grava pelas entidades, adaptadores e casos de uso do modulo, com as mesmas regras da API.
 */
import { createHash } from 'node:crypto';
import type { SeedModulo } from '@erp/api/sdk/puro';
import { contextoPg } from '../api/compartilhado/efeitos-pg.ts';
import { exigirOk } from '../api/compartilhado/result.ts';
import { DepositoRepoPg } from '../api/deposito/adapter/deposito-repo-pg.ts';
import { Deposito, Local } from '../api/deposito/model/deposito.ts';
import { casosDeUso } from '../api/fabrica.ts';
import type { EntradaMovimentacao } from '../api/movimentacao/use-case/movimentacoes.ts';
import { ProdutoRepoPg } from '../api/produto/adapter/produto-repo-pg.ts';
import { CodigoBarras } from '../api/produto/model/codigo-barras.ts';
import { Produto, Unidade, Variacao, type DadosProduto } from '../api/produto/model/produto.ts';

/** uuid deterministico a partir de uma chave (mesmo id em toda execucao). */
function idDe(chave: string): string {
  const h = createHash('sha256').update(`estoque-demo:${chave}`).digest('hex');
  return `${h.slice(0, 8)}-${h.slice(8, 12)}-4${h.slice(13, 16)}-a${h.slice(17, 20)}-${h.slice(20, 32)}`;
}

const diaMais = (dias: number) => { const d = new Date(); d.setUTCDate(d.getUTCDate() + dias); return d.toISOString().slice(0, 10); };

const UNIDADES = [{ sigla: 'FD', nome: 'Fardo', casas: 0 }, { sigla: 'RL', nome: 'Rolo', casas: 0 }];

const DEPOSITOS = [
  { k: 'cd', codigo: 'CD01', nome: 'Centro de distribuição', endereco: 'Rodovia Anhanguera, km 24, São Paulo SP', locais: ['A-01', 'A-02', 'B-01'] },
  { k: 'loja', codigo: 'LJ01', nome: 'Loja Centro', endereco: 'Rua Direita, 210, Centro, São Paulo SP', locais: ['VITRINE', 'RESERVA'] },
  { k: 'avaria', codigo: 'AVR', nome: 'Avarias e devoluções', endereco: null, locais: [] },
];

const PRODUTOS: (DadosProduto & { k: string; barras?: string })[] = [
  { k: 'papel', sku: 'PAP-A4-500', nome: 'Papel sulfite A4 75g resma 500 folhas', unidade: 'UN', barras: '789100000001', custo: 21.9, preco: 32.9, estoque_minimo: 80, descricao: 'Resma branca para impressora e copiadora.' },
  { k: 'caneta', sku: 'CAN-AZ-CX50', nome: 'Caneta esferográfica azul caixa com 50', unidade: 'CX', barras: '789100000002', custo: 38.5, preco: 59.9, estoque_minimo: 25 },
  { k: 'cafe', sku: 'CAF-TOR-500', nome: 'Café torrado e moído 500 g', unidade: 'UN', barras: '789100000003', custo: 14.2, preco: 22.5, estoque_minimo: 30, controla_lote: true },
  { k: 'detergente', sku: 'DET-NEU-500', nome: 'Detergente neutro 500 ml', unidade: 'UN', barras: '789100000004', custo: 2.1, preco: 3.99, estoque_minimo: 48, controla_lote: true },
  { k: 'camiseta', sku: 'CAM-BAS', nome: 'Camiseta básica algodão', unidade: 'PC', custo: 18, preco: 49.9, estoque_minimo: 0, atributos: { cor: ['Preta', 'Branca'], tamanho: ['P', 'M', 'G'] } },
  { k: 'hdmi', sku: 'CAB-HDMI-2M', nome: 'Cabo HDMI 2.0 2 metros', unidade: 'UN', barras: '789100000006', custo: 12.4, preco: 29.9, estoque_minimo: 15 },
  { k: 'fita', sku: 'FIT-ADS-45', nome: 'Fita adesiva transparente 45 mm x 100 m', unidade: 'RL', custo: 4.8, preco: 8.9, estoque_minimo: 20 },
  { k: 'acucar', sku: 'ACU-REF-KG', nome: 'Açúcar refinado', unidade: 'KG', custo: 4.35, preco: 6.49, estoque_minimo: 25 },
];

const VARIACOES = [
  { k: 'cam-p-pr', produto: 'camiseta', sku: 'CAM-BAS-PR-P', atributos: { cor: 'Preta', tamanho: 'P' } },
  { k: 'cam-m-pr', produto: 'camiseta', sku: 'CAM-BAS-PR-M', atributos: { cor: 'Preta', tamanho: 'M' } },
  { k: 'cam-g-pr', produto: 'camiseta', sku: 'CAM-BAS-PR-G', atributos: { cor: 'Preta', tamanho: 'G' } },
  { k: 'cam-m-br', produto: 'camiseta', sku: 'CAM-BAS-BR-M', atributos: { cor: 'Branca', tamanho: 'M' } },
];

const semear: SeedModulo = async ({ c, usuarioId, log }) => {
  const produtos = new ProdutoRepoPg(c);
  const depositos = new DepositoRepoPg(c);
  const casos = casosDeUso(c);
  const ctx = contextoPg(c, { tipo: 'usuario', id: usuarioId });
  let novos = 0;

  for (const u of UNIDADES) {
    if (await produtos.unidadeCadastrada(u.sigla)) continue;
    await produtos.inserirUnidade(Unidade.create(u, idDe(`unidade:${u.sigla}`)));
    novos++;
  }

  const dep = new Map<string, string>();
  const loc = new Map<string, string>();
  for (const d of DEPOSITOS) {
    const id = idDe(`deposito:${d.k}`);
    const existente = (await depositos.obterPorId(id)) ?? (await depositos.buscarPorCodigo(d.codigo));
    if (!existente) { await depositos.inserir(Deposito.create({ codigo: d.codigo, nome: d.nome, endereco: d.endereco }, id)); novos++; }
    const depId = existente?.id ?? id;
    dep.set(d.k, depId);
    for (const l of d.locais) {
      const lid = idDe(`local:${d.k}:${l}`);
      if (!(await depositos.localExiste(depId, l))) { await depositos.inserirLocal(Local.create({ deposito_id: depId, codigo: l }, lid)); novos++; }
      loc.set(`${d.k}:${l}`, (await c.query('SELECT id FROM estoque_locais WHERE deposito_id = $1 AND codigo = $2 AND deleted_at IS NULL', [depId, l])).rows[0].id);
    }
  }

  const fornecedores = (await c.query("SELECT id FROM cadastros_parceiros WHERE e_fornecedor AND estado = 'ativo' AND deleted_at IS NULL ORDER BY created_at LIMIT 2")).rows.map((r) => r.id as string);
  const prod = new Map<string, string>();
  for (const [i, p] of PRODUTOS.entries()) {
    const id = idDe(`produto:${p.k}`);
    const existente = (await produtos.obterPorId(id)) ?? (await produtos.buscarPorSku(p.sku));
    if (!existente) {
      const { k, barras, ...dados } = p;
      await produtos.inserir(Produto.create({ ...dados, codigo_barras: barras ? CodigoBarras.ean13(barras).valor : null, fornecedor_id: fornecedores[i % 2] ?? null }, id));
      novos++;
    }
    prod.set(p.k, existente?.id ?? id);
  }

  const vari = new Map<string, string>();
  for (const v of VARIACOES) {
    const id = idDe(`variacao:${v.k}`);
    if (!(await produtos.skuVariacaoEmUso(v.sku))) {
      const pai = (await produtos.obterPorId(prod.get(v.produto)!))!;
      await produtos.inserirVariacao(Variacao.create({ produto_id: pai.id, sku: v.sku, atributos: v.atributos }, pai.paraDados(), id));
      novos++;
    }
    vari.set(v.k, (await c.query('SELECT id FROM estoque_variacoes WHERE sku = $1 AND deleted_at IS NULL', [v.sku])).rows[0].id);
  }

  const P = (k: string) => prod.get(k)!;
  const MOVS: (EntradaMovimentacao & { documento: string })[] = [
    { documento: 'DEMO-NF-1001', tipo: 'entrada', motivo: 'Compra inicial de material de escritório', deposito_id: dep.get('cd')!, parceiro_id: fornecedores[0] ?? null, data: diaMais(-40), itens: [
      { produto_id: P('papel'), quantidade: 120, custo_unitario: 21.9, local_id: loc.get('cd:A-01') },
      { produto_id: P('caneta'), quantidade: 25, custo_unitario: 38.5, local_id: loc.get('cd:A-02') },
      { produto_id: P('fita'), quantidade: 60, custo_unitario: 4.8 },
      { produto_id: P('hdmi'), quantidade: 40, custo_unitario: 12.4, local_id: loc.get('cd:B-01') },
    ] },
    { documento: 'DEMO-NF-1002', tipo: 'entrada', motivo: 'Compra de copa e limpeza', deposito_id: dep.get('cd')!, parceiro_id: fornecedores[1] ?? null, data: diaMais(-30), itens: [
      { produto_id: P('cafe'), quantidade: 80, custo_unitario: 14.2, lote_codigo: 'CAF2609A', validade: diaMais(20) },
      { produto_id: P('cafe'), quantidade: 60, custo_unitario: 15.1, lote_codigo: 'CAF2610B', validade: diaMais(150) },
      { produto_id: P('detergente'), quantidade: 96, custo_unitario: 2.1, lote_codigo: 'DT-7781', validade: diaMais(400) },
      { produto_id: P('acucar'), quantidade: 50.5, custo_unitario: 4.35 },
    ] },
    { documento: 'DEMO-NF-1003', tipo: 'entrada', motivo: 'Reposição de camisetas para a loja', deposito_id: dep.get('loja')!, data: diaMais(-20), itens: [
      { produto_id: P('camiseta'), variacao_id: vari.get('cam-p-pr'), quantidade: 12, custo_unitario: 18, local_id: loc.get('loja:VITRINE') },
      { produto_id: P('camiseta'), variacao_id: vari.get('cam-m-pr'), quantidade: 20, custo_unitario: 18, local_id: loc.get('loja:VITRINE') },
      { produto_id: P('camiseta'), variacao_id: vari.get('cam-g-pr'), quantidade: 8, custo_unitario: 18.6, local_id: loc.get('loja:RESERVA') },
      { produto_id: P('camiseta'), variacao_id: vari.get('cam-m-br'), quantidade: 15, custo_unitario: 17.4, local_id: loc.get('loja:VITRINE') },
    ] },
    { documento: 'DEMO-TR-2001', tipo: 'transferencia', motivo: 'Abastecimento semanal da Loja Centro', deposito_id: dep.get('cd')!, deposito_destino_id: dep.get('loja')!, data: diaMais(-12), itens: [
      { produto_id: P('papel'), quantidade: 30, local_id: loc.get('cd:A-01'), local_destino_id: loc.get('loja:RESERVA') },
      { produto_id: P('hdmi'), quantidade: 10, local_id: loc.get('cd:B-01'), local_destino_id: loc.get('loja:VITRINE') },
    ] },
    { documento: 'DEMO-REQ-3001', tipo: 'saida', motivo: 'Consumo interno do escritório de setembro', deposito_id: dep.get('cd')!, data: diaMais(-6), itens: [
      { produto_id: P('papel'), quantidade: 62, local_id: loc.get('cd:A-01') },
      { produto_id: P('caneta'), quantidade: 4, local_id: loc.get('cd:A-02') },
      { produto_id: P('cafe'), quantidade: 55, lote_codigo: null, lote_id: null },
    ] },
    { documento: 'DEMO-AJ-4001', tipo: 'ajuste', motivo: 'Fita danificada na umidade do galpão', deposito_id: dep.get('cd')!, data: diaMais(-3), itens: [
      { produto_id: P('fita'), quantidade: -6 },
    ] },
  ];

  for (const m of MOVS) {
    if ((await c.query('SELECT 1 FROM estoque_movimentacoes WHERE documento = $1 AND deleted_at IS NULL', [m.documento])).rowCount) continue;
    if (m.documento === 'DEMO-REQ-3001') {
      const lote = (await c.query("SELECT id FROM estoque_lotes WHERE produto_id = $1 AND codigo = 'CAF2609A' AND deleted_at IS NULL", [P('cafe')])).rows[0]?.id;
      m.itens[2]!.lote_id = lote;
    }
    exigirOk(await casos.registrarMovimentacao.execute(ctx, m));
    novos++;
  }

  // M9.4: roda a verificacao na hora para a aba Reposicao ja nascer com alertas (o job da outbox repete, idempotente).
  exigirOk(await casos.verificarReposicao.execute(ctx, {}));

  // M9.5: inventario aberto na Loja Centro com parte da contagem feita.
  const descricao = 'Contagem mensal da Loja Centro (demo)';
  if (!(await c.query('SELECT 1 FROM estoque_inventarios WHERE descricao = $1 AND deleted_at IS NULL', [descricao])).rowCount
      && !(await c.query("SELECT 1 FROM estoque_inventarios WHERE deposito_id = $1 AND estado = 'aberto' AND deleted_at IS NULL", [dep.get('loja')])).rowCount) {
    const { id } = exigirOk(await casos.abrirInventario.execute(ctx, { deposito_id: dep.get('loja')!, descricao }));
    const itens = (await c.query('SELECT id, quantidade_sistema::float8 AS q FROM estoque_inventario_itens WHERE inventario_id = $1 ORDER BY created_at, id', [id])).rows;
    const contagens = itens.slice(0, 3).map((x, i) => ({ item_id: x.id as string, quantidade_contada: i === 1 ? Number(x.q) - 1 : Number(x.q) }));
    if (contagens.length) exigirOk(await casos.registrarContagem.execute(ctx, { id, contagens }));
    novos++;
  }

  log(`${novos} registro(s) demo novo(s) (${UNIDADES.length} unidades, ${DEPOSITOS.length} depósitos, ${PRODUTOS.length} produtos, ${VARIACOES.length} variações, ${MOVS.length} movimentações, 1 inventário)`);
};

export default semear;
