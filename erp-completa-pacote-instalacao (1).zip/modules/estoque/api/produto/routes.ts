/** Rotas REST do Produto fora das tools: edicao, estado, exclusao, variacoes, lotes, unidades, resumo e opcoes. */
import { esquemaErro, requer, type FastifyInstance } from '@erp/api/sdk';
import { naTransacao } from '../borda.ts';
import { exigirOk } from '../compartilhado/result.ts';
import { estadosCadastro, propsLote, propsProduto, propsUnidade, propsVariacao, uuid } from '../esquemas.ts';
import type { DadosLote, DadosProduto, DadosUnidade, DadosVariacao, EstadoProduto } from './model/produto.ts';
import { listarFornecedores, listarLotes, listarUnidades, listarVariacoes, obterProduto, resumoEstoque } from './query/produtos.ts';

const tags = ['estoque'];
const paramId = { type: 'object', required: ['id'], properties: { id: uuid } } as const;
const erros = { 400: esquemaErro, 403: esquemaErro, 404: esquemaErro, 409: esquemaErro };

export function rotasProduto(app: FastifyInstance): void {
  app.patch<{ Params: { id: string }; Body: Partial<DadosProduto> }>('/produtos/:id', {
    preHandler: requer('estoque.editar'),
    schema: { tags, summary: 'Edita produto (EditarProduto)', params: paramId, body: { type: 'object', additionalProperties: false, properties: propsProduto }, response: erros },
  }, (req) => naTransacao(req, async (casos, ctx, c) => {
    exigirOk(await casos.editarProduto.execute(ctx, { ...req.body, id: req.params.id }));
    return obterProduto(c, req.params.id);
  }));

  app.post<{ Params: { id: string }; Body: { estado: EstadoProduto } }>('/produtos/:id/estado', {
    preHandler: requer('estoque.editar'),
    schema: {
      tags, summary: 'Arquiva ou reativa produto (MudarEstadoProduto)', params: paramId,
      body: { type: 'object', additionalProperties: false, required: ['estado'], properties: { estado: { type: 'string', enum: [...estadosCadastro] } } }, response: erros,
    },
  }, (req) => naTransacao(req, async (casos, ctx, c) => {
    exigirOk(await casos.mudarEstadoProduto.execute(ctx, { id: req.params.id, estado: req.body.estado }));
    return obterProduto(c, req.params.id);
  }));

  app.delete<{ Params: { id: string } }>('/produtos/:id', {
    preHandler: requer('estoque.excluir'),
    schema: { tags, summary: 'Exclui produto sem movimentacao (exclusao logica)', params: paramId, response: erros },
  }, async (req, reply) => {
    await naTransacao(req, async (casos, ctx) => exigirOk(await casos.excluirProduto.execute(ctx, { id: req.params.id })));
    return reply.code(204).send();
  });

  app.get<{ Querystring: { produto_id?: string } }>('/variacoes', {
    preHandler: requer('estoque.ver'),
    schema: { tags, summary: 'Variacoes com produto e saldo', querystring: { type: 'object', additionalProperties: false, properties: { produto_id: uuid } } },
  }, (req) => naTransacao(req, (_, __, c) => listarVariacoes(c, req.query.produto_id)));

  app.post<{ Params: { id: string }; Body: Omit<DadosVariacao, 'produto_id'> }>('/produtos/:id/variacoes', {
    preHandler: requer('estoque.criar'),
    schema: { tags, summary: 'Cria variacao do produto (CriarVariacao)', params: paramId, body: { type: 'object', additionalProperties: false, required: ['sku'], properties: propsVariacao }, response: erros },
  }, async (req, reply) => reply.code(201).send(await naTransacao(req, async (casos, ctx, c) => {
    exigirOk(await casos.criarVariacao.execute(ctx, { ...req.body, produto_id: req.params.id }));
    return obterProduto(c, req.params.id);
  })));

  app.delete<{ Params: { id: string } }>('/variacoes/:id', {
    preHandler: requer('estoque.excluir'),
    schema: { tags, summary: 'Exclui variacao sem movimentacao', params: paramId, response: erros },
  }, async (req, reply) => {
    await naTransacao(req, async (casos, ctx) => exigirOk(await casos.excluirVariacao.execute(ctx, { id: req.params.id })));
    return reply.code(204).send();
  });

  app.get<{ Querystring: { produto_id?: string; situacao?: string } }>('/lotes', {
    preHandler: requer('estoque.ver'),
    schema: {
      tags, summary: 'Lotes com saldo e situacao da validade',
      querystring: { type: 'object', additionalProperties: false, properties: { produto_id: uuid, situacao: { type: 'string', enum: ['vencido', 'vencendo', 'ok', 'sem_validade'] } } },
    },
  }, (req) => naTransacao(req, (_, __, c) => listarLotes(c, req.query)));

  app.post<{ Body: DadosLote }>('/lotes', {
    preHandler: requer('estoque.criar'),
    schema: { tags, summary: 'Cria lote (CriarLote)', body: { type: 'object', additionalProperties: false, required: ['produto_id', 'codigo'], properties: propsLote }, response: erros },
  }, async (req, reply) => reply.code(201).send(await naTransacao(req, async (casos, ctx, c) => {
    const { id } = exigirOk(await casos.criarLote.execute(ctx, req.body));
    return (await listarLotes(c, { produto_id: req.body.produto_id })).find((l) => l.id === id);
  })));

  app.get('/unidades', {
    preHandler: requer('estoque.ver'),
    schema: { tags, summary: 'Unidades de medida (padrao e do workspace)' },
  }, (req) => naTransacao(req, (_, __, c) => listarUnidades(c)));

  app.post<{ Body: DadosUnidade }>('/unidades', {
    preHandler: requer('estoque.criar'),
    schema: { tags, summary: 'Cadastra unidade de medida (CriarUnidade)', body: { type: 'object', additionalProperties: false, required: ['sigla', 'nome'], properties: propsUnidade }, response: erros },
  }, async (req, reply) => reply.code(201).send(await naTransacao(req, async (casos, ctx, c) => {
    exigirOk(await casos.criarUnidade.execute(ctx, req.body));
    return listarUnidades(c);
  })));

  app.get('/resumo', {
    preHandler: requer('estoque.ver'),
    schema: { tags, summary: 'Valor em estoque, produtos ativos, abaixo do minimo e lotes vencidos ou vencendo' },
  }, (req) => naTransacao(req, (_, __, c) => resumoEstoque(c)));

  app.get('/fornecedores', {
    preHandler: requer('estoque.ver'),
    schema: { tags, summary: 'Fornecedores ativos do Cadastros (opcoes do formulario)' },
  }, (req) => naTransacao(req, (_, __, c) => listarFornecedores(c)));
}
