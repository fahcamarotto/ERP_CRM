/**
 * Casos de uso do Produto (M9.1, M9.6): criar, editar, arquivar ou reativar, excluir sem movimentacao,
 * variacoes, lotes, unidades e reapontamento de fornecedor mesclado no Cadastros.
 */
import { erroDe, fail, ok, okVazio, type ErroDominio, type Result } from '../../compartilhado/result.ts';
import type { ContextoCaso } from '../../compartilhado/efeitos.ts';
import { Lote, Produto, Unidade, Variacao, type DadosLote, type DadosProduto, type DadosUnidade, type DadosVariacao, type EstadoProduto } from '../model/produto.ts';
import type {
  ConsultarReferenciasProduto, ExcluirProduto, GravarLotes, GravarProduto, GravarUnidades, GravarVariacoes, ObterProduto, ReapontarParceiros,
} from '../model/portas.ts';

const TABELA = 'estoque_produtos';

export interface DepsProduto {
  repo: ObterProduto & GravarProduto;
  refs: ConsultarReferenciasProduto;
}

async function conferir(deps: DepsProduto, p: Produto, anterior?: Produto): Promise<ErroDominio[]> {
  const d = p.paraDados();
  const a = anterior?.paraDados();
  const erros: ErroDominio[] = [];
  if (d.sku !== a?.sku) {
    const outro = await deps.repo.buscarPorSku(d.sku);
    if (outro && outro.id !== d.id) erros.push(erroDe('conflito', `SKU ${d.sku} ja usado por outro produto`, 'sku', { produto_id: outro.id }));
  }
  if (d.codigo_barras && d.codigo_barras !== a?.codigo_barras) {
    const outro = await deps.repo.buscarPorCodigoBarras(d.codigo_barras);
    if (outro && outro.id !== d.id) erros.push(erroDe('conflito', 'Codigo de barras ja usado por outro produto', 'codigo_barras', { produto_id: outro.id }));
  }
  if (d.unidade !== a?.unidade && !(await deps.refs.unidadeExiste(d.unidade))) {
    erros.push(erroDe('unidade_invalida', `Unidade ${d.unidade} nao cadastrada`, 'unidade'));
  }
  if (d.fornecedor_id && d.fornecedor_id !== a?.fornecedor_id && !(await deps.refs.fornecedorAtivo(d.fornecedor_id))) {
    erros.push(erroDe('fornecedor_invalido', 'Fornecedor nao encontrado ou arquivado no Cadastros', 'fornecedor_id'));
  }
  return erros;
}

/** Conflito vem primeiro na lista para a borda responder 409. */
const ordenar = (e: ErroDominio[]) => [...e].sort((x, y) => Number(y.codigo === 'conflito') - Number(x.codigo === 'conflito'));

export class CriarProduto {
  constructor(private readonly deps: DepsProduto) {}
  async execute(ctx: ContextoCaso, e: DadosProduto): Promise<Result<{ id: string }>> {
    const r = Produto.tryCreate(e);
    if (!r.ok) return r;
    const erros = await conferir(this.deps, r.valor);
    if (erros.length) return fail(...ordenar(erros));
    await this.deps.repo.inserir(r.valor);
    const d = r.valor.paraDados();
    await ctx.efeitos.auditar('produto.criar', TABELA, d.id, undefined, d);
    return ok({ id: d.id });
  }
}

export class EditarProduto {
  constructor(private readonly deps: DepsProduto) {}
  async execute(ctx: ContextoCaso, e: { id: string } & Partial<DadosProduto>): Promise<Result<void>> {
    const { id, ...mud } = e;
    const atual = await this.deps.repo.obterPorId(id);
    if (!atual) return fail(erroDe('nao_encontrado', 'Produto nao encontrado'));
    const r = atual.editar(mud);
    if (!r.ok) return r;
    const erros = await conferir(this.deps, r.valor, atual);
    if (erros.length) return fail(...ordenar(erros));
    await this.deps.repo.atualizar(r.valor);
    const antes = atual.paraDados() as unknown as Record<string, unknown>;
    const depois = r.valor.paraDados() as unknown as Record<string, unknown>;
    await ctx.efeitos.historico(TABELA, id, antes, depois);
    await ctx.efeitos.auditar('produto.editar', TABELA, id, antes, depois);
    return okVazio();
  }
}

export class MudarEstadoProduto {
  constructor(private readonly deps: { repo: ObterProduto & GravarProduto }) {}
  async execute(ctx: ContextoCaso, e: { id: string; estado: EstadoProduto }): Promise<Result<void>> {
    const atual = await this.deps.repo.obterPorId(e.id);
    if (!atual) return fail(erroDe('nao_encontrado', 'Produto nao encontrado'));
    const r = atual.mudarEstado(e.estado);
    if (!r.ok) return r;
    await this.deps.repo.atualizar(r.valor);
    await ctx.efeitos.historico(TABELA, e.id, { estado: atual.estado }, { estado: e.estado });
    await ctx.efeitos.auditar(`produto.${e.estado === 'arquivado' ? 'arquivar' : 'reativar'}`, TABELA, e.id, { estado: atual.estado }, { estado: e.estado });
    return okVazio();
  }
}

export class ExcluirProdutoCaso {
  constructor(private readonly deps: { repo: ObterProduto & ExcluirProduto }) {}
  async execute(ctx: ContextoCaso, e: { id: string }): Promise<Result<void>> {
    const atual = await this.deps.repo.obterPorId(e.id);
    if (!atual) return fail(erroDe('nao_encontrado', 'Produto nao encontrado'));
    if (await this.deps.repo.temMovimentacao(e.id)) {
      return fail(erroDe('conflito', 'Produto com movimentacoes nao pode ser excluido; arquive o produto'));
    }
    await this.deps.repo.excluir(e.id);
    await ctx.efeitos.auditar('produto.excluir', TABELA, e.id, atual.paraDados(), undefined);
    return okVazio();
  }
}

export class CriarVariacao {
  constructor(private readonly deps: { repo: ObterProduto; variacoes: GravarVariacoes }) {}
  async execute(ctx: ContextoCaso, e: DadosVariacao): Promise<Result<{ id: string }>> {
    const produto = await this.deps.repo.obterPorId(e.produto_id);
    if (!produto) return fail(erroDe('nao_encontrado', 'Produto nao encontrado'));
    if (produto.estado !== 'ativo') return fail(erroDe('transicao_invalida', 'Produto arquivado nao recebe variacao'));
    const r = Variacao.tryCreate(e, produto.paraDados());
    if (!r.ok) return r;
    const sku = r.valor.dados.sku;
    if ((await this.deps.variacoes.skuVariacaoEmUso(sku)) || (await this.deps.repo.buscarPorSku(sku))) {
      return fail(erroDe('conflito', `SKU ${sku} ja usado`, 'sku'));
    }
    await this.deps.variacoes.inserirVariacao(r.valor);
    await ctx.efeitos.auditar('variacao.criar', 'estoque_variacoes', r.valor.dados.id, undefined, r.valor.dados);
    await ctx.efeitos.nota(TABELA, produto.id, `Variacao ${r.valor.dados.nome} (${sku}) criada`);
    return ok({ id: r.valor.dados.id });
  }
}

export class ExcluirVariacao {
  constructor(private readonly deps: { variacoes: GravarVariacoes }) {}
  async execute(ctx: ContextoCaso, e: { id: string }): Promise<Result<void>> {
    const v = await this.deps.variacoes.obterVariacao(e.id);
    if (!v) return fail(erroDe('nao_encontrado', 'Variacao nao encontrada'));
    if (await this.deps.variacoes.variacaoTemMovimentacao(e.id)) return fail(erroDe('conflito', 'Variacao com movimentacoes nao pode ser excluida'));
    await this.deps.variacoes.excluirVariacao(e.id);
    await ctx.efeitos.auditar('variacao.excluir', 'estoque_variacoes', e.id, v, undefined);
    return okVazio();
  }
}

export class CriarLote {
  constructor(private readonly deps: { repo: ObterProduto; lotes: GravarLotes }) {}
  async execute(ctx: ContextoCaso, e: DadosLote): Promise<Result<{ id: string }>> {
    const produto = await this.deps.repo.obterPorId(e.produto_id);
    if (!produto) return fail(erroDe('nao_encontrado', 'Produto nao encontrado'));
    const r = Lote.tryCreate(e);
    if (!r.ok) return r;
    if (await this.deps.lotes.buscarLote(e.produto_id, r.valor.dados.codigo)) {
      return fail(erroDe('conflito', `Lote ${r.valor.dados.codigo} ja existe para este produto`, 'codigo'));
    }
    await this.deps.lotes.inserirLote(r.valor);
    await ctx.efeitos.auditar('lote.criar', 'estoque_lotes', r.valor.dados.id, undefined, r.valor.dados);
    return ok({ id: r.valor.dados.id });
  }
}

export class CriarUnidade {
  constructor(private readonly deps: { unidades: GravarUnidades }) {}
  async execute(ctx: ContextoCaso, e: DadosUnidade): Promise<Result<{ id: string }>> {
    const r = Unidade.tryCreate(e);
    if (!r.ok) return r;
    if (await this.deps.unidades.unidadeCadastrada(r.valor.dados.sigla)) return fail(erroDe('conflito', `Unidade ${r.valor.dados.sigla} ja cadastrada`, 'sigla'));
    await this.deps.unidades.inserirUnidade(r.valor);
    await ctx.efeitos.auditar('unidade.criar', 'estoque_unidades', r.valor.dados.id, undefined, r.valor.dados);
    return ok({ id: r.valor.dados.id });
  }
}

/** Reacao a parceiro.mesclado (CONTRATOS 7.1.1): fornecedor e parceiro das movimentacoes passam ao mantido. */
export class ReapontarParceiro {
  constructor(private readonly deps: { repo: ReapontarParceiros }) {}
  async execute(ctx: ContextoCaso, e: { mantido_id: string; removidos_ids: string[] }): Promise<Result<{ alterados: number }>> {
    const removidos = (e.removidos_ids ?? []).filter((x) => x && x !== e.mantido_id);
    if (!e.mantido_id || removidos.length === 0) return ok({ alterados: 0 });
    const alterados = await this.deps.repo.reapontarParceiro(removidos, e.mantido_id);
    if (alterados) await ctx.efeitos.auditar('parceiro.reapontar', TABELA, null, { removidos }, { mantido_id: e.mantido_id, alterados });
    return ok({ alterados });
  }
}
