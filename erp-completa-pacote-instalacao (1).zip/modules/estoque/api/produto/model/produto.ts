/**
 * Agregado Produto (M9.1): SKU, unidade, codigo de barras, custo, preco, estoque minimo, atributos,
 * controle de lote e custo medio (M9.7, derivado das entradas). Filhas: Variacao e Lote (M9.6).
 * Imutavel: toda alteracao devolve um clone novo.
 */
import { randomUUID } from 'node:crypto';
import { combinar, erroDe, fail, ok, type ErroDominio, type Result } from '../../compartilhado/result.ts';
import { Codigo, dataValida, Dinheiro, Quantidade, texto } from '../../compartilhado/valores.ts';
import { CodigoBarras } from './codigo-barras.ts';

export const ESTADOS_PRODUTO = ['ativo', 'arquivado'] as const;
export type EstadoProduto = (typeof ESTADOS_PRODUTO)[number];

/** Unidades que valem em todo workspace sem cadastro (o catalogo estoque_unidades acrescenta outras). */
export const UNIDADES_PADRAO: Record<string, { nome: string; casas: number }> = {
  UN: { nome: 'Unidade', casas: 0 }, PC: { nome: 'Peca', casas: 0 }, CX: { nome: 'Caixa', casas: 0 },
  KG: { nome: 'Quilograma', casas: 3 }, G: { nome: 'Grama', casas: 0 }, L: { nome: 'Litro', casas: 3 },
  ML: { nome: 'Mililitro', casas: 0 }, M: { nome: 'Metro', casas: 3 },
};

/** Atributos: { cor: ['Azul', 'Preto'], tamanho: ['P', 'M'] } no produto; { cor: 'Azul' } na variacao. */
export type Atributos = Record<string, string[]>;

export interface DadosProduto {
  sku: string;
  nome: string;
  descricao?: string | null;
  unidade?: string;
  codigo_barras?: string | null;
  custo?: number;
  preco?: number;
  estoque_minimo?: number;
  controla_lote?: boolean;
  atributos?: Atributos;
  fornecedor_id?: string | null;
  extras?: Record<string, unknown>;
}

export interface ProdutoDados {
  id: string;
  sku: string;
  nome: string;
  descricao: string | null;
  unidade: string;
  codigo_barras: string | null;
  custo: number;
  custo_medio: number;
  preco: number;
  estoque_minimo: number;
  controla_lote: boolean;
  atributos: Atributos;
  fornecedor_id: string | null;
  estado: EstadoProduto;
  extras: Record<string, unknown>;
}

function normalizarAtributos(a: unknown): Result<Atributos> {
  if (a === undefined || a === null) return ok({});
  if (typeof a !== 'object' || Array.isArray(a)) return fail(erroDe('atributos_invalidos', 'Atributos devem ser um objeto { nome: [valores] }', 'atributos'));
  const r: Atributos = {};
  for (const [k, v] of Object.entries(a as Record<string, unknown>)) {
    const chave = k.trim().toLowerCase();
    const valores = (Array.isArray(v) ? v : [v]).map((x) => String(x ?? '').trim()).filter(Boolean);
    if (!chave || chave.length > 40 || valores.length === 0 || valores.length > 50 || valores.some((x) => x.length > 60)) {
      return fail(erroDe('atributos_invalidos', `Atributo ${k} invalido`, 'atributos'));
    }
    r[chave] = [...new Set(valores)];
  }
  return Object.keys(r).length > 20 ? fail(erroDe('atributos_invalidos', 'Maximo de 20 atributos', 'atributos')) : ok(r);
}

function montar(e: Partial<DadosProduto>, base: ProdutoDados): Result<ProdutoDados> {
  const tem = (k: keyof DadosProduto) => e[k] !== undefined;
  const r = combinar(
    tem('sku') ? Codigo.tryCreate(e.sku, 'sku', 40) : ok(null),
    tem('codigo_barras') && texto(e.codigo_barras) ? CodigoBarras.tryCreate(e.codigo_barras!) : ok(null),
    tem('custo') ? Dinheiro.tryCreate(e.custo, 'custo', 4) : ok(null),
    tem('preco') ? Dinheiro.tryCreate(e.preco, 'preco', 2) : ok(null),
    tem('estoque_minimo') ? Quantidade.tryCreate(e.estoque_minimo ?? 0, 'estoque_minimo', { naoNegativa: true }) : ok(null),
    tem('atributos') ? normalizarAtributos(e.atributos) : ok(null),
  );
  if (!r.ok) return r;
  const [sku, barras, custo, preco, minimo, atributos] = r.valor;
  const d: ProdutoDados = {
    ...base,
    sku: sku?.valor ?? base.sku,
    nome: tem('nome') ? (e.nome ?? '').trim() : base.nome,
    descricao: tem('descricao') ? texto(e.descricao) : base.descricao,
    unidade: tem('unidade') ? String(e.unidade ?? '').trim().toUpperCase() : base.unidade,
    codigo_barras: tem('codigo_barras') ? barras?.valor ?? null : base.codigo_barras,
    custo: custo?.valor ?? base.custo,
    preco: preco?.valor ?? base.preco,
    estoque_minimo: minimo?.valor ?? base.estoque_minimo,
    controla_lote: tem('controla_lote') ? !!e.controla_lote : base.controla_lote,
    atributos: atributos ?? { ...base.atributos },
    fornecedor_id: tem('fornecedor_id') ? texto(e.fornecedor_id) : base.fornecedor_id,
    extras: tem('extras') ? { ...e.extras } : { ...base.extras },
  };
  const erros: ErroDominio[] = [];
  if (d.nome.length < 2 || d.nome.length > 200) erros.push(erroDe('nome_invalido', 'Nome deve ter de 2 a 200 caracteres', 'nome'));
  if (!/^[A-Z0-9]{1,10}$/.test(d.unidade)) erros.push(erroDe('unidade_invalida', 'Unidade invalida (sigla de 1 a 10 letras ou numeros)', 'unidade'));
  return erros.length ? fail(...erros) : ok(d);
}

export class Produto {
  private constructor(private readonly d: ProdutoDados) {}

  static tryCreate(e: DadosProduto, id: string = randomUUID()): Result<Produto> {
    const vazio: ProdutoDados = {
      id, sku: '', nome: '', descricao: null, unidade: 'UN', codigo_barras: null, custo: 0, custo_medio: 0, preco: 0,
      estoque_minimo: 0, controla_lote: false, atributos: {}, fornecedor_id: null, estado: 'ativo', extras: {},
    };
    const r = montar({ ...e, sku: e.sku ?? '', nome: e.nome ?? '', unidade: e.unidade ?? 'UN' }, vazio);
    if (!r.ok) return r;
    return ok(new Produto({ ...r.valor, custo_medio: r.valor.custo }));
  }

  static create(e: DadosProduto, id?: string): Produto {
    const r = Produto.tryCreate(e, id);
    if (!r.ok) throw new Error(r.erros.map((x) => x.mensagem).join('; '));
    return r.valor;
  }

  static reidratar(d: ProdutoDados): Produto {
    return new Produto({ ...d, custo: Number(d.custo), custo_medio: Number(d.custo_medio), preco: Number(d.preco), estoque_minimo: Number(d.estoque_minimo), atributos: { ...d.atributos }, extras: { ...d.extras } });
  }

  get id(): string { return this.d.id; }
  get estado(): EstadoProduto { return this.d.estado; }

  editar(e: Partial<DadosProduto>): Result<Produto> {
    if (this.d.estado === 'arquivado') return fail(erroDe('transicao_invalida', 'Produto arquivado nao pode ser editado; reative antes'));
    const r = montar(e, this.d);
    return r.ok ? ok(new Produto(r.valor)) : r;
  }

  mudarEstado(novo: EstadoProduto): Result<Produto> {
    if (!ESTADOS_PRODUTO.includes(novo)) return fail(erroDe('estado_invalido', 'Estado invalido', 'estado'));
    if (novo === this.d.estado) return fail(erroDe('transicao_invalida', `Produto ja esta ${novo}`, 'estado', { permitidas: ESTADOS_PRODUTO.filter((x) => x !== novo) }));
    return ok(new Produto({ ...this.d, estado: novo }));
  }

  paraDados(): ProdutoDados {
    return { ...this.d, atributos: { ...this.d.atributos }, extras: { ...this.d.extras } };
  }
}

// Variacao (M9.1) ---------------------------------------------------------------------------
export interface DadosVariacao {
  produto_id: string;
  nome?: string | null;
  sku: string;
  codigo_barras?: string | null;
  atributos?: Record<string, string>;
  preco?: number | null;
}
export interface VariacaoDados {
  id: string;
  produto_id: string;
  nome: string;
  sku: string;
  codigo_barras: string | null;
  atributos: Record<string, string>;
  preco: number | null;
}

export class Variacao {
  private constructor(readonly dados: VariacaoDados) {}
  /** Os atributos da variacao precisam existir na grade de atributos do produto. */
  static tryCreate(e: DadosVariacao, produto: ProdutoDados, id: string = randomUUID()): Result<Variacao> {
    const atributos: Record<string, string> = {};
    const erros: ErroDominio[] = [];
    for (const [k, v] of Object.entries(e.atributos ?? {})) {
      const chave = k.trim().toLowerCase();
      const valor = String(v ?? '').trim();
      if (!produto.atributos[chave]?.includes(valor)) erros.push(erroDe('atributo_invalido', `Atributo ${chave}=${valor} nao existe no produto`, 'atributos', { permitidos: produto.atributos }));
      else atributos[chave] = valor;
    }
    const r = combinar(
      Codigo.tryCreate(e.sku, 'sku', 40),
      texto(e.codigo_barras) ? CodigoBarras.tryCreate(e.codigo_barras!) : ok(null),
      e.preco === undefined || e.preco === null ? ok(null) : Dinheiro.tryCreate(e.preco, 'preco', 2),
    );
    if (!r.ok) erros.push(...r.erros);
    const nome = texto(e.nome) ?? Object.values(atributos).join(' / ');
    if (!nome || nome.length > 120) erros.push(erroDe('nome_invalido', 'Informe o nome da variacao ou os atributos', 'nome'));
    if (erros.length || !r.ok) return fail(...erros);
    const [sku, barras, preco] = r.valor;
    return ok(new Variacao({ id, produto_id: produto.id, nome, sku: sku.valor, codigo_barras: barras?.valor ?? null, atributos, preco: preco?.valor ?? null }));
  }
  static create(e: DadosVariacao, produto: ProdutoDados, id?: string): Variacao {
    const r = Variacao.tryCreate(e, produto, id);
    if (!r.ok) throw new Error(r.erros.map((x) => x.mensagem).join('; '));
    return r.valor;
  }
}

// Lote e validade (M9.6) --------------------------------------------------------------------
export interface DadosLote { produto_id: string; codigo: string; fabricacao?: string | null; validade?: string | null }
export interface LoteDados { id: string; produto_id: string; codigo: string; fabricacao: string | null; validade: string | null }

export class Lote {
  private constructor(readonly dados: LoteDados) {}
  static tryCreate(e: DadosLote, id: string = randomUUID()): Result<Lote> {
    const d: LoteDados = { id, produto_id: e.produto_id, codigo: String(e.codigo ?? '').trim().toUpperCase(), fabricacao: texto(e.fabricacao), validade: texto(e.validade) };
    const erros: ErroDominio[] = [];
    if (!d.codigo || d.codigo.length > 60) erros.push(erroDe('lote_invalido', 'Codigo do lote deve ter de 1 a 60 caracteres', 'codigo'));
    if (!dataValida(d.fabricacao)) erros.push(erroDe('data_invalida', 'Fabricacao deve ser AAAA-MM-DD', 'fabricacao'));
    if (!dataValida(d.validade)) erros.push(erroDe('data_invalida', 'Validade deve ser AAAA-MM-DD', 'validade'));
    if (d.fabricacao && d.validade && dataValida(d.fabricacao) && dataValida(d.validade) && d.validade < d.fabricacao) erros.push(erroDe('validade_invalida', 'Validade antes da fabricacao', 'validade'));
    return erros.length ? fail(...erros) : ok(new Lote(d));
  }
  static create(e: DadosLote, id?: string): Lote {
    const r = Lote.tryCreate(e, id);
    if (!r.ok) throw new Error(r.erros.map((x) => x.mensagem).join('; '));
    return r.valor;
  }
}

/** Situacao do lote pela validade (vencido, vence em ate 30 dias, ok). */
export function situacaoLote(validade: string | null, hoje: string): 'vencido' | 'vencendo' | 'ok' | 'sem_validade' {
  if (!validade) return 'sem_validade';
  if (validade < hoje) return 'vencido';
  const limite = new Date(`${hoje}T00:00:00Z`);
  limite.setUTCDate(limite.getUTCDate() + 30);
  return validade <= limite.toISOString().slice(0, 10) ? 'vencendo' : 'ok';
}

// Unidade de medida (M9.1) ------------------------------------------------------------------
export interface DadosUnidade { sigla: string; nome: string; casas?: number }
export interface UnidadeDados { id: string; sigla: string; nome: string; casas: number }

export class Unidade {
  private constructor(readonly dados: UnidadeDados) {}
  static tryCreate(e: DadosUnidade, id: string = randomUUID()): Result<Unidade> {
    const d: UnidadeDados = { id, sigla: String(e.sigla ?? '').trim().toUpperCase(), nome: String(e.nome ?? '').trim(), casas: Number(e.casas ?? 0) };
    const erros: ErroDominio[] = [];
    if (!/^[A-Z0-9]{1,10}$/.test(d.sigla)) erros.push(erroDe('unidade_invalida', 'Sigla de 1 a 10 letras ou numeros', 'sigla'));
    if (!d.nome || d.nome.length > 60) erros.push(erroDe('nome_invalido', 'Nome de 1 a 60 caracteres', 'nome'));
    if (!Number.isInteger(d.casas) || d.casas < 0 || d.casas > 3) erros.push(erroDe('casas_invalidas', 'Casas decimais de 0 a 3', 'casas'));
    return erros.length ? fail(...erros) : ok(new Unidade(d));
  }
  static create(e: DadosUnidade, id?: string): Unidade {
    const r = Unidade.tryCreate(e, id);
    if (!r.ok) throw new Error(r.erros.map((x) => x.mensagem).join('; '));
    return r.valor;
  }
}
