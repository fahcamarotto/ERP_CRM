/** Codigo de barras GTIN (EAN-8, UPC-A 12, EAN-13, GTIN-14) com digito verificador conferido. */
import { erroDe, fail, ok, type Result } from '../../compartilhado/result.ts';

export function digitoGtin(base: string): number {
  const soma = [...base].reverse().reduce((a, d, i) => a + Number(d) * (i % 2 === 0 ? 3 : 1), 0);
  return (10 - (soma % 10)) % 10;
}

export class CodigoBarras {
  private constructor(readonly valor: string) {}
  static tryCreate(bruto: string, campo = 'codigo_barras'): Result<CodigoBarras> {
    const v = String(bruto ?? '').replace(/\D/g, '');
    if (![8, 12, 13, 14].includes(v.length)) return fail(erroDe('codigo_barras_invalido', 'Codigo de barras deve ter 8, 12, 13 ou 14 digitos', campo));
    if (digitoGtin(v.slice(0, -1)) !== Number(v.at(-1))) return fail(erroDe('codigo_barras_invalido', 'Digito verificador do codigo de barras nao confere', campo));
    return ok(new CodigoBarras(v));
  }
  static create(bruto: string, campo?: string): CodigoBarras {
    const r = CodigoBarras.tryCreate(bruto, campo);
    if (!r.ok) throw new Error(r.erros[0]!.mensagem);
    return r.valor;
  }
  /** Gera um EAN-13 valido a partir de 12 digitos (seed e testes). */
  static ean13(base12: string): CodigoBarras {
    return CodigoBarras.create(`${base12}${digitoGtin(base12)}`);
  }
}
