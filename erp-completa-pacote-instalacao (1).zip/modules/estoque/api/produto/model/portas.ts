/** Portas do agregado Produto (e filhas Variacao, Lote, Unidade), segregadas por operacao. */
import type { Lote, Produto, Unidade, Variacao } from './produto.ts';

export interface ObterProduto {
  obterPorId(id: string): Promise<Produto | null>;
  buscarPorSku(sku: string): Promise<{ id: string } | null>;
  buscarPorCodigoBarras(codigo: string): Promise<{ id: string } | null>;
}

export interface GravarProduto {
  inserir(p: Produto): Promise<void>;
  atualizar(p: Produto): Promise<void>;
}

export interface ExcluirProduto {
  excluir(id: string): Promise<void>;
  temMovimentacao(id: string): Promise<boolean>;
}

/** Referencias externas: fornecedor (cadastros_parceiros publicado) e unidade do catalogo. */
export interface ConsultarReferenciasProduto {
  fornecedorAtivo(id: string): Promise<boolean>;
  unidadeExiste(sigla: string): Promise<boolean>;
}

export interface GravarVariacoes {
  inserirVariacao(v: Variacao): Promise<void>;
  skuVariacaoEmUso(sku: string): Promise<boolean>;
  obterVariacao(id: string): Promise<{ id: string; produto_id: string } | null>;
  excluirVariacao(id: string): Promise<void>;
  variacaoTemMovimentacao(id: string): Promise<boolean>;
}

export interface GravarLotes {
  inserirLote(l: Lote): Promise<void>;
  buscarLote(produtoId: string, codigo: string): Promise<{ id: string } | null>;
}

export interface GravarUnidades {
  inserirUnidade(u: Unidade): Promise<void>;
  unidadeCadastrada(sigla: string): Promise<boolean>;
}

/** Reapontar parceiro mesclado no Cadastros (evento parceiro.mesclado). */
export interface ReapontarParceiros {
  reapontarParceiro(de: string[], para: string): Promise<number>;
}
