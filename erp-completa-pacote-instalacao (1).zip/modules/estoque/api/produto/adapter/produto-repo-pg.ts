/** Adaptador Postgres do agregado Produto e filhas (RLS restringe ao workspace da sessao). */
import type pg from 'pg';
import { Produto, UNIDADES_PADRAO, type Lote, type ProdutoDados, type Unidade, type Variacao } from '../model/produto.ts';
import type {
  ConsultarReferenciasProduto, ExcluirProduto, GravarLotes, GravarProduto, GravarUnidades, GravarVariacoes, ObterProduto, ReapontarParceiros,
} from '../model/portas.ts';

const COLUNAS = `id, sku, nome, descricao, unidade, codigo_barras, custo::float8 AS custo, custo_medio::float8 AS custo_medio,
  preco::float8 AS preco, estoque_minimo::float8 AS estoque_minimo, controla_lote, atributos, fornecedor_id, estado, extras`;

export class ProdutoRepoPg implements ObterProduto, GravarProduto, ExcluirProduto, ConsultarReferenciasProduto, GravarVariacoes, GravarLotes, GravarUnidades, ReapontarParceiros {
  constructor(private readonly c: pg.PoolClient) {}

  async obterPorId(id: string): Promise<Produto | null> {
    const r = await this.c.query(`SELECT ${COLUNAS} FROM estoque_produtos WHERE id = $1 AND deleted_at IS NULL`, [id]);
    return r.rows[0] ? Produto.reidratar(r.rows[0] as ProdutoDados) : null;
  }

  async buscarPorSku(sku: string) {
    return (await this.c.query('SELECT id FROM estoque_produtos WHERE sku = $1 AND deleted_at IS NULL', [sku])).rows[0] ?? null;
  }

  async buscarPorCodigoBarras(codigo: string) {
    return (await this.c.query('SELECT id FROM estoque_produtos WHERE codigo_barras = $1 AND deleted_at IS NULL', [codigo])).rows[0] ?? null;
  }

  async inserir(p: Produto): Promise<void> {
    const d = p.paraDados();
    await this.c.query(
      `INSERT INTO estoque_produtos (id, sku, nome, descricao, unidade, codigo_barras, custo, custo_medio, preco, estoque_minimo, controla_lote,
         atributos, fornecedor_id, estado, extras, creator_id)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, nucleo_usuario_atual())`,
      [d.id, d.sku, d.nome, d.descricao, d.unidade, d.codigo_barras, d.custo, d.custo_medio, d.preco, d.estoque_minimo, d.controla_lote,
        JSON.stringify(d.atributos), d.fornecedor_id, d.estado, JSON.stringify(d.extras)],
    );
  }

  async atualizar(p: Produto): Promise<void> {
    const d = p.paraDados();
    await this.c.query(
      `UPDATE estoque_produtos SET sku = $2, nome = $3, descricao = $4, unidade = $5, codigo_barras = $6, custo = $7, preco = $8,
         estoque_minimo = $9, controla_lote = $10, atributos = $11, fornecedor_id = $12, estado = $13, extras = $14
       WHERE id = $1 AND deleted_at IS NULL`,
      [d.id, d.sku, d.nome, d.descricao, d.unidade, d.codigo_barras, d.custo, d.preco, d.estoque_minimo, d.controla_lote,
        JSON.stringify(d.atributos), d.fornecedor_id, d.estado, JSON.stringify(d.extras)],
    );
  }

  async excluir(id: string): Promise<void> {
    await this.c.query('UPDATE estoque_produtos SET deleted_at = now() WHERE id = $1 AND deleted_at IS NULL', [id]);
    await this.c.query('UPDATE estoque_variacoes SET deleted_at = now() WHERE produto_id = $1 AND deleted_at IS NULL', [id]);
    await this.c.query('UPDATE estoque_lotes SET deleted_at = now() WHERE produto_id = $1 AND deleted_at IS NULL', [id]);
  }

  async temMovimentacao(id: string): Promise<boolean> {
    return ((await this.c.query('SELECT 1 FROM estoque_movimentacao_itens WHERE produto_id = $1 AND deleted_at IS NULL LIMIT 1', [id])).rowCount ?? 0) > 0;
  }

  /** Leitura da tabela publicada cadastros_parceiros (CONTRATOS 7.1.1). */
  async fornecedorAtivo(id: string): Promise<boolean> {
    return ((await this.c.query("SELECT 1 FROM cadastros_parceiros WHERE id = $1 AND deleted_at IS NULL AND estado = 'ativo'", [id])).rowCount ?? 0) > 0;
  }

  async unidadeExiste(sigla: string): Promise<boolean> {
    return !!UNIDADES_PADRAO[sigla] || (await this.unidadeCadastrada(sigla));
  }

  async inserirVariacao(v: Variacao): Promise<void> {
    const d = v.dados;
    await this.c.query(
      `INSERT INTO estoque_variacoes (id, produto_id, nome, sku, codigo_barras, atributos, preco, creator_id)
       VALUES ($1, $2, $3, $4, $5, $6, $7, nucleo_usuario_atual())`,
      [d.id, d.produto_id, d.nome, d.sku, d.codigo_barras, JSON.stringify(d.atributos), d.preco],
    );
  }

  async skuVariacaoEmUso(sku: string): Promise<boolean> {
    return ((await this.c.query('SELECT 1 FROM estoque_variacoes WHERE sku = $1 AND deleted_at IS NULL', [sku])).rowCount ?? 0) > 0;
  }

  async obterVariacao(id: string) {
    return (await this.c.query('SELECT id, produto_id FROM estoque_variacoes WHERE id = $1 AND deleted_at IS NULL', [id])).rows[0] ?? null;
  }

  async excluirVariacao(id: string): Promise<void> {
    await this.c.query('UPDATE estoque_variacoes SET deleted_at = now() WHERE id = $1 AND deleted_at IS NULL', [id]);
  }

  async variacaoTemMovimentacao(id: string): Promise<boolean> {
    return ((await this.c.query('SELECT 1 FROM estoque_movimentacao_itens WHERE variacao_id = $1 AND deleted_at IS NULL LIMIT 1', [id])).rowCount ?? 0) > 0;
  }

  async inserirLote(l: Lote): Promise<void> {
    const d = l.dados;
    await this.c.query(
      'INSERT INTO estoque_lotes (id, produto_id, codigo, fabricacao, validade, creator_id) VALUES ($1, $2, $3, $4, $5, nucleo_usuario_atual())',
      [d.id, d.produto_id, d.codigo, d.fabricacao, d.validade],
    );
  }

  async buscarLote(produtoId: string, codigo: string) {
    return (await this.c.query('SELECT id FROM estoque_lotes WHERE produto_id = $1 AND upper(codigo) = upper($2) AND deleted_at IS NULL', [produtoId, codigo.trim()])).rows[0] ?? null;
  }

  async inserirUnidade(u: Unidade): Promise<void> {
    const d = u.dados;
    await this.c.query('INSERT INTO estoque_unidades (id, sigla, nome, casas, creator_id) VALUES ($1, $2, $3, $4, nucleo_usuario_atual())', [d.id, d.sigla, d.nome, d.casas]);
  }

  async unidadeCadastrada(sigla: string): Promise<boolean> {
    return ((await this.c.query('SELECT 1 FROM estoque_unidades WHERE sigla = $1 AND deleted_at IS NULL', [sigla])).rowCount ?? 0) > 0;
  }

  async reapontarParceiro(de: string[], para: string): Promise<number> {
    const a = await this.c.query('UPDATE estoque_produtos SET fornecedor_id = $2 WHERE fornecedor_id = ANY ($1::uuid[])', [de, para]);
    const b = await this.c.query('UPDATE estoque_movimentacoes SET parceiro_id = $2 WHERE parceiro_id = ANY ($1::uuid[])', [de, para]);
    return (a.rowCount ?? 0) + (b.rowCount ?? 0);
  }
}
