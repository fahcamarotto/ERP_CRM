/**
 * Consultas de leitura do Produto: lista com saldo e valor (M9.7), ficha com variacoes, lotes e saldos
 * por deposito, unidades, variacoes, lotes com situacao de validade (M9.6), saldo (tool estoque.saldo) e resumo.
 */
import type pg from 'pg';
import { decodificarCursor, pagina } from '../../compartilhado/cursor.ts';
import { UNIDADES_PADRAO } from '../model/produto.ts';

const SALDO = `coalesce((SELECT sum(s.quantidade) FROM estoque_saldos s WHERE s.produto_id = p.id), 0)::float8`;

const RESUMO = `p.id, p.sku, p.nome, p.unidade, p.codigo_barras, p.custo::float8 AS custo, p.custo_medio::float8 AS custo_medio,
  p.preco::float8 AS preco, p.estoque_minimo::float8 AS estoque_minimo, p.controla_lote, p.estado, p.fornecedor_id,
  f.nome AS fornecedor_nome, ${SALDO} AS saldo, round((${SALDO} * p.custo_medio)::numeric, 2)::float8 AS valor_estoque,
  (p.estoque_minimo > 0 AND ${SALDO} < p.estoque_minimo) AS abaixo_minimo,
  (SELECT count(*)::int FROM estoque_variacoes v WHERE v.produto_id = p.id AND v.deleted_at IS NULL) AS variacoes_qtd,
  p.created_at, p.updated_at`;

const JUNCOES = `FROM estoque_produtos p LEFT JOIN cadastros_parceiros f ON f.id = p.fornecedor_id AND f.deleted_at IS NULL`;

export interface FiltroProdutos {
  busca?: string;
  estado?: 'ativo' | 'arquivado' | 'todos';
  abaixo_minimo?: boolean;
  limite?: number;
  cursor?: string;
}

export async function listarProdutos(c: pg.PoolClient, f: FiltroProdutos) {
  const lim = Math.min(Math.max(f.limite ?? 50, 1), 200);
  const cur = decodificarCursor(f.cursor);
  const estado = f.estado === 'todos' ? null : (f.estado ?? 'ativo');
  const r = await c.query(
    `SELECT ${RESUMO} ${JUNCOES}
     WHERE p.deleted_at IS NULL AND ($1::text IS NULL OR p.estado = $1)
       AND ($2::text IS NULL OR p.nome ILIKE '%' || $2 || '%' OR p.sku ILIKE '%' || $2 || '%' OR p.codigo_barras = $2)
       AND (NOT $3::boolean OR (p.estoque_minimo > 0 AND ${SALDO} < p.estoque_minimo))
       AND ($4::timestamptz IS NULL OR (p.created_at, p.id) > ($4::timestamptz, $5::uuid))
     ORDER BY p.created_at, p.id LIMIT $6`,
    [estado, f.busca?.trim() || null, !!f.abaixo_minimo, cur?.[0] ?? null, cur?.[1] ?? null, lim + 1],
  );
  return pagina(r.rows, lim);
}

export async function obterProduto(c: pg.PoolClient, id: string) {
  const r = await c.query(
    `SELECT ${RESUMO}, p.descricao, p.atributos, p.extras,
       coalesce((SELECT json_agg(json_build_object('id', v.id, 'nome', v.nome, 'sku', v.sku, 'codigo_barras', v.codigo_barras,
         'atributos', v.atributos, 'preco', v.preco::float8,
         'saldo', coalesce((SELECT sum(s.quantidade) FROM estoque_saldos s WHERE s.variacao_id = v.id), 0)::float8) ORDER BY v.nome)
         FROM estoque_variacoes v WHERE v.produto_id = p.id AND v.deleted_at IS NULL), '[]') AS variacoes,
       coalesce((SELECT json_agg(json_build_object('id', l.id, 'codigo', l.codigo, 'validade', to_char(l.validade, 'YYYY-MM-DD'),
         'saldo', coalesce((SELECT sum(s.quantidade) FROM estoque_saldos s WHERE s.lote_id = l.id), 0)::float8) ORDER BY l.validade NULLS LAST, l.codigo)
         FROM estoque_lotes l WHERE l.produto_id = p.id AND l.deleted_at IS NULL), '[]') AS lotes,
       coalesce((SELECT json_agg(json_build_object('deposito_id', s.deposito_id, 'deposito_nome', d.nome, 'local_codigo', lc.codigo,
         'variacao_nome', v.nome, 'lote_codigo', l.codigo, 'quantidade', s.quantidade::float8) ORDER BY d.nome, lc.codigo NULLS FIRST)
         FROM estoque_saldos s JOIN estoque_depositos d ON d.id = s.deposito_id
         LEFT JOIN estoque_locais lc ON lc.id = s.local_id LEFT JOIN estoque_variacoes v ON v.id = s.variacao_id
         LEFT JOIN estoque_lotes l ON l.id = s.lote_id
         WHERE s.produto_id = p.id AND s.quantidade <> 0), '[]') AS saldos
     ${JUNCOES} WHERE p.id = $1 AND p.deleted_at IS NULL`,
    [id],
  );
  return r.rows[0] ?? null;
}

export async function listarUnidades(c: pg.PoolClient) {
  const r = await c.query('SELECT id, sigla, nome, casas FROM estoque_unidades WHERE deleted_at IS NULL ORDER BY sigla');
  const cadastradas = new Set(r.rows.map((x) => x.sigla as string));
  const padrao = Object.entries(UNIDADES_PADRAO).filter(([s]) => !cadastradas.has(s)).map(([sigla, u]) => ({ id: `padrao-${sigla}`, sigla, nome: u.nome, casas: u.casas, origem: 'padrao' }));
  return [...padrao, ...r.rows.map((x) => ({ ...x, origem: 'workspace' }))].sort((a, b) => a.sigla.localeCompare(b.sigla));
}

export async function listarVariacoes(c: pg.PoolClient, produtoId?: string) {
  return (await c.query(
    `SELECT v.id, v.produto_id, p.sku AS produto_sku, p.nome AS produto_nome, v.nome, v.sku, v.codigo_barras, v.atributos,
       v.preco::float8 AS preco, coalesce((SELECT sum(s.quantidade) FROM estoque_saldos s WHERE s.variacao_id = v.id), 0)::float8 AS saldo, v.created_at
     FROM estoque_variacoes v JOIN estoque_produtos p ON p.id = v.produto_id AND p.deleted_at IS NULL
     WHERE v.deleted_at IS NULL AND ($1::uuid IS NULL OR v.produto_id = $1) ORDER BY p.nome, v.nome LIMIT 500`,
    [produtoId ?? null],
  )).rows;
}

/** M9.6: lotes com saldo e situacao (vencido, vencendo em 30 dias, ok, sem_validade). */
export async function listarLotes(c: pg.PoolClient, f: { produto_id?: string; situacao?: string }) {
  return (await c.query(
    `SELECT * FROM (
       SELECT l.id, l.produto_id, p.sku AS produto_sku, p.nome AS produto_nome, l.codigo, to_char(l.fabricacao, 'YYYY-MM-DD') AS fabricacao,
         to_char(l.validade, 'YYYY-MM-DD') AS validade,
         coalesce((SELECT sum(s.quantidade) FROM estoque_saldos s WHERE s.lote_id = l.id), 0)::float8 AS saldo,
         CASE WHEN l.validade IS NULL THEN 'sem_validade' WHEN l.validade < current_date THEN 'vencido'
              WHEN l.validade <= current_date + 30 THEN 'vencendo' ELSE 'ok' END AS situacao,
         (l.validade - current_date) AS dias_para_vencer, l.created_at
       FROM estoque_lotes l JOIN estoque_produtos p ON p.id = l.produto_id AND p.deleted_at IS NULL
       WHERE l.deleted_at IS NULL AND ($1::uuid IS NULL OR l.produto_id = $1)) x
     WHERE ($2::text IS NULL OR x.situacao = $2)
     ORDER BY x.validade NULLS LAST, x.produto_nome, x.codigo LIMIT 500`,
    [f.produto_id ?? null, f.situacao ?? null],
  )).rows;
}

/** Tool estoque.saldo: saldo por produto e deposito com custo medio e valor (M9.7). */
export async function saldoEstoque(c: pg.PoolClient, f: { produto_id?: string; sku?: string; deposito_id?: string; busca?: string }) {
  const r = await c.query(
    `SELECT p.id AS produto_id, p.sku, p.nome, p.unidade, d.id AS deposito_id, d.nome AS deposito_nome,
       sum(s.quantidade)::float8 AS quantidade, p.custo_medio::float8 AS custo_medio,
       round(sum(s.quantidade) * p.custo_medio, 2)::float8 AS valor
     FROM estoque_saldos s JOIN estoque_produtos p ON p.id = s.produto_id AND p.deleted_at IS NULL
     JOIN estoque_depositos d ON d.id = s.deposito_id
     WHERE ($1::uuid IS NULL OR p.id = $1) AND ($2::text IS NULL OR p.sku = upper($2)) AND ($3::uuid IS NULL OR d.id = $3)
       AND ($4::text IS NULL OR p.nome ILIKE '%' || $4 || '%' OR p.sku ILIKE '%' || $4 || '%')
     GROUP BY p.id, p.sku, p.nome, p.unidade, p.custo_medio, d.id, d.nome HAVING sum(s.quantidade) <> 0 ORDER BY p.nome, d.nome LIMIT 1000`,
    [f.produto_id ?? null, f.sku?.trim() || null, f.deposito_id ?? null, f.busca?.trim() || null],
  );
  const valor_total = Math.round(r.rows.reduce((a, x) => a + Number(x.valor), 0) * 100) / 100;
  return { itens: r.rows, valor_total };
}

export async function resumoEstoque(c: pg.PoolClient) {
  return (await c.query(
    `SELECT
       coalesce((SELECT round(sum(x.q * x.cm), 2) FROM (SELECT sum(s.quantidade) AS q, p.custo_medio AS cm FROM estoque_saldos s
         JOIN estoque_produtos p ON p.id = s.produto_id AND p.deleted_at IS NULL GROUP BY p.id, p.custo_medio) x), 0)::float8 AS valor_total,
       (SELECT count(*)::int FROM estoque_produtos p WHERE p.deleted_at IS NULL AND p.estado = 'ativo') AS produtos_ativos,
       (SELECT count(*)::int FROM estoque_produtos p WHERE p.deleted_at IS NULL AND p.estado = 'ativo' AND p.estoque_minimo > 0
          AND ${SALDO} < p.estoque_minimo) AS abaixo_minimo,
       (SELECT count(*)::int FROM estoque_alertas a WHERE a.estado = 'aberto' AND a.deleted_at IS NULL) AS alertas_abertos,
       (SELECT count(*)::int FROM estoque_lotes l WHERE l.deleted_at IS NULL AND l.validade < current_date
          AND coalesce((SELECT sum(s.quantidade) FROM estoque_saldos s WHERE s.lote_id = l.id), 0) > 0) AS lotes_vencidos,
       (SELECT count(*)::int FROM estoque_lotes l WHERE l.deleted_at IS NULL AND l.validade BETWEEN current_date AND current_date + 30
          AND coalesce((SELECT sum(s.quantidade) FROM estoque_saldos s WHERE s.lote_id = l.id), 0) > 0) AS lotes_vencendo`,
  )).rows[0];
}

/** Opcoes de fornecedor no formulario (leitura da tabela publicada cadastros_parceiros, CONTRATOS 7.1.1). */
export async function listarFornecedores(c: pg.PoolClient) {
  return (await c.query("SELECT id, nome FROM cadastros_parceiros WHERE e_fornecedor AND estado = 'ativo' AND deleted_at IS NULL ORDER BY nome LIMIT 200")).rows;
}
