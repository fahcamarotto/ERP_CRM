/** Consultas do Inventario: lista e ficha com itens, saldo atual e diferenca. */
import type pg from 'pg';

const RESUMO = `v.id, v.deposito_id, d.nome AS deposito_nome, v.descricao, v.estado, v.movimentacao_id,
  v.concluido_em, v.created_at, v.updated_at,
  (SELECT count(*)::int FROM estoque_inventario_itens i WHERE i.inventario_id = v.id AND i.deleted_at IS NULL) AS itens_qtd,
  (SELECT count(*)::int FROM estoque_inventario_itens i WHERE i.inventario_id = v.id AND i.deleted_at IS NULL AND i.quantidade_contada IS NOT NULL) AS contados_qtd`;

export async function listarInventarios(c: pg.PoolClient, f: { estado?: string } = {}) {
  return (await c.query(
    `SELECT ${RESUMO} FROM estoque_inventarios v JOIN estoque_depositos d ON d.id = v.deposito_id
     WHERE v.deleted_at IS NULL AND ($1::text IS NULL OR v.estado = $1) ORDER BY v.created_at DESC LIMIT 200`,
    [f.estado ?? null],
  )).rows;
}

export async function obterInventario(c: pg.PoolClient, id: string) {
  const r = await c.query(
    `SELECT ${RESUMO},
       coalesce((SELECT json_agg(json_build_object('id', i.id, 'produto_id', i.produto_id, 'sku', p.sku, 'produto_nome', p.nome, 'unidade', p.unidade,
         'variacao_nome', va.nome, 'lote_codigo', l.codigo, 'local_codigo', lc.codigo,
         'quantidade_sistema', i.quantidade_sistema::float8, 'quantidade_contada', i.quantidade_contada::float8,
         'saldo_atual', coalesce((SELECT sum(s.quantidade) FROM estoque_saldos s WHERE s.deposito_id = v.deposito_id AND s.produto_id = i.produto_id
            AND s.variacao_id IS NOT DISTINCT FROM i.variacao_id AND s.lote_id IS NOT DISTINCT FROM i.lote_id
            AND s.local_id IS NOT DISTINCT FROM i.local_id), 0)::float8) ORDER BY p.nome, l.codigo NULLS FIRST)
         FROM estoque_inventario_itens i JOIN estoque_produtos p ON p.id = i.produto_id
         LEFT JOIN estoque_variacoes va ON va.id = i.variacao_id LEFT JOIN estoque_lotes l ON l.id = i.lote_id
         LEFT JOIN estoque_locais lc ON lc.id = i.local_id
         WHERE i.inventario_id = v.id AND i.deleted_at IS NULL), '[]') AS itens
     FROM estoque_inventarios v JOIN estoque_depositos d ON d.id = v.deposito_id WHERE v.id = $1 AND v.deleted_at IS NULL`,
    [id],
  );
  return r.rows[0] ?? null;
}
