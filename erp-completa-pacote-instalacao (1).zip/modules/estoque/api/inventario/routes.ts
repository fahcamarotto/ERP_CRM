/** Rotas REST do Inventario: abrir, listar, ficha, contagem, concluir com ajuste e cancelar. */
import { esquemaErro, requer, type FastifyInstance } from '@erp/api/sdk';
import { naTransacao, naoEncontrado } from '../borda.ts';
import { exigirOk } from '../compartilhado/result.ts';
import { uuid } from '../esquemas.ts';
import { listarInventarios, obterInventario } from './query/inventarios.ts';

const tags = ['estoque'];
const paramId = { type: 'object', required: ['id'], properties: { id: uuid } } as const;
const erros = { 400: esquemaErro, 403: esquemaErro, 404: esquemaErro, 409: esquemaErro };

export function rotasInventario(app: FastifyInstance): void {
  app.get<{ Querystring: { estado?: string } }>('/inventarios', {
    preHandler: requer('estoque.ver'),
    schema: { tags, summary: 'Inventarios', querystring: { type: 'object', additionalProperties: false, properties: { estado: { type: 'string', enum: ['aberto', 'concluido', 'cancelado'] } } } },
  }, (req) => naTransacao(req, (_, __, c) => listarInventarios(c, req.query)));

  app.get<{ Params: { id: string } }>('/inventarios/:id', {
    preHandler: requer('estoque.ver'),
    schema: { tags, summary: 'Ficha do inventario com itens, saldo atual e diferenca', params: paramId, response: { 404: esquemaErro } },
  }, (req) => naTransacao(req, async (_, __, c) => (await obterInventario(c, req.params.id)) ?? Promise.reject(naoEncontrado('Inventario nao encontrado'))));

  app.post<{ Body: { deposito_id: string; descricao: string; produto_ids?: string[] } }>('/inventarios', {
    preHandler: requer('estoque.criar'),
    schema: {
      tags, summary: 'Abre inventario e fotografa o saldo do deposito (AbrirInventario)',
      body: { type: 'object', additionalProperties: false, required: ['deposito_id', 'descricao'], properties: {
        deposito_id: uuid, descricao: { type: 'string', minLength: 3, maxLength: 200 }, produto_ids: { type: 'array', items: uuid, maxItems: 500 },
      } },
      response: erros,
    },
  }, async (req, reply) => reply.code(201).send(await naTransacao(req, async (casos, ctx, c) => {
    const { id } = exigirOk(await casos.abrirInventario.execute(ctx, req.body));
    return obterInventario(c, id);
  })));

  app.post<{ Params: { id: string }; Body: { contagens: { item_id: string; quantidade_contada: number | null }[] } }>('/inventarios/:id/contagens', {
    preHandler: requer('estoque.editar'),
    schema: {
      tags, summary: 'Registra a contagem dos itens (RegistrarContagem)', params: paramId,
      body: { type: 'object', additionalProperties: false, required: ['contagens'], properties: {
        contagens: { type: 'array', minItems: 1, maxItems: 1000, items: { type: 'object', additionalProperties: false, required: ['item_id', 'quantidade_contada'], properties: {
          item_id: uuid, quantidade_contada: { type: ['number', 'null'], minimum: 0 },
        } } },
      } },
      response: erros,
    },
  }, (req) => naTransacao(req, async (casos, ctx, c) => {
    exigirOk(await casos.registrarContagem.execute(ctx, { id: req.params.id, contagens: req.body.contagens }));
    return obterInventario(c, req.params.id);
  }));

  app.post<{ Params: { id: string } }>('/inventarios/:id/concluir', {
    preHandler: requer('estoque.editar'),
    schema: { tags, summary: 'Conclui e gera o ajuste automatico da diferenca (ConcluirInventario)', params: paramId, response: erros },
  }, (req) => naTransacao(req, async (casos, ctx, c) => {
    const r = exigirOk(await casos.concluirInventario.execute(ctx, { id: req.params.id }));
    return { ...(await obterInventario(c, req.params.id)), ajustes: r.ajustes };
  }));

  app.post<{ Params: { id: string } }>('/inventarios/:id/cancelar', {
    preHandler: requer('estoque.editar'),
    schema: { tags, summary: 'Cancela inventario aberto (CancelarInventario)', params: paramId, response: erros },
  }, (req) => naTransacao(req, async (casos, ctx, c) => {
    exigirOk(await casos.cancelarInventario.execute(ctx, { id: req.params.id }));
    return obterInventario(c, req.params.id);
  }));
}
