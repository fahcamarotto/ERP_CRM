/**
 * Agregado Inventario (M9.5): fotografa o saldo de um deposito, recebe a contagem item a item e, ao
 * concluir, gera um ajuste automatico com a diferenca. Estados: aberto -> concluido | cancelado.
 */
import { randomUUID } from 'node:crypto';
import { erroDe, fail, ok, type ErroDominio, type Result } from '../../compartilhado/result.ts';
import { Quantidade } from '../../compartilhado/valores.ts';

export const ESTADOS_INVENTARIO = ['aberto', 'concluido', 'cancelado'] as const;
export type EstadoInventario = (typeof ESTADOS_INVENTARIO)[number];
export const TRANSICOES: Record<EstadoInventario, EstadoInventario[]> = { aberto: ['concluido', 'cancelado'], concluido: [], cancelado: [] };

export interface ItemInventario {
  id: string;
  produto_id: string;
  variacao_id: string | null;
  lote_id: string | null;
  local_id: string | null;
  quantidade_sistema: number;
  quantidade_contada: number | null;
}

export interface InventarioDados {
  id: string;
  deposito_id: string;
  descricao: string;
  estado: EstadoInventario;
  movimentacao_id: string | null;
  itens: ItemInventario[];
}

export interface FotoSaldo { produto_id: string; variacao_id: string | null; lote_id: string | null; local_id: string | null; quantidade: number }

/** Diferenca a ajustar de um item contado (contada menos o saldo atual). */
export interface Diferenca { item: ItemInventario; diferenca: number }

export class Inventario {
  private constructor(private readonly d: InventarioDados) {}

  static tryCreate(e: { deposito_id: string; descricao: string }, foto: FotoSaldo[], id: string = randomUUID(), novoId: () => string = randomUUID): Result<Inventario> {
    const descricao = (e.descricao ?? '').trim();
    const erros: ErroDominio[] = [];
    if (descricao.length < 3 || descricao.length > 200) erros.push(erroDe('descricao_invalida', 'Descricao de 3 a 200 caracteres', 'descricao'));
    if (!e.deposito_id) erros.push(erroDe('deposito_obrigatorio', 'Informe o deposito', 'deposito_id'));
    if (foto.length === 0) erros.push(erroDe('inventario_vazio', 'Nenhum produto para contar neste deposito', 'produto_ids'));
    if (erros.length) return fail(...erros);
    const itens = foto.map((f) => ({ id: novoId(), produto_id: f.produto_id, variacao_id: f.variacao_id, lote_id: f.lote_id, local_id: f.local_id ?? null, quantidade_sistema: Number(f.quantidade), quantidade_contada: null }));
    return ok(new Inventario({ id, deposito_id: e.deposito_id, descricao, estado: 'aberto', movimentacao_id: null, itens }));
  }

  static reidratar(d: InventarioDados): Inventario {
    return new Inventario({
      ...d,
      itens: d.itens.map((i) => ({ ...i, quantidade_sistema: Number(i.quantidade_sistema), quantidade_contada: i.quantidade_contada === null ? null : Number(i.quantidade_contada) })),
    });
  }

  get id(): string { return this.d.id; }
  get estado(): EstadoInventario { return this.d.estado; }

  private exigirAberto(): ErroDominio | null {
    return this.d.estado === 'aberto' ? null : erroDe('transicao_invalida', `Inventario ${this.d.estado} nao aceita alteracao`, 'estado', { permitidas: TRANSICOES[this.d.estado] });
  }

  registrarContagem(contagens: { item_id: string; quantidade_contada: number | null }[]): Result<Inventario> {
    const bloqueio = this.exigirAberto();
    if (bloqueio) return fail(bloqueio);
    const mapa = new Map(this.d.itens.map((i) => [i.id, { ...i }]));
    const erros: ErroDominio[] = [];
    contagens.forEach((c, n) => {
      const item = mapa.get(c.item_id);
      if (!item) { erros.push(erroDe('item_invalido', 'Item nao pertence ao inventario', `contagens.${n}.item_id`)); return; }
      if (c.quantidade_contada === null) { item.quantidade_contada = null; return; }
      const q = Quantidade.tryCreate(c.quantidade_contada, `contagens.${n}.quantidade_contada`, { naoNegativa: true });
      if (!q.ok) erros.push(...q.erros);
      else item.quantidade_contada = q.valor.valor;
    });
    return erros.length ? fail(...erros) : ok(new Inventario({ ...this.d, itens: [...mapa.values()] }));
  }

  /** Itens contados com diferenca em relacao ao saldo atual (a contagem vence o sistema). */
  diferencas(saldoAtual: (i: ItemInventario) => number): Diferenca[] {
    return this.d.itens
      .filter((i) => i.quantidade_contada !== null)
      .map((i) => ({ item: i, diferenca: Math.round(((i.quantidade_contada as number) - saldoAtual(i)) * 1000) / 1000 }))
      .filter((x) => x.diferenca !== 0);
  }

  concluir(movimentacaoId: string | null): Result<Inventario> {
    const bloqueio = this.exigirAberto();
    if (bloqueio) return fail(bloqueio);
    if (!this.d.itens.some((i) => i.quantidade_contada !== null)) return fail(erroDe('contagem_pendente', 'Registre a contagem de ao menos um item antes de concluir'));
    return ok(new Inventario({ ...this.d, estado: 'concluido', movimentacao_id: movimentacaoId }));
  }

  cancelar(): Result<Inventario> {
    const bloqueio = this.exigirAberto();
    if (bloqueio) return fail(bloqueio);
    return ok(new Inventario({ ...this.d, estado: 'cancelado' }));
  }

  paraDados(): InventarioDados { return { ...this.d, itens: this.d.itens.map((i) => ({ ...i })) }; }
}
