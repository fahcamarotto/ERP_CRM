/** Portas do agregado Inventario. */
import type { FotoSaldo, Inventario, ItemInventario } from './inventario.ts';

export interface ObterInventario {
  obterPorId(id: string): Promise<Inventario | null>;
  abertoNoDeposito(depositoId: string): Promise<{ id: string } | null>;
}

export interface GravarInventario {
  inserir(i: Inventario): Promise<void>;
  /** Grava estado, movimentacao e as contagens dos itens. */
  atualizar(i: Inventario): Promise<void>;
}

export interface FotografarSaldos {
  depositoAtivo(id: string): Promise<boolean>;
  /** Saldos do deposito por produto, variacao, lote e local; produtoIds limita e inclui o produto com saldo zero. */
  fotografar(depositoId: string, produtoIds?: string[]): Promise<FotoSaldo[]>;
  /** Saldo atual da chave exata do item (produto, variacao, lote e local) no deposito. */
  saldoAtual(depositoId: string, item: Pick<ItemInventario, 'produto_id' | 'variacao_id' | 'lote_id' | 'local_id'>): Promise<number>;
}
