/** Adaptador Postgres do Inventario: cabecalho, itens com contagem e fotografia do saldo pela view. */
import type pg from 'pg';
import { Inventario, type FotoSaldo, type InventarioDados, type ItemInventario } from '../model/inventario.ts';
import type { FotografarSaldos, GravarInventario, ObterInventario } from '../model/portas.ts';

export class InventarioRepoPg implements ObterInventario, GravarInventario, FotografarSaldos {
  constructor(private readonly c: pg.PoolClient) {}

  async obterPorId(id: string): Promise<Inventario | null> {
    const r = await this.c.query(
      `SELECT v.id, v.deposito_id, v.descricao, v.estado, v.movimentacao_id,
         coalesce((SELECT json_agg(json_build_object('id', i.id, 'produto_id', i.produto_id, 'variacao_id', i.variacao_id, 'lote_id', i.lote_id,
           'local_id', i.local_id, 'quantidade_sistema', i.quantidade_sistema, 'quantidade_contada', i.quantidade_contada) ORDER BY i.created_at, i.id)
           FROM estoque_inventario_itens i WHERE i.inventario_id = v.id AND i.deleted_at IS NULL), '[]') AS itens
       FROM estoque_inventarios v WHERE v.id = $1 AND v.deleted_at IS NULL`,
      [id],
    );
    return r.rows[0] ? Inventario.reidratar(r.rows[0] as InventarioDados) : null;
  }

  async abertoNoDeposito(depositoId: string) {
    return (await this.c.query("SELECT id FROM estoque_inventarios WHERE deposito_id = $1 AND estado = 'aberto' AND deleted_at IS NULL", [depositoId])).rows[0] ?? null;
  }

  async inserir(inv: Inventario): Promise<void> {
    const d = inv.paraDados();
    await this.c.query('INSERT INTO estoque_inventarios (id, deposito_id, descricao, estado, creator_id) VALUES ($1, $2, $3, $4, nucleo_usuario_atual())',
      [d.id, d.deposito_id, d.descricao, d.estado]);
    await this.c.query(
      `INSERT INTO estoque_inventario_itens (id, inventario_id, produto_id, variacao_id, lote_id, local_id, quantidade_sistema, creator_id)
       SELECT x.id, $1, x.produto_id, x.variacao_id, x.lote_id, x.local_id, x.quantidade_sistema, nucleo_usuario_atual()
       FROM json_to_recordset($2::json) AS x(id uuid, produto_id uuid, variacao_id uuid, lote_id uuid, local_id uuid, quantidade_sistema numeric)`,
      [d.id, JSON.stringify(d.itens)],
    );
  }

  async atualizar(inv: Inventario): Promise<void> {
    const d = inv.paraDados();
    await this.c.query(
      `UPDATE estoque_inventarios SET estado = $2, movimentacao_id = $3, concluido_em = CASE WHEN $2 = 'concluido' THEN now() ELSE concluido_em END
       WHERE id = $1 AND deleted_at IS NULL`,
      [d.id, d.estado, d.movimentacao_id],
    );
    await this.c.query(
      `UPDATE estoque_inventario_itens i SET quantidade_contada = x.quantidade_contada
       FROM json_to_recordset($2::json) AS x(id uuid, quantidade_contada numeric)
       WHERE i.id = x.id AND i.inventario_id = $1 AND i.quantidade_contada IS DISTINCT FROM x.quantidade_contada`,
      [d.id, JSON.stringify(d.itens.map((i) => ({ id: i.id, quantidade_contada: i.quantidade_contada })))],
    );
  }

  async depositoAtivo(id: string): Promise<boolean> {
    return ((await this.c.query("SELECT 1 FROM estoque_depositos WHERE id = $1 AND estado = 'ativo' AND deleted_at IS NULL", [id])).rowCount ?? 0) > 0;
  }

  async fotografar(depositoId: string, produtoIds?: string[]): Promise<FotoSaldo[]> {
    const r = await this.c.query(
      `SELECT s.produto_id, s.variacao_id, s.lote_id, s.local_id, s.quantidade::float8 AS quantidade
       FROM estoque_saldos s JOIN estoque_produtos p ON p.id = s.produto_id AND p.deleted_at IS NULL
       WHERE s.deposito_id = $1 AND ($2::uuid[] IS NULL OR s.produto_id = ANY ($2::uuid[])) AND s.quantidade <> 0
       UNION ALL
       SELECT p.id, NULL, NULL, NULL, 0 FROM estoque_produtos p
       WHERE $2::uuid[] IS NOT NULL AND p.id = ANY ($2::uuid[]) AND p.deleted_at IS NULL AND NOT p.controla_lote
         AND NOT EXISTS (SELECT 1 FROM estoque_saldos s WHERE s.deposito_id = $1 AND s.produto_id = p.id AND s.quantidade <> 0)
       ORDER BY 1, 2, 3, 4`,
      [depositoId, produtoIds ?? null],
    );
    return r.rows as FotoSaldo[];
  }

  async saldoAtual(depositoId: string, i: Pick<ItemInventario, 'produto_id' | 'variacao_id' | 'lote_id' | 'local_id'>): Promise<number> {
    const r = await this.c.query(
      `SELECT coalesce(sum(quantidade), 0)::float8 AS q FROM estoque_saldos WHERE deposito_id = $1 AND produto_id = $2
         AND variacao_id IS NOT DISTINCT FROM $3::uuid AND lote_id IS NOT DISTINCT FROM $4::uuid AND local_id IS NOT DISTINCT FROM $5::uuid`,
      [depositoId, i.produto_id, i.variacao_id, i.lote_id, i.local_id],
    );
    return Number(r.rows[0].q);
  }
}
