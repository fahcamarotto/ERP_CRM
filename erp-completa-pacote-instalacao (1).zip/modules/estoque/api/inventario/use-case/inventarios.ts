/**
 * Casos de uso do Inventario (M9.5): abrir (fotografa o saldo), registrar contagem, concluir com
 * ajuste automatico da diferenca (uma movimentacao do tipo ajuste) e cancelar.
 */
import { erroDe, fail, ok, okVazio, type Result } from '../../compartilhado/result.ts';
import type { ContextoCaso } from '../../compartilhado/efeitos.ts';
import type { RegistrarMovimentacao } from '../../movimentacao/use-case/movimentacoes.ts';
import { Inventario } from '../model/inventario.ts';
import type { FotografarSaldos, GravarInventario, ObterInventario } from '../model/portas.ts';

const TABELA = 'estoque_inventarios';

export interface DepsInventario {
  repo: ObterInventario & GravarInventario;
  saldos: FotografarSaldos;
}

export class AbrirInventario {
  constructor(private readonly deps: DepsInventario) {}
  async execute(ctx: ContextoCaso, e: { deposito_id: string; descricao: string; produto_ids?: string[] }): Promise<Result<{ id: string }>> {
    if (!(await this.deps.saldos.depositoAtivo(e.deposito_id))) return fail(erroDe('deposito_invalido', 'Deposito nao encontrado ou arquivado', 'deposito_id'));
    const aberto = await this.deps.repo.abertoNoDeposito(e.deposito_id);
    if (aberto) return fail(erroDe('conflito', 'Ja existe inventario aberto neste deposito', 'deposito_id', { inventario_id: aberto.id }));
    const foto = await this.deps.saldos.fotografar(e.deposito_id, e.produto_ids?.length ? e.produto_ids : undefined);
    const r = Inventario.tryCreate(e, foto);
    if (!r.ok) return r;
    await this.deps.repo.inserir(r.valor);
    const d = r.valor.paraDados();
    await ctx.efeitos.auditar('inventario.abrir', TABELA, d.id, undefined, { deposito_id: d.deposito_id, descricao: d.descricao, itens: d.itens.length });
    return ok({ id: d.id });
  }
}

export class RegistrarContagem {
  constructor(private readonly deps: DepsInventario) {}
  async execute(ctx: ContextoCaso, e: { id: string; contagens: { item_id: string; quantidade_contada: number | null }[] }): Promise<Result<void>> {
    const atual = await this.deps.repo.obterPorId(e.id);
    if (!atual) return fail(erroDe('nao_encontrado', 'Inventario nao encontrado'));
    const r = atual.registrarContagem(e.contagens ?? []);
    if (!r.ok) return r;
    await this.deps.repo.atualizar(r.valor);
    await ctx.efeitos.auditar('inventario.contar', TABELA, e.id, undefined, { contagens: e.contagens.length });
    return okVazio();
  }
}

export class ConcluirInventario {
  constructor(private readonly deps: DepsInventario & { registrar: RegistrarMovimentacao }) {}
  async execute(ctx: ContextoCaso, e: { id: string }): Promise<Result<{ movimentacao_id: string | null; ajustes: number }>> {
    const atual = await this.deps.repo.obterPorId(e.id);
    if (!atual) return fail(erroDe('nao_encontrado', 'Inventario nao encontrado'));
    const d = atual.paraDados();
    const saldos = new Map<string, number>();
    for (const i of d.itens) if (i.quantidade_contada !== null) saldos.set(i.id, await this.deps.saldos.saldoAtual(d.deposito_id, i));
    const difs = atual.diferencas((i) => saldos.get(i.id) ?? 0);
    const previa = atual.concluir(null);
    if (!previa.ok) return previa;
    let movId: string | null = null;
    if (difs.length) {
      const m = await this.deps.registrar.execute(ctx, {
        tipo: 'ajuste', motivo: `Inventario: ${d.descricao}`.slice(0, 500), deposito_id: d.deposito_id, inventario_id: d.id,
        itens: difs.map((x) => ({ produto_id: x.item.produto_id, variacao_id: x.item.variacao_id, lote_id: x.item.lote_id, local_id: x.item.local_id, quantidade: x.diferenca })),
      });
      if (!m.ok) return m;
      movId = m.valor.id;
    }
    const r = atual.concluir(movId);
    if (!r.ok) return r;
    await this.deps.repo.atualizar(r.valor);
    await ctx.efeitos.historico(TABELA, e.id, { estado: 'aberto' }, { estado: 'concluido', movimentacao_id: movId });
    await ctx.efeitos.auditar('inventario.concluir', TABELA, e.id, { estado: 'aberto' }, { estado: 'concluido', movimentacao_id: movId, ajustes: difs.length });
    return ok({ movimentacao_id: movId, ajustes: difs.length });
  }
}

export class CancelarInventario {
  constructor(private readonly deps: DepsInventario) {}
  async execute(ctx: ContextoCaso, e: { id: string }): Promise<Result<void>> {
    const atual = await this.deps.repo.obterPorId(e.id);
    if (!atual) return fail(erroDe('nao_encontrado', 'Inventario nao encontrado'));
    const r = atual.cancelar();
    if (!r.ok) return r;
    await this.deps.repo.atualizar(r.valor);
    await ctx.efeitos.historico(TABELA, e.id, { estado: 'aberto' }, { estado: 'cancelado' });
    await ctx.efeitos.auditar('inventario.cancelar', TABELA, e.id, { estado: 'aberto' }, { estado: 'cancelado' });
    return okVazio();
  }
}
