/** Rotas da Reposicao (M9.4): historico de alertas e verificacao sob demanda (job). A lista e a tool reposicao.listar. */
import { requer, type FastifyInstance } from '@erp/api/sdk';
import { naTransacao } from '../borda.ts';
import { exigirOk } from '../compartilhado/result.ts';
import { listarAlertas } from './consultas.ts';

const tags = ['estoque'];

export function rotasReposicao(app: FastifyInstance): void {
  app.get('/alertas', {
    preHandler: requer('estoque.ver'),
    schema: { tags, summary: 'Ultimos 100 alertas de reposicao (abertos e resolvidos)' },
  }, (req) => naTransacao(req, (_, __, c) => listarAlertas(c)));

  app.post('/reposicao/verificar', {
    preHandler: requer('estoque.editar'),
    schema: { tags, summary: 'Agenda a verificacao de todos os produtos com estoque minimo (job estoque.verificar_reposicao)' },
  }, async (req, reply) => reply.code(202).send(await naTransacao(req, async (casos, ctx) => exigirOk(await casos.solicitarVerificacaoReposicao.execute(ctx)))));
}
