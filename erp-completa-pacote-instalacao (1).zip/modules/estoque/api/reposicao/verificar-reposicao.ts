/**
 * Reposicao (M9.4, job): a movimentacao (ou o botao Verificar agora) grava a intencao na outbox;
 * o worker roda VerificarReposicao, que abre alerta e publica estoque.abaixo_minimo quando o saldo
 * fica abaixo do minimo, atualiza o alerta aberto e o resolve quando o saldo volta ao minimo.
 */
import { randomUUID } from 'node:crypto';
import { ok, type Result } from '../compartilhado/result.ts';
import type { ContextoCaso } from '../compartilhado/efeitos.ts';
import type { FilaJobs } from '../movimentacao/model/portas.ts';
import { TIPO_JOB_REPOSICAO } from '../movimentacao/use-case/movimentacoes.ts';

export interface ProdutoReposicao { id: string; sku: string; nome: string; estoque_minimo: number; saldo: number }

export interface PortaReposicao {
  /** Sem ids: todos os produtos ativos com estoque minimo. Com ids: esses produtos (mesmo sem minimo, para resolver alerta). */
  produtosParaVerificar(ids?: string[]): Promise<ProdutoReposicao[]>;
  alertaAberto(produtoId: string): Promise<{ id: string; saldo: number } | null>;
  abrirAlerta(a: { id: string; produto_id: string; saldo: number; estoque_minimo: number }): Promise<void>;
  atualizarAlerta(id: string, saldo: number): Promise<void>;
  resolverAlerta(id: string, saldo: number): Promise<void>;
}

export class SolicitarVerificacaoReposicao {
  constructor(private readonly deps: { fila: FilaJobs }) {}
  async execute(ctx: ContextoCaso): Promise<Result<{ job_id: string }>> {
    const job = await this.deps.fila.enfileirar(TIPO_JOB_REPOSICAO, { todos: true });
    await ctx.efeitos.auditar('reposicao.verificar', 'estoque_alertas', null, undefined, { job_id: job });
    return ok({ job_id: job });
  }
}

export class VerificarReposicao {
  constructor(private readonly deps: { repo: PortaReposicao; novoId?: () => string }) {}
  async execute(ctx: ContextoCaso, e: { produto_ids?: string[] }): Promise<Result<{ abertos: number; resolvidos: number; atualizados: number }>> {
    const produtos = await this.deps.repo.produtosParaVerificar(e.produto_ids?.length ? e.produto_ids : undefined);
    let abertos = 0;
    let resolvidos = 0;
    let atualizados = 0;
    for (const p of produtos) {
      const alerta = await this.deps.repo.alertaAberto(p.id);
      const abaixo = p.estoque_minimo > 0 && p.saldo < p.estoque_minimo;
      if (abaixo && !alerta) {
        const id = (this.deps.novoId ?? randomUUID)();
        await this.deps.repo.abrirAlerta({ id, produto_id: p.id, saldo: p.saldo, estoque_minimo: p.estoque_minimo });
        await ctx.efeitos.publicar('estoque.abaixo_minimo', {
          alerta_id: id, produto_id: p.id, sku: p.sku, nome: p.nome, saldo: p.saldo, estoque_minimo: p.estoque_minimo,
          sugestao_compra: Math.max(p.estoque_minimo * 2 - p.saldo, 0),
        });
        await ctx.efeitos.nota('estoque_produtos', p.id, `Saldo ${p.saldo} abaixo do minimo ${p.estoque_minimo}: alerta de reposicao aberto`);
        abertos++;
      } else if (abaixo && alerta && alerta.saldo !== p.saldo) {
        await this.deps.repo.atualizarAlerta(alerta.id, p.saldo);
        atualizados++;
      } else if (!abaixo && alerta) {
        await this.deps.repo.resolverAlerta(alerta.id, p.saldo);
        await ctx.efeitos.nota('estoque_produtos', p.id, `Saldo ${p.saldo} voltou ao minimo: alerta de reposicao resolvido`);
        resolvidos++;
      }
    }
    return ok({ abertos, resolvidos, atualizados });
  }
}
