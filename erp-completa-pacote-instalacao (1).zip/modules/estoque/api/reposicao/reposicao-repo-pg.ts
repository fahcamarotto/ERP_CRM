/** Adaptador Postgres da reposicao (M9.4): saldo total por produto e alertas em estoque_alertas. */
import type pg from 'pg';
import type { PortaReposicao, ProdutoReposicao } from './verificar-reposicao.ts';

export class ReposicaoRepoPg implements PortaReposicao {
  constructor(private readonly c: pg.PoolClient) {}

  async produtosParaVerificar(ids?: string[]): Promise<ProdutoReposicao[]> {
    const r = await this.c.query(
      `SELECT p.id, p.sku, p.nome, p.estoque_minimo::float8 AS estoque_minimo,
         coalesce((SELECT sum(s.quantidade) FROM estoque_saldos s WHERE s.produto_id = p.id), 0)::float8 AS saldo
       FROM estoque_produtos p
       WHERE p.deleted_at IS NULL AND (($1::uuid[] IS NULL AND p.estado = 'ativo' AND p.estoque_minimo > 0) OR p.id = ANY ($1::uuid[]))
       ORDER BY p.sku`,
      [ids ?? null],
    );
    return r.rows as ProdutoReposicao[];
  }

  async alertaAberto(produtoId: string) {
    const r = await this.c.query("SELECT id, saldo::float8 AS saldo FROM estoque_alertas WHERE produto_id = $1 AND estado = 'aberto' AND deleted_at IS NULL", [produtoId]);
    return r.rows[0] ?? null;
  }

  async abrirAlerta(a: { id: string; produto_id: string; saldo: number; estoque_minimo: number }): Promise<void> {
    await this.c.query('INSERT INTO estoque_alertas (id, produto_id, saldo, estoque_minimo, creator_id) VALUES ($1, $2, $3, $4, nucleo_usuario_atual())',
      [a.id, a.produto_id, a.saldo, a.estoque_minimo]);
  }

  async atualizarAlerta(id: string, saldo: number): Promise<void> {
    await this.c.query('UPDATE estoque_alertas SET saldo = $2 WHERE id = $1', [id, saldo]);
  }

  async resolverAlerta(id: string, saldo: number): Promise<void> {
    await this.c.query("UPDATE estoque_alertas SET estado = 'resolvido', saldo = $2, resolvido_em = now() WHERE id = $1", [id, saldo]);
  }
}
