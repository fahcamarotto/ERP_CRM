/** Consultas da Reposicao (M9.4): produtos abaixo do minimo com sugestao de compra e historico de alertas. */
import type pg from 'pg';

export async function listarReposicao(c: pg.PoolClient) {
  return (await c.query(
    `SELECT * FROM (
       SELECT p.id, p.sku, p.nome, p.unidade, p.estoque_minimo::float8 AS estoque_minimo, p.custo_medio::float8 AS custo_medio,
         p.fornecedor_id, f.nome AS fornecedor_nome,
         coalesce((SELECT sum(s.quantidade) FROM estoque_saldos s WHERE s.produto_id = p.id), 0)::float8 AS saldo,
         a.id AS alerta_id, a.created_at AS alerta_em
       FROM estoque_produtos p
       LEFT JOIN cadastros_parceiros f ON f.id = p.fornecedor_id AND f.deleted_at IS NULL
       LEFT JOIN estoque_alertas a ON a.produto_id = p.id AND a.estado = 'aberto' AND a.deleted_at IS NULL
       WHERE p.deleted_at IS NULL AND p.estado = 'ativo' AND p.estoque_minimo > 0) x
     WHERE x.saldo < x.estoque_minimo ORDER BY (x.saldo / x.estoque_minimo), x.nome`,
  )).rows.map((x) => ({ ...x, sugestao_compra: Math.max(Number(x.estoque_minimo) * 2 - Number(x.saldo), 0) }));
}

export async function listarAlertas(c: pg.PoolClient) {
  return (await c.query(
    `SELECT a.id, a.produto_id, p.sku, p.nome, a.saldo::float8 AS saldo, a.estoque_minimo::float8 AS estoque_minimo, a.estado,
       a.created_at, a.resolvido_em
     FROM estoque_alertas a JOIN estoque_produtos p ON p.id = a.produto_id
     WHERE a.deleted_at IS NULL ORDER BY a.created_at DESC LIMIT 100`,
  )).rows;
}
