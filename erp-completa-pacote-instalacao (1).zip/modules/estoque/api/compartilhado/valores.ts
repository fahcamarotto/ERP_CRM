/**
 * Objetos de valor numericos e de codigo usados por mais de um agregado do Estoque
 * (quantidade com 3 casas, dinheiro, codigo SKU). Sem dependencia externa.
 */
import { erroDe, fail, ok, type Result } from './result.ts';

export const arred = (v: number, casas: number): number => {
  const f = 10 ** casas;
  return Math.round((v + Number.EPSILON) * f) / f;
};

/** Quantidade de estoque: numero finito com ate 3 casas, limite de 99 bilhoes. */
export class Quantidade {
  private constructor(readonly valor: number) {}
  static tryCreate(bruto: unknown, campo = 'quantidade', opcoes: { positiva?: boolean; naoZero?: boolean; naoNegativa?: boolean } = {}): Result<Quantidade> {
    const n = typeof bruto === 'string' ? Number(bruto.replace(',', '.')) : Number(bruto);
    if (bruto === null || bruto === undefined || bruto === '' || !Number.isFinite(n) || Math.abs(n) >= 1e11) {
      return fail(erroDe('quantidade_invalida', 'Quantidade deve ser um numero', campo));
    }
    const v = arred(n, 3);
    if (opcoes.positiva && v <= 0) return fail(erroDe('quantidade_invalida', 'Quantidade deve ser maior que zero', campo));
    if (opcoes.naoZero && v === 0) return fail(erroDe('quantidade_invalida', 'Quantidade nao pode ser zero', campo));
    if (opcoes.naoNegativa && v < 0) return fail(erroDe('quantidade_invalida', 'Quantidade nao pode ser negativa', campo));
    return ok(new Quantidade(v));
  }
  static create(bruto: unknown, campo?: string, opcoes?: { positiva?: boolean; naoZero?: boolean; naoNegativa?: boolean }): Quantidade {
    const r = Quantidade.tryCreate(bruto, campo, opcoes);
    if (!r.ok) throw new Error(r.erros[0]!.mensagem);
    return r.valor;
  }
}

/** Valor monetario nao negativo com `casas` decimais (custo 4, preco 2). */
export class Dinheiro {
  private constructor(readonly valor: number) {}
  static tryCreate(bruto: unknown, campo: string, casas = 2): Result<Dinheiro> {
    const n = Number(bruto ?? 0);
    if (!Number.isFinite(n) || n < 0 || n >= 1e10) return fail(erroDe('valor_invalido', 'Valor deve ser zero ou positivo', campo));
    return ok(new Dinheiro(arred(n, casas)));
  }
  static create(bruto: unknown, campo: string, casas = 2): Dinheiro {
    const r = Dinheiro.tryCreate(bruto, campo, casas);
    if (!r.ok) throw new Error(r.erros[0]!.mensagem);
    return r.valor;
  }
}

/** Codigo interno (SKU, codigo de deposito ou de local): maiusculas, digitos, ponto, hifen e sublinhado. */
export class Codigo {
  private constructor(readonly valor: string) {}
  static tryCreate(bruto: unknown, campo = 'sku', max = 40): Result<Codigo> {
    const v = String(bruto ?? '').trim().toUpperCase().replace(/\s+/g, '-');
    if (!v || v.length > max || !/^[A-Z0-9._-]+$/.test(v)) {
      return fail(erroDe('codigo_invalido', `Codigo deve ter de 1 a ${max} caracteres (letras, numeros, ponto, hifen)`, campo));
    }
    return ok(new Codigo(v));
  }
  static create(bruto: unknown, campo?: string, max?: number): Codigo {
    const r = Codigo.tryCreate(bruto, campo, max);
    if (!r.ok) throw new Error(r.erros[0]!.mensagem);
    return r.valor;
  }
}

export const texto = (v?: string | null): string | null => (v ?? '').trim() || null;
export const dataValida = (v: string | null): boolean => v === null || (/^\d{4}-\d{2}-\d{2}$/.test(v) && !Number.isNaN(Date.parse(v)));

/**
 * M9.7 custo medio ponderado depois de uma entrada (quantidade positiva) ou do estorno de uma entrada
 * (quantidade negativa): (saldo x medio + quantidade x custo) / (saldo + quantidade).
 */
export function custoMedioPonderado(saldo: number, medio: number, quantidade: number, custo: number): number {
  const total = saldo + quantidade;
  if (quantidade > 0 && saldo <= 0) return arred(custo, 4);
  if (total <= 0) return arred(medio, 4);
  return Math.max(0, arred((saldo * medio + quantidade * custo) / total, 4));
}
