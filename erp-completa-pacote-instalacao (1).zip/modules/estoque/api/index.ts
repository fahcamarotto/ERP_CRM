/**
 * Plugin do modulo Estoque (M9), registrado sozinho com prefixo /api/v1/estoque.
 * Importar ./tools.ts registra as @tool (MCP e REST) no carregamento.
 */
import type { FastifyPluginAsync } from '@erp/api/sdk';
import './tools.ts';
import { rotasDeposito } from './deposito/routes.ts';
import { rotasInventario } from './inventario/routes.ts';
import { rotasMovimentacao } from './movimentacao/routes.ts';
import { rotasProduto } from './produto/routes.ts';
import { rotasReposicao } from './reposicao/routes.ts';

const plugin: FastifyPluginAsync = async (app) => {
  rotasProduto(app);
  rotasDeposito(app);
  rotasMovimentacao(app);
  rotasReposicao(app);
  rotasInventario(app);
};

export default plugin;
