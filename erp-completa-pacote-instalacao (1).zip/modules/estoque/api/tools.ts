/**
 * @tool do Estoque (N15): cada chamada vira tool MCP em /mcp e rota REST com o mesmo schema no OpenAPI.
 * Tools do M9.9: estoque.saldo e produtos.listar; mais produtos.obter, produtos.criar,
 * movimentacoes.registrar e reposicao.listar.
 */
import { tool } from '@erp/api/sdk';
import { naoEncontrado } from './borda.ts';
import { contextoPg } from './compartilhado/efeitos-pg.ts';
import { exigirOk } from './compartilhado/result.ts';
import { estadosCadastro, paginacao, propsMovimentacao, propsProduto, uuid } from './esquemas.ts';
import { casosDeUso } from './fabrica.ts';
import { obterMovimentacao } from './movimentacao/query/movimentacoes.ts';
import type { EntradaMovimentacao } from './movimentacao/use-case/movimentacoes.ts';
import type { DadosProduto } from './produto/model/produto.ts';
import { listarProdutos, obterProduto, saldoEstoque, type FiltroProdutos } from './produto/query/produtos.ts';
import { listarReposicao } from './reposicao/consultas.ts';

tool<FiltroProdutos>({
  nome: 'produtos.listar', modulo: 'estoque', titulo: 'Listar produtos', tipo: 'leitura', permissao: 'estoque.ver',
  descricao: 'Lista produtos do estoque com SKU, unidade, saldo total, estoque minimo, custo medio, preco e valor em estoque; busca por nome, SKU ou codigo de barras e filtra os abaixo do minimo.',
  entrada: { type: 'object', properties: { ...paginacao, estado: { type: 'string', enum: [...estadosCadastro, 'todos'], default: 'ativo' }, abaixo_minimo: { type: 'boolean' } } },
  rota: { metodo: 'GET', caminho: '/api/v1/estoque/produtos' },
  executar: ({ c }, a) => listarProdutos(c, a),
});

tool<{ id: string }>({
  nome: 'produtos.obter', modulo: 'estoque', titulo: 'Obter produto', tipo: 'leitura', permissao: 'estoque.ver',
  descricao: 'Ficha do produto pelo id: dados, atributos, variacoes, lotes com validade e saldo por deposito, local, variacao e lote.',
  entrada: { type: 'object', required: ['id'], properties: { id: uuid } },
  rota: { metodo: 'GET', caminho: '/api/v1/estoque/produtos/:id' },
  executar: async ({ c }, a) => (await obterProduto(c, a.id)) ?? Promise.reject(naoEncontrado('Produto nao encontrado')),
});

tool<DadosProduto>({
  nome: 'produtos.criar', modulo: 'estoque', titulo: 'Criar produto', tipo: 'escrita', permissao: 'estoque.criar',
  descricao: 'Cadastra produto com SKU unico, unidade, codigo de barras GTIN, custo, preco, estoque minimo, grade de atributos e controle de lote. Saldo comeca em zero; use movimentacoes.registrar para dar entrada.',
  entrada: { type: 'object', required: ['sku', 'nome'], properties: propsProduto },
  rota: { metodo: 'POST', caminho: '/api/v1/estoque/produtos' },
  executar: async ({ c, ator, ip }, a) => {
    const { id } = exigirOk(await casosDeUso(c).criarProduto.execute(contextoPg(c, ator, ip), a));
    return obterProduto(c, id);
  },
});

tool<{ produto_id?: string; sku?: string; deposito_id?: string; busca?: string }>({
  nome: 'estoque.saldo', modulo: 'estoque', titulo: 'Saldo em estoque', tipo: 'leitura', permissao: 'estoque.ver',
  descricao: 'Saldo atual por produto e deposito (soma das movimentacoes), com custo medio e valor em estoque, mais o valor total. Filtra por produto, SKU, deposito ou busca.',
  entrada: { type: 'object', properties: { produto_id: uuid, sku: { type: 'string', maxLength: 40 }, deposito_id: uuid, busca: { type: 'string', maxLength: 120 } } },
  rota: { metodo: 'GET', caminho: '/api/v1/estoque/saldo' },
  executar: ({ c }, a) => saldoEstoque(c, a),
});

tool<EntradaMovimentacao>({
  nome: 'movimentacoes.registrar', modulo: 'estoque', titulo: 'Registrar movimentacao', tipo: 'escrita', permissao: 'estoque.criar',
  descricao: 'Registra entrada, saida, transferencia entre depositos ou ajuste, sempre com motivo. Recusa saldo negativo, cria o lote pelo codigo na entrada, recalcula o custo medio e agenda a verificacao de reposicao.',
  entrada: { type: 'object', required: ['tipo', 'motivo', 'deposito_id', 'itens'], properties: propsMovimentacao },
  rota: { metodo: 'POST', caminho: '/api/v1/estoque/movimentacoes' },
  executar: async ({ c, ator, ip }, a) => {
    const { id } = exigirOk(await casosDeUso(c).registrarMovimentacao.execute(contextoPg(c, ator, ip), a));
    return obterMovimentacao(c, id);
  },
});

tool<Record<string, never>>({
  nome: 'reposicao.listar', modulo: 'estoque', titulo: 'Produtos para repor', tipo: 'leitura', permissao: 'estoque.ver',
  descricao: 'Produtos ativos com saldo abaixo do estoque minimo, com fornecedor, alerta aberto e sugestao de compra (dobro do minimo menos o saldo).',
  entrada: { type: 'object', properties: {} },
  rota: { metodo: 'GET', caminho: '/api/v1/estoque/reposicao' },
  executar: ({ c }) => listarReposicao(c),
});
