/**
 * Casos de uso da Movimentacao (M9.3, M9.6, M9.7):
 * RegistrarMovimentacao confere produtos, variacoes, lotes, depositos e locais, impede saldo negativo,
 * resolve ou cria o lote pela entrada, recalcula o custo medio nas entradas, grava as linhas e
 * enfileira a verificacao de reposicao (M9.4) na outbox, na mesma transacao.
 * EstornarMovimentacao grava a movimentacao inversa e marca a original como estornada.
 */
import { erroDe, fail, ok, type ErroDominio, type Result } from '../../compartilhado/result.ts';
import type { ContextoCaso } from '../../compartilhado/efeitos.ts';
import { custoMedioPonderado, texto } from '../../compartilhado/valores.ts';
import { Lote } from '../../produto/model/produto.ts';
import type { GravarLotes } from '../../produto/model/portas.ts';
import { chaveSaldo, Movimentacao, type DadosMovimentacao, type ItemMovimentacao, type Linha, type TipoMovimentacao } from '../model/movimentacao.ts';
import type { AtualizarCustoMedio, ConsultarReferenciasMovimentacao, ConsultarSaldo, FilaJobs, GravarMovimentacao, ObterMovimentacao, ProdutoMov } from '../model/portas.ts';

export const TIPO_JOB_REPOSICAO = 'estoque.verificar_reposicao';
const TABELA = 'estoque_movimentacoes';

/** Item como chega da API: o lote pode vir por codigo (com validade) na entrada. */
export interface ItemEntrada extends ItemMovimentacao {
  lote_codigo?: string | null;
  validade?: string | null;
  fabricacao?: string | null;
}
export type EntradaMovimentacao = Omit<DadosMovimentacao, 'itens'> & { itens: ItemEntrada[] };

export interface DepsMovimentacao {
  repo: ObterMovimentacao & GravarMovimentacao;
  refs: ConsultarReferenciasMovimentacao;
  saldos: ConsultarSaldo;
  custos: AtualizarCustoMedio;
  lotes: GravarLotes;
  fila: FilaJobs;
}

const casasDe = (v: number) => (String(v).split('.')[1] ?? '').length;

/** Confere saldo: nenhuma chave pode ficar negativa depois das linhas da movimentacao. */
async function conferirSaldo(saldos: ConsultarSaldo, linhas: Linha[], produtos: Map<string, ProdutoMov>): Promise<ErroDominio[]> {
  const delta = new Map<string, { linha: Linha; q: number }>();
  for (const l of linhas) {
    const k = chaveSaldo(l);
    const a = delta.get(k);
    delta.set(k, { linha: l, q: (a?.q ?? 0) + l.quantidade });
  }
  const erros: ErroDominio[] = [];
  for (const { linha, q } of delta.values()) {
    if (q >= 0) continue;
    const disponivel = await saldos.saldo(linha);
    if (disponivel + q < -1e-9) {
      const p = produtos.get(linha.produto_id);
      erros.push(erroDe('saldo_insuficiente', `Saldo insuficiente de ${p?.sku ?? linha.produto_id}: disponivel ${disponivel}, solicitado ${-q}`, 'itens',
        { produto_id: linha.produto_id, deposito_id: linha.deposito_id, lote_id: linha.lote_id, disponivel, solicitado: -q }));
    }
  }
  return erros;
}

export class RegistrarMovimentacao {
  constructor(private readonly deps: DepsMovimentacao) {}

  async execute(ctx: ContextoCaso, e: EntradaMovimentacao): Promise<Result<{ id: string }>> {
    const { refs } = this.deps;
    const ids = [...new Set((e.itens ?? []).map((i) => i.produto_id).filter(Boolean))];
    const produtos = new Map((await refs.produtos(ids)).map((p) => [p.id, p]));
    const erros: ErroDominio[] = [];
    if (e.deposito_id && !(await refs.depositoAtivo(e.deposito_id))) erros.push(erroDe('deposito_invalido', 'Deposito nao encontrado ou arquivado', 'deposito_id'));
    if (e.deposito_destino_id && !(await refs.depositoAtivo(e.deposito_destino_id))) erros.push(erroDe('deposito_invalido', 'Deposito de destino nao encontrado ou arquivado', 'deposito_destino_id'));
    if (e.parceiro_id && !(await refs.parceiroAtivo(e.parceiro_id))) erros.push(erroDe('parceiro_invalido', 'Parceiro nao encontrado ou arquivado no Cadastros', 'parceiro_id'));

    const itens: ItemMovimentacao[] = [];
    for (const [i, it] of (e.itens ?? []).entries()) {
      const campo = `itens.${i}`;
      const p = produtos.get(it.produto_id);
      if (!p) { erros.push(erroDe('produto_invalido', 'Produto nao encontrado', `${campo}.produto_id`)); continue; }
      if (p.estado !== 'ativo' && (e.tipo === 'entrada' || Number(it.quantidade) > 0 && e.tipo === 'ajuste')) {
        erros.push(erroDe('produto_invalido', `Produto ${p.sku} arquivado nao recebe entrada`, `${campo}.produto_id`));
      }
      if (casasDe(Math.abs(Number(it.quantidade))) > p.casas) {
        erros.push(erroDe('quantidade_invalida', `A unidade de ${p.sku} aceita ${p.casas} casa(s) decimal(is)`, `${campo}.quantidade`));
      }
      if (it.variacao_id && !(await refs.variacaoDoProduto(it.variacao_id, p.id))) erros.push(erroDe('variacao_invalida', 'Variacao nao pertence ao produto', `${campo}.variacao_id`));
      if (it.local_id && !(await refs.localDoDeposito(it.local_id, e.deposito_id))) erros.push(erroDe('local_invalido', 'Local nao pertence ao deposito', `${campo}.local_id`));
      if (it.local_destino_id && (!e.deposito_destino_id || !(await refs.localDoDeposito(it.local_destino_id, e.deposito_destino_id)))) {
        erros.push(erroDe('local_invalido', 'Local nao pertence ao deposito de destino', `${campo}.local_destino_id`));
      }
      let loteId = texto(it.lote_id);
      const codigoLote = texto(it.lote_codigo);
      if (!p.controla_lote && (loteId || codigoLote)) erros.push(erroDe('lote_invalido', `Produto ${p.sku} nao controla lote`, `${campo}.lote_id`));
      if (p.controla_lote) {
        const entra = e.tipo === 'entrada' || (e.tipo === 'ajuste' && Number(it.quantidade) > 0);
        if (loteId && !(await refs.loteDoProduto(loteId, p.id))) erros.push(erroDe('lote_invalido', 'Lote nao pertence ao produto', `${campo}.lote_id`));
        else if (!loteId && codigoLote && entra) {
          const existente = await this.deps.lotes.buscarLote(p.id, codigoLote);
          if (existente) loteId = existente.id;
          else {
            const novo = Lote.tryCreate({ produto_id: p.id, codigo: codigoLote, validade: it.validade, fabricacao: it.fabricacao });
            if (!novo.ok) erros.push(...novo.erros.map((x) => ({ ...x, campo: `${campo}.${x.campo ?? 'lote_codigo'}` })));
            else { await this.deps.lotes.inserirLote(novo.valor); loteId = novo.valor.dados.id; }
          }
        } else if (!loteId) erros.push(erroDe('lote_obrigatorio', `Produto ${p.sku} controla lote: informe o lote`, `${campo}.lote_id`));
      }
      const custo = e.tipo === 'entrada' && it.custo_unitario !== undefined && it.custo_unitario !== null ? Number(it.custo_unitario) : p.custo_medio;
      itens.push({ ...it, lote_id: loteId, custo_unitario: custo });
    }
    const r = Movimentacao.tryCreate({ ...e, itens });
    if (!r.ok) return fail(...erros, ...r.erros);
    if (erros.length) return fail(...erros);

    const linhas = r.valor.linhas;
    const semSaldo = await conferirSaldo(this.deps.saldos, linhas, produtos);
    if (semSaldo.length) return fail(...semSaldo);

    await this.recalcularCustos(e.tipo, linhas, produtos, 1);
    await this.deps.repo.inserir(r.valor);
    const d = r.valor.paraDados();
    await ctx.efeitos.auditar(`movimentacao.${d.tipo}`, TABELA, d.id, undefined, d);
    await this.enfileirarReposicao(linhas, produtos);
    return ok({ id: d.id });
  }

  /** M9.7: entradas recalculam o custo medio ponderado do produto (estorno de entrada desfaz com sinal -1). */
  async recalcularCustos(tipo: TipoMovimentacao, linhas: Linha[], produtos: Map<string, ProdutoMov>, sinal: 1 | -1): Promise<void> {
    if (tipo !== 'entrada') return;
    const medios = new Map<string, { saldo: number; medio: number }>();
    for (const l of linhas) {
      const p = produtos.get(l.produto_id);
      if (!p) continue;
      const atual = medios.get(p.id) ?? { saldo: await this.deps.saldos.saldoProduto(p.id), medio: p.custo_medio };
      const q = Math.abs(l.quantidade) * sinal;
      medios.set(p.id, { saldo: atual.saldo + q, medio: custoMedioPonderado(atual.saldo, atual.medio, q, l.custo_unitario) });
    }
    for (const [id, m] of medios) await this.deps.custos.atualizarCustoMedio(id, m.medio);
  }

  /** M9.4: saida de produto com estoque minimo enfileira o job que abre (ou resolve) o alerta. */
  async enfileirarReposicao(linhas: Linha[], produtos: Map<string, ProdutoMov>): Promise<void> {
    const alvo = [...new Set(linhas.map((l) => l.produto_id))].filter((id) => (produtos.get(id)?.estoque_minimo ?? 0) > 0);
    if (alvo.length) await this.deps.fila.enfileirar(TIPO_JOB_REPOSICAO, { produto_ids: alvo });
  }
}

export class EstornarMovimentacao {
  constructor(private readonly deps: DepsMovimentacao & { registrar: RegistrarMovimentacao }) {}

  async execute(ctx: ContextoCaso, e: { id: string; motivo?: string | null }): Promise<Result<{ id: string }>> {
    const original = await this.deps.repo.obterPorId(e.id);
    if (!original) return fail(erroDe('nao_encontrado', 'Movimentacao nao encontrada'));
    const r = original.estornar(e.motivo);
    if (!r.ok) return r;
    const linhas = r.valor.estorno.linhas;
    const produtos = new Map((await this.deps.refs.produtos([...new Set(linhas.map((l) => l.produto_id))])).map((p) => [p.id, p]));
    const semSaldo = await conferirSaldo(this.deps.saldos, linhas, produtos);
    if (semSaldo.length) return fail(...semSaldo);
    const dados = original.paraDados();
    await this.deps.registrar.recalcularCustos(dados.tipo, original.linhas, produtos, -1);
    await this.deps.repo.inserir(r.valor.estorno);
    await this.deps.repo.atualizarEstado(r.valor.original);
    const novo = r.valor.estorno.id;
    await ctx.efeitos.historico(TABELA, e.id, { estado: 'confirmada' }, { estado: 'estornada', estorno_id: novo });
    await ctx.efeitos.auditar('movimentacao.estornar', TABELA, e.id, { estado: 'confirmada' }, { estado: 'estornada', estorno_id: novo });
    await this.deps.registrar.enfileirarReposicao(linhas, produtos);
    return ok({ id: novo });
  }
}
