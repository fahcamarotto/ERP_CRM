/** Consultas da Movimentacao: lista (mais recentes primeiro, cursor) e ficha com as linhas. */
import type pg from 'pg';
import { decodificarCursor, pagina } from '../../compartilhado/cursor.ts';

const RESUMO = `m.id, m.tipo, m.motivo, to_char(m.data, 'YYYY-MM-DD') AS data, m.documento, m.parceiro_id, pc.nome AS parceiro_nome,
  m.deposito_id, d.nome AS deposito_nome, m.deposito_destino_id, dd.nome AS deposito_destino_nome, m.estado, m.estorno_de_id,
  m.inventario_id, u.nome AS criado_por, m.created_at,
  (SELECT count(*)::int FROM estoque_movimentacao_itens i WHERE i.movimentacao_id = m.id AND (m.tipo <> 'transferencia' OR i.quantidade > 0)) AS itens_qtd,
  (SELECT sum(abs(i.quantidade))::float8 FROM estoque_movimentacao_itens i WHERE i.movimentacao_id = m.id AND (m.tipo <> 'transferencia' OR i.quantidade > 0)) AS quantidade_total,
  (SELECT e.id FROM estoque_movimentacoes e WHERE e.estorno_de_id = m.id AND e.deleted_at IS NULL) AS estornada_por_id`;

const JUNCOES = `FROM estoque_movimentacoes m
  JOIN estoque_depositos d ON d.id = m.deposito_id
  LEFT JOIN estoque_depositos dd ON dd.id = m.deposito_destino_id
  LEFT JOIN cadastros_parceiros pc ON pc.id = m.parceiro_id
  LEFT JOIN usuarios u ON u.id = m.creator_id`;

export interface FiltroMovimentacoes {
  tipo?: string;
  produto_id?: string;
  deposito_id?: string;
  limite?: number;
  cursor?: string;
}

export async function listarMovimentacoes(c: pg.PoolClient, f: FiltroMovimentacoes) {
  const lim = Math.min(Math.max(f.limite ?? 50, 1), 200);
  const cur = decodificarCursor(f.cursor);
  const r = await c.query(
    `SELECT ${RESUMO} ${JUNCOES}
     WHERE m.deleted_at IS NULL AND ($1::text IS NULL OR m.tipo = $1)
       AND ($2::uuid IS NULL OR EXISTS (SELECT 1 FROM estoque_movimentacao_itens i WHERE i.movimentacao_id = m.id AND i.produto_id = $2))
       AND ($3::uuid IS NULL OR m.deposito_id = $3 OR m.deposito_destino_id = $3)
       AND ($4::timestamptz IS NULL OR (m.created_at, m.id) < ($4::timestamptz, $5::uuid))
     ORDER BY m.created_at DESC, m.id DESC LIMIT $6`,
    [f.tipo ?? null, f.produto_id ?? null, f.deposito_id ?? null, cur?.[0] ?? null, cur?.[1] ?? null, lim + 1],
  );
  return pagina(r.rows, lim);
}

export async function obterMovimentacao(c: pg.PoolClient, id: string) {
  const r = await c.query(
    `SELECT ${RESUMO},
       coalesce((SELECT json_agg(json_build_object('id', i.id, 'produto_id', i.produto_id, 'sku', p.sku, 'produto_nome', p.nome, 'unidade', p.unidade,
         'variacao_nome', v.nome, 'lote_codigo', l.codigo, 'deposito_nome', dp.nome, 'local_codigo', lc.codigo,
         'quantidade', i.quantidade::float8, 'custo_unitario', i.custo_unitario::float8) ORDER BY i.created_at, i.id)
         FROM estoque_movimentacao_itens i JOIN estoque_produtos p ON p.id = i.produto_id JOIN estoque_depositos dp ON dp.id = i.deposito_id
         LEFT JOIN estoque_variacoes v ON v.id = i.variacao_id LEFT JOIN estoque_lotes l ON l.id = i.lote_id
         LEFT JOIN estoque_locais lc ON lc.id = i.local_id
         WHERE i.movimentacao_id = m.id AND i.deleted_at IS NULL), '[]') AS linhas
     ${JUNCOES} WHERE m.id = $1 AND m.deleted_at IS NULL`,
    [id],
  );
  return r.rows[0] ?? null;
}
