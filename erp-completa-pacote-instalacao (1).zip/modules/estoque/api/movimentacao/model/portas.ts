/** Portas do agregado Movimentacao. */
import type { Linha, Movimentacao } from './movimentacao.ts';

/** O que a movimentacao precisa saber do produto (lido do agregado Produto). */
export interface ProdutoMov {
  id: string;
  sku: string;
  nome: string;
  estado: 'ativo' | 'arquivado';
  controla_lote: boolean;
  custo_medio: number;
  estoque_minimo: number;
  /** Casas decimais aceitas pela unidade do produto. */
  casas: number;
}

export interface ObterMovimentacao {
  obterPorId(id: string): Promise<Movimentacao | null>;
}

export interface GravarMovimentacao {
  inserir(m: Movimentacao): Promise<void>;
  atualizarEstado(m: Movimentacao): Promise<void>;
}

export interface ConsultarReferenciasMovimentacao {
  produtos(ids: string[]): Promise<ProdutoMov[]>;
  depositoAtivo(id: string): Promise<boolean>;
  variacaoDoProduto(variacaoId: string, produtoId: string): Promise<boolean>;
  loteDoProduto(loteId: string, produtoId: string): Promise<boolean>;
  localDoDeposito(localId: string, depositoId: string): Promise<boolean>;
  parceiroAtivo(id: string): Promise<boolean>;
}

export interface ConsultarSaldo {
  /** Saldo exato da chave (produto, variacao, lote, deposito, local). */
  saldo(chave: Pick<Linha, 'produto_id' | 'variacao_id' | 'lote_id' | 'deposito_id' | 'local_id'>): Promise<number>;
  /** Saldo do produto em todos os depositos (base do custo medio e da reposicao). */
  saldoProduto(produtoId: string): Promise<number>;
}

export interface AtualizarCustoMedio {
  atualizarCustoMedio(produtoId: string, custoMedio: number): Promise<void>;
}

/** Fila de jobs: grava a intencao na outbox (mesma transacao) e devolve o id do job. */
export interface FilaJobs {
  enfileirar(tipo: string, payload: Record<string, unknown>): Promise<string>;
}
