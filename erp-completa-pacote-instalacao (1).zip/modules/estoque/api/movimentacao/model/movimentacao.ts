/**
 * Agregado Movimentacao (M9.3): entrada, saida, transferencia e ajuste, sempre com motivo.
 * Gera as linhas do livro razao com quantidade com sinal; o saldo e a soma dessas linhas e nunca
 * e editado a mao. Maquina de estados: confirmada -> estornada (o estorno e outra movimentacao inversa).
 */
import { randomUUID } from 'node:crypto';
import { erroDe, fail, ok, type ErroDominio, type Result } from '../../compartilhado/result.ts';
import { dataValida, Dinheiro, Quantidade, texto } from '../../compartilhado/valores.ts';

export const TIPOS_MOVIMENTACAO = ['entrada', 'saida', 'transferencia', 'ajuste'] as const;
export type TipoMovimentacao = (typeof TIPOS_MOVIMENTACAO)[number];
export const ESTADOS_MOVIMENTACAO = ['confirmada', 'estornada'] as const;
export type EstadoMovimentacao = (typeof ESTADOS_MOVIMENTACAO)[number];
export const TRANSICOES: Record<EstadoMovimentacao, EstadoMovimentacao[]> = { confirmada: ['estornada'], estornada: [] };
export const MAX_ITENS = 200;

/** Item ja resolvido pelo caso de uso (lote encontrado ou criado, custo definido). */
export interface ItemMovimentacao {
  produto_id: string;
  variacao_id?: string | null;
  lote_id?: string | null;
  local_id?: string | null;
  local_destino_id?: string | null;
  /** Positiva; no ajuste o sinal diz se entra (+) ou sai (-). */
  quantidade: number;
  custo_unitario?: number | null;
}

export interface DadosMovimentacao {
  tipo: TipoMovimentacao;
  motivo: string;
  data?: string | null;
  documento?: string | null;
  parceiro_id?: string | null;
  deposito_id: string;
  deposito_destino_id?: string | null;
  inventario_id?: string | null;
  itens: ItemMovimentacao[];
}

export interface Linha {
  produto_id: string;
  variacao_id: string | null;
  lote_id: string | null;
  deposito_id: string;
  local_id: string | null;
  quantidade: number;
  custo_unitario: number;
}

export interface MovimentacaoDados {
  id: string;
  tipo: TipoMovimentacao;
  motivo: string;
  data: string;
  documento: string | null;
  parceiro_id: string | null;
  deposito_id: string;
  deposito_destino_id: string | null;
  estado: EstadoMovimentacao;
  estorno_de_id: string | null;
  inventario_id: string | null;
  linhas: Linha[];
}

/** Chave do saldo: produto, variacao, lote, deposito e local. */
export const chaveSaldo = (l: Pick<Linha, 'produto_id' | 'variacao_id' | 'lote_id' | 'deposito_id' | 'local_id'>) =>
  [l.produto_id, l.variacao_id ?? '', l.lote_id ?? '', l.deposito_id, l.local_id ?? ''].join('|');

export class Movimentacao {
  private constructor(private readonly d: MovimentacaoDados) {}

  static tryCreate(e: DadosMovimentacao, id: string = randomUUID(), hoje = new Date().toISOString().slice(0, 10)): Result<Movimentacao> {
    const erros: ErroDominio[] = [];
    const tipo = e.tipo;
    if (!TIPOS_MOVIMENTACAO.includes(tipo)) erros.push(erroDe('tipo_invalido', 'Tipo deve ser entrada, saida, transferencia ou ajuste', 'tipo'));
    const motivo = (e.motivo ?? '').trim();
    if (motivo.length < 3 || motivo.length > 500) erros.push(erroDe('motivo_obrigatorio', 'Motivo obrigatorio (3 a 500 caracteres)', 'motivo'));
    const data = texto(e.data) ?? hoje;
    if (!dataValida(data)) erros.push(erroDe('data_invalida', 'Data deve ser AAAA-MM-DD', 'data'));
    const destino = texto(e.deposito_destino_id);
    if (tipo === 'transferencia' && !destino) erros.push(erroDe('deposito_destino_obrigatorio', 'Transferencia precisa do deposito de destino', 'deposito_destino_id'));
    if (tipo === 'transferencia' && destino && destino === e.deposito_id) erros.push(erroDe('deposito_destino_invalido', 'Destino igual a origem', 'deposito_destino_id'));
    if (!e.deposito_id) erros.push(erroDe('deposito_obrigatorio', 'Informe o deposito', 'deposito_id'));
    const itens = e.itens ?? [];
    if (itens.length === 0) erros.push(erroDe('itens_obrigatorios', 'Informe ao menos um item', 'itens'));
    if (itens.length > MAX_ITENS) erros.push(erroDe('itens_demais', `Maximo de ${MAX_ITENS} itens`, 'itens'));

    const linhas: Linha[] = [];
    itens.forEach((it, i) => {
      const q = Quantidade.tryCreate(it.quantidade, `itens.${i}.quantidade`, tipo === 'ajuste' ? { naoZero: true } : { positiva: true });
      const c = Dinheiro.tryCreate(it.custo_unitario ?? 0, `itens.${i}.custo_unitario`, 4);
      if (!it.produto_id) erros.push(erroDe('produto_obrigatorio', 'Informe o produto', `itens.${i}.produto_id`));
      if (!q.ok) { erros.push(...q.erros); return; }
      if (!c.ok) { erros.push(...c.erros); return; }
      const base = { produto_id: it.produto_id, variacao_id: texto(it.variacao_id), lote_id: texto(it.lote_id), custo_unitario: c.valor.valor };
      const qtd = q.valor.valor;
      if (tipo === 'entrada') linhas.push({ ...base, deposito_id: e.deposito_id, local_id: texto(it.local_id), quantidade: qtd });
      else if (tipo === 'saida') linhas.push({ ...base, deposito_id: e.deposito_id, local_id: texto(it.local_id), quantidade: -qtd });
      else if (tipo === 'ajuste') linhas.push({ ...base, deposito_id: e.deposito_id, local_id: texto(it.local_id), quantidade: qtd });
      else if (destino) {
        linhas.push({ ...base, deposito_id: e.deposito_id, local_id: texto(it.local_id), quantidade: -qtd });
        linhas.push({ ...base, deposito_id: destino, local_id: texto(it.local_destino_id), quantidade: qtd });
      }
    });
    if (erros.length) return fail(...erros);
    return ok(new Movimentacao({
      id, tipo, motivo, data, documento: texto(e.documento), parceiro_id: texto(e.parceiro_id), deposito_id: e.deposito_id,
      deposito_destino_id: tipo === 'transferencia' ? destino : null, estado: 'confirmada', estorno_de_id: null,
      inventario_id: texto(e.inventario_id), linhas,
    }));
  }

  static create(e: DadosMovimentacao, id?: string): Movimentacao {
    const r = Movimentacao.tryCreate(e, id);
    if (!r.ok) throw new Error(r.erros.map((x) => x.mensagem).join('; '));
    return r.valor;
  }

  static reidratar(d: MovimentacaoDados): Movimentacao {
    return new Movimentacao({ ...d, linhas: d.linhas.map((l) => ({ ...l, quantidade: Number(l.quantidade), custo_unitario: Number(l.custo_unitario) })) });
  }

  get id(): string { return this.d.id; }
  get estado(): EstadoMovimentacao { return this.d.estado; }
  get linhas(): Linha[] { return this.d.linhas.map((l) => ({ ...l })); }

  /** Devolve a original marcada como estornada e a movimentacao inversa (mesmo tipo, linhas com sinal trocado). */
  estornar(motivo?: string | null, id: string = randomUUID(), hoje = new Date().toISOString().slice(0, 10)): Result<{ original: Movimentacao; estorno: Movimentacao }> {
    if (this.d.estorno_de_id) return fail(erroDe('transicao_invalida', 'Um estorno nao pode ser estornado', 'estado', { permitidas: [] }));
    if (!TRANSICOES[this.d.estado].includes('estornada')) {
      return fail(erroDe('transicao_invalida', `Movimentacao ${this.d.estado} nao pode ser estornada`, 'estado', { permitidas: TRANSICOES[this.d.estado] }));
    }
    const m = `Estorno: ${(texto(motivo) ?? this.d.motivo)}`.slice(0, 500);
    const estorno = new Movimentacao({
      ...this.d, id, motivo: m, data: hoje, estado: 'confirmada', estorno_de_id: this.d.id, inventario_id: null,
      linhas: this.d.linhas.map((l) => ({ ...l, quantidade: -l.quantidade })),
    });
    return ok({ original: new Movimentacao({ ...this.d, estado: 'estornada', linhas: this.linhas }), estorno });
  }

  paraDados(): MovimentacaoDados { return { ...this.d, linhas: this.linhas }; }
}
