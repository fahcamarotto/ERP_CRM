/** Rotas REST da Movimentacao fora das tools: lista, ficha e estorno. Registrar e @tool em ../tools.ts. */
import { esquemaErro, requer, type FastifyInstance } from '@erp/api/sdk';
import { naTransacao, naoEncontrado } from '../borda.ts';
import { exigirOk } from '../compartilhado/result.ts';
import { paginacao, tiposMovimentacao, uuid } from '../esquemas.ts';
import { listarMovimentacoes, obterMovimentacao, type FiltroMovimentacoes } from './query/movimentacoes.ts';

const tags = ['estoque'];
const paramId = { type: 'object', required: ['id'], properties: { id: uuid } } as const;

export function rotasMovimentacao(app: FastifyInstance): void {
  app.get<{ Querystring: FiltroMovimentacoes }>('/movimentacoes', {
    preHandler: requer('estoque.ver'),
    schema: {
      tags, summary: 'Movimentacoes (mais recentes primeiro)',
      querystring: { type: 'object', additionalProperties: false, properties: { tipo: { type: 'string', enum: [...tiposMovimentacao] }, produto_id: uuid, deposito_id: uuid, limite: paginacao.limite, cursor: paginacao.cursor } },
    },
  }, (req) => naTransacao(req, (_, __, c) => listarMovimentacoes(c, req.query)));

  app.get<{ Params: { id: string } }>('/movimentacoes/:id', {
    preHandler: requer('estoque.ver'),
    schema: { tags, summary: 'Ficha da movimentacao com linhas', params: paramId, response: { 404: esquemaErro } },
  }, (req) => naTransacao(req, async (_, __, c) => (await obterMovimentacao(c, req.params.id)) ?? Promise.reject(naoEncontrado('Movimentacao nao encontrada'))));

  app.post<{ Params: { id: string }; Body: { motivo?: string } }>('/movimentacoes/:id/estornar', {
    preHandler: requer('estoque.editar'),
    schema: {
      tags, summary: 'Estorna movimentacao (EstornarMovimentacao): grava a inversa e marca a original como estornada', params: paramId,
      body: { type: 'object', additionalProperties: false, properties: { motivo: { type: 'string', maxLength: 500 } } },
      response: { 400: esquemaErro, 403: esquemaErro, 404: esquemaErro, 409: esquemaErro },
    },
  }, async (req, reply) => reply.code(201).send(await naTransacao(req, async (casos, ctx, c) => {
    const { id } = exigirOk(await casos.estornarMovimentacao.execute(ctx, { id: req.params.id, motivo: req.body?.motivo }));
    return obterMovimentacao(c, id);
  })));
}
