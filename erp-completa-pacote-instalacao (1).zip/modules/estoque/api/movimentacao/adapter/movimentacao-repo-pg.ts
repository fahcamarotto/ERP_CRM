/** Adaptador Postgres da Movimentacao: cabecalho, linhas do livro razao, saldo pela view e fila (outbox). */
import type pg from 'pg';
import { UNIDADES_PADRAO } from '../../produto/model/produto.ts';
import { Movimentacao, type Linha, type MovimentacaoDados } from '../model/movimentacao.ts';
import type {
  AtualizarCustoMedio, ConsultarReferenciasMovimentacao, ConsultarSaldo, FilaJobs, GravarMovimentacao, ObterMovimentacao, ProdutoMov,
} from '../model/portas.ts';

export class MovimentacaoRepoPg implements ObterMovimentacao, GravarMovimentacao, ConsultarReferenciasMovimentacao, ConsultarSaldo, AtualizarCustoMedio {
  constructor(private readonly c: pg.PoolClient) {}

  async obterPorId(id: string): Promise<Movimentacao | null> {
    const r = await this.c.query(
      `SELECT m.id, m.tipo, m.motivo, to_char(m.data, 'YYYY-MM-DD') AS data, m.documento, m.parceiro_id, m.deposito_id, m.deposito_destino_id,
         m.estado, m.estorno_de_id, m.inventario_id,
         coalesce((SELECT json_agg(json_build_object('produto_id', i.produto_id, 'variacao_id', i.variacao_id, 'lote_id', i.lote_id,
           'deposito_id', i.deposito_id, 'local_id', i.local_id, 'quantidade', i.quantidade, 'custo_unitario', i.custo_unitario) ORDER BY i.created_at, i.id)
           FROM estoque_movimentacao_itens i WHERE i.movimentacao_id = m.id AND i.deleted_at IS NULL), '[]') AS linhas
       FROM estoque_movimentacoes m WHERE m.id = $1 AND m.deleted_at IS NULL`,
      [id],
    );
    return r.rows[0] ? Movimentacao.reidratar(r.rows[0] as MovimentacaoDados) : null;
  }

  async inserir(m: Movimentacao): Promise<void> {
    const d = m.paraDados();
    await this.c.query(
      `INSERT INTO estoque_movimentacoes (id, tipo, motivo, data, documento, parceiro_id, deposito_id, deposito_destino_id, estado, estorno_de_id, inventario_id, creator_id)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, nucleo_usuario_atual())`,
      [d.id, d.tipo, d.motivo, d.data, d.documento, d.parceiro_id, d.deposito_id, d.deposito_destino_id, d.estado, d.estorno_de_id, d.inventario_id],
    );
    await this.c.query(
      `INSERT INTO estoque_movimentacao_itens (movimentacao_id, produto_id, variacao_id, lote_id, deposito_id, local_id, quantidade, custo_unitario, creator_id)
       SELECT $1, x.produto_id, x.variacao_id, x.lote_id, x.deposito_id, x.local_id, x.quantidade, x.custo_unitario, nucleo_usuario_atual()
       FROM json_to_recordset($2::json) AS x(produto_id uuid, variacao_id uuid, lote_id uuid, deposito_id uuid, local_id uuid, quantidade numeric, custo_unitario numeric)`,
      [d.id, JSON.stringify(d.linhas)],
    );
  }

  async atualizarEstado(m: Movimentacao): Promise<void> {
    await this.c.query('UPDATE estoque_movimentacoes SET estado = $2 WHERE id = $1 AND deleted_at IS NULL', [m.id, m.estado]);
  }

  async produtos(ids: string[]): Promise<ProdutoMov[]> {
    if (!ids.length) return [];
    const r = await this.c.query(
      `SELECT p.id, p.sku, p.nome, p.estado, p.controla_lote, p.custo_medio::float8 AS custo_medio, p.estoque_minimo::float8 AS estoque_minimo,
         p.unidade, u.casas FROM estoque_produtos p
       LEFT JOIN estoque_unidades u ON u.sigla = p.unidade AND u.deleted_at IS NULL
       WHERE p.id = ANY ($1::uuid[]) AND p.deleted_at IS NULL`,
      [ids],
    );
    return r.rows.map((x) => ({ ...x, casas: x.casas ?? UNIDADES_PADRAO[x.unidade as string]?.casas ?? 3 }));
  }

  async depositoAtivo(id: string): Promise<boolean> {
    return ((await this.c.query("SELECT 1 FROM estoque_depositos WHERE id = $1 AND estado = 'ativo' AND deleted_at IS NULL", [id])).rowCount ?? 0) > 0;
  }

  async variacaoDoProduto(variacaoId: string, produtoId: string): Promise<boolean> {
    return ((await this.c.query('SELECT 1 FROM estoque_variacoes WHERE id = $1 AND produto_id = $2 AND deleted_at IS NULL', [variacaoId, produtoId])).rowCount ?? 0) > 0;
  }

  async loteDoProduto(loteId: string, produtoId: string): Promise<boolean> {
    return ((await this.c.query('SELECT 1 FROM estoque_lotes WHERE id = $1 AND produto_id = $2 AND deleted_at IS NULL', [loteId, produtoId])).rowCount ?? 0) > 0;
  }

  async localDoDeposito(localId: string, depositoId: string): Promise<boolean> {
    return ((await this.c.query('SELECT 1 FROM estoque_locais WHERE id = $1 AND deposito_id = $2 AND deleted_at IS NULL', [localId, depositoId])).rowCount ?? 0) > 0;
  }

  /** Leitura da tabela publicada cadastros_parceiros (CONTRATOS 7.1.1). */
  async parceiroAtivo(id: string): Promise<boolean> {
    return ((await this.c.query("SELECT 1 FROM cadastros_parceiros WHERE id = $1 AND deleted_at IS NULL AND estado = 'ativo'", [id])).rowCount ?? 0) > 0;
  }

  async saldo(k: Pick<Linha, 'produto_id' | 'variacao_id' | 'lote_id' | 'deposito_id' | 'local_id'>): Promise<number> {
    const r = await this.c.query(
      `SELECT coalesce(sum(quantidade), 0)::float8 AS q FROM estoque_saldos
       WHERE produto_id = $1 AND variacao_id IS NOT DISTINCT FROM $2::uuid AND lote_id IS NOT DISTINCT FROM $3::uuid
         AND deposito_id = $4 AND local_id IS NOT DISTINCT FROM $5::uuid`,
      [k.produto_id, k.variacao_id, k.lote_id, k.deposito_id, k.local_id],
    );
    return Number(r.rows[0].q);
  }

  async saldoProduto(produtoId: string): Promise<number> {
    return Number((await this.c.query('SELECT coalesce(sum(quantidade), 0)::float8 AS q FROM estoque_saldos WHERE produto_id = $1', [produtoId])).rows[0].q);
  }

  async atualizarCustoMedio(produtoId: string, custoMedio: number): Promise<void> {
    await this.c.query('UPDATE estoque_produtos SET custo_medio = $2 WHERE id = $1', [produtoId, custoMedio]);
  }
}

/** Intencao do job gravada na outbox do nucleo, na mesma transacao do caso de uso (docs/CONTRATOS.md 6). */
export class FilaOutboxPg implements FilaJobs {
  constructor(private readonly c: pg.PoolClient) {}
  async enfileirar(tipo: string, payload: Record<string, unknown>): Promise<string> {
    return (await this.c.query('INSERT INTO outbox (tipo, payload) VALUES ($1, $2) RETURNING id', [tipo, JSON.stringify(payload)])).rows[0].id as string;
  }
}
