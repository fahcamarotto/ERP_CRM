/**
 * Composicao do modulo Estoque: liga casos de uso aos adaptadores Postgres para um cliente de transacao.
 * Usada pelas rotas, pelas tools, pelo worker e pelo seed. Nao importa Fastify nem o pool do servidor.
 */
import type pg from 'pg';
import { DepositoRepoPg } from './deposito/adapter/deposito-repo-pg.ts';
import { AdicionarLocal, CriarDeposito, EditarDeposito, MudarEstadoDeposito } from './deposito/use-case/depositos.ts';
import { InventarioRepoPg } from './inventario/adapter/inventario-repo-pg.ts';
import { AbrirInventario, CancelarInventario, ConcluirInventario, RegistrarContagem } from './inventario/use-case/inventarios.ts';
import { FilaOutboxPg, MovimentacaoRepoPg } from './movimentacao/adapter/movimentacao-repo-pg.ts';
import { EstornarMovimentacao, RegistrarMovimentacao } from './movimentacao/use-case/movimentacoes.ts';
import { ProdutoRepoPg } from './produto/adapter/produto-repo-pg.ts';
import {
  CriarLote, CriarProduto, CriarUnidade, CriarVariacao, EditarProduto, ExcluirProdutoCaso, ExcluirVariacao, MudarEstadoProduto, ReapontarParceiro,
} from './produto/use-case/produtos.ts';
import { ReposicaoRepoPg } from './reposicao/reposicao-repo-pg.ts';
import { SolicitarVerificacaoReposicao, VerificarReposicao } from './reposicao/verificar-reposicao.ts';

export function casosDeUso(c: pg.PoolClient) {
  const produtos = new ProdutoRepoPg(c);
  const depositos = new DepositoRepoPg(c);
  const movs = new MovimentacaoRepoPg(c);
  const inventarios = new InventarioRepoPg(c);
  const fila = new FilaOutboxPg(c);
  const depsMov = { repo: movs, refs: movs, saldos: movs, custos: movs, lotes: produtos, fila };
  const registrarMovimentacao = new RegistrarMovimentacao(depsMov);
  const depsInv = { repo: inventarios, saldos: inventarios };
  return {
    criarProduto: new CriarProduto({ repo: produtos, refs: produtos }),
    editarProduto: new EditarProduto({ repo: produtos, refs: produtos }),
    mudarEstadoProduto: new MudarEstadoProduto({ repo: produtos }),
    excluirProduto: new ExcluirProdutoCaso({ repo: produtos }),
    criarVariacao: new CriarVariacao({ repo: produtos, variacoes: produtos }),
    excluirVariacao: new ExcluirVariacao({ variacoes: produtos }),
    criarLote: new CriarLote({ repo: produtos, lotes: produtos }),
    criarUnidade: new CriarUnidade({ unidades: produtos }),
    reapontarParceiro: new ReapontarParceiro({ repo: produtos }),
    criarDeposito: new CriarDeposito({ repo: depositos }),
    editarDeposito: new EditarDeposito({ repo: depositos }),
    mudarEstadoDeposito: new MudarEstadoDeposito({ repo: depositos, saldos: depositos }),
    adicionarLocal: new AdicionarLocal({ repo: depositos, locais: depositos }),
    registrarMovimentacao,
    estornarMovimentacao: new EstornarMovimentacao({ ...depsMov, registrar: registrarMovimentacao }),
    abrirInventario: new AbrirInventario(depsInv),
    registrarContagem: new RegistrarContagem(depsInv),
    concluirInventario: new ConcluirInventario({ ...depsInv, registrar: registrarMovimentacao }),
    cancelarInventario: new CancelarInventario(depsInv),
    solicitarVerificacaoReposicao: new SolicitarVerificacaoReposicao({ fila }),
    verificarReposicao: new VerificarReposicao({ repo: new ReposicaoRepoPg(c) }),
  };
}

export type CasosDeUso = ReturnType<typeof casosDeUso>;
