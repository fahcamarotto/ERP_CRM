/** JSON Schemas dos DTOs de entrada (validacao Fastify, OpenAPI em /docs e schema das tools MCP). */
export const uuid = { type: 'string', format: 'uuid' } as const;
const texto = (max: number) => ({ type: ['string', 'null'], maxLength: max });
const data = { type: ['string', 'null'], format: 'date' } as const;

export const tiposMovimentacao = ['entrada', 'saida', 'transferencia', 'ajuste'] as const;
export const estadosCadastro = ['ativo', 'arquivado'] as const;

export const propsProduto = {
  sku: { type: 'string', minLength: 1, maxLength: 40, description: 'Codigo interno unico (vira maiusculas)' },
  nome: { type: 'string', minLength: 2, maxLength: 200 },
  descricao: texto(4000),
  unidade: { type: 'string', maxLength: 10, description: 'Sigla da unidade (UN, KG, L, M, CX, PC, G, ML ou cadastrada)' },
  codigo_barras: { ...texto(14), description: 'GTIN/EAN de 8, 12, 13 ou 14 digitos com digito verificador' },
  custo: { type: 'number', minimum: 0 },
  preco: { type: 'number', minimum: 0 },
  estoque_minimo: { type: 'number', minimum: 0, description: 'Abaixo dele o job de reposicao abre alerta e publica estoque.abaixo_minimo' },
  controla_lote: { type: 'boolean' },
  atributos: { type: 'object', description: 'Grade de atributos: { "cor": ["Azul", "Preto"], "tamanho": ["P", "M"] }', additionalProperties: { type: 'array', items: { type: 'string', maxLength: 60 }, maxItems: 50 } },
  fornecedor_id: { type: ['string', 'null'], format: 'uuid', description: 'Fornecedor (cadastros_parceiros)' },
  extras: { type: 'object', description: 'Campos personalizados (modulo estoque, entidade produto)' },
} as const;

export const propsVariacao = {
  nome: texto(120),
  sku: { type: 'string', minLength: 1, maxLength: 40 },
  codigo_barras: texto(14),
  atributos: { type: 'object', additionalProperties: { type: 'string', maxLength: 60 }, description: 'Valores da grade do produto: { "cor": "Azul" }' },
  preco: { type: ['number', 'null'], minimum: 0 },
} as const;

export const propsLote = {
  produto_id: uuid,
  codigo: { type: 'string', minLength: 1, maxLength: 60 },
  fabricacao: data,
  validade: data,
} as const;

export const propsUnidade = {
  sigla: { type: 'string', minLength: 1, maxLength: 10 },
  nome: { type: 'string', minLength: 1, maxLength: 60 },
  casas: { type: 'integer', minimum: 0, maximum: 3 },
} as const;

export const propsDeposito = {
  codigo: { type: 'string', minLength: 1, maxLength: 20 },
  nome: { type: 'string', minLength: 2, maxLength: 120 },
  endereco: texto(300),
} as const;

export const propsLocal = {
  codigo: { type: 'string', minLength: 1, maxLength: 30 },
  nome: texto(120),
} as const;

export const propsItemMovimentacao = {
  produto_id: uuid,
  variacao_id: { type: ['string', 'null'], format: 'uuid' },
  lote_id: { type: ['string', 'null'], format: 'uuid' },
  lote_codigo: { ...texto(60), description: 'Na entrada: codigo do lote (criado se nao existir)' },
  validade: data,
  fabricacao: data,
  local_id: { type: ['string', 'null'], format: 'uuid' },
  local_destino_id: { type: ['string', 'null'], format: 'uuid' },
  quantidade: { type: 'number', description: 'Positiva; no ajuste use negativa para baixar' },
  custo_unitario: { type: ['number', 'null'], minimum: 0, description: 'Entrada: custo da compra (recalcula o custo medio)' },
} as const;

export const propsMovimentacao = {
  tipo: { type: 'string', enum: [...tiposMovimentacao] },
  motivo: { type: 'string', minLength: 3, maxLength: 500 },
  data,
  documento: texto(120),
  parceiro_id: { type: ['string', 'null'], format: 'uuid', description: 'Fornecedor ou cliente (cadastros_parceiros)' },
  deposito_id: uuid,
  deposito_destino_id: { type: ['string', 'null'], format: 'uuid' },
  itens: { type: 'array', minItems: 1, maxItems: 200, items: { type: 'object', additionalProperties: false, required: ['produto_id', 'quantidade'], properties: propsItemMovimentacao } },
} as const;

export const paginacao = {
  busca: { type: 'string', maxLength: 120 },
  limite: { type: 'integer', minimum: 1, maximum: 200, default: 50 },
  cursor: { type: 'string', maxLength: 200 },
} as const;
