/** Adaptador Postgres do Deposito e dos locais. */
import type pg from 'pg';
import { Deposito, type DepositoDados, type Local } from '../model/deposito.ts';
import type { GravarDeposito, GravarLocais, ObterDeposito, SaldoDoDeposito } from '../model/portas.ts';

export class DepositoRepoPg implements ObterDeposito, GravarDeposito, GravarLocais, SaldoDoDeposito {
  constructor(private readonly c: pg.PoolClient) {}

  async obterPorId(id: string): Promise<Deposito | null> {
    const r = await this.c.query('SELECT id, codigo, nome, endereco, estado FROM estoque_depositos WHERE id = $1 AND deleted_at IS NULL', [id]);
    return r.rows[0] ? Deposito.reidratar(r.rows[0] as DepositoDados) : null;
  }

  async buscarPorCodigo(codigo: string) {
    return (await this.c.query('SELECT id FROM estoque_depositos WHERE codigo = $1 AND deleted_at IS NULL', [codigo])).rows[0] ?? null;
  }

  async inserir(dep: Deposito): Promise<void> {
    const d = dep.paraDados();
    await this.c.query('INSERT INTO estoque_depositos (id, codigo, nome, endereco, estado, creator_id) VALUES ($1, $2, $3, $4, $5, nucleo_usuario_atual())',
      [d.id, d.codigo, d.nome, d.endereco, d.estado]);
  }

  async atualizar(dep: Deposito): Promise<void> {
    const d = dep.paraDados();
    await this.c.query('UPDATE estoque_depositos SET nome = $2, endereco = $3, estado = $4 WHERE id = $1 AND deleted_at IS NULL', [d.id, d.nome, d.endereco, d.estado]);
  }

  async inserirLocal(l: Local): Promise<void> {
    const d = l.dados;
    await this.c.query('INSERT INTO estoque_locais (id, deposito_id, codigo, nome, creator_id) VALUES ($1, $2, $3, $4, nucleo_usuario_atual())', [d.id, d.deposito_id, d.codigo, d.nome]);
  }

  async localExiste(depositoId: string, codigo: string): Promise<boolean> {
    return ((await this.c.query('SELECT 1 FROM estoque_locais WHERE deposito_id = $1 AND codigo = $2 AND deleted_at IS NULL', [depositoId, codigo])).rowCount ?? 0) > 0;
  }

  async temSaldo(depositoId: string): Promise<boolean> {
    return ((await this.c.query('SELECT 1 FROM estoque_saldos WHERE deposito_id = $1 AND quantidade <> 0 LIMIT 1', [depositoId])).rowCount ?? 0) > 0;
  }
}
