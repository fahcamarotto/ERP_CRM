/** Casos de uso do Deposito (M9.2): criar, editar, arquivar ou reativar e adicionar local. */
import { erroDe, fail, ok, okVazio, type Result } from '../../compartilhado/result.ts';
import type { ContextoCaso } from '../../compartilhado/efeitos.ts';
import { Deposito, Local, type DadosDeposito, type DadosLocal, type EstadoDeposito } from '../model/deposito.ts';
import type { GravarDeposito, GravarLocais, ObterDeposito, SaldoDoDeposito } from '../model/portas.ts';

const TABELA = 'estoque_depositos';

export class CriarDeposito {
  constructor(private readonly deps: { repo: ObterDeposito & GravarDeposito }) {}
  async execute(ctx: ContextoCaso, e: DadosDeposito): Promise<Result<{ id: string }>> {
    const r = Deposito.tryCreate(e);
    if (!r.ok) return r;
    const d = r.valor.paraDados();
    if (await this.deps.repo.buscarPorCodigo(d.codigo)) return fail(erroDe('conflito', `Codigo ${d.codigo} ja usado por outro deposito`, 'codigo'));
    await this.deps.repo.inserir(r.valor);
    await ctx.efeitos.auditar('deposito.criar', TABELA, d.id, undefined, d);
    return ok({ id: d.id });
  }
}

export class EditarDeposito {
  constructor(private readonly deps: { repo: ObterDeposito & GravarDeposito }) {}
  async execute(ctx: ContextoCaso, e: { id: string } & Partial<DadosDeposito>): Promise<Result<void>> {
    const { id, ...mud } = e;
    const atual = await this.deps.repo.obterPorId(id);
    if (!atual) return fail(erroDe('nao_encontrado', 'Deposito nao encontrado'));
    const r = atual.editar(mud);
    if (!r.ok) return r;
    await this.deps.repo.atualizar(r.valor);
    const antes = atual.paraDados() as unknown as Record<string, unknown>;
    const depois = r.valor.paraDados() as unknown as Record<string, unknown>;
    await ctx.efeitos.historico(TABELA, id, antes, depois);
    await ctx.efeitos.auditar('deposito.editar', TABELA, id, antes, depois);
    return okVazio();
  }
}

export class MudarEstadoDeposito {
  constructor(private readonly deps: { repo: ObterDeposito & GravarDeposito; saldos: SaldoDoDeposito }) {}
  async execute(ctx: ContextoCaso, e: { id: string; estado: EstadoDeposito }): Promise<Result<void>> {
    const atual = await this.deps.repo.obterPorId(e.id);
    if (!atual) return fail(erroDe('nao_encontrado', 'Deposito nao encontrado'));
    const r = atual.mudarEstado(e.estado);
    if (!r.ok) return r;
    if (e.estado === 'arquivado' && (await this.deps.saldos.temSaldo(e.id))) {
      return fail(erroDe('conflito', 'Deposito com saldo nao pode ser arquivado; transfira o estoque antes'));
    }
    await this.deps.repo.atualizar(r.valor);
    await ctx.efeitos.historico(TABELA, e.id, { estado: atual.estado }, { estado: e.estado });
    await ctx.efeitos.auditar('deposito.mudar_estado', TABELA, e.id, { estado: atual.estado }, { estado: e.estado });
    return okVazio();
  }
}

export class AdicionarLocal {
  constructor(private readonly deps: { repo: ObterDeposito; locais: GravarLocais }) {}
  async execute(ctx: ContextoCaso, e: DadosLocal): Promise<Result<{ id: string }>> {
    const dep = await this.deps.repo.obterPorId(e.deposito_id);
    if (!dep) return fail(erroDe('nao_encontrado', 'Deposito nao encontrado'));
    if (dep.estado !== 'ativo') return fail(erroDe('transicao_invalida', 'Deposito arquivado nao recebe local'));
    const r = Local.tryCreate(e);
    if (!r.ok) return r;
    if (await this.deps.locais.localExiste(e.deposito_id, r.valor.dados.codigo)) return fail(erroDe('conflito', `Local ${r.valor.dados.codigo} ja existe neste deposito`, 'codigo'));
    await this.deps.locais.inserirLocal(r.valor);
    await ctx.efeitos.auditar('local.criar', 'estoque_locais', r.valor.dados.id, undefined, r.valor.dados);
    await ctx.efeitos.nota(TABELA, e.deposito_id, `Local ${r.valor.dados.codigo} adicionado`);
    return ok({ id: r.valor.dados.id });
  }
}
