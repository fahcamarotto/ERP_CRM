/** Rotas REST do Deposito e dos locais. */
import { esquemaErro, requer, type FastifyInstance } from '@erp/api/sdk';
import { naTransacao, naoEncontrado } from '../borda.ts';
import { exigirOk } from '../compartilhado/result.ts';
import { estadosCadastro, propsDeposito, propsLocal, uuid } from '../esquemas.ts';
import type { DadosDeposito, DadosLocal, EstadoDeposito } from './model/deposito.ts';
import { listarDepositos, obterDeposito } from './query/depositos.ts';

const tags = ['estoque'];
const paramId = { type: 'object', required: ['id'], properties: { id: uuid } } as const;
const erros = { 400: esquemaErro, 403: esquemaErro, 404: esquemaErro, 409: esquemaErro };

export function rotasDeposito(app: FastifyInstance): void {
  app.get<{ Querystring: { estado?: 'ativo' | 'arquivado' | 'todos' } }>('/depositos', {
    preHandler: requer('estoque.ver'),
    schema: { tags, summary: 'Depositos com locais, produtos e valor em estoque', querystring: { type: 'object', additionalProperties: false, properties: { estado: { type: 'string', enum: [...estadosCadastro, 'todos'] } } } },
  }, (req) => naTransacao(req, (_, __, c) => listarDepositos(c, req.query)));

  app.get<{ Params: { id: string } }>('/depositos/:id', {
    preHandler: requer('estoque.ver'),
    schema: { tags, summary: 'Ficha do deposito com locais e saldos', params: paramId, response: { 404: esquemaErro } },
  }, (req) => naTransacao(req, async (_, __, c) => (await obterDeposito(c, req.params.id)) ?? Promise.reject(naoEncontrado('Deposito nao encontrado'))));

  app.post<{ Body: DadosDeposito }>('/depositos', {
    preHandler: requer('estoque.criar'),
    schema: { tags, summary: 'Cria deposito (CriarDeposito)', body: { type: 'object', additionalProperties: false, required: ['codigo', 'nome'], properties: propsDeposito }, response: erros },
  }, async (req, reply) => reply.code(201).send(await naTransacao(req, async (casos, ctx, c) => {
    const { id } = exigirOk(await casos.criarDeposito.execute(ctx, req.body));
    return obterDeposito(c, id);
  })));

  app.patch<{ Params: { id: string }; Body: Partial<DadosDeposito> }>('/depositos/:id', {
    preHandler: requer('estoque.editar'),
    schema: {
      tags, summary: 'Edita deposito (EditarDeposito)', params: paramId,
      body: { type: 'object', additionalProperties: false, properties: { nome: propsDeposito.nome, endereco: propsDeposito.endereco } }, response: erros,
    },
  }, (req) => naTransacao(req, async (casos, ctx, c) => {
    exigirOk(await casos.editarDeposito.execute(ctx, { ...req.body, id: req.params.id }));
    return obterDeposito(c, req.params.id);
  }));

  app.post<{ Params: { id: string }; Body: { estado: EstadoDeposito } }>('/depositos/:id/estado', {
    preHandler: requer('estoque.editar'),
    schema: {
      tags, summary: 'Arquiva (sem saldo) ou reativa deposito', params: paramId,
      body: { type: 'object', additionalProperties: false, required: ['estado'], properties: { estado: { type: 'string', enum: [...estadosCadastro] } } }, response: erros,
    },
  }, (req) => naTransacao(req, async (casos, ctx, c) => {
    exigirOk(await casos.mudarEstadoDeposito.execute(ctx, { id: req.params.id, estado: req.body.estado }));
    return obterDeposito(c, req.params.id);
  }));

  app.post<{ Params: { id: string }; Body: Omit<DadosLocal, 'deposito_id'> }>('/depositos/:id/locais', {
    preHandler: requer('estoque.criar'),
    schema: { tags, summary: 'Adiciona local ao deposito (AdicionarLocal)', params: paramId, body: { type: 'object', additionalProperties: false, required: ['codigo'], properties: propsLocal }, response: erros },
  }, async (req, reply) => reply.code(201).send(await naTransacao(req, async (casos, ctx, c) => {
    exigirOk(await casos.adicionarLocal.execute(ctx, { ...req.body, deposito_id: req.params.id }));
    return obterDeposito(c, req.params.id);
  })));
}
