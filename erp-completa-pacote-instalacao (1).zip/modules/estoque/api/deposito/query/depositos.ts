/** Consultas do Deposito: lista com locais e valor em estoque, ficha com locais e saldos. */
import type pg from 'pg';

const RESUMO = `d.id, d.codigo, d.nome, d.endereco, d.estado, d.created_at, d.updated_at,
  (SELECT count(*)::int FROM estoque_locais l WHERE l.deposito_id = d.id AND l.deleted_at IS NULL) AS locais_qtd,
  (SELECT count(DISTINCT s.produto_id)::int FROM estoque_saldos s WHERE s.deposito_id = d.id AND s.quantidade <> 0) AS produtos_qtd,
  coalesce((SELECT round(sum(s.quantidade * p.custo_medio), 2) FROM estoque_saldos s JOIN estoque_produtos p ON p.id = s.produto_id
    WHERE s.deposito_id = d.id), 0)::float8 AS valor_estoque`;

export async function listarDepositos(c: pg.PoolClient, f: { estado?: 'ativo' | 'arquivado' | 'todos' } = {}) {
  const estado = f.estado === 'todos' ? null : (f.estado ?? 'ativo');
  return (await c.query(`SELECT ${RESUMO} FROM estoque_depositos d WHERE d.deleted_at IS NULL AND ($1::text IS NULL OR d.estado = $1) ORDER BY d.nome`, [estado])).rows;
}

export async function obterDeposito(c: pg.PoolClient, id: string) {
  const r = await c.query(
    `SELECT ${RESUMO},
       coalesce((SELECT json_agg(json_build_object('id', l.id, 'codigo', l.codigo, 'nome', l.nome) ORDER BY l.codigo)
         FROM estoque_locais l WHERE l.deposito_id = d.id AND l.deleted_at IS NULL), '[]') AS locais,
       coalesce((SELECT json_agg(json_build_object('produto_id', p.id, 'sku', p.sku, 'nome', p.nome, 'unidade', p.unidade,
         'local_codigo', lc.codigo, 'lote_codigo', lt.codigo, 'variacao_nome', v.nome, 'quantidade', s.quantidade::float8) ORDER BY p.nome)
         FROM estoque_saldos s JOIN estoque_produtos p ON p.id = s.produto_id
         LEFT JOIN estoque_locais lc ON lc.id = s.local_id LEFT JOIN estoque_lotes lt ON lt.id = s.lote_id
         LEFT JOIN estoque_variacoes v ON v.id = s.variacao_id
         WHERE s.deposito_id = d.id AND s.quantidade <> 0), '[]') AS saldos
     FROM estoque_depositos d WHERE d.id = $1 AND d.deleted_at IS NULL`,
    [id],
  );
  return r.rows[0] ?? null;
}
