/** Agregado Deposito (M9.2) com a filha Local (corredor, prateleira, posicao). Imutavel. */
import { randomUUID } from 'node:crypto';
import { erroDe, fail, ok, type ErroDominio, type Result } from '../../compartilhado/result.ts';
import { Codigo, texto } from '../../compartilhado/valores.ts';

export type EstadoDeposito = 'ativo' | 'arquivado';
export interface DadosDeposito { codigo: string; nome: string; endereco?: string | null }
export interface DepositoDados { id: string; codigo: string; nome: string; endereco: string | null; estado: EstadoDeposito }

function validar(d: DepositoDados): ErroDominio[] {
  const e: ErroDominio[] = [];
  if (d.nome.length < 2 || d.nome.length > 120) e.push(erroDe('nome_invalido', 'Nome deve ter de 2 a 120 caracteres', 'nome'));
  if (d.endereco && d.endereco.length > 300) e.push(erroDe('endereco_invalido', 'Endereco com no maximo 300 caracteres', 'endereco'));
  return e;
}

export class Deposito {
  private constructor(private readonly d: DepositoDados) {}

  static tryCreate(e: DadosDeposito, id: string = randomUUID()): Result<Deposito> {
    const c = Codigo.tryCreate(e.codigo, 'codigo', 20);
    const d: DepositoDados = { id, codigo: c.ok ? c.valor.valor : '', nome: (e.nome ?? '').trim(), endereco: texto(e.endereco), estado: 'ativo' };
    const erros = [...(c.ok ? [] : c.erros), ...validar(d)];
    return erros.length ? fail(...erros) : ok(new Deposito(d));
  }
  static create(e: DadosDeposito, id?: string): Deposito {
    const r = Deposito.tryCreate(e, id);
    if (!r.ok) throw new Error(r.erros.map((x) => x.mensagem).join('; '));
    return r.valor;
  }
  static reidratar(d: DepositoDados): Deposito { return new Deposito({ ...d }); }

  get id(): string { return this.d.id; }
  get estado(): EstadoDeposito { return this.d.estado; }

  editar(e: Partial<DadosDeposito>): Result<Deposito> {
    if (this.d.estado === 'arquivado') return fail(erroDe('transicao_invalida', 'Deposito arquivado nao pode ser editado'));
    const n: DepositoDados = {
      ...this.d,
      nome: e.nome !== undefined ? (e.nome ?? '').trim() : this.d.nome,
      endereco: e.endereco !== undefined ? texto(e.endereco) : this.d.endereco,
    };
    const erros = validar(n);
    return erros.length ? fail(...erros) : ok(new Deposito(n));
  }

  mudarEstado(novo: EstadoDeposito): Result<Deposito> {
    if (novo !== 'ativo' && novo !== 'arquivado') return fail(erroDe('estado_invalido', 'Estado invalido', 'estado'));
    if (novo === this.d.estado) return fail(erroDe('transicao_invalida', `Deposito ja esta ${novo}`, 'estado'));
    return ok(new Deposito({ ...this.d, estado: novo }));
  }

  paraDados(): DepositoDados { return { ...this.d }; }
}

export interface DadosLocal { deposito_id: string; codigo: string; nome?: string | null }
export interface LocalDados { id: string; deposito_id: string; codigo: string; nome: string | null }

export class Local {
  private constructor(readonly dados: LocalDados) {}
  static tryCreate(e: DadosLocal, id: string = randomUUID()): Result<Local> {
    const c = Codigo.tryCreate(e.codigo, 'codigo', 30);
    if (!c.ok) return c;
    const nome = texto(e.nome);
    if (nome && nome.length > 120) return fail(erroDe('nome_invalido', 'Nome com no maximo 120 caracteres', 'nome'));
    return ok(new Local({ id, deposito_id: e.deposito_id, codigo: c.valor.valor, nome }));
  }
  static create(e: DadosLocal, id?: string): Local {
    const r = Local.tryCreate(e, id);
    if (!r.ok) throw new Error(r.erros.map((x) => x.mensagem).join('; '));
    return r.valor;
  }
}
