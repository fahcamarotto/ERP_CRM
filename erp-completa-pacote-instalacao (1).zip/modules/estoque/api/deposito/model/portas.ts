/** Portas do agregado Deposito e da filha Local. */
import type { Deposito, Local } from './deposito.ts';

export interface ObterDeposito {
  obterPorId(id: string): Promise<Deposito | null>;
  buscarPorCodigo(codigo: string): Promise<{ id: string } | null>;
}

export interface GravarDeposito {
  inserir(d: Deposito): Promise<void>;
  atualizar(d: Deposito): Promise<void>;
}

export interface GravarLocais {
  inserirLocal(l: Local): Promise<void>;
  localExiste(depositoId: string, codigo: string): Promise<boolean>;
}

/** Saldo diferente de zero no deposito impede arquivar. */
export interface SaldoDoDeposito {
  temSaldo(depositoId: string): Promise<boolean>;
}
