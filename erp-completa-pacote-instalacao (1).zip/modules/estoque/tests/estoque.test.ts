/**
 * Testes do modulo Estoque: cada caso de uso com repositorio em memoria.
 * Rodar: node --import tsx --test modules/estoque/tests/*.test.ts
 */
import assert from 'node:assert/strict';
import { describe, it } from 'node:test';
import { custoMedioPonderado, Quantidade } from '../api/compartilhado/valores.ts';
import { Deposito } from '../api/deposito/model/deposito.ts';
import { AdicionarLocal, CriarDeposito, MudarEstadoDeposito } from '../api/deposito/use-case/depositos.ts';
import { Inventario } from '../api/inventario/model/inventario.ts';
import { AbrirInventario, CancelarInventario, ConcluirInventario, RegistrarContagem } from '../api/inventario/use-case/inventarios.ts';
import { Movimentacao } from '../api/movimentacao/model/movimentacao.ts';
import { EstornarMovimentacao, RegistrarMovimentacao, TIPO_JOB_REPOSICAO } from '../api/movimentacao/use-case/movimentacoes.ts';
import { CodigoBarras } from '../api/produto/model/codigo-barras.ts';
import { Lote, Produto, situacaoLote, Variacao } from '../api/produto/model/produto.ts';
import {
  CriarLote, CriarProduto, CriarUnidade, CriarVariacao, EditarProduto, ExcluirProdutoCaso, MudarEstadoProduto, ReapontarParceiro,
} from '../api/produto/use-case/produtos.ts';
import { SolicitarVerificacaoReposicao, VerificarReposicao } from '../api/reposicao/verificar-reposicao.ts';
import { contexto, EstoqueMemoria, repositorios } from './memoria.ts';

const EAN = CodigoBarras.ean13('789100000001').valor;

function montar() {
  const db = new EstoqueMemoria();
  const r = repositorios(db);
  const depsMov = { repo: r.movs, refs: db, saldos: db, custos: db, lotes: db, fila: db };
  const registrar = new RegistrarMovimentacao(depsMov);
  const depsInv = { repo: r.inventarios, saldos: db };
  return {
    db, r, registrar,
    criarProduto: new CriarProduto({ repo: r.produtos, refs: db }),
    editarProduto: new EditarProduto({ repo: r.produtos, refs: db }),
    estadoProduto: new MudarEstadoProduto({ repo: r.produtos }),
    excluirProduto: new ExcluirProdutoCaso({ repo: r.produtos }),
    criarVariacao: new CriarVariacao({ repo: r.produtos, variacoes: db }),
    criarLote: new CriarLote({ repo: r.produtos, lotes: db }),
    criarUnidade: new CriarUnidade({ unidades: db }),
    criarDeposito: new CriarDeposito({ repo: r.depositos }),
    estadoDeposito: new MudarEstadoDeposito({ repo: r.depositos, saldos: db }),
    adicionarLocal: new AdicionarLocal({ repo: r.depositos, locais: db }),
    estornar: new EstornarMovimentacao({ ...depsMov, registrar }),
    abrir: new AbrirInventario(depsInv),
    contar: new RegistrarContagem(depsInv),
    concluir: new ConcluirInventario({ ...depsInv, registrar }),
    cancelar: new CancelarInventario(depsInv),
    verificar: new VerificarReposicao({ repo: db }),
  };
}

async function cenario() {
  const m = montar();
  const ctx = contexto();
  const cd = await m.criarDeposito.execute(ctx, { codigo: 'cd01', nome: 'Centro de distribuicao' });
  const loja = await m.criarDeposito.execute(ctx, { codigo: 'LJ01', nome: 'Loja Centro' });
  const papel = await m.criarProduto.execute(ctx, { sku: 'pap-a4', nome: 'Papel A4', custo: 20, estoque_minimo: 50, codigo_barras: EAN });
  const cafe = await m.criarProduto.execute(ctx, { sku: 'CAF-500', nome: 'Cafe 500 g', controla_lote: true, custo: 14 });
  assert.ok(cd.ok && loja.ok && papel.ok && cafe.ok);
  return { ...m, ctx, cd: cd.valor.id, loja: loja.valor.id, papel: papel.valor.id, cafe: cafe.valor.id };
}

describe('objetos de valor', () => {
  it('CodigoBarras confere o digito GTIN e recusa digito errado', () => {
    assert.equal(CodigoBarras.create('7894900011517').valor, '7894900011517');
    assert.equal(CodigoBarras.create('96385074').valor.length, 8);
    assert.equal(CodigoBarras.tryCreate('7894900011518').ok, false);
    assert.equal(CodigoBarras.tryCreate('123').ok, false);
    assert.throws(() => CodigoBarras.create('abc'));
  });

  it('Quantidade arredonda em 3 casas e aplica as regras de sinal', () => {
    assert.equal(Quantidade.create('1,23456').valor, 1.235);
    assert.equal(Quantidade.tryCreate(0, 'q', { positiva: true }).ok, false);
    assert.equal(Quantidade.tryCreate(-1, 'q', { naoNegativa: true }).ok, false);
    assert.equal(Quantidade.tryCreate('x').ok, false);
    assert.throws(() => Quantidade.create(null));
  });

  it('custo medio ponderado (M9.7)', () => {
    assert.equal(custoMedioPonderado(0, 0, 10, 5), 5);
    assert.equal(custoMedioPonderado(10, 5, 10, 7), 6);
    assert.equal(custoMedioPonderado(20, 6, -10, 7), 5);
  });

  it('Lote valida datas e situacao pela validade', () => {
    assert.equal(Lote.tryCreate({ produto_id: 'p', codigo: 'L1', fabricacao: '2026-05-01', validade: '2026-04-01' }).ok, false);
    assert.equal(situacaoLote('2026-01-01', '2026-10-01'), 'vencido');
    assert.equal(situacaoLote('2026-10-20', '2026-10-01'), 'vencendo');
    assert.equal(situacaoLote('2027-10-20', '2026-10-01'), 'ok');
    assert.equal(situacaoLote(null, '2026-10-01'), 'sem_validade');
  });
});

describe('entidade Produto', () => {
  it('tryCreate acumula erros como valor', () => {
    const r = Produto.tryCreate({ sku: 'com espaco!', nome: 'X', unidade: 'kg!', custo: -1, codigo_barras: '7894900011518' });
    assert.equal(r.ok, false);
    if (!r.ok) assert.deepEqual(r.erros.map((e) => e.codigo).sort(), ['codigo_barras_invalido', 'codigo_invalido', 'valor_invalido']);
    const r2 = Produto.tryCreate({ sku: 'OK', nome: 'X', unidade: 'kg!' });
    assert.equal(r2.ok, false);
    if (!r2.ok) assert.deepEqual(r2.erros.map((e) => e.codigo).sort(), ['nome_invalido', 'unidade_invalida']);
  });

  it('editar devolve clone e nao muta o original; arquivado nao edita', () => {
    const p = Produto.create({ sku: 'a-1', nome: 'Produto A' });
    const r = p.editar({ nome: 'Produto A2', preco: 10 });
    assert.ok(r.ok);
    assert.equal(p.paraDados().nome, 'Produto A');
    assert.equal(r.valor.paraDados().preco, 10);
    assert.equal(p.paraDados().sku, 'A-1');
    const arq = p.mudarEstado('arquivado');
    assert.ok(arq.ok);
    const e = arq.valor.editar({ nome: 'Nada' });
    assert.equal(e.ok, false);
    if (!e.ok) assert.equal(e.erros[0]!.codigo, 'transicao_invalida');
    const mesmo = p.mudarEstado('ativo');
    assert.equal(mesmo.ok, false);
  });

  it('Variacao so aceita valores da grade de atributos do produto', () => {
    const p = Produto.create({ sku: 'CAM', nome: 'Camiseta', atributos: { Cor: ['Preta', 'Branca'], tamanho: ['P'] } }).paraDados();
    const v = Variacao.tryCreate({ produto_id: p.id, sku: 'cam-pr-p', atributos: { cor: 'Preta', tamanho: 'P' } }, p);
    assert.ok(v.ok);
    assert.equal(v.valor.dados.nome, 'Preta / P');
    assert.equal(Variacao.tryCreate({ produto_id: p.id, sku: 'cam-az', atributos: { cor: 'Azul' } }, p).ok, false);
  });
});

describe('casos de uso do Produto e do Deposito', () => {
  it('CriarProduto audita e recusa SKU, codigo de barras e unidade invalidos', async () => {
    const m = await cenario();
    assert.ok(m.ctx.efeitos.auditoria.some((a) => a.acao === 'produto.criar' && a.entidade === 'estoque_produtos'));
    const dup = await m.criarProduto.execute(m.ctx, { sku: 'PAP-A4', nome: 'Outro papel' });
    assert.equal(dup.ok, false);
    if (!dup.ok) assert.equal(dup.erros[0]!.codigo, 'conflito');
    const barras = await m.criarProduto.execute(m.ctx, { sku: 'NOVO', nome: 'Outro', codigo_barras: EAN });
    assert.equal(barras.ok, false);
    const unid = await m.criarProduto.execute(m.ctx, { sku: 'NOVO', nome: 'Outro', unidade: 'FD' });
    assert.equal(unid.ok, false);
    if (!unid.ok) assert.equal(unid.erros[0]!.codigo, 'unidade_invalida');
    assert.ok((await m.criarUnidade.execute(m.ctx, { sigla: 'fd', nome: 'Fardo' })).ok);
    assert.equal((await m.criarUnidade.execute(m.ctx, { sigla: 'FD', nome: 'Fardo' })).ok, false);
    assert.ok((await m.criarProduto.execute(m.ctx, { sku: 'NOVO', nome: 'Outro', unidade: 'FD' })).ok);
    const forn = await m.criarProduto.execute(m.ctx, { sku: 'NOVO2', nome: 'Outro 2', fornecedor_id: '00000000-0000-4000-8000-0000000000aa' });
    assert.equal(forn.ok, false);
  });

  it('EditarProduto grava historico; nao encontrado devolve nao_encontrado', async () => {
    const m = await cenario();
    assert.ok((await m.editarProduto.execute(m.ctx, { id: m.papel, preco: 30 })).ok);
    assert.equal(m.ctx.efeitos.historicos.length, 1);
    const r = await m.editarProduto.execute(m.ctx, { id: '00000000-0000-4000-8000-000000000999', preco: 1 });
    assert.equal(r.ok, false);
    if (!r.ok) assert.equal(r.erros[0]!.codigo, 'nao_encontrado');
  });

  it('Variacao, lote, local e regra de exclusao com movimentacao', async () => {
    const m = await cenario();
    const sem = await m.criarVariacao.execute(m.ctx, { produto_id: m.papel, sku: 'PAP-X', atributos: { cor: 'Azul' } });
    assert.equal(sem.ok, false);
    assert.ok((await m.criarLote.execute(m.ctx, { produto_id: m.cafe, codigo: 'l1', validade: '2027-01-01' })).ok);
    const dupLote = await m.criarLote.execute(m.ctx, { produto_id: m.cafe, codigo: 'L1' });
    assert.equal(dupLote.ok, false);
    if (!dupLote.ok) assert.equal(dupLote.erros[0]!.codigo, 'conflito');
    assert.ok((await m.adicionarLocal.execute(m.ctx, { deposito_id: m.cd, codigo: 'a-01' })).ok);
    assert.equal((await m.adicionarLocal.execute(m.ctx, { deposito_id: m.cd, codigo: 'A-01' })).ok, false);
    await m.registrar.execute(m.ctx, { tipo: 'entrada', motivo: 'Compra', deposito_id: m.cd, itens: [{ produto_id: m.papel, quantidade: 5 }] });
    const exc = await m.excluirProduto.execute(m.ctx, { id: m.papel });
    assert.equal(exc.ok, false);
    if (!exc.ok) assert.equal(exc.erros[0]!.codigo, 'conflito');
    const arq = await m.estadoDeposito.execute(m.ctx, { id: m.cd, estado: 'arquivado' });
    assert.equal(arq.ok, false);
    assert.ok((await m.estadoDeposito.execute(m.ctx, { id: m.loja, estado: 'arquivado' })).ok);
    assert.equal(Deposito.tryCreate({ codigo: '', nome: 'x' }).ok, false);
  });
});

describe('Movimentacao (M9.3, M9.6, M9.7)', () => {
  it('motivo e obrigatorio e o saldo e a soma das linhas', async () => {
    const m = await cenario();
    const sem = await m.registrar.execute(m.ctx, { tipo: 'entrada', motivo: ' ', deposito_id: m.cd, itens: [{ produto_id: m.papel, quantidade: 1 }] });
    assert.equal(sem.ok, false);
    if (!sem.ok) assert.ok(sem.erros.some((e) => e.codigo === 'motivo_obrigatorio'));
    assert.ok((await m.registrar.execute(m.ctx, { tipo: 'entrada', motivo: 'Compra NF 1', deposito_id: m.cd, itens: [{ produto_id: m.papel, quantidade: 100, custo_unitario: 20 }] })).ok);
    assert.ok((await m.registrar.execute(m.ctx, { tipo: 'saida', motivo: 'Consumo', deposito_id: m.cd, itens: [{ produto_id: m.papel, quantidade: 30 }] })).ok);
    assert.equal(await m.db.saldoProduto(m.papel), 70);
    assert.ok(m.ctx.efeitos.auditoria.some((a) => a.acao === 'movimentacao.saida'));
  });

  it('saida acima do saldo devolve saldo_insuficiente e nao grava', async () => {
    const m = await cenario();
    await m.registrar.execute(m.ctx, { tipo: 'entrada', motivo: 'Compra', deposito_id: m.cd, itens: [{ produto_id: m.papel, quantidade: 10 }] });
    const r = await m.registrar.execute(m.ctx, { tipo: 'saida', motivo: 'Venda', deposito_id: m.cd, itens: [{ produto_id: m.papel, quantidade: 6 }, { produto_id: m.papel, quantidade: 6 }] });
    assert.equal(r.ok, false);
    if (!r.ok) { assert.equal(r.erros[0]!.codigo, 'saldo_insuficiente'); assert.equal(r.erros[0]!.meta?.solicitado, 12); }
    assert.equal(m.db.movs.size, 1);
  });

  it('transferencia gera duas linhas e conserva o saldo total', async () => {
    const m = await cenario();
    await m.registrar.execute(m.ctx, { tipo: 'entrada', motivo: 'Compra', deposito_id: m.cd, itens: [{ produto_id: m.papel, quantidade: 10 }] });
    const t = await m.registrar.execute(m.ctx, { tipo: 'transferencia', motivo: 'Abastecer loja', deposito_id: m.cd, deposito_destino_id: m.loja, itens: [{ produto_id: m.papel, quantidade: 4 }] });
    assert.ok(t.ok);
    assert.equal(await m.db.saldo({ produto_id: m.papel, variacao_id: null, lote_id: null, deposito_id: m.loja, local_id: null }), 4);
    assert.equal(await m.db.saldoProduto(m.papel), 10);
    const igual = Movimentacao.tryCreate({ tipo: 'transferencia', motivo: 'xxx', deposito_id: m.cd, deposito_destino_id: m.cd, itens: [{ produto_id: m.papel, quantidade: 1 }] });
    assert.equal(igual.ok, false);
  });

  it('entrada recalcula o custo medio e o estorno desfaz', async () => {
    const m = await cenario();
    await m.registrar.execute(m.ctx, { tipo: 'entrada', motivo: 'Compra 1', deposito_id: m.cd, itens: [{ produto_id: m.papel, quantidade: 10, custo_unitario: 10 }] });
    const e2 = await m.registrar.execute(m.ctx, { tipo: 'entrada', motivo: 'Compra 2', deposito_id: m.cd, itens: [{ produto_id: m.papel, quantidade: 10, custo_unitario: 20 }] });
    assert.ok(e2.ok);
    assert.equal(m.db.produtosM.get(m.papel)!.custo_medio, 15);
    const est = await m.estornar.execute(m.ctx, { id: e2.valor.id });
    assert.ok(est.ok);
    assert.equal(m.db.produtosM.get(m.papel)!.custo_medio, 10);
    assert.equal(await m.db.saldoProduto(m.papel), 10);
    assert.equal(m.db.movs.get(e2.valor.id)!.estado, 'estornada');
  });

  it('estorno: maquina de estados e saldo ja consumido', async () => {
    const m = await cenario();
    const e1 = await m.registrar.execute(m.ctx, { tipo: 'entrada', motivo: 'Compra', deposito_id: m.cd, itens: [{ produto_id: m.papel, quantidade: 10 }] });
    assert.ok(e1.ok);
    await m.registrar.execute(m.ctx, { tipo: 'saida', motivo: 'Consumo', deposito_id: m.cd, itens: [{ produto_id: m.papel, quantidade: 8 }] });
    const semSaldo = await m.estornar.execute(m.ctx, { id: e1.valor.id });
    assert.equal(semSaldo.ok, false);
    if (!semSaldo.ok) assert.equal(semSaldo.erros[0]!.codigo, 'saldo_insuficiente');
    const s = [...m.db.movs.values()].find((x) => x.tipo === 'saida')!;
    const est = await m.estornar.execute(m.ctx, { id: s.id, motivo: 'Lancado errado' });
    assert.ok(est.ok);
    const de2 = await m.estornar.execute(m.ctx, { id: s.id });
    assert.equal(de2.ok, false);
    if (!de2.ok) assert.equal(de2.erros[0]!.codigo, 'transicao_invalida');
    const doEstorno = await m.estornar.execute(m.ctx, { id: est.valor.id });
    assert.equal(doEstorno.ok, false);
    if (!doEstorno.ok) assert.equal(doEstorno.erros[0]!.codigo, 'transicao_invalida');
    const nada = await m.estornar.execute(m.ctx, { id: '00000000-0000-4000-8000-000000000999' });
    assert.equal(nada.ok, false);
    if (!nada.ok) assert.equal(nada.erros[0]!.codigo, 'nao_encontrado');
  });

  it('lote: obrigatorio no produto que controla, criado pelo codigo na entrada, exigido na saida', async () => {
    const m = await cenario();
    const sem = await m.registrar.execute(m.ctx, { tipo: 'entrada', motivo: 'Compra', deposito_id: m.cd, itens: [{ produto_id: m.cafe, quantidade: 5 }] });
    assert.equal(sem.ok, false);
    if (!sem.ok) assert.equal(sem.erros[0]!.codigo, 'lote_obrigatorio');
    const com = await m.registrar.execute(m.ctx, { tipo: 'entrada', motivo: 'Compra', deposito_id: m.cd, itens: [{ produto_id: m.cafe, quantidade: 5, lote_codigo: 'caf-1', validade: '2027-01-31' }] });
    assert.ok(com.ok);
    const lote = [...m.db.lotes.values()][0]!;
    assert.equal(lote.codigo, 'CAF-1');
    assert.equal(lote.validade, '2027-01-31');
    assert.equal((await m.registrar.execute(m.ctx, { tipo: 'saida', motivo: 'Uso', deposito_id: m.cd, itens: [{ produto_id: m.cafe, quantidade: 1 }] })).ok, false);
    assert.ok((await m.registrar.execute(m.ctx, { tipo: 'saida', motivo: 'Uso', deposito_id: m.cd, itens: [{ produto_id: m.cafe, quantidade: 1, lote_id: lote.id }] })).ok);
    const errado = await m.registrar.execute(m.ctx, { tipo: 'entrada', motivo: 'Compra', deposito_id: m.cd, itens: [{ produto_id: m.papel, quantidade: 1, lote_codigo: 'X' }] });
    assert.equal(errado.ok, false);
    if (!errado.ok) assert.equal(errado.erros[0]!.codigo, 'lote_invalido');
  });

  it('casas decimais da unidade, produto arquivado e deposito invalido', async () => {
    const m = await cenario();
    const fr = await m.registrar.execute(m.ctx, { tipo: 'entrada', motivo: 'Compra', deposito_id: m.cd, itens: [{ produto_id: m.papel, quantidade: 1.5 }] });
    assert.equal(fr.ok, false);
    if (!fr.ok) assert.equal(fr.erros[0]!.codigo, 'quantidade_invalida');
    assert.ok((await m.estadoProduto.execute(m.ctx, { id: m.papel, estado: 'arquivado' })).ok);
    const arq = await m.registrar.execute(m.ctx, { tipo: 'entrada', motivo: 'Compra', deposito_id: m.cd, itens: [{ produto_id: m.papel, quantidade: 1 }] });
    assert.equal(arq.ok, false);
    const dep = await m.registrar.execute(m.ctx, { tipo: 'entrada', motivo: 'Compra', deposito_id: '00000000-0000-4000-8000-000000000999', itens: [{ produto_id: m.cafe, quantidade: 1, lote_codigo: 'L' }] });
    assert.equal(dep.ok, false);
    if (!dep.ok) assert.equal(dep.erros[0]!.codigo, 'deposito_invalido');
  });
});

describe('Reposicao (M9.4)', () => {
  it('movimentacao de produto com minimo enfileira o job; o job abre alerta, publica evento, atualiza e resolve', async () => {
    const m = await cenario();
    await m.registrar.execute(m.ctx, { tipo: 'entrada', motivo: 'Compra', deposito_id: m.cd, itens: [{ produto_id: m.papel, quantidade: 60 }] });
    await m.registrar.execute(m.ctx, { tipo: 'saida', motivo: 'Consumo', deposito_id: m.cd, itens: [{ produto_id: m.papel, quantidade: 20 }] });
    assert.equal(m.db.jobs.length, 2);
    assert.equal(m.db.jobs[1]!.tipo, TIPO_JOB_REPOSICAO);
    assert.deepEqual(m.db.jobs[1]!.payload, { produto_ids: [m.papel] });
    const ctxJob = contexto();
    const r = await m.verificar.execute(ctxJob, { produto_ids: [m.papel] });
    assert.ok(r.ok);
    assert.deepEqual(r.valor, { abertos: 1, resolvidos: 0, atualizados: 0 });
    const ev = ctxJob.efeitos.eventos[0]!;
    assert.equal(ev.evento, 'estoque.abaixo_minimo');
    assert.equal(ev.dados.saldo, 40);
    assert.equal(ev.dados.sugestao_compra, 60);
    const de2 = await m.verificar.execute(ctxJob, {});
    assert.ok(de2.ok);
    assert.equal(de2.valor.abertos, 0);
    assert.equal(ctxJob.efeitos.eventos.length, 1);
    await m.registrar.execute(m.ctx, { tipo: 'saida', motivo: 'Consumo', deposito_id: m.cd, itens: [{ produto_id: m.papel, quantidade: 5 }] });
    assert.equal((await m.verificar.execute(ctxJob, { produto_ids: [m.papel] })).ok && [...m.db.alertas.values()][0]!.saldo, 35);
    await m.registrar.execute(m.ctx, { tipo: 'entrada', motivo: 'Compra', deposito_id: m.cd, itens: [{ produto_id: m.papel, quantidade: 30 }] });
    const res = await m.verificar.execute(ctxJob, { produto_ids: [m.papel] });
    assert.ok(res.ok);
    assert.equal(res.valor.resolvidos, 1);
    assert.equal([...m.db.alertas.values()][0]!.estado, 'resolvido');
  });

  it('produto sem minimo nao enfileira; SolicitarVerificacao grava o job de todos', async () => {
    const m = await cenario();
    await m.registrar.execute(m.ctx, { tipo: 'entrada', motivo: 'Compra', deposito_id: m.cd, itens: [{ produto_id: m.cafe, quantidade: 5, lote_codigo: 'A' }] });
    assert.equal(m.db.jobs.length, 0);
    const s = await new SolicitarVerificacaoReposicao({ fila: m.db }).execute(m.ctx);
    assert.ok(s.ok);
    assert.deepEqual(m.db.jobs[0]!.payload, { todos: true });
  });
});

describe('Inventario (M9.5)', () => {
  it('abre com a foto do saldo, recusa segundo aberto, conta e conclui com ajuste da diferenca', async () => {
    const m = await cenario();
    await m.registrar.execute(m.ctx, { tipo: 'entrada', motivo: 'Compra', deposito_id: m.cd, itens: [{ produto_id: m.papel, quantidade: 10 }, { produto_id: m.cafe, quantidade: 4, lote_codigo: 'L9' }] });
    const a = await m.abrir.execute(m.ctx, { deposito_id: m.cd, descricao: 'Contagem de outubro' });
    assert.ok(a.ok);
    const dup = await m.abrir.execute(m.ctx, { deposito_id: m.cd, descricao: 'Outra contagem' });
    assert.equal(dup.ok, false);
    if (!dup.ok) assert.equal(dup.erros[0]!.codigo, 'conflito');
    const vazio = await m.abrir.execute(m.ctx, { deposito_id: m.loja, descricao: 'Loja sem estoque' });
    assert.equal(vazio.ok, false);
    const inv = m.db.inventarios.get(a.valor.id)!;
    assert.equal(inv.itens.length, 2);
    const papel = inv.itens.find((i) => i.produto_id === m.papel)!;
    const cafe = inv.itens.find((i) => i.produto_id === m.cafe)!;
    assert.equal(papel.quantidade_sistema, 10);
    const ruim = await m.contar.execute(m.ctx, { id: a.valor.id, contagens: [{ item_id: 'nao-existe', quantidade_contada: 1 }] });
    assert.equal(ruim.ok, false);
    assert.ok((await m.contar.execute(m.ctx, { id: a.valor.id, contagens: [{ item_id: papel.id, quantidade_contada: 7 }, { item_id: cafe.id, quantidade_contada: 4 }] })).ok);
    const c = await m.concluir.execute(m.ctx, { id: a.valor.id });
    assert.ok(c.ok);
    assert.equal(c.valor.ajustes, 1);
    assert.equal(await m.db.saldoProduto(m.papel), 7);
    const ajuste = m.db.movs.get(c.valor.movimentacao_id!)!;
    assert.equal(ajuste.tipo, 'ajuste');
    assert.equal(ajuste.inventario_id, a.valor.id);
    assert.equal(ajuste.linhas[0]!.quantidade, -3);
    const de2 = await m.concluir.execute(m.ctx, { id: a.valor.id });
    assert.equal(de2.ok, false);
    if (!de2.ok) assert.equal(de2.erros[0]!.codigo, 'transicao_invalida');
    assert.equal((await m.cancelar.execute(m.ctx, { id: a.valor.id })).ok, false);
  });

  it('concluir sem contagem falha; cancelar libera o deposito', async () => {
    const m = await cenario();
    await m.registrar.execute(m.ctx, { tipo: 'entrada', motivo: 'Compra', deposito_id: m.cd, itens: [{ produto_id: m.papel, quantidade: 3 }] });
    const a = await m.abrir.execute(m.ctx, { deposito_id: m.cd, descricao: 'Contagem rapida' });
    assert.ok(a.ok);
    const c = await m.concluir.execute(m.ctx, { id: a.valor.id });
    assert.equal(c.ok, false);
    if (!c.ok) assert.equal(c.erros[0]!.codigo, 'contagem_pendente');
    assert.ok((await m.cancelar.execute(m.ctx, { id: a.valor.id })).ok);
    assert.ok((await m.abrir.execute(m.ctx, { deposito_id: m.cd, descricao: 'Nova contagem' })).ok);
    assert.equal(Inventario.tryCreate({ deposito_id: m.cd, descricao: 'ab' }, []).ok, false);
  });
});

describe('integracao com Cadastros', () => {
  it('parceiro.mesclado reaponta fornecedor do produto e parceiro da movimentacao', async () => {
    const m = await cenario();
    const velho = '00000000-0000-4000-8000-0000000000a1';
    const novo = '00000000-0000-4000-8000-0000000000a2';
    m.db.parceirosAtivos.add(velho);
    assert.ok((await m.editarProduto.execute(m.ctx, { id: m.papel, fornecedor_id: velho })).ok);
    await m.registrar.execute(m.ctx, { tipo: 'entrada', motivo: 'Compra', deposito_id: m.cd, parceiro_id: velho, itens: [{ produto_id: m.papel, quantidade: 1 }] });
    const r = await new ReapontarParceiro({ repo: m.db }).execute(m.ctx, { mantido_id: novo, removidos_ids: [velho] });
    assert.ok(r.ok);
    assert.equal(r.valor.alterados, 2);
    assert.equal(m.db.produtosM.get(m.papel)!.fornecedor_id, novo);
  });
});
