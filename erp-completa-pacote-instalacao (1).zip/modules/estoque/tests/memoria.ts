/**
 * Repositorios em memoria das portas do Estoque e porta Efeitos que grava o que foi publicado.
 * Os casos de uso rodam aqui sem banco, sem Fastify e sem o SDK. O saldo e a soma das linhas gravadas.
 */
import type { ContextoCaso, Efeitos } from '../api/compartilhado/efeitos.ts';
import { Deposito, type DepositoDados, type Local } from '../api/deposito/model/deposito.ts';
import type { GravarDeposito, GravarLocais, ObterDeposito, SaldoDoDeposito } from '../api/deposito/model/portas.ts';
import { Inventario, type FotoSaldo, type InventarioDados, type ItemInventario } from '../api/inventario/model/inventario.ts';
import type { FotografarSaldos, GravarInventario, ObterInventario } from '../api/inventario/model/portas.ts';
import { chaveSaldo, Movimentacao, type Linha, type MovimentacaoDados } from '../api/movimentacao/model/movimentacao.ts';
import type {
  AtualizarCustoMedio, ConsultarReferenciasMovimentacao, ConsultarSaldo, FilaJobs, GravarMovimentacao, ObterMovimentacao, ProdutoMov,
} from '../api/movimentacao/model/portas.ts';
import { Produto, UNIDADES_PADRAO, type Lote, type LoteDados, type ProdutoDados, type Unidade, type VariacaoDados, type Variacao } from '../api/produto/model/produto.ts';
import type {
  ConsultarReferenciasProduto, ExcluirProduto, GravarLotes, GravarProduto, GravarUnidades, GravarVariacoes, ObterProduto, ReapontarParceiros,
} from '../api/produto/model/portas.ts';
import type { PortaReposicao, ProdutoReposicao } from '../api/reposicao/verificar-reposicao.ts';

export class EfeitosMemoria implements Efeitos {
  auditoria: { acao: string; entidade: string; id: string | null }[] = [];
  eventos: { evento: string; dados: Record<string, unknown> }[] = [];
  historicos: { entidade: string; id: string; antes: unknown; depois: unknown }[] = [];
  notas: { entidade: string; id: string; corpo: string }[] = [];
  async auditar(acao: string, entidade: string, id: string | null) { this.auditoria.push({ acao, entidade, id }); }
  async publicar(evento: string, dados: Record<string, unknown>) { this.eventos.push({ evento, dados }); }
  async historico(entidade: string, id: string, antes: unknown, depois: unknown) { this.historicos.push({ entidade, id, antes, depois }); }
  async nota(entidade: string, id: string, corpo: string) { this.notas.push({ entidade, id, corpo }); }
}

export function contexto(): ContextoCaso & { efeitos: EfeitosMemoria } {
  return { ator: { tipo: 'usuario', id: '00000000-0000-4000-8000-000000000001' }, efeitos: new EfeitosMemoria() };
}

/** Um "banco" em memoria compartilhado por todos os repositorios do teste. */
export class EstoqueMemoria implements
  ObterProduto, GravarProduto, ExcluirProduto, ConsultarReferenciasProduto, GravarVariacoes, GravarLotes, GravarUnidades, ReapontarParceiros,
  ObterDeposito, GravarDeposito, GravarLocais, SaldoDoDeposito,
  ObterMovimentacao, GravarMovimentacao, ConsultarReferenciasMovimentacao, ConsultarSaldo, AtualizarCustoMedio, FilaJobs,
  ObterInventario, GravarInventario, FotografarSaldos, PortaReposicao {
  produtosM = new Map<string, ProdutoDados & { deleted: boolean }>();
  variacoes = new Map<string, VariacaoDados & { deleted: boolean }>();
  lotes = new Map<string, LoteDados>();
  unidades = new Map<string, Unidade>();
  depositosM = new Map<string, DepositoDados>();
  locais = new Map<string, Local>();
  movs = new Map<string, MovimentacaoDados>();
  inventarios = new Map<string, InventarioDados>();
  alertas = new Map<string, { id: string; produto_id: string; saldo: number; estoque_minimo: number; estado: 'aberto' | 'resolvido' }>();
  parceirosAtivos = new Set<string>();
  jobs: { id: string; tipo: string; payload: Record<string, unknown> }[] = [];

  private get linhas(): Linha[] { return [...this.movs.values()].flatMap((m) => m.linhas); }

  // Produto
  async obterPorId(id: string): Promise<never> { throw new Error(`use um repositorio especifico (${id})`); }
  async buscarPorSku(sku: string) { const p = [...this.produtosM.values()].find((x) => !x.deleted && x.sku === sku); return p ? { id: p.id } : null; }
  async buscarPorCodigoBarras(c: string) { const p = [...this.produtosM.values()].find((x) => !x.deleted && x.codigo_barras === c); return p ? { id: p.id } : null; }
  async inserir(_x: unknown): Promise<void> { throw new Error('use um repositorio especifico'); }
  async atualizar(_x: unknown): Promise<void> { throw new Error('use um repositorio especifico'); }
  async excluir(id: string) { const p = this.produtosM.get(id); if (p) p.deleted = true; }
  async temMovimentacao(id: string) { return this.linhas.some((l) => l.produto_id === id); }
  async fornecedorAtivo(id: string) { return this.parceirosAtivos.has(id); }
  async unidadeExiste(s: string) { return !!UNIDADES_PADRAO[s] || this.unidades.has(s); }
  async inserirVariacao(v: Variacao) { this.variacoes.set(v.dados.id, { ...v.dados, deleted: false }); }
  async skuVariacaoEmUso(sku: string) { return [...this.variacoes.values()].some((v) => !v.deleted && v.sku === sku); }
  async obterVariacao(id: string) { const v = this.variacoes.get(id); return v && !v.deleted ? { id: v.id, produto_id: v.produto_id } : null; }
  async excluirVariacao(id: string) { const v = this.variacoes.get(id); if (v) v.deleted = true; }
  async variacaoTemMovimentacao(id: string) { return this.linhas.some((l) => l.variacao_id === id); }
  async inserirLote(l: Lote) { this.lotes.set(l.dados.id, { ...l.dados }); }
  async buscarLote(produtoId: string, codigo: string) { const l = [...this.lotes.values()].find((x) => x.produto_id === produtoId && x.codigo === codigo.trim().toUpperCase()); return l ? { id: l.id } : null; }
  async inserirUnidade(u: Unidade) { this.unidades.set(u.dados.sigla, u); }
  async unidadeCadastrada(s: string) { return this.unidades.has(s); }
  async reapontarParceiro(de: string[], para: string) {
    let n = 0;
    for (const p of this.produtosM.values()) if (p.fornecedor_id && de.includes(p.fornecedor_id)) { p.fornecedor_id = para; n++; }
    for (const m of this.movs.values()) if (m.parceiro_id && de.includes(m.parceiro_id)) { m.parceiro_id = para; n++; }
    return n;
  }

  // Deposito
  async buscarPorCodigo(codigo: string) { const d = [...this.depositosM.values()].find((x) => x.codigo === codigo); return d ? { id: d.id } : null; }
  async inserirLocal(l: Local) { this.locais.set(l.dados.id, l); }
  async localExiste(depositoId: string, codigo: string) { return [...this.locais.values()].some((l) => l.dados.deposito_id === depositoId && l.dados.codigo === codigo); }
  async temSaldo(depositoId: string) {
    const s = new Map<string, number>();
    for (const l of this.linhas) if (l.deposito_id === depositoId) s.set(chaveSaldo(l), (s.get(chaveSaldo(l)) ?? 0) + l.quantidade);
    return [...s.values()].some((q) => Math.abs(q) > 1e-9);
  }

  // Movimentacao
  async atualizarEstado(m: Movimentacao) { const d = this.movs.get(m.id); if (d) d.estado = m.estado; }
  async produtos(ids: string[]): Promise<ProdutoMov[]> {
    return ids.map((id) => this.produtosM.get(id)).filter((p): p is ProdutoDados & { deleted: boolean } => !!p && !p.deleted).map((p) => ({
      id: p.id, sku: p.sku, nome: p.nome, estado: p.estado, controla_lote: p.controla_lote, custo_medio: p.custo_medio, estoque_minimo: p.estoque_minimo,
      casas: this.unidades.get(p.unidade)?.dados.casas ?? UNIDADES_PADRAO[p.unidade]?.casas ?? 3,
    }));
  }
  async depositoAtivo(id: string) { return this.depositosM.get(id)?.estado === 'ativo'; }
  async variacaoDoProduto(v: string, p: string) { return this.variacoes.get(v)?.produto_id === p; }
  async loteDoProduto(l: string, p: string) { return this.lotes.get(l)?.produto_id === p; }
  async localDoDeposito(l: string, d: string) { return this.locais.get(l)?.dados.deposito_id === d; }
  async parceiroAtivo(id: string) { return this.parceirosAtivos.has(id); }
  async saldo(k: Pick<Linha, 'produto_id' | 'variacao_id' | 'lote_id' | 'deposito_id' | 'local_id'>) {
    const alvo = chaveSaldo(k);
    return Math.round(this.linhas.filter((l) => chaveSaldo(l) === alvo).reduce((a, l) => a + l.quantidade, 0) * 1000) / 1000;
  }
  async saldoProduto(produtoId: string) { return Math.round(this.linhas.filter((l) => l.produto_id === produtoId).reduce((a, l) => a + l.quantidade, 0) * 1000) / 1000; }
  async atualizarCustoMedio(produtoId: string, cm: number) { const p = this.produtosM.get(produtoId); if (p) p.custo_medio = cm; }
  async enfileirar(tipo: string, payload: Record<string, unknown>) { const id = `job-${this.jobs.length + 1}`; this.jobs.push({ id, tipo, payload }); return id; }

  // Inventario
  async abertoNoDeposito(depositoId: string) { const i = [...this.inventarios.values()].find((x) => x.deposito_id === depositoId && x.estado === 'aberto'); return i ? { id: i.id } : null; }
  async fotografar(depositoId: string, produtoIds?: string[]): Promise<FotoSaldo[]> {
    const s = new Map<string, FotoSaldo>();
    for (const l of this.linhas) {
      if (l.deposito_id !== depositoId || (produtoIds && !produtoIds.includes(l.produto_id))) continue;
      const k = chaveSaldo(l);
      const a = s.get(k) ?? { produto_id: l.produto_id, variacao_id: l.variacao_id, lote_id: l.lote_id, local_id: l.local_id, quantidade: 0 };
      a.quantidade += l.quantidade;
      s.set(k, a);
    }
    return [...s.values()].filter((x) => x.quantidade !== 0);
  }
  async saldoAtual(depositoId: string, i: Pick<ItemInventario, 'produto_id' | 'variacao_id' | 'lote_id' | 'local_id'>) { return this.saldo({ ...i, deposito_id: depositoId }); }

  // Reposicao
  async produtosParaVerificar(ids?: string[]): Promise<ProdutoReposicao[]> {
    const lista = [...this.produtosM.values()].filter((p) => !p.deleted && (ids ? ids.includes(p.id) : p.estado === 'ativo' && p.estoque_minimo > 0));
    return Promise.all(lista.map(async (p) => ({ id: p.id, sku: p.sku, nome: p.nome, estoque_minimo: p.estoque_minimo, saldo: await this.saldoProduto(p.id) })));
  }
  async alertaAberto(produtoId: string) { const a = [...this.alertas.values()].find((x) => x.produto_id === produtoId && x.estado === 'aberto'); return a ? { id: a.id, saldo: a.saldo } : null; }
  async abrirAlerta(a: { id: string; produto_id: string; saldo: number; estoque_minimo: number }) { this.alertas.set(a.id, { ...a, estado: 'aberto' }); }
  async atualizarAlerta(id: string, saldo: number) { const a = this.alertas.get(id); if (a) a.saldo = saldo; }
  async resolverAlerta(id: string, saldo: number) { const a = this.alertas.get(id); if (a) { a.estado = 'resolvido'; a.saldo = saldo; } }
}

/** Visoes tipadas do mesmo banco para cada agregado (obterPorId, inserir e atualizar mudam de dono). */
export function repositorios(db: EstoqueMemoria) {
  const produtos = Object.assign(Object.create(db) as EstoqueMemoria, {
    obterPorId: async (id: string) => { const p = db.produtosM.get(id); return p && !p.deleted ? Produto.reidratar(p) : null; },
    inserir: async (p: Produto) => { db.produtosM.set(p.id, { ...p.paraDados(), deleted: false }); },
    atualizar: async (p: Produto) => { const a = db.produtosM.get(p.id); if (a && !a.deleted) db.produtosM.set(p.id, { ...p.paraDados(), custo_medio: a.custo_medio, deleted: false }); },
  });
  const depositos = Object.assign(Object.create(db) as EstoqueMemoria, {
    obterPorId: async (id: string) => { const d = db.depositosM.get(id); return d ? Deposito.reidratar(d) : null; },
    inserir: async (d: Deposito) => { db.depositosM.set(d.id, d.paraDados()); },
    atualizar: async (d: Deposito) => { db.depositosM.set(d.id, d.paraDados()); },
  });
  const movs = Object.assign(Object.create(db) as EstoqueMemoria, {
    obterPorId: async (id: string) => { const m = db.movs.get(id); return m ? Movimentacao.reidratar(m) : null; },
    inserir: async (m: Movimentacao) => { db.movs.set(m.id, m.paraDados()); },
  });
  const inventarios = Object.assign(Object.create(db) as EstoqueMemoria, {
    obterPorId: async (id: string) => { const i = db.inventarios.get(id); return i ? Inventario.reidratar(i) : null; },
    inserir: async (i: Inventario) => { db.inventarios.set(i.id, i.paraDados()); },
    atualizar: async (i: Inventario) => { db.inventarios.set(i.id, i.paraDados()); },
  });
  return { produtos, depositos, movs, inventarios };
}
