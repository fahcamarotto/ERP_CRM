-- M9.5: o item do inventario guarda o local, para o ajuste cair na mesma chave de saldo contada.
ALTER TABLE estoque_inventario_itens ADD COLUMN IF NOT EXISTS local_id uuid;
DO $$ BEGIN
  ALTER TABLE estoque_inventario_itens ADD CONSTRAINT estoque_inventario_itens_local_fk
    FOREIGN KEY (local_id, tenant_id, workspace_id) REFERENCES estoque_locais (id, tenant_id, workspace_id);
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
