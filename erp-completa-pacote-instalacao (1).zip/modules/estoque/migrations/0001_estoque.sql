-- M9 Estoque: unidades, produtos com variacoes e atributos, lotes e validade, depositos e locais,
-- movimentacoes (livro razao de quantidades), alertas de reposicao e inventarios.
-- Toda tabela: tenant_id e workspace_id do contexto da sessao, PK composta, FK composta, RLS
-- por nucleo_aplicar_padrao, exclusao logica (sem DELETE). Idempotente.
-- Saldo NUNCA e editado: a view estoque_saldos soma as linhas de estoque_movimentacao_itens.

-- M9.1 Unidades de medida (catalogo do workspace; UN, KG, L, M, CX, PC, G, ML ja valem sem cadastro) ---
CREATE TABLE IF NOT EXISTS estoque_unidades (
  id            uuid NOT NULL DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL DEFAULT nucleo_tenant_atual(),
  workspace_id  uuid NOT NULL DEFAULT nucleo_workspace_atual(),
  creator_id    uuid,
  sigla         text NOT NULL CHECK (sigla ~ '^[A-Z0-9]{1,10}$'),
  nome          text NOT NULL CHECK (length(btrim(nome)) BETWEEN 1 AND 60),
  casas         smallint NOT NULL DEFAULT 0 CHECK (casas BETWEEN 0 AND 3),
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now(),
  deleted_at    timestamptz,
  PRIMARY KEY (id, tenant_id, workspace_id),
  FOREIGN KEY (workspace_id, tenant_id) REFERENCES workspaces (id, tenant_id),
  FOREIGN KEY (creator_id, tenant_id, workspace_id) REFERENCES usuarios (id, tenant_id, workspace_id)
);
CREATE UNIQUE INDEX IF NOT EXISTS estoque_unidades_sigla_uq ON estoque_unidades (tenant_id, workspace_id, sigla) WHERE deleted_at IS NULL;
SELECT nucleo_aplicar_padrao('estoque_unidades');

-- M9.1 Agregado Produto ----------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS estoque_produtos (
  id              uuid NOT NULL DEFAULT gen_random_uuid(),
  tenant_id       uuid NOT NULL DEFAULT nucleo_tenant_atual(),
  workspace_id    uuid NOT NULL DEFAULT nucleo_workspace_atual(),
  creator_id      uuid,
  sku             text NOT NULL CHECK (sku ~ '^[A-Z0-9._-]{1,40}$'),
  nome            text NOT NULL CHECK (length(btrim(nome)) BETWEEN 2 AND 200),
  descricao       text,
  unidade         text NOT NULL DEFAULT 'UN' CHECK (unidade ~ '^[A-Z0-9]{1,10}$'),
  codigo_barras   text CHECK (codigo_barras IS NULL OR codigo_barras ~ '^([0-9]{8}|[0-9]{12,14})$'),
  custo           numeric(14,4) NOT NULL DEFAULT 0 CHECK (custo >= 0),
  custo_medio     numeric(14,4) NOT NULL DEFAULT 0 CHECK (custo_medio >= 0),
  preco           numeric(14,2) NOT NULL DEFAULT 0 CHECK (preco >= 0),
  estoque_minimo  numeric(14,3) NOT NULL DEFAULT 0 CHECK (estoque_minimo >= 0),
  controla_lote   boolean NOT NULL DEFAULT false,
  atributos       jsonb NOT NULL DEFAULT '{}'::jsonb,
  fornecedor_id   uuid,
  estado          text NOT NULL DEFAULT 'ativo' CHECK (estado IN ('ativo', 'arquivado')),
  extras          jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at      timestamptz NOT NULL DEFAULT now(),
  updated_at      timestamptz NOT NULL DEFAULT now(),
  deleted_at      timestamptz,
  PRIMARY KEY (id, tenant_id, workspace_id),
  FOREIGN KEY (workspace_id, tenant_id) REFERENCES workspaces (id, tenant_id),
  FOREIGN KEY (creator_id, tenant_id, workspace_id) REFERENCES usuarios (id, tenant_id, workspace_id),
  FOREIGN KEY (fornecedor_id, tenant_id, workspace_id) REFERENCES cadastros_parceiros (id, tenant_id, workspace_id)
);
CREATE UNIQUE INDEX IF NOT EXISTS estoque_produtos_sku_uq ON estoque_produtos (tenant_id, workspace_id, sku) WHERE deleted_at IS NULL;
CREATE UNIQUE INDEX IF NOT EXISTS estoque_produtos_barras_uq
  ON estoque_produtos (tenant_id, workspace_id, codigo_barras) WHERE codigo_barras IS NOT NULL AND deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS estoque_produtos_lista_idx ON estoque_produtos (tenant_id, workspace_id, created_at, id) WHERE deleted_at IS NULL;
SELECT nucleo_aplicar_padrao('estoque_produtos');
DROP TRIGGER IF EXISTS estoque_produtos_extras ON estoque_produtos;
CREATE TRIGGER estoque_produtos_extras BEFORE INSERT OR UPDATE OF extras ON estoque_produtos
  FOR EACH ROW EXECUTE FUNCTION nucleo_trigger_extras('estoque', 'produto');

-- M9.1 Variacoes do produto (combinacao de atributos: cor Azul, tamanho M) --------------------
CREATE TABLE IF NOT EXISTS estoque_variacoes (
  id             uuid NOT NULL DEFAULT gen_random_uuid(),
  tenant_id      uuid NOT NULL DEFAULT nucleo_tenant_atual(),
  workspace_id   uuid NOT NULL DEFAULT nucleo_workspace_atual(),
  creator_id     uuid,
  produto_id     uuid NOT NULL,
  nome           text NOT NULL CHECK (length(btrim(nome)) BETWEEN 1 AND 120),
  sku            text NOT NULL CHECK (sku ~ '^[A-Z0-9._-]{1,40}$'),
  codigo_barras  text CHECK (codigo_barras IS NULL OR codigo_barras ~ '^([0-9]{8}|[0-9]{12,14})$'),
  atributos      jsonb NOT NULL DEFAULT '{}'::jsonb,
  preco          numeric(14,2) CHECK (preco IS NULL OR preco >= 0),
  created_at     timestamptz NOT NULL DEFAULT now(),
  updated_at     timestamptz NOT NULL DEFAULT now(),
  deleted_at     timestamptz,
  PRIMARY KEY (id, tenant_id, workspace_id),
  FOREIGN KEY (workspace_id, tenant_id) REFERENCES workspaces (id, tenant_id),
  FOREIGN KEY (creator_id, tenant_id, workspace_id) REFERENCES usuarios (id, tenant_id, workspace_id),
  FOREIGN KEY (produto_id, tenant_id, workspace_id) REFERENCES estoque_produtos (id, tenant_id, workspace_id)
);
CREATE UNIQUE INDEX IF NOT EXISTS estoque_variacoes_sku_uq ON estoque_variacoes (tenant_id, workspace_id, sku) WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS estoque_variacoes_produto_idx ON estoque_variacoes (tenant_id, workspace_id, produto_id) WHERE deleted_at IS NULL;
SELECT nucleo_aplicar_padrao('estoque_variacoes');

-- M9.6 Lotes e validade ----------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS estoque_lotes (
  id            uuid NOT NULL DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL DEFAULT nucleo_tenant_atual(),
  workspace_id  uuid NOT NULL DEFAULT nucleo_workspace_atual(),
  creator_id    uuid,
  produto_id    uuid NOT NULL,
  codigo        text NOT NULL CHECK (length(btrim(codigo)) BETWEEN 1 AND 60),
  fabricacao    date,
  validade      date,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now(),
  deleted_at    timestamptz,
  PRIMARY KEY (id, tenant_id, workspace_id),
  FOREIGN KEY (workspace_id, tenant_id) REFERENCES workspaces (id, tenant_id),
  FOREIGN KEY (creator_id, tenant_id, workspace_id) REFERENCES usuarios (id, tenant_id, workspace_id),
  FOREIGN KEY (produto_id, tenant_id, workspace_id) REFERENCES estoque_produtos (id, tenant_id, workspace_id),
  CHECK (fabricacao IS NULL OR validade IS NULL OR validade >= fabricacao)
);
CREATE UNIQUE INDEX IF NOT EXISTS estoque_lotes_codigo_uq ON estoque_lotes (tenant_id, workspace_id, produto_id, upper(codigo)) WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS estoque_lotes_validade_idx ON estoque_lotes (tenant_id, workspace_id, validade) WHERE deleted_at IS NULL;
SELECT nucleo_aplicar_padrao('estoque_lotes');

-- M9.2 Depositos e locais --------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS estoque_depositos (
  id            uuid NOT NULL DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL DEFAULT nucleo_tenant_atual(),
  workspace_id  uuid NOT NULL DEFAULT nucleo_workspace_atual(),
  creator_id    uuid,
  codigo        text NOT NULL CHECK (codigo ~ '^[A-Z0-9._-]{1,20}$'),
  nome          text NOT NULL CHECK (length(btrim(nome)) BETWEEN 2 AND 120),
  endereco      text,
  estado        text NOT NULL DEFAULT 'ativo' CHECK (estado IN ('ativo', 'arquivado')),
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now(),
  deleted_at    timestamptz,
  PRIMARY KEY (id, tenant_id, workspace_id),
  FOREIGN KEY (workspace_id, tenant_id) REFERENCES workspaces (id, tenant_id),
  FOREIGN KEY (creator_id, tenant_id, workspace_id) REFERENCES usuarios (id, tenant_id, workspace_id)
);
CREATE UNIQUE INDEX IF NOT EXISTS estoque_depositos_codigo_uq ON estoque_depositos (tenant_id, workspace_id, codigo) WHERE deleted_at IS NULL;
SELECT nucleo_aplicar_padrao('estoque_depositos');

CREATE TABLE IF NOT EXISTS estoque_locais (
  id            uuid NOT NULL DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL DEFAULT nucleo_tenant_atual(),
  workspace_id  uuid NOT NULL DEFAULT nucleo_workspace_atual(),
  creator_id    uuid,
  deposito_id   uuid NOT NULL,
  codigo        text NOT NULL CHECK (codigo ~ '^[A-Z0-9._-]{1,30}$'),
  nome          text,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now(),
  deleted_at    timestamptz,
  PRIMARY KEY (id, tenant_id, workspace_id),
  FOREIGN KEY (workspace_id, tenant_id) REFERENCES workspaces (id, tenant_id),
  FOREIGN KEY (creator_id, tenant_id, workspace_id) REFERENCES usuarios (id, tenant_id, workspace_id),
  FOREIGN KEY (deposito_id, tenant_id, workspace_id) REFERENCES estoque_depositos (id, tenant_id, workspace_id)
);
CREATE UNIQUE INDEX IF NOT EXISTS estoque_locais_codigo_uq ON estoque_locais (tenant_id, workspace_id, deposito_id, codigo) WHERE deleted_at IS NULL;
SELECT nucleo_aplicar_padrao('estoque_locais');

-- M9.5 Inventario (antes das movimentacoes: o ajuste aponta para o inventario) ---------------
CREATE TABLE IF NOT EXISTS estoque_inventarios (
  id               uuid NOT NULL DEFAULT gen_random_uuid(),
  tenant_id        uuid NOT NULL DEFAULT nucleo_tenant_atual(),
  workspace_id     uuid NOT NULL DEFAULT nucleo_workspace_atual(),
  creator_id       uuid,
  deposito_id      uuid NOT NULL,
  descricao        text NOT NULL CHECK (length(btrim(descricao)) BETWEEN 3 AND 200),
  estado           text NOT NULL DEFAULT 'aberto' CHECK (estado IN ('aberto', 'concluido', 'cancelado')),
  movimentacao_id  uuid,
  concluido_em     timestamptz,
  created_at       timestamptz NOT NULL DEFAULT now(),
  updated_at       timestamptz NOT NULL DEFAULT now(),
  deleted_at       timestamptz,
  PRIMARY KEY (id, tenant_id, workspace_id),
  FOREIGN KEY (workspace_id, tenant_id) REFERENCES workspaces (id, tenant_id),
  FOREIGN KEY (creator_id, tenant_id, workspace_id) REFERENCES usuarios (id, tenant_id, workspace_id),
  FOREIGN KEY (deposito_id, tenant_id, workspace_id) REFERENCES estoque_depositos (id, tenant_id, workspace_id)
);
CREATE UNIQUE INDEX IF NOT EXISTS estoque_inventarios_aberto_uq
  ON estoque_inventarios (tenant_id, workspace_id, deposito_id) WHERE estado = 'aberto' AND deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS estoque_inventarios_lista_idx ON estoque_inventarios (tenant_id, workspace_id, created_at, id) WHERE deleted_at IS NULL;
SELECT nucleo_aplicar_padrao('estoque_inventarios');

CREATE TABLE IF NOT EXISTS estoque_inventario_itens (
  id                  uuid NOT NULL DEFAULT gen_random_uuid(),
  tenant_id           uuid NOT NULL DEFAULT nucleo_tenant_atual(),
  workspace_id        uuid NOT NULL DEFAULT nucleo_workspace_atual(),
  creator_id          uuid,
  inventario_id       uuid NOT NULL,
  produto_id          uuid NOT NULL,
  variacao_id         uuid,
  lote_id             uuid,
  quantidade_sistema  numeric(14,3) NOT NULL DEFAULT 0,
  quantidade_contada  numeric(14,3) CHECK (quantidade_contada IS NULL OR quantidade_contada >= 0),
  created_at          timestamptz NOT NULL DEFAULT now(),
  updated_at          timestamptz NOT NULL DEFAULT now(),
  deleted_at          timestamptz,
  PRIMARY KEY (id, tenant_id, workspace_id),
  FOREIGN KEY (workspace_id, tenant_id) REFERENCES workspaces (id, tenant_id),
  FOREIGN KEY (creator_id, tenant_id, workspace_id) REFERENCES usuarios (id, tenant_id, workspace_id),
  FOREIGN KEY (inventario_id, tenant_id, workspace_id) REFERENCES estoque_inventarios (id, tenant_id, workspace_id),
  FOREIGN KEY (produto_id, tenant_id, workspace_id) REFERENCES estoque_produtos (id, tenant_id, workspace_id),
  FOREIGN KEY (variacao_id, tenant_id, workspace_id) REFERENCES estoque_variacoes (id, tenant_id, workspace_id),
  FOREIGN KEY (lote_id, tenant_id, workspace_id) REFERENCES estoque_lotes (id, tenant_id, workspace_id)
);
CREATE INDEX IF NOT EXISTS estoque_inventario_itens_inv_idx ON estoque_inventario_itens (tenant_id, workspace_id, inventario_id) WHERE deleted_at IS NULL;
SELECT nucleo_aplicar_padrao('estoque_inventario_itens');

-- M9.3 Agregado Movimentacao -----------------------------------------------------------------
CREATE TABLE IF NOT EXISTS estoque_movimentacoes (
  id                   uuid NOT NULL DEFAULT gen_random_uuid(),
  tenant_id            uuid NOT NULL DEFAULT nucleo_tenant_atual(),
  workspace_id         uuid NOT NULL DEFAULT nucleo_workspace_atual(),
  creator_id           uuid,
  tipo                 text NOT NULL CHECK (tipo IN ('entrada', 'saida', 'transferencia', 'ajuste')),
  motivo               text NOT NULL CHECK (length(btrim(motivo)) BETWEEN 3 AND 500),
  data                 date NOT NULL DEFAULT current_date,
  documento            text,
  parceiro_id          uuid,
  deposito_id          uuid NOT NULL,
  deposito_destino_id  uuid,
  estado               text NOT NULL DEFAULT 'confirmada' CHECK (estado IN ('confirmada', 'estornada')),
  estorno_de_id        uuid,
  inventario_id        uuid,
  created_at           timestamptz NOT NULL DEFAULT now(),
  updated_at           timestamptz NOT NULL DEFAULT now(),
  deleted_at           timestamptz,
  PRIMARY KEY (id, tenant_id, workspace_id),
  FOREIGN KEY (workspace_id, tenant_id) REFERENCES workspaces (id, tenant_id),
  FOREIGN KEY (creator_id, tenant_id, workspace_id) REFERENCES usuarios (id, tenant_id, workspace_id),
  FOREIGN KEY (parceiro_id, tenant_id, workspace_id) REFERENCES cadastros_parceiros (id, tenant_id, workspace_id),
  FOREIGN KEY (deposito_id, tenant_id, workspace_id) REFERENCES estoque_depositos (id, tenant_id, workspace_id),
  FOREIGN KEY (deposito_destino_id, tenant_id, workspace_id) REFERENCES estoque_depositos (id, tenant_id, workspace_id),
  FOREIGN KEY (estorno_de_id, tenant_id, workspace_id) REFERENCES estoque_movimentacoes (id, tenant_id, workspace_id),
  FOREIGN KEY (inventario_id, tenant_id, workspace_id) REFERENCES estoque_inventarios (id, tenant_id, workspace_id),
  CHECK ((tipo = 'transferencia') = (deposito_destino_id IS NOT NULL)),
  CHECK (deposito_destino_id IS NULL OR deposito_destino_id <> deposito_id)
);
CREATE INDEX IF NOT EXISTS estoque_movimentacoes_lista_idx ON estoque_movimentacoes (tenant_id, workspace_id, created_at, id) WHERE deleted_at IS NULL;
CREATE UNIQUE INDEX IF NOT EXISTS estoque_movimentacoes_estorno_uq
  ON estoque_movimentacoes (tenant_id, workspace_id, estorno_de_id) WHERE estorno_de_id IS NOT NULL AND deleted_at IS NULL;
SELECT nucleo_aplicar_padrao('estoque_movimentacoes');

-- Linhas do livro razao: quantidade com sinal (+ entra no deposito, - sai). Transferencia gera duas linhas.
CREATE TABLE IF NOT EXISTS estoque_movimentacao_itens (
  id               uuid NOT NULL DEFAULT gen_random_uuid(),
  tenant_id        uuid NOT NULL DEFAULT nucleo_tenant_atual(),
  workspace_id     uuid NOT NULL DEFAULT nucleo_workspace_atual(),
  creator_id       uuid,
  movimentacao_id  uuid NOT NULL,
  produto_id       uuid NOT NULL,
  variacao_id      uuid,
  lote_id          uuid,
  deposito_id      uuid NOT NULL,
  local_id         uuid,
  quantidade       numeric(14,3) NOT NULL CHECK (quantidade <> 0),
  custo_unitario   numeric(14,4) NOT NULL DEFAULT 0 CHECK (custo_unitario >= 0),
  created_at       timestamptz NOT NULL DEFAULT now(),
  updated_at       timestamptz NOT NULL DEFAULT now(),
  deleted_at       timestamptz,
  PRIMARY KEY (id, tenant_id, workspace_id),
  FOREIGN KEY (workspace_id, tenant_id) REFERENCES workspaces (id, tenant_id),
  FOREIGN KEY (creator_id, tenant_id, workspace_id) REFERENCES usuarios (id, tenant_id, workspace_id),
  FOREIGN KEY (movimentacao_id, tenant_id, workspace_id) REFERENCES estoque_movimentacoes (id, tenant_id, workspace_id),
  FOREIGN KEY (produto_id, tenant_id, workspace_id) REFERENCES estoque_produtos (id, tenant_id, workspace_id),
  FOREIGN KEY (variacao_id, tenant_id, workspace_id) REFERENCES estoque_variacoes (id, tenant_id, workspace_id),
  FOREIGN KEY (lote_id, tenant_id, workspace_id) REFERENCES estoque_lotes (id, tenant_id, workspace_id),
  FOREIGN KEY (deposito_id, tenant_id, workspace_id) REFERENCES estoque_depositos (id, tenant_id, workspace_id),
  FOREIGN KEY (local_id, tenant_id, workspace_id) REFERENCES estoque_locais (id, tenant_id, workspace_id)
);
CREATE INDEX IF NOT EXISTS estoque_mov_itens_mov_idx ON estoque_movimentacao_itens (tenant_id, workspace_id, movimentacao_id);
CREATE INDEX IF NOT EXISTS estoque_mov_itens_saldo_idx ON estoque_movimentacao_itens (tenant_id, workspace_id, produto_id, deposito_id) WHERE deleted_at IS NULL;
SELECT nucleo_aplicar_padrao('estoque_movimentacao_itens');

DO $$ BEGIN
  ALTER TABLE estoque_inventarios ADD CONSTRAINT estoque_inventarios_mov_fk
    FOREIGN KEY (movimentacao_id, tenant_id, workspace_id) REFERENCES estoque_movimentacoes (id, tenant_id, workspace_id);
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

-- Saldo: soma das movimentacoes (security_invoker: a RLS das tabelas vale para quem consulta).
CREATE OR REPLACE VIEW estoque_saldos WITH (security_invoker = true) AS
  SELECT i.tenant_id, i.workspace_id, i.produto_id, i.variacao_id, i.lote_id, i.deposito_id, i.local_id,
         sum(i.quantidade)::numeric(14,3) AS quantidade
  FROM estoque_movimentacao_itens i
  WHERE i.deleted_at IS NULL
  GROUP BY i.tenant_id, i.workspace_id, i.produto_id, i.variacao_id, i.lote_id, i.deposito_id, i.local_id;

-- M9.4 Reposicao: alerta aberto quando o saldo cai abaixo do minimo (gerado pelo job do worker) ---
CREATE TABLE IF NOT EXISTS estoque_alertas (
  id              uuid NOT NULL DEFAULT gen_random_uuid(),
  tenant_id       uuid NOT NULL DEFAULT nucleo_tenant_atual(),
  workspace_id    uuid NOT NULL DEFAULT nucleo_workspace_atual(),
  creator_id      uuid,
  produto_id      uuid NOT NULL,
  saldo           numeric(14,3) NOT NULL,
  estoque_minimo  numeric(14,3) NOT NULL,
  estado          text NOT NULL DEFAULT 'aberto' CHECK (estado IN ('aberto', 'resolvido')),
  resolvido_em    timestamptz,
  created_at      timestamptz NOT NULL DEFAULT now(),
  updated_at      timestamptz NOT NULL DEFAULT now(),
  deleted_at      timestamptz,
  PRIMARY KEY (id, tenant_id, workspace_id),
  FOREIGN KEY (workspace_id, tenant_id) REFERENCES workspaces (id, tenant_id),
  FOREIGN KEY (creator_id, tenant_id, workspace_id) REFERENCES usuarios (id, tenant_id, workspace_id),
  FOREIGN KEY (produto_id, tenant_id, workspace_id) REFERENCES estoque_produtos (id, tenant_id, workspace_id)
);
CREATE UNIQUE INDEX IF NOT EXISTS estoque_alertas_aberto_uq
  ON estoque_alertas (tenant_id, workspace_id, produto_id) WHERE estado = 'aberto' AND deleted_at IS NULL;
SELECT nucleo_aplicar_padrao('estoque_alertas');

-- Papeis de banco: API (erp_app) e worker (erp_worker: reposicao e parceiro.mesclado).
GRANT SELECT, INSERT, UPDATE ON estoque_unidades, estoque_produtos, estoque_variacoes, estoque_lotes, estoque_depositos,
  estoque_locais, estoque_inventarios, estoque_inventario_itens, estoque_movimentacoes, estoque_movimentacao_itens,
  estoque_alertas TO erp_app;
GRANT SELECT ON estoque_saldos TO erp_app, erp_worker;
GRANT SELECT, INSERT, UPDATE ON estoque_alertas TO erp_worker;
GRANT SELECT, UPDATE ON estoque_produtos, estoque_movimentacoes TO erp_worker;
GRANT SELECT ON estoque_unidades, estoque_variacoes, estoque_lotes, estoque_depositos, estoque_locais, estoque_inventarios,
  estoque_inventario_itens, estoque_movimentacao_itens TO erp_worker;
